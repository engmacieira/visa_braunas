import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/indicadores/TabelaAlertasOperacionais.tsx");const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport5_react_jsxDevRuntime["jsxDEV"];/**
* Painel e Tabela de Alertas Operacionais de Vencimento
* Monitora notificações sanitárias com prazos de adequação expirados/expirando
* e alvarás sanitários próximos da renovação (30/60 dias).
*/
import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=0fd2848a";
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=0fd2848a";
import { ArrowRight, Calendar, Clock, ExternalLink, FileCheck2, FileWarning, ShieldAlert } from "/node_modules/.vite/deps/lucide-react.js?v=0fd2848a";
import { APP_CONFIG } from "/src/config/app.config.ts";
import { ROUTES } from "/src/config/routes.config.ts";
var _jsxFileName = "E:/Projetos VSCODE/visa_braunas/src/components/indicadores/TabelaAlertasOperacionais.tsx";
import __vite__cjsImport5_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=0fd2848a";
var _s = $RefreshSig$();
export const TabelaAlertasOperacionais = ({ alertas, isLoading }) => {
	_s();
	const [abaAtiva, setAbaAtiva] = useState("notificacoes");
	const notificacoes = alertas?.notificacoes || [];
	const documentos = alertas?.documentos || [];
	const totalNotificacoesCriticas = alertas?.total_notificacoes_criticas || notificacoes.length;
	const totalDocumentosVencendo = alertas?.total_documentos_vencendo || documentos.length;
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 shadow-xs space-y-5",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-100 dark:border-slate-800",
				children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h2", {
					className: "text-base font-bold text-slate-900 dark:text-white flex items-center gap-2",
					children: [/* @__PURE__ */ _jsxDEV(ShieldAlert, { className: "w-5 h-5 text-amber-500" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 46,
						columnNumber: 13
					}, this), "Alertas Operacionais & Controle de Prazos Legais"]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 45,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("p", {
					className: "text-xs text-slate-500 dark:text-slate-400 mt-0.5",
					children: [
						"Monitoramento de termos de notificação de campo e vigência de alvarás de ",
						APP_CONFIG.municipio,
						"/",
						APP_CONFIG.uf
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 49,
					columnNumber: 11
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 44,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-1 bg-slate-100 dark:bg-slate-800 p-1 rounded-lg self-start sm:self-auto",
					children: [/* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						onClick: () => setAbaAtiva("notificacoes"),
						className: `flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-semibold transition-all ${abaAtiva === "notificacoes" ? "bg-white dark:bg-slate-900 text-rose-700 dark:text-rose-400 shadow-xs" : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"}`,
						children: [
							/* @__PURE__ */ _jsxDEV(FileWarning, { className: "w-3.5 h-3.5" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 65,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("span", { children: "Notificações / Prazos" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 66,
								columnNumber: 13
							}, this),
							totalNotificacoesCriticas > 0 && /* @__PURE__ */ _jsxDEV("span", {
								className: "px-1.5 py-0.2 rounded-full text-[10px] bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300 font-bold",
								children: totalNotificacoesCriticas
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 68,
								columnNumber: 15
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 56,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						onClick: () => setAbaAtiva("documentos"),
						className: `flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-semibold transition-all ${abaAtiva === "documentos" ? "bg-white dark:bg-slate-900 text-teal-700 dark:text-teal-400 shadow-xs" : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"}`,
						children: [
							/* @__PURE__ */ _jsxDEV(FileCheck2, { className: "w-3.5 h-3.5" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 83,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("span", { children: "Alvarás a Vencer" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 84,
								columnNumber: 13
							}, this),
							totalDocumentosVencendo > 0 && /* @__PURE__ */ _jsxDEV("span", {
								className: "px-1.5 py-0.2 rounded-full text-[10px] bg-teal-100 text-teal-800 dark:bg-teal-950 dark:text-teal-300 font-bold",
								children: totalDocumentosVencendo
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 86,
								columnNumber: 15
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 74,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 55,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 43,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "grid grid-cols-1 sm:grid-cols-2 gap-4",
				children: [/* @__PURE__ */ _jsxDEV(Link, {
					to: ROUTES.INSPECOES.PRAZOS,
					className: "p-4 rounded-xl border border-rose-200 dark:border-rose-900/60 bg-rose-50/40 dark:bg-rose-950/20 hover:bg-rose-50 dark:hover:bg-rose-950/30 transition-all flex items-center justify-between group",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "w-10 h-10 rounded-lg bg-rose-100 dark:bg-rose-900/40 text-rose-600 flex items-center justify-center shrink-0",
							children: /* @__PURE__ */ _jsxDEV(Clock, { className: "w-5 h-5" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 102,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 101,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("div", { children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "text-xs font-bold text-rose-900 dark:text-rose-300 uppercase tracking-wider",
								children: "Prazos Fiscais Críticos"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 105,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "text-xl font-extrabold text-rose-700 dark:text-rose-400 tabular-nums",
								children: [totalNotificacoesCriticas, " pendentes"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 108,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("p", {
								className: "text-[11px] text-rose-600 dark:text-rose-400",
								children: "Notificações com prazo vencido ou a expirar em 7 dias"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 111,
								columnNumber: 15
							}, this)
						] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 104,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 100,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV(ArrowRight, { className: "w-4 h-4 text-rose-500 group-hover:translate-x-1 transition-transform" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 116,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 96,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV(Link, {
					to: ROUTES.LICENCIAMENTO.LIST,
					className: "p-4 rounded-xl border border-amber-200 dark:border-amber-900/60 bg-amber-50/40 dark:bg-amber-950/20 hover:bg-amber-50 dark:hover:bg-amber-950/30 transition-all flex items-center justify-between group",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "w-10 h-10 rounded-lg bg-amber-100 dark:bg-amber-900/40 text-amber-600 flex items-center justify-center shrink-0",
							children: /* @__PURE__ */ _jsxDEV(Calendar, { className: "w-5 h-5" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 125,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 124,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("div", { children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "text-xs font-bold text-amber-900 dark:text-amber-300 uppercase tracking-wider",
								children: "Alvarás a Renovar"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 128,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "text-xl font-extrabold text-amber-700 dark:text-amber-400 tabular-nums",
								children: [totalDocumentosVencendo, " nos próximos 30/60 dias"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 131,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("p", {
								className: "text-[11px] text-amber-600 dark:text-amber-400",
								children: "Licenças com término de vigência regulatória"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 134,
								columnNumber: 15
							}, this)
						] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 127,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 123,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV(ArrowRight, { className: "w-4 h-4 text-amber-500 group-hover:translate-x-1 transition-transform" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 139,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 119,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 95,
				columnNumber: 7
			}, this),
			isLoading ? /* @__PURE__ */ _jsxDEV("div", {
				className: "p-8 text-center text-xs text-slate-400 flex flex-col items-center justify-center",
				children: [/* @__PURE__ */ _jsxDEV("div", { className: "w-6 h-6 border-2 border-teal-500 border-t-transparent rounded-full animate-spin mb-2" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 146,
					columnNumber: 11
				}, this), "Carregando alertas do sistema..."]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 145,
				columnNumber: 9
			}, this) : abaAtiva === "notificacoes" ? /* @__PURE__ */ _jsxDEV("div", {
				className: "overflow-x-auto border border-slate-200 dark:border-slate-800 rounded-lg",
				children: /* @__PURE__ */ _jsxDEV("table", {
					className: "w-full text-left text-xs",
					children: [/* @__PURE__ */ _jsxDEV("thead", {
						className: "bg-slate-50 dark:bg-slate-800/60 text-slate-500 uppercase font-semibold text-[11px] border-b border-slate-200 dark:border-slate-800",
						children: /* @__PURE__ */ _jsxDEV("tr", { children: [
							/* @__PURE__ */ _jsxDEV("th", {
								className: "py-2.5 px-3",
								children: "Termo"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 154,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV("th", {
								className: "py-2.5 px-3",
								children: "Estabelecimento / CNPJ"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 155,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV("th", {
								className: "py-2.5 px-3",
								children: "Fiscal"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 156,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV("th", {
								className: "py-2.5 px-3",
								children: "Limite Legal"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 157,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV("th", {
								className: "py-2.5 px-3 text-center",
								children: "Status / Restante"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 158,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV("th", {
								className: "py-2.5 px-3 text-right",
								children: "Ação"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 159,
								columnNumber: 17
							}, this)
						] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 153,
							columnNumber: 15
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 152,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("tbody", {
						className: "divide-y divide-slate-100 dark:divide-slate-800",
						children: notificacoes.length === 0 ? /* @__PURE__ */ _jsxDEV("tr", { children: /* @__PURE__ */ _jsxDEV("td", {
							colSpan: 6,
							className: "py-8 text-center text-slate-400",
							children: "Nenhuma notificação fiscal com prazo crítico pendente."
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 165,
							columnNumber: 19
						}, this) }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 164,
							columnNumber: 17
						}, this) : notificacoes.map((item) => {
							const isVencido = item.dias_restantes < 0;
							const isCritico = item.dias_restantes >= 0 && item.dias_restantes <= 7;
							return /* @__PURE__ */ _jsxDEV("tr", {
								className: "hover:bg-slate-50/60 dark:hover:bg-slate-800/40 transition-colors",
								children: [
									/* @__PURE__ */ _jsxDEV("td", {
										className: "py-2.5 px-3 font-mono font-bold text-slate-900 dark:text-white",
										children: item.numero_termo || "NOT-2026"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 179,
										columnNumber: 23
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										className: "py-2.5 px-3",
										children: [/* @__PURE__ */ _jsxDEV("div", {
											className: "font-semibold text-slate-800 dark:text-slate-200 truncate max-w-[220px]",
											children: item.razao_social
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 183,
											columnNumber: 25
										}, this), /* @__PURE__ */ _jsxDEV("div", {
											className: "text-[11px] text-slate-400 font-mono",
											children: item.cnpj_cpf
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 186,
											columnNumber: 25
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 182,
										columnNumber: 23
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										className: "py-2.5 px-3 text-slate-600 dark:text-slate-300",
										children: item.fiscal_responsavel || "Fiscal VISA"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 190,
										columnNumber: 23
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										className: "py-2.5 px-3 text-slate-600 dark:text-slate-300 font-mono",
										children: item.data_limite_cumprimento
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 193,
										columnNumber: 23
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										className: "py-2.5 px-3 text-center",
										children: /* @__PURE__ */ _jsxDEV("span", {
											className: `inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold uppercase ${isVencido ? "bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300 border border-rose-300" : isCritico ? "bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300 border border-amber-300" : "bg-blue-50 text-blue-700 dark:bg-blue-950 dark:text-blue-300 border border-blue-200"}`,
											children: isVencido ? `Vencido há ${Math.abs(item.dias_restantes)}d` : `${item.dias_restantes} dias restantes`
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 197,
											columnNumber: 25
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 196,
										columnNumber: 23
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										className: "py-2.5 px-3 text-right",
										children: /* @__PURE__ */ _jsxDEV(Link, {
											to: ROUTES.INSPECOES.LIST,
											className: "inline-flex items-center gap-1 text-[11px] font-semibold text-teal-600 hover:text-teal-700 hover:underline",
											children: [/* @__PURE__ */ _jsxDEV("span", { children: "Reinspecionar" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 216,
												columnNumber: 27
											}, this), /* @__PURE__ */ _jsxDEV(ExternalLink, { className: "w-3 h-3" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 217,
												columnNumber: 27
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 212,
											columnNumber: 25
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 211,
										columnNumber: 23
									}, this)
								]
							}, item.inspecao_id, true, {
								fileName: _jsxFileName,
								lineNumber: 175,
								columnNumber: 21
							}, this);
						})
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 162,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 151,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 150,
				columnNumber: 9
			}, this) : /* @__PURE__ */ _jsxDEV("div", {
				className: "overflow-x-auto border border-slate-200 dark:border-slate-800 rounded-lg",
				children: /* @__PURE__ */ _jsxDEV("table", {
					className: "w-full text-left text-xs",
					children: [/* @__PURE__ */ _jsxDEV("thead", {
						className: "bg-slate-50 dark:bg-slate-800/60 text-slate-500 uppercase font-semibold text-[11px] border-b border-slate-200 dark:border-slate-800",
						children: /* @__PURE__ */ _jsxDEV("tr", { children: [
							/* @__PURE__ */ _jsxDEV("th", {
								className: "py-2.5 px-3",
								children: "Documento"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 232,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV("th", {
								className: "py-2.5 px-3",
								children: "Estabelecimento"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 233,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV("th", {
								className: "py-2.5 px-3",
								children: "Categoria"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 234,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV("th", {
								className: "py-2.5 px-3",
								children: "Data Vencimento"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 235,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV("th", {
								className: "py-2.5 px-3 text-center",
								children: "Dias para Expirar"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 236,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV("th", {
								className: "py-2.5 px-3 text-right",
								children: "Ação"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 237,
								columnNumber: 17
							}, this)
						] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 231,
							columnNumber: 15
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 230,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("tbody", {
						className: "divide-y divide-slate-100 dark:divide-slate-800",
						children: documentos.length === 0 ? /* @__PURE__ */ _jsxDEV("tr", { children: /* @__PURE__ */ _jsxDEV("td", {
							colSpan: 6,
							className: "py-8 text-center text-slate-400",
							children: "Nenhum alvará ou documento sanitário vencendo nos próximos 30 dias."
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 243,
							columnNumber: 19
						}, this) }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 242,
							columnNumber: 17
						}, this) : documentos.map((item) => /* @__PURE__ */ _jsxDEV("tr", {
							className: "hover:bg-slate-50/60 dark:hover:bg-slate-800/40 transition-colors",
							children: [
								/* @__PURE__ */ _jsxDEV("td", {
									className: "py-2.5 px-3 font-semibold text-slate-900 dark:text-white",
									children: item.nome_documento
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 253,
									columnNumber: 21
								}, this),
								/* @__PURE__ */ _jsxDEV("td", {
									className: "py-2.5 px-3 text-slate-700 dark:text-slate-300 truncate max-w-[220px]",
									children: item.razao_social
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 256,
									columnNumber: 21
								}, this),
								/* @__PURE__ */ _jsxDEV("td", {
									className: "py-2.5 px-3 text-slate-500 capitalize",
									children: item.categoria
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 259,
									columnNumber: 21
								}, this),
								/* @__PURE__ */ _jsxDEV("td", {
									className: "py-2.5 px-3 font-mono text-slate-700 dark:text-slate-300",
									children: item.data_vencimento
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 262,
									columnNumber: 21
								}, this),
								/* @__PURE__ */ _jsxDEV("td", {
									className: "py-2.5 px-3 text-center",
									children: /* @__PURE__ */ _jsxDEV("span", {
										className: "inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold bg-amber-50 text-amber-700 dark:bg-amber-950 dark:text-amber-300 border border-amber-200",
										children: [item.dias_para_vencimento, " dias"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 266,
										columnNumber: 23
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 265,
									columnNumber: 21
								}, this),
								/* @__PURE__ */ _jsxDEV("td", {
									className: "py-2.5 px-3 text-right",
									children: /* @__PURE__ */ _jsxDEV(Link, {
										to: ROUTES.LICENCIAMENTO.LIST,
										className: "inline-flex items-center gap-1 text-[11px] font-semibold text-teal-600 hover:text-teal-700 hover:underline",
										children: [/* @__PURE__ */ _jsxDEV("span", { children: "Abrir Renovação" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 275,
											columnNumber: 25
										}, this), /* @__PURE__ */ _jsxDEV(ExternalLink, { className: "w-3 h-3" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 276,
											columnNumber: 25
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 271,
										columnNumber: 23
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 270,
									columnNumber: 21
								}, this)
							]
						}, item.documento_id, true, {
							fileName: _jsxFileName,
							lineNumber: 249,
							columnNumber: 19
						}, this))
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 240,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 229,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 228,
				columnNumber: 9
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 41,
		columnNumber: 5
	}, this);
};
_s(TabelaAlertasOperacionais, "CpPvULpXli7EzFTcXyWFmyKkveE=");
_c = TabelaAlertasOperacionais;
export default TabelaAlertasOperacionais;
var _c;
$RefreshReg$(_c, "TabelaAlertasOperacionais");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/indicadores/TabelaAlertasOperacionais.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("E:/Projetos VSCODE/visa_braunas/src/components/indicadores/TabelaAlertasOperacionais.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("E:/Projetos VSCODE/visa_braunas/src/components/indicadores/TabelaAlertasOperacionais.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "E:/Projetos VSCODE/visa_braunas/src/components/indicadores/TabelaAlertasOperacionais.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7Ozs7QUFNQSxPQUFPLFNBQVMsZ0JBQWdCO0FBQ2hDLFNBQVMsWUFBWTtBQUNyQixTQUdFLFlBQ0EsVUFDQSxPQUNBLGNBQ0EsWUFDQSxhQUNBLG1CQUNLO0FBQ1AsU0FBUyxrQkFBa0I7QUFDM0IsU0FBUyxjQUFjOzs7O0FBUXZCLE9BQU8sTUFBTSw2QkFBdUUsRUFDbEYsU0FDQSxnQkFDSTs7Q0FDSixNQUFNLENBQUMsVUFBVSxlQUFlLFNBQXdDLGNBQWM7Q0FFdEYsTUFBTSxlQUFlLFNBQVMsZ0JBQWdCLENBQUM7Q0FDL0MsTUFBTSxhQUFhLFNBQVMsY0FBYyxDQUFDO0NBQzNDLE1BQU0sNEJBQTRCLFNBQVMsK0JBQStCLGFBQWE7Q0FDdkYsTUFBTSwwQkFBMEIsU0FBUyw2QkFBNkIsV0FBVztDQUVqRixPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQWY7R0FFRSx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE1BQUQ7S0FBSSxXQUFVO2VBQWQsQ0FDRSx3QkFBQyxhQUFELEVBQWEsV0FBVSx5QkFBMEI7Ozs7ZUFBQyxrREFFaEQ7Ozs7O2NBQ0osd0JBQUMsS0FBRDtLQUFHLFdBQVU7ZUFBYjtNQUFpRTtNQUNXLFdBQVc7TUFBVTtNQUFFLFdBQVc7S0FDM0c7Ozs7O1lBQ0E7Ozs7Y0FHTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsVUFBRDtNQUNFLE1BQUs7TUFDTCxlQUFlLFlBQVksY0FBYztNQUN6QyxXQUFXLHlGQUNULGFBQWEsaUJBQ1QsMEVBQ0E7Z0JBTlI7T0FTRSx3QkFBQyxhQUFELEVBQWEsV0FBVSxjQUFlOzs7OztPQUN0Qyx3QkFBQyxRQUFELFlBQU0sd0JBQTJCOzs7OztPQUNoQyw0QkFBNEIsS0FDM0Isd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQ2I7T0FDRzs7Ozs7TUFFRjs7Ozs7ZUFFUix3QkFBQyxVQUFEO01BQ0UsTUFBSztNQUNMLGVBQWUsWUFBWSxZQUFZO01BQ3ZDLFdBQVcseUZBQ1QsYUFBYSxlQUNULDBFQUNBO2dCQU5SO09BU0Usd0JBQUMsWUFBRCxFQUFZLFdBQVUsY0FBZTs7Ozs7T0FDckMsd0JBQUMsUUFBRCxZQUFNLG1CQUFzQjs7Ozs7T0FDM0IsMEJBQTBCLEtBQ3pCLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUNiO09BQ0c7Ozs7O01BRUY7Ozs7O2FBQ0w7Ozs7O1lBQ0Y7Ozs7OztHQUdMLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxNQUFEO0tBQ0UsSUFBSSxPQUFPLFVBQVU7S0FDckIsV0FBVTtlQUZaLENBSUUsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFDYix3QkFBQyxPQUFELEVBQU8sV0FBVSxVQUFXOzs7OztNQUN6Qjs7OztnQkFDTCx3QkFBQyxPQUFEO09BQ0Usd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQThFO09BRXhGOzs7OztPQUNMLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0csMkJBQTBCLFlBQ3hCOzs7Ozs7T0FDTCx3QkFBQyxLQUFEO1FBQUcsV0FBVTtrQkFBK0M7T0FFekQ7Ozs7O01BQ0E7Ozs7Y0FDRjs7Ozs7ZUFDTCx3QkFBQyxZQUFELEVBQVksV0FBVSx1RUFBd0U7Ozs7YUFDMUY7Ozs7O2NBRU4sd0JBQUMsTUFBRDtLQUNFLElBQUksT0FBTyxjQUFjO0tBQ3pCLFdBQVU7ZUFGWixDQUlFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQ2Isd0JBQUMsVUFBRCxFQUFVLFdBQVUsVUFBVzs7Ozs7TUFDNUI7Ozs7Z0JBQ0wsd0JBQUMsT0FBRDtPQUNFLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFnRjtPQUUxRjs7Ozs7T0FDTCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNHLHlCQUF3QiwwQkFDdEI7Ozs7OztPQUNMLHdCQUFDLEtBQUQ7UUFBRyxXQUFVO2tCQUFpRDtPQUUzRDs7Ozs7TUFDQTs7OztjQUNGOzs7OztlQUNMLHdCQUFDLFlBQUQsRUFBWSxXQUFVLHdFQUF5RTs7OzthQUMzRjs7Ozs7WUFDSDs7Ozs7O0dBR0osWUFDQyx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsT0FBRCxFQUFLLFdBQVUsdUZBQXdGOzs7O2NBQUMsa0NBRXJHOzs7OztjQUNILGFBQWEsaUJBQ2Ysd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FDYix3QkFBQyxTQUFEO0tBQU8sV0FBVTtlQUFqQixDQUNFLHdCQUFDLFNBQUQ7TUFBTyxXQUFVO2dCQUNmLHdCQUFDLE1BQUQ7T0FDRSx3QkFBQyxNQUFEO1FBQUksV0FBVTtrQkFBYztPQUFTOzs7OztPQUNyQyx3QkFBQyxNQUFEO1FBQUksV0FBVTtrQkFBYztPQUEwQjs7Ozs7T0FDdEQsd0JBQUMsTUFBRDtRQUFJLFdBQVU7a0JBQWM7T0FBVTs7Ozs7T0FDdEMsd0JBQUMsTUFBRDtRQUFJLFdBQVU7a0JBQWM7T0FBZ0I7Ozs7O09BQzVDLHdCQUFDLE1BQUQ7UUFBSSxXQUFVO2tCQUEwQjtPQUFxQjs7Ozs7T0FDN0Qsd0JBQUMsTUFBRDtRQUFJLFdBQVU7a0JBQXlCO09BQVE7Ozs7O01BQzdDOzs7OztLQUNDOzs7O2VBQ1Asd0JBQUMsU0FBRDtNQUFPLFdBQVU7Z0JBQ2QsYUFBYSxXQUFXLElBQ3ZCLHdCQUFDLE1BQUQsWUFDRSx3QkFBQyxNQUFEO09BQUksU0FBUztPQUFHLFdBQVU7aUJBQWtDO01BRXhEOzs7O2VBQ0Y7Ozs7aUJBRUosYUFBYSxLQUFLLFNBQVM7T0FDekIsTUFBTSxZQUFZLEtBQUssaUJBQWlCO09BQ3hDLE1BQU0sWUFBWSxLQUFLLGtCQUFrQixLQUFLLEtBQUssa0JBQWtCO09BRXJFLE9BQ0Usd0JBQUMsTUFBRDtRQUVFLFdBQVU7a0JBRlo7U0FJRSx3QkFBQyxNQUFEO1VBQUksV0FBVTtvQkFDWCxLQUFLLGdCQUFnQjtTQUNwQjs7Ozs7U0FDSix3QkFBQyxNQUFEO1VBQUksV0FBVTtvQkFBZCxDQUNFLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUNaLEtBQUs7VUFDSDs7OztvQkFDTCx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFDWixLQUFLO1VBQ0g7Ozs7a0JBQ0g7Ozs7OztTQUNKLHdCQUFDLE1BQUQ7VUFBSSxXQUFVO29CQUNYLEtBQUssc0JBQXNCO1NBQzFCOzs7OztTQUNKLHdCQUFDLE1BQUQ7VUFBSSxXQUFVO29CQUNYLEtBQUs7U0FDSjs7Ozs7U0FDSix3QkFBQyxNQUFEO1VBQUksV0FBVTtvQkFDWix3QkFBQyxRQUFEO1dBQ0UsV0FBVyxnRkFDVCxZQUNJLHlGQUNBLFlBQ0EsOEZBQ0E7cUJBR0wsWUFDRyxjQUFjLEtBQUssSUFBSSxLQUFLLGNBQWMsRUFBRSxLQUM1QyxHQUFHLEtBQUssZUFBZTtVQUN2Qjs7Ozs7U0FDSjs7Ozs7U0FDSix3QkFBQyxNQUFEO1VBQUksV0FBVTtvQkFDWix3QkFBQyxNQUFEO1dBQ0UsSUFBSSxPQUFPLFVBQVU7V0FDckIsV0FBVTtxQkFGWixDQUlFLHdCQUFDLFFBQUQsWUFBTSxnQkFBbUI7Ozs7cUJBQ3pCLHdCQUFDLGNBQUQsRUFBYyxXQUFVLFVBQVc7Ozs7bUJBQy9COzs7Ozs7U0FDSjs7Ozs7UUFDRjtVQTVDRyxLQUFLOzs7O2NBNENSO01BRVIsQ0FBQztLQUVFOzs7O2FBQ0Y7Ozs7OztHQUNKOzs7O2NBRUwsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FDYix3QkFBQyxTQUFEO0tBQU8sV0FBVTtlQUFqQixDQUNFLHdCQUFDLFNBQUQ7TUFBTyxXQUFVO2dCQUNmLHdCQUFDLE1BQUQ7T0FDRSx3QkFBQyxNQUFEO1FBQUksV0FBVTtrQkFBYztPQUFhOzs7OztPQUN6Qyx3QkFBQyxNQUFEO1FBQUksV0FBVTtrQkFBYztPQUFtQjs7Ozs7T0FDL0Msd0JBQUMsTUFBRDtRQUFJLFdBQVU7a0JBQWM7T0FBYTs7Ozs7T0FDekMsd0JBQUMsTUFBRDtRQUFJLFdBQVU7a0JBQWM7T0FBbUI7Ozs7O09BQy9DLHdCQUFDLE1BQUQ7UUFBSSxXQUFVO2tCQUEwQjtPQUFxQjs7Ozs7T0FDN0Qsd0JBQUMsTUFBRDtRQUFJLFdBQVU7a0JBQXlCO09BQVE7Ozs7O01BQzdDOzs7OztLQUNDOzs7O2VBQ1Asd0JBQUMsU0FBRDtNQUFPLFdBQVU7Z0JBQ2QsV0FBVyxXQUFXLElBQ3JCLHdCQUFDLE1BQUQsWUFDRSx3QkFBQyxNQUFEO09BQUksU0FBUztPQUFHLFdBQVU7aUJBQWtDO01BRXhEOzs7O2VBQ0Y7Ozs7aUJBRUosV0FBVyxLQUFLLFNBQ2Qsd0JBQUMsTUFBRDtPQUVFLFdBQVU7aUJBRlo7UUFJRSx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFDWCxLQUFLO1FBQ0o7Ozs7O1FBQ0osd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQ1gsS0FBSztRQUNKOzs7OztRQUNKLHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUNYLEtBQUs7UUFDSjs7Ozs7UUFDSix3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFDWCxLQUFLO1FBQ0o7Ozs7O1FBQ0osd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQ1osd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQWhCLENBQ0csS0FBSyxzQkFBcUIsT0FDdkI7Ozs7OztRQUNKOzs7OztRQUNKLHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUNaLHdCQUFDLE1BQUQ7VUFDRSxJQUFJLE9BQU8sY0FBYztVQUN6QixXQUFVO29CQUZaLENBSUUsd0JBQUMsUUFBRCxZQUFNLGtCQUFxQjs7OztvQkFDM0Isd0JBQUMsY0FBRCxFQUFjLFdBQVUsVUFBVzs7OztrQkFDL0I7Ozs7OztRQUNKOzs7OztPQUNGO1NBN0JHLEtBQUs7Ozs7YUE2QlIsQ0FDTDtLQUVFOzs7O2FBQ0Y7Ozs7OztHQUNKOzs7OztFQUVKOzs7Ozs7QUFFVDs7O0FBRUEsZUFBZSIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJUYWJlbGFBbGVydGFzT3BlcmFjaW9uYWlzLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyIvKipcclxuICogUGFpbmVsIGUgVGFiZWxhIGRlIEFsZXJ0YXMgT3BlcmFjaW9uYWlzIGRlIFZlbmNpbWVudG9cclxuICogTW9uaXRvcmEgbm90aWZpY2HDp8O1ZXMgc2FuaXTDoXJpYXMgY29tIHByYXpvcyBkZSBhZGVxdWHDp8OjbyBleHBpcmFkb3MvZXhwaXJhbmRvXHJcbiAqIGUgYWx2YXLDoXMgc2FuaXTDoXJpb3MgcHLDs3hpbW9zIGRhIHJlbm92YcOnw6NvICgzMC82MCBkaWFzKS5cclxuICovXHJcblxyXG5pbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHsgTGluayB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCI7XHJcbmltcG9ydCB7XHJcbiAgQWxlcnRDaXJjbGUsXHJcbiAgQWxlcnRUcmlhbmdsZSxcclxuICBBcnJvd1JpZ2h0LFxyXG4gIENhbGVuZGFyLFxyXG4gIENsb2NrLFxyXG4gIEV4dGVybmFsTGluayxcclxuICBGaWxlQ2hlY2syLFxyXG4gIEZpbGVXYXJuaW5nLFxyXG4gIFNoaWVsZEFsZXJ0LFxyXG59IGZyb20gXCJsdWNpZGUtcmVhY3RcIjtcclxuaW1wb3J0IHsgQVBQX0NPTkZJRyB9IGZyb20gXCIuLi8uLi9jb25maWcvYXBwLmNvbmZpZ1wiO1xyXG5pbXBvcnQgeyBST1VURVMgfSBmcm9tIFwiLi4vLi4vY29uZmlnL3JvdXRlcy5jb25maWdcIjtcclxuaW1wb3J0IHsgQWxlcnRhc1ZlbmNpbWVudG9SZXNwb25zZSB9IGZyb20gXCIuLi8uLi90eXBlcy9pbmRpY2Fkb3Jlc1wiO1xyXG5cclxuaW50ZXJmYWNlIFRhYmVsYUFsZXJ0YXNPcGVyYWNpb25haXNQcm9wcyB7XHJcbiAgYWxlcnRhcz86IEFsZXJ0YXNWZW5jaW1lbnRvUmVzcG9uc2U7XHJcbiAgaXNMb2FkaW5nPzogYm9vbGVhbjtcclxufVxyXG5cclxuZXhwb3J0IGNvbnN0IFRhYmVsYUFsZXJ0YXNPcGVyYWNpb25haXM6IFJlYWN0LkZDPFRhYmVsYUFsZXJ0YXNPcGVyYWNpb25haXNQcm9wcz4gPSAoe1xyXG4gIGFsZXJ0YXMsXHJcbiAgaXNMb2FkaW5nLFxyXG59KSA9PiB7XHJcbiAgY29uc3QgW2FiYUF0aXZhLCBzZXRBYmFBdGl2YV0gPSB1c2VTdGF0ZTxcIm5vdGlmaWNhY29lc1wiIHwgXCJkb2N1bWVudG9zXCI+KFwibm90aWZpY2Fjb2VzXCIpO1xyXG5cclxuICBjb25zdCBub3RpZmljYWNvZXMgPSBhbGVydGFzPy5ub3RpZmljYWNvZXMgfHwgW107XHJcbiAgY29uc3QgZG9jdW1lbnRvcyA9IGFsZXJ0YXM/LmRvY3VtZW50b3MgfHwgW107XHJcbiAgY29uc3QgdG90YWxOb3RpZmljYWNvZXNDcml0aWNhcyA9IGFsZXJ0YXM/LnRvdGFsX25vdGlmaWNhY29lc19jcml0aWNhcyB8fCBub3RpZmljYWNvZXMubGVuZ3RoO1xyXG4gIGNvbnN0IHRvdGFsRG9jdW1lbnRvc1ZlbmNlbmRvID0gYWxlcnRhcz8udG90YWxfZG9jdW1lbnRvc192ZW5jZW5kbyB8fCBkb2N1bWVudG9zLmxlbmd0aDtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGFyazpiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtODAwIHJvdW5kZWQteGwgcC02IHNoYWRvdy14cyBzcGFjZS15LTVcIj5cclxuICAgICAgey8qIENhYmXDp2FsaG8gZG8gUGFpbmVsIGRlIEFsZXJ0YXMgKi99XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBzbTpmbGV4LXJvdyBzbTppdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC0zIHBiLTQgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTEwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDBcIj5cclxuICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtYmFzZSBmb250LWJvbGQgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgIDxTaGllbGRBbGVydCBjbGFzc05hbWU9XCJ3LTUgaC01IHRleHQtYW1iZXItNTAwXCIgLz5cclxuICAgICAgICAgICAgQWxlcnRhcyBPcGVyYWNpb25haXMgJiBDb250cm9sZSBkZSBQcmF6b3MgTGVnYWlzXHJcbiAgICAgICAgICA8L2gyPlxyXG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTUwMCBkYXJrOnRleHQtc2xhdGUtNDAwIG10LTAuNVwiPlxyXG4gICAgICAgICAgICBNb25pdG9yYW1lbnRvIGRlIHRlcm1vcyBkZSBub3RpZmljYcOnw6NvIGRlIGNhbXBvIGUgdmlnw6puY2lhIGRlIGFsdmFyw6FzIGRlIHtBUFBfQ09ORklHLm11bmljaXBpb30ve0FQUF9DT05GSUcudWZ9XHJcbiAgICAgICAgICA8L3A+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIHsvKiBBYmFzIEFsdGVybsOhdmVpcyAqL31cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xIGJnLXNsYXRlLTEwMCBkYXJrOmJnLXNsYXRlLTgwMCBwLTEgcm91bmRlZC1sZyBzZWxmLXN0YXJ0IHNtOnNlbGYtYXV0b1wiPlxyXG4gICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0QWJhQXRpdmEoXCJub3RpZmljYWNvZXNcIil9XHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT17YGZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgcHgtMyBweS0xLjUgcm91bmRlZC1tZCB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdHJhbnNpdGlvbi1hbGwgJHtcclxuICAgICAgICAgICAgICBhYmFBdGl2YSA9PT0gXCJub3RpZmljYWNvZXNcIlxyXG4gICAgICAgICAgICAgICAgPyBcImJnLXdoaXRlIGRhcms6Ymctc2xhdGUtOTAwIHRleHQtcm9zZS03MDAgZGFyazp0ZXh0LXJvc2UtNDAwIHNoYWRvdy14c1wiXHJcbiAgICAgICAgICAgICAgICA6IFwidGV4dC1zbGF0ZS02MDAgZGFyazp0ZXh0LXNsYXRlLTQwMCBob3Zlcjp0ZXh0LXNsYXRlLTkwMCBkYXJrOmhvdmVyOnRleHQtd2hpdGVcIlxyXG4gICAgICAgICAgICB9YH1cclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgPEZpbGVXYXJuaW5nIGNsYXNzTmFtZT1cInctMy41IGgtMy41XCIgLz5cclxuICAgICAgICAgICAgPHNwYW4+Tm90aWZpY2HDp8O1ZXMgLyBQcmF6b3M8L3NwYW4+XHJcbiAgICAgICAgICAgIHt0b3RhbE5vdGlmaWNhY29lc0NyaXRpY2FzID4gMCAmJiAoXHJcbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicHgtMS41IHB5LTAuMiByb3VuZGVkLWZ1bGwgdGV4dC1bMTBweF0gYmctcm9zZS0xMDAgdGV4dC1yb3NlLTgwMCBkYXJrOmJnLXJvc2UtOTUwIGRhcms6dGV4dC1yb3NlLTMwMCBmb250LWJvbGRcIj5cclxuICAgICAgICAgICAgICAgIHt0b3RhbE5vdGlmaWNhY29lc0NyaXRpY2FzfVxyXG4gICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgKX1cclxuICAgICAgICAgIDwvYnV0dG9uPlxyXG5cclxuICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEFiYUF0aXZhKFwiZG9jdW1lbnRvc1wiKX1cclxuICAgICAgICAgICAgY2xhc3NOYW1lPXtgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBweC0zIHB5LTEuNSByb3VuZGVkLW1kIHRleHQteHMgZm9udC1zZW1pYm9sZCB0cmFuc2l0aW9uLWFsbCAke1xyXG4gICAgICAgICAgICAgIGFiYUF0aXZhID09PSBcImRvY3VtZW50b3NcIlxyXG4gICAgICAgICAgICAgICAgPyBcImJnLXdoaXRlIGRhcms6Ymctc2xhdGUtOTAwIHRleHQtdGVhbC03MDAgZGFyazp0ZXh0LXRlYWwtNDAwIHNoYWRvdy14c1wiXHJcbiAgICAgICAgICAgICAgICA6IFwidGV4dC1zbGF0ZS02MDAgZGFyazp0ZXh0LXNsYXRlLTQwMCBob3Zlcjp0ZXh0LXNsYXRlLTkwMCBkYXJrOmhvdmVyOnRleHQtd2hpdGVcIlxyXG4gICAgICAgICAgICB9YH1cclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgPEZpbGVDaGVjazIgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPlxyXG4gICAgICAgICAgICA8c3Bhbj5BbHZhcsOhcyBhIFZlbmNlcjwvc3Bhbj5cclxuICAgICAgICAgICAge3RvdGFsRG9jdW1lbnRvc1ZlbmNlbmRvID4gMCAmJiAoXHJcbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicHgtMS41IHB5LTAuMiByb3VuZGVkLWZ1bGwgdGV4dC1bMTBweF0gYmctdGVhbC0xMDAgdGV4dC10ZWFsLTgwMCBkYXJrOmJnLXRlYWwtOTUwIGRhcms6dGV4dC10ZWFsLTMwMCBmb250LWJvbGRcIj5cclxuICAgICAgICAgICAgICAgIHt0b3RhbERvY3VtZW50b3NWZW5jZW5kb31cclxuICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICl9XHJcbiAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICB7LyogQ2FyZHMgZGUgUmVzdW1vIENsaWPDoXZlaXMgKi99XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBzbTpncmlkLWNvbHMtMiBnYXAtNFwiPlxyXG4gICAgICAgIDxMaW5rXHJcbiAgICAgICAgICB0bz17Uk9VVEVTLklOU1BFQ09FUy5QUkFaT1N9XHJcbiAgICAgICAgICBjbGFzc05hbWU9XCJwLTQgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXJvc2UtMjAwIGRhcms6Ym9yZGVyLXJvc2UtOTAwLzYwIGJnLXJvc2UtNTAvNDAgZGFyazpiZy1yb3NlLTk1MC8yMCBob3ZlcjpiZy1yb3NlLTUwIGRhcms6aG92ZXI6Ymctcm9zZS05NTAvMzAgdHJhbnNpdGlvbi1hbGwgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdyb3VwXCJcclxuICAgICAgICA+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zXCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xMCBoLTEwIHJvdW5kZWQtbGcgYmctcm9zZS0xMDAgZGFyazpiZy1yb3NlLTkwMC80MCB0ZXh0LXJvc2UtNjAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHNocmluay0wXCI+XHJcbiAgICAgICAgICAgICAgPENsb2NrIGNsYXNzTmFtZT1cInctNSBoLTVcIiAvPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHRleHQtcm9zZS05MDAgZGFyazp0ZXh0LXJvc2UtMzAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPlxyXG4gICAgICAgICAgICAgICAgUHJhem9zIEZpc2NhaXMgQ3LDrXRpY29zXHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtZXh0cmFib2xkIHRleHQtcm9zZS03MDAgZGFyazp0ZXh0LXJvc2UtNDAwIHRhYnVsYXItbnVtc1wiPlxyXG4gICAgICAgICAgICAgICAge3RvdGFsTm90aWZpY2Fjb2VzQ3JpdGljYXN9IHBlbmRlbnRlc1xyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtcm9zZS02MDAgZGFyazp0ZXh0LXJvc2UtNDAwXCI+XHJcbiAgICAgICAgICAgICAgICBOb3RpZmljYcOnw7VlcyBjb20gcHJhem8gdmVuY2lkbyBvdSBhIGV4cGlyYXIgZW0gNyBkaWFzXHJcbiAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPEFycm93UmlnaHQgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LXJvc2UtNTAwIGdyb3VwLWhvdmVyOnRyYW5zbGF0ZS14LTEgdHJhbnNpdGlvbi10cmFuc2Zvcm1cIiAvPlxyXG4gICAgICAgIDwvTGluaz5cclxuXHJcbiAgICAgICAgPExpbmtcclxuICAgICAgICAgIHRvPXtST1VURVMuTElDRU5DSUFNRU5UTy5MSVNUfVxyXG4gICAgICAgICAgY2xhc3NOYW1lPVwicC00IHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1hbWJlci0yMDAgZGFyazpib3JkZXItYW1iZXItOTAwLzYwIGJnLWFtYmVyLTUwLzQwIGRhcms6YmctYW1iZXItOTUwLzIwIGhvdmVyOmJnLWFtYmVyLTUwIGRhcms6aG92ZXI6YmctYW1iZXItOTUwLzMwIHRyYW5zaXRpb24tYWxsIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBncm91cFwiXHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTAgaC0xMCByb3VuZGVkLWxnIGJnLWFtYmVyLTEwMCBkYXJrOmJnLWFtYmVyLTkwMC80MCB0ZXh0LWFtYmVyLTYwMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBzaHJpbmstMFwiPlxyXG4gICAgICAgICAgICAgIDxDYWxlbmRhciBjbGFzc05hbWU9XCJ3LTUgaC01XCIgLz5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LWFtYmVyLTkwMCBkYXJrOnRleHQtYW1iZXItMzAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPlxyXG4gICAgICAgICAgICAgICAgQWx2YXLDoXMgYSBSZW5vdmFyXHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtZXh0cmFib2xkIHRleHQtYW1iZXItNzAwIGRhcms6dGV4dC1hbWJlci00MDAgdGFidWxhci1udW1zXCI+XHJcbiAgICAgICAgICAgICAgICB7dG90YWxEb2N1bWVudG9zVmVuY2VuZG99IG5vcyBwcsOzeGltb3MgMzAvNjAgZGlhc1xyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtYW1iZXItNjAwIGRhcms6dGV4dC1hbWJlci00MDBcIj5cclxuICAgICAgICAgICAgICAgIExpY2Vuw6dhcyBjb20gdMOpcm1pbm8gZGUgdmlnw6puY2lhIHJlZ3VsYXTDs3JpYVxyXG4gICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDxBcnJvd1JpZ2h0IGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1hbWJlci01MDAgZ3JvdXAtaG92ZXI6dHJhbnNsYXRlLXgtMSB0cmFuc2l0aW9uLXRyYW5zZm9ybVwiIC8+XHJcbiAgICAgICAgPC9MaW5rPlxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIHsvKiBDb250ZcO6ZG8gZGEgVGFiZWxhIFNlbGVjaW9uYWRhICovfVxyXG4gICAgICB7aXNMb2FkaW5nID8gKFxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC04IHRleHQtY2VudGVyIHRleHQteHMgdGV4dC1zbGF0ZS00MDAgZmxleCBmbGV4LWNvbCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXJcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy02IGgtNiBib3JkZXItMiBib3JkZXItdGVhbC01MDAgYm9yZGVyLXQtdHJhbnNwYXJlbnQgcm91bmRlZC1mdWxsIGFuaW1hdGUtc3BpbiBtYi0yXCIgLz5cclxuICAgICAgICAgIENhcnJlZ2FuZG8gYWxlcnRhcyBkbyBzaXN0ZW1hLi4uXHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICkgOiBhYmFBdGl2YSA9PT0gXCJub3RpZmljYWNvZXNcIiA/IChcclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm92ZXJmbG93LXgtYXV0byBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC1sZ1wiPlxyXG4gICAgICAgICAgPHRhYmxlIGNsYXNzTmFtZT1cInctZnVsbCB0ZXh0LWxlZnQgdGV4dC14c1wiPlxyXG4gICAgICAgICAgICA8dGhlYWQgY2xhc3NOYW1lPVwiYmctc2xhdGUtNTAgZGFyazpiZy1zbGF0ZS04MDAvNjAgdGV4dC1zbGF0ZS01MDAgdXBwZXJjYXNlIGZvbnQtc2VtaWJvbGQgdGV4dC1bMTFweF0gYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDBcIj5cclxuICAgICAgICAgICAgICA8dHI+XHJcbiAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMi41IHB4LTNcIj5UZXJtbzwvdGg+XHJcbiAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMi41IHB4LTNcIj5Fc3RhYmVsZWNpbWVudG8gLyBDTlBKPC90aD5cclxuICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0yLjUgcHgtM1wiPkZpc2NhbDwvdGg+XHJcbiAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMi41IHB4LTNcIj5MaW1pdGUgTGVnYWw8L3RoPlxyXG4gICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB5LTIuNSBweC0zIHRleHQtY2VudGVyXCI+U3RhdHVzIC8gUmVzdGFudGU8L3RoPlxyXG4gICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB5LTIuNSBweC0zIHRleHQtcmlnaHRcIj5Bw6fDo288L3RoPlxyXG4gICAgICAgICAgICAgIDwvdHI+XHJcbiAgICAgICAgICAgIDwvdGhlYWQ+XHJcbiAgICAgICAgICAgIDx0Ym9keSBjbGFzc05hbWU9XCJkaXZpZGUteSBkaXZpZGUtc2xhdGUtMTAwIGRhcms6ZGl2aWRlLXNsYXRlLTgwMFwiPlxyXG4gICAgICAgICAgICAgIHtub3RpZmljYWNvZXMubGVuZ3RoID09PSAwID8gKFxyXG4gICAgICAgICAgICAgICAgPHRyPlxyXG4gICAgICAgICAgICAgICAgICA8dGQgY29sU3Bhbj17Nn0gY2xhc3NOYW1lPVwicHktOCB0ZXh0LWNlbnRlciB0ZXh0LXNsYXRlLTQwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIE5lbmh1bWEgbm90aWZpY2HDp8OjbyBmaXNjYWwgY29tIHByYXpvIGNyw610aWNvIHBlbmRlbnRlLlxyXG4gICAgICAgICAgICAgICAgICA8L3RkPlxyXG4gICAgICAgICAgICAgICAgPC90cj5cclxuICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgbm90aWZpY2Fjb2VzLm1hcCgoaXRlbSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICBjb25zdCBpc1ZlbmNpZG8gPSBpdGVtLmRpYXNfcmVzdGFudGVzIDwgMDtcclxuICAgICAgICAgICAgICAgICAgY29uc3QgaXNDcml0aWNvID0gaXRlbS5kaWFzX3Jlc3RhbnRlcyA+PSAwICYmIGl0ZW0uZGlhc19yZXN0YW50ZXMgPD0gNztcclxuXHJcbiAgICAgICAgICAgICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPHRyXHJcbiAgICAgICAgICAgICAgICAgICAgICBrZXk9e2l0ZW0uaW5zcGVjYW9faWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJob3ZlcjpiZy1zbGF0ZS01MC82MCBkYXJrOmhvdmVyOmJnLXNsYXRlLTgwMC80MCB0cmFuc2l0aW9uLWNvbG9yc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTIuNSBweC0zIGZvbnQtbW9ubyBmb250LWJvbGQgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtpdGVtLm51bWVyb190ZXJtbyB8fCBcIk5PVC0yMDI2XCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTIuNSBweC0zXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTgwMCBkYXJrOnRleHQtc2xhdGUtMjAwIHRydW5jYXRlIG1heC13LVsyMjBweF1cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7aXRlbS5yYXphb19zb2NpYWx9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtc2xhdGUtNDAwIGZvbnQtbW9ub1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtpdGVtLmNucGpfY3BmfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMi41IHB4LTMgdGV4dC1zbGF0ZS02MDAgZGFyazp0ZXh0LXNsYXRlLTMwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7aXRlbS5maXNjYWxfcmVzcG9uc2F2ZWwgfHwgXCJGaXNjYWwgVklTQVwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS0yLjUgcHgtMyB0ZXh0LXNsYXRlLTYwMCBkYXJrOnRleHQtc2xhdGUtMzAwIGZvbnQtbW9ub1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7aXRlbS5kYXRhX2xpbWl0ZV9jdW1wcmltZW50b31cclxuICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMi41IHB4LTMgdGV4dC1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgcHgtMiBweS0wLjUgcm91bmRlZCB0ZXh0LVsxMHB4XSBmb250LWJvbGQgdXBwZXJjYXNlICR7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpc1ZlbmNpZG9cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBcImJnLXJvc2UtMTAwIHRleHQtcm9zZS04MDAgZGFyazpiZy1yb3NlLTk1MCBkYXJrOnRleHQtcm9zZS0zMDAgYm9yZGVyIGJvcmRlci1yb3NlLTMwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogaXNDcml0aWNvXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gXCJiZy1hbWJlci0xMDAgdGV4dC1hbWJlci04MDAgZGFyazpiZy1hbWJlci05NTAgZGFyazp0ZXh0LWFtYmVyLTMwMCBib3JkZXIgYm9yZGVyLWFtYmVyLTMwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogXCJiZy1ibHVlLTUwIHRleHQtYmx1ZS03MDAgZGFyazpiZy1ibHVlLTk1MCBkYXJrOnRleHQtYmx1ZS0zMDAgYm9yZGVyIGJvcmRlci1ibHVlLTIwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfWB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7aXNWZW5jaWRvXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IGBWZW5jaWRvIGjDoSAke01hdGguYWJzKGl0ZW0uZGlhc19yZXN0YW50ZXMpfWRgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IGAke2l0ZW0uZGlhc19yZXN0YW50ZXN9IGRpYXMgcmVzdGFudGVzYH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS0yLjUgcHgtMyB0ZXh0LXJpZ2h0XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxMaW5rXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdG89e1JPVVRFUy5JTlNQRUNPRVMuTElTVH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgdGV4dC1bMTFweF0gZm9udC1zZW1pYm9sZCB0ZXh0LXRlYWwtNjAwIGhvdmVyOnRleHQtdGVhbC03MDAgaG92ZXI6dW5kZXJsaW5lXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPlJlaW5zcGVjaW9uYXI8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPEV4dGVybmFsTGluayBjbGFzc05hbWU9XCJ3LTMgaC0zXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICAgICAgICAgICAgICA8L3RyPlxyXG4gICAgICAgICAgICAgICAgICApO1xyXG4gICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICA8L3Rib2R5PlxyXG4gICAgICAgICAgPC90YWJsZT5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgKSA6IChcclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm92ZXJmbG93LXgtYXV0byBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC1sZ1wiPlxyXG4gICAgICAgICAgPHRhYmxlIGNsYXNzTmFtZT1cInctZnVsbCB0ZXh0LWxlZnQgdGV4dC14c1wiPlxyXG4gICAgICAgICAgICA8dGhlYWQgY2xhc3NOYW1lPVwiYmctc2xhdGUtNTAgZGFyazpiZy1zbGF0ZS04MDAvNjAgdGV4dC1zbGF0ZS01MDAgdXBwZXJjYXNlIGZvbnQtc2VtaWJvbGQgdGV4dC1bMTFweF0gYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDBcIj5cclxuICAgICAgICAgICAgICA8dHI+XHJcbiAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMi41IHB4LTNcIj5Eb2N1bWVudG88L3RoPlxyXG4gICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB5LTIuNSBweC0zXCI+RXN0YWJlbGVjaW1lbnRvPC90aD5cclxuICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0yLjUgcHgtM1wiPkNhdGVnb3JpYTwvdGg+XHJcbiAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMi41IHB4LTNcIj5EYXRhIFZlbmNpbWVudG88L3RoPlxyXG4gICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB5LTIuNSBweC0zIHRleHQtY2VudGVyXCI+RGlhcyBwYXJhIEV4cGlyYXI8L3RoPlxyXG4gICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB5LTIuNSBweC0zIHRleHQtcmlnaHRcIj5Bw6fDo288L3RoPlxyXG4gICAgICAgICAgICAgIDwvdHI+XHJcbiAgICAgICAgICAgIDwvdGhlYWQ+XHJcbiAgICAgICAgICAgIDx0Ym9keSBjbGFzc05hbWU9XCJkaXZpZGUteSBkaXZpZGUtc2xhdGUtMTAwIGRhcms6ZGl2aWRlLXNsYXRlLTgwMFwiPlxyXG4gICAgICAgICAgICAgIHtkb2N1bWVudG9zLmxlbmd0aCA9PT0gMCA/IChcclxuICAgICAgICAgICAgICAgIDx0cj5cclxuICAgICAgICAgICAgICAgICAgPHRkIGNvbFNwYW49ezZ9IGNsYXNzTmFtZT1cInB5LTggdGV4dC1jZW50ZXIgdGV4dC1zbGF0ZS00MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICBOZW5odW0gYWx2YXLDoSBvdSBkb2N1bWVudG8gc2FuaXTDoXJpbyB2ZW5jZW5kbyBub3MgcHLDs3hpbW9zIDMwIGRpYXMuXHJcbiAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICA8L3RyPlxyXG4gICAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgICBkb2N1bWVudG9zLm1hcCgoaXRlbSkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICA8dHJcclxuICAgICAgICAgICAgICAgICAgICBrZXk9e2l0ZW0uZG9jdW1lbnRvX2lkfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImhvdmVyOmJnLXNsYXRlLTUwLzYwIGRhcms6aG92ZXI6Ymctc2xhdGUtODAwLzQwIHRyYW5zaXRpb24tY29sb3JzXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS0yLjUgcHgtMyBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2l0ZW0ubm9tZV9kb2N1bWVudG99XHJcbiAgICAgICAgICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMi41IHB4LTMgdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTMwMCB0cnVuY2F0ZSBtYXgtdy1bMjIwcHhdXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7aXRlbS5yYXphb19zb2NpYWx9XHJcbiAgICAgICAgICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMi41IHB4LTMgdGV4dC1zbGF0ZS01MDAgY2FwaXRhbGl6ZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2l0ZW0uY2F0ZWdvcmlhfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTIuNSBweC0zIGZvbnQtbW9ubyB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7aXRlbS5kYXRhX3ZlbmNpbWVudG99XHJcbiAgICAgICAgICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMi41IHB4LTMgdGV4dC1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBweC0yIHB5LTAuNSByb3VuZGVkIHRleHQtWzEwcHhdIGZvbnQtYm9sZCBiZy1hbWJlci01MCB0ZXh0LWFtYmVyLTcwMCBkYXJrOmJnLWFtYmVyLTk1MCBkYXJrOnRleHQtYW1iZXItMzAwIGJvcmRlciBib3JkZXItYW1iZXItMjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtpdGVtLmRpYXNfcGFyYV92ZW5jaW1lbnRvfSBkaWFzXHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMi41IHB4LTMgdGV4dC1yaWdodFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPExpbmtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdG89e1JPVVRFUy5MSUNFTkNJQU1FTlRPLkxJU1R9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMSB0ZXh0LVsxMXB4XSBmb250LXNlbWlib2xkIHRleHQtdGVhbC02MDAgaG92ZXI6dGV4dC10ZWFsLTcwMCBob3Zlcjp1bmRlcmxpbmVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5BYnJpciBSZW5vdmHDp8Ojbzwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPEV4dGVybmFsTGluayBjbGFzc05hbWU9XCJ3LTMgaC0zXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICAgICAgICAgICAgICA8L3RkPlxyXG4gICAgICAgICAgICAgICAgICA8L3RyPlxyXG4gICAgICAgICAgICAgICAgKSlcclxuICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICA8L3Rib2R5PlxyXG4gICAgICAgICAgPC90YWJsZT5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgKX1cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBUYWJlbGFBbGVydGFzT3BlcmFjaW9uYWlzO1xyXG4iXX0=