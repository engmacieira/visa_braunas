import { r as __toESM } from "/node_modules/.vite/deps/rolldown-runtime-SbdDWaPq.js?v=0fd2848a";
import { t as require_react } from "/node_modules/.vite/deps/react-4hkZzRew.js?v=0fd2848a";
import { t as require_jsx_runtime } from "/node_modules/.vite/deps/jsx-runtime-cNwuCTLA.js?v=0fd2848a";
// node_modules/@tanstack/react-query/build/modern/QueryClientProvider.js
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var import_jsx_runtime = require_jsx_runtime();
/**
* The context that `useQueryClient` reads from. `QueryClientProvider` is the normal way to set it.
*/
var QueryClientContext = import_react.createContext(void 0);
/**
* The `useQueryClient` hook returns the current `QueryClient` instance.
* @param queryClient - Use this to use a custom `QueryClient`. Otherwise, the one from the nearest context will
* be used.
* @returns The current `QueryClient` instance.
* @throws {Error} If no `queryClient` argument is passed and no `QueryClientProvider` is found in the
* component tree.
*/
var useQueryClient = (queryClient) => {
	const client = import_react.useContext(QueryClientContext);
	if (queryClient) return queryClient;
	if (!client) throw new Error("No QueryClient set, use QueryClientProvider to set one");
	return client;
};
/**
* Use the `QueryClientProvider` component to connect and provide a `QueryClient` to your application. Also
* calls `client.mount()`/`client.unmount()` as this component mounts/unmounts, which subscribes the client to
* focus/online events (resuming any paused mutations and refetching as needed when the app regains focus or
* comes back online).
* @param props - The `client` to provide, and the `children` that get access to it.
* @returns The provided `children`, wrapped so they can read the `QueryClient` via `useQueryClient`.
* @example
* ```tsx
* import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
*
* const queryClient = new QueryClient()
*
* function App() {
*   return <QueryClientProvider client={queryClient}>...</QueryClientProvider>
* }
* ```
*/
var QueryClientProvider = ({ client, children }) => {
	import_react.useEffect(() => {
		client.mount();
		return () => {
			client.unmount();
		};
	}, [client]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QueryClientContext.Provider, {
		value: client,
		children
	});
};
// node_modules/@tanstack/query-core/build/modern/timeoutManager.js
var defaultTimeoutProvider = {
	setTimeout: (callback, delay) => setTimeout(callback, delay),
	clearTimeout: (timeoutId) => clearTimeout(timeoutId),
	setInterval: (callback, delay) => setInterval(callback, delay),
	clearInterval: (intervalId) => clearInterval(intervalId)
};
/**
* Allows customization of how timeouts are created.
*
* `@tanstack/query-core` makes liberal use of timeouts to implement `staleTime`
* and `gcTime`. The default TimeoutManager provider uses the platform's global
* `setTimeout` implementation, which is known to have scalability issues with
* thousands of timeouts on the event loop.
*
* If you hit this limitation, consider providing a custom TimeoutProvider that
* coalesces timeouts.
*/
var TimeoutManager = class {
	#provider = defaultTimeoutProvider;
	#providerCalled = false;
	/**
	* `setTimeoutProvider` can be used to set a custom implementation of the
	* `setTimeout`, `clearTimeout`, `setInterval`, `clearInterval` functions,
	* called a `TimeoutProvider`.
	*
	* This may be useful if you notice event loop performance issues with
	* thousands of queries. A custom TimeoutProvider could also support timer
	* delays longer than the global `setTimeout` maximum delay value of about
	* 24 days.
	*
	* It is important to call `setTimeoutProvider` before creating a
	* QueryClient or queries, so that the same provider is used consistently
	* for all timers in the application, since different TimeoutProviders
	* cannot cancel each others' timers.
	* @param provider - The `TimeoutProvider` to use for all timers from now on.
	* @example
	* ```ts
	* import { timeoutManager, QueryClient } from '@tanstack/query-core'
	* import { CustomTimeoutProvider } from './CustomTimeoutProvider'
	*
	* timeoutManager.setTimeoutProvider(new CustomTimeoutProvider())
	*
	* export const queryClient = new QueryClient()
	* ```
	*/
	setTimeoutProvider(provider) {
		if (this.#providerCalled && provider !== this.#provider) console.error(`[timeoutManager]: Switching provider after calls to previous provider might result in unexpected behavior.`, {
			previous: this.#provider,
			provider
		});
		this.#provider = provider;
		this.#providerCalled = false;
	}
	/**
	* `setTimeout` schedules a callback to run after approximately `delay`
	* milliseconds, like the global `setTimeout` function. The callback can be
	* canceled with `clearTimeout`.
	*
	* It returns a timer ID, which may be a number or an object that can be
	* coerced to a number via `Symbol.toPrimitive`.
	* @param callback - The function to call when the timeout elapses.
	* @param delay - The time to wait before calling `callback`, in milliseconds.
	* @returns The timer ID, to pass to {@link TimeoutManager#clearTimeout}.
	* @example
	* ```ts
	* import { timeoutManager } from '@tanstack/query-core'
	*
	* const timeoutId = timeoutManager.setTimeout(
	*   () => console.log('ran at:', new Date()),
	*   1000,
	* )
	*
	* const timeoutIdNumber: number = Number(timeoutId)
	* ```
	*/
	setTimeout(callback, delay) {
		this.#providerCalled = true;
		return this.#provider.setTimeout(callback, delay);
	}
	/**
	* `clearTimeout` cancels a timeout callback scheduled with `setTimeout`,
	* like the global `clearTimeout` function. It should be called with a
	* timer ID returned by `setTimeout`.
	* @param timeoutId - The timer ID returned by `setTimeout`, or `undefined`.
	* @example
	* ```ts
	* import { timeoutManager } from '@tanstack/query-core'
	*
	* const timeoutId = timeoutManager.setTimeout(
	*   () => console.log('ran at:', new Date()),
	*   1000,
	* )
	*
	* timeoutManager.clearTimeout(timeoutId)
	* ```
	*/
	clearTimeout(timeoutId) {
		this.#provider.clearTimeout(timeoutId);
	}
	/**
	* `setInterval` schedules a callback to be called approximately every
	* `delay` milliseconds, like the global `setInterval` function.
	*
	* Like `setTimeout`, it returns a timer ID, which may be a number or an
	* object that can be coerced to a number via `Symbol.toPrimitive`.
	* @param callback - The function to call on every interval.
	* @param delay - The time between calls, in milliseconds.
	* @returns The timer ID, to pass to {@link TimeoutManager#clearInterval}.
	* @example
	* ```ts
	* import { timeoutManager } from '@tanstack/query-core'
	*
	* const intervalId = timeoutManager.setInterval(
	*   () => console.log('ran at:', new Date()),
	*   1000,
	* )
	* ```
	*/
	setInterval(callback, delay) {
		this.#providerCalled = true;
		return this.#provider.setInterval(callback, delay);
	}
	/**
	* `clearInterval` can be used to cancel an interval, like the global
	* `clearInterval` function. It should be called with an interval ID
	* returned by `setInterval`.
	* @param intervalId - The timer ID returned by `setInterval`, or `undefined`.
	* @example
	* ```ts
	* import { timeoutManager } from '@tanstack/query-core'
	*
	* const intervalId = timeoutManager.setInterval(
	*   () => console.log('ran at:', new Date()),
	*   1000,
	* )
	*
	* timeoutManager.clearInterval(intervalId)
	* ```
	*/
	clearInterval(intervalId) {
		this.#provider.clearInterval(intervalId);
	}
};
/**
* Singleton instance of {@link TimeoutManager}, used throughout TanStack Query to schedule and cancel timers.
*/
var timeoutManager = new TimeoutManager();
/**
* In many cases code wants to delay to the next event loop tick; this is not
* mediated by {@link timeoutManager}.
*
* This function is provided to make auditing the `tanstack/query-core` for
* incorrect use of system `setTimeout` easier.
* @param callback - The function to call on the next event loop tick.
*/
function systemSetTimeoutZero(callback) {
	setTimeout(callback, 0);
}
// node_modules/@tanstack/query-core/build/modern/utils.js
/**
* @deprecated use `environmentManager.isServer()` instead.
*/
var isServer = typeof window === "undefined" || "Deno" in globalThis;
function noop() {}
/**
* Resolves an {@link Updater}: calls it with `input` if it is a function, otherwise returns it as
* is.
* @param updater - The new value, or a function that receives `input` and returns the new value.
* @param input - The current value, passed to `updater` if it is a function.
* @returns The new value.
*/
function functionalUpdate(updater, input) {
	return typeof updater === "function" ? updater(input) : updater;
}
/**
* Checks whether a value can be used as a timeout: a non-negative, finite number.
* @param value - The value to check.
* @returns `true` if `value` is a number that is `>= 0` and not `Infinity`.
*/
function isValidTimeout(value) {
	return typeof value === "number" && value >= 0 && value !== Infinity;
}
/**
* Calculates how long until data updated at `updatedAt` becomes stale.
* @param updatedAt - The timestamp, in milliseconds, at which the data was last updated.
* @param staleTime - The time, in milliseconds, after which data is considered stale. Defaults to
* `0`.
* @returns The remaining time in milliseconds, or `0` if the data is already stale.
*/
function timeUntilStale(updatedAt, staleTime) {
	return Math.max(updatedAt + (staleTime || 0) - Date.now(), 0);
}
/**
* Resolves an option that can be given either as a value or as a function of the query, such as
* `staleTime`.
* @param value - The option value, or a function that receives `query` and returns the value.
* @param query - The query passed to `value` if it is a function.
* @returns The resolved value, or `undefined` if `value` is `undefined`.
*/
function resolveQueryValue(value, query) {
	return typeof value === "function" ? value(query) : value;
}
/**
* Checks whether a query matches the given {@link QueryFilters}.
* Every filter that is specified must match; filters that are left unspecified are ignored.
* @param filters - The filters to check the query against.
* @param query - The query to check.
* @returns `true` if the query matches every specified filter.
* @example
* ```ts
* const queryCache = queryClient.getQueryCache()
*
* const matchingQueries = queryCache
*   .getAll()
*   .filter((query) => matchQuery({ queryKey: ['posts'] }, query))
* ```
*/
function matchQuery(filters, query) {
	const { type = "all", exact, fetchStatus, predicate, queryKey, stale } = filters;
	if (queryKey) {
		if (exact) {
			if (query.queryHash !== hashQueryKeyByOptions(queryKey, query.options)) return false;
		} else if (!partialMatchKey(query.queryKey, queryKey)) return false;
	}
	if (type !== "all") {
		const isActive = query.isActive();
		if (type === "active" && !isActive) return false;
		if (type === "inactive" && isActive) return false;
	}
	if (typeof stale === "boolean" && query.isStale() !== stale) return false;
	if (fetchStatus && fetchStatus !== query.state.fetchStatus) return false;
	if (predicate && !predicate(query)) return false;
	return true;
}
/**
* Checks whether a mutation matches the given {@link MutationFilters}.
* Every filter that is specified must match; filters that are left unspecified are ignored.
* If a `mutationKey` filter is provided but the mutation has no `mutationKey` of its own, it does not match.
* @param filters - The filters to check the mutation against.
* @param mutation - The mutation to check.
* @returns `true` if the mutation matches every specified filter.
* @example
* ```ts
* const mutationCache = queryClient.getMutationCache()
*
* const matchingMutations = mutationCache
*   .getAll()
*   .filter((mutation) => matchMutation({ mutationKey: ['addPost'] }, mutation))
* ```
*/
function matchMutation(filters, mutation) {
	const { exact, status, predicate, mutationKey } = filters;
	if (mutationKey) {
		if (!mutation.options.mutationKey) return false;
		if (exact) {
			if (hashKey(mutation.options.mutationKey) !== hashKey(mutationKey)) return false;
		} else if (!partialMatchKey(mutation.options.mutationKey, mutationKey)) return false;
	}
	if (status && mutation.state.status !== status) return false;
	if (predicate && !predicate(mutation)) return false;
	return true;
}
/**
* Hashes a query key with the query's `queryKeyHashFn` option, falling back to {@link hashKey}.
* @param queryKey - The query key to hash.
* @param options - The query options that may provide a custom `queryKeyHashFn`.
* @returns The query hash, a string that identifies the query in the cache.
*/
function hashQueryKeyByOptions(queryKey, options) {
	return (options?.queryKeyHashFn || hashKey)(queryKey);
}
/**
* Default query & mutation keys hash function.
* Hashes the value into a stable hash.
* @param queryKey - The query or mutation key to hash.
* @returns The stable hash of the key, as a JSON string.
* @example
* ```ts
* // Object keys are sorted, so key order doesn't affect the hash:
* hashKey(['todos', { page: 1, filter: 'done' }]) // === '["todos",{"filter":"done","page":1}]'
* ```
*/
function hashKey(queryKey) {
	return JSON.stringify(queryKey, (_, val) => isPlainObject(val) ? Object.keys(val).sort().reduce((result, key) => {
		result[key] = val[key];
		return result;
	}, {}) : val);
}
function partialMatchKey(a, b) {
	if (a === b) return true;
	if (typeof a !== typeof b) return false;
	if (a && b && typeof a === "object" && typeof b === "object") {
		if (Array.isArray(a) && Array.isArray(b)) {
			if (b.length > a.length) return false;
			for (let i = 0; i < b.length; i++) if (!partialMatchKey(a[i], b[i])) return false;
			return true;
		}
		const bKeys = Object.keys(b);
		for (const key of bKeys) if (!partialMatchKey(a[key], b[key])) return false;
		return true;
	}
	return false;
}
var hasOwn = Object.prototype.hasOwnProperty;
function replaceEqualDeep(a, b, depth = 0) {
	if (a === b) return a;
	if (depth > 500) return b;
	const array = isPlainArray(a) && isPlainArray(b);
	if (!array && !(isPlainObject(a) && isPlainObject(b))) return b;
	const aSize = (array ? a : Object.keys(a)).length;
	const bItems = array ? b : Object.keys(b);
	const bSize = bItems.length;
	const copy = array ? new Array(bSize) : {};
	let equalItems = 0;
	for (let i = 0; i < bSize; i++) {
		const key = array ? i : bItems[i];
		const aItem = a[key];
		const bItem = b[key];
		if (aItem === bItem) {
			copy[key] = aItem;
			if (array ? i < aSize : hasOwn.call(a, key)) equalItems++;
			continue;
		}
		if (aItem === null || bItem === null || typeof aItem !== "object" || typeof bItem !== "object") {
			copy[key] = bItem;
			continue;
		}
		const v = replaceEqualDeep(aItem, bItem, depth + 1);
		copy[key] = v;
		if (v === aItem) equalItems++;
	}
	return aSize === bSize && equalItems === aSize ? a : copy;
}
/**
* Shallow compare objects.
* @param a - The first object.
* @param b - The second object, or `undefined`.
* @returns `true` if both objects have the same keys, with strictly equal values for each key.
*/
function shallowEqualObjects(a, b) {
	if (!b || Object.keys(a).length !== Object.keys(b).length) return false;
	for (const key of Object.keys(a)) if (!hasOwn.call(b, key) || a[key] !== b[key]) return false;
	return true;
}
/**
* Checks whether a value is an array with no holes and no extra properties.
* @param value - The value to check.
* @returns `true` if `value` is an array whose number of own keys equals its `length`.
*/
function isPlainArray(value) {
	return Array.isArray(value) && value.length === Object.keys(value).length;
}
/**
* Checks whether a value is a plain object, e.g. created with an object literal or
* `Object.create(null)`.
* @param o - The value to check.
* @returns `true` if `o` is a plain object.
*/
function isPlainObject(o) {
	if (!hasObjectPrototype(o)) return false;
	const objectPrototype = Object.getPrototypeOf(o);
	const ctor = objectPrototype?.constructor;
	if (ctor === void 0) return true;
	if (typeof ctor !== "function") return false;
	const prot = ctor.prototype;
	if (!hasObjectPrototype(prot)) return false;
	if (!prot.hasOwnProperty("isPrototypeOf")) return false;
	if (objectPrototype !== Object.prototype) return false;
	return true;
}
/**
* Checks whether a value's `Object.prototype.toString` tag is `[object Object]`.
* @param o - The value to check.
* @returns `true` if the tag is `[object Object]`.
*/
function hasObjectPrototype(o) {
	return Object.prototype.toString.call(o) === "[object Object]";
}
/**
* Waits for the given time, using the configured {@link timeoutManager}.
* @param timeout - The time to wait, in milliseconds.
* @returns A promise that resolves after `timeout` milliseconds.
*/
function sleep(timeout) {
	return new Promise((resolve) => {
		timeoutManager.setTimeout(resolve, timeout);
	});
}
/**
* Applies a query's `structuralSharing` option when writing new data.
* @param prevData - The previously cached data.
* @param data - The new data.
* @param options - The query options, whose `structuralSharing` decides how the data is merged.
* @returns The result of a custom `structuralSharing` function, `data` with its unchanged parts
* replaced by those of `prevData` by default, or `data` as is if `structuralSharing` is `false`.
* @throws {Error} The error from the default structural sharing, e.g. when the data is not JSON serializable.
* Outside production, it is also logged to the console.
*/
function replaceData(prevData, data, options) {
	if (typeof options.structuralSharing === "function") return options.structuralSharing(prevData, data);
	else if (options.structuralSharing !== false) try {
		return replaceEqualDeep(prevData, data);
	} catch (error) {
		console.error(`Structural sharing requires data to be JSON serializable. To fix this, turn off structuralSharing or return JSON-serializable data from your queryFn. [${options.queryHash}]: ${error}`);
		throw error;
	}
	return data;
}
/**
* Intended to be passed as a query's `placeholderData` option, for example
* `placeholderData: keepPreviousData`. Instead of resetting the query's data to `undefined` while a new
* query key is fetching, it keeps displaying the previously fetched data until the new data arrives.
* @param previousData - The data of the previous query key, passed by the observer.
* @returns The previous data, unchanged.
* @example
* ```ts
* new QueryObserver(queryClient, {
*   queryKey: ['posts', page],
*   queryFn: () => fetchPosts(page),
*   placeholderData: keepPreviousData,
* })
* ```
*/
function keepPreviousData(previousData) {
	return previousData;
}
/**
* Returns a new array with `item` added at the end. If that makes the array longer than `max`,
* excess items are removed from the start.
* @param items - The current items.
* @param item - The value to append.
* @param max - The maximum number of items to keep. `0` (the default) means no limit.
* @returns A new array with `item` added.
*/
function addToEnd(items, item, max = 0) {
	const newItems = [...items, item];
	return max && newItems.length > max ? newItems.slice(-max) : newItems;
}
/**
* Returns a new array with `item` added at the start. If that makes the array longer than `max`,
* excess items are removed from the end.
* @param items - The current items.
* @param item - The value to prepend.
* @param max - The maximum number of items to keep. `0` (the default) means no limit.
* @returns A new array with `item` added.
*/
function addToStart(items, item, max = 0) {
	const newItems = [item, ...items];
	return max && newItems.length > max ? newItems.slice(0, max) : newItems;
}
/**
* Sentinel value that can be passed as a query's `queryFn` to conditionally disable the query (equivalent
* to `enabled: false`) while preserving full type inference for the query's data. Unlike `enabled: false`,
* a query disabled via `skipToken` cannot be triggered with `refetch`.
* @example
* ```ts
* new QueryObserver(queryClient, {
*   queryKey: ['post', postId],
*   queryFn: postId != null ? () => fetchPost(postId) : skipToken,
* })
* ```
*/
var skipToken = Symbol();
/**
* Returns the function to call for a fetch. If there is no `queryFn` but the fetch was started from
* an `initialPromise`, that promise is returned instead. If there is no usable `queryFn` (missing or
* {@link skipToken}), the returned function rejects with a `Missing queryFn` error.
* @param options - The query options with the `queryFn`, and the `queryHash` used in error messages.
* @param fetchOptions - The fetch options, which may carry an `initialPromise`.
* @returns The function to call for the fetch.
*/
function ensureQueryFn(options, fetchOptions) {
	if (options.queryFn === skipToken) console.error(`Attempted to invoke queryFn when set to skipToken. This is likely a configuration error. Query hash: '${options.queryHash}'`);
	if (!options.queryFn && fetchOptions?.initialPromise) return () => fetchOptions.initialPromise;
	if (!options.queryFn || options.queryFn === skipToken) return () => Promise.reject(/* @__PURE__ */ new Error(`Missing queryFn: '${options.queryHash}'`));
	return options.queryFn;
}
/**
* Resolves a `throwOnError` option to a boolean.
* If `throwOnError` is a function, it is called with `params` (e.g. the error and, depending on the caller,
* additional context such as the query or mutation) and its result is returned, allowing the throwing
* behavior to be decided per error. Otherwise, `throwOnError` itself is coerced to a boolean (`undefined`
* resolves to `false`).
* @param throwOnError - The `throwOnError` option: a boolean, a function that decides per error, or
* `undefined`.
* @param params - The arguments passed to `throwOnError` if it is a function.
* @returns Whether the error should be thrown.
* @example
* ```ts
* const throwOnError =
*   query.state.error && typeof options.throwOnError === 'function'
*     ? shouldThrowError(options.throwOnError, [query.state.error, query])
*     : options.throwOnError
* ```
*/
function shouldThrowError(throwOnError, params) {
	if (typeof throwOnError === "function") return throwOnError(...params);
	return !!throwOnError;
}
var fetchSignal = Symbol();
/**
* Adds a lazy `signal` getter to an object, such as a query function context. The first time
* `signal` is read, `onCancelled` is registered for the signal's `abort` event (or called right
* away if it is already aborted), so cancellation is only tracked when the signal is actually used.
* @param object - The object to add the `signal` property to.
* @param getSignal - Returns the `AbortSignal`. Called once, when `signal` is first read.
* @param onCancelled - Called when the signal is aborted, if `signal` was read.
* @param internalSignal - The fetch signal to forward without consuming the getter.
* @returns The same object, with the `signal` property added.
*/
function addConsumeAwareSignal(object, getSignal, onCancelled, internalSignal) {
	let consumed = false;
	let signal;
	Object.defineProperties(object, {
		[fetchSignal]: { value: internalSignal },
		signal: {
			enumerable: true,
			get: () => {
				signal ??= getSignal();
				if (consumed) return signal;
				consumed = true;
				if (signal.aborted) onCancelled();
				else signal.addEventListener("abort", onCancelled, { once: true });
				return signal;
			}
		}
	});
	return object;
}
// node_modules/@tanstack/query-core/build/modern/environmentManager.js
var isServerFn = () => isServer;
/**
* Returns whether the current runtime should be treated as a server environment.
* @returns `true` if the runtime is treated as a server.
*/
var isServer$2 = () => isServerFn();
/**
* Manages how TanStack Query detects whether the current runtime should be treated as
* server-side, which disables scheduling refetch timers and changes the default `retry` count
* and `gcTime`. By default, the detection treats a missing `window` (or the presence of a
* `Deno` global) as server.
*
* Override this for runtimes where that default detection would give the wrong answer — for
* example, a Service Worker, where `window` is undefined even though the environment should
* behave like a client.
* @example
* ```ts
* import { environmentManager } from '@tanstack/query-core'
*
* environmentManager.setIsServer(() => false)
* ```
*/
var environmentManager = {
	isServer: isServer$2,
	/**
	* Overrides the server check globally.
	* @param isServerValue - A function that returns whether the runtime should be treated as a
	* server.
	*/
	setIsServer(isServerValue) {
		isServerFn = isServerValue;
	}
};
// node_modules/@tanstack/query-core/build/modern/subscribable.js
/**
* The base class behind everything in Query that you can subscribe to: `QueryCache`, `MutationCache`,
* the observers, and the `FocusManager`/`OnlineManager` behind `focusManager` and `onlineManager`.
* Subclasses decide what a listener receives and when it is called.
*/
var Subscribable = class {
	constructor() {
		this.listeners = /* @__PURE__ */ new Set();
		this.subscribe = this.subscribe.bind(this);
	}
	/**
	* Registers a listener to be called on every update this object notifies about. Returns a function
	* that removes the listener again — call it to stop listening. The base class never drops a listener
	* on its own, though some subclasses clear all of theirs in `destroy()`.
	* @param listener - Called on each update, with whatever the subclass passes to its subscribers.
	* @returns A function that removes the listener.
	* @example
	* ```ts
	* const unsubscribe = subscribable.subscribe(() => {
	*   // react to the update
	* })
	*
	* unsubscribe()
	* ```
	*/
	subscribe(listener) {
		this.listeners.add(listener);
		this.onSubscribe();
		return () => {
			this.listeners.delete(listener);
			this.onUnsubscribe();
		};
	}
	/**
	* Returns `true` while at least one listener is registered, `false` once they have all unsubscribed.
	* @returns `true` if at least one listener is registered.
	*/
	hasListeners() {
		return this.listeners.size > 0;
	}
	/**
	* Called after a listener is added. Does nothing here; subclasses override it, e.g. to start
	* tracking what they observe once the first listener subscribes.
	*/
	onSubscribe() {}
	/**
	* Called after a listener is removed. Does nothing here; subclasses override it, e.g. to clean up
	* once the last listener unsubscribes.
	*/
	onUnsubscribe() {}
};
// node_modules/@tanstack/query-core/build/modern/focusManager.js
/**
* The `FocusManager` manages the focus state within TanStack Query.
*
* It can be used to change the default event listeners or to manually change the focus state.
*/
var FocusManager = class extends Subscribable {
	#focused;
	#cleanup;
	#setup;
	constructor() {
		super();
		this.#setup = (onFocus) => {
			if (typeof window !== "undefined" && window.addEventListener) {
				const listener = () => onFocus();
				window.addEventListener("visibilitychange", listener, false);
				return () => {
					window.removeEventListener("visibilitychange", listener);
				};
			}
		};
	}
	onSubscribe() {
		if (!this.#cleanup) this.setEventListener(this.#setup);
	}
	onUnsubscribe() {
		if (!this.hasListeners()) {
			this.#cleanup?.();
			this.#cleanup = void 0;
		}
	}
	/**
	* `setEventListener` can be used to set a custom event listener that will
	* be used to determine the focus state. The provided `setup` function
	* receives a `setFocused` callback: call it with a `boolean` to manually
	* set the focus state, or with no arguments to re-evaluate the current
	* focus state and notify subscribers.
	* @param setup - Receives the `setFocused` callback, registers the event listener, and may return
	* a cleanup function that is called when the listener is replaced or no longer needed.
	* @example
	* ```ts
	* import { focusManager } from '@tanstack/query-core'
	*
	* focusManager.setEventListener((handleFocus) => {
	*   const listener = () => handleFocus()
	*   // Listen to visibilitychange
	*   if (typeof window !== 'undefined' && window.addEventListener) {
	*     window.addEventListener('visibilitychange', listener, false)
	*   }
	*
	*   return () => {
	*     // Be sure to unsubscribe if a new handler is set
	*     window.removeEventListener('visibilitychange', listener)
	*   }
	* })
	* ```
	*/
	setEventListener(setup) {
		this.#setup = setup;
		this.#cleanup?.();
		this.#cleanup = setup((focused) => {
			if (typeof focused === "boolean") this.setFocused(focused);
			else this.onFocus();
		});
	}
	/**
	* `setFocused` can be used to manually set the focus state. Set `undefined`
	* to fall back to the default focus check.
	* @param focused - The focus state, or `undefined` to use the default focus check.
	* @example
	* ```ts
	* import { focusManager } from '@tanstack/query-core'
	*
	* // Set focused
	* focusManager.setFocused(true)
	*
	* // Set unfocused
	* focusManager.setFocused(false)
	*
	* // Fallback to the default focus check
	* focusManager.setFocused(undefined)
	* ```
	*/
	setFocused(focused) {
		if (this.#focused !== focused) {
			this.#focused = focused;
			this.onFocus();
		}
	}
	/**
	* `onFocus` notifies all subscribed listeners with the current focus state.
	*/
	onFocus() {
		const isFocused = this.isFocused();
		this.listeners.forEach((listener) => {
			listener(isFocused);
		});
	}
	/**
	* `isFocused` can be used to get the current focus state.
	* @returns The focus state set with `setFocused`, or otherwise whether the document is visible.
	*/
	isFocused() {
		if (typeof this.#focused === "boolean") return this.#focused;
		return globalThis.document?.visibilityState !== "hidden";
	}
};
/**
* Singleton instance of {@link FocusManager}, used to manage and observe the focus state within TanStack Query.
*/
var focusManager = new FocusManager();
// node_modules/@tanstack/query-core/build/modern/hydration.js
/**
* Reads the value of a promise synchronously if it has already resolved, e.g. a thenable that
* resolves within its `then` call.
* @param promise - The promise to read.
* @returns An object with the resolved `data`, or `undefined` if the promise hasn't resolved
* synchronously (or resolved with `undefined`).
*/
function tryResolveSync(promise) {
	let data;
	promise.then((result) => {
		data = result;
		return result;
	}, noop)?.catch?.(noop);
	if (data !== void 0) return { data };
}
/**
* Dehydrates a single `Mutation` into a serializable snapshot of its key, state, scope, and meta.
* @param mutation - The mutation to dehydrate.
* @returns The dehydrated mutation.
*/
function dehydrateMutation(mutation) {
	return {
		mutationKey: mutation.options.mutationKey,
		state: mutation.state,
		...mutation.options.scope && { scope: mutation.options.scope },
		...mutation.meta && { meta: mutation.meta }
	};
}
/**
* Prepares the in-flight promise of a pending query for dehydration: applies `serializeData` to its
* result, and redacts its rejection error unless `shouldRedactErrors` returns `false` for it.
* @param query - The pending query whose promise is dehydrated.
* @param serializeData - Optional transform applied to the resolved data.
* @param shouldRedactErrors - Optional predicate; if it returns `false` for the rejection error,
* that
* error is kept as-is instead of being redacted.
* @returns The transformed promise, or `undefined` if the query has no in-flight promise.
*/
function dehydratePromise(query, serializeData, shouldRedactErrors) {
	const promise = query.promise?.then(serializeData).catch((error) => {
		if (shouldRedactErrors?.(error) === false) return Promise.reject(error);
		console.error(`A query that was dehydrated as pending ended up rejecting. [${query.queryHash}]: ${error}; The error will be redacted in production builds`);
		return Promise.reject(/* @__PURE__ */ new Error("redacted"));
	});
	promise?.catch(noop);
	return promise;
}
/**
* Dehydrates a single `Query` into a serializable `DehydratedQuery` snapshot. Note that most query config (e.g.
* `queryFn`, `staleTime`) is not dehydrated but instead meant to be configured again when consuming the
* de/rehydrated data, typically with `useQuery` on the client. If the query is still `pending`, its in-flight
* promise is dehydrated too so it can be resumed on the other side instead of re-fetched.
* @param query - The query to dehydrate.
* @param serializeData - Optional transform applied to `query.state.data` before it is included in the snapshot.
* @param shouldRedactErrors - Optional predicate; if it returns `false` for the promise's rejection error, that
* error is kept as-is instead of being redacted.
* @returns The dehydrated query.
*/
function dehydrateQuery(query, serializeData, shouldRedactErrors) {
	return {
		dehydratedAt: Date.now(),
		state: {
			...query.state,
			...query.state.data !== void 0 && { data: serializeData ? serializeData(query.state.data) : query.state.data }
		},
		queryKey: query.queryKey,
		queryHash: query.queryHash,
		...query.state.status === "pending" && { promise: dehydratePromise(query, serializeData, shouldRedactErrors) },
		...query.meta && { meta: query.meta },
		...query.queryType && { queryType: query.queryType }
	};
}
/**
* The default `shouldDehydrateMutation` predicate used by `dehydrate`. Only dehydrates mutations that are
* currently paused (e.g. paused by `networkMode` while offline).
* @param mutation - The mutation to check.
* @returns `true` if the mutation is paused.
*/
function defaultShouldDehydrateMutation(mutation) {
	return mutation.state.isPaused;
}
/**
* The default `shouldDehydrateQuery` predicate used by `dehydrate`. Only dehydrates queries whose status is
* `'success'`.
* @param query - The query to check.
* @returns `true` if the query's status is `'success'`.
*/
function defaultShouldDehydrateQuery(query) {
	return query.state.status === "success";
}
/**
* Dehydrates a `QueryClient`'s cache (queries and mutations) into a plain, serializable `DehydratedState`,
* typically to embed in server-rendered markup and later restore into a client-side `QueryClient` via `hydrate`.
* Which queries/mutations are included, and how their data/errors are transformed, is controlled by `options`,
* falling back to the client's `dehydrate` default options, and finally to `defaultShouldDehydrateQuery` /
* `defaultShouldDehydrateMutation`.
* @param client - The client whose cache is dehydrated.
* @param options - Controls which queries and mutations are included and how their data and errors
* are transformed. Each option falls back to the client's `defaultOptions.dehydrate`.
* @returns The dehydrated state, with the included `queries` and `mutations`.
* @example
* ```ts
* const queryClient = new QueryClient()
*
* await queryClient.prefetchQuery({
*   queryKey: ['posts'],
*   queryFn: getPosts,
* })
*
* const dehydratedState = dehydrate(queryClient)
* ```
*/
function dehydrate(client, options = {}) {
	const filterMutation = options.shouldDehydrateMutation ?? client.getDefaultOptions().dehydrate?.shouldDehydrateMutation ?? defaultShouldDehydrateMutation;
	const mutations = client.getMutationCache().getAll().flatMap((mutation) => filterMutation(mutation) ? [dehydrateMutation(mutation)] : []);
	const filterQuery = options.shouldDehydrateQuery ?? client.getDefaultOptions().dehydrate?.shouldDehydrateQuery ?? defaultShouldDehydrateQuery;
	const shouldRedactErrors = options.shouldRedactErrors ?? client.getDefaultOptions().dehydrate?.shouldRedactErrors;
	const serializeData = options.serializeData ?? client.getDefaultOptions().dehydrate?.serializeData;
	return {
		mutations,
		queries: client.getQueryCache().getAll().flatMap((query) => filterQuery(query) ? [dehydrateQuery(query, serializeData, shouldRedactErrors)] : [])
	};
}
/**
* Restores a `DehydratedState` (as produced by `dehydrate`) into a `QueryClient`'s cache, typically to seed the
* client with data already fetched on the server. `mutations` and `queries` are each optional on `dehydratedState`.
* Queries not yet in the cache are built from the dehydrated snapshot; queries that already exist are only updated
* when the dehydrated data is newer than what's already cached. Newly built queries have their `fetchStatus` reset
* to `'idle'` so they don't hydrate stuck in a fetching state. If a dehydrated query still had an in-flight
* promise, it is resumed via `query.fetch()` (reusing that promise as `initialPromise`) rather than re-invoking
* `queryFn`.
* @param client - The client whose cache is restored into.
* @param dehydratedState - The dehydrated state, e.g. produced by `dehydrate` on the server.
* @param options - `defaultOptions` merged into every restored query and mutation (on top of the
* client's `defaultOptions.hydrate`), and `deserializeData` to reverse `serializeData`.
* @example
* ```ts
* // dehydratedState was produced by `dehydrate` on the server
* // and sent to the client, e.g. embedded in server-rendered markup.
* const queryClient = new QueryClient()
*
* hydrate(queryClient, dehydratedState)
* ```
*/
function hydrate(client, dehydratedState, options) {
	const mutationCache = client.getMutationCache();
	const queryCache = client.getQueryCache();
	const deserializeData = options?.defaultOptions?.deserializeData ?? client.getDefaultOptions().hydrate?.deserializeData;
	dehydratedState.mutations?.forEach(({ state, ...mutationOptions }) => {
		mutationCache.build(client, {
			...client.getDefaultOptions().hydrate?.mutations,
			...options?.defaultOptions?.mutations,
			...mutationOptions
		}, state);
	});
	dehydratedState.queries?.forEach(({ queryKey, state, queryHash, meta, promise, dehydratedAt, queryType }) => {
		const syncData = promise ? tryResolveSync(promise) : void 0;
		const rawData = state.data === void 0 ? syncData?.data : state.data;
		const data = rawData === void 0 ? rawData : deserializeData ? deserializeData(rawData) : rawData;
		let query = queryCache.get(queryHash);
		const existingQueryIsPending = query?.state.status === "pending";
		const existingQueryIsFetching = query?.state.fetchStatus === "fetching";
		if (query) {
			const hasNewerSyncData = syncData && dehydratedAt > query.state.dataUpdatedAt;
			if (state.dataUpdatedAt > query.state.dataUpdatedAt || hasNewerSyncData) {
				const { fetchStatus: _ignored, ...serializedState } = state;
				query.setState({
					...serializedState,
					data,
					...state.status === "pending" && data !== void 0 && {
						status: "success",
						dataUpdatedAt: dehydratedAt,
						...!existingQueryIsFetching && { fetchStatus: "idle" }
					}
				});
			}
		} else query = queryCache.build(client, {
			...client.getDefaultOptions().hydrate?.queries,
			...options?.defaultOptions?.queries,
			queryKey,
			queryHash,
			meta,
			_type: queryType
		}, {
			...state,
			data,
			fetchStatus: "idle",
			status: state.status === "pending" && data !== void 0 ? "success" : state.status,
			...state.status === "pending" && data !== void 0 && { dataUpdatedAt: dehydratedAt }
		});
		if (promise && !syncData && !existingQueryIsPending && !existingQueryIsFetching && dehydratedAt > query.state.dataUpdatedAt) query.fetch(void 0, { initialPromise: Promise.resolve(promise).then(deserializeData) }).catch(noop);
	});
}
// node_modules/@tanstack/query-core/build/modern/notifyManager.js
/**
* Default scheduling function used by the notify manager.
* Schedules the callback with the system's `setTimeout(callback, 0)`.
*/
var defaultScheduler = systemSetTimeoutZero;
/**
* Creates a notify manager, which schedules and batches notifications to subscribers. Query uses a
* single instance of it, exported as {@link notifyManager}.
* @returns A new notify manager.
*/
function createNotifyManager() {
	let queue = [];
	let transactions = 0;
	let notifyFn = (callback) => {
		callback();
	};
	let batchNotifyFn = (callback) => {
		callback();
	};
	let scheduleFn = defaultScheduler;
	const schedule = (callback) => {
		if (transactions) queue.push(callback);
		else scheduleFn(() => {
			notifyFn(callback);
		});
	};
	const flush = () => {
		const originalQueue = queue;
		queue = [];
		if (originalQueue.length) scheduleFn(() => {
			batchNotifyFn(() => {
				originalQueue.forEach((callback) => {
					notifyFn(callback);
				});
			});
		});
	};
	return {
		/**
		* Batches all updates scheduled inside the passed callback.
		* This is mainly used internally to optimize query client updating.
		* Batches can be nested; the queue is only flushed once the outermost `batch` call finishes.
		* The return value of `callback` is passed through.
		* @param callback - The function to run in the batch.
		* @returns The return value of `callback`.
		*/
		batch: (callback) => {
			let result;
			transactions++;
			try {
				result = callback();
			} finally {
				transactions--;
				if (!transactions) flush();
			}
			return result;
		},
		/**
		* All calls to the wrapped function will be batched.
		* @param callback - The function to wrap.
		* @returns A function that schedules a call to `callback` with the given arguments.
		*/
		batchCalls: (callback) => {
			return (...args) => {
				schedule(() => {
					callback(...args);
				});
			};
		},
		/**
		* Schedules a function to be run on the next batch.
		* By default, the batch is run with a `setTimeout`, but this can be configured via `setScheduler`.
		*/
		schedule,
		/**
		* Use this method to set a custom notify function.
		* This can be used to for example wrap notifications with `React.act` while running tests.
		* @param fn - Receives each notification callback and must call it.
		*/
		setNotifyFunction: (fn) => {
			notifyFn = fn;
		},
		/**
		* Use this method to set a custom function to batch notifications together into a single tick.
		* Framework adapters use this to plug in their own batching primitive, so that a single query
		* update only triggers one re-render instead of one per subscriber.
		* @param fn - Receives a function that runs a batch of notifications and must call it.
		* @example
		* ```ts
		* import { notifyManager } from '@tanstack/query-core'
		* import { batch } from 'solid-js'
		*
		* notifyManager.setBatchNotifyFunction(batch)
		* ```
		*/
		setBatchNotifyFunction: (fn) => {
			batchNotifyFn = fn;
		},
		/**
		* Configures a custom callback that schedules when the next batch runs.
		* The default behavior is `setTimeout(callback, 0)`.
		* @param fn - Receives a callback that runs the next batch, and schedules it.
		* @example
		* ```ts
		* import { notifyManager } from '@tanstack/query-core'
		*
		* // Schedule batches in the next microtask
		* notifyManager.setScheduler(queueMicrotask)
		*
		* // Schedule batches before the next frame is rendered
		* notifyManager.setScheduler(requestAnimationFrame)
		*
		* // Schedule batches some time in the future
		* notifyManager.setScheduler((cb) => setTimeout(cb, 10))
		* ```
		*/
		setScheduler: (fn) => {
			scheduleFn = fn;
		}
	};
}
/**
* Handles scheduling and batching callbacks in TanStack Query.
*/
var notifyManager = createNotifyManager();
// node_modules/@tanstack/query-core/build/modern/onlineManager.js
/**
* The `OnlineManager` manages the online state within TanStack Query. It can
* be used to change the default event listeners or to manually change the
* online state.
*
* By default, the `onlineManager` assumes an active network connection, and
* listens to the `online` and `offline` events on the `window` object to
* detect changes.
*/
var OnlineManager = class extends Subscribable {
	#online = true;
	#cleanup;
	#setup;
	constructor() {
		super();
		this.#setup = (onOnline) => {
			if (typeof window !== "undefined" && window.addEventListener) {
				const onlineListener = () => onOnline(true);
				const offlineListener = () => onOnline(false);
				window.addEventListener("online", onlineListener, false);
				window.addEventListener("offline", offlineListener, false);
				return () => {
					window.removeEventListener("online", onlineListener);
					window.removeEventListener("offline", offlineListener);
				};
			}
		};
	}
	onSubscribe() {
		if (!this.#cleanup) this.setEventListener(this.#setup);
	}
	onUnsubscribe() {
		if (!this.hasListeners()) {
			this.#cleanup?.();
			this.#cleanup = void 0;
		}
	}
	/**
	* `setEventListener` can be used to set a custom event listener that will
	* be used to determine the online state. The provided `setup` function
	* receives a `setOnline` callback that should be called with a `boolean`
	* whenever the online state changes.
	* @param setup - Receives the `setOnline` callback, registers the event listener, and may return
	* a cleanup function that is called when the listener is replaced or no longer needed.
	* @example
	* ```ts
	* import NetInfo from '@react-native-community/netinfo'
	* import { onlineManager } from '@tanstack/query-core'
	*
	* onlineManager.setEventListener((setOnline) => {
	*   return NetInfo.addEventListener((state) => {
	*     setOnline(!!state.isConnected)
	*   })
	* })
	* ```
	*/
	setEventListener(setup) {
		this.#setup = setup;
		this.#cleanup?.();
		this.#cleanup = setup(this.setOnline.bind(this));
	}
	/**
	* `setOnline` can be used to manually set the online state.
	* @param online - The online state.
	* @example
	* ```ts
	* import { onlineManager } from '@tanstack/query-core'
	*
	* // Set to online
	* onlineManager.setOnline(true)
	*
	* // Set to offline
	* onlineManager.setOnline(false)
	* ```
	*/
	setOnline(online) {
		if (this.#online !== online) {
			this.#online = online;
			this.listeners.forEach((listener) => {
				listener(online);
			});
		}
	}
	/**
	* `isOnline` can be used to get the current online state.
	* @returns `true` if online.
	*/
	isOnline() {
		return this.#online;
	}
};
/**
* Singleton instance of {@link OnlineManager}, used to manage and observe the online state within TanStack Query.
*/
var onlineManager = new OnlineManager();
// node_modules/@tanstack/query-core/build/modern/retryer.js
/**
* The default `retryDelay`: doubles with every failure, starting at 1 second, up to 30 seconds.
* @param failureCount - The number of failures so far.
* @returns The delay before the next retry, in milliseconds.
*/
function defaultRetryDelay(failureCount) {
	return Math.min(1e3 * 2 ** failureCount, 3e4);
}
/**
* Checks whether a fetch can run for the given network mode.
* @param networkMode - The `networkMode` option. Defaults to `'online'`.
* @returns `true` if the network mode is not `'online'`, or if it is and the client is online.
*/
function canFetch(networkMode) {
	return (networkMode ?? "online") === "online" ? onlineManager.isOnline() : true;
}
/**
* The error thrown by a `Retryer` (and surfaced to `query.promise`/`mutation`) when a fetch is cancelled, e.g. via
* `query.cancel()`. `revert`, if `true`, tells the caller to restore the state the query was in before the fetch
* started instead of surfacing the error. `silent`, if `true`, tells the caller to suppress this error and instead
* resolve with the promise of the fetch that triggered the cancellation.
* @example
* ```ts
* query.cancel()
*
* try {
*   await query.promise
* } catch (error) {
*   if (error instanceof CancelledError) {
*     // the fetch was cancelled, e.g. via `query.cancel()`
*   }
* }
* ```
*/
var CancelledError = class extends Error {
	constructor(options) {
		super("CancelledError");
		this.revert = options?.revert;
		this.silent = options?.silent;
	}
};
/**
* Checks whether a value is a `CancelledError`.
* @param value - The value to check.
* @returns `true` if `value` is a `CancelledError`.
* @deprecated Use instanceof `CancelledError` instead.
*/
function isCancelledError(value) {
	return value instanceof CancelledError;
}
/**
* Creates a retryer, which runs a function and retries it on failure according to the `retry` and
* `retryDelay` options. It pauses while the network mode doesn't allow fetching or `canRun` returns
* `false`, and can be cancelled. Queries and mutations use it to run their `queryFn` and
* `mutationFn`.
* @param config - The function to run, the retry options, and the callbacks for failures, pausing,
* continuing, and cancellation.
* @returns The retryer, whose `promise` settles with the result of the function.
*/
function createRetryer(config) {
	let isRetryCancelled = false;
	let failureCount = 0;
	let continueFn;
	let status = "pending";
	let promiseResolve;
	let promiseReject;
	const promise = new Promise((resolve, reject) => {
		promiseResolve = resolve;
		promiseReject = reject;
	});
	promise.catch(noop);
	const isResolved = () => status !== "pending";
	const cancel = (cancelOptions) => {
		if (!isResolved()) {
			const error = new CancelledError(cancelOptions);
			reject(error);
			config.onCancel?.(error);
		}
	};
	const cancelRetry = () => {
		isRetryCancelled = true;
	};
	const continueRetry = () => {
		isRetryCancelled = false;
	};
	const canContinue = () => focusManager.isFocused() && (config.networkMode === "always" || onlineManager.isOnline()) && config.canRun();
	const canStart = () => canFetch(config.networkMode) && config.canRun();
	const resolve = (value) => {
		if (!isResolved()) {
			continueFn?.();
			status = "resolved";
			promiseResolve(value);
		}
	};
	const reject = (value) => {
		if (!isResolved()) {
			continueFn?.();
			status = "rejected";
			promiseReject(value);
		}
	};
	const pause = (canResume) => {
		return new Promise((continueResolve) => {
			continueFn = (value) => {
				if (isResolved() || canResume()) continueResolve(value);
			};
			config.onPause?.();
		}).then(() => {
			continueFn = void 0;
			if (!isResolved()) config.onContinue?.();
		});
	};
	const run = () => {
		if (isResolved()) return;
		let promiseOrValue;
		const initialPromise = failureCount === 0 ? config.initialPromise : void 0;
		try {
			promiseOrValue = initialPromise ?? config.fn();
		} catch (error) {
			promiseOrValue = Promise.reject(error);
		}
		Promise.resolve(promiseOrValue).then(resolve).catch((error) => {
			if (isResolved()) return;
			const retry = config.retry ?? (isServer$2() ? 0 : 3);
			const retryDelay = config.retryDelay ?? defaultRetryDelay;
			const delay = typeof retryDelay === "function" ? retryDelay(failureCount, error) : retryDelay;
			const shouldRetry = retry === true || typeof retry === "number" && failureCount < retry || typeof retry === "function" && retry(failureCount, error);
			if (isRetryCancelled || !shouldRetry) {
				reject(error);
				return;
			}
			failureCount++;
			config.onFail?.(failureCount, error);
			sleep(delay).then(() => {
				return isResolved() || canContinue() ? void 0 : pause(canContinue);
			}).then(() => {
				if (isRetryCancelled) reject(error);
				else run();
			});
		});
	};
	return {
		promise,
		status: () => status,
		cancel,
		continue: () => {
			continueFn?.();
			return promise;
		},
		cancelRetry,
		continueRetry,
		canStart,
		start: () => {
			if (canStart()) run();
			else pause(canStart).then(run);
			return promise;
		}
	};
}
// node_modules/@tanstack/query-core/build/modern/removable.js
/**
* The base class for cache entries that are garbage collected once nothing is using them —
* `Query` and `Mutation` both extend it. `gcTime` controls how long an unused entry is kept.
*/
var Removable = class {
	#gcTimeout;
	/**
	* Clears the pending garbage collection timeout, so the entry is no longer scheduled for removal.
	* A subclass may override this to release what it holds on to as well — `Query` also cancels any
	* in-flight fetch.
	*/
	destroy() {
		this.clearGcTimeout();
	}
	/**
	* Schedules the entry to be removed from its cache after `gcTime`, replacing any timeout scheduled
	* before. Nothing is scheduled if `gcTime` is `Infinity`.
	*/
	scheduleGc() {
		this.clearGcTimeout();
		if (isValidTimeout(this.gcTime)) this.#gcTimeout = timeoutManager.setTimeout(() => {
			this.optionalRemove();
		}, this.gcTime);
	}
	/**
	* Updates `gcTime`, keeping the longest one seen so far. Without a value, it defaults to 5 minutes
	* on the client and `Infinity` on the server.
	* @param newGcTime - The `gcTime` from the latest options, if any.
	*/
	updateGcTime(newGcTime) {
		this.gcTime = Math.max(this.gcTime || 0, newGcTime ?? (isServer$2() ? Infinity : 3e5));
	}
	/**
	* Cancels the scheduled removal, if there is one.
	*/
	clearGcTimeout() {
		if (this.#gcTimeout !== void 0) {
			timeoutManager.clearTimeout(this.#gcTimeout);
			this.#gcTimeout = void 0;
		}
	}
};
// node_modules/@tanstack/query-core/build/modern/infiniteQueryBehavior.js
/**
* Creates the behavior that fetches the pages of an infinite query: the next or previous page for
* `fetchNextPage`/`fetchPreviousPage`, or all pages again from the start on a refetch.
* @param pages - The number of pages to fetch from the start when all pages are fetched again,
* e.g. from the `pages` option of `queryClient.infiniteQuery`. Defaults to the number of cached
* pages.
* @returns The query behavior to set on an infinite query.
*/
function infiniteQueryBehavior(pages) {
	return { onFetch: (context, query) => {
		const options = context.options;
		const direction = context.fetchOptions?.meta?.fetchMore?.direction;
		const oldPages = context.state.data?.pages || [];
		const oldPageParams = context.state.data?.pageParams || [];
		let result = {
			pages: [],
			pageParams: []
		};
		let currentPage = 0;
		const fetchFn = async () => {
			let cancelled = false;
			const signalContext = context;
			const addSignalProperty = (object) => {
				addConsumeAwareSignal(object, () => context.signal, () => cancelled = true, signalContext[fetchSignal]);
			};
			const queryFn = ensureQueryFn(context.options, context.fetchOptions);
			const fetchPage = async (data, param, previous) => {
				if (cancelled) return Promise.reject(context.signal.reason);
				if (param == null && data.pages.length) return Promise.resolve(data);
				const createQueryFnContext = () => {
					const queryFnContext = {
						client: context.client,
						queryKey: context.queryKey,
						pageParam: param,
						direction: previous ? "backward" : "forward",
						meta: context.options.meta
					};
					addSignalProperty(queryFnContext);
					return queryFnContext;
				};
				const queryFnContext = createQueryFnContext();
				const page = await queryFn(queryFnContext);
				const { maxPages } = context.options;
				const addTo = previous ? addToStart : addToEnd;
				return {
					pages: addTo(data.pages, page, maxPages),
					pageParams: addTo(data.pageParams, param, maxPages)
				};
			};
			if (direction && oldPages.length) {
				const previous = direction === "backward";
				const pageParamFn = previous ? getPreviousPageParam : getNextPageParam;
				const oldData = {
					pages: oldPages,
					pageParams: oldPageParams
				};
				result = await fetchPage(oldData, pageParamFn(options, oldData), previous);
			} else {
				const remainingPages = pages ?? oldPages.length;
				do {
					const param = currentPage === 0 ? oldPageParams[0] === void 0 ? options.initialPageParam : oldPageParams[0] : getNextPageParam(options, result);
					if (currentPage > 0 && param == null) break;
					result = await fetchPage(result, param);
					currentPage++;
				} while (currentPage < remainingPages);
			}
			return result;
		};
		if (context.options.persister) context.fetchFn = () => {
			return context.options.persister?.(fetchFn, {
				client: context.client,
				queryKey: context.queryKey,
				meta: context.options.meta,
				signal: context.signal
			}, query);
		};
		else context.fetchFn = fetchFn;
	} };
}
/**
* Computes the page param of the page after the last one, with the `getNextPageParam` option.
* @param options - The infinite query options.
* @param data - The current pages and page params.
* @returns The next page param, or `undefined` if there are no pages yet.
*/
function getNextPageParam(options, { pages, pageParams }) {
	const lastIndex = pages.length - 1;
	return pages.length > 0 ? options.getNextPageParam(pages[lastIndex], pages, pageParams[lastIndex], pageParams) : void 0;
}
/**
* Computes the page param of the page before the first one, with the `getPreviousPageParam`
* option.
* @param options - The infinite query options.
* @param data - The current pages and page params.
* @returns The previous page param, or `undefined` if there are no pages yet or no
* `getPreviousPageParam` option.
*/
function getPreviousPageParam(options, { pages, pageParams }) {
	return pages.length > 0 ? options.getPreviousPageParam?.(pages[0], pages, pageParams[0], pageParams) : void 0;
}
/**
* Checks if there is a next page.
* @param options - The infinite query options with `getNextPageParam`.
* @param data - The current pages and page params.
* @returns `true` if `getNextPageParam` returns a value other than `null` or `undefined`.
*/
function hasNextPage(options, data) {
	if (!data) return false;
	return getNextPageParam(options, data) != null;
}
/**
* Checks if there is a previous page.
* @param options - The infinite query options with `getPreviousPageParam`.
* @param data - The current pages and page params.
* @returns `true` if `getPreviousPageParam` is set and returns a value other than `null` or
* `undefined`.
*/
function hasPreviousPage(options, data) {
	if (!data || !options.getPreviousPageParam) return false;
	return getPreviousPageParam(options, data) != null;
}
// node_modules/@tanstack/query-core/build/modern/query.js
/**
* Represents a single cached query. A `Query` holds the query's key, options,
* state (data/error/status), and the observers currently subscribed to it.
*
* Instances are created and managed internally by `QueryCache`; application
* code typically interacts with queries indirectly through `QueryClient` or
* a framework hook like `useQuery`. Direct access to a `Query` instance is
* possible via `queryCache.find()`/`findAll()` for inspecting cache state.
* @example
* ```ts
* const queryCache = queryClient.getQueryCache()
* const query = queryCache.find({ queryKey: ['posts'] })
*
* if (query) {
*   console.log(query.state.dataUpdatedAt)
* }
* ```
*/
var Query = class extends Removable {
	#queryType;
	#initialState;
	#revertState;
	#cache;
	#client;
	#retryer;
	#fetchPromise;
	#defaultOptions;
	#abortSignalConsumed;
	constructor(config) {
		super();
		this.#abortSignalConsumed = false;
		this.#defaultOptions = config.defaultOptions;
		this.setOptions(config.options);
		this.observers = [];
		this.#client = config.client;
		this.#cache = this.#client.getQueryCache();
		this.queryKey = config.queryKey;
		this.queryHash = config.queryHash;
		this.#initialState = getDefaultState$1(this.options);
		this.state = config.state ?? this.#initialState;
		this.scheduleGc();
	}
	/**
	* The `meta` object passed in the query's options, if any.
	* @returns The query's `meta`, or `undefined` if none was set.
	*/
	get meta() {
		return this.options.meta;
	}
	/**
	* `'infinite'` for an infinite query, otherwise `undefined`.
	* @internal
	* @returns The type of the query, set from the `_type` option (e.g. `'infinite'`).
	*/
	get queryType() {
		return this.#queryType;
	}
	/**
	* The promise for the currently in-flight fetch, if the query is fetching.
	* `undefined` when the query is not fetching.
	* @returns The promise of the in-flight fetch, or `undefined`.
	*/
	get promise() {
		return this.#retryer?.promise;
	}
	/**
	* Replaces the query's options and applies their `gcTime`. If the query has no data yet, it gets
	* the `initialData` from the new options, if any.
	* @internal
	* @param options - The new query options, merged on top of the query's default options.
	*/
	setOptions(options) {
		this.options = {
			...this.#defaultOptions,
			...options
		};
		if (options?._type) this.#queryType = options._type;
		this.updateGcTime(this.options.gcTime);
		if (this.state && this.state.data === void 0) {
			const defaultState = getDefaultState$1(this.options);
			if (defaultState.data !== void 0) {
				this.setState(successState(defaultState.data, defaultState.dataUpdatedAt));
				this.#initialState = defaultState;
			}
		}
	}
	optionalRemove() {
		if (!this.observers.length && this.state.fetchStatus === "idle") this.#cache.remove(this);
	}
	/**
	* Writes new data to the query and marks it as successfully fetched.
	* @internal
	* @param newData - The data to write. Structural sharing with the current data is applied.
	* @param options - Set `updatedAt` to override the timestamp, and `manual` to mark the write as
	* manual (e.g. from `queryClient.setQueryData`).
	* @returns The data that was written.
	*/
	setData(newData, options) {
		const data = replaceData(this.state.data, newData, this.options);
		this.#dispatch({
			data,
			type: "success",
			dataUpdatedAt: options?.updatedAt,
			manual: options?.manual
		});
		return data;
	}
	/**
	* Merges the given partial state directly into this query's state, notifying observers. Used
	* by persistence and broadcast plugins to restore a state snapshot, and by devtools to let a
	* user manually trigger a loading/error state or edit the cached data.
	* @param state - The partial state to merge into the query's state.
	*/
	setState(state) {
		this.#dispatch({
			type: "setState",
			state
		});
	}
	/**
	* Cancels the query's currently in-flight fetch, if any.
	* - Returns a promise that resolves once the cancellation has settled.
	* - If no fetch is in progress, resolves immediately.
	* @param options - Set `revert` to restore the state from before the fetch started, and `silent`
	* to suppress the cancellation error when a new fetch replaces the cancelled one.
	* @returns A promise that resolves once the cancellation has settled.
	* @example
	* ```ts
	* await query.cancel()
	* ```
	*/
	cancel(options) {
		const promise = this.#retryer?.promise;
		this.#retryer?.cancel(options);
		return promise ? promise.then(noop).catch(noop) : Promise.resolve();
	}
	/**
	* Clears the query's garbage collection timeout and silently cancels any
	* in-flight fetch. Called by `QueryCache` when the query is removed from
	* the cache.
	* @see {@link Query#cancel}
	*/
	destroy() {
		super.destroy();
		this.cancel({ silent: true });
	}
	/**
	* The state the query was created with.
	* @internal
	* @returns The state the query had when it was first created, used by {@link Query#reset}.
	*/
	get resetState() {
		return this.#initialState;
	}
	/**
	* Resets the query back to its initial state (the state it had when it was
	* first created, e.g. any `initialData`), destroying it first to cancel any
	* in-flight fetch.
	*/
	reset() {
		this.destroy();
		this.setState(this.resetState);
	}
	/**
	* Returns `true` if the query has at least one observer for which `enabled`
	* does not resolve to `false`.
	* @returns `true` if the query has an enabled observer.
	*/
	isActive() {
		return this.observers.some((observer) => resolveQueryValue(observer.options.enabled, this) !== false);
	}
	/**
	* Returns `true` if the query is disabled, meaning it will not fetch
	* automatically.
	* - If the query has observers, it is disabled when none of them are active
	*   (see `isActive`).
	* - If the query has no observers, it is disabled when its `queryFn` is
	*   `skipToken` or it has never been fetched.
	* @returns `true` if the query is disabled.
	*/
	isDisabled() {
		if (this.getObserversCount() > 0) return !this.isActive();
		return this.options.queryFn === skipToken || !this.isFetched();
	}
	/**
	* Returns `true` if the query has been fetched, i.e. it has resolved with
	* either data or an error at least once.
	* @returns `true` if the query has been fetched.
	*/
	isFetched() {
		return this.state.dataUpdateCount + this.state.errorUpdateCount > 0;
	}
	/**
	* Returns `true` if the query has data and at least one observer configured with
	* `staleTime: 'static'`, meaning it is treated as never stale.
	* @returns `true` if the query is static.
	*/
	isStatic() {
		if (this.state.data === void 0) return false;
		if (this.getObserversCount() > 0) return this.observers.some((observer) => resolveQueryValue(observer.options.staleTime, this) === "static");
		return false;
	}
	/**
	* Returns `true` if the query is stale.
	* - If the query has observers, defers to whether any observer's current
	*   result reports `isStale` (which accounts for each observer's own
	*   `staleTime` and `enabled` state).
	* - If the query has no observers, it is considered stale when it has no
	*   data or has been invalidated.
	* @returns `true` if the query is stale.
	* @see {@link Query#isStaleByTime}
	* @example
	* ```ts
	* if (query.isStale()) {
	*   // refetch or otherwise treat the cached data as outdated
	* }
	* ```
	*/
	isStale() {
		if (this.getObserversCount() > 0) return this.observers.some((observer) => observer.getCurrentResult().isStale);
		return this.state.data === void 0 || this.state.isInvalidated;
	}
	/**
	* Returns `true` if the query's data is stale relative to the given
	* `staleTime` (defaults to `0`).
	* - A query with no data is always stale.
	* - `staleTime: 'static'` is never stale.
	* - An invalidated query is always stale.
	* - Otherwise, staleness is based on elapsed time since `dataUpdatedAt`.
	* @param staleTime - The time, in milliseconds, after which data is considered stale, or
	* `'static'` to never treat existing data as stale. A query without data is stale either way.
	* @returns `true` if the query's data is stale.
	* @see {@link Query#isStale}
	* @example
	* ```ts
	* const isStale = query.isStaleByTime(60 * 1000)
	* ```
	*/
	isStaleByTime(staleTime = 0) {
		if (this.state.data === void 0) return true;
		if (staleTime === "static") return false;
		if (this.state.isInvalidated) return true;
		return !timeUntilStale(this.state.dataUpdatedAt, staleTime);
	}
	/**
	* Refetches the query when the window regains focus, if an observer wants that, and continues a
	* paused fetch.
	* @internal
	*/
	onFocus() {
		this.observers.find((x) => x.shouldFetchOnWindowFocus())?.refetch({ cancelRefetch: false });
		this.#retryer?.continue();
	}
	/**
	* Refetches the query when the app reconnects, if an observer wants that, and continues a paused
	* fetch.
	* @internal
	*/
	onOnline() {
		this.observers.find((x) => x.shouldFetchOnReconnect())?.refetch({ cancelRefetch: false });
		this.#retryer?.continue();
	}
	/**
	* Subscribes an observer to the query and stops its garbage collection.
	* @internal
	* @param observer - The observer to add. Adding an observer that is already subscribed does
	* nothing.
	*/
	addObserver(observer) {
		if (!this.observers.includes(observer)) {
			this.observers.push(observer);
			this.clearGcTimeout();
			this.#cache.notify({
				type: "observerAdded",
				query: this,
				observer
			});
		}
	}
	/**
	* Unsubscribes an observer from the query.
	* @internal
	* @param observer - The observer to remove. When the last observer is removed, the in-flight
	* fetch is cancelled if its abort signal was consumed (otherwise only its retries are stopped),
	* and garbage collection is scheduled.
	*/
	removeObserver(observer) {
		const index = this.observers.indexOf(observer);
		if (index !== -1) {
			this.observers.splice(index, 1);
			if (!this.observers.length) {
				if (this.#retryer) {
					if (this.#abortSignalConsumed || this.state.fetchStatus === "paused" && this.state.status === "pending") this.#retryer.cancel({ revert: true });
					else this.#retryer.cancelRetry();
				}
				this.scheduleGc();
			}
			this.#cache.notify({
				type: "observerRemoved",
				query: this,
				observer
			});
		}
	}
	/**
	* Returns the number of observers currently subscribed to this query.
	* @returns The number of observers.
	* @example
	* ```ts
	* if (query.getObserversCount() === 0) {
	*   // no component is currently watching this query
	* }
	* ```
	*/
	getObserversCount() {
		return this.observers.length;
	}
	/**
	* Marks the query as invalidated, unless it is already invalidated. This
	* updates `state.isInvalidated` and notifies observers, but does not by
	* itself trigger a refetch.
	* @example
	* ```ts
	* query.invalidate()
	* ```
	*/
	invalidate() {
		if (!this.state.isInvalidated) this.#dispatch({ type: "invalidate" });
	}
	/**
	* Fetches the query, i.e. runs its `queryFn` (through any configured
	* retryer/behavior) and updates the query's state with the result.
	* - If a fetch is already in flight, returns its promise instead of
	*   starting a new one, unless `fetchOptions.cancelRefetch` is set and the
	*   query already has data, in which case the current fetch is silently
	*   cancelled first.
	* - If `options` is passed, it replaces the query's current options
	*   before fetching.
	* @param options - Query options that replace the query's current options before fetching. They
	* are not applied when an in-flight fetch is reused.
	* @param fetchOptions - Set `cancelRefetch` to cancel an in-flight fetch first (only if the query
	* already has data), and `meta` to pass extra information to the query's behavior.
	* @returns A promise that resolves with the fetched data, or rejects with the fetch error. If the
	* fetch is cancelled with `revert` while the query has data, it resolves with the restored data
	* instead.
	*/
	async fetch(options, fetchOptions) {
		if (this.state.fetchStatus !== "idle" && this.#retryer?.status() !== "rejected") {
			if (this.state.data !== void 0 && fetchOptions?.cancelRefetch) this.cancel({ silent: true });
			else if (this.#retryer && this.#fetchPromise) {
				this.#retryer.continueRetry();
				return this.#fetchPromise;
			}
		}
		if (options) this.setOptions(options);
		if (!this.options.queryFn) {
			const observer = this.observers.find((x) => x.options.queryFn);
			if (observer) this.setOptions(observer.options);
		}
		if (!Array.isArray(this.options.queryKey)) console.error(`As of v4, queryKey needs to be an Array. If you are using a string like 'repoData', please change it to an Array, e.g. ['repoData']`);
		const abortController = new AbortController();
		const addSignalProperty = (object) => {
			Object.defineProperties(object, {
				[fetchSignal]: {
					value: abortController.signal,
					enumerable: true
				},
				signal: {
					enumerable: true,
					get: () => {
						this.#abortSignalConsumed = true;
						return abortController.signal;
					}
				}
			});
		};
		const fetchFn = () => {
			const queryFn = ensureQueryFn(this.options, fetchOptions);
			const createQueryFnContext = () => {
				const queryFnContext = {
					client: this.#client,
					queryKey: this.queryKey,
					meta: this.meta
				};
				addSignalProperty(queryFnContext);
				return queryFnContext;
			};
			const queryFnContext = createQueryFnContext();
			this.#abortSignalConsumed = false;
			if (this.options.persister) return this.options.persister(queryFn, queryFnContext, this);
			return queryFn(queryFnContext);
		};
		const createFetchContext = () => {
			const context = {
				fetchOptions,
				options: this.options,
				queryKey: this.queryKey,
				client: this.#client,
				state: this.state,
				fetchFn
			};
			addSignalProperty(context);
			return context;
		};
		const context = createFetchContext();
		(this.#queryType === "infinite" ? infiniteQueryBehavior(this.options.pages) : this.options.behavior)?.onFetch(context, this);
		this.#revertState = this.state;
		if (this.state.fetchStatus === "idle" || this.state.fetchMeta !== context.fetchOptions?.meta) this.#dispatch({
			type: "fetch",
			meta: context.fetchOptions?.meta
		});
		const retryer = this.#retryer = createRetryer({
			initialPromise: fetchOptions?.initialPromise,
			fn: context.fetchFn,
			onCancel: (error) => {
				if (error instanceof CancelledError && error.revert) this.setState({
					...this.#revertState,
					fetchStatus: "idle"
				});
				abortController.abort();
			},
			onFail: (failureCount, error) => {
				this.#dispatch({
					type: "failed",
					failureCount,
					error
				});
			},
			onPause: () => {
				this.#dispatch({ type: "pause" });
			},
			onContinue: () => {
				this.#dispatch({ type: "continue" });
			},
			retry: context.options.retry,
			retryDelay: context.options.retryDelay,
			networkMode: context.options.networkMode,
			canRun: () => true
		});
		const fetchPromise = (async () => {
			try {
				const data = await retryer.promise;
				if (data === void 0) {
					console.error(`Query data cannot be undefined. Please make sure to return a value other than undefined from your query function. Affected query key: ${this.queryHash}`);
					throw new Error(`${this.queryHash} data is undefined`);
				}
				this.setData(data);
				this.#cache.config.onSuccess?.(data, this);
				this.#cache.config.onSettled?.(data, this.state.error, this);
				return data;
			} catch (error) {
				if (error instanceof CancelledError) {
					if (error.silent) {
						if (this.#retryer !== retryer && this.#fetchPromise) return this.#fetchPromise;
						throw error;
					} else if (error.revert) {
						if (this.state.data === void 0) throw error;
						return this.state.data;
					}
				}
				this.#dispatch({
					type: "error",
					error
				});
				this.#cache.config.onError?.(error, this);
				this.#cache.config.onSettled?.(this.state.data, error, this);
				throw error;
			} finally {
				if (this.#retryer === retryer) {
					this.#retryer = void 0;
					this.#fetchPromise = void 0;
				}
				this.scheduleGc();
			}
		})();
		this.#fetchPromise = fetchPromise;
		retryer.start();
		return fetchPromise;
	}
	#dispatch(action) {
		const reducer = (state) => {
			switch (action.type) {
				case "failed": return {
					...state,
					fetchFailureCount: action.failureCount,
					fetchFailureReason: action.error
				};
				case "pause": return {
					...state,
					fetchStatus: "paused"
				};
				case "continue": return {
					...state,
					fetchStatus: "fetching"
				};
				case "fetch": return {
					...state,
					...fetchState(state.data, this.options),
					fetchMeta: action.meta ?? null
				};
				case "success":
					const newState = {
						...state,
						...successState(action.data, action.dataUpdatedAt),
						dataUpdateCount: state.dataUpdateCount + 1,
						...!action.manual && {
							fetchStatus: "idle",
							fetchFailureCount: 0,
							fetchFailureReason: null
						}
					};
					this.#revertState = action.manual ? newState : void 0;
					return newState;
				case "error":
					const error = action.error;
					return {
						...state,
						error,
						errorUpdateCount: state.errorUpdateCount + 1,
						errorUpdatedAt: Date.now(),
						fetchFailureCount: state.fetchFailureCount + 1,
						fetchFailureReason: error,
						fetchStatus: "idle",
						status: "error",
						isInvalidated: true
					};
				case "invalidate": return {
					...state,
					isInvalidated: true
				};
				case "setState": return {
					...state,
					...action.state
				};
			}
		};
		this.state = reducer(this.state);
		notifyManager.batch(() => {
			this.observers.slice().forEach((observer) => {
				observer.onQueryUpdate();
			});
			this.#cache.notify({
				query: this,
				type: "updated",
				action
			});
		});
	}
};
/**
* Returns the state changes applied when a query starts fetching.
* @param data - The query's current data. If it is `undefined`, the query is also reset to
* `'pending'` with no error.
* @param options - The query options, whose `networkMode` decides whether the query is `'fetching'`
* or `'paused'`.
* @returns The partial query state for a starting fetch.
*/
function fetchState(data, options) {
	return {
		fetchFailureCount: 0,
		fetchFailureReason: null,
		fetchStatus: canFetch(options.networkMode) ? "fetching" : "paused",
		...data === void 0 && {
			error: null,
			status: "pending"
		}
	};
}
/**
* Returns the state changes applied when a query receives data.
* @param data - The new data.
* @param dataUpdatedAt - The timestamp the data is recorded with. Defaults to the current time.
* @returns The partial query state for a successful update.
*/
function successState(data, dataUpdatedAt) {
	return {
		data,
		dataUpdatedAt: dataUpdatedAt ?? Date.now(),
		error: null,
		isInvalidated: false,
		status: "success"
	};
}
/**
* Returns the initial state of a query, based on its `initialData` and `initialDataUpdatedAt`
* options.
* @param options - The query options.
* @returns The initial query state: `'success'` if `initialData` is set, otherwise `'pending'`.
*/
function getDefaultState$1(options) {
	const data = typeof options.initialData === "function" ? options.initialData() : options.initialData;
	const hasData = data !== void 0;
	const initialDataUpdatedAt = hasData ? typeof options.initialDataUpdatedAt === "function" ? options.initialDataUpdatedAt() : options.initialDataUpdatedAt : 0;
	return {
		data,
		dataUpdateCount: 0,
		dataUpdatedAt: hasData ? initialDataUpdatedAt ?? Date.now() : 0,
		error: null,
		errorUpdateCount: 0,
		errorUpdatedAt: 0,
		fetchFailureCount: 0,
		fetchFailureReason: null,
		fetchMeta: null,
		isInvalidated: false,
		status: hasData ? "success" : "pending",
		fetchStatus: "idle"
	};
}
// node_modules/@tanstack/query-core/build/modern/queryObserver.js
/**
* A `QueryObserver` watches a single query in the `QueryCache` and computes a
* `QueryObserverResult` from its state, recomputing and notifying subscribers
* whenever the underlying query (or the observer's options) changes. It is
* the primitive that framework adapters (e.g. `useQuery`) build their hooks
* on top of, but it can also be used directly to observe and switch between
* queries outside of any framework.
* @example
* ```ts
* const observer = new QueryObserver(queryClient, {
*   queryKey: ['posts'],
*   queryFn: fetchPosts,
* })
*
* const unsubscribe = observer.subscribe((result) => {
*   console.log(result.data)
* })
* ```
*/
var QueryObserver = class extends Subscribable {
	#client;
	#currentQuery = void 0;
	#currentQueryInitialState = void 0;
	#currentResult = void 0;
	#currentResultState;
	#currentResultOptions;
	#selectError;
	#selectFn;
	#selectResult;
	#lastQueryWithDefinedData;
	#staleTimeoutId;
	#refetchIntervalId;
	#currentRefetchInterval;
	#trackedProps = /* @__PURE__ */ new Set();
	constructor(client, options) {
		super();
		this.options = options;
		this.#client = client;
		this.#selectError = null;
		this.bindMethods();
		this.setOptions(options);
	}
	/**
	* Binds the methods of the result (`refetch`) to the observer, so they keep working when destructured
	* from it. Subclasses override it to bind their own result methods as well.
	*/
	bindMethods() {
		this.refetch = this.refetch.bind(this);
	}
	onSubscribe() {
		if (this.listeners.size === 1) {
			this.#currentQuery.addObserver(this);
			if (shouldFetchOnMount(this.#currentQuery, this.options)) this.#executeFetch();
			else this.updateResult();
			this.#updateTimers();
		}
	}
	onUnsubscribe() {
		if (!this.hasListeners()) this.destroy();
	}
	/**
	* Returns whether the observed query is currently stale and configured
	* (via the `refetchOnReconnect` option) to refetch when the network
	* reconnects.
	* @returns `true` if the observer should refetch the query on reconnect.
	*/
	shouldFetchOnReconnect() {
		return shouldFetchOn(this.#currentQuery, this.options, this.options.refetchOnReconnect);
	}
	/**
	* Returns whether the observed query is currently stale and configured
	* (via the `refetchOnWindowFocus` option) to refetch when the window
	* regains focus.
	* @returns `true` if the observer should refetch the query on window focus.
	*/
	shouldFetchOnWindowFocus() {
		return shouldFetchOn(this.#currentQuery, this.options, this.options.refetchOnWindowFocus);
	}
	/**
	* Stops observing the current query: clears all listeners, cancels the
	* stale and refetch-interval timers, and removes this observer from the
	* query it was observing.
	*/
	destroy() {
		this.listeners = /* @__PURE__ */ new Set();
		this.#clearStaleTimeout();
		this.#clearRefetchInterval();
		this.#currentQuery.removeObserver(this);
	}
	/**
	* Updates the observer's options. This will re-resolve the query being
	* observed (switching to a different query if the `queryKey` changed),
	* trigger a fetch if the new options require one and the observer has
	* subscribers, recompute the current result, and reschedule the stale and
	* refetch-interval timers as needed.
	* @param options - The new observer options. They are defaulted with {@link
	* QueryClient#defaultQueryOptions} before being applied.
	* @throws {Error} If `enabled` is neither a boolean nor a function.
	* @example
	* ```ts
	* observer.setOptions({ queryKey: ['posts', 1], queryFn: () => fetchPost(1) })
	* // later: switch to a different query, reusing the same observer
	* observer.setOptions({ queryKey: ['posts', 2], queryFn: () => fetchPost(2) })
	* ```
	*/
	setOptions(options) {
		const prevOptions = this.options;
		const prevQuery = this.#currentQuery;
		this.options = this.#client.defaultQueryOptions(options);
		if (this.options.enabled !== void 0 && typeof this.options.enabled !== "boolean" && typeof this.options.enabled !== "function" && typeof resolveQueryValue(this.options.enabled, this.#currentQuery) !== "boolean") throw new Error("Expected enabled to be a boolean or a callback that returns a boolean");
		this.#updateQuery();
		this.#currentQuery.setOptions(this.options);
		if (prevOptions._defaulted && !shallowEqualObjects(this.options, prevOptions)) this.#client.getQueryCache().notify({
			type: "observerOptionsUpdated",
			query: this.#currentQuery,
			observer: this
		});
		const mounted = this.hasListeners();
		if (mounted && shouldFetchOptionally(this.#currentQuery, prevQuery, this.options, prevOptions)) this.#executeFetch();
		this.updateResult();
		if (mounted && (this.#currentQuery !== prevQuery || resolveQueryValue(this.options.enabled, this.#currentQuery) !== resolveQueryValue(prevOptions.enabled, this.#currentQuery) || resolveQueryValue(this.options.staleTime, this.#currentQuery) !== resolveQueryValue(prevOptions.staleTime, this.#currentQuery))) this.#updateStaleTimeout();
		const nextRefetchInterval = this.#computeRefetchInterval();
		if (mounted && (this.#currentQuery !== prevQuery || resolveQueryValue(this.options.enabled, this.#currentQuery) !== resolveQueryValue(prevOptions.enabled, this.#currentQuery) || nextRefetchInterval !== this.#currentRefetchInterval)) this.#updateRefetchInterval(nextRefetchInterval);
	}
	/**
	* Computes the result the observer would produce for the given (already-defaulted) options
	* right now, building the underlying `Query` if it doesn't exist yet, without waiting for a
	* subscription callback. Called by framework adapters on every render (e.g. `useQuery`) so the
	* returned value is available synchronously, ahead of `setOptions` triggering an actual fetch.
	* @param options - The defaulted observer options to compute the result for.
	* @returns The result for the given options.
	*/
	getOptimisticResult(options) {
		const query = this.#client.getQueryCache().build(this.#client, options);
		const result = this.createResult(query, options);
		if (!shallowEqualObjects(this.getCurrentResult(), result)) {
			this.#currentResult = result;
			this.#currentResultOptions = this.options;
			this.#currentResultState = this.#currentQuery.state;
		}
		return result;
	}
	/**
	* Returns the most recently computed `QueryObserverResult` for the
	* observed query. This is a point-in-time read; to be notified of updates
	* as they happen, subscribe to the observer instead (its inherited
	* `subscribe` method).
	* @returns The observer's latest result.
	* @example
	* ```ts
	* const result = observer.getCurrentResult()
	* console.log(result.status, result.data)
	* ```
	*/
	getCurrentResult() {
		return this.#currentResult;
	}
	/**
	* Wraps a `QueryObserverResult` in a `Proxy` that records which properties are read, via
	* {@link QueryObserver#trackProp} (and an optional `onPropTracked` callback). Used by framework
	* adapters when `notifyOnChangeProps` is not set, to implement its default "only re-render on
	* properties you actually read" behavior.
	* @param result - The result to wrap.
	* @param onPropTracked - Called with the name of each property that is read.
	* @returns A proxy of `result` that tracks property reads.
	*/
	trackResult(result, onPropTracked) {
		return new Proxy(result, { get: (target, key) => {
			this.trackProp(key);
			onPropTracked?.(key);
			return Reflect.get(target, key);
		} });
	}
	/**
	* Records that the given `QueryObserverResult` property was read, so a subsequent update only
	* notifies this observer if a tracked property actually changed. Normally called indirectly via
	* {@link QueryObserver#trackResult}'s proxy; exposed directly for adapters that track property
	* access themselves (e.g. through their own reactivity system) instead of via the proxy.
	* @param key - The name of the property that was read.
	*/
	trackProp(key) {
		this.#trackedProps.add(key);
	}
	/**
	* Returns the `Query` instance this observer is currently observing.
	* @returns The observed query.
	*/
	getCurrentQuery() {
		return this.#currentQuery;
	}
	/**
	* Refetches the observed query and returns a promise that resolves with
	* the resulting `QueryObserverResult`.
	* @param options - Set `cancelRefetch` to `false` to keep a running fetch instead of cancelling
	* it, and `throwOnError` to `true` to reject when the refetch fails.
	* @returns A promise that resolves with the result after the refetch.
	* @example
	* ```ts
	* const result = await observer.refetch({ cancelRefetch: false })
	* console.log(result.data)
	* ```
	*/
	refetch({ ...options } = {}) {
		return this.fetch({ ...options });
	}
	/**
	* Fetches a query defined by the given options without affecting this
	* observer's own tracked query or result, and returns a promise that
	* resolves with the `QueryObserverResult` for that fetch. This is useful
	* for prefetching data that another observer (e.g. a query about to be
	* navigated to) will need, ahead of time.
	* @param options - The observer options of the query to fetch.
	* @returns A promise that resolves with the result for the fetched query.
	* @example
	* ```ts
	* const result = await observer.fetchOptimistic({
	*   queryKey: ['posts', 2],
	*   queryFn: () => fetchPost(2),
	* })
	* console.log(result.data)
	* ```
	*/
	fetchOptimistic(options) {
		const defaultedOptions = this.#client.defaultQueryOptions(options);
		const query = this.#client.getQueryCache().build(this.#client, defaultedOptions);
		let unsubscribe = () => {};
		let resolveEarly;
		const cachePromise = new Promise((resolve) => {
			resolveEarly = resolve;
			unsubscribe = this.#client.getQueryCache().subscribe((event) => {
				if (event.type === "updated" && event.query.queryHash === query.queryHash && query.state.data !== void 0) {
					unsubscribe();
					resolve(this.createResult(query, defaultedOptions));
				}
			});
		});
		return Promise.race([query.fetch(defaultedOptions).then(() => {
			const result = this.createResult(query, defaultedOptions);
			resolveEarly?.(result);
			return result;
		}).finally(() => {
			unsubscribe();
		}), cachePromise]);
	}
	/**
	* Fetches the observed query and updates the result once the fetch settles. Used by `refetch` and,
	* in `InfiniteQueryObserver`, to fetch more pages.
	* @param fetchOptions - Options for this fetch. `cancelRefetch` defaults to `true`.
	* @returns A promise that resolves with the updated result.
	*/
	fetch(fetchOptions) {
		return this.#executeFetch({
			...fetchOptions,
			cancelRefetch: fetchOptions.cancelRefetch ?? true
		}).then(() => {
			this.updateResult();
			return this.#currentResult;
		});
	}
	#executeFetch(fetchOptions) {
		this.#updateQuery();
		let promise = this.#currentQuery.fetch(this.options, fetchOptions);
		if (!fetchOptions?.throwOnError) promise = promise.catch(noop);
		return promise;
	}
	#shouldScheduleTimer(timeout) {
		return !isServer$2() && resolveQueryValue(this.options.enabled, this.#currentQuery) !== false && isValidTimeout(timeout);
	}
	#updateStaleTimeout() {
		this.#clearStaleTimeout();
		const staleTime = resolveQueryValue(this.options.staleTime, this.#currentQuery);
		if (this.#currentResult.isStale || !this.#shouldScheduleTimer(staleTime)) return;
		const timeout = timeUntilStale(this.#currentResult.dataUpdatedAt, staleTime) + 1;
		this.#staleTimeoutId = timeoutManager.setTimeout(() => {
			if (!this.#currentResult.isStale) this.updateResult();
		}, timeout);
	}
	#computeRefetchInterval() {
		return resolveQueryValue(this.options.refetchInterval, this.#currentQuery) ?? false;
	}
	#updateRefetchInterval(nextInterval) {
		this.#clearRefetchInterval();
		this.#currentRefetchInterval = nextInterval;
		if (this.#currentRefetchInterval === 0 || !this.#shouldScheduleTimer(this.#currentRefetchInterval)) return;
		this.#refetchIntervalId = timeoutManager.setInterval(() => {
			if (this.options.refetchIntervalInBackground || focusManager.isFocused()) this.#executeFetch();
		}, this.#currentRefetchInterval);
	}
	#updateTimers() {
		this.#updateStaleTimeout();
		this.#updateRefetchInterval(this.#computeRefetchInterval());
	}
	#clearStaleTimeout() {
		if (this.#staleTimeoutId !== void 0) {
			timeoutManager.clearTimeout(this.#staleTimeoutId);
			this.#staleTimeoutId = void 0;
		}
	}
	#clearRefetchInterval() {
		if (this.#refetchIntervalId !== void 0) {
			timeoutManager.clearInterval(this.#refetchIntervalId);
			this.#refetchIntervalId = void 0;
		}
	}
	/**
	* Computes the result for a query and options from the query's state, applying `select`,
	* `placeholderData`, and the derived flags. Subclasses override it to add their own fields.
	* @param query - The query to compute the result for.
	* @param options - The observer options to compute the result with.
	* @returns The computed result.
	*/
	createResult(query, options) {
		const prevQuery = this.#currentQuery;
		const prevOptions = this.options;
		const prevResult = this.#currentResult;
		const prevResultState = this.#currentResultState;
		const prevResultOptions = this.#currentResultOptions;
		const queryInitialState = query !== prevQuery ? query.state : this.#currentQueryInitialState;
		const { state } = query;
		let newState = { ...state };
		let isPlaceholderData = false;
		let data;
		if (options._optimisticResults) {
			const mounted = this.hasListeners();
			const fetchOnMount = !mounted && shouldFetchOnMount(query, options);
			const fetchOptionally = mounted && shouldFetchOptionally(query, prevQuery, options, prevOptions);
			if (fetchOnMount || fetchOptionally) newState = {
				...newState,
				...fetchState(state.data, query.options)
			};
			if (options._optimisticResults === "isRestoring") newState.fetchStatus = "idle";
		}
		let { error, errorUpdatedAt, status } = newState;
		data = newState.data;
		let skipSelect = false;
		if (options.placeholderData !== void 0 && data === void 0 && status === "pending") {
			let placeholderData;
			if (prevResult?.isPlaceholderData && options.placeholderData === prevResultOptions?.placeholderData) {
				placeholderData = prevResult.data;
				skipSelect = true;
			} else placeholderData = typeof options.placeholderData === "function" ? options.placeholderData(this.#lastQueryWithDefinedData?.state.data, this.#lastQueryWithDefinedData) : options.placeholderData;
			if (placeholderData !== void 0) {
				status = "success";
				data = replaceData(prevResult?.data, placeholderData, options);
				isPlaceholderData = true;
			}
		}
		if (options.select && data !== void 0 && !skipSelect) {
			if (prevResult && data === prevResultState?.data && options.select === this.#selectFn) data = this.#selectResult;
			else try {
				this.#selectFn = options.select;
				data = options.select(data);
				data = replaceData(prevResult?.data, data, options);
				this.#selectResult = data;
				this.#selectError = null;
			} catch (selectError) {
				this.#selectError = selectError;
			}
		} else if (data === void 0) this.#selectError = null;
		if (this.#selectError) {
			error = this.#selectError;
			data = this.#selectResult;
			errorUpdatedAt = prevResult?.error === error ? prevResult.errorUpdatedAt : Date.now();
			status = "error";
			isPlaceholderData = false;
		}
		const isFetching = newState.fetchStatus === "fetching";
		const isPending = status === "pending";
		const isError = status === "error";
		const isLoading = isPending && isFetching;
		const hasData = data !== void 0;
		return {
			status,
			fetchStatus: newState.fetchStatus,
			isPending,
			isSuccess: status === "success",
			isError,
			isInitialLoading: isLoading,
			isLoading,
			data,
			dataUpdatedAt: newState.dataUpdatedAt,
			error,
			errorUpdatedAt,
			failureCount: newState.fetchFailureCount,
			failureReason: newState.fetchFailureReason,
			errorUpdateCount: newState.errorUpdateCount,
			isFetched: query.isFetched(),
			isFetchedAfterMount: newState.dataUpdateCount > queryInitialState.dataUpdateCount || newState.errorUpdateCount > queryInitialState.errorUpdateCount,
			isFetching,
			isRefetching: isFetching && !isPending,
			isLoadingError: isError && !hasData,
			isPaused: newState.fetchStatus === "paused",
			isPlaceholderData,
			isRefetchError: isError && hasData,
			isStale: isStale(query, options),
			refetch: this.refetch,
			isEnabled: resolveQueryValue(options.enabled, query) !== false
		};
	}
	/**
	* Recomputes and stores the current result from the current query/options, notifying listeners
	* if it changed. Framework adapters call this right after subscribing to make sure no query
	* update was missed in the gap between creating the observer and subscribing to it.
	*/
	updateResult() {
		const prevResult = this.#currentResult;
		const nextResult = this.createResult(this.#currentQuery, this.options);
		this.#currentResultState = this.#currentQuery.state;
		this.#currentResultOptions = this.options;
		if (this.#currentResultState.data !== void 0) this.#lastQueryWithDefinedData = this.#currentQuery;
		if (shallowEqualObjects(nextResult, prevResult)) return;
		this.#currentResult = nextResult;
		const shouldNotifyListeners = () => {
			if (!prevResult) return true;
			const { notifyOnChangeProps } = this.options;
			const notifyOnChangePropsValue = typeof notifyOnChangeProps === "function" ? notifyOnChangeProps() : notifyOnChangeProps;
			if (notifyOnChangePropsValue === "all" || !notifyOnChangePropsValue && !this.#trackedProps.size) return true;
			if (this.options.throwOnError && this.#currentResult.error !== prevResult.error) return true;
			for (const key of notifyOnChangePropsValue ?? this.#trackedProps) if (this.#currentResult[key] !== prevResult[key]) return true;
			return false;
		};
		const notifyListeners = shouldNotifyListeners();
		notifyManager.batch(() => {
			if (notifyListeners) this.listeners.forEach((listener) => {
				listener(this.#currentResult);
			});
			this.#client.getQueryCache().notify({
				query: this.#currentQuery,
				type: "observerResultsUpdated"
			});
		});
	}
	#updateQuery() {
		const query = this.#client.getQueryCache().build(this.#client, this.options);
		if (query === this.#currentQuery) return;
		const prevQuery = this.#currentQuery;
		this.#currentQuery = query;
		this.#currentQueryInitialState = query.state;
		if (this.hasListeners()) {
			prevQuery?.removeObserver(this);
			query.addObserver(this);
		}
	}
	/**
	* Updates the observer's result when the observed query changes, and reschedules its timers if it
	* has listeners.
	* @internal
	*/
	onQueryUpdate() {
		this.updateResult();
		if (this.hasListeners()) this.#updateTimers();
	}
};
/**
* Checks whether a query has no data yet and should do its initial load when an observer mounts.
* @param query - The query to check.
* @param options - The observer options.
* @returns `true` if the query is enabled, has no data, and isn't in an error state with
* `retryOnMount: false`.
*/
function shouldLoadOnMount(query, options) {
	return resolveQueryValue(options.enabled, query) !== false && query.state.data === void 0 && !(query.state.status === "error" && resolveQueryValue(options.retryOnMount, query) === false);
}
/**
* Checks whether a query should fetch when an observer mounts: either for its initial load, or
* because it has data and `refetchOnMount` asks for a refetch.
* @param query - The query to check.
* @param options - The observer options.
* @returns `true` if the query should fetch on mount.
*/
function shouldFetchOnMount(query, options) {
	return shouldLoadOnMount(query, options) || query.state.data !== void 0 && shouldFetchOn(query, options, options.refetchOnMount);
}
/**
* Checks whether a query should fetch for a `refetchOnMount`, `refetchOnWindowFocus`, or
* `refetchOnReconnect` option.
* @param query - The query to check.
* @param options - The observer options.
* @param field - The value of the option to check.
* @returns `true` if the query is enabled, not static, and the option is `'always'`, or is not
* `false` and the query is stale.
*/
function shouldFetchOn(query, options, field) {
	if (resolveQueryValue(options.enabled, query) !== false && resolveQueryValue(options.staleTime, query) !== "static") {
		const value = resolveQueryValue(field, query);
		return value === "always" || value !== false && isStale(query, options);
	}
	return false;
}
/**
* Checks whether a query should fetch after the observer's options change.
* @param query - The query observed with the new options.
* @param prevQuery - The query observed with the previous options.
* @param options - The new observer options.
* @param prevOptions - The previous observer options.
* @returns `true` if the query changed or was disabled before, it isn't a suspense query in an
* error state, and it is stale.
*/
function shouldFetchOptionally(query, prevQuery, options, prevOptions) {
	return (query !== prevQuery || resolveQueryValue(prevOptions.enabled, query) === false) && (!options.suspense || query.state.status !== "error") && isStale(query, options);
}
/**
* Checks whether a query is stale for the given observer options.
* @param query - The query to check.
* @param options - The observer options, whose `enabled` and `staleTime` are used.
* @returns `true` if the query is enabled and its data is stale for `staleTime`.
*/
function isStale(query, options) {
	return resolveQueryValue(options.enabled, query) !== false && query.isStaleByTime(resolveQueryValue(options.staleTime, query));
}
// node_modules/@tanstack/query-core/build/modern/infiniteQueryObserver.js
/**
* An `InfiniteQueryObserver` extends `QueryObserver` to observe and switch
* between infinite queries. It augments the base `QueryObserverResult` with
* infinite-query-specific fields and methods, such as `hasNextPage` and
* `fetchNextPage`, and is the primitive that framework adapters (e.g.
* `useInfiniteQuery`) build their hooks on top of.
* @example
* ```ts
* const observer = new InfiniteQueryObserver(queryClient, {
*   queryKey: ['projects'],
*   queryFn: ({ pageParam }) => fetchProjects(pageParam),
*   initialPageParam: 0,
*   getNextPageParam: (lastPage) => lastPage.nextCursor,
* })
*
* const unsubscribe = observer.subscribe((result) => console.log(result))
* ```
*/
var InfiniteQueryObserver = class extends QueryObserver {
	constructor(client, options) {
		super(client, options);
	}
	bindMethods() {
		super.bindMethods();
		this.fetchNextPage = this.fetchNextPage.bind(this);
		this.fetchPreviousPage = this.fetchPreviousPage.bind(this);
	}
	/**
	* Updates the observer's options. Behaves the same as
	* `QueryObserver.setOptions`, additionally marking the options as
	* belonging to an infinite query before delegating to the base
	* implementation.
	* @param options - The new infinite query observer options.
	*/
	setOptions(options) {
		options._type = "infinite";
		super.setOptions(options);
	}
	/**
	* The infinite-query counterpart of {@link QueryObserver#getOptimisticResult}, marking the
	* options as an infinite query before delegating to it. Called by framework adapters (e.g.
	* `useInfiniteQuery`) ahead of subscribing, to compute the current `InfiniteQueryObserverResult`
	* synchronously.
	* @param options - The defaulted infinite query observer options to compute the result for.
	* @returns The result for the given options.
	*/
	getOptimisticResult(options) {
		options._type = "infinite";
		return super.getOptimisticResult(options);
	}
	/**
	* Fetches the next page of the infinite query and returns a promise that
	* resolves with the resulting `InfiniteQueryObserverResult`. The page
	* param used for the fetch is determined by `getNextPageParam`, which
	* receives the current pages/page params and whose result also determines
	* `hasNextPage`.
	* @param options - Set `cancelRefetch` to `false` to ignore the call while a fetch is running,
	* and `throwOnError` to `true` to reject when the fetch fails.
	* @returns A promise that resolves with the result after the next page is fetched. With
	* `cancelRefetch: false`, a running fetch is reused instead, so the next page may not be fetched.
	* @see {@link InfiniteQueryObserver#fetchPreviousPage}
	* @example
	* ```ts
	* const { hasNextPage } = observer.getCurrentResult()
	*
	* if (hasNextPage) {
	*   await observer.fetchNextPage()
	* }
	* ```
	*/
	fetchNextPage(options) {
		return this.fetch({
			...options,
			meta: { fetchMore: { direction: "forward" } }
		});
	}
	/**
	* Fetches the previous page of the infinite query and returns a promise
	* that resolves with the resulting `InfiniteQueryObserverResult`. The page
	* param used for the fetch is determined by `getPreviousPageParam`, which
	* receives the current pages/page params and whose result also determines
	* `hasPreviousPage`.
	* @param options - Set `cancelRefetch` to `false` to ignore the call while a fetch is running,
	* and `throwOnError` to `true` to reject when the fetch fails.
	* @returns A promise that resolves with the result after the previous page is fetched. With
	* `cancelRefetch: false`, a running fetch is reused instead, so the previous page may not be fetched.
	* @see {@link InfiniteQueryObserver#fetchNextPage}
	* @example
	* ```ts
	* const { hasPreviousPage } = observer.getCurrentResult()
	*
	* if (hasPreviousPage) {
	*   await observer.fetchPreviousPage()
	* }
	* ```
	*/
	fetchPreviousPage(options) {
		return this.fetch({
			...options,
			meta: { fetchMore: { direction: "backward" } }
		});
	}
	createResult(query, options) {
		const { state } = query;
		const parentResult = super.createResult(query, options);
		const { isFetching, isRefetching, isError, isRefetchError } = parentResult;
		const fetchDirection = state.fetchMeta?.fetchMore?.direction;
		const isFetchNextPageError = isError && fetchDirection === "forward";
		const isFetchingNextPage = isFetching && fetchDirection === "forward";
		const isFetchPreviousPageError = isError && fetchDirection === "backward";
		const isFetchingPreviousPage = isFetching && fetchDirection === "backward";
		return {
			...parentResult,
			fetchNextPage: this.fetchNextPage,
			fetchPreviousPage: this.fetchPreviousPage,
			hasNextPage: hasNextPage(options, state.data),
			hasPreviousPage: hasPreviousPage(options, state.data),
			isFetchNextPageError,
			isFetchingNextPage,
			isFetchPreviousPageError,
			isFetchingPreviousPage,
			isRefetchError: isRefetchError && !isFetchNextPageError && !isFetchPreviousPageError,
			isRefetching: isRefetching && !isFetchingNextPage && !isFetchingPreviousPage
		};
	}
};
// node_modules/@tanstack/query-core/build/modern/mutation.js
/**
* Represents a single mutation attempt. A `Mutation` holds the mutation's
* options, state (data/error/status), and the `MutationObserver`s currently
* subscribed to it.
*
* Instances are created and managed internally by `MutationCache`; application
* code typically interacts with mutations indirectly through `QueryClient` or
* a framework hook like `useMutation`. Direct access to a `Mutation` instance
* is possible via `mutationCache.find()`/`getAll()` for inspecting cache state.
* @example
* ```ts
* const mutationCache = queryClient.getMutationCache()
*
* const mutation = mutationCache.find({ mutationKey: ['addPost'] })
* ```
*/
var Mutation = class extends Removable {
	#client;
	#observers;
	#mutationCache;
	#retryer;
	constructor(config) {
		super();
		this.#client = config.client;
		this.mutationId = config.mutationId;
		this.#mutationCache = config.mutationCache;
		this.#observers = [];
		this.state = config.state || getDefaultState();
		this.setOptions(config.options);
		this.scheduleGc();
	}
	/**
	* Replaces the mutation's options and applies their `gcTime`.
	* @internal
	* @param options - The new mutation options.
	*/
	setOptions(options) {
		this.options = options;
		this.updateGcTime(this.options.gcTime);
	}
	/**
	* The `meta` object passed in the mutation's options, if any.
	* @returns The mutation's `meta`, or `undefined` if none was set.
	*/
	get meta() {
		return this.options.meta;
	}
	/**
	* Subscribes an observer to the mutation and stops its garbage collection.
	* @internal
	* @param observer - The observer to add. Adding an observer that is already subscribed does
	* nothing.
	*/
	addObserver(observer) {
		if (!this.#observers.includes(observer)) {
			this.#observers.push(observer);
			this.clearGcTimeout();
			this.#mutationCache.notify({
				type: "observerAdded",
				mutation: this,
				observer
			});
		}
	}
	/**
	* Unsubscribes an observer from the mutation.
	* @internal
	* @param observer - The observer to remove. Garbage collection is scheduled afterwards.
	*/
	removeObserver(observer) {
		this.#observers = this.#observers.filter((x) => x !== observer);
		this.scheduleGc();
		this.#mutationCache.notify({
			type: "observerRemoved",
			mutation: this,
			observer
		});
	}
	optionalRemove() {
		if (!this.#observers.length) {
			if (this.state.status === "pending") this.scheduleGc();
			else this.#mutationCache.remove(this);
		}
	}
	/**
	* Resumes a mutation that is currently paused or was restored from a
	* dehydrated, still-`pending` state.
	*
	* - If this mutation has an active retryer (it paused mid-attempt, e.g. due
	*   to the network mode or scope-based queuing), its retryer is resumed.
	* - Otherwise, if the mutation's status is still `pending` (e.g. it was
	*   dehydrated while an attempt was in flight and never got a retryer in
	*   this instance), `execute` is called again with the last known variables.
	* - Otherwise the mutation has already settled and this resolves immediately
	*   without running anything again.
	* @returns A promise that settles with the resumed mutation: it rejects if the mutation fails.
	* It resolves immediately if the mutation has already settled.
	* @see {@link Mutation#execute}
	* @example
	* ```ts
	* // typically driven by reconnect handling, e.g. queryClient.resumePausedMutations()
	* const mutation = mutationCache.find({ mutationKey: ['addPost'] })
	* await mutation?.continue()
	* ```
	*/
	continue() {
		return this.#retryer?.continue() ?? (this.state.status === "pending" ? this.execute(this.state.variables) : Promise.resolve());
	}
	/**
	* Runs the mutation function for the given variables through a retryer, and
	* drives the mutation's state and lifecycle callbacks through to settlement.
	*
	* If this mutation's state is already `pending` when `execute` is called
	* (i.e. it was restored, still in-flight, from a dehydrated state), the
	* `onMutate` step is skipped and a `continue` action is dispatched to
	* unpause it; otherwise a `pending` action is dispatched first, then the
	* mutation cache's `onMutate` and the mutation's own `onMutate` option are
	* awaited in that order, and the resulting context is stored.
	*
	* The mutation function is then run (subject to `retry`/`retryDelay`/
	* `networkMode`, and to the mutation cache's scope-based serialization).
	* On success, the cache's `onSuccess`/`onSettled` callbacks run before the
	* mutation's own `onSuccess`/`onSettled` options, a `success` action is
	* dispatched, and the resolved data is returned. On failure, the same
	* cache-then-option ordering is used for `onError`/`onSettled`, but each of
	* those four callbacks is individually caught so that a throwing callback
	* cannot mask the original error; an `error` action is then dispatched and
	* the original error is re-thrown.
	* @param variables - The variables passed to the `mutationFn`.
	* @returns A promise that resolves with the mutation's data, or rejects with its error.
	* @see {@link Mutation#continue}
	* @example
	* ```ts
	* // Called internally by `MutationObserver.mutate` and `Mutation.continue` —
	* // applications normally trigger mutations through those, not this method.
	* const data = await mutation.execute(variables)
	* ```
	*/
	async execute(variables) {
		const onContinue = () => {
			this.#dispatch({ type: "continue" });
		};
		const mutationFnContext = {
			client: this.#client,
			meta: this.options.meta,
			mutationKey: this.options.mutationKey
		};
		const retryer = this.#retryer = createRetryer({
			fn: () => {
				if (!this.options.mutationFn) return Promise.reject(/* @__PURE__ */ new Error("No mutationFn found"));
				return this.options.mutationFn(variables, mutationFnContext);
			},
			onFail: (failureCount, error) => {
				this.#dispatch({
					type: "failed",
					failureCount,
					error
				});
			},
			onPause: () => {
				this.#dispatch({ type: "pause" });
			},
			onContinue,
			retry: this.options.retry ?? 0,
			retryDelay: this.options.retryDelay,
			networkMode: this.options.networkMode,
			canRun: () => this.#mutationCache.canRun(this)
		});
		const restored = this.state.status === "pending";
		const isPaused = !retryer.canStart();
		try {
			if (restored) onContinue();
			else {
				this.#dispatch({
					type: "pending",
					variables,
					isPaused
				});
				if (this.#mutationCache.config.onMutate) await this.#mutationCache.config.onMutate(variables, this, mutationFnContext);
				const context = await this.options.onMutate?.(variables, mutationFnContext);
				if (context !== this.state.context) this.#dispatch({
					type: "pending",
					context,
					variables,
					isPaused
				});
			}
			if (this.state.isPaused && retryer.canStart()) onContinue();
			const data = await retryer.start();
			await this.#mutationCache.config.onSuccess?.(data, variables, this.state.context, this, mutationFnContext);
			await this.options.onSuccess?.(data, variables, this.state.context, mutationFnContext);
			await this.#mutationCache.config.onSettled?.(data, null, this.state.variables, this.state.context, this, mutationFnContext);
			await this.options.onSettled?.(data, null, variables, this.state.context, mutationFnContext);
			this.#dispatch({
				type: "success",
				data
			});
			return data;
		} catch (error) {
			try {
				await this.#mutationCache.config.onError?.(error, variables, this.state.context, this, mutationFnContext);
			} catch (e) {
				Promise.reject(e);
			}
			try {
				await this.options.onError?.(error, variables, this.state.context, mutationFnContext);
			} catch (e) {
				Promise.reject(e);
			}
			try {
				await this.#mutationCache.config.onSettled?.(void 0, error, this.state.variables, this.state.context, this, mutationFnContext);
			} catch (e) {
				Promise.reject(e);
			}
			try {
				await this.options.onSettled?.(void 0, error, variables, this.state.context, mutationFnContext);
			} catch (e) {
				Promise.reject(e);
			}
			this.#dispatch({
				type: "error",
				error
			});
			throw error;
		} finally {
			if (this.#retryer === retryer) this.#retryer = void 0;
			this.#mutationCache.runNext(this);
		}
	}
	#dispatch(action) {
		const reducer = (state) => {
			switch (action.type) {
				case "failed": return {
					...state,
					failureCount: action.failureCount,
					failureReason: action.error
				};
				case "pause": return {
					...state,
					isPaused: true
				};
				case "continue": return {
					...state,
					isPaused: false
				};
				case "pending": return {
					...state,
					context: action.context,
					data: void 0,
					failureCount: 0,
					failureReason: null,
					error: null,
					isPaused: action.isPaused,
					status: "pending",
					variables: action.variables,
					submittedAt: Date.now()
				};
				case "success": return {
					...state,
					data: action.data,
					failureCount: 0,
					failureReason: null,
					error: null,
					status: "success",
					isPaused: false
				};
				case "error": return {
					...state,
					data: void 0,
					error: action.error,
					failureCount: state.failureCount + 1,
					failureReason: action.error,
					isPaused: false,
					status: "error"
				};
			}
		};
		this.state = reducer(this.state);
		notifyManager.batch(() => {
			this.#observers.forEach((observer) => {
				observer.onMutationUpdate(action);
			});
			this.#mutationCache.notify({
				mutation: this,
				type: "updated",
				action
			});
		});
	}
};
/**
* Returns the initial state of a mutation: `'idle'`, with no data, error, or variables.
* @returns The initial mutation state.
*/
function getDefaultState() {
	return {
		context: void 0,
		data: void 0,
		error: null,
		failureCount: 0,
		failureReason: null,
		isPaused: false,
		status: "idle",
		variables: void 0,
		submittedAt: 0
	};
}
// node_modules/@tanstack/query-core/build/modern/mutationCache.js
/**
* The `MutationCache` is the storage for mutations.
*
* Normally, you will not interact with the `MutationCache` directly and instead use a
* `QueryClient`. You can subscribe to it (inherited from `Subscribable`) to be informed of
* safe/known updates to the cache, such as mutations being added, removed, or updated.
* @example
* ```ts
* const unsubscribe = mutationCache.subscribe((event) => {
*   console.log(event.type, event.mutation)
* })
* ```
*/
var MutationCache = class extends Subscribable {
	#mutations;
	#scopes;
	#mutationId;
	constructor(config = {}) {
		super();
		this.config = config;
		this.#mutations = /* @__PURE__ */ new Set();
		this.#scopes = /* @__PURE__ */ new Map();
		this.#mutationId = 0;
	}
	/**
	* Creates a mutation and adds it to the cache.
	* @internal
	* @param client - The client the mutation belongs to, used to default its options.
	* @param options - The mutation options. They are defaulted with {@link
	* QueryClient#defaultMutationOptions}.
	* @param state - The initial state of the mutation, e.g. when restoring a dehydrated mutation.
	* @returns The new mutation, already added to the cache.
	*/
	build(client, options, state) {
		const mutation = new Mutation({
			client,
			mutationCache: this,
			mutationId: ++this.#mutationId,
			options: client.defaultMutationOptions(options),
			state
		});
		this.add(mutation);
		return mutation;
	}
	/**
	* Adds a mutation to the cache.
	* @internal
	* @param mutation - The mutation to add. If it has a `scope`, it is queued in that scope.
	*/
	add(mutation) {
		this.#mutations.add(mutation);
		const scope = scopeFor(mutation);
		if (typeof scope === "string") {
			const scopedMutations = this.#scopes.get(scope);
			if (scopedMutations) scopedMutations.push(mutation);
			else this.#scopes.set(scope, [mutation]);
		}
		this.notify({
			type: "added",
			mutation
		});
	}
	/**
	* Removes a mutation from the cache.
	* @internal
	* @param mutation - The mutation to remove, also from its scope's queue.
	*/
	remove(mutation) {
		if (this.#mutations.delete(mutation)) {
			const scope = scopeFor(mutation);
			if (typeof scope === "string") {
				const scopedMutations = this.#scopes.get(scope);
				if (scopedMutations) {
					if (scopedMutations.length > 1) {
						const index = scopedMutations.indexOf(mutation);
						if (index !== -1) scopedMutations.splice(index, 1);
					} else if (scopedMutations[0] === mutation) this.#scopes.delete(scope);
				}
			}
		}
		this.notify({
			type: "removed",
			mutation
		});
	}
	/**
	* Checks whether a mutation can run now, given the other mutations in its `scope`.
	* @internal
	* @param mutation - The mutation to check.
	* @returns `true` if the mutation has no `scope`, or no other mutation in its scope is pending
	* ahead of it.
	*/
	canRun(mutation) {
		const scope = scopeFor(mutation);
		if (typeof scope === "string") {
			const firstPendingMutation = this.#scopes.get(scope)?.find((m) => m.state.status === "pending");
			return !firstPendingMutation || firstPendingMutation === mutation;
		} else return true;
	}
	/**
	* Continues the next paused mutation in the same `scope` after a mutation finishes.
	* @internal
	* @param mutation - The mutation that finished.
	* @returns A promise that resolves once the next paused mutation in the same scope has continued,
	* or immediately if there is none.
	*/
	runNext(mutation) {
		const scope = scopeFor(mutation);
		if (typeof scope === "string") return (this.#scopes.get(scope)?.find((m) => m !== mutation && m.state.isPaused))?.continue() ?? Promise.resolve();
		else return Promise.resolve();
	}
	/**
	* Removes all mutations from the cache.
	* @example
	* ```ts
	* const mutationCache = queryClient.getMutationCache()
	*
	* mutationCache.clear()
	* ```
	*/
	clear() {
		notifyManager.batch(() => {
			const mutations = this.getAll();
			this.#mutations.clear();
			this.#scopes.clear();
			mutations.forEach((mutation) => {
				this.notify({
					type: "removed",
					mutation
				});
			});
		});
	}
	/**
	* Returns all mutations within the cache.
	*
	* This is not typically needed for most applications, but can come in handy when needing more
	* information about a mutation in rare scenarios.
	* @returns Every mutation in the cache.
	* @example
	* ```ts
	* const mutationCache = queryClient.getMutationCache()
	*
	* const mutations = mutationCache.getAll()
	* ```
	*/
	getAll() {
		return Array.from(this.#mutations);
	}
	/**
	* A slightly more advanced method that can be used to get an existing mutation instance from
	* the cache. If the mutation does not exist, `undefined` is returned.
	*
	* This is not typically needed for most applications, but can come in handy when needing more
	* information about a mutation in rare scenarios.
	* @param filters - The filters to match. `exact` defaults to `true`.
	* @returns The first matching mutation, or `undefined`.
	* @see {@link MutationCache#findAll}
	* @example
	* ```ts
	* const mutationCache = queryClient.getMutationCache()
	*
	* const mutation = mutationCache.find({ mutationKey: ['addPost'] })
	* ```
	*/
	find(filters) {
		const defaultedFilters = {
			exact: true,
			...filters
		};
		return this.getAll().find((mutation) => matchMutation(defaultedFilters, mutation));
	}
	/**
	* An even more advanced method that can be used to get existing mutation instances from the
	* cache that match the given filters. If no mutations match, an empty array is returned.
	*
	* This is not typically needed for most applications, but can come in handy when needing more
	* information about mutations in rare scenarios.
	* @param filters - The filters to match. Without filters, every mutation is returned.
	* @returns The matching mutations.
	* @see {@link MutationCache#find}
	* @example
	* ```ts
	* const mutationCache = queryClient.getMutationCache()
	*
	* const mutations = mutationCache.findAll({ mutationKey: ['addPost'] })
	* ```
	*/
	findAll(filters = {}) {
		return this.getAll().filter((mutation) => matchMutation(filters, mutation));
	}
	/**
	* Notifies every cache listener of an event, in one batch.
	* @internal
	* @param event - The event passed to every listener.
	*/
	notify(event) {
		notifyManager.batch(() => {
			this.listeners.forEach((listener) => {
				listener(event);
			});
		});
	}
	/**
	* Continues every paused mutation, e.g. when the app comes back online.
	* @internal
	* @returns A promise that resolves once every paused mutation has continued and settled.
	*/
	resumePausedMutations() {
		const pausedMutations = this.getAll().filter((x) => x.state.isPaused);
		return notifyManager.batch(() => Promise.all(pausedMutations.map((mutation) => mutation.continue().catch(noop))));
	}
};
/**
* Returns the scope id of a mutation, used to run mutations with the same scope one after another.
* @param mutation - The mutation to read the scope of.
* @returns The mutation's `scope.id`, or `undefined` if it has no scope.
*/
function scopeFor(mutation) {
	return mutation.options.scope?.id;
}
// node_modules/@tanstack/query-core/build/modern/mutationObserver.js
/**
* Observes a single mutation and derives a `MutationObserverResult` from it.
* A framework hook like `useMutation` creates one `MutationObserver` per hook
* call, keeps it stable across re-renders, calls `setOptions` when the options
* passed to the hook change, subscribes to it to re-render on updates, and
* reads `getCurrentResult()` for the value to return. Calling `mutate()`
* builds a new underlying `Mutation` in the `MutationCache` and executes it.
* @example
* ```ts
* const observer = new MutationObserver(queryClient, {
*   mutationFn: (variables: { title: string }) => addPost(variables),
* })
* ```
*/
var MutationObserver = class extends Subscribable {
	#client;
	#currentResult = void 0;
	#currentMutation;
	#mutateOptions;
	constructor(client, options) {
		super();
		this.#client = client;
		this.setOptions(options);
		this.bindMethods();
		this.#updateResult();
	}
	/**
	* Binds the methods of the result (`mutate` and `reset`) to the observer, so they keep working when
	* destructured from it.
	*/
	bindMethods() {
		this.mutate = this.mutate.bind(this);
		this.reset = this.reset.bind(this);
	}
	/**
	* Updates the observer's options.
	*
	* If the new `mutationKey` differs from the previous one (and both were
	* defined), the observer is reset, detaching it from the mutation it was
	* observing. Otherwise, if the currently observed mutation is still
	* `pending`, its options are updated in place as well.
	* @param options - The new mutation observer options. They are defaulted with {@link
	* QueryClient#defaultMutationOptions} before being applied.
	* @example
	* ```ts
	* observer.setOptions({
	*   mutationFn: (variables: { title: string }) => addPost(variables),
	*   onSuccess: (data) => console.log(data),
	* })
	* ```
	*/
	setOptions(options) {
		const prevOptions = this.options;
		this.options = this.#client.defaultMutationOptions(options);
		if (!shallowEqualObjects(this.options, prevOptions)) this.#client.getMutationCache().notify({
			type: "observerOptionsUpdated",
			mutation: this.#currentMutation,
			observer: this
		});
		if (prevOptions?.mutationKey && this.options.mutationKey && hashKey(prevOptions.mutationKey) !== hashKey(this.options.mutationKey)) this.reset();
		else if (this.#currentMutation?.state.status === "pending") this.#currentMutation.setOptions(this.options);
	}
	onSubscribe() {
		if (this.listeners.size === 1 && this.#currentMutation) {
			this.#currentMutation.addObserver(this);
			this.#updateResult();
		}
	}
	onUnsubscribe() {
		if (!this.hasListeners()) this.#currentMutation?.removeObserver(this);
	}
	/**
	* Updates the observer's result when the observed mutation changes, and notifies its listeners.
	* @internal
	* @param action - The action that updated the observed mutation, passed on to the observer's
	* callbacks.
	*/
	onMutationUpdate(action) {
		this.#updateResult();
		this.#notify(action);
	}
	/**
	* Returns the observer's current result, derived from the observed
	* mutation's state (or the default, `idle` state if no mutation has been
	* built yet, e.g. before the first `mutate()` call or after `reset()`).
	* @returns The observer's latest result.
	*/
	getCurrentResult() {
		return this.#currentResult;
	}
	/**
	* Detaches the observer from the mutation it is currently observing (if
	* any) and resets the observed result back to its default, `idle` state.
	*
	* This does not cancel an in-flight mutation; the mutation itself keeps
	* running to completion and its own callbacks still fire, but this
	* observer stops reflecting its state and a subsequent `mutate()` call
	* will build a brand new mutation.
	* @see {@link MutationObserver#mutate}
	* @example
	* ```ts
	* observer.reset()
	* ```
	*/
	reset() {
		this.#currentMutation?.removeObserver(this);
		this.#currentMutation = void 0;
		this.#updateResult();
		this.#notify();
	}
	/**
	* Builds a new `Mutation` in the `MutationCache` using the observer's
	* current options, detaches this observer from any previously observed
	* mutation, attaches it to the new one, and executes it with the given
	* variables.
	*
	* The optional per-call `options` (`onSuccess`/`onError`/`onSettled`) are
	* invoked once the mutation settles, in addition to any callbacks defined
	* on the observer's own options.
	* @param variables - The variables passed to the `mutationFn`.
	* @param options - Per-call `onSuccess`, `onError`, and `onSettled` callbacks.
	* @returns A promise that resolves with the mutation's data, or rejects with its error.
	* @example
	* ```ts
	* await observer.mutate(
	*   { title: 'New post' },
	*   { onSuccess: (data) => console.log(data) },
	* )
	* ```
	*/
	mutate(variables, options) {
		this.#mutateOptions = options;
		this.#currentMutation?.removeObserver(this);
		this.#currentMutation = this.#client.getMutationCache().build(this.#client, this.options);
		this.#currentMutation.addObserver(this);
		return this.#currentMutation.execute(variables);
	}
	#updateResult() {
		const state = this.#currentMutation?.state ?? getDefaultState();
		this.#currentResult = {
			...state,
			isPending: state.status === "pending",
			isSuccess: state.status === "success",
			isError: state.status === "error",
			isIdle: state.status === "idle",
			mutate: this.mutate,
			reset: this.reset
		};
	}
	#notify(action) {
		notifyManager.batch(() => {
			const mutateOptions = this.#mutateOptions;
			if (mutateOptions && this.hasListeners()) {
				const variables = this.#currentResult.variables;
				const onMutateResult = this.#currentResult.context;
				const context = {
					client: this.#client,
					meta: this.options.meta,
					mutationKey: this.options.mutationKey
				};
				if (action?.type === "success") {
					try {
						mutateOptions.onSuccess?.(action.data, variables, onMutateResult, context);
					} catch (e) {
						Promise.reject(e);
					}
					try {
						mutateOptions.onSettled?.(action.data, null, variables, onMutateResult, context);
					} catch (e) {
						Promise.reject(e);
					}
				} else if (action?.type === "error") {
					try {
						mutateOptions.onError?.(action.error, variables, onMutateResult, context);
					} catch (e) {
						Promise.reject(e);
					}
					try {
						mutateOptions.onSettled?.(void 0, action.error, variables, onMutateResult, context);
					} catch (e) {
						Promise.reject(e);
					}
				}
			}
			this.listeners.forEach((listener) => {
				listener(this.#currentResult);
			});
		});
	}
};
// node_modules/@tanstack/query-core/build/modern/queriesObserver.js
/**
* Returns the items of `array1` that are not in `array2`.
* @param array1 - The items to filter.
* @param array2 - The items to exclude.
* @returns A new array with the items of `array1` that are not in `array2`.
*/
function difference(array1, array2) {
	const excludeSet = new Set(array2);
	return array1.filter((x) => !excludeSet.has(x));
}
/**
* A `QueriesObserver` watches an array of queries at once, exposing them as
* a single array of `QueryObserverResult`s (or, when a `combine` option is
* given, as a combined value derived from that array). It manages one
* internal `QueryObserver` per query, and is the primitive that framework
* adapters (e.g. `useQueries`) build their hooks on top of.
* @example
* ```ts
* const observer = new QueriesObserver(queryClient, [
*   { queryKey: ['post', 1], queryFn: fetchPost },
*   { queryKey: ['post', 2], queryFn: fetchPost },
* ])
*
* const unsubscribe = observer.subscribe((result) => {
*   console.log(result)
* })
* ```
*/
var QueriesObserver = class extends Subscribable {
	#client;
	#result;
	#queries;
	#options;
	#observers;
	#combinedResult;
	#lastCombine;
	#lastResult;
	#lastQueryHashes;
	#observerMatches = [];
	constructor(client, queries, options) {
		super();
		this.#client = client;
		this.#options = options;
		this.#queries = [];
		this.#observers = [];
		this.#result = [];
		this.setQueries(queries);
	}
	onSubscribe() {
		if (this.listeners.size === 1) this.#observers.forEach((observer) => {
			observer.subscribe((result) => {
				this.#onUpdate(observer, result);
			});
		});
	}
	onUnsubscribe() {
		if (!this.listeners.size) this.destroy();
	}
	/**
	* Stops observing all queries: clears all listeners and destroys every
	* underlying `QueryObserver` this observer manages.
	*/
	destroy() {
		this.listeners = /* @__PURE__ */ new Set();
		this.#observers.forEach((observer) => {
			observer.destroy();
		});
	}
	/**
	* Replaces the set of queries being observed. Existing `QueryObserver`s
	* are reused for queries that match an already-observed query hash;
	* observers for queries that are no longer present are destroyed, and new
	* observers are created and subscribed to for newly added queries.
	* @param queries - The options of the queries to observe.
	* @param options - Replaces the observer's options, e.g. its `combine` function.
	* @example
	* ```ts
	* observer.setQueries([
	*   { queryKey: ['post', 1], queryFn: fetchPost },
	*   { queryKey: ['post', 3], queryFn: fetchPost },
	* ])
	* ```
	*/
	setQueries(queries, options) {
		this.#queries = queries;
		this.#options = options;
		{
			const queryHashes = queries.map((query) => this.#client.defaultQueryOptions(query).queryHash);
			if (new Set(queryHashes).size !== queryHashes.length) console.warn("[QueriesObserver]: Duplicate Queries found. This might result in unexpected behavior.");
		}
		notifyManager.batch(() => {
			const prevObservers = this.#observers;
			const newObserverMatches = this.#findMatchingObservers(this.#queries);
			newObserverMatches.forEach((match) => match.observer.setOptions(match.defaultedQueryOptions));
			const newObservers = newObserverMatches.map((match) => match.observer);
			const newResult = newObservers.map((observer) => observer.getCurrentResult());
			const hasLengthChange = prevObservers.length !== newObservers.length;
			const hasIndexChange = newObservers.some((observer, index) => observer !== prevObservers[index]);
			const hasStructuralChange = hasLengthChange || hasIndexChange;
			const hasResultChange = hasStructuralChange ? true : newResult.some((result, index) => {
				const prev = this.#result[index];
				return !prev || !shallowEqualObjects(result, prev);
			});
			if (!hasStructuralChange && !hasResultChange) return;
			if (hasStructuralChange) {
				this.#observerMatches = newObserverMatches;
				this.#observers = newObservers;
			}
			this.#result = newResult;
			if (!this.hasListeners()) return;
			if (hasStructuralChange) {
				difference(prevObservers, newObservers).forEach((observer) => {
					observer.destroy();
				});
				difference(newObservers, prevObservers).forEach((observer) => {
					observer.subscribe((result) => {
						this.#onUpdate(observer, result);
					});
				});
			}
			this.#notify();
		});
	}
	/**
	* Returns the most recently computed array of `QueryObserverResult`s, one
	* per observed query, in the same order as the queries passed to the
	* constructor or `setQueries`.
	* @returns The current results.
	* @example
	* ```ts
	* const results = observer.getCurrentResult()
	* const data = results.map((result) => result.data)
	* ```
	*/
	getCurrentResult() {
		return this.#result;
	}
	/**
	* Returns the underlying `Query` instances currently being observed, in
	* the same order as the queries passed to the constructor or `setQueries`.
	* @returns The observed queries.
	*/
	getQueries() {
		return this.#observers.map((observer) => observer.getCurrentQuery());
	}
	/**
	* Returns the underlying `QueryObserver` instances this observer manages,
	* in the same order as the queries passed to the constructor or
	* `setQueries`.
	* @returns The managed query observers.
	*/
	getObservers() {
		return this.#observers;
	}
	/**
	* The `QueriesObserver` counterpart of {@link QueryObserver#getOptimisticResult} — computes
	* the result for the given (already-defaulted) queries right now, synchronously. Called by
	* framework adapters (e.g. `useQueries`) ahead of subscribing, returning a tuple of the raw
	* per-query results, a function to compute the combined result from them, and a function to
	* wrap the results for property-access tracking.
	* @param queries - The defaulted options of the queries to compute the result for.
	* @param combine - The `combine` function used by the returned `combineResult`, if any.
	* @returns A tuple of the per-query results, a function that computes the combined result, and a
	* function that returns the results wrapped for property-access tracking.
	*/
	getOptimisticResult(queries, combine) {
		const matches = this.#findMatchingObservers(queries);
		const result = matches.map((match) => match.observer.getOptimisticResult(match.defaultedQueryOptions));
		const queryHashes = matches.map((match) => match.defaultedQueryOptions.queryHash);
		return [
			result,
			(r) => {
				return this.#combineResult(r ?? result, combine, queryHashes);
			},
			() => {
				return this.#trackResult(result, matches);
			}
		];
	}
	#trackResult(result, matches) {
		const trackedProps = /* @__PURE__ */ new Set();
		return matches.map((match, index) => {
			const observerResult = result[index];
			return !match.defaultedQueryOptions.notifyOnChangeProps ? match.observer.trackResult(observerResult, (accessedProp) => {
				if (!trackedProps.has(accessedProp)) {
					trackedProps.add(accessedProp);
					matches.forEach((m) => {
						m.observer.trackProp(accessedProp);
					});
				}
			}) : observerResult;
		});
	}
	#combineResult(input, combine, queryHashes) {
		if (combine) {
			const lastHashes = this.#lastQueryHashes;
			const queryHashesChanged = queryHashes !== void 0 && lastHashes !== void 0 && (lastHashes.length !== queryHashes.length || queryHashes.some((hash, i) => hash !== lastHashes[i]));
			if (this.#result !== this.#lastResult || queryHashesChanged || combine !== this.#lastCombine) {
				this.#lastCombine = combine;
				this.#lastResult = this.#result;
				if (queryHashes !== void 0) this.#lastQueryHashes = queryHashes;
				this.#combinedResult = replaceEqualDeep(this.#combinedResult, combine(input));
			}
			return this.#combinedResult;
		}
		return input;
	}
	#shouldSkipCombine() {
		return !this.#options?.combine || this.#observers.some((observer, index) => {
			return observer.options.suspense && this.#result[index]?.data === void 0;
		});
	}
	#findMatchingObservers(queries) {
		const prevObserversMap = /* @__PURE__ */ new Map();
		this.#observers.forEach((observer) => {
			const key = observer.options.queryHash;
			if (!key) return;
			const previousObservers = prevObserversMap.get(key);
			if (previousObservers) previousObservers.push(observer);
			else prevObserversMap.set(key, [observer]);
		});
		const observers = [];
		queries.forEach((options) => {
			const defaultedOptions = this.#client.defaultQueryOptions(options);
			const observer = prevObserversMap.get(defaultedOptions.queryHash)?.shift() ?? new QueryObserver(this.#client, defaultedOptions);
			observers.push({
				defaultedQueryOptions: defaultedOptions,
				observer
			});
		});
		return observers;
	}
	#onUpdate(observer, result) {
		const index = this.#observers.indexOf(observer);
		if (index !== -1) {
			this.#result = this.#result.slice();
			this.#result[index] = result;
			this.#notify();
		}
	}
	#notify() {
		if (this.hasListeners()) {
			const shouldSkipCombine = this.#shouldSkipCombine();
			const previousResult = this.#combinedResult;
			const newResult = shouldSkipCombine ? previousResult : this.#combineResult(this.#trackResult(this.#result, this.#observerMatches), this.#options?.combine);
			if (shouldSkipCombine || previousResult !== newResult) notifyManager.batch(() => {
				this.listeners.forEach((listener) => {
					listener(this.#result);
				});
			});
		}
	}
};
// node_modules/@tanstack/query-core/build/modern/queryCache.js
/**
* The `QueryCache` is the storage mechanism for TanStack Query. It stores all the data, meta
* information, and state of the queries it contains.
*
* Normally, you will not interact with the `QueryCache` directly and instead use a `QueryClient`
* for a specific cache. You can subscribe to it (inherited from `Subscribable`) to be informed of
* safe/known updates to the cache, such as queries being added, removed, or updated — updates made
* outside of the cache's own tracked mechanisms (e.g. mutating a query's state object directly) do
* not notify subscribers.
* @example
* ```ts
* const unsubscribe = queryCache.subscribe((event) => {
*   console.log(event.type, event.query)
* })
* ```
*/
var QueryCache = class extends Subscribable {
	#queries;
	constructor(config = {}) {
		super();
		this.config = config;
		this.#queries = /* @__PURE__ */ new Map();
	}
	/**
	* Returns the existing `Query` instance for the given options' `queryKey`/`queryHash`, or
	* builds and adds a new one to the cache if none exists yet. Used by framework adapters and
	* plugins (e.g. broadcast/persistence) that need to get-or-create a `Query` directly, bypassing
	* the reactive `QueryObserver` machinery.
	* @param client - The client the query belongs to, used to default its options.
	* @param options - The query options, including the `queryKey`. A new query is created with the
	* options defaulted by {@link QueryClient#defaultQueryOptions}.
	* @param state - The initial state of a newly created query, e.g. when hydrating. Ignored if the
	* query already exists.
	* @returns The existing or newly created query.
	* @example
	* ```ts
	* const queryCache = queryClient.getQueryCache()
	*
	* const query = queryCache.build(queryClient, {
	*   queryKey: ['posts'],
	*   queryFn: fetchPosts,
	* })
	* ```
	*/
	build(client, options, state) {
		const queryKey = options.queryKey;
		const queryHash = options.queryHash ?? hashQueryKeyByOptions(queryKey, options);
		let query = this.get(queryHash);
		if (!query) {
			query = new Query({
				client,
				queryKey,
				queryHash,
				options: client.defaultQueryOptions(options),
				state,
				defaultOptions: client.getQueryDefaults(queryKey)
			});
			this.add(query);
		}
		return query;
	}
	/**
	* Adds a query to the cache.
	* @internal
	* @param query - The query to add. If a query with the same hash is already cached, nothing
	* happens.
	*/
	add(query) {
		if (!this.#queries.has(query.queryHash)) {
			this.#queries.set(query.queryHash, query);
			this.notify({
				type: "added",
				query
			});
		}
	}
	/**
	* Destroys the given `Query` and removes it from the cache, notifying subscribers with a
	* `'removed'` event. A no-op if the query is no longer the one currently stored under its hash
	* (e.g. it was already replaced). Used by plugins (e.g. the broadcast client) that mirror
	* removals across `QueryCache` instances.
	* @param query - The query to remove.
	* @example
	* ```ts
	* const queryCache = queryClient.getQueryCache()
	* const query = queryCache.find({ queryKey: ['posts'] })
	*
	* if (query) {
	*   queryCache.remove(query)
	* }
	* ```
	*/
	remove(query) {
		if (this.#queries.get(query.queryHash) === query) {
			query.destroy();
			this.#queries.delete(query.queryHash);
			this.notify({
				type: "removed",
				query
			});
		}
	}
	/**
	* Removes all queries from the cache.
	* @example
	* ```ts
	* const queryCache = queryClient.getQueryCache()
	*
	* queryCache.clear()
	* ```
	*/
	clear() {
		notifyManager.batch(() => {
			this.getAll().forEach((query) => {
				this.remove(query);
			});
		});
	}
	/**
	* Returns the `Query` instance stored under the given `queryHash`, or `undefined` if none
	* exists. Unlike {@link QueryCache#find}, this looks up by the already-computed hash rather
	* than by `QueryFilters`. Used by plugins (e.g. broadcast/hydration) that already have a hash
	* to look up directly.
	* @param queryHash - The hash of the query to look up.
	* @returns The query stored under the hash, or `undefined`.
	* @example
	* ```ts
	* const queryCache = queryClient.getQueryCache()
	* const queryHash = hashKey(['posts'])
	*
	* const query = queryCache.get(queryHash)
	* ```
	*/
	get(queryHash) {
		return this.#queries.get(queryHash);
	}
	/**
	* Returns all queries within the cache.
	* @returns Every query in the cache.
	* @example
	* ```ts
	* const queryCache = queryClient.getQueryCache()
	*
	* const queries = queryCache.getAll()
	* ```
	*/
	getAll() {
		return [...this.#queries.values()];
	}
	/**
	* A slightly more advanced method that can be used to get an existing query instance from the
	* cache. This instance not only contains all the state for the query, but all of the instances,
	* and underlying guts of the query as well. If the query does not exist, `undefined` is
	* returned.
	*
	* This is not typically needed for most applications, but can come in handy when needing more
	* information about a query in rare scenarios (e.g. looking at `query.state.dataUpdatedAt` to
	* decide whether a query is fresh enough to be used as an initial value).
	* @param filters - The filters to match, including the required `queryKey`. `exact` defaults to
	* `true`.
	* @returns The first matching query, or `undefined`.
	* @see {@link QueryCache#findAll}
	* @example
	* ```ts
	* const queryCache = queryClient.getQueryCache()
	*
	* const query = queryCache.find({ queryKey: ['posts'] })
	* ```
	*/
	find(filters) {
		const defaultedFilters = {
			exact: true,
			...filters
		};
		return this.getAll().find((query) => matchQuery(defaultedFilters, query));
	}
	/**
	* An even more advanced method that can be used to get existing query instances from the cache
	* that partially match a query key. If no queries match, an empty array is returned.
	*
	* This is not typically needed for most applications, but can come in handy when needing more
	* information about queries in rare scenarios.
	* @param filters - The filters to match. Without filters, every query is returned.
	* @returns The matching queries.
	* @see {@link QueryCache#find}
	* @example
	* ```ts
	* const queryCache = queryClient.getQueryCache()
	*
	* const queries = queryCache.findAll({ queryKey: ['posts'] })
	* ```
	*/
	findAll(filters = {}) {
		const queries = this.getAll();
		return Object.keys(filters).length > 0 ? queries.filter((query) => matchQuery(filters, query)) : queries;
	}
	/**
	* Notifies every cache listener of an event, in one batch.
	* @internal
	* @param event - The event passed to every listener.
	*/
	notify(event) {
		notifyManager.batch(() => {
			this.listeners.forEach((listener) => {
				listener(event);
			});
		});
	}
	/**
	* Calls {@link Query#onFocus} on every cached query, in one batch.
	* @internal
	*/
	onFocus() {
		notifyManager.batch(() => {
			this.getAll().forEach((query) => {
				query.onFocus();
			});
		});
	}
	/**
	* Calls {@link Query#onOnline} on every cached query, in one batch.
	* @internal
	*/
	onOnline() {
		notifyManager.batch(() => {
			this.getAll().forEach((query) => {
				query.onOnline();
			});
		});
	}
};
// node_modules/@tanstack/query-core/build/modern/queryClient.js
/**
* `QueryClient` is used to interact with a cache of queries and mutations. It owns a
* `QueryCache` and a `MutationCache` (creating default ones if none are passed in) and holds
* the default options that are applied to queries and mutations created through it.
* @example
* ```ts
* const queryClient = new QueryClient({
*   defaultOptions: {
*     queries: {
*       staleTime: Infinity,
*     },
*   },
* })
*
* await queryClient.query({ queryKey: ['posts'], queryFn: fetchPosts })
* ```
*/
var QueryClient = class {
	#queryCache;
	#mutationCache;
	#defaultOptions;
	#queryDefaults;
	#mutationDefaults;
	#mountCount;
	#unsubscribeFocus;
	#unsubscribeOnline;
	constructor(config = {}) {
		this.#queryCache = config.queryCache || new QueryCache();
		this.#mutationCache = config.mutationCache || new MutationCache();
		this.#defaultOptions = config.defaultOptions || {};
		this.#queryDefaults = /* @__PURE__ */ new Map();
		this.#mutationDefaults = /* @__PURE__ */ new Map();
		this.#mountCount = 0;
	}
	/**
	* Called by a framework adapter's `QueryClientProvider`-equivalent when it mounts, to start
	* listening for focus/online events and resume paused mutations. Ref-counted via an internal
	* mount count, so nested or multiple providers sharing the same `QueryClient` don't tear down
	* the shared listeners until the last one unmounts.
	*/
	mount() {
		this.#mountCount++;
		if (this.#mountCount !== 1) return;
		this.#unsubscribeFocus = focusManager.subscribe(async (focused) => {
			if (focused) {
				await this.resumePausedMutations();
				this.#queryCache.onFocus();
			}
		});
		this.#unsubscribeOnline = onlineManager.subscribe(async (online) => {
			if (online) {
				await this.resumePausedMutations();
				this.#queryCache.onOnline();
			}
		});
	}
	/**
	* The inverse of {@link QueryClient#mount} — called by a framework adapter's
	* `QueryClientProvider`-equivalent when it unmounts. Only tears down the focus/online
	* listeners once the mount count returns to `0`.
	*/
	unmount() {
		this.#mountCount--;
		if (this.#mountCount !== 0) return;
		this.#unsubscribeFocus?.();
		this.#unsubscribeFocus = void 0;
		this.#unsubscribeOnline?.();
		this.#unsubscribeOnline = void 0;
	}
	/**
	* Returns the number of queries in the cache that are currently fetching, optionally
	* matching a set of filters. This includes background-fetching, loading new pages, and
	* loading more infinite query results.
	* @param filters - Narrows down which fetching queries are counted. Without filters, every
	* fetching query is counted.
	* @returns The number of matching queries whose `fetchStatus` is `'fetching'`.
	* @example
	* ```ts
	* if (queryClient.isFetching()) {
	*   console.log('At least one query is fetching!')
	* }
	* ```
	*/
	isFetching(filters) {
		return this.#queryCache.findAll({
			...filters,
			fetchStatus: "fetching"
		}).length;
	}
	/**
	* Returns the number of mutations in the cache that are currently pending, optionally
	* matching a set of filters.
	* @param filters - Narrows down which pending mutations are counted. Without filters, every
	* pending mutation is counted.
	* @returns The number of matching mutations whose `status` is `'pending'`.
	* @example
	* ```ts
	* if (queryClient.isMutating()) {
	*   console.log('At least one mutation is pending!')
	* }
	* ```
	*/
	isMutating(filters) {
		return this.#mutationCache.findAll({
			...filters,
			status: "pending"
		}).length;
	}
	/**
	* Imperative (non-reactive) way to retrieve data for a QueryKey.
	* Should only be used in callbacks or functions where reading the latest data is necessary, e.g. for optimistic updates.
	*
	* Hint: Do not use this function inside a component, because it won't receive updates.
	* Use `useQuery` to create a `QueryObserver` that subscribes to changes.
	* @param queryKey - The query key of the query to read.
	* @returns The cached data for the query, or `undefined` if no query with this key has been observed yet.
	* @see {@link QueryClient#getQueriesData}
	*/
	getQueryData(queryKey) {
		const options = this.defaultQueryOptions({ queryKey });
		return this.#queryCache.get(options.queryHash)?.state.data;
	}
	/**
	* Returns the cached data of a query, or fetches it if there is none. With `revalidateIfStale`,
	* stale cached data is also refetched in the background.
	* @param options - The query options. If the query has no cached data yet, it is fetched with
	* these options.
	* @returns A promise that resolves to the cached data, or to the fetched data if nothing was
	* cached yet.
	* @deprecated Use queryClient.query({ ...options, staleTime: 'static' }) instead. This method will be removed in the next major version.
	*/
	ensureQueryData(options) {
		const defaultedOptions = this.defaultQueryOptions(options);
		const query = this.#queryCache.build(this, defaultedOptions);
		const cachedData = query.state.data;
		if (cachedData === void 0) return this.fetchQuery(options);
		if (options.revalidateIfStale && query.isStaleByTime(resolveQueryValue(defaultedOptions.staleTime, query))) this.prefetchQuery(defaultedOptions);
		return Promise.resolve(cachedData);
	}
	/**
	* Imperative (non-reactive) way to retrieve the cached data of multiple queries at once.
	* Only queries matching the given filters are returned; if none match, an empty array is
	* returned.
	*
	* Because the matched queries can hold data of different shapes (e.g. a broad filter can match
	* queries with unrelated data types), the `TQueryFnData` generic defaults to `unknown` rather
	* than being inferred. Passing a more specific type is a convenience for call sites that know
	* every matched query holds the same shape — it is not checked against the actual cache
	* contents.
	* @param filters - The filters that select which queries to read.
	* @returns An array of query key and data pairs. The data is `undefined` for a query with no cached data.
	* @see {@link QueryClient#getQueryData}
	* @example
	* ```ts
	* const data = queryClient.getQueriesData({ queryKey: ['posts'] })
	* ```
	*/
	getQueriesData(filters) {
		return this.#queryCache.findAll(filters).map(({ queryKey, state }) => {
			return [queryKey, state.data];
		});
	}
	/**
	* Synchronous way to immediately update a query's cached data. If the updater (or the value
	* passed) resolves to `undefined`, the cache is left untouched and no query is created;
	* otherwise, if the query does not exist yet, it will be created. To update multiple queries
	* at once by partially matching query keys, use {@link QueryClient#setQueriesData} instead.
	*
	* Updates must be performed immutably: do not mutate `oldData`, or data previously retrieved
	* via {@link QueryClient#getQueryData}, in place.
	* @param queryKey - The query key to set data for.
	* @param updater - Either the new data, or a function that receives the current data (which
	* may be `undefined`) and returns the new data.
	* @param options - Set `updatedAt` to override the timestamp the written data is recorded with.
	* @returns The data that was written, or `undefined` if the updater returned `undefined` — in that case
	* the write is skipped and the cache is left unchanged.
	* @example
	* ```ts
	* queryClient.setQueryData(['posts'], newPosts)
	*
	* // Or, using an updater function that receives the current data:
	* queryClient.setQueryData(['posts'], (oldPosts) => [...oldPosts, newPost])
	* ```
	*/
	setQueryData(queryKey, updater, options) {
		const defaultedOptions = this.defaultQueryOptions({ queryKey });
		const prevData = this.#queryCache.get(defaultedOptions.queryHash)?.state.data;
		const data = functionalUpdate(updater, prevData);
		if (data === void 0) return;
		return this.#queryCache.build(this, defaultedOptions).setData(data, {
			...options,
			manual: true
		});
	}
	/**
	* Synchronous way to immediately update the cached data of multiple queries at once, using
	* filters or partial query key matching. Only queries that already exist and match the given
	* filters are updated; no new cache entries are created. Internally this calls
	* {@link QueryClient#setQueryData} for each matching query.
	* @param filters - The filters that select which existing queries to update.
	* @param updater - Either the new data, or a function that receives each matched query's current
	* data (which may be `undefined`) and returns the new data.
	* @param options - Set `updatedAt` to override the timestamp the written data is recorded with.
	* @returns One `[queryKey, data]` tuple per matched query, in the same shape and with the same
	* `undefined` case as {@link QueryClient#setQueryData}.
	* @example
	* ```ts
	* queryClient.setQueriesData({ queryKey: ['posts'] }, (oldPosts) =>
	*   oldPosts ? oldPosts.filter((post) => post.id !== deletedId) : oldPosts,
	* )
	* ```
	*/
	setQueriesData(filters, updater, options) {
		return notifyManager.batch(() => this.#queryCache.findAll(filters).map(({ queryKey }) => [queryKey, this.setQueryData(queryKey, updater, options)]));
	}
	/**
	* Imperative (non-reactive) way to retrieve an existing query's state. If the query does not
	* exist, `undefined` is returned.
	* @param queryKey - The query key of the query to read.
	* @returns The query's state, or `undefined` if no query with this key exists.
	* @example
	* ```ts
	* const state = queryClient.getQueryState(['posts'])
	* console.log(state?.dataUpdatedAt)
	* ```
	*/
	getQueryState(queryKey) {
		const options = this.defaultQueryOptions({ queryKey });
		return this.#queryCache.get(options.queryHash)?.state;
	}
	/**
	* Removes queries from the cache that match the given filters. Unlike
	* {@link QueryClient#invalidateQueries} or {@link QueryClient#refetchQueries}, this removes
	* matching queries from the cache instead of refetching them. Without filters, every query in
	* the cache is removed.
	* @param filters - The filters that select which queries to remove. Without filters, every query
	* is removed.
	* @example
	* ```ts
	* queryClient.removeQueries({ queryKey: ['posts'], exact: true })
	* ```
	*/
	removeQueries(filters) {
		const queryCache = this.#queryCache;
		notifyManager.batch(() => {
			queryCache.findAll(filters).forEach((query) => {
				queryCache.remove(query);
			});
		});
	}
	/**
	* Resets queries matching the given filters back to their initial state (e.g. any
	* `initialData`), notifying subscribers rather than removing them. Active queries among the
	* matched set are then refetched, and the returned promise resolves once that refetch settles.
	* @param filters - The filters that select which queries to reset. Without filters, every query
	* is reset.
	* @param options - Passed to the refetch of the active matched queries, e.g. `cancelRefetch` and
	* `throwOnError`.
	* @returns A promise that resolves once the refetch of the active matched queries settles.
	* @example
	* ```ts
	* await queryClient.resetQueries({ queryKey: ['posts'], exact: true })
	* ```
	*/
	resetQueries(filters, options) {
		const queryCache = this.#queryCache;
		return notifyManager.batch(() => {
			const matched = queryCache.findAll(filters);
			const queriesToRefetch = new Set(matched);
			matched.forEach((query) => {
				query.reset();
			});
			return this.refetchQueries({
				type: "active",
				predicate: (query) => queriesToRefetch.has(query)
			}, options);
		});
	}
	/**
	* Cancels outgoing fetches for queries matching the given filters. Most useful when performing
	* optimistic updates, since any outgoing refetch that resolves afterwards would otherwise
	* overwrite the optimistic update. By default (`revert: true`), a cancelled query's data is
	* reverted to its state before the outgoing fetch started.
	*
	* The returned promise never rejects, even if individual cancellations fail.
	* @param filters - The filters that select which queries to cancel. Without filters, every query
	* is cancelled.
	* @param cancelOptions - Passed to each matched query's cancellation. `revert` defaults to
	* `true`.
	* @returns A promise that resolves once every cancellation has settled.
	* @example
	* ```ts
	* await queryClient.cancelQueries({ queryKey: ['posts'], exact: true })
	* ```
	*/
	cancelQueries(filters, cancelOptions = {}) {
		const defaultedCancelOptions = {
			revert: true,
			...cancelOptions
		};
		const promises = notifyManager.batch(() => this.#queryCache.findAll(filters).map((query) => query.cancel(defaultedCancelOptions)));
		return Promise.all(promises).then(noop).catch(noop);
	}
	/**
	* Marks queries matching the given filters as invalidated. Unlike
	* {@link QueryClient#removeQueries}, invalidated queries stay in the cache.
	*
	* Unless `filters.refetchType` is `'none'`, matching queries are then refetched via
	* {@link QueryClient#refetchQueries}, using `filters.refetchType` if set, otherwise
	* `filters.type`, otherwise `'active'`.
	* @param filters - The filters that select which queries to invalidate, plus `refetchType` to
	* control which of them to refetch afterwards. Without filters, every query is invalidated.
	* @param options - Passed to {@link QueryClient#refetchQueries}, e.g. `cancelRefetch` and
	* `throwOnError`.
	* @returns A promise that resolves once the refetch settles, or immediately if `refetchType` is
	* `'none'`.
	* @example
	* ```ts
	* await queryClient.invalidateQueries({ queryKey: ['posts'], refetchType: 'active' })
	* ```
	*/
	invalidateQueries(filters, options = {}) {
		return notifyManager.batch(() => {
			this.#queryCache.findAll(filters).forEach((query) => {
				query.invalidate();
			});
			if (filters?.refetchType === "none") return Promise.resolve();
			return this.refetchQueries({
				...filters,
				type: filters?.refetchType ?? filters?.type ?? "active"
			}, options);
		});
	}
	/**
	* Refetches queries matching the given filters, regardless of whether they are stale. Without
	* filters, every query in the cache is refetched. Queries that are disabled, or static (only
	* have observers with a static `staleTime`), are never refetched.
	*
	* By default (`cancelRefetch: true`), a currently running fetch is cancelled before the new
	* one starts. The returned promise does not reject on individual query failures unless
	* `throwOnError` is `true`.
	*
	* Initially paused fetches do not delay the returned promise. Their later errors are handled
	* even when `throwOnError` is `true`.
	* @param filters - The filters that select which queries to refetch. Without filters, every query
	* in the cache is included.
	* @param options - Set `cancelRefetch` to `false` to keep a running fetch instead of cancelling
	* it, and `throwOnError` to `true` to reject when a refetch that was not initially paused fails.
	* @returns A promise that resolves once all matching refetches that were not initially paused
	* have settled.
	* @example
	* ```ts
	* // refetch all active queries partially matching a query key:
	* await queryClient.refetchQueries({ queryKey: ['posts'], type: 'active' })
	* ```
	*/
	refetchQueries(filters, options = {}) {
		const fetchOptions = {
			...options,
			cancelRefetch: options.cancelRefetch ?? true
		};
		const promises = notifyManager.batch(() => this.#queryCache.findAll(filters).filter((query) => !query.isDisabled() && !query.isStatic()).map((query) => {
			let promise = query.fetch(void 0, fetchOptions);
			const isPaused = query.state.fetchStatus === "paused";
			if (!fetchOptions.throwOnError || isPaused) promise = promise.catch(noop);
			return isPaused ? Promise.resolve() : promise;
		}));
		return Promise.all(promises).then(noop);
	}
	/**
	* Asynchronous method to fetch and cache a query, resolving with the data or throwing with
	* the error.
	*
	* If the query already exists in the cache and its data is not stale (per the given
	* `staleTime`), the cached data is returned without fetching. Otherwise, the query is fetched
	* and the promise resolves once the fetch settles. If a `select` function is provided, it is
	* applied to the data in both cases (cached or freshly fetched) before it is returned.
	*
	* Unlike a reactive observer, retries are disabled by default here (`retry: false`) unless
	* explicitly configured, since there is no component to catch a thrown error and retry through
	* re-render.
	*
	* The accepted options are `QueryObserverOptions` minus the fields that only make sense for a
	* reactive observer — `enabled`, `refetchInterval`, `refetchIntervalInBackground`,
	* `refetchOnWindowFocus`, `refetchOnReconnect`, `refetchOnMount`, `retryOnMount`,
	* `notifyOnChangeProps`, `throwOnError`, `suspense`, and `placeholderData` are not part of this
	* method's options.
	*
	* This method replaces the deprecated `fetchQuery`, and — combined with
	* `{ staleTime: 'static' }` — the deprecated `ensureQueryData`.
	* @param options - The query options, including the `queryKey` and the `queryFn` used if the
	* query needs to fetch.
	* @returns A promise that resolves to the data, or to the result of `select` if provided. It
	* rejects with the error from the fetch or from `select`.
	* @example
	* ```ts
	* try {
	*   const data = await queryClient.query({ queryKey, queryFn, staleTime: 10000 })
	* } catch (error) {
	*   console.log(error)
	* }
	* ```
	*/
	async query(options) {
		const defaultedOptions = this.defaultQueryOptions(options);
		if (defaultedOptions.retry === void 0) defaultedOptions.retry = false;
		const query = this.#queryCache.build(this, defaultedOptions);
		const queryData = query.isStaleByTime(resolveQueryValue(defaultedOptions.staleTime, query)) ? await query.fetch(defaultedOptions) : query.state.data;
		const select = defaultedOptions.select;
		if (select) return select(queryData);
		return queryData;
	}
	/**
	* Fetches and caches a query, or returns its cached data if it isn't stale. Unlike in observers,
	* the fetch isn't retried unless `retry` is set.
	* @param options - The query options, including the `queryKey` and the `queryFn` used if the
	* query needs to fetch.
	* @returns A promise that resolves to the cached or fetched data, or rejects with the fetch
	* error.
	* @deprecated Use queryClient.query(options) instead. This method will be removed in the next major version.
	*/
	fetchQuery(options) {
		const defaultedOptions = this.defaultQueryOptions(options);
		if (defaultedOptions.retry === void 0) defaultedOptions.retry = false;
		const query = this.#queryCache.build(this, defaultedOptions);
		return query.isStaleByTime(resolveQueryValue(defaultedOptions.staleTime, query)) ? query.fetch(defaultedOptions) : Promise.resolve(query.state.data);
	}
	/**
	* Fetches and caches a query like {@link QueryClient#fetchQuery}, but ignores the result and any
	* error.
	* @param options - The query options, including the `queryKey` and the `queryFn` used if the
	* query needs to fetch.
	* @returns A promise that resolves once the fetch settles. It never rejects.
	* @deprecated Use queryClient.query(options) instead. You can swallow errors with `.catch(noop)`. This method will be removed in the next major version.
	*/
	prefetchQuery(options) {
		return this.fetchQuery(options).then(noop).catch(noop);
	}
	/**
	* Asynchronous method to fetch and cache an infinite query, resolving with an
	* {@link InfiniteData} object or throwing with the error.
	*
	* Behaves like {@link QueryClient#query}, accepting the same options (minus
	* `initialPageParam`), plus the required `initialPageParam`, and an optional `pages` /
	* `getNextPageParam` pair used to refetch a fixed number of pages from the start.
	*
	* This method replaces the deprecated `fetchInfiniteQuery`, and — combined with
	* `{ staleTime: 'static' }` — the deprecated `ensureInfiniteQueryData`.
	* @param options - The infinite query options, including the `queryKey`, the `queryFn`, and the
	* `initialPageParam`.
	* @returns A promise that resolves to the {@link InfiniteData}, or to the result of `select` if
	* provided. It rejects with the error from the fetch or from `select`.
	* @example
	* ```ts
	* try {
	*   const data = await queryClient.infiniteQuery({ queryKey, queryFn, initialPageParam: 0 })
	*   console.log(data.pages)
	* } catch (error) {
	*   console.log(error)
	* }
	* ```
	*/
	infiniteQuery(options) {
		options._type = "infinite";
		return this.query(options);
	}
	/**
	* Fetches and caches an infinite query, or returns its cached data if it isn't stale.
	* @param options - The infinite query options, including the `queryKey`, the `queryFn`, and the
	* `initialPageParam`.
	* @returns A promise that resolves to the cached or fetched {@link InfiniteData}, or rejects with
	* the fetch error.
	* @deprecated Use queryClient.infiniteQuery(options) instead. This method will be removed in the next major version.
	*/
	fetchInfiniteQuery(options) {
		options._type = "infinite";
		return this.fetchQuery(options);
	}
	/**
	* Fetches and caches an infinite query like {@link QueryClient#fetchInfiniteQuery}, but ignores
	* the result and any error.
	* @param options - The infinite query options, including the `queryKey`, the `queryFn`, and the
	* `initialPageParam`.
	* @returns A promise that resolves once the fetch settles. It never rejects.
	* @deprecated Use queryClient.infiniteQuery(options) instead. You can swallow errors with `.catch(noop)`. This method will be removed in the next major version.
	*/
	prefetchInfiniteQuery(options) {
		return this.fetchInfiniteQuery(options).then(noop).catch(noop);
	}
	/**
	* Returns the cached data of an infinite query, or fetches it if there is none. With
	* `revalidateIfStale`, stale cached data is also refetched in the background.
	* @param options - The infinite query options. If the query has no cached data yet, it is fetched
	* with these options.
	* @returns A promise that resolves to the cached {@link InfiniteData}, or to the fetched data if
	* nothing was cached yet.
	* @deprecated Use queryClient.infiniteQuery({ ...options, staleTime: 'static' }) instead. This method will be removed in the next major version.
	*/
	ensureInfiniteQueryData(options) {
		options._type = "infinite";
		return this.ensureQueryData(options);
	}
	/**
	* Resumes mutations that were paused because there was no network connection. Does nothing
	* (resolving immediately) if the client is currently offline.
	* @returns A promise that resolves once the resumed mutations have settled.
	* @example
	* ```ts
	* import { QueryClient } from '@tanstack/query-core'
	*
	* const queryClient = new QueryClient()
	* await queryClient.resumePausedMutations()
	* ```
	*/
	resumePausedMutations() {
		if (onlineManager.isOnline()) return this.#mutationCache.resumePausedMutations();
		return Promise.resolve();
	}
	/**
	* Returns the query cache this client is connected to.
	* @returns The {@link QueryCache} instance.
	* @example
	* ```ts
	* import { QueryClient } from '@tanstack/query-core'
	*
	* const queryClient = new QueryClient()
	* const queryCache = queryClient.getQueryCache()
	* const queries = queryCache.findAll({ queryKey: ['posts'] })
	* ```
	*/
	getQueryCache() {
		return this.#queryCache;
	}
	/**
	* Returns the mutation cache this client is connected to.
	* @returns The {@link MutationCache} instance.
	* @example
	* ```ts
	* import { QueryClient } from '@tanstack/query-core'
	*
	* const queryClient = new QueryClient()
	* const mutationCache = queryClient.getMutationCache()
	* const mutations = mutationCache.findAll({ status: 'pending' })
	* ```
	*/
	getMutationCache() {
		return this.#mutationCache;
	}
	/**
	* Returns the default options that were set when creating the client, or via
	* {@link QueryClient#setDefaultOptions}.
	* @returns The client's current default options.
	* @example
	* ```ts
	* import { QueryClient } from '@tanstack/query-core'
	*
	* const queryClient = new QueryClient()
	* const defaultOptions = queryClient.getDefaultOptions()
	* ```
	*/
	getDefaultOptions() {
		return this.#defaultOptions;
	}
	/**
	* Dynamically sets the default options for this client, overwriting any previously defined
	* default options.
	* @param options - The new default options for queries and mutations.
	* @see {@link QueryClient#getDefaultOptions}
	* @example
	* ```ts
	* import { QueryClient } from '@tanstack/query-core'
	*
	* const queryClient = new QueryClient()
	* queryClient.setDefaultOptions({
	*   queries: {
	*     staleTime: Infinity,
	*   },
	* })
	* ```
	*/
	setDefaultOptions(options) {
		this.#defaultOptions = options;
	}
	/**
	* Sets default options for queries whose query key partially matches the given `queryKey`.
	*
	* If several registered query defaults match a given query key, they are merged together in
	* registration order by {@link QueryClient#getQueryDefaults}, so register defaults from the
	* most generic key to the least generic one — more specific defaults should be registered
	* after more generic ones so they take precedence.
	* @param queryKey - The query key that query keys are partially matched against.
	* @param options - The default options applied to matching queries.
	* @example
	* ```ts
	* queryClient.setQueryDefaults(['posts'], { queryFn: fetchPosts })
	*
	* await queryClient.query({ queryKey: ['posts'] })
	* ```
	*/
	setQueryDefaults(queryKey, options) {
		this.#queryDefaults.set(hashKey(queryKey), {
			queryKey,
			defaultOptions: options
		});
	}
	/**
	* Returns the default options registered for queries whose query key partially matches the
	* given `queryKey`, via {@link QueryClient#setQueryDefaults}. If multiple registered defaults
	* match, they are merged together in registration order.
	* @param queryKey - The query key to look up registered defaults for.
	* @returns The merged default options of every registration that matches, or an empty object if
	* none match.
	* @example
	* ```ts
	* const defaultOptions = queryClient.getQueryDefaults(['posts'])
	* ```
	*/
	getQueryDefaults(queryKey) {
		const defaults = [...this.#queryDefaults.values()];
		const result = {};
		defaults.forEach((queryDefault) => {
			if (partialMatchKey(queryKey, queryDefault.queryKey)) Object.assign(result, queryDefault.defaultOptions);
		});
		return result;
	}
	/**
	* Sets default options for mutations whose mutation key partially matches the given
	* `mutationKey`. As with {@link QueryClient#setQueryDefaults}, the order of registration
	* matters when several registered defaults match the same mutation key.
	* @param mutationKey - The mutation key that mutation keys are partially matched against.
	* @param options - The default options applied to matching mutations.
	* @see {@link QueryClient#getMutationDefaults}
	* @example
	* ```ts
	* queryClient.setMutationDefaults(['addPost'], { mutationFn: addPost })
	* ```
	*/
	setMutationDefaults(mutationKey, options) {
		this.#mutationDefaults.set(hashKey(mutationKey), {
			mutationKey,
			defaultOptions: options
		});
	}
	/**
	* Returns the default options registered for mutations whose mutation key partially matches
	* the given `mutationKey`, via {@link QueryClient#setMutationDefaults}. If multiple registered
	* defaults match, they are merged together in registration order.
	* @param mutationKey - The mutation key to look up registered defaults for.
	* @returns The merged default options of every registration that matches, or an empty object if
	* none match.
	* @example
	* ```ts
	* const defaultOptions = queryClient.getMutationDefaults(['addPost'])
	* ```
	*/
	getMutationDefaults(mutationKey) {
		const defaults = [...this.#mutationDefaults.values()];
		const result = {};
		defaults.forEach((queryDefault) => {
			if (partialMatchKey(mutationKey, queryDefault.mutationKey)) Object.assign(result, queryDefault.defaultOptions);
		});
		return result;
	}
	/**
	* Called by framework adapters (e.g. inside `useQuery`) to resolve the options passed by the
	* caller into their final, defaulted form: merging the client's own `defaultOptions.queries`,
	* then `queryClient.setQueryDefaults` for the given `queryKey`, then the caller's options on
	* top. A no-op if the options are already defaulted (`_defaulted: true`).
	* @param options - The query options passed by the caller.
	* @returns The defaulted options, with `queryHash` and dependent defaults (e.g.
	* `refetchOnReconnect`) filled in.
	*/
	defaultQueryOptions(options) {
		if (options._defaulted) return options;
		const defaultedOptions = {
			...this.#defaultOptions.queries,
			...this.getQueryDefaults(options.queryKey),
			...options,
			_defaulted: true
		};
		if (!defaultedOptions.queryHash) defaultedOptions.queryHash = hashQueryKeyByOptions(defaultedOptions.queryKey, defaultedOptions);
		if (defaultedOptions.refetchOnReconnect === void 0) defaultedOptions.refetchOnReconnect = defaultedOptions.networkMode !== "always";
		if (defaultedOptions.throwOnError === void 0) defaultedOptions.throwOnError = !!defaultedOptions.suspense;
		if (!defaultedOptions.networkMode && defaultedOptions.persister) defaultedOptions.networkMode = "offlineFirst";
		if (defaultedOptions.queryFn === skipToken) defaultedOptions.enabled = false;
		return defaultedOptions;
	}
	/**
	* The mutation counterpart of {@link QueryClient#defaultQueryOptions}. Called by framework
	* adapters (e.g. inside `useMutation`) to merge the client's `defaultOptions.mutations`, then
	* `queryClient.setMutationDefaults` for the given `mutationKey`, then the caller's options on
	* top. A no-op if the options are already defaulted (`_defaulted: true`).
	* @param options - The mutation options passed by the caller.
	* @returns The defaulted options.
	*/
	defaultMutationOptions(options) {
		if (options?._defaulted) return options;
		return {
			...this.#defaultOptions.mutations,
			...options?.mutationKey && this.getMutationDefaults(options.mutationKey),
			...options,
			_defaulted: true
		};
	}
	/**
	* Clears both the query cache and the mutation cache this client is connected to.
	* @example
	* ```ts
	* import { QueryClient } from '@tanstack/query-core'
	*
	* const queryClient = new QueryClient()
	* queryClient.clear()
	* ```
	*/
	clear() {
		this.#queryCache.clear();
		this.#mutationCache.clear();
	}
};
// node_modules/@tanstack/query-core/build/modern/streamedQuery.js
/**
* This is a helper function to create a query function that streams data from an AsyncIterable.
* Data will be an Array of all the chunks received.
* The query will be in a 'pending' state until the first chunk of data is received, but will go to 'success' after that.
* The query will stay in fetchStatus 'fetching' until the stream ends.
* Explicit cancellation stops further cache updates, even if `streamFn` does not read `signal`.
* If `streamFn` does not read `signal`, the stream continues after the last observer unsubscribes.
* @param options - The `streamFn` that returns an AsyncIterable to stream data from, and the optional
* `refetchMode`, `reducer`, and `initialValue` options.
* @returns A query function to pass as `queryFn`.
* @example
* ```ts
* await queryClient.query({
*   queryKey: ['data'],
*   queryFn: streamedQuery({
*     streamFn: fetchDataInChunks,
*   }),
* })
* ```
*/
function streamedQuery({ streamFn, refetchMode = "reset", reducer = (items, chunk) => addToEnd(items, chunk), initialValue = [] }) {
	return async (context) => {
		const signal = context[fetchSignal];
		if (signal?.aborted) return initialValue;
		const query = context.client.getQueryCache().find({
			queryKey: context.queryKey,
			exact: true
		});
		const isRefetch = !!query && query.isFetched();
		if (isRefetch && refetchMode === "reset") query.setState({
			...query.resetState,
			fetchStatus: "fetching"
		});
		let result = initialValue;
		let cancelled = false;
		const streamFnContext = addConsumeAwareSignal({
			client: context.client,
			meta: context.meta,
			queryKey: context.queryKey,
			pageParam: context.pageParam,
			direction: context.direction
		}, () => context.signal, () => cancelled = true, signal);
		const isStreamInactive = () => cancelled || signal?.aborted === true;
		const stream = await streamFn(streamFnContext);
		const isReplaceRefetch = isRefetch && refetchMode === "replace";
		for await (const chunk of stream) {
			if (isStreamInactive()) break;
			if (isReplaceRefetch) result = reducer(result, chunk);
			else context.client.setQueryData(context.queryKey, (prev) => reducer(prev === void 0 ? initialValue : prev, chunk));
		}
		if (isReplaceRefetch && !isStreamInactive()) context.client.setQueryData(context.queryKey, result);
		const data = context.client.getQueryData(context.queryKey);
		return data === void 0 ? initialValue : data;
	};
}
// node_modules/@tanstack/query-core/build/modern/types.js
/* istanbul ignore file */
var dataTagSymbol = Symbol();
var dataTagErrorSymbol = Symbol();
var unsetMarker = Symbol();
// node_modules/@tanstack/react-query/build/modern/HydrationBoundary.js
/**
* `HydrationBoundary` adds a previously dehydrated state into the `queryClient` that would be returned by
* `useQueryClient()`. If the client already contains data, the new queries will be intelligently merged based on
* update timestamp.
*
* Note: Only `queries` can be dehydrated with an `HydrationBoundary`.
* @param props - The dehydrated `state` to hydrate, the hydrate `options`, an optional custom
* `queryClient`, and the `children` to render.
* @returns The provided `children`, rendered unconditionally. New queries in `state` are hydrated into the
* cache during render; for queries already in the cache, only newer dehydrated data is hydrated, in an effect
* after commit.
* @example
* ```tsx
* import { HydrationBoundary } from '@tanstack/react-query'
*
* function App() {
*   return <HydrationBoundary state={dehydratedState}>...</HydrationBoundary>
* }
* ```
* @example
* Server-side prefetch handed off to the client via `dehydrate`:
* ```tsx
* import { HydrationBoundary, dehydrate, noop } from '@tanstack/react-query'
*
* async function ServerComponent() {
*   const queryClient = getQueryClient()
*
*   await queryClient
*     .query({
*       queryKey: ['posts'],
*       queryFn: fetchPosts,
*     })
*     .catch(noop)
*
*   return (
*     <HydrationBoundary state={dehydrate(queryClient)}>
*       <Posts />
*     </HydrationBoundary>
*   )
* }
* ```
*/
var HydrationBoundary = ({ children, options = {}, state, queryClient }) => {
	const client = useQueryClient(queryClient);
	const optionsRef = import_react.useRef(options);
	import_react.useEffect(() => {
		optionsRef.current = options;
	});
	const hydrationQueue = import_react.useMemo(() => {
		if (state) {
			if (typeof state !== "object") return;
			const queryCache = client.getQueryCache();
			const queries = state.queries || [];
			const newQueries = [];
			const existingQueries = [];
			for (const dehydratedQuery of queries) {
				const existingQuery = queryCache.get(dehydratedQuery.queryHash);
				if (!existingQuery) newQueries.push(dehydratedQuery);
				else if (dehydratedQuery.state.dataUpdatedAt > existingQuery.state.dataUpdatedAt || dehydratedQuery.promise && existingQuery.state.status !== "pending" && existingQuery.state.fetchStatus !== "fetching" && dehydratedQuery.dehydratedAt > existingQuery.state.dataUpdatedAt) existingQueries.push(dehydratedQuery);
			}
			if (newQueries.length > 0) hydrate(client, { queries: newQueries }, optionsRef.current);
			if (existingQueries.length > 0) return existingQueries;
		}
	}, [client, state]);
	import_react.useEffect(() => {
		if (hydrationQueue) hydrate(client, { queries: hydrationQueue }, optionsRef.current);
	}, [client, hydrationQueue]);
	return children;
};
// node_modules/@tanstack/react-query/build/modern/IsRestoringProvider.js
var IsRestoringContext = import_react.createContext(false);
/**
* If you are using `PersistQueryClientProvider`, you can also use the `useIsRestoring` hook alongside it to
* check if a restore is currently in progress. `useQuery` and friends also check this internally to avoid
* race conditions between the restore and mounting queries.
* @returns `true` while a persisted client is being restored, `false` otherwise.
*/
var useIsRestoring = () => import_react.useContext(IsRestoringContext);
/**
* The Provider that `PersistQueryClientProvider` uses to signal whether a persisted client is currently
* being restored, read by `useIsRestoring`.
*/
var IsRestoringProvider = IsRestoringContext.Provider;
// node_modules/@tanstack/react-query/build/modern/QueryErrorResetBoundary.js
/**
* Creates the value shared through the boundary's context, which tracks whether a reset was
* requested.
* @returns The `clearReset`, `isReset`, and `reset` functions of the boundary.
*/
function createValue() {
	let isReset = false;
	return {
		/**
		* Clears the reset state, so queries know not to try again until the boundary is reset again.
		*/
		clearReset: () => {
			isReset = false;
		},
		/**
		* Resets any query errors within the boundary, so queries know they can try again.
		*/
		reset: () => {
			isReset = true;
		},
		/**
		* Returns whether the boundary has been reset and not yet cleared.
		* @returns `true` if the boundary has been reset and not yet cleared.
		*/
		isReset: () => {
			return isReset;
		}
	};
}
var QueryErrorResetBoundaryContext = import_react.createContext(createValue());
/**
* This hook will reset any query errors within the closest `QueryErrorResetBoundary`. If there is no boundary
* defined it will reset them globally.
* @returns The boundary's {@link QueryErrorResetBoundaryValue}.
* @example
* ```tsx
* import { ErrorBoundary } from 'react-error-boundary'
* import { useQueryErrorResetBoundary } from '@tanstack/react-query'
*
* function App({ children }: { children: React.ReactNode }) {
*   const { reset } = useQueryErrorResetBoundary()
*
*   return (
*     <ErrorBoundary
*       onReset={reset}
*       fallbackRender={({ resetErrorBoundary }) => (
*         <div>
*           There was an error!
*           <button onClick={() => resetErrorBoundary()}>Try again</button>
*         </div>
*       )}
*     >
*       {children}
*     </ErrorBoundary>
*   )
* }
* ```
*/
var useQueryErrorResetBoundary = () => import_react.useContext(QueryErrorResetBoundaryContext);
/**
* When using `suspense` or `throwOnError` in your queries, you need a way to let queries know that you want to
* try again when re-rendering after some error occurred. With the `QueryErrorResetBoundary` component you can
* reset any query errors within the boundaries of the component.
* @param props - The `children` to render.
* @returns The `children`, rendered as-is, or called with the boundary's {@link QueryErrorResetBoundaryValue}
* if `children` is a function.
* @example
* ```tsx
* import { ErrorBoundary } from 'react-error-boundary'
* import { QueryErrorResetBoundary } from '@tanstack/react-query'
*
* function App() {
*   return (
*     <QueryErrorResetBoundary>
*       {({ reset }) => (
*         <ErrorBoundary
*           onReset={reset}
*           fallbackRender={({ resetErrorBoundary }) => (
*             <div>
*               There was an error!
*               <button onClick={() => resetErrorBoundary()}>Try again</button>
*             </div>
*           )}
*         >
*           <Page />
*         </ErrorBoundary>
*       )}
*     </QueryErrorResetBoundary>
*   )
* }
* ```
*/
var QueryErrorResetBoundary = ({ children }) => {
	const [value] = import_react.useState(() => createValue());
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QueryErrorResetBoundaryContext.Provider, {
		value,
		children: typeof children === "function" ? children(value) : children
	});
};
// node_modules/@tanstack/react-query/build/modern/errorBoundaryUtils.js
/**
* Turns off `retryOnMount` for a query that throws its errors (with `suspense` or `throwOnError`),
* unless the error boundary has been reset, so a remount doesn't retry the failed query before the
* user resets the boundary. Mutates the options.
* @param options - The defaulted query options to adjust.
* @param errorResetBoundary - The value of the nearest `QueryErrorResetBoundary`.
* @param query - The query, used to evaluate a `throwOnError` function against its error.
*/
var ensurePreventErrorBoundaryRetry = (options, errorResetBoundary, query) => {
	const throwOnError = query?.state.status === "error" && typeof options.throwOnError === "function" ? shouldThrowError(options.throwOnError, [query.state.error, query]) : options.throwOnError;
	if (options.suspense || throwOnError) {
		if (!errorResetBoundary.isReset()) options.retryOnMount = false;
	}
};
/**
* Clears the reset state of the error boundary after the component mounts, so later errors are
* thrown to the boundary again.
* @param errorResetBoundary - The value of the nearest `QueryErrorResetBoundary`.
*/
var useClearResetErrorBoundary = (errorResetBoundary) => {
	import_react.useEffect(() => {
		errorResetBoundary.clearReset();
	}, [errorResetBoundary]);
};
/**
* Checks whether the query error should be thrown to the nearest error boundary: the query errored
* and isn't fetching, the boundary hasn't been reset, and either `suspense` is enabled with no data
* or `throwOnError` says so.
* @param params - The observer `result`, the `errorResetBoundary`, the `throwOnError` option, the
* `query`, and the `suspense` option.
* @returns `true` if the error should be thrown.
*/
var getHasError = ({ result, errorResetBoundary, throwOnError, query, suspense }) => {
	return result.isError && !errorResetBoundary.isReset() && !result.isFetching && query && (suspense && result.data === void 0 || shouldThrowError(throwOnError, [result.error, query]));
};
// node_modules/@tanstack/react-query/build/modern/suspense.js
/**
* The default `throwOnError` of the suspense hooks: throws the error to the nearest error boundary
* only if the query has no data to show.
* @param _error - The error of the query. Unused.
* @param query - The query that errored.
* @returns `true` if the query has no data.
*/
var defaultThrowOnError = (_error, query) => query.state.data === void 0;
/**
* Raises `staleTime` and a numeric `gcTime` to at least 1000ms when `suspense` is enabled, so a
* component that remounts after suspending doesn't refetch right away or find the query garbage
* collected. A `'static'` `staleTime` is kept as is. Mutates the options.
* @param defaultedOptions - The defaulted query options to adjust.
*/
var ensureSuspenseTimers = (defaultedOptions) => {
	if (defaultedOptions.suspense) {
		const MIN_SUSPENSE_TIME_MS = 1e3;
		const clamp = (value) => value === "static" ? value : Math.max(value ?? MIN_SUSPENSE_TIME_MS, MIN_SUSPENSE_TIME_MS);
		const originalStaleTime = defaultedOptions.staleTime;
		defaultedOptions.staleTime = typeof originalStaleTime === "function" ? (...args) => clamp(originalStaleTime(...args)) : clamp(originalStaleTime);
		if (typeof defaultedOptions.gcTime === "number") defaultedOptions.gcTime = Math.max(defaultedOptions.gcTime, MIN_SUSPENSE_TIME_MS);
	}
};
/**
* Checks whether a query should suspend: `suspense` is enabled and the result is still `pending`.
* @param defaultedOptions - The defaulted query options, if any.
* @param result - The current result of the observer.
* @returns `true` if the component should suspend.
*/
var shouldSuspend = (defaultedOptions, result) => defaultedOptions?.suspense && result.isPending;
/**
* Fetches the query for a suspending component, without affecting the observer's own result. If
* the fetch fails, the reset state of the error boundary is cleared, so the error is thrown to it.
* @param defaultedOptions - The defaulted query options to fetch with.
* @param observer - The observer of the query.
* @param errorResetBoundary - The value of the nearest `QueryErrorResetBoundary`.
* @returns A promise that resolves once the fetch settles. It never rejects.
*/
var fetchOptimistic = (defaultedOptions, observer, errorResetBoundary) => observer.fetchOptimistic(defaultedOptions).catch(() => {
	errorResetBoundary.clearReset();
});
// node_modules/@tanstack/react-query/build/modern/useQueries.js
/**
* The `useQueries` hook can be used to fetch a variable number of queries.
*
* The `queries` key accepts an array with query option objects mostly identical to `useQuery` — the top-level
* `subscribed` option isn't accepted per query (see `placeholderData` below for another difference). A custom
* `QueryClient` is supplied once, as `useQueries`' own top-level second argument, rather than per query.
*
* Having the same query key more than once in the array of query objects may cause some data to be shared
* between queries. To avoid this, consider de-duplicating the queries and map the results back to the desired
* structure.
*
* The `combine` option can be used to combine the results of the queries into a single value. The result will
* be structurally shared to be as referentially stable as possible.
* @param options - The `queries` array to run, and the optional `combine` and `subscribed` options.
* @param queryClient - Use this to provide a custom `QueryClient`. Otherwise, the one from the nearest context
* will be used.
* @returns The combined result. Without `combine`, this is an array with all the query results, in the same
* order as the input. When `combine` is provided, this is the value returned by `combine` instead.
* @throws {Error} The error of the first query that should be thrown to the nearest error boundary (see
* `throwOnError`). While suspending, it throws a promise instead.
* @remarks The `combine` function only re-runs if it changed referentially, or if any of the query results
* changed. An inlined `combine` function, as shown in the example below, therefore runs on every render — wrap
* it in `useCallback`, or extract it to a stable function reference if it doesn't have any dependencies, to
* avoid that.
*
* Unlike `useQuery`, `useQueries` cannot infer the `data` argument of an _inline_ `select` from its sibling
* `queryFn`. Because `useQueries` infers the type of the whole `queries` array at once, the `select` parameter
* of a query object written inline cannot be contextually typed from that same object's `queryFn`, so it falls
* back to `unknown` — a [known TypeScript limitation](https://github.com/TanStack/query/issues/6556). Annotate
* the `select` parameter explicitly, or define the query with {@link queryOptions}, which resolves its types in
* a single object _before_ it reaches `useQueries`, to work around this — see the example below. The same
* limitation applies to {@link useSuspenseQueries}.
*
* `placeholderData` is supported here too, but unlike `useQuery`, it doesn't receive information from
* previously rendered queries, because the number of queries can differ between renders.
* @example
* ```tsx
* import { useQueries } from '@tanstack/react-query'
*
* function Posts({ ids }: { ids: Array<number> }) {
*   const postQueries = useQueries({
*     queries: ids.map((id) => ({
*       queryKey: ['post', id],
*       queryFn: () => fetchPost(id),
*       staleTime: Infinity,
*     })),
*   })
*
*   return (
*     <ul>
*       {postQueries.map((query, index) => {
*         if (query.isPending) return <li key={ids[index]}>Loading...</li>
*         if (query.isError) return <li key={ids[index]}>Error: {query.error.message}</li>
*         return <li key={ids[index]}>{query.data.title}</li>
*       })}
*     </ul>
*   )
* }
* ```
* @example
* Combining results into a single value:
* ```tsx
* import { useQueries } from '@tanstack/react-query'
*
* function Posts({ ids }: { ids: Array<number> }) {
*   const { data, isPending, isError } = useQueries({
*     queries: ids.map((id) => ({
*       queryKey: ['post', id],
*       queryFn: () => fetchPost(id),
*     })),
*     combine: (postQueries) => {
*       return {
*         data: postQueries.map((query) => query.data),
*         isPending: postQueries.some((query) => query.isPending),
*         isError: postQueries.some((query) => query.isError),
*       }
*     },
*   })
*
*   if (isPending) return 'Loading...'
*   if (isError) return 'Error loading posts'
*
*   return (
*     <ul>
*       {data.map((post) => (
*         <li key={post?.id}>{post?.title}</li>
*       ))}
*     </ul>
*   )
* }
* ```
* @example
* Typing `select` via {@link queryOptions}. Note that spreading a `queryOptions` result and overriding
* `select` inline still falls back to `unknown` — wrap the spread in `queryOptions` again so the override is
* resolved before it reaches `useQueries`:
* ```tsx
* import { queryOptions, useQueries } from '@tanstack/react-query'
*
* const postOptions = (id: number) =>
*   queryOptions({
*     queryKey: ['post', id],
*     queryFn: () => fetchPost(id),
*   })
*
* function PostTitle({ id }: { id: number }) {
*   const [{ data: broken }] = useQueries({
*     queries: [
*       {
*         ...postOptions(id),
*         // ❌ `data` is `unknown` here
*         select: (data) => data.title,
*       },
*     ],
*   })
*
*   const [{ data: fixed }] = useQueries({
*     queries: [
*       queryOptions({
*         ...postOptions(id),
*         // ✅ `data` is `Post`
*         select: (data) => data.title,
*       }),
*     ],
*   })
*
*   return <h1>{fixed}</h1>
* }
* ```
*/
function useQueries({ queries, ...options }, queryClient) {
	const client = useQueryClient(queryClient);
	const isRestoring = useIsRestoring();
	const errorResetBoundary = useQueryErrorResetBoundary();
	const subscribed = options.subscribed !== false;
	const defaultedQueries = import_react.useMemo(() => queries.map((opts) => {
		const defaultedOptions = client.defaultQueryOptions(opts);
		defaultedOptions._optimisticResults = isRestoring ? "isRestoring" : subscribed ? "optimistic" : void 0;
		return defaultedOptions;
	}), [
		queries,
		client,
		isRestoring,
		subscribed
	]);
	defaultedQueries.forEach((queryOptions) => {
		ensureSuspenseTimers(queryOptions);
		const query = client.getQueryCache().get(queryOptions.queryHash);
		ensurePreventErrorBoundaryRetry(queryOptions, errorResetBoundary, query);
	});
	useClearResetErrorBoundary(errorResetBoundary);
	const [observer] = import_react.useState(() => new QueriesObserver(client, defaultedQueries, options));
	const [optimisticResult, getCombinedResult, trackResult] = observer.getOptimisticResult(defaultedQueries, options.combine);
	import_react.useEffect(() => {
		observer.setQueries(defaultedQueries, options);
	}, [
		defaultedQueries,
		options,
		observer
	]);
	const shouldSubscribe = !isRestoring && subscribed;
	import_react.useSyncExternalStore(import_react.useCallback((onStoreChange) => shouldSubscribe ? observer.subscribe(notifyManager.batchCalls(onStoreChange)) : noop, [observer, shouldSubscribe]), () => observer.getCurrentResult(), () => observer.getCurrentResult());
	const suspensePromises = optimisticResult.some((result, index) => shouldSuspend(defaultedQueries[index], result)) ? optimisticResult.flatMap((result, index) => {
		const opts = defaultedQueries[index];
		if (opts && shouldSuspend(opts, result)) return fetchOptimistic(opts, new QueryObserver(client, opts), errorResetBoundary);
		return [];
	}) : [];
	if (suspensePromises.length > 0) throw Promise.all(suspensePromises);
	const firstSingleResultWhichShouldThrow = optimisticResult.find((result, index) => {
		const query = defaultedQueries[index];
		return query && getHasError({
			result,
			errorResetBoundary,
			throwOnError: query.throwOnError,
			query: client.getQueryCache().get(query.queryHash),
			suspense: query.suspense
		});
	});
	if (firstSingleResultWhichShouldThrow) throw firstSingleResultWhichShouldThrow.error;
	return getCombinedResult(trackResult());
}
// node_modules/@tanstack/react-query/build/modern/useBaseQuery.js
/**
* Base implementation shared by `useQuery`, `useInfiniteQuery`, `useSuspenseQuery`, and
* `useSuspenseInfiniteQuery`.
* @param options - The options passed to the calling hook.
* @param Observer - The observer class from query-core (`QueryObserver` or
* `InfiniteQueryObserver`).
* @param queryClient - Use this to use a custom `QueryClient`. Otherwise, the one from the nearest
* context will be used.
* @returns The query result, tracking which properties are read unless `notifyOnChangeProps` is
* set.
* @throws {Error} If `options` is not an object (outside production), or the query error when it should be
* thrown to the nearest error boundary (see `throwOnError`). While suspending, it throws a promise instead.
*/
function useBaseQuery(options, Observer, queryClient) {
	if (typeof options !== "object" || Array.isArray(options)) throw new Error("Bad argument type. Starting with v5, only the \"Object\" form is allowed when calling query related functions. Please use the error stack to find the culprit call. More info here: https://tanstack.com/query/latest/docs/react/guides/migrating-to-v5#supports-a-single-signature-one-object");
	const isRestoring = useIsRestoring();
	const errorResetBoundary = useQueryErrorResetBoundary();
	const client = useQueryClient(queryClient);
	const defaultedOptions = client.defaultQueryOptions(options);
	const query = client.getQueryCache().get(defaultedOptions.queryHash);
	if (!defaultedOptions.queryFn) console.error(`[${defaultedOptions.queryHash}]: No queryFn was passed as an option, and no default queryFn was found. The queryFn parameter is only optional when using a default queryFn. More info here: https://tanstack.com/query/latest/docs/framework/react/guides/default-query-function`);
	const subscribed = options.subscribed !== false;
	defaultedOptions._optimisticResults = isRestoring ? "isRestoring" : subscribed ? "optimistic" : void 0;
	ensureSuspenseTimers(defaultedOptions);
	ensurePreventErrorBoundaryRetry(defaultedOptions, errorResetBoundary, query);
	useClearResetErrorBoundary(errorResetBoundary);
	const [observer] = import_react.useState(() => new Observer(client, defaultedOptions));
	const result = observer.getOptimisticResult(defaultedOptions);
	import_react.useEffect(() => {
		observer.setOptions(defaultedOptions);
	}, [defaultedOptions, observer]);
	const shouldSubscribe = !isRestoring && subscribed;
	import_react.useSyncExternalStore(import_react.useCallback((onStoreChange) => {
		const unsubscribe = shouldSubscribe ? observer.subscribe(notifyManager.batchCalls(onStoreChange)) : noop;
		observer.updateResult();
		return unsubscribe;
	}, [observer, shouldSubscribe]), () => observer.getCurrentResult(), () => observer.getCurrentResult());
	if (shouldSuspend(defaultedOptions, result)) throw fetchOptimistic(defaultedOptions, observer, errorResetBoundary);
	if (getHasError({
		result,
		errorResetBoundary,
		throwOnError: defaultedOptions.throwOnError,
		query,
		suspense: defaultedOptions.suspense
	})) throw result.error;
	return !defaultedOptions.notifyOnChangeProps ? observer.trackResult(result) : result;
}
// node_modules/@tanstack/react-query/build/modern/useQuery.js
function useQuery(options, queryClient) {
	return useBaseQuery(options, QueryObserver, queryClient);
}
// node_modules/@tanstack/react-query/build/modern/useSuspenseQuery.js
/**
* The options for `useSuspenseQuery` are the same as for `useQuery`, except for `throwOnError`, `enabled`, and
* `placeholderData` — and `queryFn` may not be `skipToken`, since Suspense hooks can't render a "disabled" state.
*
* Caveat: cancellation does not work.
* @param options - The {@link UseSuspenseQueryOptions} to use — the same options as `useQuery`, minus the ones listed above.
* @param queryClient - Use this to use a custom `QueryClient`. Otherwise, the one from the nearest context will
* be used.
* @returns The same object as `useQuery`, except that `data` is guaranteed to be defined, `isPlaceholderData`
* is missing, and `status` is either `success` or `error` (with the derived flags set accordingly).
* @remarks Multiple `useSuspenseQuery` calls in the same component suspend serially, causing a request
* waterfall — each one blocks rendering until it resolves, so the next doesn't even start fetching until then.
* Use {@link useSuspenseQueries} instead when you have more than one suspenseful query in a component, so they
* fetch in parallel.
* @example
* The query error is thrown if the fetch fails and no cached data exists yet, so an error boundary is
* required around `<Suspense>`. A failed background refetch instead continues to render the cached data.
* Use {@link QueryErrorResetBoundary} to let the user retry after such an error:
* ```tsx
* import { Suspense } from 'react'
* import { ErrorBoundary } from 'react-error-boundary'
* import { QueryErrorResetBoundary, useSuspenseQuery } from '@tanstack/react-query'
*
* function Posts() {
*   // `data` is guaranteed to be defined here — no `isPending` check needed.
*   const { data, isFetching } = useSuspenseQuery({
*     queryKey: ['posts'],
*     queryFn: fetchPosts,
*   })
*
*   return (
*     <div>
*       <h1>Posts {isFetching ? '(refreshing...)' : null}</h1>
*       <ul>
*         {data.map((post) => (
*           <li key={post.id}>{post.title}</li>
*         ))}
*       </ul>
*     </div>
*   )
* }
*
* function App() {
*   return (
*     <QueryErrorResetBoundary>
*       {({ reset }) => (
*         <ErrorBoundary
*           onReset={reset}
*           fallbackRender={({ resetErrorBoundary }) => (
*             <div>
*               There was an error!
*               <button onClick={() => resetErrorBoundary()}>Try again</button>
*             </div>
*           )}
*         >
*           <Suspense fallback={<h1>Loading posts...</h1>}>
*             <Posts />
*           </Suspense>
*         </ErrorBoundary>
*       )}
*     </QueryErrorResetBoundary>
*   )
* }
* ```
*/
function useSuspenseQuery(options, queryClient) {
	if (options.queryFn === skipToken) console.error("skipToken is not allowed for useSuspenseQuery");
	return useBaseQuery({
		...options,
		enabled: true,
		suspense: true,
		throwOnError: defaultThrowOnError,
		placeholderData: void 0
	}, QueryObserver, queryClient);
}
// node_modules/@tanstack/react-query/build/modern/useSuspenseInfiniteQuery.js
/**
* The options for `useSuspenseInfiniteQuery` are the same as for `useInfiniteQuery`, except for `throwOnError`,
* `enabled`, and `placeholderData`.
*
* Caveat: cancellation does not work.
* @param options - The {@link UseSuspenseInfiniteQueryOptions} to use — the same options as `useInfiniteQuery`, minus the ones listed above.
* @param queryClient - Use this to use a custom `QueryClient`. Otherwise, the one from the nearest context will
* be used.
* @returns The same object as `useInfiniteQuery`, except that `data` is guaranteed to be defined,
* `isPlaceholderData` is missing, and `status` is either `success` or `error` (with the derived flags set
* accordingly).
* @remarks Multiple suspenseful query calls in the same component suspend serially, causing a request
* waterfall — each one blocks rendering until it resolves, so the next doesn't even start fetching until
* then. There's no way to parallelize multiple infinite queries under Suspense. Also keep in mind that
* imperative fetch calls, such as `fetchNextPage`, may interfere with the default refetch behavior,
* resulting in outdated data. Make sure to call these functions only in response to user actions, or add
* conditions like `hasNextPage && !isFetching`.
* @see {@link useInfiniteQuery} for the non-Suspense version of this hook.
* @example
* The query error is thrown if a fetch fails and no cached data exists yet, so an error boundary is
* required around `<Suspense>`. A failed background refetch instead continues to render the cached data.
* Use {@link QueryErrorResetBoundary} to let the user retry after such an error:
* ```tsx
* import { Suspense } from 'react'
* import { ErrorBoundary } from 'react-error-boundary'
* import {
*   QueryErrorResetBoundary,
*   useSuspenseInfiniteQuery,
* } from '@tanstack/react-query'
*
* function Projects() {
*   // `data` is guaranteed to be defined here — no `isPending` check needed.
*   const { data, fetchNextPage, hasNextPage, isFetching, isFetchingNextPage } =
*     useSuspenseInfiniteQuery({
*       queryKey: ['projects'],
*       queryFn: ({ pageParam }) => fetchProjects(pageParam),
*       initialPageParam: 0,
*       getNextPageParam: (lastPage) => lastPage.nextId,
*     })
*
*   return (
*     <div>
*       <ul>
*         {data.pages.map((page) =>
*           page.projects.map((project) => <li key={project.id}>{project.name}</li>),
*         )}
*       </ul>
*       <button
*         onClick={() => fetchNextPage()}
*         disabled={!hasNextPage || isFetching}
*       >
*         {isFetchingNextPage
*           ? 'Loading more...'
*           : hasNextPage
*             ? 'Load More'
*             : 'Nothing more to load'}
*       </button>
*     </div>
*   )
* }
*
* function App() {
*   return (
*     <QueryErrorResetBoundary>
*       {({ reset }) => (
*         <ErrorBoundary
*           onReset={reset}
*           fallbackRender={({ resetErrorBoundary }) => (
*             <div>
*               There was an error!
*               <button onClick={() => resetErrorBoundary()}>Try again</button>
*             </div>
*           )}
*         >
*           <Suspense fallback={<h1>Loading projects...</h1>}>
*             <Projects />
*           </Suspense>
*         </ErrorBoundary>
*       )}
*     </QueryErrorResetBoundary>
*   )
* }
* ```
*/
function useSuspenseInfiniteQuery(options, queryClient) {
	if (options.queryFn === skipToken) console.error("skipToken is not allowed for useSuspenseInfiniteQuery");
	return useBaseQuery({
		...options,
		enabled: true,
		suspense: true,
		throwOnError: defaultThrowOnError,
		placeholderData: void 0
	}, InfiniteQueryObserver, queryClient);
}
// node_modules/@tanstack/react-query/build/modern/useSuspenseQueries.js
function useSuspenseQueries(options, queryClient) {
	return useQueries({
		...options,
		queries: options.queries.map((query) => {
			if (query.queryFn === skipToken) console.error("skipToken is not allowed for useSuspenseQueries");
			return {
				...query,
				suspense: true,
				throwOnError: defaultThrowOnError,
				enabled: true,
				placeholderData: void 0
			};
		})
	}, queryClient);
}
// node_modules/@tanstack/react-query/build/modern/usePrefetchQuery.js
/**
* `usePrefetchQuery` does not return anything, it should be used just to fire a prefetch during render, before
* a suspense boundary that wraps a component that uses `useSuspenseQuery`. You can pass everything to
* `usePrefetchQuery` that you can pass to `queryClient.query`, though `queryKey` is always required, and
* `queryFn` is required unless a default query function has been defined.
*
* The prefetch is skipped if the query already has any cached state — including a `pending`/`error` state left
* over from a previous attempt — so calling this on every render is cheap and won't refetch data that's
* already there or already in flight.
* @param options - The {@link UsePrefetchQueryOptions} to use — everything you can pass to `queryClient.query`.
* @param queryClient - Use this to use a custom `QueryClient`. Otherwise, the one from the nearest context will
* be used.
* @example
* ```tsx
* import { Suspense } from 'react'
* import { usePrefetchQuery } from '@tanstack/react-query'
*
* function App() {
*   // Fire the prefetch during render, before the suspense boundary below.
*   usePrefetchQuery({
*     queryKey: ['posts'],
*     queryFn: fetchPosts,
*   })
*
*   return (
*     <Suspense fallback={<h1>Loading posts...</h1>}>
*       <Posts />
*     </Suspense>
*   )
* }
* ```
*/
function usePrefetchQuery(options, queryClient) {
	const client = useQueryClient(queryClient);
	if (!client.getQueryState(options.queryKey)) client.query(options).catch(noop);
}
// node_modules/@tanstack/react-query/build/modern/usePrefetchInfiniteQuery.js
/**
* `usePrefetchInfiniteQuery` does not return anything, it should be used just to fire a prefetch during render,
* before a suspense boundary that wraps a component that uses `useSuspenseInfiniteQuery`. You can pass
* everything to `usePrefetchInfiniteQuery` that you can pass to `queryClient.infiniteQuery`, though
* `queryKey`, `initialPageParam`, and `getNextPageParam` are always required, and `queryFn` is required unless
* a default query function has been defined.
*
* `getNextPageParam` receives both the last page of the infinite list of data and the full array of all pages,
* as well as pageParam information, and should return a single variable that will be passed to your query
* function as `context.pageParam`. Return `undefined` or `null` to indicate there is no next page available.
*
* The prefetch is skipped if the query already has any cached state — including a `pending`/`error` state left
* over from a previous attempt — so calling this on every render is cheap and won't refetch data that's
* already there or already in flight.
* @param options - The {@link UsePrefetchInfiniteQueryOptions} to use — everything you can pass to `queryClient.infiniteQuery`.
* @param queryClient - Use this to use a custom `QueryClient`. Otherwise, the one from the nearest context will
* be used.
* @example
* ```tsx
* import { Suspense } from 'react'
* import { infiniteQueryOptions, usePrefetchInfiniteQuery } from '@tanstack/react-query'
*
* const projectsOptions = infiniteQueryOptions({
*   queryKey: ['projects'],
*   queryFn: ({ pageParam }) => fetchProjects(pageParam),
*   initialPageParam: 0,
*   getNextPageParam: (lastPage) => lastPage.nextId,
* })
*
* function App() {
*   // Fire the prefetch during render, before the suspense boundary below.
*   usePrefetchInfiniteQuery(projectsOptions)
*
*   return (
*     <Suspense fallback={<h1>Loading projects...</h1>}>
*       <Projects />
*     </Suspense>
*   )
* }
* ```
*/
function usePrefetchInfiniteQuery(options, queryClient) {
	const client = useQueryClient(queryClient);
	if (!client.getQueryState(options.queryKey)) client.infiniteQuery(options).catch(noop);
}
// node_modules/@tanstack/react-query/build/modern/queryOptions.js
function queryOptions(options) {
	return options;
}
// node_modules/@tanstack/react-query/build/modern/infiniteQueryOptions.js
function infiniteQueryOptions(options) {
	return options;
}
// node_modules/@tanstack/react-query/build/modern/useIsFetching.js
/**
* The `useIsFetching` hook returns the `number` of the queries that your application is loading or fetching in
* the background (useful for app-wide loading indicators).
* @param filters - The {@link QueryFilters} to narrow down the matched queries.
* @param queryClient - Use this to use a custom `QueryClient`. Otherwise, the one from the nearest context will
* be used.
* @returns Will be the `number` of the queries that your application is currently loading or fetching in the
* background.
* @example
* ```tsx
* import { useIsFetching } from '@tanstack/react-query'
*
* function PostsFetchingIndicator() {
*   // How many queries matching the posts prefix are fetching?
*   const isFetchingPosts = useIsFetching({ queryKey: ['posts'] })
*
*   return isFetchingPosts ? <span>Refreshing posts...</span> : null
* }
* ```
* @example
* A global loading indicator for any query fetching in the background, not just the ones on screen:
* ```tsx
* import { useIsFetching } from '@tanstack/react-query'
*
* function GlobalLoadingIndicator() {
*   const isFetching = useIsFetching()
*
*   return isFetching ? (
*     <div>Queries are fetching in the background...</div>
*   ) : null
* }
* ```
*/
function useIsFetching(filters, queryClient) {
	const client = useQueryClient(queryClient);
	const queryCache = client.getQueryCache();
	return import_react.useSyncExternalStore(import_react.useCallback((onStoreChange) => queryCache.subscribe(notifyManager.batchCalls(onStoreChange)), [queryCache]), () => client.isFetching(filters), () => client.isFetching(filters));
}
// node_modules/@tanstack/react-query/build/modern/useMutationState.js
/**
* The `useIsMutating` hook returns the `number` of mutations that your application currently has `pending`
* (useful for app-wide loading indicators).
* @param filters - The {@link MutationFilters} to narrow down the matched mutations.
* @param queryClient - Use this to use a custom `QueryClient`. Otherwise, the one from the nearest context will
* be used.
* @returns Will be the `number` of the mutations that your application currently has `pending`.
* @example
* ```tsx
* import { useIsMutating } from '@tanstack/react-query'
*
* function PostsMutatingIndicator() {
*   // How many mutations matching the posts prefix are in progress?
*   const isMutatingPosts = useIsMutating({ mutationKey: ['posts'] })
*
*   return isMutatingPosts ? <span>Saving posts...</span> : null
* }
* ```
*/
function useIsMutating(filters, queryClient) {
	const client = useQueryClient(queryClient);
	return useMutationState({ filters: {
		...filters,
		status: "pending"
	} }, client).length;
}
/**
* Creates snapshot getters that share equal selected results across renders.
* A new getter is created on each render. Each getter caches its snapshot until the matching mutations
* or their states change.
* @returns A factory for snapshot getters with a shared result cache.
*/
function createSnapshotFactory() {
	let previousResult;
	return (mutationCache, options) => {
		let inputs = [];
		let snapshot;
		return () => {
			const mutations = mutationCache.findAll(options.filters);
			const nextInputs = mutations.flatMap((mutation) => [mutation, mutation.state]);
			if (!snapshot || nextInputs.length !== inputs.length || nextInputs.some((input, index) => !Object.is(input, inputs[index]))) {
				inputs = nextInputs;
				snapshot = replaceEqualDeep(previousResult, mutations.map((mutation) => options.select ? options.select(mutation) : mutation.state));
				previousResult = snapshot;
			}
			return snapshot;
		};
	};
}
/**
* `useMutationState` is a hook that gives you access to all mutations in the `MutationCache`. You can pass
* `filters` ({@link MutationFilters}) to narrow down your mutations, and `select` to transform the mutation
* state.
* @param options - The `filters` to narrow down matched mutations, and an optional `select` to transform the
* mutation state.
* @param queryClient - Use this to use a custom `QueryClient`. Otherwise, the one from the nearest context will
* be used.
* @returns Will be an Array of whatever `select` returns for each matching mutation.
* @example
* Get all variables of all running mutations:
* ```tsx
* import { useMutationState } from '@tanstack/react-query'
*
* function PendingPosts() {
*   const pendingVariables = useMutationState({
*     filters: { status: 'pending' },
*     select: (mutation) => mutation.state.variables,
*   })
*
*   return <>{pendingVariables.length} posts saving...</>
* }
* ```
* @example
* Get all data for specific mutations via the `mutationKey`:
* ```tsx
* import { useMutation, useMutationState } from '@tanstack/react-query'
*
* const mutationKey = ['posts']
*
* function Posts() {
*   // Some mutation that we want to get the state for
*   const mutation = useMutation({
*     mutationKey,
*     mutationFn: createPosts,
*   })
*
*   const savedPosts = useMutationState({
*     // this mutation key needs to match the mutation key of the given mutation (see above)
*     filters: { mutationKey, status: 'success' },
*     select: (mutation) => mutation.state.data,
*   })
*
*   return (
*     <button onClick={() => mutation.mutate(['New Post'])}>
*       Create post ({savedPosts.length} saved so far)
*     </button>
*   )
* }
* ```
* @example
* Access the latest successful mutation data via the `mutationKey`. Each invocation of `mutate` adds a new
* entry to the mutation cache for `gcTime` milliseconds — with the `status: 'success'` filter below, check the
* last item that `useMutationState` returns to get the latest successful invocation:
* ```tsx
* import { useMutationState } from '@tanstack/react-query'
*
* function LatestPost() {
*   const savedPosts = useMutationState({
*     filters: { mutationKey: ['posts'], status: 'success' },
*     select: (mutation) => mutation.state.data,
*   })
*
*   const latestSavedPost = savedPosts[savedPosts.length - 1]
*
*   return <>{latestSavedPost ? 'Saved' : 'Nothing saved yet'}</>
* }
* ```
*/
function useMutationState(options = {}, queryClient) {
	const mutationCache = useQueryClient(queryClient).getMutationCache();
	const [createSnapshot] = import_react.useState(() => createSnapshotFactory());
	const getSnapshot = createSnapshot(mutationCache, options);
	return import_react.useSyncExternalStore(import_react.useCallback((onStoreChange) => mutationCache.subscribe(notifyManager.batchCalls(onStoreChange)), [mutationCache]), getSnapshot, getSnapshot);
}
// node_modules/@tanstack/react-query/build/modern/useMutation.js
/**
* Unlike queries, mutations are typically used to create/update/delete data or perform server side-effects.
* `useMutation` is the hook for that.
* @param options - The {@link UseMutationOptions} to use — everything you can pass to `useMutation`.
* @param queryClient - Use this to use a custom `QueryClient`. Otherwise, the one from the nearest context will
* be used.
* @returns `mutate`/`mutateAsync` also accept per-call `onSuccess`/`onError`/`onSettled` callbacks as a second
* argument, useful for triggering call-site side effects (e.g. navigation) without coupling them to the shared
* mutation definition. Hook-level callbacks (passed to `options`) fire for every mutation; per-call callbacks
* fire only for the latest call you've made, and only while the component is still mounted — unmounting before
* the mutation settles removes the subscription and prevents them from firing.
* @throws {Error} The mutation error, when `throwOnError` is `true` or returns `true` for it, so that it is
* thrown to the nearest error boundary.
* @see {@link mutationOptions} to share these options across multiple `useMutation` call sites, or to look
* the mutation up elsewhere via its `mutationKey` (e.g. with `useMutationState`).
* @example
* ```tsx
* import { useMutation, useQueryClient } from '@tanstack/react-query'
*
* function AddTodo() {
*   const queryClient = useQueryClient()
*
*   const addMutation = useMutation({
*     mutationFn: addTodo,
*     onSuccess: () => queryClient.invalidateQueries({ queryKey: ['todos'] }),
*   })
*
*   return (
*     <button
*       onClick={() =>
*         addMutation.mutate('Item', {
*           onError: (error) => console.error('Failed to add item:', error),
*         })
*       }
*     >
*       Add
*     </button>
*   )
* }
* ```
* @example
* Rendering the mutation's own state, rather than just firing it off:
* ```tsx
* import { useMutation, useQueryClient } from '@tanstack/react-query'
*
* function AddTodo() {
*   const queryClient = useQueryClient()
*
*   const addMutation = useMutation({
*     mutationFn: addTodo,
*     onSuccess: () => queryClient.invalidateQueries({ queryKey: ['todos'] }),
*   })
*
*   return (
*     <div>
*       {addMutation.isPending ? (
*         'Adding todo...'
*       ) : (
*         <>
*           {addMutation.isError ? (
*             <div>An error occurred: {addMutation.error.message}</div>
*           ) : null}
*           <button onClick={() => addMutation.mutate('Item')}>Add</button>
*         </>
*       )}
*     </div>
*   )
* }
* ```
* @example
* Optimistic update via `onMutate`, rolling back on `onError`:
* ```tsx
* import { useMutation, useQueryClient } from '@tanstack/react-query'
*
* function AddTodo() {
*   const queryClient = useQueryClient()
*
*   const addMutation = useMutation({
*     mutationFn: addTodo,
*     onMutate: async (newTodo) => {
*       await queryClient.cancelQueries({ queryKey: ['todos'] })
*       const previousTodos = queryClient.getQueryData<Array<string>>(['todos'])
*
*       queryClient.setQueryData<Array<string>>(['todos'], (old) => [
*         ...(old ?? []),
*         newTodo,
*       ])
*
*       // Passed to `onError` as `onMutateResult` if the mutation fails.
*       return { previousTodos }
*     },
*     onError: (_err, _newTodo, onMutateResult) => {
*       queryClient.setQueryData(['todos'], onMutateResult?.previousTodos)
*     },
*     onSettled: () => {
*       queryClient.invalidateQueries({ queryKey: ['todos'] })
*     },
*   })
*
*   return (
*     <button onClick={() => addMutation.mutate('Item')}>Add</button>
*   )
* }
* ```
* @example
* Callbacks passed per call to `mutate` only fire for the last call — `mutateAsync` gives you a
* promise per call instead, so you can wait for all of them when they succeed:
* ```tsx
* import { useMutation, useQueryClient } from '@tanstack/react-query'
*
* function AddTodos() {
*   const queryClient = useQueryClient()
*
*   const addMutation = useMutation({
*     mutationFn: addTodo,
*     onSuccess: () => queryClient.invalidateQueries({ queryKey: ['todos'] }),
*   })
*
*   async function handleAddAll(todos: Array<string>) {
*     try {
*       await Promise.all(todos.map((todo) => addMutation.mutateAsync(todo)))
*     } catch (error) {
*       console.error('Failed to add todos:', error)
*     }
*   }
*
*   return (
*     <button onClick={() => handleAddAll(['Todo 1', 'Todo 2', 'Todo 3'])}>
*       Add all
*     </button>
*   )
* }
* ```
* @example
* If some of the mutations above can fail independently of the others, and you want to know which ones
* did — rather than losing that information the moment the first one rejects — swap `Promise.all` for
* `Promise.allSettled`:
* ```tsx
* import { useMutation, useQueryClient } from '@tanstack/react-query'
*
* function AddTodos() {
*   const queryClient = useQueryClient()
*
*   const addMutation = useMutation({
*     mutationFn: addTodo,
*     onSuccess: () => queryClient.invalidateQueries({ queryKey: ['todos'] }),
*   })
*
*   async function handleAddAll(todos: Array<string>) {
*     const addResults = await Promise.allSettled(
*       todos.map((todo) => addMutation.mutateAsync(todo)),
*     )
*
*     addResults.forEach((addResult, index) => {
*       if (addResult.status === 'rejected') {
*         console.error(`Failed to add "${todos[index]}":`, addResult.reason)
*       }
*     })
*   }
*
*   return (
*     <button onClick={() => handleAddAll(['Todo 1', 'Todo 2', 'Todo 3'])}>
*       Add all
*     </button>
*   )
* }
* ```
*/
function useMutation(options, queryClient) {
	const client = useQueryClient(queryClient);
	const [observer] = import_react.useState(() => new MutationObserver(client, options));
	import_react.useEffect(() => {
		observer.setOptions(options);
	}, [observer, options]);
	const result = import_react.useSyncExternalStore(import_react.useCallback((onStoreChange) => observer.subscribe(notifyManager.batchCalls(onStoreChange)), [observer]), () => observer.getCurrentResult(), () => observer.getCurrentResult());
	const mutate = import_react.useCallback((...args) => {
		observer.mutate(args[0], args[1]).catch(noop);
	}, [observer]);
	if (result.error && shouldThrowError(observer.options.throwOnError, [result.error])) throw result.error;
	return {
		...result,
		mutate,
		mutateAsync: result.mutate
	};
}
// node_modules/@tanstack/react-query/build/modern/mutationOptions.js
function mutationOptions(options) {
	return options;
}
// node_modules/@tanstack/react-query/build/modern/useInfiniteQuery.js
function useInfiniteQuery(options, queryClient) {
	return useBaseQuery(options, InfiniteQueryObserver, queryClient);
}
// node_modules/@tanstack/react-query/build/modern/index.js
/* istanbul ignore file */
export { CancelledError, HydrationBoundary, InfiniteQueryObserver, IsRestoringProvider, Mutation, MutationCache, MutationObserver, QueriesObserver, Query, QueryCache, QueryClient, QueryClientContext, QueryClientProvider, QueryErrorResetBoundary, QueryObserver, dataTagErrorSymbol, dataTagSymbol, defaultScheduler, defaultShouldDehydrateMutation, defaultShouldDehydrateQuery, dehydrate, dehydrateQuery, environmentManager, streamedQuery as experimental_streamedQuery, focusManager, hashKey, hydrate, infiniteQueryOptions, isCancelledError, isServer, keepPreviousData, matchMutation, matchQuery, mutationOptions, noop, notifyManager, onlineManager, partialMatchKey, queryOptions, replaceEqualDeep, shouldThrowError, skipToken, timeoutManager, unsetMarker, useInfiniteQuery, useIsFetching, useIsMutating, useIsRestoring, useMutation, useMutationState, usePrefetchInfiniteQuery, usePrefetchQuery, useQueries, useQuery, useQueryClient, useQueryErrorResetBoundary, useSuspenseInfiniteQuery, useSuspenseQueries, useSuspenseQuery };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiQHRhbnN0YWNrX3JlYWN0LXF1ZXJ5LmpzIiwibmFtZXMiOlsiaXNTZXJ2ZXIkMSIsImlzU2VydmVyIiwiaXNTZXJ2ZXIiLCJpc1NlcnZlciIsImdldERlZmF1bHRTdGF0ZSIsImlzU2VydmVyIl0sInNvdXJjZXMiOlsiLi4vLi4vQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5L2J1aWxkL21vZGVybi9RdWVyeUNsaWVudFByb3ZpZGVyLmpzIiwiLi4vLi4vQHRhbnN0YWNrL3F1ZXJ5LWNvcmUvYnVpbGQvbW9kZXJuL3RpbWVvdXRNYW5hZ2VyLmpzIiwiLi4vLi4vQHRhbnN0YWNrL3F1ZXJ5LWNvcmUvYnVpbGQvbW9kZXJuL3V0aWxzLmpzIiwiLi4vLi4vQHRhbnN0YWNrL3F1ZXJ5LWNvcmUvYnVpbGQvbW9kZXJuL2Vudmlyb25tZW50TWFuYWdlci5qcyIsIi4uLy4uL0B0YW5zdGFjay9xdWVyeS1jb3JlL2J1aWxkL21vZGVybi9zdWJzY3JpYmFibGUuanMiLCIuLi8uLi9AdGFuc3RhY2svcXVlcnktY29yZS9idWlsZC9tb2Rlcm4vZm9jdXNNYW5hZ2VyLmpzIiwiLi4vLi4vQHRhbnN0YWNrL3F1ZXJ5LWNvcmUvYnVpbGQvbW9kZXJuL2h5ZHJhdGlvbi5qcyIsIi4uLy4uL0B0YW5zdGFjay9xdWVyeS1jb3JlL2J1aWxkL21vZGVybi9ub3RpZnlNYW5hZ2VyLmpzIiwiLi4vLi4vQHRhbnN0YWNrL3F1ZXJ5LWNvcmUvYnVpbGQvbW9kZXJuL29ubGluZU1hbmFnZXIuanMiLCIuLi8uLi9AdGFuc3RhY2svcXVlcnktY29yZS9idWlsZC9tb2Rlcm4vcmV0cnllci5qcyIsIi4uLy4uL0B0YW5zdGFjay9xdWVyeS1jb3JlL2J1aWxkL21vZGVybi9yZW1vdmFibGUuanMiLCIuLi8uLi9AdGFuc3RhY2svcXVlcnktY29yZS9idWlsZC9tb2Rlcm4vaW5maW5pdGVRdWVyeUJlaGF2aW9yLmpzIiwiLi4vLi4vQHRhbnN0YWNrL3F1ZXJ5LWNvcmUvYnVpbGQvbW9kZXJuL3F1ZXJ5LmpzIiwiLi4vLi4vQHRhbnN0YWNrL3F1ZXJ5LWNvcmUvYnVpbGQvbW9kZXJuL3F1ZXJ5T2JzZXJ2ZXIuanMiLCIuLi8uLi9AdGFuc3RhY2svcXVlcnktY29yZS9idWlsZC9tb2Rlcm4vaW5maW5pdGVRdWVyeU9ic2VydmVyLmpzIiwiLi4vLi4vQHRhbnN0YWNrL3F1ZXJ5LWNvcmUvYnVpbGQvbW9kZXJuL211dGF0aW9uLmpzIiwiLi4vLi4vQHRhbnN0YWNrL3F1ZXJ5LWNvcmUvYnVpbGQvbW9kZXJuL211dGF0aW9uQ2FjaGUuanMiLCIuLi8uLi9AdGFuc3RhY2svcXVlcnktY29yZS9idWlsZC9tb2Rlcm4vbXV0YXRpb25PYnNlcnZlci5qcyIsIi4uLy4uL0B0YW5zdGFjay9xdWVyeS1jb3JlL2J1aWxkL21vZGVybi9xdWVyaWVzT2JzZXJ2ZXIuanMiLCIuLi8uLi9AdGFuc3RhY2svcXVlcnktY29yZS9idWlsZC9tb2Rlcm4vcXVlcnlDYWNoZS5qcyIsIi4uLy4uL0B0YW5zdGFjay9xdWVyeS1jb3JlL2J1aWxkL21vZGVybi9xdWVyeUNsaWVudC5qcyIsIi4uLy4uL0B0YW5zdGFjay9xdWVyeS1jb3JlL2J1aWxkL21vZGVybi9zdHJlYW1lZFF1ZXJ5LmpzIiwiLi4vLi4vQHRhbnN0YWNrL3F1ZXJ5LWNvcmUvYnVpbGQvbW9kZXJuL3R5cGVzLmpzIiwiLi4vLi4vQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5L2J1aWxkL21vZGVybi9IeWRyYXRpb25Cb3VuZGFyeS5qcyIsIi4uLy4uL0B0YW5zdGFjay9yZWFjdC1xdWVyeS9idWlsZC9tb2Rlcm4vSXNSZXN0b3JpbmdQcm92aWRlci5qcyIsIi4uLy4uL0B0YW5zdGFjay9yZWFjdC1xdWVyeS9idWlsZC9tb2Rlcm4vUXVlcnlFcnJvclJlc2V0Qm91bmRhcnkuanMiLCIuLi8uLi9AdGFuc3RhY2svcmVhY3QtcXVlcnkvYnVpbGQvbW9kZXJuL2Vycm9yQm91bmRhcnlVdGlscy5qcyIsIi4uLy4uL0B0YW5zdGFjay9yZWFjdC1xdWVyeS9idWlsZC9tb2Rlcm4vc3VzcGVuc2UuanMiLCIuLi8uLi9AdGFuc3RhY2svcmVhY3QtcXVlcnkvYnVpbGQvbW9kZXJuL3VzZVF1ZXJpZXMuanMiLCIuLi8uLi9AdGFuc3RhY2svcmVhY3QtcXVlcnkvYnVpbGQvbW9kZXJuL3VzZUJhc2VRdWVyeS5qcyIsIi4uLy4uL0B0YW5zdGFjay9yZWFjdC1xdWVyeS9idWlsZC9tb2Rlcm4vdXNlUXVlcnkuanMiLCIuLi8uLi9AdGFuc3RhY2svcmVhY3QtcXVlcnkvYnVpbGQvbW9kZXJuL3VzZVN1c3BlbnNlUXVlcnkuanMiLCIuLi8uLi9AdGFuc3RhY2svcmVhY3QtcXVlcnkvYnVpbGQvbW9kZXJuL3VzZVN1c3BlbnNlSW5maW5pdGVRdWVyeS5qcyIsIi4uLy4uL0B0YW5zdGFjay9yZWFjdC1xdWVyeS9idWlsZC9tb2Rlcm4vdXNlU3VzcGVuc2VRdWVyaWVzLmpzIiwiLi4vLi4vQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5L2J1aWxkL21vZGVybi91c2VQcmVmZXRjaFF1ZXJ5LmpzIiwiLi4vLi4vQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5L2J1aWxkL21vZGVybi91c2VQcmVmZXRjaEluZmluaXRlUXVlcnkuanMiLCIuLi8uLi9AdGFuc3RhY2svcmVhY3QtcXVlcnkvYnVpbGQvbW9kZXJuL3F1ZXJ5T3B0aW9ucy5qcyIsIi4uLy4uL0B0YW5zdGFjay9yZWFjdC1xdWVyeS9idWlsZC9tb2Rlcm4vaW5maW5pdGVRdWVyeU9wdGlvbnMuanMiLCIuLi8uLi9AdGFuc3RhY2svcmVhY3QtcXVlcnkvYnVpbGQvbW9kZXJuL3VzZUlzRmV0Y2hpbmcuanMiLCIuLi8uLi9AdGFuc3RhY2svcmVhY3QtcXVlcnkvYnVpbGQvbW9kZXJuL3VzZU11dGF0aW9uU3RhdGUuanMiLCIuLi8uLi9AdGFuc3RhY2svcmVhY3QtcXVlcnkvYnVpbGQvbW9kZXJuL3VzZU11dGF0aW9uLmpzIiwiLi4vLi4vQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5L2J1aWxkL21vZGVybi9tdXRhdGlvbk9wdGlvbnMuanMiLCIuLi8uLi9AdGFuc3RhY2svcmVhY3QtcXVlcnkvYnVpbGQvbW9kZXJuL3VzZUluZmluaXRlUXVlcnkuanMiLCIuLi8uLi9AdGFuc3RhY2svcmVhY3QtcXVlcnkvYnVpbGQvbW9kZXJuL2luZGV4LmpzIl0sInNvdXJjZXNDb250ZW50IjpbIlwidXNlIGNsaWVudFwiO1xuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBqc3ggfSBmcm9tIFwicmVhY3QvanN4LXJ1bnRpbWVcIjtcbi8vIHNyYy9RdWVyeUNsaWVudFByb3ZpZGVyLnRzeFxuLyoqXG4qIFRoZSBjb250ZXh0IHRoYXQgYHVzZVF1ZXJ5Q2xpZW50YCByZWFkcyBmcm9tLiBgUXVlcnlDbGllbnRQcm92aWRlcmAgaXMgdGhlIG5vcm1hbCB3YXkgdG8gc2V0IGl0LlxuKi9cbmNvbnN0IFF1ZXJ5Q2xpZW50Q29udGV4dCA9IFJlYWN0LmNyZWF0ZUNvbnRleHQodm9pZCAwKTtcbi8qKlxuKiBUaGUgYHVzZVF1ZXJ5Q2xpZW50YCBob29rIHJldHVybnMgdGhlIGN1cnJlbnQgYFF1ZXJ5Q2xpZW50YCBpbnN0YW5jZS5cbiogQHBhcmFtIHF1ZXJ5Q2xpZW50IC0gVXNlIHRoaXMgdG8gdXNlIGEgY3VzdG9tIGBRdWVyeUNsaWVudGAuIE90aGVyd2lzZSwgdGhlIG9uZSBmcm9tIHRoZSBuZWFyZXN0IGNvbnRleHQgd2lsbFxuKiBiZSB1c2VkLlxuKiBAcmV0dXJucyBUaGUgY3VycmVudCBgUXVlcnlDbGllbnRgIGluc3RhbmNlLlxuKiBAdGhyb3dzIHtFcnJvcn0gSWYgbm8gYHF1ZXJ5Q2xpZW50YCBhcmd1bWVudCBpcyBwYXNzZWQgYW5kIG5vIGBRdWVyeUNsaWVudFByb3ZpZGVyYCBpcyBmb3VuZCBpbiB0aGVcbiogY29tcG9uZW50IHRyZWUuXG4qL1xuY29uc3QgdXNlUXVlcnlDbGllbnQgPSAocXVlcnlDbGllbnQpID0+IHtcblx0Y29uc3QgY2xpZW50ID0gUmVhY3QudXNlQ29udGV4dChRdWVyeUNsaWVudENvbnRleHQpO1xuXHRpZiAocXVlcnlDbGllbnQpIHJldHVybiBxdWVyeUNsaWVudDtcblx0aWYgKCFjbGllbnQpIHRocm93IG5ldyBFcnJvcihcIk5vIFF1ZXJ5Q2xpZW50IHNldCwgdXNlIFF1ZXJ5Q2xpZW50UHJvdmlkZXIgdG8gc2V0IG9uZVwiKTtcblx0cmV0dXJuIGNsaWVudDtcbn07XG4vKipcbiogVXNlIHRoZSBgUXVlcnlDbGllbnRQcm92aWRlcmAgY29tcG9uZW50IHRvIGNvbm5lY3QgYW5kIHByb3ZpZGUgYSBgUXVlcnlDbGllbnRgIHRvIHlvdXIgYXBwbGljYXRpb24uIEFsc29cbiogY2FsbHMgYGNsaWVudC5tb3VudCgpYC9gY2xpZW50LnVubW91bnQoKWAgYXMgdGhpcyBjb21wb25lbnQgbW91bnRzL3VubW91bnRzLCB3aGljaCBzdWJzY3JpYmVzIHRoZSBjbGllbnQgdG9cbiogZm9jdXMvb25saW5lIGV2ZW50cyAocmVzdW1pbmcgYW55IHBhdXNlZCBtdXRhdGlvbnMgYW5kIHJlZmV0Y2hpbmcgYXMgbmVlZGVkIHdoZW4gdGhlIGFwcCByZWdhaW5zIGZvY3VzIG9yXG4qIGNvbWVzIGJhY2sgb25saW5lKS5cbiogQHBhcmFtIHByb3BzIC0gVGhlIGBjbGllbnRgIHRvIHByb3ZpZGUsIGFuZCB0aGUgYGNoaWxkcmVuYCB0aGF0IGdldCBhY2Nlc3MgdG8gaXQuXG4qIEByZXR1cm5zIFRoZSBwcm92aWRlZCBgY2hpbGRyZW5gLCB3cmFwcGVkIHNvIHRoZXkgY2FuIHJlYWQgdGhlIGBRdWVyeUNsaWVudGAgdmlhIGB1c2VRdWVyeUNsaWVudGAuXG4qIEBleGFtcGxlXG4qIGBgYHRzeFxuKiBpbXBvcnQgeyBRdWVyeUNsaWVudCwgUXVlcnlDbGllbnRQcm92aWRlciB9IGZyb20gJ0B0YW5zdGFjay9yZWFjdC1xdWVyeSdcbipcbiogY29uc3QgcXVlcnlDbGllbnQgPSBuZXcgUXVlcnlDbGllbnQoKVxuKlxuKiBmdW5jdGlvbiBBcHAoKSB7XG4qICAgcmV0dXJuIDxRdWVyeUNsaWVudFByb3ZpZGVyIGNsaWVudD17cXVlcnlDbGllbnR9Pi4uLjwvUXVlcnlDbGllbnRQcm92aWRlcj5cbiogfVxuKiBgYGBcbiovXG5jb25zdCBRdWVyeUNsaWVudFByb3ZpZGVyID0gKHsgY2xpZW50LCBjaGlsZHJlbiB9KSA9PiB7XG5cdFJlYWN0LnVzZUVmZmVjdCgoKSA9PiB7XG5cdFx0Y2xpZW50Lm1vdW50KCk7XG5cdFx0cmV0dXJuICgpID0+IHtcblx0XHRcdGNsaWVudC51bm1vdW50KCk7XG5cdFx0fTtcblx0fSwgW2NsaWVudF0pO1xuXHRyZXR1cm4gLyogQF9fUFVSRV9fICovIGpzeChRdWVyeUNsaWVudENvbnRleHQuUHJvdmlkZXIsIHtcblx0XHR2YWx1ZTogY2xpZW50LFxuXHRcdGNoaWxkcmVuXG5cdH0pO1xufTtcbmV4cG9ydCB7IFF1ZXJ5Q2xpZW50Q29udGV4dCwgUXVlcnlDbGllbnRQcm92aWRlciwgdXNlUXVlcnlDbGllbnQgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9UXVlcnlDbGllbnRQcm92aWRlci5qcy5tYXAiLCIvLyBzcmMvdGltZW91dE1hbmFnZXIudHNcbmNvbnN0IGRlZmF1bHRUaW1lb3V0UHJvdmlkZXIgPSB7XG5cdHNldFRpbWVvdXQ6IChjYWxsYmFjaywgZGVsYXkpID0+IHNldFRpbWVvdXQoY2FsbGJhY2ssIGRlbGF5KSxcblx0Y2xlYXJUaW1lb3V0OiAodGltZW91dElkKSA9PiBjbGVhclRpbWVvdXQodGltZW91dElkKSxcblx0c2V0SW50ZXJ2YWw6IChjYWxsYmFjaywgZGVsYXkpID0+IHNldEludGVydmFsKGNhbGxiYWNrLCBkZWxheSksXG5cdGNsZWFySW50ZXJ2YWw6IChpbnRlcnZhbElkKSA9PiBjbGVhckludGVydmFsKGludGVydmFsSWQpXG59O1xuLyoqXG4qIEFsbG93cyBjdXN0b21pemF0aW9uIG9mIGhvdyB0aW1lb3V0cyBhcmUgY3JlYXRlZC5cbipcbiogYEB0YW5zdGFjay9xdWVyeS1jb3JlYCBtYWtlcyBsaWJlcmFsIHVzZSBvZiB0aW1lb3V0cyB0byBpbXBsZW1lbnQgYHN0YWxlVGltZWBcbiogYW5kIGBnY1RpbWVgLiBUaGUgZGVmYXVsdCBUaW1lb3V0TWFuYWdlciBwcm92aWRlciB1c2VzIHRoZSBwbGF0Zm9ybSdzIGdsb2JhbFxuKiBgc2V0VGltZW91dGAgaW1wbGVtZW50YXRpb24sIHdoaWNoIGlzIGtub3duIHRvIGhhdmUgc2NhbGFiaWxpdHkgaXNzdWVzIHdpdGhcbiogdGhvdXNhbmRzIG9mIHRpbWVvdXRzIG9uIHRoZSBldmVudCBsb29wLlxuKlxuKiBJZiB5b3UgaGl0IHRoaXMgbGltaXRhdGlvbiwgY29uc2lkZXIgcHJvdmlkaW5nIGEgY3VzdG9tIFRpbWVvdXRQcm92aWRlciB0aGF0XG4qIGNvYWxlc2NlcyB0aW1lb3V0cy5cbiovXG52YXIgVGltZW91dE1hbmFnZXIgPSBjbGFzcyB7XG5cdCNwcm92aWRlciA9IGRlZmF1bHRUaW1lb3V0UHJvdmlkZXI7XG5cdCNwcm92aWRlckNhbGxlZCA9IGZhbHNlO1xuXHQvKipcblx0KiBgc2V0VGltZW91dFByb3ZpZGVyYCBjYW4gYmUgdXNlZCB0byBzZXQgYSBjdXN0b20gaW1wbGVtZW50YXRpb24gb2YgdGhlXG5cdCogYHNldFRpbWVvdXRgLCBgY2xlYXJUaW1lb3V0YCwgYHNldEludGVydmFsYCwgYGNsZWFySW50ZXJ2YWxgIGZ1bmN0aW9ucyxcblx0KiBjYWxsZWQgYSBgVGltZW91dFByb3ZpZGVyYC5cblx0KlxuXHQqIFRoaXMgbWF5IGJlIHVzZWZ1bCBpZiB5b3Ugbm90aWNlIGV2ZW50IGxvb3AgcGVyZm9ybWFuY2UgaXNzdWVzIHdpdGhcblx0KiB0aG91c2FuZHMgb2YgcXVlcmllcy4gQSBjdXN0b20gVGltZW91dFByb3ZpZGVyIGNvdWxkIGFsc28gc3VwcG9ydCB0aW1lclxuXHQqIGRlbGF5cyBsb25nZXIgdGhhbiB0aGUgZ2xvYmFsIGBzZXRUaW1lb3V0YCBtYXhpbXVtIGRlbGF5IHZhbHVlIG9mIGFib3V0XG5cdCogMjQgZGF5cy5cblx0KlxuXHQqIEl0IGlzIGltcG9ydGFudCB0byBjYWxsIGBzZXRUaW1lb3V0UHJvdmlkZXJgIGJlZm9yZSBjcmVhdGluZyBhXG5cdCogUXVlcnlDbGllbnQgb3IgcXVlcmllcywgc28gdGhhdCB0aGUgc2FtZSBwcm92aWRlciBpcyB1c2VkIGNvbnNpc3RlbnRseVxuXHQqIGZvciBhbGwgdGltZXJzIGluIHRoZSBhcHBsaWNhdGlvbiwgc2luY2UgZGlmZmVyZW50IFRpbWVvdXRQcm92aWRlcnNcblx0KiBjYW5ub3QgY2FuY2VsIGVhY2ggb3RoZXJzJyB0aW1lcnMuXG5cdCogQHBhcmFtIHByb3ZpZGVyIC0gVGhlIGBUaW1lb3V0UHJvdmlkZXJgIHRvIHVzZSBmb3IgYWxsIHRpbWVycyBmcm9tIG5vdyBvbi5cblx0KiBAZXhhbXBsZVxuXHQqIGBgYHRzXG5cdCogaW1wb3J0IHsgdGltZW91dE1hbmFnZXIsIFF1ZXJ5Q2xpZW50IH0gZnJvbSAnQHRhbnN0YWNrL3F1ZXJ5LWNvcmUnXG5cdCogaW1wb3J0IHsgQ3VzdG9tVGltZW91dFByb3ZpZGVyIH0gZnJvbSAnLi9DdXN0b21UaW1lb3V0UHJvdmlkZXInXG5cdCpcblx0KiB0aW1lb3V0TWFuYWdlci5zZXRUaW1lb3V0UHJvdmlkZXIobmV3IEN1c3RvbVRpbWVvdXRQcm92aWRlcigpKVxuXHQqXG5cdCogZXhwb3J0IGNvbnN0IHF1ZXJ5Q2xpZW50ID0gbmV3IFF1ZXJ5Q2xpZW50KClcblx0KiBgYGBcblx0Ki9cblx0c2V0VGltZW91dFByb3ZpZGVyKHByb3ZpZGVyKSB7XG5cdFx0aWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikge1xuXHRcdFx0aWYgKHRoaXMuI3Byb3ZpZGVyQ2FsbGVkICYmIHByb3ZpZGVyICE9PSB0aGlzLiNwcm92aWRlcikgY29uc29sZS5lcnJvcihgW3RpbWVvdXRNYW5hZ2VyXTogU3dpdGNoaW5nIHByb3ZpZGVyIGFmdGVyIGNhbGxzIHRvIHByZXZpb3VzIHByb3ZpZGVyIG1pZ2h0IHJlc3VsdCBpbiB1bmV4cGVjdGVkIGJlaGF2aW9yLmAsIHtcblx0XHRcdFx0cHJldmlvdXM6IHRoaXMuI3Byb3ZpZGVyLFxuXHRcdFx0XHRwcm92aWRlclxuXHRcdFx0fSk7XG5cdFx0fVxuXHRcdHRoaXMuI3Byb3ZpZGVyID0gcHJvdmlkZXI7XG5cdFx0aWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgdGhpcy4jcHJvdmlkZXJDYWxsZWQgPSBmYWxzZTtcblx0fVxuXHQvKipcblx0KiBgc2V0VGltZW91dGAgc2NoZWR1bGVzIGEgY2FsbGJhY2sgdG8gcnVuIGFmdGVyIGFwcHJveGltYXRlbHkgYGRlbGF5YFxuXHQqIG1pbGxpc2Vjb25kcywgbGlrZSB0aGUgZ2xvYmFsIGBzZXRUaW1lb3V0YCBmdW5jdGlvbi4gVGhlIGNhbGxiYWNrIGNhbiBiZVxuXHQqIGNhbmNlbGVkIHdpdGggYGNsZWFyVGltZW91dGAuXG5cdCpcblx0KiBJdCByZXR1cm5zIGEgdGltZXIgSUQsIHdoaWNoIG1heSBiZSBhIG51bWJlciBvciBhbiBvYmplY3QgdGhhdCBjYW4gYmVcblx0KiBjb2VyY2VkIHRvIGEgbnVtYmVyIHZpYSBgU3ltYm9sLnRvUHJpbWl0aXZlYC5cblx0KiBAcGFyYW0gY2FsbGJhY2sgLSBUaGUgZnVuY3Rpb24gdG8gY2FsbCB3aGVuIHRoZSB0aW1lb3V0IGVsYXBzZXMuXG5cdCogQHBhcmFtIGRlbGF5IC0gVGhlIHRpbWUgdG8gd2FpdCBiZWZvcmUgY2FsbGluZyBgY2FsbGJhY2tgLCBpbiBtaWxsaXNlY29uZHMuXG5cdCogQHJldHVybnMgVGhlIHRpbWVyIElELCB0byBwYXNzIHRvIHtAbGluayBUaW1lb3V0TWFuYWdlciNjbGVhclRpbWVvdXR9LlxuXHQqIEBleGFtcGxlXG5cdCogYGBgdHNcblx0KiBpbXBvcnQgeyB0aW1lb3V0TWFuYWdlciB9IGZyb20gJ0B0YW5zdGFjay9xdWVyeS1jb3JlJ1xuXHQqXG5cdCogY29uc3QgdGltZW91dElkID0gdGltZW91dE1hbmFnZXIuc2V0VGltZW91dChcblx0KiAgICgpID0+IGNvbnNvbGUubG9nKCdyYW4gYXQ6JywgbmV3IERhdGUoKSksXG5cdCogICAxMDAwLFxuXHQqIClcblx0KlxuXHQqIGNvbnN0IHRpbWVvdXRJZE51bWJlcjogbnVtYmVyID0gTnVtYmVyKHRpbWVvdXRJZClcblx0KiBgYGBcblx0Ki9cblx0c2V0VGltZW91dChjYWxsYmFjaywgZGVsYXkpIHtcblx0XHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSB0aGlzLiNwcm92aWRlckNhbGxlZCA9IHRydWU7XG5cdFx0cmV0dXJuIHRoaXMuI3Byb3ZpZGVyLnNldFRpbWVvdXQoY2FsbGJhY2ssIGRlbGF5KTtcblx0fVxuXHQvKipcblx0KiBgY2xlYXJUaW1lb3V0YCBjYW5jZWxzIGEgdGltZW91dCBjYWxsYmFjayBzY2hlZHVsZWQgd2l0aCBgc2V0VGltZW91dGAsXG5cdCogbGlrZSB0aGUgZ2xvYmFsIGBjbGVhclRpbWVvdXRgIGZ1bmN0aW9uLiBJdCBzaG91bGQgYmUgY2FsbGVkIHdpdGggYVxuXHQqIHRpbWVyIElEIHJldHVybmVkIGJ5IGBzZXRUaW1lb3V0YC5cblx0KiBAcGFyYW0gdGltZW91dElkIC0gVGhlIHRpbWVyIElEIHJldHVybmVkIGJ5IGBzZXRUaW1lb3V0YCwgb3IgYHVuZGVmaW5lZGAuXG5cdCogQGV4YW1wbGVcblx0KiBgYGB0c1xuXHQqIGltcG9ydCB7IHRpbWVvdXRNYW5hZ2VyIH0gZnJvbSAnQHRhbnN0YWNrL3F1ZXJ5LWNvcmUnXG5cdCpcblx0KiBjb25zdCB0aW1lb3V0SWQgPSB0aW1lb3V0TWFuYWdlci5zZXRUaW1lb3V0KFxuXHQqICAgKCkgPT4gY29uc29sZS5sb2coJ3JhbiBhdDonLCBuZXcgRGF0ZSgpKSxcblx0KiAgIDEwMDAsXG5cdCogKVxuXHQqXG5cdCogdGltZW91dE1hbmFnZXIuY2xlYXJUaW1lb3V0KHRpbWVvdXRJZClcblx0KiBgYGBcblx0Ki9cblx0Y2xlYXJUaW1lb3V0KHRpbWVvdXRJZCkge1xuXHRcdHRoaXMuI3Byb3ZpZGVyLmNsZWFyVGltZW91dCh0aW1lb3V0SWQpO1xuXHR9XG5cdC8qKlxuXHQqIGBzZXRJbnRlcnZhbGAgc2NoZWR1bGVzIGEgY2FsbGJhY2sgdG8gYmUgY2FsbGVkIGFwcHJveGltYXRlbHkgZXZlcnlcblx0KiBgZGVsYXlgIG1pbGxpc2Vjb25kcywgbGlrZSB0aGUgZ2xvYmFsIGBzZXRJbnRlcnZhbGAgZnVuY3Rpb24uXG5cdCpcblx0KiBMaWtlIGBzZXRUaW1lb3V0YCwgaXQgcmV0dXJucyBhIHRpbWVyIElELCB3aGljaCBtYXkgYmUgYSBudW1iZXIgb3IgYW5cblx0KiBvYmplY3QgdGhhdCBjYW4gYmUgY29lcmNlZCB0byBhIG51bWJlciB2aWEgYFN5bWJvbC50b1ByaW1pdGl2ZWAuXG5cdCogQHBhcmFtIGNhbGxiYWNrIC0gVGhlIGZ1bmN0aW9uIHRvIGNhbGwgb24gZXZlcnkgaW50ZXJ2YWwuXG5cdCogQHBhcmFtIGRlbGF5IC0gVGhlIHRpbWUgYmV0d2VlbiBjYWxscywgaW4gbWlsbGlzZWNvbmRzLlxuXHQqIEByZXR1cm5zIFRoZSB0aW1lciBJRCwgdG8gcGFzcyB0byB7QGxpbmsgVGltZW91dE1hbmFnZXIjY2xlYXJJbnRlcnZhbH0uXG5cdCogQGV4YW1wbGVcblx0KiBgYGB0c1xuXHQqIGltcG9ydCB7IHRpbWVvdXRNYW5hZ2VyIH0gZnJvbSAnQHRhbnN0YWNrL3F1ZXJ5LWNvcmUnXG5cdCpcblx0KiBjb25zdCBpbnRlcnZhbElkID0gdGltZW91dE1hbmFnZXIuc2V0SW50ZXJ2YWwoXG5cdCogICAoKSA9PiBjb25zb2xlLmxvZygncmFuIGF0OicsIG5ldyBEYXRlKCkpLFxuXHQqICAgMTAwMCxcblx0KiApXG5cdCogYGBgXG5cdCovXG5cdHNldEludGVydmFsKGNhbGxiYWNrLCBkZWxheSkge1xuXHRcdGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIHRoaXMuI3Byb3ZpZGVyQ2FsbGVkID0gdHJ1ZTtcblx0XHRyZXR1cm4gdGhpcy4jcHJvdmlkZXIuc2V0SW50ZXJ2YWwoY2FsbGJhY2ssIGRlbGF5KTtcblx0fVxuXHQvKipcblx0KiBgY2xlYXJJbnRlcnZhbGAgY2FuIGJlIHVzZWQgdG8gY2FuY2VsIGFuIGludGVydmFsLCBsaWtlIHRoZSBnbG9iYWxcblx0KiBgY2xlYXJJbnRlcnZhbGAgZnVuY3Rpb24uIEl0IHNob3VsZCBiZSBjYWxsZWQgd2l0aCBhbiBpbnRlcnZhbCBJRFxuXHQqIHJldHVybmVkIGJ5IGBzZXRJbnRlcnZhbGAuXG5cdCogQHBhcmFtIGludGVydmFsSWQgLSBUaGUgdGltZXIgSUQgcmV0dXJuZWQgYnkgYHNldEludGVydmFsYCwgb3IgYHVuZGVmaW5lZGAuXG5cdCogQGV4YW1wbGVcblx0KiBgYGB0c1xuXHQqIGltcG9ydCB7IHRpbWVvdXRNYW5hZ2VyIH0gZnJvbSAnQHRhbnN0YWNrL3F1ZXJ5LWNvcmUnXG5cdCpcblx0KiBjb25zdCBpbnRlcnZhbElkID0gdGltZW91dE1hbmFnZXIuc2V0SW50ZXJ2YWwoXG5cdCogICAoKSA9PiBjb25zb2xlLmxvZygncmFuIGF0OicsIG5ldyBEYXRlKCkpLFxuXHQqICAgMTAwMCxcblx0KiApXG5cdCpcblx0KiB0aW1lb3V0TWFuYWdlci5jbGVhckludGVydmFsKGludGVydmFsSWQpXG5cdCogYGBgXG5cdCovXG5cdGNsZWFySW50ZXJ2YWwoaW50ZXJ2YWxJZCkge1xuXHRcdHRoaXMuI3Byb3ZpZGVyLmNsZWFySW50ZXJ2YWwoaW50ZXJ2YWxJZCk7XG5cdH1cbn07XG4vKipcbiogU2luZ2xldG9uIGluc3RhbmNlIG9mIHtAbGluayBUaW1lb3V0TWFuYWdlcn0sIHVzZWQgdGhyb3VnaG91dCBUYW5TdGFjayBRdWVyeSB0byBzY2hlZHVsZSBhbmQgY2FuY2VsIHRpbWVycy5cbiovXG5jb25zdCB0aW1lb3V0TWFuYWdlciA9IG5ldyBUaW1lb3V0TWFuYWdlcigpO1xuLyoqXG4qIEluIG1hbnkgY2FzZXMgY29kZSB3YW50cyB0byBkZWxheSB0byB0aGUgbmV4dCBldmVudCBsb29wIHRpY2s7IHRoaXMgaXMgbm90XG4qIG1lZGlhdGVkIGJ5IHtAbGluayB0aW1lb3V0TWFuYWdlcn0uXG4qXG4qIFRoaXMgZnVuY3Rpb24gaXMgcHJvdmlkZWQgdG8gbWFrZSBhdWRpdGluZyB0aGUgYHRhbnN0YWNrL3F1ZXJ5LWNvcmVgIGZvclxuKiBpbmNvcnJlY3QgdXNlIG9mIHN5c3RlbSBgc2V0VGltZW91dGAgZWFzaWVyLlxuKiBAcGFyYW0gY2FsbGJhY2sgLSBUaGUgZnVuY3Rpb24gdG8gY2FsbCBvbiB0aGUgbmV4dCBldmVudCBsb29wIHRpY2suXG4qL1xuZnVuY3Rpb24gc3lzdGVtU2V0VGltZW91dFplcm8oY2FsbGJhY2spIHtcblx0c2V0VGltZW91dChjYWxsYmFjaywgMCk7XG59XG5leHBvcnQgeyBUaW1lb3V0TWFuYWdlciwgZGVmYXVsdFRpbWVvdXRQcm92aWRlciwgc3lzdGVtU2V0VGltZW91dFplcm8sIHRpbWVvdXRNYW5hZ2VyIH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXRpbWVvdXRNYW5hZ2VyLmpzLm1hcCIsImltcG9ydCB7IHRpbWVvdXRNYW5hZ2VyIH0gZnJvbSBcIi4vdGltZW91dE1hbmFnZXIuanNcIjtcbi8vIHNyYy91dGlscy50c1xuLyoqXG4qIEBkZXByZWNhdGVkIHVzZSBgZW52aXJvbm1lbnRNYW5hZ2VyLmlzU2VydmVyKClgIGluc3RlYWQuXG4qL1xuY29uc3QgaXNTZXJ2ZXIgPSB0eXBlb2Ygd2luZG93ID09PSBcInVuZGVmaW5lZFwiIHx8IFwiRGVub1wiIGluIGdsb2JhbFRoaXM7XG5mdW5jdGlvbiBub29wKCkge31cbi8qKlxuKiBSZXNvbHZlcyBhbiB7QGxpbmsgVXBkYXRlcn06IGNhbGxzIGl0IHdpdGggYGlucHV0YCBpZiBpdCBpcyBhIGZ1bmN0aW9uLCBvdGhlcndpc2UgcmV0dXJucyBpdCBhc1xuKiBpcy5cbiogQHBhcmFtIHVwZGF0ZXIgLSBUaGUgbmV3IHZhbHVlLCBvciBhIGZ1bmN0aW9uIHRoYXQgcmVjZWl2ZXMgYGlucHV0YCBhbmQgcmV0dXJucyB0aGUgbmV3IHZhbHVlLlxuKiBAcGFyYW0gaW5wdXQgLSBUaGUgY3VycmVudCB2YWx1ZSwgcGFzc2VkIHRvIGB1cGRhdGVyYCBpZiBpdCBpcyBhIGZ1bmN0aW9uLlxuKiBAcmV0dXJucyBUaGUgbmV3IHZhbHVlLlxuKi9cbmZ1bmN0aW9uIGZ1bmN0aW9uYWxVcGRhdGUodXBkYXRlciwgaW5wdXQpIHtcblx0cmV0dXJuIHR5cGVvZiB1cGRhdGVyID09PSBcImZ1bmN0aW9uXCIgPyB1cGRhdGVyKGlucHV0KSA6IHVwZGF0ZXI7XG59XG4vKipcbiogQ2hlY2tzIHdoZXRoZXIgYSB2YWx1ZSBjYW4gYmUgdXNlZCBhcyBhIHRpbWVvdXQ6IGEgbm9uLW5lZ2F0aXZlLCBmaW5pdGUgbnVtYmVyLlxuKiBAcGFyYW0gdmFsdWUgLSBUaGUgdmFsdWUgdG8gY2hlY2suXG4qIEByZXR1cm5zIGB0cnVlYCBpZiBgdmFsdWVgIGlzIGEgbnVtYmVyIHRoYXQgaXMgYD49IDBgIGFuZCBub3QgYEluZmluaXR5YC5cbiovXG5mdW5jdGlvbiBpc1ZhbGlkVGltZW91dCh2YWx1ZSkge1xuXHRyZXR1cm4gdHlwZW9mIHZhbHVlID09PSBcIm51bWJlclwiICYmIHZhbHVlID49IDAgJiYgdmFsdWUgIT09IEluZmluaXR5O1xufVxuLyoqXG4qIENhbGN1bGF0ZXMgaG93IGxvbmcgdW50aWwgZGF0YSB1cGRhdGVkIGF0IGB1cGRhdGVkQXRgIGJlY29tZXMgc3RhbGUuXG4qIEBwYXJhbSB1cGRhdGVkQXQgLSBUaGUgdGltZXN0YW1wLCBpbiBtaWxsaXNlY29uZHMsIGF0IHdoaWNoIHRoZSBkYXRhIHdhcyBsYXN0IHVwZGF0ZWQuXG4qIEBwYXJhbSBzdGFsZVRpbWUgLSBUaGUgdGltZSwgaW4gbWlsbGlzZWNvbmRzLCBhZnRlciB3aGljaCBkYXRhIGlzIGNvbnNpZGVyZWQgc3RhbGUuIERlZmF1bHRzIHRvXG4qIGAwYC5cbiogQHJldHVybnMgVGhlIHJlbWFpbmluZyB0aW1lIGluIG1pbGxpc2Vjb25kcywgb3IgYDBgIGlmIHRoZSBkYXRhIGlzIGFscmVhZHkgc3RhbGUuXG4qL1xuZnVuY3Rpb24gdGltZVVudGlsU3RhbGUodXBkYXRlZEF0LCBzdGFsZVRpbWUpIHtcblx0cmV0dXJuIE1hdGgubWF4KHVwZGF0ZWRBdCArIChzdGFsZVRpbWUgfHwgMCkgLSBEYXRlLm5vdygpLCAwKTtcbn1cbi8qKlxuKiBSZXNvbHZlcyBhbiBvcHRpb24gdGhhdCBjYW4gYmUgZ2l2ZW4gZWl0aGVyIGFzIGEgdmFsdWUgb3IgYXMgYSBmdW5jdGlvbiBvZiB0aGUgcXVlcnksIHN1Y2ggYXNcbiogYHN0YWxlVGltZWAuXG4qIEBwYXJhbSB2YWx1ZSAtIFRoZSBvcHRpb24gdmFsdWUsIG9yIGEgZnVuY3Rpb24gdGhhdCByZWNlaXZlcyBgcXVlcnlgIGFuZCByZXR1cm5zIHRoZSB2YWx1ZS5cbiogQHBhcmFtIHF1ZXJ5IC0gVGhlIHF1ZXJ5IHBhc3NlZCB0byBgdmFsdWVgIGlmIGl0IGlzIGEgZnVuY3Rpb24uXG4qIEByZXR1cm5zIFRoZSByZXNvbHZlZCB2YWx1ZSwgb3IgYHVuZGVmaW5lZGAgaWYgYHZhbHVlYCBpcyBgdW5kZWZpbmVkYC5cbiovXG5mdW5jdGlvbiByZXNvbHZlUXVlcnlWYWx1ZSh2YWx1ZSwgcXVlcnkpIHtcblx0cmV0dXJuIHR5cGVvZiB2YWx1ZSA9PT0gXCJmdW5jdGlvblwiID8gdmFsdWUocXVlcnkpIDogdmFsdWU7XG59XG4vKipcbiogQ2hlY2tzIHdoZXRoZXIgYSBxdWVyeSBtYXRjaGVzIHRoZSBnaXZlbiB7QGxpbmsgUXVlcnlGaWx0ZXJzfS5cbiogRXZlcnkgZmlsdGVyIHRoYXQgaXMgc3BlY2lmaWVkIG11c3QgbWF0Y2g7IGZpbHRlcnMgdGhhdCBhcmUgbGVmdCB1bnNwZWNpZmllZCBhcmUgaWdub3JlZC5cbiogQHBhcmFtIGZpbHRlcnMgLSBUaGUgZmlsdGVycyB0byBjaGVjayB0aGUgcXVlcnkgYWdhaW5zdC5cbiogQHBhcmFtIHF1ZXJ5IC0gVGhlIHF1ZXJ5IHRvIGNoZWNrLlxuKiBAcmV0dXJucyBgdHJ1ZWAgaWYgdGhlIHF1ZXJ5IG1hdGNoZXMgZXZlcnkgc3BlY2lmaWVkIGZpbHRlci5cbiogQGV4YW1wbGVcbiogYGBgdHNcbiogY29uc3QgcXVlcnlDYWNoZSA9IHF1ZXJ5Q2xpZW50LmdldFF1ZXJ5Q2FjaGUoKVxuKlxuKiBjb25zdCBtYXRjaGluZ1F1ZXJpZXMgPSBxdWVyeUNhY2hlXG4qICAgLmdldEFsbCgpXG4qICAgLmZpbHRlcigocXVlcnkpID0+IG1hdGNoUXVlcnkoeyBxdWVyeUtleTogWydwb3N0cyddIH0sIHF1ZXJ5KSlcbiogYGBgXG4qL1xuZnVuY3Rpb24gbWF0Y2hRdWVyeShmaWx0ZXJzLCBxdWVyeSkge1xuXHRjb25zdCB7IHR5cGUgPSBcImFsbFwiLCBleGFjdCwgZmV0Y2hTdGF0dXMsIHByZWRpY2F0ZSwgcXVlcnlLZXksIHN0YWxlIH0gPSBmaWx0ZXJzO1xuXHRpZiAocXVlcnlLZXkpIHtcblx0XHRpZiAoZXhhY3QpIHtcblx0XHRcdGlmIChxdWVyeS5xdWVyeUhhc2ggIT09IGhhc2hRdWVyeUtleUJ5T3B0aW9ucyhxdWVyeUtleSwgcXVlcnkub3B0aW9ucykpIHJldHVybiBmYWxzZTtcblx0XHR9IGVsc2UgaWYgKCFwYXJ0aWFsTWF0Y2hLZXkocXVlcnkucXVlcnlLZXksIHF1ZXJ5S2V5KSkgcmV0dXJuIGZhbHNlO1xuXHR9XG5cdGlmICh0eXBlICE9PSBcImFsbFwiKSB7XG5cdFx0Y29uc3QgaXNBY3RpdmUgPSBxdWVyeS5pc0FjdGl2ZSgpO1xuXHRcdGlmICh0eXBlID09PSBcImFjdGl2ZVwiICYmICFpc0FjdGl2ZSkgcmV0dXJuIGZhbHNlO1xuXHRcdGlmICh0eXBlID09PSBcImluYWN0aXZlXCIgJiYgaXNBY3RpdmUpIHJldHVybiBmYWxzZTtcblx0fVxuXHRpZiAodHlwZW9mIHN0YWxlID09PSBcImJvb2xlYW5cIiAmJiBxdWVyeS5pc1N0YWxlKCkgIT09IHN0YWxlKSByZXR1cm4gZmFsc2U7XG5cdGlmIChmZXRjaFN0YXR1cyAmJiBmZXRjaFN0YXR1cyAhPT0gcXVlcnkuc3RhdGUuZmV0Y2hTdGF0dXMpIHJldHVybiBmYWxzZTtcblx0aWYgKHByZWRpY2F0ZSAmJiAhcHJlZGljYXRlKHF1ZXJ5KSkgcmV0dXJuIGZhbHNlO1xuXHRyZXR1cm4gdHJ1ZTtcbn1cbi8qKlxuKiBDaGVja3Mgd2hldGhlciBhIG11dGF0aW9uIG1hdGNoZXMgdGhlIGdpdmVuIHtAbGluayBNdXRhdGlvbkZpbHRlcnN9LlxuKiBFdmVyeSBmaWx0ZXIgdGhhdCBpcyBzcGVjaWZpZWQgbXVzdCBtYXRjaDsgZmlsdGVycyB0aGF0IGFyZSBsZWZ0IHVuc3BlY2lmaWVkIGFyZSBpZ25vcmVkLlxuKiBJZiBhIGBtdXRhdGlvbktleWAgZmlsdGVyIGlzIHByb3ZpZGVkIGJ1dCB0aGUgbXV0YXRpb24gaGFzIG5vIGBtdXRhdGlvbktleWAgb2YgaXRzIG93biwgaXQgZG9lcyBub3QgbWF0Y2guXG4qIEBwYXJhbSBmaWx0ZXJzIC0gVGhlIGZpbHRlcnMgdG8gY2hlY2sgdGhlIG11dGF0aW9uIGFnYWluc3QuXG4qIEBwYXJhbSBtdXRhdGlvbiAtIFRoZSBtdXRhdGlvbiB0byBjaGVjay5cbiogQHJldHVybnMgYHRydWVgIGlmIHRoZSBtdXRhdGlvbiBtYXRjaGVzIGV2ZXJ5IHNwZWNpZmllZCBmaWx0ZXIuXG4qIEBleGFtcGxlXG4qIGBgYHRzXG4qIGNvbnN0IG11dGF0aW9uQ2FjaGUgPSBxdWVyeUNsaWVudC5nZXRNdXRhdGlvbkNhY2hlKClcbipcbiogY29uc3QgbWF0Y2hpbmdNdXRhdGlvbnMgPSBtdXRhdGlvbkNhY2hlXG4qICAgLmdldEFsbCgpXG4qICAgLmZpbHRlcigobXV0YXRpb24pID0+IG1hdGNoTXV0YXRpb24oeyBtdXRhdGlvbktleTogWydhZGRQb3N0J10gfSwgbXV0YXRpb24pKVxuKiBgYGBcbiovXG5mdW5jdGlvbiBtYXRjaE11dGF0aW9uKGZpbHRlcnMsIG11dGF0aW9uKSB7XG5cdGNvbnN0IHsgZXhhY3QsIHN0YXR1cywgcHJlZGljYXRlLCBtdXRhdGlvbktleSB9ID0gZmlsdGVycztcblx0aWYgKG11dGF0aW9uS2V5KSB7XG5cdFx0aWYgKCFtdXRhdGlvbi5vcHRpb25zLm11dGF0aW9uS2V5KSByZXR1cm4gZmFsc2U7XG5cdFx0aWYgKGV4YWN0KSB7XG5cdFx0XHRpZiAoaGFzaEtleShtdXRhdGlvbi5vcHRpb25zLm11dGF0aW9uS2V5KSAhPT0gaGFzaEtleShtdXRhdGlvbktleSkpIHJldHVybiBmYWxzZTtcblx0XHR9IGVsc2UgaWYgKCFwYXJ0aWFsTWF0Y2hLZXkobXV0YXRpb24ub3B0aW9ucy5tdXRhdGlvbktleSwgbXV0YXRpb25LZXkpKSByZXR1cm4gZmFsc2U7XG5cdH1cblx0aWYgKHN0YXR1cyAmJiBtdXRhdGlvbi5zdGF0ZS5zdGF0dXMgIT09IHN0YXR1cykgcmV0dXJuIGZhbHNlO1xuXHRpZiAocHJlZGljYXRlICYmICFwcmVkaWNhdGUobXV0YXRpb24pKSByZXR1cm4gZmFsc2U7XG5cdHJldHVybiB0cnVlO1xufVxuLyoqXG4qIEhhc2hlcyBhIHF1ZXJ5IGtleSB3aXRoIHRoZSBxdWVyeSdzIGBxdWVyeUtleUhhc2hGbmAgb3B0aW9uLCBmYWxsaW5nIGJhY2sgdG8ge0BsaW5rIGhhc2hLZXl9LlxuKiBAcGFyYW0gcXVlcnlLZXkgLSBUaGUgcXVlcnkga2V5IHRvIGhhc2guXG4qIEBwYXJhbSBvcHRpb25zIC0gVGhlIHF1ZXJ5IG9wdGlvbnMgdGhhdCBtYXkgcHJvdmlkZSBhIGN1c3RvbSBgcXVlcnlLZXlIYXNoRm5gLlxuKiBAcmV0dXJucyBUaGUgcXVlcnkgaGFzaCwgYSBzdHJpbmcgdGhhdCBpZGVudGlmaWVzIHRoZSBxdWVyeSBpbiB0aGUgY2FjaGUuXG4qL1xuZnVuY3Rpb24gaGFzaFF1ZXJ5S2V5QnlPcHRpb25zKHF1ZXJ5S2V5LCBvcHRpb25zKSB7XG5cdHJldHVybiAob3B0aW9ucz8ucXVlcnlLZXlIYXNoRm4gfHwgaGFzaEtleSkocXVlcnlLZXkpO1xufVxuLyoqXG4qIERlZmF1bHQgcXVlcnkgJiBtdXRhdGlvbiBrZXlzIGhhc2ggZnVuY3Rpb24uXG4qIEhhc2hlcyB0aGUgdmFsdWUgaW50byBhIHN0YWJsZSBoYXNoLlxuKiBAcGFyYW0gcXVlcnlLZXkgLSBUaGUgcXVlcnkgb3IgbXV0YXRpb24ga2V5IHRvIGhhc2guXG4qIEByZXR1cm5zIFRoZSBzdGFibGUgaGFzaCBvZiB0aGUga2V5LCBhcyBhIEpTT04gc3RyaW5nLlxuKiBAZXhhbXBsZVxuKiBgYGB0c1xuKiAvLyBPYmplY3Qga2V5cyBhcmUgc29ydGVkLCBzbyBrZXkgb3JkZXIgZG9lc24ndCBhZmZlY3QgdGhlIGhhc2g6XG4qIGhhc2hLZXkoWyd0b2RvcycsIHsgcGFnZTogMSwgZmlsdGVyOiAnZG9uZScgfV0pIC8vID09PSAnW1widG9kb3NcIix7XCJmaWx0ZXJcIjpcImRvbmVcIixcInBhZ2VcIjoxfV0nXG4qIGBgYFxuKi9cbmZ1bmN0aW9uIGhhc2hLZXkocXVlcnlLZXkpIHtcblx0cmV0dXJuIEpTT04uc3RyaW5naWZ5KHF1ZXJ5S2V5LCAoXywgdmFsKSA9PiBpc1BsYWluT2JqZWN0KHZhbCkgPyBPYmplY3Qua2V5cyh2YWwpLnNvcnQoKS5yZWR1Y2UoKHJlc3VsdCwga2V5KSA9PiB7XG5cdFx0cmVzdWx0W2tleV0gPSB2YWxba2V5XTtcblx0XHRyZXR1cm4gcmVzdWx0O1xuXHR9LCB7fSkgOiB2YWwpO1xufVxuZnVuY3Rpb24gcGFydGlhbE1hdGNoS2V5KGEsIGIpIHtcblx0aWYgKGEgPT09IGIpIHJldHVybiB0cnVlO1xuXHRpZiAodHlwZW9mIGEgIT09IHR5cGVvZiBiKSByZXR1cm4gZmFsc2U7XG5cdGlmIChhICYmIGIgJiYgdHlwZW9mIGEgPT09IFwib2JqZWN0XCIgJiYgdHlwZW9mIGIgPT09IFwib2JqZWN0XCIpIHtcblx0XHRpZiAoQXJyYXkuaXNBcnJheShhKSAmJiBBcnJheS5pc0FycmF5KGIpKSB7XG5cdFx0XHRpZiAoYi5sZW5ndGggPiBhLmxlbmd0aCkgcmV0dXJuIGZhbHNlO1xuXHRcdFx0Zm9yIChsZXQgaSA9IDA7IGkgPCBiLmxlbmd0aDsgaSsrKSBpZiAoIXBhcnRpYWxNYXRjaEtleShhW2ldLCBiW2ldKSkgcmV0dXJuIGZhbHNlO1xuXHRcdFx0cmV0dXJuIHRydWU7XG5cdFx0fVxuXHRcdGNvbnN0IGJLZXlzID0gT2JqZWN0LmtleXMoYik7XG5cdFx0Zm9yIChjb25zdCBrZXkgb2YgYktleXMpIGlmICghcGFydGlhbE1hdGNoS2V5KGFba2V5XSwgYltrZXldKSkgcmV0dXJuIGZhbHNlO1xuXHRcdHJldHVybiB0cnVlO1xuXHR9XG5cdHJldHVybiBmYWxzZTtcbn1cbmNvbnN0IGhhc093biA9IE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHk7XG5mdW5jdGlvbiByZXBsYWNlRXF1YWxEZWVwKGEsIGIsIGRlcHRoID0gMCkge1xuXHRpZiAoYSA9PT0gYikgcmV0dXJuIGE7XG5cdGlmIChkZXB0aCA+IDUwMCkgcmV0dXJuIGI7XG5cdGNvbnN0IGFycmF5ID0gaXNQbGFpbkFycmF5KGEpICYmIGlzUGxhaW5BcnJheShiKTtcblx0aWYgKCFhcnJheSAmJiAhKGlzUGxhaW5PYmplY3QoYSkgJiYgaXNQbGFpbk9iamVjdChiKSkpIHJldHVybiBiO1xuXHRjb25zdCBhU2l6ZSA9IChhcnJheSA/IGEgOiBPYmplY3Qua2V5cyhhKSkubGVuZ3RoO1xuXHRjb25zdCBiSXRlbXMgPSBhcnJheSA/IGIgOiBPYmplY3Qua2V5cyhiKTtcblx0Y29uc3QgYlNpemUgPSBiSXRlbXMubGVuZ3RoO1xuXHRjb25zdCBjb3B5ID0gYXJyYXkgPyBuZXcgQXJyYXkoYlNpemUpIDoge307XG5cdGxldCBlcXVhbEl0ZW1zID0gMDtcblx0Zm9yIChsZXQgaSA9IDA7IGkgPCBiU2l6ZTsgaSsrKSB7XG5cdFx0Y29uc3Qga2V5ID0gYXJyYXkgPyBpIDogYkl0ZW1zW2ldO1xuXHRcdGNvbnN0IGFJdGVtID0gYVtrZXldO1xuXHRcdGNvbnN0IGJJdGVtID0gYltrZXldO1xuXHRcdGlmIChhSXRlbSA9PT0gYkl0ZW0pIHtcblx0XHRcdGNvcHlba2V5XSA9IGFJdGVtO1xuXHRcdFx0aWYgKGFycmF5ID8gaSA8IGFTaXplIDogaGFzT3duLmNhbGwoYSwga2V5KSkgZXF1YWxJdGVtcysrO1xuXHRcdFx0Y29udGludWU7XG5cdFx0fVxuXHRcdGlmIChhSXRlbSA9PT0gbnVsbCB8fCBiSXRlbSA9PT0gbnVsbCB8fCB0eXBlb2YgYUl0ZW0gIT09IFwib2JqZWN0XCIgfHwgdHlwZW9mIGJJdGVtICE9PSBcIm9iamVjdFwiKSB7XG5cdFx0XHRjb3B5W2tleV0gPSBiSXRlbTtcblx0XHRcdGNvbnRpbnVlO1xuXHRcdH1cblx0XHRjb25zdCB2ID0gcmVwbGFjZUVxdWFsRGVlcChhSXRlbSwgYkl0ZW0sIGRlcHRoICsgMSk7XG5cdFx0Y29weVtrZXldID0gdjtcblx0XHRpZiAodiA9PT0gYUl0ZW0pIGVxdWFsSXRlbXMrKztcblx0fVxuXHRyZXR1cm4gYVNpemUgPT09IGJTaXplICYmIGVxdWFsSXRlbXMgPT09IGFTaXplID8gYSA6IGNvcHk7XG59XG4vKipcbiogU2hhbGxvdyBjb21wYXJlIG9iamVjdHMuXG4qIEBwYXJhbSBhIC0gVGhlIGZpcnN0IG9iamVjdC5cbiogQHBhcmFtIGIgLSBUaGUgc2Vjb25kIG9iamVjdCwgb3IgYHVuZGVmaW5lZGAuXG4qIEByZXR1cm5zIGB0cnVlYCBpZiBib3RoIG9iamVjdHMgaGF2ZSB0aGUgc2FtZSBrZXlzLCB3aXRoIHN0cmljdGx5IGVxdWFsIHZhbHVlcyBmb3IgZWFjaCBrZXkuXG4qL1xuZnVuY3Rpb24gc2hhbGxvd0VxdWFsT2JqZWN0cyhhLCBiKSB7XG5cdGlmICghYiB8fCBPYmplY3Qua2V5cyhhKS5sZW5ndGggIT09IE9iamVjdC5rZXlzKGIpLmxlbmd0aCkgcmV0dXJuIGZhbHNlO1xuXHRmb3IgKGNvbnN0IGtleSBvZiBPYmplY3Qua2V5cyhhKSkgaWYgKCFoYXNPd24uY2FsbChiLCBrZXkpIHx8IGFba2V5XSAhPT0gYltrZXldKSByZXR1cm4gZmFsc2U7XG5cdHJldHVybiB0cnVlO1xufVxuLyoqXG4qIENoZWNrcyB3aGV0aGVyIGEgdmFsdWUgaXMgYW4gYXJyYXkgd2l0aCBubyBob2xlcyBhbmQgbm8gZXh0cmEgcHJvcGVydGllcy5cbiogQHBhcmFtIHZhbHVlIC0gVGhlIHZhbHVlIHRvIGNoZWNrLlxuKiBAcmV0dXJucyBgdHJ1ZWAgaWYgYHZhbHVlYCBpcyBhbiBhcnJheSB3aG9zZSBudW1iZXIgb2Ygb3duIGtleXMgZXF1YWxzIGl0cyBgbGVuZ3RoYC5cbiovXG5mdW5jdGlvbiBpc1BsYWluQXJyYXkodmFsdWUpIHtcblx0cmV0dXJuIEFycmF5LmlzQXJyYXkodmFsdWUpICYmIHZhbHVlLmxlbmd0aCA9PT0gT2JqZWN0LmtleXModmFsdWUpLmxlbmd0aDtcbn1cbi8qKlxuKiBDaGVja3Mgd2hldGhlciBhIHZhbHVlIGlzIGEgcGxhaW4gb2JqZWN0LCBlLmcuIGNyZWF0ZWQgd2l0aCBhbiBvYmplY3QgbGl0ZXJhbCBvclxuKiBgT2JqZWN0LmNyZWF0ZShudWxsKWAuXG4qIEBwYXJhbSBvIC0gVGhlIHZhbHVlIHRvIGNoZWNrLlxuKiBAcmV0dXJucyBgdHJ1ZWAgaWYgYG9gIGlzIGEgcGxhaW4gb2JqZWN0LlxuKi9cbmZ1bmN0aW9uIGlzUGxhaW5PYmplY3Qobykge1xuXHRpZiAoIWhhc09iamVjdFByb3RvdHlwZShvKSkgcmV0dXJuIGZhbHNlO1xuXHRjb25zdCBvYmplY3RQcm90b3R5cGUgPSBPYmplY3QuZ2V0UHJvdG90eXBlT2Yobyk7XG5cdGNvbnN0IGN0b3IgPSBvYmplY3RQcm90b3R5cGU/LmNvbnN0cnVjdG9yO1xuXHRpZiAoY3RvciA9PT0gdm9pZCAwKSByZXR1cm4gdHJ1ZTtcblx0aWYgKHR5cGVvZiBjdG9yICE9PSBcImZ1bmN0aW9uXCIpIHJldHVybiBmYWxzZTtcblx0Y29uc3QgcHJvdCA9IGN0b3IucHJvdG90eXBlO1xuXHRpZiAoIWhhc09iamVjdFByb3RvdHlwZShwcm90KSkgcmV0dXJuIGZhbHNlO1xuXHRpZiAoIXByb3QuaGFzT3duUHJvcGVydHkoXCJpc1Byb3RvdHlwZU9mXCIpKSByZXR1cm4gZmFsc2U7XG5cdGlmIChvYmplY3RQcm90b3R5cGUgIT09IE9iamVjdC5wcm90b3R5cGUpIHJldHVybiBmYWxzZTtcblx0cmV0dXJuIHRydWU7XG59XG4vKipcbiogQ2hlY2tzIHdoZXRoZXIgYSB2YWx1ZSdzIGBPYmplY3QucHJvdG90eXBlLnRvU3RyaW5nYCB0YWcgaXMgYFtvYmplY3QgT2JqZWN0XWAuXG4qIEBwYXJhbSBvIC0gVGhlIHZhbHVlIHRvIGNoZWNrLlxuKiBAcmV0dXJucyBgdHJ1ZWAgaWYgdGhlIHRhZyBpcyBgW29iamVjdCBPYmplY3RdYC5cbiovXG5mdW5jdGlvbiBoYXNPYmplY3RQcm90b3R5cGUobykge1xuXHRyZXR1cm4gT2JqZWN0LnByb3RvdHlwZS50b1N0cmluZy5jYWxsKG8pID09PSBcIltvYmplY3QgT2JqZWN0XVwiO1xufVxuLyoqXG4qIFdhaXRzIGZvciB0aGUgZ2l2ZW4gdGltZSwgdXNpbmcgdGhlIGNvbmZpZ3VyZWQge0BsaW5rIHRpbWVvdXRNYW5hZ2VyfS5cbiogQHBhcmFtIHRpbWVvdXQgLSBUaGUgdGltZSB0byB3YWl0LCBpbiBtaWxsaXNlY29uZHMuXG4qIEByZXR1cm5zIEEgcHJvbWlzZSB0aGF0IHJlc29sdmVzIGFmdGVyIGB0aW1lb3V0YCBtaWxsaXNlY29uZHMuXG4qL1xuZnVuY3Rpb24gc2xlZXAodGltZW91dCkge1xuXHRyZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUpID0+IHtcblx0XHR0aW1lb3V0TWFuYWdlci5zZXRUaW1lb3V0KHJlc29sdmUsIHRpbWVvdXQpO1xuXHR9KTtcbn1cbi8qKlxuKiBBcHBsaWVzIGEgcXVlcnkncyBgc3RydWN0dXJhbFNoYXJpbmdgIG9wdGlvbiB3aGVuIHdyaXRpbmcgbmV3IGRhdGEuXG4qIEBwYXJhbSBwcmV2RGF0YSAtIFRoZSBwcmV2aW91c2x5IGNhY2hlZCBkYXRhLlxuKiBAcGFyYW0gZGF0YSAtIFRoZSBuZXcgZGF0YS5cbiogQHBhcmFtIG9wdGlvbnMgLSBUaGUgcXVlcnkgb3B0aW9ucywgd2hvc2UgYHN0cnVjdHVyYWxTaGFyaW5nYCBkZWNpZGVzIGhvdyB0aGUgZGF0YSBpcyBtZXJnZWQuXG4qIEByZXR1cm5zIFRoZSByZXN1bHQgb2YgYSBjdXN0b20gYHN0cnVjdHVyYWxTaGFyaW5nYCBmdW5jdGlvbiwgYGRhdGFgIHdpdGggaXRzIHVuY2hhbmdlZCBwYXJ0c1xuKiByZXBsYWNlZCBieSB0aG9zZSBvZiBgcHJldkRhdGFgIGJ5IGRlZmF1bHQsIG9yIGBkYXRhYCBhcyBpcyBpZiBgc3RydWN0dXJhbFNoYXJpbmdgIGlzIGBmYWxzZWAuXG4qIEB0aHJvd3Mge0Vycm9yfSBUaGUgZXJyb3IgZnJvbSB0aGUgZGVmYXVsdCBzdHJ1Y3R1cmFsIHNoYXJpbmcsIGUuZy4gd2hlbiB0aGUgZGF0YSBpcyBub3QgSlNPTiBzZXJpYWxpemFibGUuXG4qIE91dHNpZGUgcHJvZHVjdGlvbiwgaXQgaXMgYWxzbyBsb2dnZWQgdG8gdGhlIGNvbnNvbGUuXG4qL1xuZnVuY3Rpb24gcmVwbGFjZURhdGEocHJldkRhdGEsIGRhdGEsIG9wdGlvbnMpIHtcblx0aWYgKHR5cGVvZiBvcHRpb25zLnN0cnVjdHVyYWxTaGFyaW5nID09PSBcImZ1bmN0aW9uXCIpIHJldHVybiBvcHRpb25zLnN0cnVjdHVyYWxTaGFyaW5nKHByZXZEYXRhLCBkYXRhKTtcblx0ZWxzZSBpZiAob3B0aW9ucy5zdHJ1Y3R1cmFsU2hhcmluZyAhPT0gZmFsc2UpIHtcblx0XHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSB0cnkge1xuXHRcdFx0cmV0dXJuIHJlcGxhY2VFcXVhbERlZXAocHJldkRhdGEsIGRhdGEpO1xuXHRcdH0gY2F0Y2ggKGVycm9yKSB7XG5cdFx0XHRjb25zb2xlLmVycm9yKGBTdHJ1Y3R1cmFsIHNoYXJpbmcgcmVxdWlyZXMgZGF0YSB0byBiZSBKU09OIHNlcmlhbGl6YWJsZS4gVG8gZml4IHRoaXMsIHR1cm4gb2ZmIHN0cnVjdHVyYWxTaGFyaW5nIG9yIHJldHVybiBKU09OLXNlcmlhbGl6YWJsZSBkYXRhIGZyb20geW91ciBxdWVyeUZuLiBbJHtvcHRpb25zLnF1ZXJ5SGFzaH1dOiAke2Vycm9yfWApO1xuXHRcdFx0dGhyb3cgZXJyb3I7XG5cdFx0fVxuXHRcdHJldHVybiByZXBsYWNlRXF1YWxEZWVwKHByZXZEYXRhLCBkYXRhKTtcblx0fVxuXHRyZXR1cm4gZGF0YTtcbn1cbi8qKlxuKiBJbnRlbmRlZCB0byBiZSBwYXNzZWQgYXMgYSBxdWVyeSdzIGBwbGFjZWhvbGRlckRhdGFgIG9wdGlvbiwgZm9yIGV4YW1wbGVcbiogYHBsYWNlaG9sZGVyRGF0YToga2VlcFByZXZpb3VzRGF0YWAuIEluc3RlYWQgb2YgcmVzZXR0aW5nIHRoZSBxdWVyeSdzIGRhdGEgdG8gYHVuZGVmaW5lZGAgd2hpbGUgYSBuZXdcbiogcXVlcnkga2V5IGlzIGZldGNoaW5nLCBpdCBrZWVwcyBkaXNwbGF5aW5nIHRoZSBwcmV2aW91c2x5IGZldGNoZWQgZGF0YSB1bnRpbCB0aGUgbmV3IGRhdGEgYXJyaXZlcy5cbiogQHBhcmFtIHByZXZpb3VzRGF0YSAtIFRoZSBkYXRhIG9mIHRoZSBwcmV2aW91cyBxdWVyeSBrZXksIHBhc3NlZCBieSB0aGUgb2JzZXJ2ZXIuXG4qIEByZXR1cm5zIFRoZSBwcmV2aW91cyBkYXRhLCB1bmNoYW5nZWQuXG4qIEBleGFtcGxlXG4qIGBgYHRzXG4qIG5ldyBRdWVyeU9ic2VydmVyKHF1ZXJ5Q2xpZW50LCB7XG4qICAgcXVlcnlLZXk6IFsncG9zdHMnLCBwYWdlXSxcbiogICBxdWVyeUZuOiAoKSA9PiBmZXRjaFBvc3RzKHBhZ2UpLFxuKiAgIHBsYWNlaG9sZGVyRGF0YToga2VlcFByZXZpb3VzRGF0YSxcbiogfSlcbiogYGBgXG4qL1xuZnVuY3Rpb24ga2VlcFByZXZpb3VzRGF0YShwcmV2aW91c0RhdGEpIHtcblx0cmV0dXJuIHByZXZpb3VzRGF0YTtcbn1cbi8qKlxuKiBSZXR1cm5zIGEgbmV3IGFycmF5IHdpdGggYGl0ZW1gIGFkZGVkIGF0IHRoZSBlbmQuIElmIHRoYXQgbWFrZXMgdGhlIGFycmF5IGxvbmdlciB0aGFuIGBtYXhgLFxuKiBleGNlc3MgaXRlbXMgYXJlIHJlbW92ZWQgZnJvbSB0aGUgc3RhcnQuXG4qIEBwYXJhbSBpdGVtcyAtIFRoZSBjdXJyZW50IGl0ZW1zLlxuKiBAcGFyYW0gaXRlbSAtIFRoZSB2YWx1ZSB0byBhcHBlbmQuXG4qIEBwYXJhbSBtYXggLSBUaGUgbWF4aW11bSBudW1iZXIgb2YgaXRlbXMgdG8ga2VlcC4gYDBgICh0aGUgZGVmYXVsdCkgbWVhbnMgbm8gbGltaXQuXG4qIEByZXR1cm5zIEEgbmV3IGFycmF5IHdpdGggYGl0ZW1gIGFkZGVkLlxuKi9cbmZ1bmN0aW9uIGFkZFRvRW5kKGl0ZW1zLCBpdGVtLCBtYXggPSAwKSB7XG5cdGNvbnN0IG5ld0l0ZW1zID0gWy4uLml0ZW1zLCBpdGVtXTtcblx0cmV0dXJuIG1heCAmJiBuZXdJdGVtcy5sZW5ndGggPiBtYXggPyBuZXdJdGVtcy5zbGljZSgtbWF4KSA6IG5ld0l0ZW1zO1xufVxuLyoqXG4qIFJldHVybnMgYSBuZXcgYXJyYXkgd2l0aCBgaXRlbWAgYWRkZWQgYXQgdGhlIHN0YXJ0LiBJZiB0aGF0IG1ha2VzIHRoZSBhcnJheSBsb25nZXIgdGhhbiBgbWF4YCxcbiogZXhjZXNzIGl0ZW1zIGFyZSByZW1vdmVkIGZyb20gdGhlIGVuZC5cbiogQHBhcmFtIGl0ZW1zIC0gVGhlIGN1cnJlbnQgaXRlbXMuXG4qIEBwYXJhbSBpdGVtIC0gVGhlIHZhbHVlIHRvIHByZXBlbmQuXG4qIEBwYXJhbSBtYXggLSBUaGUgbWF4aW11bSBudW1iZXIgb2YgaXRlbXMgdG8ga2VlcC4gYDBgICh0aGUgZGVmYXVsdCkgbWVhbnMgbm8gbGltaXQuXG4qIEByZXR1cm5zIEEgbmV3IGFycmF5IHdpdGggYGl0ZW1gIGFkZGVkLlxuKi9cbmZ1bmN0aW9uIGFkZFRvU3RhcnQoaXRlbXMsIGl0ZW0sIG1heCA9IDApIHtcblx0Y29uc3QgbmV3SXRlbXMgPSBbaXRlbSwgLi4uaXRlbXNdO1xuXHRyZXR1cm4gbWF4ICYmIG5ld0l0ZW1zLmxlbmd0aCA+IG1heCA/IG5ld0l0ZW1zLnNsaWNlKDAsIG1heCkgOiBuZXdJdGVtcztcbn1cbi8qKlxuKiBTZW50aW5lbCB2YWx1ZSB0aGF0IGNhbiBiZSBwYXNzZWQgYXMgYSBxdWVyeSdzIGBxdWVyeUZuYCB0byBjb25kaXRpb25hbGx5IGRpc2FibGUgdGhlIHF1ZXJ5IChlcXVpdmFsZW50XG4qIHRvIGBlbmFibGVkOiBmYWxzZWApIHdoaWxlIHByZXNlcnZpbmcgZnVsbCB0eXBlIGluZmVyZW5jZSBmb3IgdGhlIHF1ZXJ5J3MgZGF0YS4gVW5saWtlIGBlbmFibGVkOiBmYWxzZWAsXG4qIGEgcXVlcnkgZGlzYWJsZWQgdmlhIGBza2lwVG9rZW5gIGNhbm5vdCBiZSB0cmlnZ2VyZWQgd2l0aCBgcmVmZXRjaGAuXG4qIEBleGFtcGxlXG4qIGBgYHRzXG4qIG5ldyBRdWVyeU9ic2VydmVyKHF1ZXJ5Q2xpZW50LCB7XG4qICAgcXVlcnlLZXk6IFsncG9zdCcsIHBvc3RJZF0sXG4qICAgcXVlcnlGbjogcG9zdElkICE9IG51bGwgPyAoKSA9PiBmZXRjaFBvc3QocG9zdElkKSA6IHNraXBUb2tlbixcbiogfSlcbiogYGBgXG4qL1xuY29uc3Qgc2tpcFRva2VuID0gU3ltYm9sKCk7XG4vKipcbiogUmV0dXJucyB0aGUgZnVuY3Rpb24gdG8gY2FsbCBmb3IgYSBmZXRjaC4gSWYgdGhlcmUgaXMgbm8gYHF1ZXJ5Rm5gIGJ1dCB0aGUgZmV0Y2ggd2FzIHN0YXJ0ZWQgZnJvbVxuKiBhbiBgaW5pdGlhbFByb21pc2VgLCB0aGF0IHByb21pc2UgaXMgcmV0dXJuZWQgaW5zdGVhZC4gSWYgdGhlcmUgaXMgbm8gdXNhYmxlIGBxdWVyeUZuYCAobWlzc2luZyBvclxuKiB7QGxpbmsgc2tpcFRva2VufSksIHRoZSByZXR1cm5lZCBmdW5jdGlvbiByZWplY3RzIHdpdGggYSBgTWlzc2luZyBxdWVyeUZuYCBlcnJvci5cbiogQHBhcmFtIG9wdGlvbnMgLSBUaGUgcXVlcnkgb3B0aW9ucyB3aXRoIHRoZSBgcXVlcnlGbmAsIGFuZCB0aGUgYHF1ZXJ5SGFzaGAgdXNlZCBpbiBlcnJvciBtZXNzYWdlcy5cbiogQHBhcmFtIGZldGNoT3B0aW9ucyAtIFRoZSBmZXRjaCBvcHRpb25zLCB3aGljaCBtYXkgY2FycnkgYW4gYGluaXRpYWxQcm9taXNlYC5cbiogQHJldHVybnMgVGhlIGZ1bmN0aW9uIHRvIGNhbGwgZm9yIHRoZSBmZXRjaC5cbiovXG5mdW5jdGlvbiBlbnN1cmVRdWVyeUZuKG9wdGlvbnMsIGZldGNoT3B0aW9ucykge1xuXHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSB7XG5cdFx0aWYgKG9wdGlvbnMucXVlcnlGbiA9PT0gc2tpcFRva2VuKSBjb25zb2xlLmVycm9yKGBBdHRlbXB0ZWQgdG8gaW52b2tlIHF1ZXJ5Rm4gd2hlbiBzZXQgdG8gc2tpcFRva2VuLiBUaGlzIGlzIGxpa2VseSBhIGNvbmZpZ3VyYXRpb24gZXJyb3IuIFF1ZXJ5IGhhc2g6ICcke29wdGlvbnMucXVlcnlIYXNofSdgKTtcblx0fVxuXHRpZiAoIW9wdGlvbnMucXVlcnlGbiAmJiBmZXRjaE9wdGlvbnM/LmluaXRpYWxQcm9taXNlKSByZXR1cm4gKCkgPT4gZmV0Y2hPcHRpb25zLmluaXRpYWxQcm9taXNlO1xuXHRpZiAoIW9wdGlvbnMucXVlcnlGbiB8fCBvcHRpb25zLnF1ZXJ5Rm4gPT09IHNraXBUb2tlbikgcmV0dXJuICgpID0+IFByb21pc2UucmVqZWN0KC8qIEBfX1BVUkVfXyAqLyBuZXcgRXJyb3IoYE1pc3NpbmcgcXVlcnlGbjogJyR7b3B0aW9ucy5xdWVyeUhhc2h9J2ApKTtcblx0cmV0dXJuIG9wdGlvbnMucXVlcnlGbjtcbn1cbi8qKlxuKiBSZXNvbHZlcyBhIGB0aHJvd09uRXJyb3JgIG9wdGlvbiB0byBhIGJvb2xlYW4uXG4qIElmIGB0aHJvd09uRXJyb3JgIGlzIGEgZnVuY3Rpb24sIGl0IGlzIGNhbGxlZCB3aXRoIGBwYXJhbXNgIChlLmcuIHRoZSBlcnJvciBhbmQsIGRlcGVuZGluZyBvbiB0aGUgY2FsbGVyLFxuKiBhZGRpdGlvbmFsIGNvbnRleHQgc3VjaCBhcyB0aGUgcXVlcnkgb3IgbXV0YXRpb24pIGFuZCBpdHMgcmVzdWx0IGlzIHJldHVybmVkLCBhbGxvd2luZyB0aGUgdGhyb3dpbmdcbiogYmVoYXZpb3IgdG8gYmUgZGVjaWRlZCBwZXIgZXJyb3IuIE90aGVyd2lzZSwgYHRocm93T25FcnJvcmAgaXRzZWxmIGlzIGNvZXJjZWQgdG8gYSBib29sZWFuIChgdW5kZWZpbmVkYFxuKiByZXNvbHZlcyB0byBgZmFsc2VgKS5cbiogQHBhcmFtIHRocm93T25FcnJvciAtIFRoZSBgdGhyb3dPbkVycm9yYCBvcHRpb246IGEgYm9vbGVhbiwgYSBmdW5jdGlvbiB0aGF0IGRlY2lkZXMgcGVyIGVycm9yLCBvclxuKiBgdW5kZWZpbmVkYC5cbiogQHBhcmFtIHBhcmFtcyAtIFRoZSBhcmd1bWVudHMgcGFzc2VkIHRvIGB0aHJvd09uRXJyb3JgIGlmIGl0IGlzIGEgZnVuY3Rpb24uXG4qIEByZXR1cm5zIFdoZXRoZXIgdGhlIGVycm9yIHNob3VsZCBiZSB0aHJvd24uXG4qIEBleGFtcGxlXG4qIGBgYHRzXG4qIGNvbnN0IHRocm93T25FcnJvciA9XG4qICAgcXVlcnkuc3RhdGUuZXJyb3IgJiYgdHlwZW9mIG9wdGlvbnMudGhyb3dPbkVycm9yID09PSAnZnVuY3Rpb24nXG4qICAgICA/IHNob3VsZFRocm93RXJyb3Iob3B0aW9ucy50aHJvd09uRXJyb3IsIFtxdWVyeS5zdGF0ZS5lcnJvciwgcXVlcnldKVxuKiAgICAgOiBvcHRpb25zLnRocm93T25FcnJvclxuKiBgYGBcbiovXG5mdW5jdGlvbiBzaG91bGRUaHJvd0Vycm9yKHRocm93T25FcnJvciwgcGFyYW1zKSB7XG5cdGlmICh0eXBlb2YgdGhyb3dPbkVycm9yID09PSBcImZ1bmN0aW9uXCIpIHJldHVybiB0aHJvd09uRXJyb3IoLi4ucGFyYW1zKTtcblx0cmV0dXJuICEhdGhyb3dPbkVycm9yO1xufVxuY29uc3QgZmV0Y2hTaWduYWwgPSBTeW1ib2woKTtcbi8qKlxuKiBBZGRzIGEgbGF6eSBgc2lnbmFsYCBnZXR0ZXIgdG8gYW4gb2JqZWN0LCBzdWNoIGFzIGEgcXVlcnkgZnVuY3Rpb24gY29udGV4dC4gVGhlIGZpcnN0IHRpbWVcbiogYHNpZ25hbGAgaXMgcmVhZCwgYG9uQ2FuY2VsbGVkYCBpcyByZWdpc3RlcmVkIGZvciB0aGUgc2lnbmFsJ3MgYGFib3J0YCBldmVudCAob3IgY2FsbGVkIHJpZ2h0XG4qIGF3YXkgaWYgaXQgaXMgYWxyZWFkeSBhYm9ydGVkKSwgc28gY2FuY2VsbGF0aW9uIGlzIG9ubHkgdHJhY2tlZCB3aGVuIHRoZSBzaWduYWwgaXMgYWN0dWFsbHkgdXNlZC5cbiogQHBhcmFtIG9iamVjdCAtIFRoZSBvYmplY3QgdG8gYWRkIHRoZSBgc2lnbmFsYCBwcm9wZXJ0eSB0by5cbiogQHBhcmFtIGdldFNpZ25hbCAtIFJldHVybnMgdGhlIGBBYm9ydFNpZ25hbGAuIENhbGxlZCBvbmNlLCB3aGVuIGBzaWduYWxgIGlzIGZpcnN0IHJlYWQuXG4qIEBwYXJhbSBvbkNhbmNlbGxlZCAtIENhbGxlZCB3aGVuIHRoZSBzaWduYWwgaXMgYWJvcnRlZCwgaWYgYHNpZ25hbGAgd2FzIHJlYWQuXG4qIEBwYXJhbSBpbnRlcm5hbFNpZ25hbCAtIFRoZSBmZXRjaCBzaWduYWwgdG8gZm9yd2FyZCB3aXRob3V0IGNvbnN1bWluZyB0aGUgZ2V0dGVyLlxuKiBAcmV0dXJucyBUaGUgc2FtZSBvYmplY3QsIHdpdGggdGhlIGBzaWduYWxgIHByb3BlcnR5IGFkZGVkLlxuKi9cbmZ1bmN0aW9uIGFkZENvbnN1bWVBd2FyZVNpZ25hbChvYmplY3QsIGdldFNpZ25hbCwgb25DYW5jZWxsZWQsIGludGVybmFsU2lnbmFsKSB7XG5cdGxldCBjb25zdW1lZCA9IGZhbHNlO1xuXHRsZXQgc2lnbmFsO1xuXHRPYmplY3QuZGVmaW5lUHJvcGVydGllcyhvYmplY3QsIHtcblx0XHRbZmV0Y2hTaWduYWxdOiB7IHZhbHVlOiBpbnRlcm5hbFNpZ25hbCB9LFxuXHRcdHNpZ25hbDoge1xuXHRcdFx0ZW51bWVyYWJsZTogdHJ1ZSxcblx0XHRcdGdldDogKCkgPT4ge1xuXHRcdFx0XHRzaWduYWwgPz89IGdldFNpZ25hbCgpO1xuXHRcdFx0XHRpZiAoY29uc3VtZWQpIHJldHVybiBzaWduYWw7XG5cdFx0XHRcdGNvbnN1bWVkID0gdHJ1ZTtcblx0XHRcdFx0aWYgKHNpZ25hbC5hYm9ydGVkKSBvbkNhbmNlbGxlZCgpO1xuXHRcdFx0XHRlbHNlIHNpZ25hbC5hZGRFdmVudExpc3RlbmVyKFwiYWJvcnRcIiwgb25DYW5jZWxsZWQsIHsgb25jZTogdHJ1ZSB9KTtcblx0XHRcdFx0cmV0dXJuIHNpZ25hbDtcblx0XHRcdH1cblx0XHR9XG5cdH0pO1xuXHRyZXR1cm4gb2JqZWN0O1xufVxuZXhwb3J0IHsgYWRkQ29uc3VtZUF3YXJlU2lnbmFsLCBhZGRUb0VuZCwgYWRkVG9TdGFydCwgZW5zdXJlUXVlcnlGbiwgZmV0Y2hTaWduYWwsIGZ1bmN0aW9uYWxVcGRhdGUsIGhhc2hLZXksIGhhc2hRdWVyeUtleUJ5T3B0aW9ucywgaXNQbGFpbkFycmF5LCBpc1BsYWluT2JqZWN0LCBpc1NlcnZlciwgaXNWYWxpZFRpbWVvdXQsIGtlZXBQcmV2aW91c0RhdGEsIG1hdGNoTXV0YXRpb24sIG1hdGNoUXVlcnksIG5vb3AsIHBhcnRpYWxNYXRjaEtleSwgcmVwbGFjZURhdGEsIHJlcGxhY2VFcXVhbERlZXAsIHJlc29sdmVRdWVyeVZhbHVlLCBzaGFsbG93RXF1YWxPYmplY3RzLCBzaG91bGRUaHJvd0Vycm9yLCBza2lwVG9rZW4sIHNsZWVwLCB0aW1lVW50aWxTdGFsZSB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD11dGlscy5qcy5tYXAiLCJpbXBvcnQgeyBpc1NlcnZlciBhcyBpc1NlcnZlciQxIH0gZnJvbSBcIi4vdXRpbHMuanNcIjtcbi8vIHNyYy9lbnZpcm9ubWVudE1hbmFnZXIudHNcbmxldCBpc1NlcnZlckZuID0gKCkgPT4gaXNTZXJ2ZXIkMTtcbi8qKlxuKiBSZXR1cm5zIHdoZXRoZXIgdGhlIGN1cnJlbnQgcnVudGltZSBzaG91bGQgYmUgdHJlYXRlZCBhcyBhIHNlcnZlciBlbnZpcm9ubWVudC5cbiogQHJldHVybnMgYHRydWVgIGlmIHRoZSBydW50aW1lIGlzIHRyZWF0ZWQgYXMgYSBzZXJ2ZXIuXG4qL1xuY29uc3QgaXNTZXJ2ZXIgPSAoKSA9PiBpc1NlcnZlckZuKCk7XG4vKipcbiogTWFuYWdlcyBob3cgVGFuU3RhY2sgUXVlcnkgZGV0ZWN0cyB3aGV0aGVyIHRoZSBjdXJyZW50IHJ1bnRpbWUgc2hvdWxkIGJlIHRyZWF0ZWQgYXNcbiogc2VydmVyLXNpZGUsIHdoaWNoIGRpc2FibGVzIHNjaGVkdWxpbmcgcmVmZXRjaCB0aW1lcnMgYW5kIGNoYW5nZXMgdGhlIGRlZmF1bHQgYHJldHJ5YCBjb3VudFxuKiBhbmQgYGdjVGltZWAuIEJ5IGRlZmF1bHQsIHRoZSBkZXRlY3Rpb24gdHJlYXRzIGEgbWlzc2luZyBgd2luZG93YCAob3IgdGhlIHByZXNlbmNlIG9mIGFcbiogYERlbm9gIGdsb2JhbCkgYXMgc2VydmVyLlxuKlxuKiBPdmVycmlkZSB0aGlzIGZvciBydW50aW1lcyB3aGVyZSB0aGF0IGRlZmF1bHQgZGV0ZWN0aW9uIHdvdWxkIGdpdmUgdGhlIHdyb25nIGFuc3dlciDigJQgZm9yXG4qIGV4YW1wbGUsIGEgU2VydmljZSBXb3JrZXIsIHdoZXJlIGB3aW5kb3dgIGlzIHVuZGVmaW5lZCBldmVuIHRob3VnaCB0aGUgZW52aXJvbm1lbnQgc2hvdWxkXG4qIGJlaGF2ZSBsaWtlIGEgY2xpZW50LlxuKiBAZXhhbXBsZVxuKiBgYGB0c1xuKiBpbXBvcnQgeyBlbnZpcm9ubWVudE1hbmFnZXIgfSBmcm9tICdAdGFuc3RhY2svcXVlcnktY29yZSdcbipcbiogZW52aXJvbm1lbnRNYW5hZ2VyLnNldElzU2VydmVyKCgpID0+IGZhbHNlKVxuKiBgYGBcbiovXG5jb25zdCBlbnZpcm9ubWVudE1hbmFnZXIgPSB7XG5cdGlzU2VydmVyLFxuXHQvKipcblx0KiBPdmVycmlkZXMgdGhlIHNlcnZlciBjaGVjayBnbG9iYWxseS5cblx0KiBAcGFyYW0gaXNTZXJ2ZXJWYWx1ZSAtIEEgZnVuY3Rpb24gdGhhdCByZXR1cm5zIHdoZXRoZXIgdGhlIHJ1bnRpbWUgc2hvdWxkIGJlIHRyZWF0ZWQgYXMgYVxuXHQqIHNlcnZlci5cblx0Ki9cblx0c2V0SXNTZXJ2ZXIoaXNTZXJ2ZXJWYWx1ZSkge1xuXHRcdGlzU2VydmVyRm4gPSBpc1NlcnZlclZhbHVlO1xuXHR9XG59O1xuZXhwb3J0IHsgZW52aXJvbm1lbnRNYW5hZ2VyLCBpc1NlcnZlciB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1lbnZpcm9ubWVudE1hbmFnZXIuanMubWFwIiwiLy8gc3JjL3N1YnNjcmliYWJsZS50c1xuLyoqXG4qIFRoZSBiYXNlIGNsYXNzIGJlaGluZCBldmVyeXRoaW5nIGluIFF1ZXJ5IHRoYXQgeW91IGNhbiBzdWJzY3JpYmUgdG86IGBRdWVyeUNhY2hlYCwgYE11dGF0aW9uQ2FjaGVgLFxuKiB0aGUgb2JzZXJ2ZXJzLCBhbmQgdGhlIGBGb2N1c01hbmFnZXJgL2BPbmxpbmVNYW5hZ2VyYCBiZWhpbmQgYGZvY3VzTWFuYWdlcmAgYW5kIGBvbmxpbmVNYW5hZ2VyYC5cbiogU3ViY2xhc3NlcyBkZWNpZGUgd2hhdCBhIGxpc3RlbmVyIHJlY2VpdmVzIGFuZCB3aGVuIGl0IGlzIGNhbGxlZC5cbiovXG52YXIgU3Vic2NyaWJhYmxlID0gY2xhc3Mge1xuXHRjb25zdHJ1Y3RvcigpIHtcblx0XHR0aGlzLmxpc3RlbmVycyA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgU2V0KCk7XG5cdFx0dGhpcy5zdWJzY3JpYmUgPSB0aGlzLnN1YnNjcmliZS5iaW5kKHRoaXMpO1xuXHR9XG5cdC8qKlxuXHQqIFJlZ2lzdGVycyBhIGxpc3RlbmVyIHRvIGJlIGNhbGxlZCBvbiBldmVyeSB1cGRhdGUgdGhpcyBvYmplY3Qgbm90aWZpZXMgYWJvdXQuIFJldHVybnMgYSBmdW5jdGlvblxuXHQqIHRoYXQgcmVtb3ZlcyB0aGUgbGlzdGVuZXIgYWdhaW4g4oCUIGNhbGwgaXQgdG8gc3RvcCBsaXN0ZW5pbmcuIFRoZSBiYXNlIGNsYXNzIG5ldmVyIGRyb3BzIGEgbGlzdGVuZXJcblx0KiBvbiBpdHMgb3duLCB0aG91Z2ggc29tZSBzdWJjbGFzc2VzIGNsZWFyIGFsbCBvZiB0aGVpcnMgaW4gYGRlc3Ryb3koKWAuXG5cdCogQHBhcmFtIGxpc3RlbmVyIC0gQ2FsbGVkIG9uIGVhY2ggdXBkYXRlLCB3aXRoIHdoYXRldmVyIHRoZSBzdWJjbGFzcyBwYXNzZXMgdG8gaXRzIHN1YnNjcmliZXJzLlxuXHQqIEByZXR1cm5zIEEgZnVuY3Rpb24gdGhhdCByZW1vdmVzIHRoZSBsaXN0ZW5lci5cblx0KiBAZXhhbXBsZVxuXHQqIGBgYHRzXG5cdCogY29uc3QgdW5zdWJzY3JpYmUgPSBzdWJzY3JpYmFibGUuc3Vic2NyaWJlKCgpID0+IHtcblx0KiAgIC8vIHJlYWN0IHRvIHRoZSB1cGRhdGVcblx0KiB9KVxuXHQqXG5cdCogdW5zdWJzY3JpYmUoKVxuXHQqIGBgYFxuXHQqL1xuXHRzdWJzY3JpYmUobGlzdGVuZXIpIHtcblx0XHR0aGlzLmxpc3RlbmVycy5hZGQobGlzdGVuZXIpO1xuXHRcdHRoaXMub25TdWJzY3JpYmUoKTtcblx0XHRyZXR1cm4gKCkgPT4ge1xuXHRcdFx0dGhpcy5saXN0ZW5lcnMuZGVsZXRlKGxpc3RlbmVyKTtcblx0XHRcdHRoaXMub25VbnN1YnNjcmliZSgpO1xuXHRcdH07XG5cdH1cblx0LyoqXG5cdCogUmV0dXJucyBgdHJ1ZWAgd2hpbGUgYXQgbGVhc3Qgb25lIGxpc3RlbmVyIGlzIHJlZ2lzdGVyZWQsIGBmYWxzZWAgb25jZSB0aGV5IGhhdmUgYWxsIHVuc3Vic2NyaWJlZC5cblx0KiBAcmV0dXJucyBgdHJ1ZWAgaWYgYXQgbGVhc3Qgb25lIGxpc3RlbmVyIGlzIHJlZ2lzdGVyZWQuXG5cdCovXG5cdGhhc0xpc3RlbmVycygpIHtcblx0XHRyZXR1cm4gdGhpcy5saXN0ZW5lcnMuc2l6ZSA+IDA7XG5cdH1cblx0LyoqXG5cdCogQ2FsbGVkIGFmdGVyIGEgbGlzdGVuZXIgaXMgYWRkZWQuIERvZXMgbm90aGluZyBoZXJlOyBzdWJjbGFzc2VzIG92ZXJyaWRlIGl0LCBlLmcuIHRvIHN0YXJ0XG5cdCogdHJhY2tpbmcgd2hhdCB0aGV5IG9ic2VydmUgb25jZSB0aGUgZmlyc3QgbGlzdGVuZXIgc3Vic2NyaWJlcy5cblx0Ki9cblx0b25TdWJzY3JpYmUoKSB7fVxuXHQvKipcblx0KiBDYWxsZWQgYWZ0ZXIgYSBsaXN0ZW5lciBpcyByZW1vdmVkLiBEb2VzIG5vdGhpbmcgaGVyZTsgc3ViY2xhc3NlcyBvdmVycmlkZSBpdCwgZS5nLiB0byBjbGVhbiB1cFxuXHQqIG9uY2UgdGhlIGxhc3QgbGlzdGVuZXIgdW5zdWJzY3JpYmVzLlxuXHQqL1xuXHRvblVuc3Vic2NyaWJlKCkge31cbn07XG5leHBvcnQgeyBTdWJzY3JpYmFibGUgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9c3Vic2NyaWJhYmxlLmpzLm1hcCIsImltcG9ydCB7IFN1YnNjcmliYWJsZSB9IGZyb20gXCIuL3N1YnNjcmliYWJsZS5qc1wiO1xuLy8gc3JjL2ZvY3VzTWFuYWdlci50c1xuLyoqXG4qIFRoZSBgRm9jdXNNYW5hZ2VyYCBtYW5hZ2VzIHRoZSBmb2N1cyBzdGF0ZSB3aXRoaW4gVGFuU3RhY2sgUXVlcnkuXG4qXG4qIEl0IGNhbiBiZSB1c2VkIHRvIGNoYW5nZSB0aGUgZGVmYXVsdCBldmVudCBsaXN0ZW5lcnMgb3IgdG8gbWFudWFsbHkgY2hhbmdlIHRoZSBmb2N1cyBzdGF0ZS5cbiovXG52YXIgRm9jdXNNYW5hZ2VyID0gY2xhc3MgZXh0ZW5kcyBTdWJzY3JpYmFibGUge1xuXHQjZm9jdXNlZDtcblx0I2NsZWFudXA7XG5cdCNzZXR1cDtcblx0Y29uc3RydWN0b3IoKSB7XG5cdFx0c3VwZXIoKTtcblx0XHR0aGlzLiNzZXR1cCA9IChvbkZvY3VzKSA9PiB7XG5cdFx0XHRpZiAodHlwZW9mIHdpbmRvdyAhPT0gXCJ1bmRlZmluZWRcIiAmJiB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcikge1xuXHRcdFx0XHRjb25zdCBsaXN0ZW5lciA9ICgpID0+IG9uRm9jdXMoKTtcblx0XHRcdFx0d2luZG93LmFkZEV2ZW50TGlzdGVuZXIoXCJ2aXNpYmlsaXR5Y2hhbmdlXCIsIGxpc3RlbmVyLCBmYWxzZSk7XG5cdFx0XHRcdHJldHVybiAoKSA9PiB7XG5cdFx0XHRcdFx0d2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJ2aXNpYmlsaXR5Y2hhbmdlXCIsIGxpc3RlbmVyKTtcblx0XHRcdFx0fTtcblx0XHRcdH1cblx0XHR9O1xuXHR9XG5cdG9uU3Vic2NyaWJlKCkge1xuXHRcdGlmICghdGhpcy4jY2xlYW51cCkgdGhpcy5zZXRFdmVudExpc3RlbmVyKHRoaXMuI3NldHVwKTtcblx0fVxuXHRvblVuc3Vic2NyaWJlKCkge1xuXHRcdGlmICghdGhpcy5oYXNMaXN0ZW5lcnMoKSkge1xuXHRcdFx0dGhpcy4jY2xlYW51cD8uKCk7XG5cdFx0XHR0aGlzLiNjbGVhbnVwID0gdm9pZCAwO1xuXHRcdH1cblx0fVxuXHQvKipcblx0KiBgc2V0RXZlbnRMaXN0ZW5lcmAgY2FuIGJlIHVzZWQgdG8gc2V0IGEgY3VzdG9tIGV2ZW50IGxpc3RlbmVyIHRoYXQgd2lsbFxuXHQqIGJlIHVzZWQgdG8gZGV0ZXJtaW5lIHRoZSBmb2N1cyBzdGF0ZS4gVGhlIHByb3ZpZGVkIGBzZXR1cGAgZnVuY3Rpb25cblx0KiByZWNlaXZlcyBhIGBzZXRGb2N1c2VkYCBjYWxsYmFjazogY2FsbCBpdCB3aXRoIGEgYGJvb2xlYW5gIHRvIG1hbnVhbGx5XG5cdCogc2V0IHRoZSBmb2N1cyBzdGF0ZSwgb3Igd2l0aCBubyBhcmd1bWVudHMgdG8gcmUtZXZhbHVhdGUgdGhlIGN1cnJlbnRcblx0KiBmb2N1cyBzdGF0ZSBhbmQgbm90aWZ5IHN1YnNjcmliZXJzLlxuXHQqIEBwYXJhbSBzZXR1cCAtIFJlY2VpdmVzIHRoZSBgc2V0Rm9jdXNlZGAgY2FsbGJhY2ssIHJlZ2lzdGVycyB0aGUgZXZlbnQgbGlzdGVuZXIsIGFuZCBtYXkgcmV0dXJuXG5cdCogYSBjbGVhbnVwIGZ1bmN0aW9uIHRoYXQgaXMgY2FsbGVkIHdoZW4gdGhlIGxpc3RlbmVyIGlzIHJlcGxhY2VkIG9yIG5vIGxvbmdlciBuZWVkZWQuXG5cdCogQGV4YW1wbGVcblx0KiBgYGB0c1xuXHQqIGltcG9ydCB7IGZvY3VzTWFuYWdlciB9IGZyb20gJ0B0YW5zdGFjay9xdWVyeS1jb3JlJ1xuXHQqXG5cdCogZm9jdXNNYW5hZ2VyLnNldEV2ZW50TGlzdGVuZXIoKGhhbmRsZUZvY3VzKSA9PiB7XG5cdCogICBjb25zdCBsaXN0ZW5lciA9ICgpID0+IGhhbmRsZUZvY3VzKClcblx0KiAgIC8vIExpc3RlbiB0byB2aXNpYmlsaXR5Y2hhbmdlXG5cdCogICBpZiAodHlwZW9mIHdpbmRvdyAhPT0gJ3VuZGVmaW5lZCcgJiYgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIpIHtcblx0KiAgICAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoJ3Zpc2liaWxpdHljaGFuZ2UnLCBsaXN0ZW5lciwgZmFsc2UpXG5cdCogICB9XG5cdCpcblx0KiAgIHJldHVybiAoKSA9PiB7XG5cdCogICAgIC8vIEJlIHN1cmUgdG8gdW5zdWJzY3JpYmUgaWYgYSBuZXcgaGFuZGxlciBpcyBzZXRcblx0KiAgICAgd2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoJ3Zpc2liaWxpdHljaGFuZ2UnLCBsaXN0ZW5lcilcblx0KiAgIH1cblx0KiB9KVxuXHQqIGBgYFxuXHQqL1xuXHRzZXRFdmVudExpc3RlbmVyKHNldHVwKSB7XG5cdFx0dGhpcy4jc2V0dXAgPSBzZXR1cDtcblx0XHR0aGlzLiNjbGVhbnVwPy4oKTtcblx0XHR0aGlzLiNjbGVhbnVwID0gc2V0dXAoKGZvY3VzZWQpID0+IHtcblx0XHRcdGlmICh0eXBlb2YgZm9jdXNlZCA9PT0gXCJib29sZWFuXCIpIHRoaXMuc2V0Rm9jdXNlZChmb2N1c2VkKTtcblx0XHRcdGVsc2UgdGhpcy5vbkZvY3VzKCk7XG5cdFx0fSk7XG5cdH1cblx0LyoqXG5cdCogYHNldEZvY3VzZWRgIGNhbiBiZSB1c2VkIHRvIG1hbnVhbGx5IHNldCB0aGUgZm9jdXMgc3RhdGUuIFNldCBgdW5kZWZpbmVkYFxuXHQqIHRvIGZhbGwgYmFjayB0byB0aGUgZGVmYXVsdCBmb2N1cyBjaGVjay5cblx0KiBAcGFyYW0gZm9jdXNlZCAtIFRoZSBmb2N1cyBzdGF0ZSwgb3IgYHVuZGVmaW5lZGAgdG8gdXNlIHRoZSBkZWZhdWx0IGZvY3VzIGNoZWNrLlxuXHQqIEBleGFtcGxlXG5cdCogYGBgdHNcblx0KiBpbXBvcnQgeyBmb2N1c01hbmFnZXIgfSBmcm9tICdAdGFuc3RhY2svcXVlcnktY29yZSdcblx0KlxuXHQqIC8vIFNldCBmb2N1c2VkXG5cdCogZm9jdXNNYW5hZ2VyLnNldEZvY3VzZWQodHJ1ZSlcblx0KlxuXHQqIC8vIFNldCB1bmZvY3VzZWRcblx0KiBmb2N1c01hbmFnZXIuc2V0Rm9jdXNlZChmYWxzZSlcblx0KlxuXHQqIC8vIEZhbGxiYWNrIHRvIHRoZSBkZWZhdWx0IGZvY3VzIGNoZWNrXG5cdCogZm9jdXNNYW5hZ2VyLnNldEZvY3VzZWQodW5kZWZpbmVkKVxuXHQqIGBgYFxuXHQqL1xuXHRzZXRGb2N1c2VkKGZvY3VzZWQpIHtcblx0XHRpZiAodGhpcy4jZm9jdXNlZCAhPT0gZm9jdXNlZCkge1xuXHRcdFx0dGhpcy4jZm9jdXNlZCA9IGZvY3VzZWQ7XG5cdFx0XHR0aGlzLm9uRm9jdXMoKTtcblx0XHR9XG5cdH1cblx0LyoqXG5cdCogYG9uRm9jdXNgIG5vdGlmaWVzIGFsbCBzdWJzY3JpYmVkIGxpc3RlbmVycyB3aXRoIHRoZSBjdXJyZW50IGZvY3VzIHN0YXRlLlxuXHQqL1xuXHRvbkZvY3VzKCkge1xuXHRcdGNvbnN0IGlzRm9jdXNlZCA9IHRoaXMuaXNGb2N1c2VkKCk7XG5cdFx0dGhpcy5saXN0ZW5lcnMuZm9yRWFjaCgobGlzdGVuZXIpID0+IHtcblx0XHRcdGxpc3RlbmVyKGlzRm9jdXNlZCk7XG5cdFx0fSk7XG5cdH1cblx0LyoqXG5cdCogYGlzRm9jdXNlZGAgY2FuIGJlIHVzZWQgdG8gZ2V0IHRoZSBjdXJyZW50IGZvY3VzIHN0YXRlLlxuXHQqIEByZXR1cm5zIFRoZSBmb2N1cyBzdGF0ZSBzZXQgd2l0aCBgc2V0Rm9jdXNlZGAsIG9yIG90aGVyd2lzZSB3aGV0aGVyIHRoZSBkb2N1bWVudCBpcyB2aXNpYmxlLlxuXHQqL1xuXHRpc0ZvY3VzZWQoKSB7XG5cdFx0aWYgKHR5cGVvZiB0aGlzLiNmb2N1c2VkID09PSBcImJvb2xlYW5cIikgcmV0dXJuIHRoaXMuI2ZvY3VzZWQ7XG5cdFx0cmV0dXJuIGdsb2JhbFRoaXMuZG9jdW1lbnQ/LnZpc2liaWxpdHlTdGF0ZSAhPT0gXCJoaWRkZW5cIjtcblx0fVxufTtcbi8qKlxuKiBTaW5nbGV0b24gaW5zdGFuY2Ugb2Yge0BsaW5rIEZvY3VzTWFuYWdlcn0sIHVzZWQgdG8gbWFuYWdlIGFuZCBvYnNlcnZlIHRoZSBmb2N1cyBzdGF0ZSB3aXRoaW4gVGFuU3RhY2sgUXVlcnkuXG4qL1xuY29uc3QgZm9jdXNNYW5hZ2VyID0gbmV3IEZvY3VzTWFuYWdlcigpO1xuZXhwb3J0IHsgRm9jdXNNYW5hZ2VyLCBmb2N1c01hbmFnZXIgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9Zm9jdXNNYW5hZ2VyLmpzLm1hcCIsImltcG9ydCB7IG5vb3AgfSBmcm9tIFwiLi91dGlscy5qc1wiO1xuLy8gc3JjL2h5ZHJhdGlvbi50c1xuLyoqXG4qIFJlYWRzIHRoZSB2YWx1ZSBvZiBhIHByb21pc2Ugc3luY2hyb25vdXNseSBpZiBpdCBoYXMgYWxyZWFkeSByZXNvbHZlZCwgZS5nLiBhIHRoZW5hYmxlIHRoYXRcbiogcmVzb2x2ZXMgd2l0aGluIGl0cyBgdGhlbmAgY2FsbC5cbiogQHBhcmFtIHByb21pc2UgLSBUaGUgcHJvbWlzZSB0byByZWFkLlxuKiBAcmV0dXJucyBBbiBvYmplY3Qgd2l0aCB0aGUgcmVzb2x2ZWQgYGRhdGFgLCBvciBgdW5kZWZpbmVkYCBpZiB0aGUgcHJvbWlzZSBoYXNuJ3QgcmVzb2x2ZWRcbiogc3luY2hyb25vdXNseSAob3IgcmVzb2x2ZWQgd2l0aCBgdW5kZWZpbmVkYCkuXG4qL1xuZnVuY3Rpb24gdHJ5UmVzb2x2ZVN5bmMocHJvbWlzZSkge1xuXHRsZXQgZGF0YTtcblx0cHJvbWlzZS50aGVuKChyZXN1bHQpID0+IHtcblx0XHRkYXRhID0gcmVzdWx0O1xuXHRcdHJldHVybiByZXN1bHQ7XG5cdH0sIG5vb3ApPy5jYXRjaD8uKG5vb3ApO1xuXHRpZiAoZGF0YSAhPT0gdm9pZCAwKSByZXR1cm4geyBkYXRhIH07XG59XG4vKipcbiogRGVoeWRyYXRlcyBhIHNpbmdsZSBgTXV0YXRpb25gIGludG8gYSBzZXJpYWxpemFibGUgc25hcHNob3Qgb2YgaXRzIGtleSwgc3RhdGUsIHNjb3BlLCBhbmQgbWV0YS5cbiogQHBhcmFtIG11dGF0aW9uIC0gVGhlIG11dGF0aW9uIHRvIGRlaHlkcmF0ZS5cbiogQHJldHVybnMgVGhlIGRlaHlkcmF0ZWQgbXV0YXRpb24uXG4qL1xuZnVuY3Rpb24gZGVoeWRyYXRlTXV0YXRpb24obXV0YXRpb24pIHtcblx0cmV0dXJuIHtcblx0XHRtdXRhdGlvbktleTogbXV0YXRpb24ub3B0aW9ucy5tdXRhdGlvbktleSxcblx0XHRzdGF0ZTogbXV0YXRpb24uc3RhdGUsXG5cdFx0Li4ubXV0YXRpb24ub3B0aW9ucy5zY29wZSAmJiB7IHNjb3BlOiBtdXRhdGlvbi5vcHRpb25zLnNjb3BlIH0sXG5cdFx0Li4ubXV0YXRpb24ubWV0YSAmJiB7IG1ldGE6IG11dGF0aW9uLm1ldGEgfVxuXHR9O1xufVxuLyoqXG4qIFByZXBhcmVzIHRoZSBpbi1mbGlnaHQgcHJvbWlzZSBvZiBhIHBlbmRpbmcgcXVlcnkgZm9yIGRlaHlkcmF0aW9uOiBhcHBsaWVzIGBzZXJpYWxpemVEYXRhYCB0byBpdHNcbiogcmVzdWx0LCBhbmQgcmVkYWN0cyBpdHMgcmVqZWN0aW9uIGVycm9yIHVubGVzcyBgc2hvdWxkUmVkYWN0RXJyb3JzYCByZXR1cm5zIGBmYWxzZWAgZm9yIGl0LlxuKiBAcGFyYW0gcXVlcnkgLSBUaGUgcGVuZGluZyBxdWVyeSB3aG9zZSBwcm9taXNlIGlzIGRlaHlkcmF0ZWQuXG4qIEBwYXJhbSBzZXJpYWxpemVEYXRhIC0gT3B0aW9uYWwgdHJhbnNmb3JtIGFwcGxpZWQgdG8gdGhlIHJlc29sdmVkIGRhdGEuXG4qIEBwYXJhbSBzaG91bGRSZWRhY3RFcnJvcnMgLSBPcHRpb25hbCBwcmVkaWNhdGU7IGlmIGl0IHJldHVybnMgYGZhbHNlYCBmb3IgdGhlIHJlamVjdGlvbiBlcnJvcixcbiogdGhhdFxuKiBlcnJvciBpcyBrZXB0IGFzLWlzIGluc3RlYWQgb2YgYmVpbmcgcmVkYWN0ZWQuXG4qIEByZXR1cm5zIFRoZSB0cmFuc2Zvcm1lZCBwcm9taXNlLCBvciBgdW5kZWZpbmVkYCBpZiB0aGUgcXVlcnkgaGFzIG5vIGluLWZsaWdodCBwcm9taXNlLlxuKi9cbmZ1bmN0aW9uIGRlaHlkcmF0ZVByb21pc2UocXVlcnksIHNlcmlhbGl6ZURhdGEsIHNob3VsZFJlZGFjdEVycm9ycykge1xuXHRjb25zdCBwcm9taXNlID0gcXVlcnkucHJvbWlzZT8udGhlbihzZXJpYWxpemVEYXRhKS5jYXRjaCgoZXJyb3IpID0+IHtcblx0XHRpZiAoc2hvdWxkUmVkYWN0RXJyb3JzPy4oZXJyb3IpID09PSBmYWxzZSkgcmV0dXJuIFByb21pc2UucmVqZWN0KGVycm9yKTtcblx0XHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSBjb25zb2xlLmVycm9yKGBBIHF1ZXJ5IHRoYXQgd2FzIGRlaHlkcmF0ZWQgYXMgcGVuZGluZyBlbmRlZCB1cCByZWplY3RpbmcuIFske3F1ZXJ5LnF1ZXJ5SGFzaH1dOiAke2Vycm9yfTsgVGhlIGVycm9yIHdpbGwgYmUgcmVkYWN0ZWQgaW4gcHJvZHVjdGlvbiBidWlsZHNgKTtcblx0XHRyZXR1cm4gUHJvbWlzZS5yZWplY3QoLyogQF9fUFVSRV9fICovIG5ldyBFcnJvcihcInJlZGFjdGVkXCIpKTtcblx0fSk7XG5cdHByb21pc2U/LmNhdGNoKG5vb3ApO1xuXHRyZXR1cm4gcHJvbWlzZTtcbn1cbi8qKlxuKiBEZWh5ZHJhdGVzIGEgc2luZ2xlIGBRdWVyeWAgaW50byBhIHNlcmlhbGl6YWJsZSBgRGVoeWRyYXRlZFF1ZXJ5YCBzbmFwc2hvdC4gTm90ZSB0aGF0IG1vc3QgcXVlcnkgY29uZmlnIChlLmcuXG4qIGBxdWVyeUZuYCwgYHN0YWxlVGltZWApIGlzIG5vdCBkZWh5ZHJhdGVkIGJ1dCBpbnN0ZWFkIG1lYW50IHRvIGJlIGNvbmZpZ3VyZWQgYWdhaW4gd2hlbiBjb25zdW1pbmcgdGhlXG4qIGRlL3JlaHlkcmF0ZWQgZGF0YSwgdHlwaWNhbGx5IHdpdGggYHVzZVF1ZXJ5YCBvbiB0aGUgY2xpZW50LiBJZiB0aGUgcXVlcnkgaXMgc3RpbGwgYHBlbmRpbmdgLCBpdHMgaW4tZmxpZ2h0XG4qIHByb21pc2UgaXMgZGVoeWRyYXRlZCB0b28gc28gaXQgY2FuIGJlIHJlc3VtZWQgb24gdGhlIG90aGVyIHNpZGUgaW5zdGVhZCBvZiByZS1mZXRjaGVkLlxuKiBAcGFyYW0gcXVlcnkgLSBUaGUgcXVlcnkgdG8gZGVoeWRyYXRlLlxuKiBAcGFyYW0gc2VyaWFsaXplRGF0YSAtIE9wdGlvbmFsIHRyYW5zZm9ybSBhcHBsaWVkIHRvIGBxdWVyeS5zdGF0ZS5kYXRhYCBiZWZvcmUgaXQgaXMgaW5jbHVkZWQgaW4gdGhlIHNuYXBzaG90LlxuKiBAcGFyYW0gc2hvdWxkUmVkYWN0RXJyb3JzIC0gT3B0aW9uYWwgcHJlZGljYXRlOyBpZiBpdCByZXR1cm5zIGBmYWxzZWAgZm9yIHRoZSBwcm9taXNlJ3MgcmVqZWN0aW9uIGVycm9yLCB0aGF0XG4qIGVycm9yIGlzIGtlcHQgYXMtaXMgaW5zdGVhZCBvZiBiZWluZyByZWRhY3RlZC5cbiogQHJldHVybnMgVGhlIGRlaHlkcmF0ZWQgcXVlcnkuXG4qL1xuZnVuY3Rpb24gZGVoeWRyYXRlUXVlcnkocXVlcnksIHNlcmlhbGl6ZURhdGEsIHNob3VsZFJlZGFjdEVycm9ycykge1xuXHRyZXR1cm4ge1xuXHRcdGRlaHlkcmF0ZWRBdDogRGF0ZS5ub3coKSxcblx0XHRzdGF0ZToge1xuXHRcdFx0Li4ucXVlcnkuc3RhdGUsXG5cdFx0XHQuLi5xdWVyeS5zdGF0ZS5kYXRhICE9PSB2b2lkIDAgJiYgeyBkYXRhOiBzZXJpYWxpemVEYXRhID8gc2VyaWFsaXplRGF0YShxdWVyeS5zdGF0ZS5kYXRhKSA6IHF1ZXJ5LnN0YXRlLmRhdGEgfVxuXHRcdH0sXG5cdFx0cXVlcnlLZXk6IHF1ZXJ5LnF1ZXJ5S2V5LFxuXHRcdHF1ZXJ5SGFzaDogcXVlcnkucXVlcnlIYXNoLFxuXHRcdC4uLnF1ZXJ5LnN0YXRlLnN0YXR1cyA9PT0gXCJwZW5kaW5nXCIgJiYgeyBwcm9taXNlOiBkZWh5ZHJhdGVQcm9taXNlKHF1ZXJ5LCBzZXJpYWxpemVEYXRhLCBzaG91bGRSZWRhY3RFcnJvcnMpIH0sXG5cdFx0Li4ucXVlcnkubWV0YSAmJiB7IG1ldGE6IHF1ZXJ5Lm1ldGEgfSxcblx0XHQuLi5xdWVyeS5xdWVyeVR5cGUgJiYgeyBxdWVyeVR5cGU6IHF1ZXJ5LnF1ZXJ5VHlwZSB9XG5cdH07XG59XG4vKipcbiogVGhlIGRlZmF1bHQgYHNob3VsZERlaHlkcmF0ZU11dGF0aW9uYCBwcmVkaWNhdGUgdXNlZCBieSBgZGVoeWRyYXRlYC4gT25seSBkZWh5ZHJhdGVzIG11dGF0aW9ucyB0aGF0IGFyZVxuKiBjdXJyZW50bHkgcGF1c2VkIChlLmcuIHBhdXNlZCBieSBgbmV0d29ya01vZGVgIHdoaWxlIG9mZmxpbmUpLlxuKiBAcGFyYW0gbXV0YXRpb24gLSBUaGUgbXV0YXRpb24gdG8gY2hlY2suXG4qIEByZXR1cm5zIGB0cnVlYCBpZiB0aGUgbXV0YXRpb24gaXMgcGF1c2VkLlxuKi9cbmZ1bmN0aW9uIGRlZmF1bHRTaG91bGREZWh5ZHJhdGVNdXRhdGlvbihtdXRhdGlvbikge1xuXHRyZXR1cm4gbXV0YXRpb24uc3RhdGUuaXNQYXVzZWQ7XG59XG4vKipcbiogVGhlIGRlZmF1bHQgYHNob3VsZERlaHlkcmF0ZVF1ZXJ5YCBwcmVkaWNhdGUgdXNlZCBieSBgZGVoeWRyYXRlYC4gT25seSBkZWh5ZHJhdGVzIHF1ZXJpZXMgd2hvc2Ugc3RhdHVzIGlzXG4qIGAnc3VjY2VzcydgLlxuKiBAcGFyYW0gcXVlcnkgLSBUaGUgcXVlcnkgdG8gY2hlY2suXG4qIEByZXR1cm5zIGB0cnVlYCBpZiB0aGUgcXVlcnkncyBzdGF0dXMgaXMgYCdzdWNjZXNzJ2AuXG4qL1xuZnVuY3Rpb24gZGVmYXVsdFNob3VsZERlaHlkcmF0ZVF1ZXJ5KHF1ZXJ5KSB7XG5cdHJldHVybiBxdWVyeS5zdGF0ZS5zdGF0dXMgPT09IFwic3VjY2Vzc1wiO1xufVxuLyoqXG4qIERlaHlkcmF0ZXMgYSBgUXVlcnlDbGllbnRgJ3MgY2FjaGUgKHF1ZXJpZXMgYW5kIG11dGF0aW9ucykgaW50byBhIHBsYWluLCBzZXJpYWxpemFibGUgYERlaHlkcmF0ZWRTdGF0ZWAsXG4qIHR5cGljYWxseSB0byBlbWJlZCBpbiBzZXJ2ZXItcmVuZGVyZWQgbWFya3VwIGFuZCBsYXRlciByZXN0b3JlIGludG8gYSBjbGllbnQtc2lkZSBgUXVlcnlDbGllbnRgIHZpYSBgaHlkcmF0ZWAuXG4qIFdoaWNoIHF1ZXJpZXMvbXV0YXRpb25zIGFyZSBpbmNsdWRlZCwgYW5kIGhvdyB0aGVpciBkYXRhL2Vycm9ycyBhcmUgdHJhbnNmb3JtZWQsIGlzIGNvbnRyb2xsZWQgYnkgYG9wdGlvbnNgLFxuKiBmYWxsaW5nIGJhY2sgdG8gdGhlIGNsaWVudCdzIGBkZWh5ZHJhdGVgIGRlZmF1bHQgb3B0aW9ucywgYW5kIGZpbmFsbHkgdG8gYGRlZmF1bHRTaG91bGREZWh5ZHJhdGVRdWVyeWAgL1xuKiBgZGVmYXVsdFNob3VsZERlaHlkcmF0ZU11dGF0aW9uYC5cbiogQHBhcmFtIGNsaWVudCAtIFRoZSBjbGllbnQgd2hvc2UgY2FjaGUgaXMgZGVoeWRyYXRlZC5cbiogQHBhcmFtIG9wdGlvbnMgLSBDb250cm9scyB3aGljaCBxdWVyaWVzIGFuZCBtdXRhdGlvbnMgYXJlIGluY2x1ZGVkIGFuZCBob3cgdGhlaXIgZGF0YSBhbmQgZXJyb3JzXG4qIGFyZSB0cmFuc2Zvcm1lZC4gRWFjaCBvcHRpb24gZmFsbHMgYmFjayB0byB0aGUgY2xpZW50J3MgYGRlZmF1bHRPcHRpb25zLmRlaHlkcmF0ZWAuXG4qIEByZXR1cm5zIFRoZSBkZWh5ZHJhdGVkIHN0YXRlLCB3aXRoIHRoZSBpbmNsdWRlZCBgcXVlcmllc2AgYW5kIGBtdXRhdGlvbnNgLlxuKiBAZXhhbXBsZVxuKiBgYGB0c1xuKiBjb25zdCBxdWVyeUNsaWVudCA9IG5ldyBRdWVyeUNsaWVudCgpXG4qXG4qIGF3YWl0IHF1ZXJ5Q2xpZW50LnByZWZldGNoUXVlcnkoe1xuKiAgIHF1ZXJ5S2V5OiBbJ3Bvc3RzJ10sXG4qICAgcXVlcnlGbjogZ2V0UG9zdHMsXG4qIH0pXG4qXG4qIGNvbnN0IGRlaHlkcmF0ZWRTdGF0ZSA9IGRlaHlkcmF0ZShxdWVyeUNsaWVudClcbiogYGBgXG4qL1xuZnVuY3Rpb24gZGVoeWRyYXRlKGNsaWVudCwgb3B0aW9ucyA9IHt9KSB7XG5cdGNvbnN0IGZpbHRlck11dGF0aW9uID0gb3B0aW9ucy5zaG91bGREZWh5ZHJhdGVNdXRhdGlvbiA/PyBjbGllbnQuZ2V0RGVmYXVsdE9wdGlvbnMoKS5kZWh5ZHJhdGU/LnNob3VsZERlaHlkcmF0ZU11dGF0aW9uID8/IGRlZmF1bHRTaG91bGREZWh5ZHJhdGVNdXRhdGlvbjtcblx0Y29uc3QgbXV0YXRpb25zID0gY2xpZW50LmdldE11dGF0aW9uQ2FjaGUoKS5nZXRBbGwoKS5mbGF0TWFwKChtdXRhdGlvbikgPT4gZmlsdGVyTXV0YXRpb24obXV0YXRpb24pID8gW2RlaHlkcmF0ZU11dGF0aW9uKG11dGF0aW9uKV0gOiBbXSk7XG5cdGNvbnN0IGZpbHRlclF1ZXJ5ID0gb3B0aW9ucy5zaG91bGREZWh5ZHJhdGVRdWVyeSA/PyBjbGllbnQuZ2V0RGVmYXVsdE9wdGlvbnMoKS5kZWh5ZHJhdGU/LnNob3VsZERlaHlkcmF0ZVF1ZXJ5ID8/IGRlZmF1bHRTaG91bGREZWh5ZHJhdGVRdWVyeTtcblx0Y29uc3Qgc2hvdWxkUmVkYWN0RXJyb3JzID0gb3B0aW9ucy5zaG91bGRSZWRhY3RFcnJvcnMgPz8gY2xpZW50LmdldERlZmF1bHRPcHRpb25zKCkuZGVoeWRyYXRlPy5zaG91bGRSZWRhY3RFcnJvcnM7XG5cdGNvbnN0IHNlcmlhbGl6ZURhdGEgPSBvcHRpb25zLnNlcmlhbGl6ZURhdGEgPz8gY2xpZW50LmdldERlZmF1bHRPcHRpb25zKCkuZGVoeWRyYXRlPy5zZXJpYWxpemVEYXRhO1xuXHRyZXR1cm4ge1xuXHRcdG11dGF0aW9ucyxcblx0XHRxdWVyaWVzOiBjbGllbnQuZ2V0UXVlcnlDYWNoZSgpLmdldEFsbCgpLmZsYXRNYXAoKHF1ZXJ5KSA9PiBmaWx0ZXJRdWVyeShxdWVyeSkgPyBbZGVoeWRyYXRlUXVlcnkocXVlcnksIHNlcmlhbGl6ZURhdGEsIHNob3VsZFJlZGFjdEVycm9ycyldIDogW10pXG5cdH07XG59XG4vKipcbiogUmVzdG9yZXMgYSBgRGVoeWRyYXRlZFN0YXRlYCAoYXMgcHJvZHVjZWQgYnkgYGRlaHlkcmF0ZWApIGludG8gYSBgUXVlcnlDbGllbnRgJ3MgY2FjaGUsIHR5cGljYWxseSB0byBzZWVkIHRoZVxuKiBjbGllbnQgd2l0aCBkYXRhIGFscmVhZHkgZmV0Y2hlZCBvbiB0aGUgc2VydmVyLiBgbXV0YXRpb25zYCBhbmQgYHF1ZXJpZXNgIGFyZSBlYWNoIG9wdGlvbmFsIG9uIGBkZWh5ZHJhdGVkU3RhdGVgLlxuKiBRdWVyaWVzIG5vdCB5ZXQgaW4gdGhlIGNhY2hlIGFyZSBidWlsdCBmcm9tIHRoZSBkZWh5ZHJhdGVkIHNuYXBzaG90OyBxdWVyaWVzIHRoYXQgYWxyZWFkeSBleGlzdCBhcmUgb25seSB1cGRhdGVkXG4qIHdoZW4gdGhlIGRlaHlkcmF0ZWQgZGF0YSBpcyBuZXdlciB0aGFuIHdoYXQncyBhbHJlYWR5IGNhY2hlZC4gTmV3bHkgYnVpbHQgcXVlcmllcyBoYXZlIHRoZWlyIGBmZXRjaFN0YXR1c2AgcmVzZXRcbiogdG8gYCdpZGxlJ2Agc28gdGhleSBkb24ndCBoeWRyYXRlIHN0dWNrIGluIGEgZmV0Y2hpbmcgc3RhdGUuIElmIGEgZGVoeWRyYXRlZCBxdWVyeSBzdGlsbCBoYWQgYW4gaW4tZmxpZ2h0XG4qIHByb21pc2UsIGl0IGlzIHJlc3VtZWQgdmlhIGBxdWVyeS5mZXRjaCgpYCAocmV1c2luZyB0aGF0IHByb21pc2UgYXMgYGluaXRpYWxQcm9taXNlYCkgcmF0aGVyIHRoYW4gcmUtaW52b2tpbmdcbiogYHF1ZXJ5Rm5gLlxuKiBAcGFyYW0gY2xpZW50IC0gVGhlIGNsaWVudCB3aG9zZSBjYWNoZSBpcyByZXN0b3JlZCBpbnRvLlxuKiBAcGFyYW0gZGVoeWRyYXRlZFN0YXRlIC0gVGhlIGRlaHlkcmF0ZWQgc3RhdGUsIGUuZy4gcHJvZHVjZWQgYnkgYGRlaHlkcmF0ZWAgb24gdGhlIHNlcnZlci5cbiogQHBhcmFtIG9wdGlvbnMgLSBgZGVmYXVsdE9wdGlvbnNgIG1lcmdlZCBpbnRvIGV2ZXJ5IHJlc3RvcmVkIHF1ZXJ5IGFuZCBtdXRhdGlvbiAob24gdG9wIG9mIHRoZVxuKiBjbGllbnQncyBgZGVmYXVsdE9wdGlvbnMuaHlkcmF0ZWApLCBhbmQgYGRlc2VyaWFsaXplRGF0YWAgdG8gcmV2ZXJzZSBgc2VyaWFsaXplRGF0YWAuXG4qIEBleGFtcGxlXG4qIGBgYHRzXG4qIC8vIGRlaHlkcmF0ZWRTdGF0ZSB3YXMgcHJvZHVjZWQgYnkgYGRlaHlkcmF0ZWAgb24gdGhlIHNlcnZlclxuKiAvLyBhbmQgc2VudCB0byB0aGUgY2xpZW50LCBlLmcuIGVtYmVkZGVkIGluIHNlcnZlci1yZW5kZXJlZCBtYXJrdXAuXG4qIGNvbnN0IHF1ZXJ5Q2xpZW50ID0gbmV3IFF1ZXJ5Q2xpZW50KClcbipcbiogaHlkcmF0ZShxdWVyeUNsaWVudCwgZGVoeWRyYXRlZFN0YXRlKVxuKiBgYGBcbiovXG5mdW5jdGlvbiBoeWRyYXRlKGNsaWVudCwgZGVoeWRyYXRlZFN0YXRlLCBvcHRpb25zKSB7XG5cdGNvbnN0IG11dGF0aW9uQ2FjaGUgPSBjbGllbnQuZ2V0TXV0YXRpb25DYWNoZSgpO1xuXHRjb25zdCBxdWVyeUNhY2hlID0gY2xpZW50LmdldFF1ZXJ5Q2FjaGUoKTtcblx0Y29uc3QgZGVzZXJpYWxpemVEYXRhID0gb3B0aW9ucz8uZGVmYXVsdE9wdGlvbnM/LmRlc2VyaWFsaXplRGF0YSA/PyBjbGllbnQuZ2V0RGVmYXVsdE9wdGlvbnMoKS5oeWRyYXRlPy5kZXNlcmlhbGl6ZURhdGE7XG5cdGRlaHlkcmF0ZWRTdGF0ZS5tdXRhdGlvbnM/LmZvckVhY2goKHsgc3RhdGUsIC4uLm11dGF0aW9uT3B0aW9ucyB9KSA9PiB7XG5cdFx0bXV0YXRpb25DYWNoZS5idWlsZChjbGllbnQsIHtcblx0XHRcdC4uLmNsaWVudC5nZXREZWZhdWx0T3B0aW9ucygpLmh5ZHJhdGU/Lm11dGF0aW9ucyxcblx0XHRcdC4uLm9wdGlvbnM/LmRlZmF1bHRPcHRpb25zPy5tdXRhdGlvbnMsXG5cdFx0XHQuLi5tdXRhdGlvbk9wdGlvbnNcblx0XHR9LCBzdGF0ZSk7XG5cdH0pO1xuXHRkZWh5ZHJhdGVkU3RhdGUucXVlcmllcz8uZm9yRWFjaCgoeyBxdWVyeUtleSwgc3RhdGUsIHF1ZXJ5SGFzaCwgbWV0YSwgcHJvbWlzZSwgZGVoeWRyYXRlZEF0LCBxdWVyeVR5cGUgfSkgPT4ge1xuXHRcdGNvbnN0IHN5bmNEYXRhID0gcHJvbWlzZSA/IHRyeVJlc29sdmVTeW5jKHByb21pc2UpIDogdm9pZCAwO1xuXHRcdGNvbnN0IHJhd0RhdGEgPSBzdGF0ZS5kYXRhID09PSB2b2lkIDAgPyBzeW5jRGF0YT8uZGF0YSA6IHN0YXRlLmRhdGE7XG5cdFx0Y29uc3QgZGF0YSA9IHJhd0RhdGEgPT09IHZvaWQgMCA/IHJhd0RhdGEgOiBkZXNlcmlhbGl6ZURhdGEgPyBkZXNlcmlhbGl6ZURhdGEocmF3RGF0YSkgOiByYXdEYXRhO1xuXHRcdGxldCBxdWVyeSA9IHF1ZXJ5Q2FjaGUuZ2V0KHF1ZXJ5SGFzaCk7XG5cdFx0Y29uc3QgZXhpc3RpbmdRdWVyeUlzUGVuZGluZyA9IHF1ZXJ5Py5zdGF0ZS5zdGF0dXMgPT09IFwicGVuZGluZ1wiO1xuXHRcdGNvbnN0IGV4aXN0aW5nUXVlcnlJc0ZldGNoaW5nID0gcXVlcnk/LnN0YXRlLmZldGNoU3RhdHVzID09PSBcImZldGNoaW5nXCI7XG5cdFx0aWYgKHF1ZXJ5KSB7XG5cdFx0XHRjb25zdCBoYXNOZXdlclN5bmNEYXRhID0gc3luY0RhdGEgJiYgZGVoeWRyYXRlZEF0ID4gcXVlcnkuc3RhdGUuZGF0YVVwZGF0ZWRBdDtcblx0XHRcdGlmIChzdGF0ZS5kYXRhVXBkYXRlZEF0ID4gcXVlcnkuc3RhdGUuZGF0YVVwZGF0ZWRBdCB8fCBoYXNOZXdlclN5bmNEYXRhKSB7XG5cdFx0XHRcdGNvbnN0IHsgZmV0Y2hTdGF0dXM6IF9pZ25vcmVkLCAuLi5zZXJpYWxpemVkU3RhdGUgfSA9IHN0YXRlO1xuXHRcdFx0XHRxdWVyeS5zZXRTdGF0ZSh7XG5cdFx0XHRcdFx0Li4uc2VyaWFsaXplZFN0YXRlLFxuXHRcdFx0XHRcdGRhdGEsXG5cdFx0XHRcdFx0Li4uc3RhdGUuc3RhdHVzID09PSBcInBlbmRpbmdcIiAmJiBkYXRhICE9PSB2b2lkIDAgJiYge1xuXHRcdFx0XHRcdFx0c3RhdHVzOiBcInN1Y2Nlc3NcIixcblx0XHRcdFx0XHRcdGRhdGFVcGRhdGVkQXQ6IGRlaHlkcmF0ZWRBdCxcblx0XHRcdFx0XHRcdC4uLiFleGlzdGluZ1F1ZXJ5SXNGZXRjaGluZyAmJiB7IGZldGNoU3RhdHVzOiBcImlkbGVcIiB9XG5cdFx0XHRcdFx0fVxuXHRcdFx0XHR9KTtcblx0XHRcdH1cblx0XHR9IGVsc2UgcXVlcnkgPSBxdWVyeUNhY2hlLmJ1aWxkKGNsaWVudCwge1xuXHRcdFx0Li4uY2xpZW50LmdldERlZmF1bHRPcHRpb25zKCkuaHlkcmF0ZT8ucXVlcmllcyxcblx0XHRcdC4uLm9wdGlvbnM/LmRlZmF1bHRPcHRpb25zPy5xdWVyaWVzLFxuXHRcdFx0cXVlcnlLZXksXG5cdFx0XHRxdWVyeUhhc2gsXG5cdFx0XHRtZXRhLFxuXHRcdFx0X3R5cGU6IHF1ZXJ5VHlwZVxuXHRcdH0sIHtcblx0XHRcdC4uLnN0YXRlLFxuXHRcdFx0ZGF0YSxcblx0XHRcdGZldGNoU3RhdHVzOiBcImlkbGVcIixcblx0XHRcdHN0YXR1czogc3RhdGUuc3RhdHVzID09PSBcInBlbmRpbmdcIiAmJiBkYXRhICE9PSB2b2lkIDAgPyBcInN1Y2Nlc3NcIiA6IHN0YXRlLnN0YXR1cyxcblx0XHRcdC4uLnN0YXRlLnN0YXR1cyA9PT0gXCJwZW5kaW5nXCIgJiYgZGF0YSAhPT0gdm9pZCAwICYmIHsgZGF0YVVwZGF0ZWRBdDogZGVoeWRyYXRlZEF0IH1cblx0XHR9KTtcblx0XHRpZiAocHJvbWlzZSAmJiAhc3luY0RhdGEgJiYgIWV4aXN0aW5nUXVlcnlJc1BlbmRpbmcgJiYgIWV4aXN0aW5nUXVlcnlJc0ZldGNoaW5nICYmIGRlaHlkcmF0ZWRBdCA+IHF1ZXJ5LnN0YXRlLmRhdGFVcGRhdGVkQXQpIHF1ZXJ5LmZldGNoKHZvaWQgMCwgeyBpbml0aWFsUHJvbWlzZTogUHJvbWlzZS5yZXNvbHZlKHByb21pc2UpLnRoZW4oZGVzZXJpYWxpemVEYXRhKSB9KS5jYXRjaChub29wKTtcblx0fSk7XG59XG5leHBvcnQgeyBkZWZhdWx0U2hvdWxkRGVoeWRyYXRlTXV0YXRpb24sIGRlZmF1bHRTaG91bGREZWh5ZHJhdGVRdWVyeSwgZGVoeWRyYXRlLCBkZWh5ZHJhdGVRdWVyeSwgaHlkcmF0ZSB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1oeWRyYXRpb24uanMubWFwIiwiaW1wb3J0IHsgc3lzdGVtU2V0VGltZW91dFplcm8gfSBmcm9tIFwiLi90aW1lb3V0TWFuYWdlci5qc1wiO1xuLy8gc3JjL25vdGlmeU1hbmFnZXIudHNcbi8qKlxuKiBEZWZhdWx0IHNjaGVkdWxpbmcgZnVuY3Rpb24gdXNlZCBieSB0aGUgbm90aWZ5IG1hbmFnZXIuXG4qIFNjaGVkdWxlcyB0aGUgY2FsbGJhY2sgd2l0aCB0aGUgc3lzdGVtJ3MgYHNldFRpbWVvdXQoY2FsbGJhY2ssIDApYC5cbiovXG5jb25zdCBkZWZhdWx0U2NoZWR1bGVyID0gc3lzdGVtU2V0VGltZW91dFplcm87XG4vKipcbiogQ3JlYXRlcyBhIG5vdGlmeSBtYW5hZ2VyLCB3aGljaCBzY2hlZHVsZXMgYW5kIGJhdGNoZXMgbm90aWZpY2F0aW9ucyB0byBzdWJzY3JpYmVycy4gUXVlcnkgdXNlcyBhXG4qIHNpbmdsZSBpbnN0YW5jZSBvZiBpdCwgZXhwb3J0ZWQgYXMge0BsaW5rIG5vdGlmeU1hbmFnZXJ9LlxuKiBAcmV0dXJucyBBIG5ldyBub3RpZnkgbWFuYWdlci5cbiovXG5mdW5jdGlvbiBjcmVhdGVOb3RpZnlNYW5hZ2VyKCkge1xuXHRsZXQgcXVldWUgPSBbXTtcblx0bGV0IHRyYW5zYWN0aW9ucyA9IDA7XG5cdGxldCBub3RpZnlGbiA9IChjYWxsYmFjaykgPT4ge1xuXHRcdGNhbGxiYWNrKCk7XG5cdH07XG5cdGxldCBiYXRjaE5vdGlmeUZuID0gKGNhbGxiYWNrKSA9PiB7XG5cdFx0Y2FsbGJhY2soKTtcblx0fTtcblx0bGV0IHNjaGVkdWxlRm4gPSBkZWZhdWx0U2NoZWR1bGVyO1xuXHRjb25zdCBzY2hlZHVsZSA9IChjYWxsYmFjaykgPT4ge1xuXHRcdGlmICh0cmFuc2FjdGlvbnMpIHF1ZXVlLnB1c2goY2FsbGJhY2spO1xuXHRcdGVsc2Ugc2NoZWR1bGVGbigoKSA9PiB7XG5cdFx0XHRub3RpZnlGbihjYWxsYmFjayk7XG5cdFx0fSk7XG5cdH07XG5cdGNvbnN0IGZsdXNoID0gKCkgPT4ge1xuXHRcdGNvbnN0IG9yaWdpbmFsUXVldWUgPSBxdWV1ZTtcblx0XHRxdWV1ZSA9IFtdO1xuXHRcdGlmIChvcmlnaW5hbFF1ZXVlLmxlbmd0aCkgc2NoZWR1bGVGbigoKSA9PiB7XG5cdFx0XHRiYXRjaE5vdGlmeUZuKCgpID0+IHtcblx0XHRcdFx0b3JpZ2luYWxRdWV1ZS5mb3JFYWNoKChjYWxsYmFjaykgPT4ge1xuXHRcdFx0XHRcdG5vdGlmeUZuKGNhbGxiYWNrKTtcblx0XHRcdFx0fSk7XG5cdFx0XHR9KTtcblx0XHR9KTtcblx0fTtcblx0cmV0dXJuIHtcblx0XHQvKipcblx0XHQqIEJhdGNoZXMgYWxsIHVwZGF0ZXMgc2NoZWR1bGVkIGluc2lkZSB0aGUgcGFzc2VkIGNhbGxiYWNrLlxuXHRcdCogVGhpcyBpcyBtYWlubHkgdXNlZCBpbnRlcm5hbGx5IHRvIG9wdGltaXplIHF1ZXJ5IGNsaWVudCB1cGRhdGluZy5cblx0XHQqIEJhdGNoZXMgY2FuIGJlIG5lc3RlZDsgdGhlIHF1ZXVlIGlzIG9ubHkgZmx1c2hlZCBvbmNlIHRoZSBvdXRlcm1vc3QgYGJhdGNoYCBjYWxsIGZpbmlzaGVzLlxuXHRcdCogVGhlIHJldHVybiB2YWx1ZSBvZiBgY2FsbGJhY2tgIGlzIHBhc3NlZCB0aHJvdWdoLlxuXHRcdCogQHBhcmFtIGNhbGxiYWNrIC0gVGhlIGZ1bmN0aW9uIHRvIHJ1biBpbiB0aGUgYmF0Y2guXG5cdFx0KiBAcmV0dXJucyBUaGUgcmV0dXJuIHZhbHVlIG9mIGBjYWxsYmFja2AuXG5cdFx0Ki9cblx0XHRiYXRjaDogKGNhbGxiYWNrKSA9PiB7XG5cdFx0XHRsZXQgcmVzdWx0O1xuXHRcdFx0dHJhbnNhY3Rpb25zKys7XG5cdFx0XHR0cnkge1xuXHRcdFx0XHRyZXN1bHQgPSBjYWxsYmFjaygpO1xuXHRcdFx0fSBmaW5hbGx5IHtcblx0XHRcdFx0dHJhbnNhY3Rpb25zLS07XG5cdFx0XHRcdGlmICghdHJhbnNhY3Rpb25zKSBmbHVzaCgpO1xuXHRcdFx0fVxuXHRcdFx0cmV0dXJuIHJlc3VsdDtcblx0XHR9LFxuXHRcdC8qKlxuXHRcdCogQWxsIGNhbGxzIHRvIHRoZSB3cmFwcGVkIGZ1bmN0aW9uIHdpbGwgYmUgYmF0Y2hlZC5cblx0XHQqIEBwYXJhbSBjYWxsYmFjayAtIFRoZSBmdW5jdGlvbiB0byB3cmFwLlxuXHRcdCogQHJldHVybnMgQSBmdW5jdGlvbiB0aGF0IHNjaGVkdWxlcyBhIGNhbGwgdG8gYGNhbGxiYWNrYCB3aXRoIHRoZSBnaXZlbiBhcmd1bWVudHMuXG5cdFx0Ki9cblx0XHRiYXRjaENhbGxzOiAoY2FsbGJhY2spID0+IHtcblx0XHRcdHJldHVybiAoLi4uYXJncykgPT4ge1xuXHRcdFx0XHRzY2hlZHVsZSgoKSA9PiB7XG5cdFx0XHRcdFx0Y2FsbGJhY2soLi4uYXJncyk7XG5cdFx0XHRcdH0pO1xuXHRcdFx0fTtcblx0XHR9LFxuXHRcdC8qKlxuXHRcdCogU2NoZWR1bGVzIGEgZnVuY3Rpb24gdG8gYmUgcnVuIG9uIHRoZSBuZXh0IGJhdGNoLlxuXHRcdCogQnkgZGVmYXVsdCwgdGhlIGJhdGNoIGlzIHJ1biB3aXRoIGEgYHNldFRpbWVvdXRgLCBidXQgdGhpcyBjYW4gYmUgY29uZmlndXJlZCB2aWEgYHNldFNjaGVkdWxlcmAuXG5cdFx0Ki9cblx0XHRzY2hlZHVsZSxcblx0XHQvKipcblx0XHQqIFVzZSB0aGlzIG1ldGhvZCB0byBzZXQgYSBjdXN0b20gbm90aWZ5IGZ1bmN0aW9uLlxuXHRcdCogVGhpcyBjYW4gYmUgdXNlZCB0byBmb3IgZXhhbXBsZSB3cmFwIG5vdGlmaWNhdGlvbnMgd2l0aCBgUmVhY3QuYWN0YCB3aGlsZSBydW5uaW5nIHRlc3RzLlxuXHRcdCogQHBhcmFtIGZuIC0gUmVjZWl2ZXMgZWFjaCBub3RpZmljYXRpb24gY2FsbGJhY2sgYW5kIG11c3QgY2FsbCBpdC5cblx0XHQqL1xuXHRcdHNldE5vdGlmeUZ1bmN0aW9uOiAoZm4pID0+IHtcblx0XHRcdG5vdGlmeUZuID0gZm47XG5cdFx0fSxcblx0XHQvKipcblx0XHQqIFVzZSB0aGlzIG1ldGhvZCB0byBzZXQgYSBjdXN0b20gZnVuY3Rpb24gdG8gYmF0Y2ggbm90aWZpY2F0aW9ucyB0b2dldGhlciBpbnRvIGEgc2luZ2xlIHRpY2suXG5cdFx0KiBGcmFtZXdvcmsgYWRhcHRlcnMgdXNlIHRoaXMgdG8gcGx1ZyBpbiB0aGVpciBvd24gYmF0Y2hpbmcgcHJpbWl0aXZlLCBzbyB0aGF0IGEgc2luZ2xlIHF1ZXJ5XG5cdFx0KiB1cGRhdGUgb25seSB0cmlnZ2VycyBvbmUgcmUtcmVuZGVyIGluc3RlYWQgb2Ygb25lIHBlciBzdWJzY3JpYmVyLlxuXHRcdCogQHBhcmFtIGZuIC0gUmVjZWl2ZXMgYSBmdW5jdGlvbiB0aGF0IHJ1bnMgYSBiYXRjaCBvZiBub3RpZmljYXRpb25zIGFuZCBtdXN0IGNhbGwgaXQuXG5cdFx0KiBAZXhhbXBsZVxuXHRcdCogYGBgdHNcblx0XHQqIGltcG9ydCB7IG5vdGlmeU1hbmFnZXIgfSBmcm9tICdAdGFuc3RhY2svcXVlcnktY29yZSdcblx0XHQqIGltcG9ydCB7IGJhdGNoIH0gZnJvbSAnc29saWQtanMnXG5cdFx0KlxuXHRcdCogbm90aWZ5TWFuYWdlci5zZXRCYXRjaE5vdGlmeUZ1bmN0aW9uKGJhdGNoKVxuXHRcdCogYGBgXG5cdFx0Ki9cblx0XHRzZXRCYXRjaE5vdGlmeUZ1bmN0aW9uOiAoZm4pID0+IHtcblx0XHRcdGJhdGNoTm90aWZ5Rm4gPSBmbjtcblx0XHR9LFxuXHRcdC8qKlxuXHRcdCogQ29uZmlndXJlcyBhIGN1c3RvbSBjYWxsYmFjayB0aGF0IHNjaGVkdWxlcyB3aGVuIHRoZSBuZXh0IGJhdGNoIHJ1bnMuXG5cdFx0KiBUaGUgZGVmYXVsdCBiZWhhdmlvciBpcyBgc2V0VGltZW91dChjYWxsYmFjaywgMClgLlxuXHRcdCogQHBhcmFtIGZuIC0gUmVjZWl2ZXMgYSBjYWxsYmFjayB0aGF0IHJ1bnMgdGhlIG5leHQgYmF0Y2gsIGFuZCBzY2hlZHVsZXMgaXQuXG5cdFx0KiBAZXhhbXBsZVxuXHRcdCogYGBgdHNcblx0XHQqIGltcG9ydCB7IG5vdGlmeU1hbmFnZXIgfSBmcm9tICdAdGFuc3RhY2svcXVlcnktY29yZSdcblx0XHQqXG5cdFx0KiAvLyBTY2hlZHVsZSBiYXRjaGVzIGluIHRoZSBuZXh0IG1pY3JvdGFza1xuXHRcdCogbm90aWZ5TWFuYWdlci5zZXRTY2hlZHVsZXIocXVldWVNaWNyb3Rhc2spXG5cdFx0KlxuXHRcdCogLy8gU2NoZWR1bGUgYmF0Y2hlcyBiZWZvcmUgdGhlIG5leHQgZnJhbWUgaXMgcmVuZGVyZWRcblx0XHQqIG5vdGlmeU1hbmFnZXIuc2V0U2NoZWR1bGVyKHJlcXVlc3RBbmltYXRpb25GcmFtZSlcblx0XHQqXG5cdFx0KiAvLyBTY2hlZHVsZSBiYXRjaGVzIHNvbWUgdGltZSBpbiB0aGUgZnV0dXJlXG5cdFx0KiBub3RpZnlNYW5hZ2VyLnNldFNjaGVkdWxlcigoY2IpID0+IHNldFRpbWVvdXQoY2IsIDEwKSlcblx0XHQqIGBgYFxuXHRcdCovXG5cdFx0c2V0U2NoZWR1bGVyOiAoZm4pID0+IHtcblx0XHRcdHNjaGVkdWxlRm4gPSBmbjtcblx0XHR9XG5cdH07XG59XG4vKipcbiogSGFuZGxlcyBzY2hlZHVsaW5nIGFuZCBiYXRjaGluZyBjYWxsYmFja3MgaW4gVGFuU3RhY2sgUXVlcnkuXG4qL1xuY29uc3Qgbm90aWZ5TWFuYWdlciA9IGNyZWF0ZU5vdGlmeU1hbmFnZXIoKTtcbmV4cG9ydCB7IGNyZWF0ZU5vdGlmeU1hbmFnZXIsIGRlZmF1bHRTY2hlZHVsZXIsIG5vdGlmeU1hbmFnZXIgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9bm90aWZ5TWFuYWdlci5qcy5tYXAiLCJpbXBvcnQgeyBTdWJzY3JpYmFibGUgfSBmcm9tIFwiLi9zdWJzY3JpYmFibGUuanNcIjtcbi8vIHNyYy9vbmxpbmVNYW5hZ2VyLnRzXG4vKipcbiogVGhlIGBPbmxpbmVNYW5hZ2VyYCBtYW5hZ2VzIHRoZSBvbmxpbmUgc3RhdGUgd2l0aGluIFRhblN0YWNrIFF1ZXJ5LiBJdCBjYW5cbiogYmUgdXNlZCB0byBjaGFuZ2UgdGhlIGRlZmF1bHQgZXZlbnQgbGlzdGVuZXJzIG9yIHRvIG1hbnVhbGx5IGNoYW5nZSB0aGVcbiogb25saW5lIHN0YXRlLlxuKlxuKiBCeSBkZWZhdWx0LCB0aGUgYG9ubGluZU1hbmFnZXJgIGFzc3VtZXMgYW4gYWN0aXZlIG5ldHdvcmsgY29ubmVjdGlvbiwgYW5kXG4qIGxpc3RlbnMgdG8gdGhlIGBvbmxpbmVgIGFuZCBgb2ZmbGluZWAgZXZlbnRzIG9uIHRoZSBgd2luZG93YCBvYmplY3QgdG9cbiogZGV0ZWN0IGNoYW5nZXMuXG4qL1xudmFyIE9ubGluZU1hbmFnZXIgPSBjbGFzcyBleHRlbmRzIFN1YnNjcmliYWJsZSB7XG5cdCNvbmxpbmUgPSB0cnVlO1xuXHQjY2xlYW51cDtcblx0I3NldHVwO1xuXHRjb25zdHJ1Y3RvcigpIHtcblx0XHRzdXBlcigpO1xuXHRcdHRoaXMuI3NldHVwID0gKG9uT25saW5lKSA9PiB7XG5cdFx0XHRpZiAodHlwZW9mIHdpbmRvdyAhPT0gXCJ1bmRlZmluZWRcIiAmJiB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcikge1xuXHRcdFx0XHRjb25zdCBvbmxpbmVMaXN0ZW5lciA9ICgpID0+IG9uT25saW5lKHRydWUpO1xuXHRcdFx0XHRjb25zdCBvZmZsaW5lTGlzdGVuZXIgPSAoKSA9PiBvbk9ubGluZShmYWxzZSk7XG5cdFx0XHRcdHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKFwib25saW5lXCIsIG9ubGluZUxpc3RlbmVyLCBmYWxzZSk7XG5cdFx0XHRcdHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKFwib2ZmbGluZVwiLCBvZmZsaW5lTGlzdGVuZXIsIGZhbHNlKTtcblx0XHRcdFx0cmV0dXJuICgpID0+IHtcblx0XHRcdFx0XHR3aW5kb3cucmVtb3ZlRXZlbnRMaXN0ZW5lcihcIm9ubGluZVwiLCBvbmxpbmVMaXN0ZW5lcik7XG5cdFx0XHRcdFx0d2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJvZmZsaW5lXCIsIG9mZmxpbmVMaXN0ZW5lcik7XG5cdFx0XHRcdH07XG5cdFx0XHR9XG5cdFx0fTtcblx0fVxuXHRvblN1YnNjcmliZSgpIHtcblx0XHRpZiAoIXRoaXMuI2NsZWFudXApIHRoaXMuc2V0RXZlbnRMaXN0ZW5lcih0aGlzLiNzZXR1cCk7XG5cdH1cblx0b25VbnN1YnNjcmliZSgpIHtcblx0XHRpZiAoIXRoaXMuaGFzTGlzdGVuZXJzKCkpIHtcblx0XHRcdHRoaXMuI2NsZWFudXA/LigpO1xuXHRcdFx0dGhpcy4jY2xlYW51cCA9IHZvaWQgMDtcblx0XHR9XG5cdH1cblx0LyoqXG5cdCogYHNldEV2ZW50TGlzdGVuZXJgIGNhbiBiZSB1c2VkIHRvIHNldCBhIGN1c3RvbSBldmVudCBsaXN0ZW5lciB0aGF0IHdpbGxcblx0KiBiZSB1c2VkIHRvIGRldGVybWluZSB0aGUgb25saW5lIHN0YXRlLiBUaGUgcHJvdmlkZWQgYHNldHVwYCBmdW5jdGlvblxuXHQqIHJlY2VpdmVzIGEgYHNldE9ubGluZWAgY2FsbGJhY2sgdGhhdCBzaG91bGQgYmUgY2FsbGVkIHdpdGggYSBgYm9vbGVhbmBcblx0KiB3aGVuZXZlciB0aGUgb25saW5lIHN0YXRlIGNoYW5nZXMuXG5cdCogQHBhcmFtIHNldHVwIC0gUmVjZWl2ZXMgdGhlIGBzZXRPbmxpbmVgIGNhbGxiYWNrLCByZWdpc3RlcnMgdGhlIGV2ZW50IGxpc3RlbmVyLCBhbmQgbWF5IHJldHVyblxuXHQqIGEgY2xlYW51cCBmdW5jdGlvbiB0aGF0IGlzIGNhbGxlZCB3aGVuIHRoZSBsaXN0ZW5lciBpcyByZXBsYWNlZCBvciBubyBsb25nZXIgbmVlZGVkLlxuXHQqIEBleGFtcGxlXG5cdCogYGBgdHNcblx0KiBpbXBvcnQgTmV0SW5mbyBmcm9tICdAcmVhY3QtbmF0aXZlLWNvbW11bml0eS9uZXRpbmZvJ1xuXHQqIGltcG9ydCB7IG9ubGluZU1hbmFnZXIgfSBmcm9tICdAdGFuc3RhY2svcXVlcnktY29yZSdcblx0KlxuXHQqIG9ubGluZU1hbmFnZXIuc2V0RXZlbnRMaXN0ZW5lcigoc2V0T25saW5lKSA9PiB7XG5cdCogICByZXR1cm4gTmV0SW5mby5hZGRFdmVudExpc3RlbmVyKChzdGF0ZSkgPT4ge1xuXHQqICAgICBzZXRPbmxpbmUoISFzdGF0ZS5pc0Nvbm5lY3RlZClcblx0KiAgIH0pXG5cdCogfSlcblx0KiBgYGBcblx0Ki9cblx0c2V0RXZlbnRMaXN0ZW5lcihzZXR1cCkge1xuXHRcdHRoaXMuI3NldHVwID0gc2V0dXA7XG5cdFx0dGhpcy4jY2xlYW51cD8uKCk7XG5cdFx0dGhpcy4jY2xlYW51cCA9IHNldHVwKHRoaXMuc2V0T25saW5lLmJpbmQodGhpcykpO1xuXHR9XG5cdC8qKlxuXHQqIGBzZXRPbmxpbmVgIGNhbiBiZSB1c2VkIHRvIG1hbnVhbGx5IHNldCB0aGUgb25saW5lIHN0YXRlLlxuXHQqIEBwYXJhbSBvbmxpbmUgLSBUaGUgb25saW5lIHN0YXRlLlxuXHQqIEBleGFtcGxlXG5cdCogYGBgdHNcblx0KiBpbXBvcnQgeyBvbmxpbmVNYW5hZ2VyIH0gZnJvbSAnQHRhbnN0YWNrL3F1ZXJ5LWNvcmUnXG5cdCpcblx0KiAvLyBTZXQgdG8gb25saW5lXG5cdCogb25saW5lTWFuYWdlci5zZXRPbmxpbmUodHJ1ZSlcblx0KlxuXHQqIC8vIFNldCB0byBvZmZsaW5lXG5cdCogb25saW5lTWFuYWdlci5zZXRPbmxpbmUoZmFsc2UpXG5cdCogYGBgXG5cdCovXG5cdHNldE9ubGluZShvbmxpbmUpIHtcblx0XHRpZiAodGhpcy4jb25saW5lICE9PSBvbmxpbmUpIHtcblx0XHRcdHRoaXMuI29ubGluZSA9IG9ubGluZTtcblx0XHRcdHRoaXMubGlzdGVuZXJzLmZvckVhY2goKGxpc3RlbmVyKSA9PiB7XG5cdFx0XHRcdGxpc3RlbmVyKG9ubGluZSk7XG5cdFx0XHR9KTtcblx0XHR9XG5cdH1cblx0LyoqXG5cdCogYGlzT25saW5lYCBjYW4gYmUgdXNlZCB0byBnZXQgdGhlIGN1cnJlbnQgb25saW5lIHN0YXRlLlxuXHQqIEByZXR1cm5zIGB0cnVlYCBpZiBvbmxpbmUuXG5cdCovXG5cdGlzT25saW5lKCkge1xuXHRcdHJldHVybiB0aGlzLiNvbmxpbmU7XG5cdH1cbn07XG4vKipcbiogU2luZ2xldG9uIGluc3RhbmNlIG9mIHtAbGluayBPbmxpbmVNYW5hZ2VyfSwgdXNlZCB0byBtYW5hZ2UgYW5kIG9ic2VydmUgdGhlIG9ubGluZSBzdGF0ZSB3aXRoaW4gVGFuU3RhY2sgUXVlcnkuXG4qL1xuY29uc3Qgb25saW5lTWFuYWdlciA9IG5ldyBPbmxpbmVNYW5hZ2VyKCk7XG5leHBvcnQgeyBPbmxpbmVNYW5hZ2VyLCBvbmxpbmVNYW5hZ2VyIH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPW9ubGluZU1hbmFnZXIuanMubWFwIiwiaW1wb3J0IHsgbm9vcCwgc2xlZXAgfSBmcm9tIFwiLi91dGlscy5qc1wiO1xuaW1wb3J0IHsgaXNTZXJ2ZXIgfSBmcm9tIFwiLi9lbnZpcm9ubWVudE1hbmFnZXIuanNcIjtcbmltcG9ydCB7IGZvY3VzTWFuYWdlciB9IGZyb20gXCIuL2ZvY3VzTWFuYWdlci5qc1wiO1xuaW1wb3J0IHsgb25saW5lTWFuYWdlciB9IGZyb20gXCIuL29ubGluZU1hbmFnZXIuanNcIjtcbi8vIHNyYy9yZXRyeWVyLnRzXG4vKipcbiogVGhlIGRlZmF1bHQgYHJldHJ5RGVsYXlgOiBkb3VibGVzIHdpdGggZXZlcnkgZmFpbHVyZSwgc3RhcnRpbmcgYXQgMSBzZWNvbmQsIHVwIHRvIDMwIHNlY29uZHMuXG4qIEBwYXJhbSBmYWlsdXJlQ291bnQgLSBUaGUgbnVtYmVyIG9mIGZhaWx1cmVzIHNvIGZhci5cbiogQHJldHVybnMgVGhlIGRlbGF5IGJlZm9yZSB0aGUgbmV4dCByZXRyeSwgaW4gbWlsbGlzZWNvbmRzLlxuKi9cbmZ1bmN0aW9uIGRlZmF1bHRSZXRyeURlbGF5KGZhaWx1cmVDb3VudCkge1xuXHRyZXR1cm4gTWF0aC5taW4oMWUzICogMiAqKiBmYWlsdXJlQ291bnQsIDNlNCk7XG59XG4vKipcbiogQ2hlY2tzIHdoZXRoZXIgYSBmZXRjaCBjYW4gcnVuIGZvciB0aGUgZ2l2ZW4gbmV0d29yayBtb2RlLlxuKiBAcGFyYW0gbmV0d29ya01vZGUgLSBUaGUgYG5ldHdvcmtNb2RlYCBvcHRpb24uIERlZmF1bHRzIHRvIGAnb25saW5lJ2AuXG4qIEByZXR1cm5zIGB0cnVlYCBpZiB0aGUgbmV0d29yayBtb2RlIGlzIG5vdCBgJ29ubGluZSdgLCBvciBpZiBpdCBpcyBhbmQgdGhlIGNsaWVudCBpcyBvbmxpbmUuXG4qL1xuZnVuY3Rpb24gY2FuRmV0Y2gobmV0d29ya01vZGUpIHtcblx0cmV0dXJuIChuZXR3b3JrTW9kZSA/PyBcIm9ubGluZVwiKSA9PT0gXCJvbmxpbmVcIiA/IG9ubGluZU1hbmFnZXIuaXNPbmxpbmUoKSA6IHRydWU7XG59XG4vKipcbiogVGhlIGVycm9yIHRocm93biBieSBhIGBSZXRyeWVyYCAoYW5kIHN1cmZhY2VkIHRvIGBxdWVyeS5wcm9taXNlYC9gbXV0YXRpb25gKSB3aGVuIGEgZmV0Y2ggaXMgY2FuY2VsbGVkLCBlLmcuIHZpYVxuKiBgcXVlcnkuY2FuY2VsKClgLiBgcmV2ZXJ0YCwgaWYgYHRydWVgLCB0ZWxscyB0aGUgY2FsbGVyIHRvIHJlc3RvcmUgdGhlIHN0YXRlIHRoZSBxdWVyeSB3YXMgaW4gYmVmb3JlIHRoZSBmZXRjaFxuKiBzdGFydGVkIGluc3RlYWQgb2Ygc3VyZmFjaW5nIHRoZSBlcnJvci4gYHNpbGVudGAsIGlmIGB0cnVlYCwgdGVsbHMgdGhlIGNhbGxlciB0byBzdXBwcmVzcyB0aGlzIGVycm9yIGFuZCBpbnN0ZWFkXG4qIHJlc29sdmUgd2l0aCB0aGUgcHJvbWlzZSBvZiB0aGUgZmV0Y2ggdGhhdCB0cmlnZ2VyZWQgdGhlIGNhbmNlbGxhdGlvbi5cbiogQGV4YW1wbGVcbiogYGBgdHNcbiogcXVlcnkuY2FuY2VsKClcbipcbiogdHJ5IHtcbiogICBhd2FpdCBxdWVyeS5wcm9taXNlXG4qIH0gY2F0Y2ggKGVycm9yKSB7XG4qICAgaWYgKGVycm9yIGluc3RhbmNlb2YgQ2FuY2VsbGVkRXJyb3IpIHtcbiogICAgIC8vIHRoZSBmZXRjaCB3YXMgY2FuY2VsbGVkLCBlLmcuIHZpYSBgcXVlcnkuY2FuY2VsKClgXG4qICAgfVxuKiB9XG4qIGBgYFxuKi9cbnZhciBDYW5jZWxsZWRFcnJvciA9IGNsYXNzIGV4dGVuZHMgRXJyb3Ige1xuXHRjb25zdHJ1Y3RvcihvcHRpb25zKSB7XG5cdFx0c3VwZXIoXCJDYW5jZWxsZWRFcnJvclwiKTtcblx0XHR0aGlzLnJldmVydCA9IG9wdGlvbnM/LnJldmVydDtcblx0XHR0aGlzLnNpbGVudCA9IG9wdGlvbnM/LnNpbGVudDtcblx0fVxufTtcbi8qKlxuKiBDaGVja3Mgd2hldGhlciBhIHZhbHVlIGlzIGEgYENhbmNlbGxlZEVycm9yYC5cbiogQHBhcmFtIHZhbHVlIC0gVGhlIHZhbHVlIHRvIGNoZWNrLlxuKiBAcmV0dXJucyBgdHJ1ZWAgaWYgYHZhbHVlYCBpcyBhIGBDYW5jZWxsZWRFcnJvcmAuXG4qIEBkZXByZWNhdGVkIFVzZSBpbnN0YW5jZW9mIGBDYW5jZWxsZWRFcnJvcmAgaW5zdGVhZC5cbiovXG5mdW5jdGlvbiBpc0NhbmNlbGxlZEVycm9yKHZhbHVlKSB7XG5cdHJldHVybiB2YWx1ZSBpbnN0YW5jZW9mIENhbmNlbGxlZEVycm9yO1xufVxuLyoqXG4qIENyZWF0ZXMgYSByZXRyeWVyLCB3aGljaCBydW5zIGEgZnVuY3Rpb24gYW5kIHJldHJpZXMgaXQgb24gZmFpbHVyZSBhY2NvcmRpbmcgdG8gdGhlIGByZXRyeWAgYW5kXG4qIGByZXRyeURlbGF5YCBvcHRpb25zLiBJdCBwYXVzZXMgd2hpbGUgdGhlIG5ldHdvcmsgbW9kZSBkb2Vzbid0IGFsbG93IGZldGNoaW5nIG9yIGBjYW5SdW5gIHJldHVybnNcbiogYGZhbHNlYCwgYW5kIGNhbiBiZSBjYW5jZWxsZWQuIFF1ZXJpZXMgYW5kIG11dGF0aW9ucyB1c2UgaXQgdG8gcnVuIHRoZWlyIGBxdWVyeUZuYCBhbmRcbiogYG11dGF0aW9uRm5gLlxuKiBAcGFyYW0gY29uZmlnIC0gVGhlIGZ1bmN0aW9uIHRvIHJ1biwgdGhlIHJldHJ5IG9wdGlvbnMsIGFuZCB0aGUgY2FsbGJhY2tzIGZvciBmYWlsdXJlcywgcGF1c2luZyxcbiogY29udGludWluZywgYW5kIGNhbmNlbGxhdGlvbi5cbiogQHJldHVybnMgVGhlIHJldHJ5ZXIsIHdob3NlIGBwcm9taXNlYCBzZXR0bGVzIHdpdGggdGhlIHJlc3VsdCBvZiB0aGUgZnVuY3Rpb24uXG4qL1xuZnVuY3Rpb24gY3JlYXRlUmV0cnllcihjb25maWcpIHtcblx0bGV0IGlzUmV0cnlDYW5jZWxsZWQgPSBmYWxzZTtcblx0bGV0IGZhaWx1cmVDb3VudCA9IDA7XG5cdGxldCBjb250aW51ZUZuO1xuXHRsZXQgc3RhdHVzID0gXCJwZW5kaW5nXCI7XG5cdGxldCBwcm9taXNlUmVzb2x2ZTtcblx0bGV0IHByb21pc2VSZWplY3Q7XG5cdGNvbnN0IHByb21pc2UgPSBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG5cdFx0cHJvbWlzZVJlc29sdmUgPSByZXNvbHZlO1xuXHRcdHByb21pc2VSZWplY3QgPSByZWplY3Q7XG5cdH0pO1xuXHRwcm9taXNlLmNhdGNoKG5vb3ApO1xuXHRjb25zdCBpc1Jlc29sdmVkID0gKCkgPT4gc3RhdHVzICE9PSBcInBlbmRpbmdcIjtcblx0Y29uc3QgY2FuY2VsID0gKGNhbmNlbE9wdGlvbnMpID0+IHtcblx0XHRpZiAoIWlzUmVzb2x2ZWQoKSkge1xuXHRcdFx0Y29uc3QgZXJyb3IgPSBuZXcgQ2FuY2VsbGVkRXJyb3IoY2FuY2VsT3B0aW9ucyk7XG5cdFx0XHRyZWplY3QoZXJyb3IpO1xuXHRcdFx0Y29uZmlnLm9uQ2FuY2VsPy4oZXJyb3IpO1xuXHRcdH1cblx0fTtcblx0Y29uc3QgY2FuY2VsUmV0cnkgPSAoKSA9PiB7XG5cdFx0aXNSZXRyeUNhbmNlbGxlZCA9IHRydWU7XG5cdH07XG5cdGNvbnN0IGNvbnRpbnVlUmV0cnkgPSAoKSA9PiB7XG5cdFx0aXNSZXRyeUNhbmNlbGxlZCA9IGZhbHNlO1xuXHR9O1xuXHRjb25zdCBjYW5Db250aW51ZSA9ICgpID0+IGZvY3VzTWFuYWdlci5pc0ZvY3VzZWQoKSAmJiAoY29uZmlnLm5ldHdvcmtNb2RlID09PSBcImFsd2F5c1wiIHx8IG9ubGluZU1hbmFnZXIuaXNPbmxpbmUoKSkgJiYgY29uZmlnLmNhblJ1bigpO1xuXHRjb25zdCBjYW5TdGFydCA9ICgpID0+IGNhbkZldGNoKGNvbmZpZy5uZXR3b3JrTW9kZSkgJiYgY29uZmlnLmNhblJ1bigpO1xuXHRjb25zdCByZXNvbHZlID0gKHZhbHVlKSA9PiB7XG5cdFx0aWYgKCFpc1Jlc29sdmVkKCkpIHtcblx0XHRcdGNvbnRpbnVlRm4/LigpO1xuXHRcdFx0c3RhdHVzID0gXCJyZXNvbHZlZFwiO1xuXHRcdFx0cHJvbWlzZVJlc29sdmUodmFsdWUpO1xuXHRcdH1cblx0fTtcblx0Y29uc3QgcmVqZWN0ID0gKHZhbHVlKSA9PiB7XG5cdFx0aWYgKCFpc1Jlc29sdmVkKCkpIHtcblx0XHRcdGNvbnRpbnVlRm4/LigpO1xuXHRcdFx0c3RhdHVzID0gXCJyZWplY3RlZFwiO1xuXHRcdFx0cHJvbWlzZVJlamVjdCh2YWx1ZSk7XG5cdFx0fVxuXHR9O1xuXHRjb25zdCBwYXVzZSA9IChjYW5SZXN1bWUpID0+IHtcblx0XHRyZXR1cm4gbmV3IFByb21pc2UoKGNvbnRpbnVlUmVzb2x2ZSkgPT4ge1xuXHRcdFx0Y29udGludWVGbiA9ICh2YWx1ZSkgPT4ge1xuXHRcdFx0XHRpZiAoaXNSZXNvbHZlZCgpIHx8IGNhblJlc3VtZSgpKSBjb250aW51ZVJlc29sdmUodmFsdWUpO1xuXHRcdFx0fTtcblx0XHRcdGNvbmZpZy5vblBhdXNlPy4oKTtcblx0XHR9KS50aGVuKCgpID0+IHtcblx0XHRcdGNvbnRpbnVlRm4gPSB2b2lkIDA7XG5cdFx0XHRpZiAoIWlzUmVzb2x2ZWQoKSkgY29uZmlnLm9uQ29udGludWU/LigpO1xuXHRcdH0pO1xuXHR9O1xuXHRjb25zdCBydW4gPSAoKSA9PiB7XG5cdFx0aWYgKGlzUmVzb2x2ZWQoKSkgcmV0dXJuO1xuXHRcdGxldCBwcm9taXNlT3JWYWx1ZTtcblx0XHRjb25zdCBpbml0aWFsUHJvbWlzZSA9IGZhaWx1cmVDb3VudCA9PT0gMCA/IGNvbmZpZy5pbml0aWFsUHJvbWlzZSA6IHZvaWQgMDtcblx0XHR0cnkge1xuXHRcdFx0cHJvbWlzZU9yVmFsdWUgPSBpbml0aWFsUHJvbWlzZSA/PyBjb25maWcuZm4oKTtcblx0XHR9IGNhdGNoIChlcnJvcikge1xuXHRcdFx0cHJvbWlzZU9yVmFsdWUgPSBQcm9taXNlLnJlamVjdChlcnJvcik7XG5cdFx0fVxuXHRcdFByb21pc2UucmVzb2x2ZShwcm9taXNlT3JWYWx1ZSkudGhlbihyZXNvbHZlKS5jYXRjaCgoZXJyb3IpID0+IHtcblx0XHRcdGlmIChpc1Jlc29sdmVkKCkpIHJldHVybjtcblx0XHRcdGNvbnN0IHJldHJ5ID0gY29uZmlnLnJldHJ5ID8/IChpc1NlcnZlcigpID8gMCA6IDMpO1xuXHRcdFx0Y29uc3QgcmV0cnlEZWxheSA9IGNvbmZpZy5yZXRyeURlbGF5ID8/IGRlZmF1bHRSZXRyeURlbGF5O1xuXHRcdFx0Y29uc3QgZGVsYXkgPSB0eXBlb2YgcmV0cnlEZWxheSA9PT0gXCJmdW5jdGlvblwiID8gcmV0cnlEZWxheShmYWlsdXJlQ291bnQsIGVycm9yKSA6IHJldHJ5RGVsYXk7XG5cdFx0XHRjb25zdCBzaG91bGRSZXRyeSA9IHJldHJ5ID09PSB0cnVlIHx8IHR5cGVvZiByZXRyeSA9PT0gXCJudW1iZXJcIiAmJiBmYWlsdXJlQ291bnQgPCByZXRyeSB8fCB0eXBlb2YgcmV0cnkgPT09IFwiZnVuY3Rpb25cIiAmJiByZXRyeShmYWlsdXJlQ291bnQsIGVycm9yKTtcblx0XHRcdGlmIChpc1JldHJ5Q2FuY2VsbGVkIHx8ICFzaG91bGRSZXRyeSkge1xuXHRcdFx0XHRyZWplY3QoZXJyb3IpO1xuXHRcdFx0XHRyZXR1cm47XG5cdFx0XHR9XG5cdFx0XHRmYWlsdXJlQ291bnQrKztcblx0XHRcdGNvbmZpZy5vbkZhaWw/LihmYWlsdXJlQ291bnQsIGVycm9yKTtcblx0XHRcdHNsZWVwKGRlbGF5KS50aGVuKCgpID0+IHtcblx0XHRcdFx0cmV0dXJuIGlzUmVzb2x2ZWQoKSB8fCBjYW5Db250aW51ZSgpID8gdm9pZCAwIDogcGF1c2UoY2FuQ29udGludWUpO1xuXHRcdFx0fSkudGhlbigoKSA9PiB7XG5cdFx0XHRcdGlmIChpc1JldHJ5Q2FuY2VsbGVkKSByZWplY3QoZXJyb3IpO1xuXHRcdFx0XHRlbHNlIHJ1bigpO1xuXHRcdFx0fSk7XG5cdFx0fSk7XG5cdH07XG5cdHJldHVybiB7XG5cdFx0cHJvbWlzZSxcblx0XHRzdGF0dXM6ICgpID0+IHN0YXR1cyxcblx0XHRjYW5jZWwsXG5cdFx0Y29udGludWU6ICgpID0+IHtcblx0XHRcdGNvbnRpbnVlRm4/LigpO1xuXHRcdFx0cmV0dXJuIHByb21pc2U7XG5cdFx0fSxcblx0XHRjYW5jZWxSZXRyeSxcblx0XHRjb250aW51ZVJldHJ5LFxuXHRcdGNhblN0YXJ0LFxuXHRcdHN0YXJ0OiAoKSA9PiB7XG5cdFx0XHRpZiAoY2FuU3RhcnQoKSkgcnVuKCk7XG5cdFx0XHRlbHNlIHBhdXNlKGNhblN0YXJ0KS50aGVuKHJ1bik7XG5cdFx0XHRyZXR1cm4gcHJvbWlzZTtcblx0XHR9XG5cdH07XG59XG5leHBvcnQgeyBDYW5jZWxsZWRFcnJvciwgY2FuRmV0Y2gsIGNyZWF0ZVJldHJ5ZXIsIGlzQ2FuY2VsbGVkRXJyb3IgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9cmV0cnllci5qcy5tYXAiLCJpbXBvcnQgeyB0aW1lb3V0TWFuYWdlciB9IGZyb20gXCIuL3RpbWVvdXRNYW5hZ2VyLmpzXCI7XG5pbXBvcnQgeyBpc1ZhbGlkVGltZW91dCB9IGZyb20gXCIuL3V0aWxzLmpzXCI7XG5pbXBvcnQgeyBpc1NlcnZlciB9IGZyb20gXCIuL2Vudmlyb25tZW50TWFuYWdlci5qc1wiO1xuLy8gc3JjL3JlbW92YWJsZS50c1xuLyoqXG4qIFRoZSBiYXNlIGNsYXNzIGZvciBjYWNoZSBlbnRyaWVzIHRoYXQgYXJlIGdhcmJhZ2UgY29sbGVjdGVkIG9uY2Ugbm90aGluZyBpcyB1c2luZyB0aGVtIOKAlFxuKiBgUXVlcnlgIGFuZCBgTXV0YXRpb25gIGJvdGggZXh0ZW5kIGl0LiBgZ2NUaW1lYCBjb250cm9scyBob3cgbG9uZyBhbiB1bnVzZWQgZW50cnkgaXMga2VwdC5cbiovXG52YXIgUmVtb3ZhYmxlID0gY2xhc3Mge1xuXHQjZ2NUaW1lb3V0O1xuXHQvKipcblx0KiBDbGVhcnMgdGhlIHBlbmRpbmcgZ2FyYmFnZSBjb2xsZWN0aW9uIHRpbWVvdXQsIHNvIHRoZSBlbnRyeSBpcyBubyBsb25nZXIgc2NoZWR1bGVkIGZvciByZW1vdmFsLlxuXHQqIEEgc3ViY2xhc3MgbWF5IG92ZXJyaWRlIHRoaXMgdG8gcmVsZWFzZSB3aGF0IGl0IGhvbGRzIG9uIHRvIGFzIHdlbGwg4oCUIGBRdWVyeWAgYWxzbyBjYW5jZWxzIGFueVxuXHQqIGluLWZsaWdodCBmZXRjaC5cblx0Ki9cblx0ZGVzdHJveSgpIHtcblx0XHR0aGlzLmNsZWFyR2NUaW1lb3V0KCk7XG5cdH1cblx0LyoqXG5cdCogU2NoZWR1bGVzIHRoZSBlbnRyeSB0byBiZSByZW1vdmVkIGZyb20gaXRzIGNhY2hlIGFmdGVyIGBnY1RpbWVgLCByZXBsYWNpbmcgYW55IHRpbWVvdXQgc2NoZWR1bGVkXG5cdCogYmVmb3JlLiBOb3RoaW5nIGlzIHNjaGVkdWxlZCBpZiBgZ2NUaW1lYCBpcyBgSW5maW5pdHlgLlxuXHQqL1xuXHRzY2hlZHVsZUdjKCkge1xuXHRcdHRoaXMuY2xlYXJHY1RpbWVvdXQoKTtcblx0XHRpZiAoaXNWYWxpZFRpbWVvdXQodGhpcy5nY1RpbWUpKSB0aGlzLiNnY1RpbWVvdXQgPSB0aW1lb3V0TWFuYWdlci5zZXRUaW1lb3V0KCgpID0+IHtcblx0XHRcdHRoaXMub3B0aW9uYWxSZW1vdmUoKTtcblx0XHR9LCB0aGlzLmdjVGltZSk7XG5cdH1cblx0LyoqXG5cdCogVXBkYXRlcyBgZ2NUaW1lYCwga2VlcGluZyB0aGUgbG9uZ2VzdCBvbmUgc2VlbiBzbyBmYXIuIFdpdGhvdXQgYSB2YWx1ZSwgaXQgZGVmYXVsdHMgdG8gNSBtaW51dGVzXG5cdCogb24gdGhlIGNsaWVudCBhbmQgYEluZmluaXR5YCBvbiB0aGUgc2VydmVyLlxuXHQqIEBwYXJhbSBuZXdHY1RpbWUgLSBUaGUgYGdjVGltZWAgZnJvbSB0aGUgbGF0ZXN0IG9wdGlvbnMsIGlmIGFueS5cblx0Ki9cblx0dXBkYXRlR2NUaW1lKG5ld0djVGltZSkge1xuXHRcdHRoaXMuZ2NUaW1lID0gTWF0aC5tYXgodGhpcy5nY1RpbWUgfHwgMCwgbmV3R2NUaW1lID8/IChpc1NlcnZlcigpID8gSW5maW5pdHkgOiAzZTUpKTtcblx0fVxuXHQvKipcblx0KiBDYW5jZWxzIHRoZSBzY2hlZHVsZWQgcmVtb3ZhbCwgaWYgdGhlcmUgaXMgb25lLlxuXHQqL1xuXHRjbGVhckdjVGltZW91dCgpIHtcblx0XHRpZiAodGhpcy4jZ2NUaW1lb3V0ICE9PSB2b2lkIDApIHtcblx0XHRcdHRpbWVvdXRNYW5hZ2VyLmNsZWFyVGltZW91dCh0aGlzLiNnY1RpbWVvdXQpO1xuXHRcdFx0dGhpcy4jZ2NUaW1lb3V0ID0gdm9pZCAwO1xuXHRcdH1cblx0fVxufTtcbmV4cG9ydCB7IFJlbW92YWJsZSB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1yZW1vdmFibGUuanMubWFwIiwiaW1wb3J0IHsgYWRkQ29uc3VtZUF3YXJlU2lnbmFsLCBhZGRUb0VuZCwgYWRkVG9TdGFydCwgZW5zdXJlUXVlcnlGbiwgZmV0Y2hTaWduYWwgfSBmcm9tIFwiLi91dGlscy5qc1wiO1xuLy8gc3JjL2luZmluaXRlUXVlcnlCZWhhdmlvci50c1xuLyoqXG4qIENyZWF0ZXMgdGhlIGJlaGF2aW9yIHRoYXQgZmV0Y2hlcyB0aGUgcGFnZXMgb2YgYW4gaW5maW5pdGUgcXVlcnk6IHRoZSBuZXh0IG9yIHByZXZpb3VzIHBhZ2UgZm9yXG4qIGBmZXRjaE5leHRQYWdlYC9gZmV0Y2hQcmV2aW91c1BhZ2VgLCBvciBhbGwgcGFnZXMgYWdhaW4gZnJvbSB0aGUgc3RhcnQgb24gYSByZWZldGNoLlxuKiBAcGFyYW0gcGFnZXMgLSBUaGUgbnVtYmVyIG9mIHBhZ2VzIHRvIGZldGNoIGZyb20gdGhlIHN0YXJ0IHdoZW4gYWxsIHBhZ2VzIGFyZSBmZXRjaGVkIGFnYWluLFxuKiBlLmcuIGZyb20gdGhlIGBwYWdlc2Agb3B0aW9uIG9mIGBxdWVyeUNsaWVudC5pbmZpbml0ZVF1ZXJ5YC4gRGVmYXVsdHMgdG8gdGhlIG51bWJlciBvZiBjYWNoZWRcbiogcGFnZXMuXG4qIEByZXR1cm5zIFRoZSBxdWVyeSBiZWhhdmlvciB0byBzZXQgb24gYW4gaW5maW5pdGUgcXVlcnkuXG4qL1xuZnVuY3Rpb24gaW5maW5pdGVRdWVyeUJlaGF2aW9yKHBhZ2VzKSB7XG5cdHJldHVybiB7IG9uRmV0Y2g6IChjb250ZXh0LCBxdWVyeSkgPT4ge1xuXHRcdGNvbnN0IG9wdGlvbnMgPSBjb250ZXh0Lm9wdGlvbnM7XG5cdFx0Y29uc3QgZGlyZWN0aW9uID0gY29udGV4dC5mZXRjaE9wdGlvbnM/Lm1ldGE/LmZldGNoTW9yZT8uZGlyZWN0aW9uO1xuXHRcdGNvbnN0IG9sZFBhZ2VzID0gY29udGV4dC5zdGF0ZS5kYXRhPy5wYWdlcyB8fCBbXTtcblx0XHRjb25zdCBvbGRQYWdlUGFyYW1zID0gY29udGV4dC5zdGF0ZS5kYXRhPy5wYWdlUGFyYW1zIHx8IFtdO1xuXHRcdGxldCByZXN1bHQgPSB7XG5cdFx0XHRwYWdlczogW10sXG5cdFx0XHRwYWdlUGFyYW1zOiBbXVxuXHRcdH07XG5cdFx0bGV0IGN1cnJlbnRQYWdlID0gMDtcblx0XHRjb25zdCBmZXRjaEZuID0gYXN5bmMgKCkgPT4ge1xuXHRcdFx0bGV0IGNhbmNlbGxlZCA9IGZhbHNlO1xuXHRcdFx0Y29uc3Qgc2lnbmFsQ29udGV4dCA9IGNvbnRleHQ7XG5cdFx0XHRjb25zdCBhZGRTaWduYWxQcm9wZXJ0eSA9IChvYmplY3QpID0+IHtcblx0XHRcdFx0YWRkQ29uc3VtZUF3YXJlU2lnbmFsKG9iamVjdCwgKCkgPT4gY29udGV4dC5zaWduYWwsICgpID0+IGNhbmNlbGxlZCA9IHRydWUsIHNpZ25hbENvbnRleHRbZmV0Y2hTaWduYWxdKTtcblx0XHRcdH07XG5cdFx0XHRjb25zdCBxdWVyeUZuID0gZW5zdXJlUXVlcnlGbihjb250ZXh0Lm9wdGlvbnMsIGNvbnRleHQuZmV0Y2hPcHRpb25zKTtcblx0XHRcdGNvbnN0IGZldGNoUGFnZSA9IGFzeW5jIChkYXRhLCBwYXJhbSwgcHJldmlvdXMpID0+IHtcblx0XHRcdFx0aWYgKGNhbmNlbGxlZCkgcmV0dXJuIFByb21pc2UucmVqZWN0KGNvbnRleHQuc2lnbmFsLnJlYXNvbik7XG5cdFx0XHRcdGlmIChwYXJhbSA9PSBudWxsICYmIGRhdGEucGFnZXMubGVuZ3RoKSByZXR1cm4gUHJvbWlzZS5yZXNvbHZlKGRhdGEpO1xuXHRcdFx0XHRjb25zdCBjcmVhdGVRdWVyeUZuQ29udGV4dCA9ICgpID0+IHtcblx0XHRcdFx0XHRjb25zdCBxdWVyeUZuQ29udGV4dCA9IHtcblx0XHRcdFx0XHRcdGNsaWVudDogY29udGV4dC5jbGllbnQsXG5cdFx0XHRcdFx0XHRxdWVyeUtleTogY29udGV4dC5xdWVyeUtleSxcblx0XHRcdFx0XHRcdHBhZ2VQYXJhbTogcGFyYW0sXG5cdFx0XHRcdFx0XHRkaXJlY3Rpb246IHByZXZpb3VzID8gXCJiYWNrd2FyZFwiIDogXCJmb3J3YXJkXCIsXG5cdFx0XHRcdFx0XHRtZXRhOiBjb250ZXh0Lm9wdGlvbnMubWV0YVxuXHRcdFx0XHRcdH07XG5cdFx0XHRcdFx0YWRkU2lnbmFsUHJvcGVydHkocXVlcnlGbkNvbnRleHQpO1xuXHRcdFx0XHRcdHJldHVybiBxdWVyeUZuQ29udGV4dDtcblx0XHRcdFx0fTtcblx0XHRcdFx0Y29uc3QgcXVlcnlGbkNvbnRleHQgPSBjcmVhdGVRdWVyeUZuQ29udGV4dCgpO1xuXHRcdFx0XHRjb25zdCBwYWdlID0gYXdhaXQgcXVlcnlGbihxdWVyeUZuQ29udGV4dCk7XG5cdFx0XHRcdGNvbnN0IHsgbWF4UGFnZXMgfSA9IGNvbnRleHQub3B0aW9ucztcblx0XHRcdFx0Y29uc3QgYWRkVG8gPSBwcmV2aW91cyA/IGFkZFRvU3RhcnQgOiBhZGRUb0VuZDtcblx0XHRcdFx0cmV0dXJuIHtcblx0XHRcdFx0XHRwYWdlczogYWRkVG8oZGF0YS5wYWdlcywgcGFnZSwgbWF4UGFnZXMpLFxuXHRcdFx0XHRcdHBhZ2VQYXJhbXM6IGFkZFRvKGRhdGEucGFnZVBhcmFtcywgcGFyYW0sIG1heFBhZ2VzKVxuXHRcdFx0XHR9O1xuXHRcdFx0fTtcblx0XHRcdGlmIChkaXJlY3Rpb24gJiYgb2xkUGFnZXMubGVuZ3RoKSB7XG5cdFx0XHRcdGNvbnN0IHByZXZpb3VzID0gZGlyZWN0aW9uID09PSBcImJhY2t3YXJkXCI7XG5cdFx0XHRcdGNvbnN0IHBhZ2VQYXJhbUZuID0gcHJldmlvdXMgPyBnZXRQcmV2aW91c1BhZ2VQYXJhbSA6IGdldE5leHRQYWdlUGFyYW07XG5cdFx0XHRcdGNvbnN0IG9sZERhdGEgPSB7XG5cdFx0XHRcdFx0cGFnZXM6IG9sZFBhZ2VzLFxuXHRcdFx0XHRcdHBhZ2VQYXJhbXM6IG9sZFBhZ2VQYXJhbXNcblx0XHRcdFx0fTtcblx0XHRcdFx0cmVzdWx0ID0gYXdhaXQgZmV0Y2hQYWdlKG9sZERhdGEsIHBhZ2VQYXJhbUZuKG9wdGlvbnMsIG9sZERhdGEpLCBwcmV2aW91cyk7XG5cdFx0XHR9IGVsc2Uge1xuXHRcdFx0XHRjb25zdCByZW1haW5pbmdQYWdlcyA9IHBhZ2VzID8/IG9sZFBhZ2VzLmxlbmd0aDtcblx0XHRcdFx0ZG8ge1xuXHRcdFx0XHRcdGNvbnN0IHBhcmFtID0gY3VycmVudFBhZ2UgPT09IDAgPyBvbGRQYWdlUGFyYW1zWzBdID09PSB2b2lkIDAgPyBvcHRpb25zLmluaXRpYWxQYWdlUGFyYW0gOiBvbGRQYWdlUGFyYW1zWzBdIDogZ2V0TmV4dFBhZ2VQYXJhbShvcHRpb25zLCByZXN1bHQpO1xuXHRcdFx0XHRcdGlmIChjdXJyZW50UGFnZSA+IDAgJiYgcGFyYW0gPT0gbnVsbCkgYnJlYWs7XG5cdFx0XHRcdFx0cmVzdWx0ID0gYXdhaXQgZmV0Y2hQYWdlKHJlc3VsdCwgcGFyYW0pO1xuXHRcdFx0XHRcdGN1cnJlbnRQYWdlKys7XG5cdFx0XHRcdH0gd2hpbGUgKGN1cnJlbnRQYWdlIDwgcmVtYWluaW5nUGFnZXMpO1xuXHRcdFx0fVxuXHRcdFx0cmV0dXJuIHJlc3VsdDtcblx0XHR9O1xuXHRcdGlmIChjb250ZXh0Lm9wdGlvbnMucGVyc2lzdGVyKSBjb250ZXh0LmZldGNoRm4gPSAoKSA9PiB7XG5cdFx0XHRyZXR1cm4gY29udGV4dC5vcHRpb25zLnBlcnNpc3Rlcj8uKGZldGNoRm4sIHtcblx0XHRcdFx0Y2xpZW50OiBjb250ZXh0LmNsaWVudCxcblx0XHRcdFx0cXVlcnlLZXk6IGNvbnRleHQucXVlcnlLZXksXG5cdFx0XHRcdG1ldGE6IGNvbnRleHQub3B0aW9ucy5tZXRhLFxuXHRcdFx0XHRzaWduYWw6IGNvbnRleHQuc2lnbmFsXG5cdFx0XHR9LCBxdWVyeSk7XG5cdFx0fTtcblx0XHRlbHNlIGNvbnRleHQuZmV0Y2hGbiA9IGZldGNoRm47XG5cdH0gfTtcbn1cbi8qKlxuKiBDb21wdXRlcyB0aGUgcGFnZSBwYXJhbSBvZiB0aGUgcGFnZSBhZnRlciB0aGUgbGFzdCBvbmUsIHdpdGggdGhlIGBnZXROZXh0UGFnZVBhcmFtYCBvcHRpb24uXG4qIEBwYXJhbSBvcHRpb25zIC0gVGhlIGluZmluaXRlIHF1ZXJ5IG9wdGlvbnMuXG4qIEBwYXJhbSBkYXRhIC0gVGhlIGN1cnJlbnQgcGFnZXMgYW5kIHBhZ2UgcGFyYW1zLlxuKiBAcmV0dXJucyBUaGUgbmV4dCBwYWdlIHBhcmFtLCBvciBgdW5kZWZpbmVkYCBpZiB0aGVyZSBhcmUgbm8gcGFnZXMgeWV0LlxuKi9cbmZ1bmN0aW9uIGdldE5leHRQYWdlUGFyYW0ob3B0aW9ucywgeyBwYWdlcywgcGFnZVBhcmFtcyB9KSB7XG5cdGNvbnN0IGxhc3RJbmRleCA9IHBhZ2VzLmxlbmd0aCAtIDE7XG5cdHJldHVybiBwYWdlcy5sZW5ndGggPiAwID8gb3B0aW9ucy5nZXROZXh0UGFnZVBhcmFtKHBhZ2VzW2xhc3RJbmRleF0sIHBhZ2VzLCBwYWdlUGFyYW1zW2xhc3RJbmRleF0sIHBhZ2VQYXJhbXMpIDogdm9pZCAwO1xufVxuLyoqXG4qIENvbXB1dGVzIHRoZSBwYWdlIHBhcmFtIG9mIHRoZSBwYWdlIGJlZm9yZSB0aGUgZmlyc3Qgb25lLCB3aXRoIHRoZSBgZ2V0UHJldmlvdXNQYWdlUGFyYW1gXG4qIG9wdGlvbi5cbiogQHBhcmFtIG9wdGlvbnMgLSBUaGUgaW5maW5pdGUgcXVlcnkgb3B0aW9ucy5cbiogQHBhcmFtIGRhdGEgLSBUaGUgY3VycmVudCBwYWdlcyBhbmQgcGFnZSBwYXJhbXMuXG4qIEByZXR1cm5zIFRoZSBwcmV2aW91cyBwYWdlIHBhcmFtLCBvciBgdW5kZWZpbmVkYCBpZiB0aGVyZSBhcmUgbm8gcGFnZXMgeWV0IG9yIG5vXG4qIGBnZXRQcmV2aW91c1BhZ2VQYXJhbWAgb3B0aW9uLlxuKi9cbmZ1bmN0aW9uIGdldFByZXZpb3VzUGFnZVBhcmFtKG9wdGlvbnMsIHsgcGFnZXMsIHBhZ2VQYXJhbXMgfSkge1xuXHRyZXR1cm4gcGFnZXMubGVuZ3RoID4gMCA/IG9wdGlvbnMuZ2V0UHJldmlvdXNQYWdlUGFyYW0/LihwYWdlc1swXSwgcGFnZXMsIHBhZ2VQYXJhbXNbMF0sIHBhZ2VQYXJhbXMpIDogdm9pZCAwO1xufVxuLyoqXG4qIENoZWNrcyBpZiB0aGVyZSBpcyBhIG5leHQgcGFnZS5cbiogQHBhcmFtIG9wdGlvbnMgLSBUaGUgaW5maW5pdGUgcXVlcnkgb3B0aW9ucyB3aXRoIGBnZXROZXh0UGFnZVBhcmFtYC5cbiogQHBhcmFtIGRhdGEgLSBUaGUgY3VycmVudCBwYWdlcyBhbmQgcGFnZSBwYXJhbXMuXG4qIEByZXR1cm5zIGB0cnVlYCBpZiBgZ2V0TmV4dFBhZ2VQYXJhbWAgcmV0dXJucyBhIHZhbHVlIG90aGVyIHRoYW4gYG51bGxgIG9yIGB1bmRlZmluZWRgLlxuKi9cbmZ1bmN0aW9uIGhhc05leHRQYWdlKG9wdGlvbnMsIGRhdGEpIHtcblx0aWYgKCFkYXRhKSByZXR1cm4gZmFsc2U7XG5cdHJldHVybiBnZXROZXh0UGFnZVBhcmFtKG9wdGlvbnMsIGRhdGEpICE9IG51bGw7XG59XG4vKipcbiogQ2hlY2tzIGlmIHRoZXJlIGlzIGEgcHJldmlvdXMgcGFnZS5cbiogQHBhcmFtIG9wdGlvbnMgLSBUaGUgaW5maW5pdGUgcXVlcnkgb3B0aW9ucyB3aXRoIGBnZXRQcmV2aW91c1BhZ2VQYXJhbWAuXG4qIEBwYXJhbSBkYXRhIC0gVGhlIGN1cnJlbnQgcGFnZXMgYW5kIHBhZ2UgcGFyYW1zLlxuKiBAcmV0dXJucyBgdHJ1ZWAgaWYgYGdldFByZXZpb3VzUGFnZVBhcmFtYCBpcyBzZXQgYW5kIHJldHVybnMgYSB2YWx1ZSBvdGhlciB0aGFuIGBudWxsYCBvclxuKiBgdW5kZWZpbmVkYC5cbiovXG5mdW5jdGlvbiBoYXNQcmV2aW91c1BhZ2Uob3B0aW9ucywgZGF0YSkge1xuXHRpZiAoIWRhdGEgfHwgIW9wdGlvbnMuZ2V0UHJldmlvdXNQYWdlUGFyYW0pIHJldHVybiBmYWxzZTtcblx0cmV0dXJuIGdldFByZXZpb3VzUGFnZVBhcmFtKG9wdGlvbnMsIGRhdGEpICE9IG51bGw7XG59XG5leHBvcnQgeyBoYXNOZXh0UGFnZSwgaGFzUHJldmlvdXNQYWdlLCBpbmZpbml0ZVF1ZXJ5QmVoYXZpb3IgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9aW5maW5pdGVRdWVyeUJlaGF2aW9yLmpzLm1hcCIsImltcG9ydCB7IGVuc3VyZVF1ZXJ5Rm4sIGZldGNoU2lnbmFsLCBub29wLCByZXBsYWNlRGF0YSwgcmVzb2x2ZVF1ZXJ5VmFsdWUsIHNraXBUb2tlbiwgdGltZVVudGlsU3RhbGUgfSBmcm9tIFwiLi91dGlscy5qc1wiO1xuaW1wb3J0IHsgbm90aWZ5TWFuYWdlciB9IGZyb20gXCIuL25vdGlmeU1hbmFnZXIuanNcIjtcbmltcG9ydCB7IENhbmNlbGxlZEVycm9yLCBjYW5GZXRjaCwgY3JlYXRlUmV0cnllciB9IGZyb20gXCIuL3JldHJ5ZXIuanNcIjtcbmltcG9ydCB7IFJlbW92YWJsZSB9IGZyb20gXCIuL3JlbW92YWJsZS5qc1wiO1xuaW1wb3J0IHsgaW5maW5pdGVRdWVyeUJlaGF2aW9yIH0gZnJvbSBcIi4vaW5maW5pdGVRdWVyeUJlaGF2aW9yLmpzXCI7XG4vLyBzcmMvcXVlcnkudHNcbi8qKlxuKiBSZXByZXNlbnRzIGEgc2luZ2xlIGNhY2hlZCBxdWVyeS4gQSBgUXVlcnlgIGhvbGRzIHRoZSBxdWVyeSdzIGtleSwgb3B0aW9ucyxcbiogc3RhdGUgKGRhdGEvZXJyb3Ivc3RhdHVzKSwgYW5kIHRoZSBvYnNlcnZlcnMgY3VycmVudGx5IHN1YnNjcmliZWQgdG8gaXQuXG4qXG4qIEluc3RhbmNlcyBhcmUgY3JlYXRlZCBhbmQgbWFuYWdlZCBpbnRlcm5hbGx5IGJ5IGBRdWVyeUNhY2hlYDsgYXBwbGljYXRpb25cbiogY29kZSB0eXBpY2FsbHkgaW50ZXJhY3RzIHdpdGggcXVlcmllcyBpbmRpcmVjdGx5IHRocm91Z2ggYFF1ZXJ5Q2xpZW50YCBvclxuKiBhIGZyYW1ld29yayBob29rIGxpa2UgYHVzZVF1ZXJ5YC4gRGlyZWN0IGFjY2VzcyB0byBhIGBRdWVyeWAgaW5zdGFuY2UgaXNcbiogcG9zc2libGUgdmlhIGBxdWVyeUNhY2hlLmZpbmQoKWAvYGZpbmRBbGwoKWAgZm9yIGluc3BlY3RpbmcgY2FjaGUgc3RhdGUuXG4qIEBleGFtcGxlXG4qIGBgYHRzXG4qIGNvbnN0IHF1ZXJ5Q2FjaGUgPSBxdWVyeUNsaWVudC5nZXRRdWVyeUNhY2hlKClcbiogY29uc3QgcXVlcnkgPSBxdWVyeUNhY2hlLmZpbmQoeyBxdWVyeUtleTogWydwb3N0cyddIH0pXG4qXG4qIGlmIChxdWVyeSkge1xuKiAgIGNvbnNvbGUubG9nKHF1ZXJ5LnN0YXRlLmRhdGFVcGRhdGVkQXQpXG4qIH1cbiogYGBgXG4qL1xudmFyIFF1ZXJ5ID0gY2xhc3MgZXh0ZW5kcyBSZW1vdmFibGUge1xuXHQjcXVlcnlUeXBlO1xuXHQjaW5pdGlhbFN0YXRlO1xuXHQjcmV2ZXJ0U3RhdGU7XG5cdCNjYWNoZTtcblx0I2NsaWVudDtcblx0I3JldHJ5ZXI7XG5cdCNmZXRjaFByb21pc2U7XG5cdCNkZWZhdWx0T3B0aW9ucztcblx0I2Fib3J0U2lnbmFsQ29uc3VtZWQ7XG5cdGNvbnN0cnVjdG9yKGNvbmZpZykge1xuXHRcdHN1cGVyKCk7XG5cdFx0dGhpcy4jYWJvcnRTaWduYWxDb25zdW1lZCA9IGZhbHNlO1xuXHRcdHRoaXMuI2RlZmF1bHRPcHRpb25zID0gY29uZmlnLmRlZmF1bHRPcHRpb25zO1xuXHRcdHRoaXMuc2V0T3B0aW9ucyhjb25maWcub3B0aW9ucyk7XG5cdFx0dGhpcy5vYnNlcnZlcnMgPSBbXTtcblx0XHR0aGlzLiNjbGllbnQgPSBjb25maWcuY2xpZW50O1xuXHRcdHRoaXMuI2NhY2hlID0gdGhpcy4jY2xpZW50LmdldFF1ZXJ5Q2FjaGUoKTtcblx0XHR0aGlzLnF1ZXJ5S2V5ID0gY29uZmlnLnF1ZXJ5S2V5O1xuXHRcdHRoaXMucXVlcnlIYXNoID0gY29uZmlnLnF1ZXJ5SGFzaDtcblx0XHR0aGlzLiNpbml0aWFsU3RhdGUgPSBnZXREZWZhdWx0U3RhdGUodGhpcy5vcHRpb25zKTtcblx0XHR0aGlzLnN0YXRlID0gY29uZmlnLnN0YXRlID8/IHRoaXMuI2luaXRpYWxTdGF0ZTtcblx0XHR0aGlzLnNjaGVkdWxlR2MoKTtcblx0fVxuXHQvKipcblx0KiBUaGUgYG1ldGFgIG9iamVjdCBwYXNzZWQgaW4gdGhlIHF1ZXJ5J3Mgb3B0aW9ucywgaWYgYW55LlxuXHQqIEByZXR1cm5zIFRoZSBxdWVyeSdzIGBtZXRhYCwgb3IgYHVuZGVmaW5lZGAgaWYgbm9uZSB3YXMgc2V0LlxuXHQqL1xuXHRnZXQgbWV0YSgpIHtcblx0XHRyZXR1cm4gdGhpcy5vcHRpb25zLm1ldGE7XG5cdH1cblx0LyoqXG5cdCogYCdpbmZpbml0ZSdgIGZvciBhbiBpbmZpbml0ZSBxdWVyeSwgb3RoZXJ3aXNlIGB1bmRlZmluZWRgLlxuXHQqIEBpbnRlcm5hbFxuXHQqIEByZXR1cm5zIFRoZSB0eXBlIG9mIHRoZSBxdWVyeSwgc2V0IGZyb20gdGhlIGBfdHlwZWAgb3B0aW9uIChlLmcuIGAnaW5maW5pdGUnYCkuXG5cdCovXG5cdGdldCBxdWVyeVR5cGUoKSB7XG5cdFx0cmV0dXJuIHRoaXMuI3F1ZXJ5VHlwZTtcblx0fVxuXHQvKipcblx0KiBUaGUgcHJvbWlzZSBmb3IgdGhlIGN1cnJlbnRseSBpbi1mbGlnaHQgZmV0Y2gsIGlmIHRoZSBxdWVyeSBpcyBmZXRjaGluZy5cblx0KiBgdW5kZWZpbmVkYCB3aGVuIHRoZSBxdWVyeSBpcyBub3QgZmV0Y2hpbmcuXG5cdCogQHJldHVybnMgVGhlIHByb21pc2Ugb2YgdGhlIGluLWZsaWdodCBmZXRjaCwgb3IgYHVuZGVmaW5lZGAuXG5cdCovXG5cdGdldCBwcm9taXNlKCkge1xuXHRcdHJldHVybiB0aGlzLiNyZXRyeWVyPy5wcm9taXNlO1xuXHR9XG5cdC8qKlxuXHQqIFJlcGxhY2VzIHRoZSBxdWVyeSdzIG9wdGlvbnMgYW5kIGFwcGxpZXMgdGhlaXIgYGdjVGltZWAuIElmIHRoZSBxdWVyeSBoYXMgbm8gZGF0YSB5ZXQsIGl0IGdldHNcblx0KiB0aGUgYGluaXRpYWxEYXRhYCBmcm9tIHRoZSBuZXcgb3B0aW9ucywgaWYgYW55LlxuXHQqIEBpbnRlcm5hbFxuXHQqIEBwYXJhbSBvcHRpb25zIC0gVGhlIG5ldyBxdWVyeSBvcHRpb25zLCBtZXJnZWQgb24gdG9wIG9mIHRoZSBxdWVyeSdzIGRlZmF1bHQgb3B0aW9ucy5cblx0Ki9cblx0c2V0T3B0aW9ucyhvcHRpb25zKSB7XG5cdFx0dGhpcy5vcHRpb25zID0ge1xuXHRcdFx0Li4udGhpcy4jZGVmYXVsdE9wdGlvbnMsXG5cdFx0XHQuLi5vcHRpb25zXG5cdFx0fTtcblx0XHRpZiAob3B0aW9ucz8uX3R5cGUpIHRoaXMuI3F1ZXJ5VHlwZSA9IG9wdGlvbnMuX3R5cGU7XG5cdFx0dGhpcy51cGRhdGVHY1RpbWUodGhpcy5vcHRpb25zLmdjVGltZSk7XG5cdFx0aWYgKHRoaXMuc3RhdGUgJiYgdGhpcy5zdGF0ZS5kYXRhID09PSB2b2lkIDApIHtcblx0XHRcdGNvbnN0IGRlZmF1bHRTdGF0ZSA9IGdldERlZmF1bHRTdGF0ZSh0aGlzLm9wdGlvbnMpO1xuXHRcdFx0aWYgKGRlZmF1bHRTdGF0ZS5kYXRhICE9PSB2b2lkIDApIHtcblx0XHRcdFx0dGhpcy5zZXRTdGF0ZShzdWNjZXNzU3RhdGUoZGVmYXVsdFN0YXRlLmRhdGEsIGRlZmF1bHRTdGF0ZS5kYXRhVXBkYXRlZEF0KSk7XG5cdFx0XHRcdHRoaXMuI2luaXRpYWxTdGF0ZSA9IGRlZmF1bHRTdGF0ZTtcblx0XHRcdH1cblx0XHR9XG5cdH1cblx0b3B0aW9uYWxSZW1vdmUoKSB7XG5cdFx0aWYgKCF0aGlzLm9ic2VydmVycy5sZW5ndGggJiYgdGhpcy5zdGF0ZS5mZXRjaFN0YXR1cyA9PT0gXCJpZGxlXCIpIHRoaXMuI2NhY2hlLnJlbW92ZSh0aGlzKTtcblx0fVxuXHQvKipcblx0KiBXcml0ZXMgbmV3IGRhdGEgdG8gdGhlIHF1ZXJ5IGFuZCBtYXJrcyBpdCBhcyBzdWNjZXNzZnVsbHkgZmV0Y2hlZC5cblx0KiBAaW50ZXJuYWxcblx0KiBAcGFyYW0gbmV3RGF0YSAtIFRoZSBkYXRhIHRvIHdyaXRlLiBTdHJ1Y3R1cmFsIHNoYXJpbmcgd2l0aCB0aGUgY3VycmVudCBkYXRhIGlzIGFwcGxpZWQuXG5cdCogQHBhcmFtIG9wdGlvbnMgLSBTZXQgYHVwZGF0ZWRBdGAgdG8gb3ZlcnJpZGUgdGhlIHRpbWVzdGFtcCwgYW5kIGBtYW51YWxgIHRvIG1hcmsgdGhlIHdyaXRlIGFzXG5cdCogbWFudWFsIChlLmcuIGZyb20gYHF1ZXJ5Q2xpZW50LnNldFF1ZXJ5RGF0YWApLlxuXHQqIEByZXR1cm5zIFRoZSBkYXRhIHRoYXQgd2FzIHdyaXR0ZW4uXG5cdCovXG5cdHNldERhdGEobmV3RGF0YSwgb3B0aW9ucykge1xuXHRcdGNvbnN0IGRhdGEgPSByZXBsYWNlRGF0YSh0aGlzLnN0YXRlLmRhdGEsIG5ld0RhdGEsIHRoaXMub3B0aW9ucyk7XG5cdFx0dGhpcy4jZGlzcGF0Y2goe1xuXHRcdFx0ZGF0YSxcblx0XHRcdHR5cGU6IFwic3VjY2Vzc1wiLFxuXHRcdFx0ZGF0YVVwZGF0ZWRBdDogb3B0aW9ucz8udXBkYXRlZEF0LFxuXHRcdFx0bWFudWFsOiBvcHRpb25zPy5tYW51YWxcblx0XHR9KTtcblx0XHRyZXR1cm4gZGF0YTtcblx0fVxuXHQvKipcblx0KiBNZXJnZXMgdGhlIGdpdmVuIHBhcnRpYWwgc3RhdGUgZGlyZWN0bHkgaW50byB0aGlzIHF1ZXJ5J3Mgc3RhdGUsIG5vdGlmeWluZyBvYnNlcnZlcnMuIFVzZWRcblx0KiBieSBwZXJzaXN0ZW5jZSBhbmQgYnJvYWRjYXN0IHBsdWdpbnMgdG8gcmVzdG9yZSBhIHN0YXRlIHNuYXBzaG90LCBhbmQgYnkgZGV2dG9vbHMgdG8gbGV0IGFcblx0KiB1c2VyIG1hbnVhbGx5IHRyaWdnZXIgYSBsb2FkaW5nL2Vycm9yIHN0YXRlIG9yIGVkaXQgdGhlIGNhY2hlZCBkYXRhLlxuXHQqIEBwYXJhbSBzdGF0ZSAtIFRoZSBwYXJ0aWFsIHN0YXRlIHRvIG1lcmdlIGludG8gdGhlIHF1ZXJ5J3Mgc3RhdGUuXG5cdCovXG5cdHNldFN0YXRlKHN0YXRlKSB7XG5cdFx0dGhpcy4jZGlzcGF0Y2goe1xuXHRcdFx0dHlwZTogXCJzZXRTdGF0ZVwiLFxuXHRcdFx0c3RhdGVcblx0XHR9KTtcblx0fVxuXHQvKipcblx0KiBDYW5jZWxzIHRoZSBxdWVyeSdzIGN1cnJlbnRseSBpbi1mbGlnaHQgZmV0Y2gsIGlmIGFueS5cblx0KiAtIFJldHVybnMgYSBwcm9taXNlIHRoYXQgcmVzb2x2ZXMgb25jZSB0aGUgY2FuY2VsbGF0aW9uIGhhcyBzZXR0bGVkLlxuXHQqIC0gSWYgbm8gZmV0Y2ggaXMgaW4gcHJvZ3Jlc3MsIHJlc29sdmVzIGltbWVkaWF0ZWx5LlxuXHQqIEBwYXJhbSBvcHRpb25zIC0gU2V0IGByZXZlcnRgIHRvIHJlc3RvcmUgdGhlIHN0YXRlIGZyb20gYmVmb3JlIHRoZSBmZXRjaCBzdGFydGVkLCBhbmQgYHNpbGVudGBcblx0KiB0byBzdXBwcmVzcyB0aGUgY2FuY2VsbGF0aW9uIGVycm9yIHdoZW4gYSBuZXcgZmV0Y2ggcmVwbGFjZXMgdGhlIGNhbmNlbGxlZCBvbmUuXG5cdCogQHJldHVybnMgQSBwcm9taXNlIHRoYXQgcmVzb2x2ZXMgb25jZSB0aGUgY2FuY2VsbGF0aW9uIGhhcyBzZXR0bGVkLlxuXHQqIEBleGFtcGxlXG5cdCogYGBgdHNcblx0KiBhd2FpdCBxdWVyeS5jYW5jZWwoKVxuXHQqIGBgYFxuXHQqL1xuXHRjYW5jZWwob3B0aW9ucykge1xuXHRcdGNvbnN0IHByb21pc2UgPSB0aGlzLiNyZXRyeWVyPy5wcm9taXNlO1xuXHRcdHRoaXMuI3JldHJ5ZXI/LmNhbmNlbChvcHRpb25zKTtcblx0XHRyZXR1cm4gcHJvbWlzZSA/IHByb21pc2UudGhlbihub29wKS5jYXRjaChub29wKSA6IFByb21pc2UucmVzb2x2ZSgpO1xuXHR9XG5cdC8qKlxuXHQqIENsZWFycyB0aGUgcXVlcnkncyBnYXJiYWdlIGNvbGxlY3Rpb24gdGltZW91dCBhbmQgc2lsZW50bHkgY2FuY2VscyBhbnlcblx0KiBpbi1mbGlnaHQgZmV0Y2guIENhbGxlZCBieSBgUXVlcnlDYWNoZWAgd2hlbiB0aGUgcXVlcnkgaXMgcmVtb3ZlZCBmcm9tXG5cdCogdGhlIGNhY2hlLlxuXHQqIEBzZWUge0BsaW5rIFF1ZXJ5I2NhbmNlbH1cblx0Ki9cblx0ZGVzdHJveSgpIHtcblx0XHRzdXBlci5kZXN0cm95KCk7XG5cdFx0dGhpcy5jYW5jZWwoeyBzaWxlbnQ6IHRydWUgfSk7XG5cdH1cblx0LyoqXG5cdCogVGhlIHN0YXRlIHRoZSBxdWVyeSB3YXMgY3JlYXRlZCB3aXRoLlxuXHQqIEBpbnRlcm5hbFxuXHQqIEByZXR1cm5zIFRoZSBzdGF0ZSB0aGUgcXVlcnkgaGFkIHdoZW4gaXQgd2FzIGZpcnN0IGNyZWF0ZWQsIHVzZWQgYnkge0BsaW5rIFF1ZXJ5I3Jlc2V0fS5cblx0Ki9cblx0Z2V0IHJlc2V0U3RhdGUoKSB7XG5cdFx0cmV0dXJuIHRoaXMuI2luaXRpYWxTdGF0ZTtcblx0fVxuXHQvKipcblx0KiBSZXNldHMgdGhlIHF1ZXJ5IGJhY2sgdG8gaXRzIGluaXRpYWwgc3RhdGUgKHRoZSBzdGF0ZSBpdCBoYWQgd2hlbiBpdCB3YXNcblx0KiBmaXJzdCBjcmVhdGVkLCBlLmcuIGFueSBgaW5pdGlhbERhdGFgKSwgZGVzdHJveWluZyBpdCBmaXJzdCB0byBjYW5jZWwgYW55XG5cdCogaW4tZmxpZ2h0IGZldGNoLlxuXHQqL1xuXHRyZXNldCgpIHtcblx0XHR0aGlzLmRlc3Ryb3koKTtcblx0XHR0aGlzLnNldFN0YXRlKHRoaXMucmVzZXRTdGF0ZSk7XG5cdH1cblx0LyoqXG5cdCogUmV0dXJucyBgdHJ1ZWAgaWYgdGhlIHF1ZXJ5IGhhcyBhdCBsZWFzdCBvbmUgb2JzZXJ2ZXIgZm9yIHdoaWNoIGBlbmFibGVkYFxuXHQqIGRvZXMgbm90IHJlc29sdmUgdG8gYGZhbHNlYC5cblx0KiBAcmV0dXJucyBgdHJ1ZWAgaWYgdGhlIHF1ZXJ5IGhhcyBhbiBlbmFibGVkIG9ic2VydmVyLlxuXHQqL1xuXHRpc0FjdGl2ZSgpIHtcblx0XHRyZXR1cm4gdGhpcy5vYnNlcnZlcnMuc29tZSgob2JzZXJ2ZXIpID0+IHJlc29sdmVRdWVyeVZhbHVlKG9ic2VydmVyLm9wdGlvbnMuZW5hYmxlZCwgdGhpcykgIT09IGZhbHNlKTtcblx0fVxuXHQvKipcblx0KiBSZXR1cm5zIGB0cnVlYCBpZiB0aGUgcXVlcnkgaXMgZGlzYWJsZWQsIG1lYW5pbmcgaXQgd2lsbCBub3QgZmV0Y2hcblx0KiBhdXRvbWF0aWNhbGx5LlxuXHQqIC0gSWYgdGhlIHF1ZXJ5IGhhcyBvYnNlcnZlcnMsIGl0IGlzIGRpc2FibGVkIHdoZW4gbm9uZSBvZiB0aGVtIGFyZSBhY3RpdmVcblx0KiAgIChzZWUgYGlzQWN0aXZlYCkuXG5cdCogLSBJZiB0aGUgcXVlcnkgaGFzIG5vIG9ic2VydmVycywgaXQgaXMgZGlzYWJsZWQgd2hlbiBpdHMgYHF1ZXJ5Rm5gIGlzXG5cdCogICBgc2tpcFRva2VuYCBvciBpdCBoYXMgbmV2ZXIgYmVlbiBmZXRjaGVkLlxuXHQqIEByZXR1cm5zIGB0cnVlYCBpZiB0aGUgcXVlcnkgaXMgZGlzYWJsZWQuXG5cdCovXG5cdGlzRGlzYWJsZWQoKSB7XG5cdFx0aWYgKHRoaXMuZ2V0T2JzZXJ2ZXJzQ291bnQoKSA+IDApIHJldHVybiAhdGhpcy5pc0FjdGl2ZSgpO1xuXHRcdHJldHVybiB0aGlzLm9wdGlvbnMucXVlcnlGbiA9PT0gc2tpcFRva2VuIHx8ICF0aGlzLmlzRmV0Y2hlZCgpO1xuXHR9XG5cdC8qKlxuXHQqIFJldHVybnMgYHRydWVgIGlmIHRoZSBxdWVyeSBoYXMgYmVlbiBmZXRjaGVkLCBpLmUuIGl0IGhhcyByZXNvbHZlZCB3aXRoXG5cdCogZWl0aGVyIGRhdGEgb3IgYW4gZXJyb3IgYXQgbGVhc3Qgb25jZS5cblx0KiBAcmV0dXJucyBgdHJ1ZWAgaWYgdGhlIHF1ZXJ5IGhhcyBiZWVuIGZldGNoZWQuXG5cdCovXG5cdGlzRmV0Y2hlZCgpIHtcblx0XHRyZXR1cm4gdGhpcy5zdGF0ZS5kYXRhVXBkYXRlQ291bnQgKyB0aGlzLnN0YXRlLmVycm9yVXBkYXRlQ291bnQgPiAwO1xuXHR9XG5cdC8qKlxuXHQqIFJldHVybnMgYHRydWVgIGlmIHRoZSBxdWVyeSBoYXMgZGF0YSBhbmQgYXQgbGVhc3Qgb25lIG9ic2VydmVyIGNvbmZpZ3VyZWQgd2l0aFxuXHQqIGBzdGFsZVRpbWU6ICdzdGF0aWMnYCwgbWVhbmluZyBpdCBpcyB0cmVhdGVkIGFzIG5ldmVyIHN0YWxlLlxuXHQqIEByZXR1cm5zIGB0cnVlYCBpZiB0aGUgcXVlcnkgaXMgc3RhdGljLlxuXHQqL1xuXHRpc1N0YXRpYygpIHtcblx0XHRpZiAodGhpcy5zdGF0ZS5kYXRhID09PSB2b2lkIDApIHJldHVybiBmYWxzZTtcblx0XHRpZiAodGhpcy5nZXRPYnNlcnZlcnNDb3VudCgpID4gMCkgcmV0dXJuIHRoaXMub2JzZXJ2ZXJzLnNvbWUoKG9ic2VydmVyKSA9PiByZXNvbHZlUXVlcnlWYWx1ZShvYnNlcnZlci5vcHRpb25zLnN0YWxlVGltZSwgdGhpcykgPT09IFwic3RhdGljXCIpO1xuXHRcdHJldHVybiBmYWxzZTtcblx0fVxuXHQvKipcblx0KiBSZXR1cm5zIGB0cnVlYCBpZiB0aGUgcXVlcnkgaXMgc3RhbGUuXG5cdCogLSBJZiB0aGUgcXVlcnkgaGFzIG9ic2VydmVycywgZGVmZXJzIHRvIHdoZXRoZXIgYW55IG9ic2VydmVyJ3MgY3VycmVudFxuXHQqICAgcmVzdWx0IHJlcG9ydHMgYGlzU3RhbGVgICh3aGljaCBhY2NvdW50cyBmb3IgZWFjaCBvYnNlcnZlcidzIG93blxuXHQqICAgYHN0YWxlVGltZWAgYW5kIGBlbmFibGVkYCBzdGF0ZSkuXG5cdCogLSBJZiB0aGUgcXVlcnkgaGFzIG5vIG9ic2VydmVycywgaXQgaXMgY29uc2lkZXJlZCBzdGFsZSB3aGVuIGl0IGhhcyBub1xuXHQqICAgZGF0YSBvciBoYXMgYmVlbiBpbnZhbGlkYXRlZC5cblx0KiBAcmV0dXJucyBgdHJ1ZWAgaWYgdGhlIHF1ZXJ5IGlzIHN0YWxlLlxuXHQqIEBzZWUge0BsaW5rIFF1ZXJ5I2lzU3RhbGVCeVRpbWV9XG5cdCogQGV4YW1wbGVcblx0KiBgYGB0c1xuXHQqIGlmIChxdWVyeS5pc1N0YWxlKCkpIHtcblx0KiAgIC8vIHJlZmV0Y2ggb3Igb3RoZXJ3aXNlIHRyZWF0IHRoZSBjYWNoZWQgZGF0YSBhcyBvdXRkYXRlZFxuXHQqIH1cblx0KiBgYGBcblx0Ki9cblx0aXNTdGFsZSgpIHtcblx0XHRpZiAodGhpcy5nZXRPYnNlcnZlcnNDb3VudCgpID4gMCkgcmV0dXJuIHRoaXMub2JzZXJ2ZXJzLnNvbWUoKG9ic2VydmVyKSA9PiBvYnNlcnZlci5nZXRDdXJyZW50UmVzdWx0KCkuaXNTdGFsZSk7XG5cdFx0cmV0dXJuIHRoaXMuc3RhdGUuZGF0YSA9PT0gdm9pZCAwIHx8IHRoaXMuc3RhdGUuaXNJbnZhbGlkYXRlZDtcblx0fVxuXHQvKipcblx0KiBSZXR1cm5zIGB0cnVlYCBpZiB0aGUgcXVlcnkncyBkYXRhIGlzIHN0YWxlIHJlbGF0aXZlIHRvIHRoZSBnaXZlblxuXHQqIGBzdGFsZVRpbWVgIChkZWZhdWx0cyB0byBgMGApLlxuXHQqIC0gQSBxdWVyeSB3aXRoIG5vIGRhdGEgaXMgYWx3YXlzIHN0YWxlLlxuXHQqIC0gYHN0YWxlVGltZTogJ3N0YXRpYydgIGlzIG5ldmVyIHN0YWxlLlxuXHQqIC0gQW4gaW52YWxpZGF0ZWQgcXVlcnkgaXMgYWx3YXlzIHN0YWxlLlxuXHQqIC0gT3RoZXJ3aXNlLCBzdGFsZW5lc3MgaXMgYmFzZWQgb24gZWxhcHNlZCB0aW1lIHNpbmNlIGBkYXRhVXBkYXRlZEF0YC5cblx0KiBAcGFyYW0gc3RhbGVUaW1lIC0gVGhlIHRpbWUsIGluIG1pbGxpc2Vjb25kcywgYWZ0ZXIgd2hpY2ggZGF0YSBpcyBjb25zaWRlcmVkIHN0YWxlLCBvclxuXHQqIGAnc3RhdGljJ2AgdG8gbmV2ZXIgdHJlYXQgZXhpc3RpbmcgZGF0YSBhcyBzdGFsZS4gQSBxdWVyeSB3aXRob3V0IGRhdGEgaXMgc3RhbGUgZWl0aGVyIHdheS5cblx0KiBAcmV0dXJucyBgdHJ1ZWAgaWYgdGhlIHF1ZXJ5J3MgZGF0YSBpcyBzdGFsZS5cblx0KiBAc2VlIHtAbGluayBRdWVyeSNpc1N0YWxlfVxuXHQqIEBleGFtcGxlXG5cdCogYGBgdHNcblx0KiBjb25zdCBpc1N0YWxlID0gcXVlcnkuaXNTdGFsZUJ5VGltZSg2MCAqIDEwMDApXG5cdCogYGBgXG5cdCovXG5cdGlzU3RhbGVCeVRpbWUoc3RhbGVUaW1lID0gMCkge1xuXHRcdGlmICh0aGlzLnN0YXRlLmRhdGEgPT09IHZvaWQgMCkgcmV0dXJuIHRydWU7XG5cdFx0aWYgKHN0YWxlVGltZSA9PT0gXCJzdGF0aWNcIikgcmV0dXJuIGZhbHNlO1xuXHRcdGlmICh0aGlzLnN0YXRlLmlzSW52YWxpZGF0ZWQpIHJldHVybiB0cnVlO1xuXHRcdHJldHVybiAhdGltZVVudGlsU3RhbGUodGhpcy5zdGF0ZS5kYXRhVXBkYXRlZEF0LCBzdGFsZVRpbWUpO1xuXHR9XG5cdC8qKlxuXHQqIFJlZmV0Y2hlcyB0aGUgcXVlcnkgd2hlbiB0aGUgd2luZG93IHJlZ2FpbnMgZm9jdXMsIGlmIGFuIG9ic2VydmVyIHdhbnRzIHRoYXQsIGFuZCBjb250aW51ZXMgYVxuXHQqIHBhdXNlZCBmZXRjaC5cblx0KiBAaW50ZXJuYWxcblx0Ki9cblx0b25Gb2N1cygpIHtcblx0XHR0aGlzLm9ic2VydmVycy5maW5kKCh4KSA9PiB4LnNob3VsZEZldGNoT25XaW5kb3dGb2N1cygpKT8ucmVmZXRjaCh7IGNhbmNlbFJlZmV0Y2g6IGZhbHNlIH0pO1xuXHRcdHRoaXMuI3JldHJ5ZXI/LmNvbnRpbnVlKCk7XG5cdH1cblx0LyoqXG5cdCogUmVmZXRjaGVzIHRoZSBxdWVyeSB3aGVuIHRoZSBhcHAgcmVjb25uZWN0cywgaWYgYW4gb2JzZXJ2ZXIgd2FudHMgdGhhdCwgYW5kIGNvbnRpbnVlcyBhIHBhdXNlZFxuXHQqIGZldGNoLlxuXHQqIEBpbnRlcm5hbFxuXHQqL1xuXHRvbk9ubGluZSgpIHtcblx0XHR0aGlzLm9ic2VydmVycy5maW5kKCh4KSA9PiB4LnNob3VsZEZldGNoT25SZWNvbm5lY3QoKSk/LnJlZmV0Y2goeyBjYW5jZWxSZWZldGNoOiBmYWxzZSB9KTtcblx0XHR0aGlzLiNyZXRyeWVyPy5jb250aW51ZSgpO1xuXHR9XG5cdC8qKlxuXHQqIFN1YnNjcmliZXMgYW4gb2JzZXJ2ZXIgdG8gdGhlIHF1ZXJ5IGFuZCBzdG9wcyBpdHMgZ2FyYmFnZSBjb2xsZWN0aW9uLlxuXHQqIEBpbnRlcm5hbFxuXHQqIEBwYXJhbSBvYnNlcnZlciAtIFRoZSBvYnNlcnZlciB0byBhZGQuIEFkZGluZyBhbiBvYnNlcnZlciB0aGF0IGlzIGFscmVhZHkgc3Vic2NyaWJlZCBkb2VzXG5cdCogbm90aGluZy5cblx0Ki9cblx0YWRkT2JzZXJ2ZXIob2JzZXJ2ZXIpIHtcblx0XHRpZiAoIXRoaXMub2JzZXJ2ZXJzLmluY2x1ZGVzKG9ic2VydmVyKSkge1xuXHRcdFx0dGhpcy5vYnNlcnZlcnMucHVzaChvYnNlcnZlcik7XG5cdFx0XHR0aGlzLmNsZWFyR2NUaW1lb3V0KCk7XG5cdFx0XHR0aGlzLiNjYWNoZS5ub3RpZnkoe1xuXHRcdFx0XHR0eXBlOiBcIm9ic2VydmVyQWRkZWRcIixcblx0XHRcdFx0cXVlcnk6IHRoaXMsXG5cdFx0XHRcdG9ic2VydmVyXG5cdFx0XHR9KTtcblx0XHR9XG5cdH1cblx0LyoqXG5cdCogVW5zdWJzY3JpYmVzIGFuIG9ic2VydmVyIGZyb20gdGhlIHF1ZXJ5LlxuXHQqIEBpbnRlcm5hbFxuXHQqIEBwYXJhbSBvYnNlcnZlciAtIFRoZSBvYnNlcnZlciB0byByZW1vdmUuIFdoZW4gdGhlIGxhc3Qgb2JzZXJ2ZXIgaXMgcmVtb3ZlZCwgdGhlIGluLWZsaWdodFxuXHQqIGZldGNoIGlzIGNhbmNlbGxlZCBpZiBpdHMgYWJvcnQgc2lnbmFsIHdhcyBjb25zdW1lZCAob3RoZXJ3aXNlIG9ubHkgaXRzIHJldHJpZXMgYXJlIHN0b3BwZWQpLFxuXHQqIGFuZCBnYXJiYWdlIGNvbGxlY3Rpb24gaXMgc2NoZWR1bGVkLlxuXHQqL1xuXHRyZW1vdmVPYnNlcnZlcihvYnNlcnZlcikge1xuXHRcdGNvbnN0IGluZGV4ID0gdGhpcy5vYnNlcnZlcnMuaW5kZXhPZihvYnNlcnZlcik7XG5cdFx0aWYgKGluZGV4ICE9PSAtMSkge1xuXHRcdFx0dGhpcy5vYnNlcnZlcnMuc3BsaWNlKGluZGV4LCAxKTtcblx0XHRcdGlmICghdGhpcy5vYnNlcnZlcnMubGVuZ3RoKSB7XG5cdFx0XHRcdGlmICh0aGlzLiNyZXRyeWVyKSB7XG5cdFx0XHRcdFx0aWYgKHRoaXMuI2Fib3J0U2lnbmFsQ29uc3VtZWQgfHwgdGhpcy5zdGF0ZS5mZXRjaFN0YXR1cyA9PT0gXCJwYXVzZWRcIiAmJiB0aGlzLnN0YXRlLnN0YXR1cyA9PT0gXCJwZW5kaW5nXCIpIHRoaXMuI3JldHJ5ZXIuY2FuY2VsKHsgcmV2ZXJ0OiB0cnVlIH0pO1xuXHRcdFx0XHRcdGVsc2UgdGhpcy4jcmV0cnllci5jYW5jZWxSZXRyeSgpO1xuXHRcdFx0XHR9XG5cdFx0XHRcdHRoaXMuc2NoZWR1bGVHYygpO1xuXHRcdFx0fVxuXHRcdFx0dGhpcy4jY2FjaGUubm90aWZ5KHtcblx0XHRcdFx0dHlwZTogXCJvYnNlcnZlclJlbW92ZWRcIixcblx0XHRcdFx0cXVlcnk6IHRoaXMsXG5cdFx0XHRcdG9ic2VydmVyXG5cdFx0XHR9KTtcblx0XHR9XG5cdH1cblx0LyoqXG5cdCogUmV0dXJucyB0aGUgbnVtYmVyIG9mIG9ic2VydmVycyBjdXJyZW50bHkgc3Vic2NyaWJlZCB0byB0aGlzIHF1ZXJ5LlxuXHQqIEByZXR1cm5zIFRoZSBudW1iZXIgb2Ygb2JzZXJ2ZXJzLlxuXHQqIEBleGFtcGxlXG5cdCogYGBgdHNcblx0KiBpZiAocXVlcnkuZ2V0T2JzZXJ2ZXJzQ291bnQoKSA9PT0gMCkge1xuXHQqICAgLy8gbm8gY29tcG9uZW50IGlzIGN1cnJlbnRseSB3YXRjaGluZyB0aGlzIHF1ZXJ5XG5cdCogfVxuXHQqIGBgYFxuXHQqL1xuXHRnZXRPYnNlcnZlcnNDb3VudCgpIHtcblx0XHRyZXR1cm4gdGhpcy5vYnNlcnZlcnMubGVuZ3RoO1xuXHR9XG5cdC8qKlxuXHQqIE1hcmtzIHRoZSBxdWVyeSBhcyBpbnZhbGlkYXRlZCwgdW5sZXNzIGl0IGlzIGFscmVhZHkgaW52YWxpZGF0ZWQuIFRoaXNcblx0KiB1cGRhdGVzIGBzdGF0ZS5pc0ludmFsaWRhdGVkYCBhbmQgbm90aWZpZXMgb2JzZXJ2ZXJzLCBidXQgZG9lcyBub3QgYnlcblx0KiBpdHNlbGYgdHJpZ2dlciBhIHJlZmV0Y2guXG5cdCogQGV4YW1wbGVcblx0KiBgYGB0c1xuXHQqIHF1ZXJ5LmludmFsaWRhdGUoKVxuXHQqIGBgYFxuXHQqL1xuXHRpbnZhbGlkYXRlKCkge1xuXHRcdGlmICghdGhpcy5zdGF0ZS5pc0ludmFsaWRhdGVkKSB0aGlzLiNkaXNwYXRjaCh7IHR5cGU6IFwiaW52YWxpZGF0ZVwiIH0pO1xuXHR9XG5cdC8qKlxuXHQqIEZldGNoZXMgdGhlIHF1ZXJ5LCBpLmUuIHJ1bnMgaXRzIGBxdWVyeUZuYCAodGhyb3VnaCBhbnkgY29uZmlndXJlZFxuXHQqIHJldHJ5ZXIvYmVoYXZpb3IpIGFuZCB1cGRhdGVzIHRoZSBxdWVyeSdzIHN0YXRlIHdpdGggdGhlIHJlc3VsdC5cblx0KiAtIElmIGEgZmV0Y2ggaXMgYWxyZWFkeSBpbiBmbGlnaHQsIHJldHVybnMgaXRzIHByb21pc2UgaW5zdGVhZCBvZlxuXHQqICAgc3RhcnRpbmcgYSBuZXcgb25lLCB1bmxlc3MgYGZldGNoT3B0aW9ucy5jYW5jZWxSZWZldGNoYCBpcyBzZXQgYW5kIHRoZVxuXHQqICAgcXVlcnkgYWxyZWFkeSBoYXMgZGF0YSwgaW4gd2hpY2ggY2FzZSB0aGUgY3VycmVudCBmZXRjaCBpcyBzaWxlbnRseVxuXHQqICAgY2FuY2VsbGVkIGZpcnN0LlxuXHQqIC0gSWYgYG9wdGlvbnNgIGlzIHBhc3NlZCwgaXQgcmVwbGFjZXMgdGhlIHF1ZXJ5J3MgY3VycmVudCBvcHRpb25zXG5cdCogICBiZWZvcmUgZmV0Y2hpbmcuXG5cdCogQHBhcmFtIG9wdGlvbnMgLSBRdWVyeSBvcHRpb25zIHRoYXQgcmVwbGFjZSB0aGUgcXVlcnkncyBjdXJyZW50IG9wdGlvbnMgYmVmb3JlIGZldGNoaW5nLiBUaGV5XG5cdCogYXJlIG5vdCBhcHBsaWVkIHdoZW4gYW4gaW4tZmxpZ2h0IGZldGNoIGlzIHJldXNlZC5cblx0KiBAcGFyYW0gZmV0Y2hPcHRpb25zIC0gU2V0IGBjYW5jZWxSZWZldGNoYCB0byBjYW5jZWwgYW4gaW4tZmxpZ2h0IGZldGNoIGZpcnN0IChvbmx5IGlmIHRoZSBxdWVyeVxuXHQqIGFscmVhZHkgaGFzIGRhdGEpLCBhbmQgYG1ldGFgIHRvIHBhc3MgZXh0cmEgaW5mb3JtYXRpb24gdG8gdGhlIHF1ZXJ5J3MgYmVoYXZpb3IuXG5cdCogQHJldHVybnMgQSBwcm9taXNlIHRoYXQgcmVzb2x2ZXMgd2l0aCB0aGUgZmV0Y2hlZCBkYXRhLCBvciByZWplY3RzIHdpdGggdGhlIGZldGNoIGVycm9yLiBJZiB0aGVcblx0KiBmZXRjaCBpcyBjYW5jZWxsZWQgd2l0aCBgcmV2ZXJ0YCB3aGlsZSB0aGUgcXVlcnkgaGFzIGRhdGEsIGl0IHJlc29sdmVzIHdpdGggdGhlIHJlc3RvcmVkIGRhdGFcblx0KiBpbnN0ZWFkLlxuXHQqL1xuXHRhc3luYyBmZXRjaChvcHRpb25zLCBmZXRjaE9wdGlvbnMpIHtcblx0XHRpZiAodGhpcy5zdGF0ZS5mZXRjaFN0YXR1cyAhPT0gXCJpZGxlXCIgJiYgdGhpcy4jcmV0cnllcj8uc3RhdHVzKCkgIT09IFwicmVqZWN0ZWRcIikge1xuXHRcdFx0aWYgKHRoaXMuc3RhdGUuZGF0YSAhPT0gdm9pZCAwICYmIGZldGNoT3B0aW9ucz8uY2FuY2VsUmVmZXRjaCkgdGhpcy5jYW5jZWwoeyBzaWxlbnQ6IHRydWUgfSk7XG5cdFx0XHRlbHNlIGlmICh0aGlzLiNyZXRyeWVyICYmIHRoaXMuI2ZldGNoUHJvbWlzZSkge1xuXHRcdFx0XHR0aGlzLiNyZXRyeWVyLmNvbnRpbnVlUmV0cnkoKTtcblx0XHRcdFx0cmV0dXJuIHRoaXMuI2ZldGNoUHJvbWlzZTtcblx0XHRcdH1cblx0XHR9XG5cdFx0aWYgKG9wdGlvbnMpIHRoaXMuc2V0T3B0aW9ucyhvcHRpb25zKTtcblx0XHRpZiAoIXRoaXMub3B0aW9ucy5xdWVyeUZuKSB7XG5cdFx0XHRjb25zdCBvYnNlcnZlciA9IHRoaXMub2JzZXJ2ZXJzLmZpbmQoKHgpID0+IHgub3B0aW9ucy5xdWVyeUZuKTtcblx0XHRcdGlmIChvYnNlcnZlcikgdGhpcy5zZXRPcHRpb25zKG9ic2VydmVyLm9wdGlvbnMpO1xuXHRcdH1cblx0XHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSB7XG5cdFx0XHRpZiAoIUFycmF5LmlzQXJyYXkodGhpcy5vcHRpb25zLnF1ZXJ5S2V5KSkgY29uc29sZS5lcnJvcihgQXMgb2YgdjQsIHF1ZXJ5S2V5IG5lZWRzIHRvIGJlIGFuIEFycmF5LiBJZiB5b3UgYXJlIHVzaW5nIGEgc3RyaW5nIGxpa2UgJ3JlcG9EYXRhJywgcGxlYXNlIGNoYW5nZSBpdCB0byBhbiBBcnJheSwgZS5nLiBbJ3JlcG9EYXRhJ11gKTtcblx0XHR9XG5cdFx0Y29uc3QgYWJvcnRDb250cm9sbGVyID0gbmV3IEFib3J0Q29udHJvbGxlcigpO1xuXHRcdGNvbnN0IGFkZFNpZ25hbFByb3BlcnR5ID0gKG9iamVjdCkgPT4ge1xuXHRcdFx0T2JqZWN0LmRlZmluZVByb3BlcnRpZXMob2JqZWN0LCB7XG5cdFx0XHRcdFtmZXRjaFNpZ25hbF06IHtcblx0XHRcdFx0XHR2YWx1ZTogYWJvcnRDb250cm9sbGVyLnNpZ25hbCxcblx0XHRcdFx0XHRlbnVtZXJhYmxlOiB0cnVlXG5cdFx0XHRcdH0sXG5cdFx0XHRcdHNpZ25hbDoge1xuXHRcdFx0XHRcdGVudW1lcmFibGU6IHRydWUsXG5cdFx0XHRcdFx0Z2V0OiAoKSA9PiB7XG5cdFx0XHRcdFx0XHR0aGlzLiNhYm9ydFNpZ25hbENvbnN1bWVkID0gdHJ1ZTtcblx0XHRcdFx0XHRcdHJldHVybiBhYm9ydENvbnRyb2xsZXIuc2lnbmFsO1xuXHRcdFx0XHRcdH1cblx0XHRcdFx0fVxuXHRcdFx0fSk7XG5cdFx0fTtcblx0XHRjb25zdCBmZXRjaEZuID0gKCkgPT4ge1xuXHRcdFx0Y29uc3QgcXVlcnlGbiA9IGVuc3VyZVF1ZXJ5Rm4odGhpcy5vcHRpb25zLCBmZXRjaE9wdGlvbnMpO1xuXHRcdFx0Y29uc3QgY3JlYXRlUXVlcnlGbkNvbnRleHQgPSAoKSA9PiB7XG5cdFx0XHRcdGNvbnN0IHF1ZXJ5Rm5Db250ZXh0ID0ge1xuXHRcdFx0XHRcdGNsaWVudDogdGhpcy4jY2xpZW50LFxuXHRcdFx0XHRcdHF1ZXJ5S2V5OiB0aGlzLnF1ZXJ5S2V5LFxuXHRcdFx0XHRcdG1ldGE6IHRoaXMubWV0YVxuXHRcdFx0XHR9O1xuXHRcdFx0XHRhZGRTaWduYWxQcm9wZXJ0eShxdWVyeUZuQ29udGV4dCk7XG5cdFx0XHRcdHJldHVybiBxdWVyeUZuQ29udGV4dDtcblx0XHRcdH07XG5cdFx0XHRjb25zdCBxdWVyeUZuQ29udGV4dCA9IGNyZWF0ZVF1ZXJ5Rm5Db250ZXh0KCk7XG5cdFx0XHR0aGlzLiNhYm9ydFNpZ25hbENvbnN1bWVkID0gZmFsc2U7XG5cdFx0XHRpZiAodGhpcy5vcHRpb25zLnBlcnNpc3RlcikgcmV0dXJuIHRoaXMub3B0aW9ucy5wZXJzaXN0ZXIocXVlcnlGbiwgcXVlcnlGbkNvbnRleHQsIHRoaXMpO1xuXHRcdFx0cmV0dXJuIHF1ZXJ5Rm4ocXVlcnlGbkNvbnRleHQpO1xuXHRcdH07XG5cdFx0Y29uc3QgY3JlYXRlRmV0Y2hDb250ZXh0ID0gKCkgPT4ge1xuXHRcdFx0Y29uc3QgY29udGV4dCA9IHtcblx0XHRcdFx0ZmV0Y2hPcHRpb25zLFxuXHRcdFx0XHRvcHRpb25zOiB0aGlzLm9wdGlvbnMsXG5cdFx0XHRcdHF1ZXJ5S2V5OiB0aGlzLnF1ZXJ5S2V5LFxuXHRcdFx0XHRjbGllbnQ6IHRoaXMuI2NsaWVudCxcblx0XHRcdFx0c3RhdGU6IHRoaXMuc3RhdGUsXG5cdFx0XHRcdGZldGNoRm5cblx0XHRcdH07XG5cdFx0XHRhZGRTaWduYWxQcm9wZXJ0eShjb250ZXh0KTtcblx0XHRcdHJldHVybiBjb250ZXh0O1xuXHRcdH07XG5cdFx0Y29uc3QgY29udGV4dCA9IGNyZWF0ZUZldGNoQ29udGV4dCgpO1xuXHRcdCh0aGlzLiNxdWVyeVR5cGUgPT09IFwiaW5maW5pdGVcIiA/IGluZmluaXRlUXVlcnlCZWhhdmlvcih0aGlzLm9wdGlvbnMucGFnZXMpIDogdGhpcy5vcHRpb25zLmJlaGF2aW9yKT8ub25GZXRjaChjb250ZXh0LCB0aGlzKTtcblx0XHR0aGlzLiNyZXZlcnRTdGF0ZSA9IHRoaXMuc3RhdGU7XG5cdFx0aWYgKHRoaXMuc3RhdGUuZmV0Y2hTdGF0dXMgPT09IFwiaWRsZVwiIHx8IHRoaXMuc3RhdGUuZmV0Y2hNZXRhICE9PSBjb250ZXh0LmZldGNoT3B0aW9ucz8ubWV0YSkgdGhpcy4jZGlzcGF0Y2goe1xuXHRcdFx0dHlwZTogXCJmZXRjaFwiLFxuXHRcdFx0bWV0YTogY29udGV4dC5mZXRjaE9wdGlvbnM/Lm1ldGFcblx0XHR9KTtcblx0XHRjb25zdCByZXRyeWVyID0gdGhpcy4jcmV0cnllciA9IGNyZWF0ZVJldHJ5ZXIoe1xuXHRcdFx0aW5pdGlhbFByb21pc2U6IGZldGNoT3B0aW9ucz8uaW5pdGlhbFByb21pc2UsXG5cdFx0XHRmbjogY29udGV4dC5mZXRjaEZuLFxuXHRcdFx0b25DYW5jZWw6IChlcnJvcikgPT4ge1xuXHRcdFx0XHRpZiAoZXJyb3IgaW5zdGFuY2VvZiBDYW5jZWxsZWRFcnJvciAmJiBlcnJvci5yZXZlcnQpIHRoaXMuc2V0U3RhdGUoe1xuXHRcdFx0XHRcdC4uLnRoaXMuI3JldmVydFN0YXRlLFxuXHRcdFx0XHRcdGZldGNoU3RhdHVzOiBcImlkbGVcIlxuXHRcdFx0XHR9KTtcblx0XHRcdFx0YWJvcnRDb250cm9sbGVyLmFib3J0KCk7XG5cdFx0XHR9LFxuXHRcdFx0b25GYWlsOiAoZmFpbHVyZUNvdW50LCBlcnJvcikgPT4ge1xuXHRcdFx0XHR0aGlzLiNkaXNwYXRjaCh7XG5cdFx0XHRcdFx0dHlwZTogXCJmYWlsZWRcIixcblx0XHRcdFx0XHRmYWlsdXJlQ291bnQsXG5cdFx0XHRcdFx0ZXJyb3Jcblx0XHRcdFx0fSk7XG5cdFx0XHR9LFxuXHRcdFx0b25QYXVzZTogKCkgPT4ge1xuXHRcdFx0XHR0aGlzLiNkaXNwYXRjaCh7IHR5cGU6IFwicGF1c2VcIiB9KTtcblx0XHRcdH0sXG5cdFx0XHRvbkNvbnRpbnVlOiAoKSA9PiB7XG5cdFx0XHRcdHRoaXMuI2Rpc3BhdGNoKHsgdHlwZTogXCJjb250aW51ZVwiIH0pO1xuXHRcdFx0fSxcblx0XHRcdHJldHJ5OiBjb250ZXh0Lm9wdGlvbnMucmV0cnksXG5cdFx0XHRyZXRyeURlbGF5OiBjb250ZXh0Lm9wdGlvbnMucmV0cnlEZWxheSxcblx0XHRcdG5ldHdvcmtNb2RlOiBjb250ZXh0Lm9wdGlvbnMubmV0d29ya01vZGUsXG5cdFx0XHRjYW5SdW46ICgpID0+IHRydWVcblx0XHR9KTtcblx0XHRjb25zdCBmZXRjaFByb21pc2UgPSAoYXN5bmMgKCkgPT4ge1xuXHRcdFx0dHJ5IHtcblx0XHRcdFx0Y29uc3QgZGF0YSA9IGF3YWl0IHJldHJ5ZXIucHJvbWlzZTtcblx0XHRcdFx0aWYgKGRhdGEgPT09IHZvaWQgMCkge1xuXHRcdFx0XHRcdGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIGNvbnNvbGUuZXJyb3IoYFF1ZXJ5IGRhdGEgY2Fubm90IGJlIHVuZGVmaW5lZC4gUGxlYXNlIG1ha2Ugc3VyZSB0byByZXR1cm4gYSB2YWx1ZSBvdGhlciB0aGFuIHVuZGVmaW5lZCBmcm9tIHlvdXIgcXVlcnkgZnVuY3Rpb24uIEFmZmVjdGVkIHF1ZXJ5IGtleTogJHt0aGlzLnF1ZXJ5SGFzaH1gKTtcblx0XHRcdFx0XHR0aHJvdyBuZXcgRXJyb3IoYCR7dGhpcy5xdWVyeUhhc2h9IGRhdGEgaXMgdW5kZWZpbmVkYCk7XG5cdFx0XHRcdH1cblx0XHRcdFx0dGhpcy5zZXREYXRhKGRhdGEpO1xuXHRcdFx0XHR0aGlzLiNjYWNoZS5jb25maWcub25TdWNjZXNzPy4oZGF0YSwgdGhpcyk7XG5cdFx0XHRcdHRoaXMuI2NhY2hlLmNvbmZpZy5vblNldHRsZWQ/LihkYXRhLCB0aGlzLnN0YXRlLmVycm9yLCB0aGlzKTtcblx0XHRcdFx0cmV0dXJuIGRhdGE7XG5cdFx0XHR9IGNhdGNoIChlcnJvcikge1xuXHRcdFx0XHRpZiAoZXJyb3IgaW5zdGFuY2VvZiBDYW5jZWxsZWRFcnJvcikge1xuXHRcdFx0XHRcdGlmIChlcnJvci5zaWxlbnQpIHtcblx0XHRcdFx0XHRcdGlmICh0aGlzLiNyZXRyeWVyICE9PSByZXRyeWVyICYmIHRoaXMuI2ZldGNoUHJvbWlzZSkgcmV0dXJuIHRoaXMuI2ZldGNoUHJvbWlzZTtcblx0XHRcdFx0XHRcdHRocm93IGVycm9yO1xuXHRcdFx0XHRcdH0gZWxzZSBpZiAoZXJyb3IucmV2ZXJ0KSB7XG5cdFx0XHRcdFx0XHRpZiAodGhpcy5zdGF0ZS5kYXRhID09PSB2b2lkIDApIHRocm93IGVycm9yO1xuXHRcdFx0XHRcdFx0cmV0dXJuIHRoaXMuc3RhdGUuZGF0YTtcblx0XHRcdFx0XHR9XG5cdFx0XHRcdH1cblx0XHRcdFx0dGhpcy4jZGlzcGF0Y2goe1xuXHRcdFx0XHRcdHR5cGU6IFwiZXJyb3JcIixcblx0XHRcdFx0XHRlcnJvclxuXHRcdFx0XHR9KTtcblx0XHRcdFx0dGhpcy4jY2FjaGUuY29uZmlnLm9uRXJyb3I/LihlcnJvciwgdGhpcyk7XG5cdFx0XHRcdHRoaXMuI2NhY2hlLmNvbmZpZy5vblNldHRsZWQ/Lih0aGlzLnN0YXRlLmRhdGEsIGVycm9yLCB0aGlzKTtcblx0XHRcdFx0dGhyb3cgZXJyb3I7XG5cdFx0XHR9IGZpbmFsbHkge1xuXHRcdFx0XHRpZiAodGhpcy4jcmV0cnllciA9PT0gcmV0cnllcikge1xuXHRcdFx0XHRcdHRoaXMuI3JldHJ5ZXIgPSB2b2lkIDA7XG5cdFx0XHRcdFx0dGhpcy4jZmV0Y2hQcm9taXNlID0gdm9pZCAwO1xuXHRcdFx0XHR9XG5cdFx0XHRcdHRoaXMuc2NoZWR1bGVHYygpO1xuXHRcdFx0fVxuXHRcdH0pKCk7XG5cdFx0dGhpcy4jZmV0Y2hQcm9taXNlID0gZmV0Y2hQcm9taXNlO1xuXHRcdHJldHJ5ZXIuc3RhcnQoKTtcblx0XHRyZXR1cm4gZmV0Y2hQcm9taXNlO1xuXHR9XG5cdCNkaXNwYXRjaChhY3Rpb24pIHtcblx0XHRjb25zdCByZWR1Y2VyID0gKHN0YXRlKSA9PiB7XG5cdFx0XHRzd2l0Y2ggKGFjdGlvbi50eXBlKSB7XG5cdFx0XHRcdGNhc2UgXCJmYWlsZWRcIjogcmV0dXJuIHtcblx0XHRcdFx0XHQuLi5zdGF0ZSxcblx0XHRcdFx0XHRmZXRjaEZhaWx1cmVDb3VudDogYWN0aW9uLmZhaWx1cmVDb3VudCxcblx0XHRcdFx0XHRmZXRjaEZhaWx1cmVSZWFzb246IGFjdGlvbi5lcnJvclxuXHRcdFx0XHR9O1xuXHRcdFx0XHRjYXNlIFwicGF1c2VcIjogcmV0dXJuIHtcblx0XHRcdFx0XHQuLi5zdGF0ZSxcblx0XHRcdFx0XHRmZXRjaFN0YXR1czogXCJwYXVzZWRcIlxuXHRcdFx0XHR9O1xuXHRcdFx0XHRjYXNlIFwiY29udGludWVcIjogcmV0dXJuIHtcblx0XHRcdFx0XHQuLi5zdGF0ZSxcblx0XHRcdFx0XHRmZXRjaFN0YXR1czogXCJmZXRjaGluZ1wiXG5cdFx0XHRcdH07XG5cdFx0XHRcdGNhc2UgXCJmZXRjaFwiOiByZXR1cm4ge1xuXHRcdFx0XHRcdC4uLnN0YXRlLFxuXHRcdFx0XHRcdC4uLmZldGNoU3RhdGUoc3RhdGUuZGF0YSwgdGhpcy5vcHRpb25zKSxcblx0XHRcdFx0XHRmZXRjaE1ldGE6IGFjdGlvbi5tZXRhID8/IG51bGxcblx0XHRcdFx0fTtcblx0XHRcdFx0Y2FzZSBcInN1Y2Nlc3NcIjpcblx0XHRcdFx0XHRjb25zdCBuZXdTdGF0ZSA9IHtcblx0XHRcdFx0XHRcdC4uLnN0YXRlLFxuXHRcdFx0XHRcdFx0Li4uc3VjY2Vzc1N0YXRlKGFjdGlvbi5kYXRhLCBhY3Rpb24uZGF0YVVwZGF0ZWRBdCksXG5cdFx0XHRcdFx0XHRkYXRhVXBkYXRlQ291bnQ6IHN0YXRlLmRhdGFVcGRhdGVDb3VudCArIDEsXG5cdFx0XHRcdFx0XHQuLi4hYWN0aW9uLm1hbnVhbCAmJiB7XG5cdFx0XHRcdFx0XHRcdGZldGNoU3RhdHVzOiBcImlkbGVcIixcblx0XHRcdFx0XHRcdFx0ZmV0Y2hGYWlsdXJlQ291bnQ6IDAsXG5cdFx0XHRcdFx0XHRcdGZldGNoRmFpbHVyZVJlYXNvbjogbnVsbFxuXHRcdFx0XHRcdFx0fVxuXHRcdFx0XHRcdH07XG5cdFx0XHRcdFx0dGhpcy4jcmV2ZXJ0U3RhdGUgPSBhY3Rpb24ubWFudWFsID8gbmV3U3RhdGUgOiB2b2lkIDA7XG5cdFx0XHRcdFx0cmV0dXJuIG5ld1N0YXRlO1xuXHRcdFx0XHRjYXNlIFwiZXJyb3JcIjpcblx0XHRcdFx0XHRjb25zdCBlcnJvciA9IGFjdGlvbi5lcnJvcjtcblx0XHRcdFx0XHRyZXR1cm4ge1xuXHRcdFx0XHRcdFx0Li4uc3RhdGUsXG5cdFx0XHRcdFx0XHRlcnJvcixcblx0XHRcdFx0XHRcdGVycm9yVXBkYXRlQ291bnQ6IHN0YXRlLmVycm9yVXBkYXRlQ291bnQgKyAxLFxuXHRcdFx0XHRcdFx0ZXJyb3JVcGRhdGVkQXQ6IERhdGUubm93KCksXG5cdFx0XHRcdFx0XHRmZXRjaEZhaWx1cmVDb3VudDogc3RhdGUuZmV0Y2hGYWlsdXJlQ291bnQgKyAxLFxuXHRcdFx0XHRcdFx0ZmV0Y2hGYWlsdXJlUmVhc29uOiBlcnJvcixcblx0XHRcdFx0XHRcdGZldGNoU3RhdHVzOiBcImlkbGVcIixcblx0XHRcdFx0XHRcdHN0YXR1czogXCJlcnJvclwiLFxuXHRcdFx0XHRcdFx0aXNJbnZhbGlkYXRlZDogdHJ1ZVxuXHRcdFx0XHRcdH07XG5cdFx0XHRcdGNhc2UgXCJpbnZhbGlkYXRlXCI6IHJldHVybiB7XG5cdFx0XHRcdFx0Li4uc3RhdGUsXG5cdFx0XHRcdFx0aXNJbnZhbGlkYXRlZDogdHJ1ZVxuXHRcdFx0XHR9O1xuXHRcdFx0XHRjYXNlIFwic2V0U3RhdGVcIjogcmV0dXJuIHtcblx0XHRcdFx0XHQuLi5zdGF0ZSxcblx0XHRcdFx0XHQuLi5hY3Rpb24uc3RhdGVcblx0XHRcdFx0fTtcblx0XHRcdH1cblx0XHR9O1xuXHRcdHRoaXMuc3RhdGUgPSByZWR1Y2VyKHRoaXMuc3RhdGUpO1xuXHRcdG5vdGlmeU1hbmFnZXIuYmF0Y2goKCkgPT4ge1xuXHRcdFx0dGhpcy5vYnNlcnZlcnMuc2xpY2UoKS5mb3JFYWNoKChvYnNlcnZlcikgPT4ge1xuXHRcdFx0XHRvYnNlcnZlci5vblF1ZXJ5VXBkYXRlKCk7XG5cdFx0XHR9KTtcblx0XHRcdHRoaXMuI2NhY2hlLm5vdGlmeSh7XG5cdFx0XHRcdHF1ZXJ5OiB0aGlzLFxuXHRcdFx0XHR0eXBlOiBcInVwZGF0ZWRcIixcblx0XHRcdFx0YWN0aW9uXG5cdFx0XHR9KTtcblx0XHR9KTtcblx0fVxufTtcbi8qKlxuKiBSZXR1cm5zIHRoZSBzdGF0ZSBjaGFuZ2VzIGFwcGxpZWQgd2hlbiBhIHF1ZXJ5IHN0YXJ0cyBmZXRjaGluZy5cbiogQHBhcmFtIGRhdGEgLSBUaGUgcXVlcnkncyBjdXJyZW50IGRhdGEuIElmIGl0IGlzIGB1bmRlZmluZWRgLCB0aGUgcXVlcnkgaXMgYWxzbyByZXNldCB0b1xuKiBgJ3BlbmRpbmcnYCB3aXRoIG5vIGVycm9yLlxuKiBAcGFyYW0gb3B0aW9ucyAtIFRoZSBxdWVyeSBvcHRpb25zLCB3aG9zZSBgbmV0d29ya01vZGVgIGRlY2lkZXMgd2hldGhlciB0aGUgcXVlcnkgaXMgYCdmZXRjaGluZydgXG4qIG9yIGAncGF1c2VkJ2AuXG4qIEByZXR1cm5zIFRoZSBwYXJ0aWFsIHF1ZXJ5IHN0YXRlIGZvciBhIHN0YXJ0aW5nIGZldGNoLlxuKi9cbmZ1bmN0aW9uIGZldGNoU3RhdGUoZGF0YSwgb3B0aW9ucykge1xuXHRyZXR1cm4ge1xuXHRcdGZldGNoRmFpbHVyZUNvdW50OiAwLFxuXHRcdGZldGNoRmFpbHVyZVJlYXNvbjogbnVsbCxcblx0XHRmZXRjaFN0YXR1czogY2FuRmV0Y2gob3B0aW9ucy5uZXR3b3JrTW9kZSkgPyBcImZldGNoaW5nXCIgOiBcInBhdXNlZFwiLFxuXHRcdC4uLmRhdGEgPT09IHZvaWQgMCAmJiB7XG5cdFx0XHRlcnJvcjogbnVsbCxcblx0XHRcdHN0YXR1czogXCJwZW5kaW5nXCJcblx0XHR9XG5cdH07XG59XG4vKipcbiogUmV0dXJucyB0aGUgc3RhdGUgY2hhbmdlcyBhcHBsaWVkIHdoZW4gYSBxdWVyeSByZWNlaXZlcyBkYXRhLlxuKiBAcGFyYW0gZGF0YSAtIFRoZSBuZXcgZGF0YS5cbiogQHBhcmFtIGRhdGFVcGRhdGVkQXQgLSBUaGUgdGltZXN0YW1wIHRoZSBkYXRhIGlzIHJlY29yZGVkIHdpdGguIERlZmF1bHRzIHRvIHRoZSBjdXJyZW50IHRpbWUuXG4qIEByZXR1cm5zIFRoZSBwYXJ0aWFsIHF1ZXJ5IHN0YXRlIGZvciBhIHN1Y2Nlc3NmdWwgdXBkYXRlLlxuKi9cbmZ1bmN0aW9uIHN1Y2Nlc3NTdGF0ZShkYXRhLCBkYXRhVXBkYXRlZEF0KSB7XG5cdHJldHVybiB7XG5cdFx0ZGF0YSxcblx0XHRkYXRhVXBkYXRlZEF0OiBkYXRhVXBkYXRlZEF0ID8/IERhdGUubm93KCksXG5cdFx0ZXJyb3I6IG51bGwsXG5cdFx0aXNJbnZhbGlkYXRlZDogZmFsc2UsXG5cdFx0c3RhdHVzOiBcInN1Y2Nlc3NcIlxuXHR9O1xufVxuLyoqXG4qIFJldHVybnMgdGhlIGluaXRpYWwgc3RhdGUgb2YgYSBxdWVyeSwgYmFzZWQgb24gaXRzIGBpbml0aWFsRGF0YWAgYW5kIGBpbml0aWFsRGF0YVVwZGF0ZWRBdGBcbiogb3B0aW9ucy5cbiogQHBhcmFtIG9wdGlvbnMgLSBUaGUgcXVlcnkgb3B0aW9ucy5cbiogQHJldHVybnMgVGhlIGluaXRpYWwgcXVlcnkgc3RhdGU6IGAnc3VjY2VzcydgIGlmIGBpbml0aWFsRGF0YWAgaXMgc2V0LCBvdGhlcndpc2UgYCdwZW5kaW5nJ2AuXG4qL1xuZnVuY3Rpb24gZ2V0RGVmYXVsdFN0YXRlKG9wdGlvbnMpIHtcblx0Y29uc3QgZGF0YSA9IHR5cGVvZiBvcHRpb25zLmluaXRpYWxEYXRhID09PSBcImZ1bmN0aW9uXCIgPyBvcHRpb25zLmluaXRpYWxEYXRhKCkgOiBvcHRpb25zLmluaXRpYWxEYXRhO1xuXHRjb25zdCBoYXNEYXRhID0gZGF0YSAhPT0gdm9pZCAwO1xuXHRjb25zdCBpbml0aWFsRGF0YVVwZGF0ZWRBdCA9IGhhc0RhdGEgPyB0eXBlb2Ygb3B0aW9ucy5pbml0aWFsRGF0YVVwZGF0ZWRBdCA9PT0gXCJmdW5jdGlvblwiID8gb3B0aW9ucy5pbml0aWFsRGF0YVVwZGF0ZWRBdCgpIDogb3B0aW9ucy5pbml0aWFsRGF0YVVwZGF0ZWRBdCA6IDA7XG5cdHJldHVybiB7XG5cdFx0ZGF0YSxcblx0XHRkYXRhVXBkYXRlQ291bnQ6IDAsXG5cdFx0ZGF0YVVwZGF0ZWRBdDogaGFzRGF0YSA/IGluaXRpYWxEYXRhVXBkYXRlZEF0ID8/IERhdGUubm93KCkgOiAwLFxuXHRcdGVycm9yOiBudWxsLFxuXHRcdGVycm9yVXBkYXRlQ291bnQ6IDAsXG5cdFx0ZXJyb3JVcGRhdGVkQXQ6IDAsXG5cdFx0ZmV0Y2hGYWlsdXJlQ291bnQ6IDAsXG5cdFx0ZmV0Y2hGYWlsdXJlUmVhc29uOiBudWxsLFxuXHRcdGZldGNoTWV0YTogbnVsbCxcblx0XHRpc0ludmFsaWRhdGVkOiBmYWxzZSxcblx0XHRzdGF0dXM6IGhhc0RhdGEgPyBcInN1Y2Nlc3NcIiA6IFwicGVuZGluZ1wiLFxuXHRcdGZldGNoU3RhdHVzOiBcImlkbGVcIlxuXHR9O1xufVxuZXhwb3J0IHsgUXVlcnksIGZldGNoU3RhdGUgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9cXVlcnkuanMubWFwIiwiaW1wb3J0IHsgdGltZW91dE1hbmFnZXIgfSBmcm9tIFwiLi90aW1lb3V0TWFuYWdlci5qc1wiO1xuaW1wb3J0IHsgaXNWYWxpZFRpbWVvdXQsIG5vb3AsIHJlcGxhY2VEYXRhLCByZXNvbHZlUXVlcnlWYWx1ZSwgc2hhbGxvd0VxdWFsT2JqZWN0cywgdGltZVVudGlsU3RhbGUgfSBmcm9tIFwiLi91dGlscy5qc1wiO1xuaW1wb3J0IHsgaXNTZXJ2ZXIgfSBmcm9tIFwiLi9lbnZpcm9ubWVudE1hbmFnZXIuanNcIjtcbmltcG9ydCB7IFN1YnNjcmliYWJsZSB9IGZyb20gXCIuL3N1YnNjcmliYWJsZS5qc1wiO1xuaW1wb3J0IHsgZm9jdXNNYW5hZ2VyIH0gZnJvbSBcIi4vZm9jdXNNYW5hZ2VyLmpzXCI7XG5pbXBvcnQgeyBub3RpZnlNYW5hZ2VyIH0gZnJvbSBcIi4vbm90aWZ5TWFuYWdlci5qc1wiO1xuaW1wb3J0IHsgZmV0Y2hTdGF0ZSB9IGZyb20gXCIuL3F1ZXJ5LmpzXCI7XG4vLyBzcmMvcXVlcnlPYnNlcnZlci50c1xuLyoqXG4qIEEgYFF1ZXJ5T2JzZXJ2ZXJgIHdhdGNoZXMgYSBzaW5nbGUgcXVlcnkgaW4gdGhlIGBRdWVyeUNhY2hlYCBhbmQgY29tcHV0ZXMgYVxuKiBgUXVlcnlPYnNlcnZlclJlc3VsdGAgZnJvbSBpdHMgc3RhdGUsIHJlY29tcHV0aW5nIGFuZCBub3RpZnlpbmcgc3Vic2NyaWJlcnNcbiogd2hlbmV2ZXIgdGhlIHVuZGVybHlpbmcgcXVlcnkgKG9yIHRoZSBvYnNlcnZlcidzIG9wdGlvbnMpIGNoYW5nZXMuIEl0IGlzXG4qIHRoZSBwcmltaXRpdmUgdGhhdCBmcmFtZXdvcmsgYWRhcHRlcnMgKGUuZy4gYHVzZVF1ZXJ5YCkgYnVpbGQgdGhlaXIgaG9va3Ncbiogb24gdG9wIG9mLCBidXQgaXQgY2FuIGFsc28gYmUgdXNlZCBkaXJlY3RseSB0byBvYnNlcnZlIGFuZCBzd2l0Y2ggYmV0d2VlblxuKiBxdWVyaWVzIG91dHNpZGUgb2YgYW55IGZyYW1ld29yay5cbiogQGV4YW1wbGVcbiogYGBgdHNcbiogY29uc3Qgb2JzZXJ2ZXIgPSBuZXcgUXVlcnlPYnNlcnZlcihxdWVyeUNsaWVudCwge1xuKiAgIHF1ZXJ5S2V5OiBbJ3Bvc3RzJ10sXG4qICAgcXVlcnlGbjogZmV0Y2hQb3N0cyxcbiogfSlcbipcbiogY29uc3QgdW5zdWJzY3JpYmUgPSBvYnNlcnZlci5zdWJzY3JpYmUoKHJlc3VsdCkgPT4ge1xuKiAgIGNvbnNvbGUubG9nKHJlc3VsdC5kYXRhKVxuKiB9KVxuKiBgYGBcbiovXG52YXIgUXVlcnlPYnNlcnZlciA9IGNsYXNzIGV4dGVuZHMgU3Vic2NyaWJhYmxlIHtcblx0I2NsaWVudDtcblx0I2N1cnJlbnRRdWVyeSA9IHZvaWQgMDtcblx0I2N1cnJlbnRRdWVyeUluaXRpYWxTdGF0ZSA9IHZvaWQgMDtcblx0I2N1cnJlbnRSZXN1bHQgPSB2b2lkIDA7XG5cdCNjdXJyZW50UmVzdWx0U3RhdGU7XG5cdCNjdXJyZW50UmVzdWx0T3B0aW9ucztcblx0I3NlbGVjdEVycm9yO1xuXHQjc2VsZWN0Rm47XG5cdCNzZWxlY3RSZXN1bHQ7XG5cdCNsYXN0UXVlcnlXaXRoRGVmaW5lZERhdGE7XG5cdCNzdGFsZVRpbWVvdXRJZDtcblx0I3JlZmV0Y2hJbnRlcnZhbElkO1xuXHQjY3VycmVudFJlZmV0Y2hJbnRlcnZhbDtcblx0I3RyYWNrZWRQcm9wcyA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgU2V0KCk7XG5cdGNvbnN0cnVjdG9yKGNsaWVudCwgb3B0aW9ucykge1xuXHRcdHN1cGVyKCk7XG5cdFx0dGhpcy5vcHRpb25zID0gb3B0aW9ucztcblx0XHR0aGlzLiNjbGllbnQgPSBjbGllbnQ7XG5cdFx0dGhpcy4jc2VsZWN0RXJyb3IgPSBudWxsO1xuXHRcdHRoaXMuYmluZE1ldGhvZHMoKTtcblx0XHR0aGlzLnNldE9wdGlvbnMob3B0aW9ucyk7XG5cdH1cblx0LyoqXG5cdCogQmluZHMgdGhlIG1ldGhvZHMgb2YgdGhlIHJlc3VsdCAoYHJlZmV0Y2hgKSB0byB0aGUgb2JzZXJ2ZXIsIHNvIHRoZXkga2VlcCB3b3JraW5nIHdoZW4gZGVzdHJ1Y3R1cmVkXG5cdCogZnJvbSBpdC4gU3ViY2xhc3NlcyBvdmVycmlkZSBpdCB0byBiaW5kIHRoZWlyIG93biByZXN1bHQgbWV0aG9kcyBhcyB3ZWxsLlxuXHQqL1xuXHRiaW5kTWV0aG9kcygpIHtcblx0XHR0aGlzLnJlZmV0Y2ggPSB0aGlzLnJlZmV0Y2guYmluZCh0aGlzKTtcblx0fVxuXHRvblN1YnNjcmliZSgpIHtcblx0XHRpZiAodGhpcy5saXN0ZW5lcnMuc2l6ZSA9PT0gMSkge1xuXHRcdFx0dGhpcy4jY3VycmVudFF1ZXJ5LmFkZE9ic2VydmVyKHRoaXMpO1xuXHRcdFx0aWYgKHNob3VsZEZldGNoT25Nb3VudCh0aGlzLiNjdXJyZW50UXVlcnksIHRoaXMub3B0aW9ucykpIHRoaXMuI2V4ZWN1dGVGZXRjaCgpO1xuXHRcdFx0ZWxzZSB0aGlzLnVwZGF0ZVJlc3VsdCgpO1xuXHRcdFx0dGhpcy4jdXBkYXRlVGltZXJzKCk7XG5cdFx0fVxuXHR9XG5cdG9uVW5zdWJzY3JpYmUoKSB7XG5cdFx0aWYgKCF0aGlzLmhhc0xpc3RlbmVycygpKSB0aGlzLmRlc3Ryb3koKTtcblx0fVxuXHQvKipcblx0KiBSZXR1cm5zIHdoZXRoZXIgdGhlIG9ic2VydmVkIHF1ZXJ5IGlzIGN1cnJlbnRseSBzdGFsZSBhbmQgY29uZmlndXJlZFxuXHQqICh2aWEgdGhlIGByZWZldGNoT25SZWNvbm5lY3RgIG9wdGlvbikgdG8gcmVmZXRjaCB3aGVuIHRoZSBuZXR3b3JrXG5cdCogcmVjb25uZWN0cy5cblx0KiBAcmV0dXJucyBgdHJ1ZWAgaWYgdGhlIG9ic2VydmVyIHNob3VsZCByZWZldGNoIHRoZSBxdWVyeSBvbiByZWNvbm5lY3QuXG5cdCovXG5cdHNob3VsZEZldGNoT25SZWNvbm5lY3QoKSB7XG5cdFx0cmV0dXJuIHNob3VsZEZldGNoT24odGhpcy4jY3VycmVudFF1ZXJ5LCB0aGlzLm9wdGlvbnMsIHRoaXMub3B0aW9ucy5yZWZldGNoT25SZWNvbm5lY3QpO1xuXHR9XG5cdC8qKlxuXHQqIFJldHVybnMgd2hldGhlciB0aGUgb2JzZXJ2ZWQgcXVlcnkgaXMgY3VycmVudGx5IHN0YWxlIGFuZCBjb25maWd1cmVkXG5cdCogKHZpYSB0aGUgYHJlZmV0Y2hPbldpbmRvd0ZvY3VzYCBvcHRpb24pIHRvIHJlZmV0Y2ggd2hlbiB0aGUgd2luZG93XG5cdCogcmVnYWlucyBmb2N1cy5cblx0KiBAcmV0dXJucyBgdHJ1ZWAgaWYgdGhlIG9ic2VydmVyIHNob3VsZCByZWZldGNoIHRoZSBxdWVyeSBvbiB3aW5kb3cgZm9jdXMuXG5cdCovXG5cdHNob3VsZEZldGNoT25XaW5kb3dGb2N1cygpIHtcblx0XHRyZXR1cm4gc2hvdWxkRmV0Y2hPbih0aGlzLiNjdXJyZW50UXVlcnksIHRoaXMub3B0aW9ucywgdGhpcy5vcHRpb25zLnJlZmV0Y2hPbldpbmRvd0ZvY3VzKTtcblx0fVxuXHQvKipcblx0KiBTdG9wcyBvYnNlcnZpbmcgdGhlIGN1cnJlbnQgcXVlcnk6IGNsZWFycyBhbGwgbGlzdGVuZXJzLCBjYW5jZWxzIHRoZVxuXHQqIHN0YWxlIGFuZCByZWZldGNoLWludGVydmFsIHRpbWVycywgYW5kIHJlbW92ZXMgdGhpcyBvYnNlcnZlciBmcm9tIHRoZVxuXHQqIHF1ZXJ5IGl0IHdhcyBvYnNlcnZpbmcuXG5cdCovXG5cdGRlc3Ryb3koKSB7XG5cdFx0dGhpcy5saXN0ZW5lcnMgPSAvKiBAX19QVVJFX18gKi8gbmV3IFNldCgpO1xuXHRcdHRoaXMuI2NsZWFyU3RhbGVUaW1lb3V0KCk7XG5cdFx0dGhpcy4jY2xlYXJSZWZldGNoSW50ZXJ2YWwoKTtcblx0XHR0aGlzLiNjdXJyZW50UXVlcnkucmVtb3ZlT2JzZXJ2ZXIodGhpcyk7XG5cdH1cblx0LyoqXG5cdCogVXBkYXRlcyB0aGUgb2JzZXJ2ZXIncyBvcHRpb25zLiBUaGlzIHdpbGwgcmUtcmVzb2x2ZSB0aGUgcXVlcnkgYmVpbmdcblx0KiBvYnNlcnZlZCAoc3dpdGNoaW5nIHRvIGEgZGlmZmVyZW50IHF1ZXJ5IGlmIHRoZSBgcXVlcnlLZXlgIGNoYW5nZWQpLFxuXHQqIHRyaWdnZXIgYSBmZXRjaCBpZiB0aGUgbmV3IG9wdGlvbnMgcmVxdWlyZSBvbmUgYW5kIHRoZSBvYnNlcnZlciBoYXNcblx0KiBzdWJzY3JpYmVycywgcmVjb21wdXRlIHRoZSBjdXJyZW50IHJlc3VsdCwgYW5kIHJlc2NoZWR1bGUgdGhlIHN0YWxlIGFuZFxuXHQqIHJlZmV0Y2gtaW50ZXJ2YWwgdGltZXJzIGFzIG5lZWRlZC5cblx0KiBAcGFyYW0gb3B0aW9ucyAtIFRoZSBuZXcgb2JzZXJ2ZXIgb3B0aW9ucy4gVGhleSBhcmUgZGVmYXVsdGVkIHdpdGgge0BsaW5rXG5cdCogUXVlcnlDbGllbnQjZGVmYXVsdFF1ZXJ5T3B0aW9uc30gYmVmb3JlIGJlaW5nIGFwcGxpZWQuXG5cdCogQHRocm93cyB7RXJyb3J9IElmIGBlbmFibGVkYCBpcyBuZWl0aGVyIGEgYm9vbGVhbiBub3IgYSBmdW5jdGlvbi5cblx0KiBAZXhhbXBsZVxuXHQqIGBgYHRzXG5cdCogb2JzZXJ2ZXIuc2V0T3B0aW9ucyh7IHF1ZXJ5S2V5OiBbJ3Bvc3RzJywgMV0sIHF1ZXJ5Rm46ICgpID0+IGZldGNoUG9zdCgxKSB9KVxuXHQqIC8vIGxhdGVyOiBzd2l0Y2ggdG8gYSBkaWZmZXJlbnQgcXVlcnksIHJldXNpbmcgdGhlIHNhbWUgb2JzZXJ2ZXJcblx0KiBvYnNlcnZlci5zZXRPcHRpb25zKHsgcXVlcnlLZXk6IFsncG9zdHMnLCAyXSwgcXVlcnlGbjogKCkgPT4gZmV0Y2hQb3N0KDIpIH0pXG5cdCogYGBgXG5cdCovXG5cdHNldE9wdGlvbnMob3B0aW9ucykge1xuXHRcdGNvbnN0IHByZXZPcHRpb25zID0gdGhpcy5vcHRpb25zO1xuXHRcdGNvbnN0IHByZXZRdWVyeSA9IHRoaXMuI2N1cnJlbnRRdWVyeTtcblx0XHR0aGlzLm9wdGlvbnMgPSB0aGlzLiNjbGllbnQuZGVmYXVsdFF1ZXJ5T3B0aW9ucyhvcHRpb25zKTtcblx0XHRpZiAodGhpcy5vcHRpb25zLmVuYWJsZWQgIT09IHZvaWQgMCAmJiB0eXBlb2YgdGhpcy5vcHRpb25zLmVuYWJsZWQgIT09IFwiYm9vbGVhblwiICYmIHR5cGVvZiB0aGlzLm9wdGlvbnMuZW5hYmxlZCAhPT0gXCJmdW5jdGlvblwiICYmIHR5cGVvZiByZXNvbHZlUXVlcnlWYWx1ZSh0aGlzLm9wdGlvbnMuZW5hYmxlZCwgdGhpcy4jY3VycmVudFF1ZXJ5KSAhPT0gXCJib29sZWFuXCIpIHRocm93IG5ldyBFcnJvcihcIkV4cGVjdGVkIGVuYWJsZWQgdG8gYmUgYSBib29sZWFuIG9yIGEgY2FsbGJhY2sgdGhhdCByZXR1cm5zIGEgYm9vbGVhblwiKTtcblx0XHR0aGlzLiN1cGRhdGVRdWVyeSgpO1xuXHRcdHRoaXMuI2N1cnJlbnRRdWVyeS5zZXRPcHRpb25zKHRoaXMub3B0aW9ucyk7XG5cdFx0aWYgKHByZXZPcHRpb25zLl9kZWZhdWx0ZWQgJiYgIXNoYWxsb3dFcXVhbE9iamVjdHModGhpcy5vcHRpb25zLCBwcmV2T3B0aW9ucykpIHRoaXMuI2NsaWVudC5nZXRRdWVyeUNhY2hlKCkubm90aWZ5KHtcblx0XHRcdHR5cGU6IFwib2JzZXJ2ZXJPcHRpb25zVXBkYXRlZFwiLFxuXHRcdFx0cXVlcnk6IHRoaXMuI2N1cnJlbnRRdWVyeSxcblx0XHRcdG9ic2VydmVyOiB0aGlzXG5cdFx0fSk7XG5cdFx0Y29uc3QgbW91bnRlZCA9IHRoaXMuaGFzTGlzdGVuZXJzKCk7XG5cdFx0aWYgKG1vdW50ZWQgJiYgc2hvdWxkRmV0Y2hPcHRpb25hbGx5KHRoaXMuI2N1cnJlbnRRdWVyeSwgcHJldlF1ZXJ5LCB0aGlzLm9wdGlvbnMsIHByZXZPcHRpb25zKSkgdGhpcy4jZXhlY3V0ZUZldGNoKCk7XG5cdFx0dGhpcy51cGRhdGVSZXN1bHQoKTtcblx0XHRpZiAobW91bnRlZCAmJiAodGhpcy4jY3VycmVudFF1ZXJ5ICE9PSBwcmV2UXVlcnkgfHwgcmVzb2x2ZVF1ZXJ5VmFsdWUodGhpcy5vcHRpb25zLmVuYWJsZWQsIHRoaXMuI2N1cnJlbnRRdWVyeSkgIT09IHJlc29sdmVRdWVyeVZhbHVlKHByZXZPcHRpb25zLmVuYWJsZWQsIHRoaXMuI2N1cnJlbnRRdWVyeSkgfHwgcmVzb2x2ZVF1ZXJ5VmFsdWUodGhpcy5vcHRpb25zLnN0YWxlVGltZSwgdGhpcy4jY3VycmVudFF1ZXJ5KSAhPT0gcmVzb2x2ZVF1ZXJ5VmFsdWUocHJldk9wdGlvbnMuc3RhbGVUaW1lLCB0aGlzLiNjdXJyZW50UXVlcnkpKSkgdGhpcy4jdXBkYXRlU3RhbGVUaW1lb3V0KCk7XG5cdFx0Y29uc3QgbmV4dFJlZmV0Y2hJbnRlcnZhbCA9IHRoaXMuI2NvbXB1dGVSZWZldGNoSW50ZXJ2YWwoKTtcblx0XHRpZiAobW91bnRlZCAmJiAodGhpcy4jY3VycmVudFF1ZXJ5ICE9PSBwcmV2UXVlcnkgfHwgcmVzb2x2ZVF1ZXJ5VmFsdWUodGhpcy5vcHRpb25zLmVuYWJsZWQsIHRoaXMuI2N1cnJlbnRRdWVyeSkgIT09IHJlc29sdmVRdWVyeVZhbHVlKHByZXZPcHRpb25zLmVuYWJsZWQsIHRoaXMuI2N1cnJlbnRRdWVyeSkgfHwgbmV4dFJlZmV0Y2hJbnRlcnZhbCAhPT0gdGhpcy4jY3VycmVudFJlZmV0Y2hJbnRlcnZhbCkpIHRoaXMuI3VwZGF0ZVJlZmV0Y2hJbnRlcnZhbChuZXh0UmVmZXRjaEludGVydmFsKTtcblx0fVxuXHQvKipcblx0KiBDb21wdXRlcyB0aGUgcmVzdWx0IHRoZSBvYnNlcnZlciB3b3VsZCBwcm9kdWNlIGZvciB0aGUgZ2l2ZW4gKGFscmVhZHktZGVmYXVsdGVkKSBvcHRpb25zXG5cdCogcmlnaHQgbm93LCBidWlsZGluZyB0aGUgdW5kZXJseWluZyBgUXVlcnlgIGlmIGl0IGRvZXNuJ3QgZXhpc3QgeWV0LCB3aXRob3V0IHdhaXRpbmcgZm9yIGFcblx0KiBzdWJzY3JpcHRpb24gY2FsbGJhY2suIENhbGxlZCBieSBmcmFtZXdvcmsgYWRhcHRlcnMgb24gZXZlcnkgcmVuZGVyIChlLmcuIGB1c2VRdWVyeWApIHNvIHRoZVxuXHQqIHJldHVybmVkIHZhbHVlIGlzIGF2YWlsYWJsZSBzeW5jaHJvbm91c2x5LCBhaGVhZCBvZiBgc2V0T3B0aW9uc2AgdHJpZ2dlcmluZyBhbiBhY3R1YWwgZmV0Y2guXG5cdCogQHBhcmFtIG9wdGlvbnMgLSBUaGUgZGVmYXVsdGVkIG9ic2VydmVyIG9wdGlvbnMgdG8gY29tcHV0ZSB0aGUgcmVzdWx0IGZvci5cblx0KiBAcmV0dXJucyBUaGUgcmVzdWx0IGZvciB0aGUgZ2l2ZW4gb3B0aW9ucy5cblx0Ki9cblx0Z2V0T3B0aW1pc3RpY1Jlc3VsdChvcHRpb25zKSB7XG5cdFx0Y29uc3QgcXVlcnkgPSB0aGlzLiNjbGllbnQuZ2V0UXVlcnlDYWNoZSgpLmJ1aWxkKHRoaXMuI2NsaWVudCwgb3B0aW9ucyk7XG5cdFx0Y29uc3QgcmVzdWx0ID0gdGhpcy5jcmVhdGVSZXN1bHQocXVlcnksIG9wdGlvbnMpO1xuXHRcdGlmICghc2hhbGxvd0VxdWFsT2JqZWN0cyh0aGlzLmdldEN1cnJlbnRSZXN1bHQoKSwgcmVzdWx0KSkge1xuXHRcdFx0dGhpcy4jY3VycmVudFJlc3VsdCA9IHJlc3VsdDtcblx0XHRcdHRoaXMuI2N1cnJlbnRSZXN1bHRPcHRpb25zID0gdGhpcy5vcHRpb25zO1xuXHRcdFx0dGhpcy4jY3VycmVudFJlc3VsdFN0YXRlID0gdGhpcy4jY3VycmVudFF1ZXJ5LnN0YXRlO1xuXHRcdH1cblx0XHRyZXR1cm4gcmVzdWx0O1xuXHR9XG5cdC8qKlxuXHQqIFJldHVybnMgdGhlIG1vc3QgcmVjZW50bHkgY29tcHV0ZWQgYFF1ZXJ5T2JzZXJ2ZXJSZXN1bHRgIGZvciB0aGVcblx0KiBvYnNlcnZlZCBxdWVyeS4gVGhpcyBpcyBhIHBvaW50LWluLXRpbWUgcmVhZDsgdG8gYmUgbm90aWZpZWQgb2YgdXBkYXRlc1xuXHQqIGFzIHRoZXkgaGFwcGVuLCBzdWJzY3JpYmUgdG8gdGhlIG9ic2VydmVyIGluc3RlYWQgKGl0cyBpbmhlcml0ZWRcblx0KiBgc3Vic2NyaWJlYCBtZXRob2QpLlxuXHQqIEByZXR1cm5zIFRoZSBvYnNlcnZlcidzIGxhdGVzdCByZXN1bHQuXG5cdCogQGV4YW1wbGVcblx0KiBgYGB0c1xuXHQqIGNvbnN0IHJlc3VsdCA9IG9ic2VydmVyLmdldEN1cnJlbnRSZXN1bHQoKVxuXHQqIGNvbnNvbGUubG9nKHJlc3VsdC5zdGF0dXMsIHJlc3VsdC5kYXRhKVxuXHQqIGBgYFxuXHQqL1xuXHRnZXRDdXJyZW50UmVzdWx0KCkge1xuXHRcdHJldHVybiB0aGlzLiNjdXJyZW50UmVzdWx0O1xuXHR9XG5cdC8qKlxuXHQqIFdyYXBzIGEgYFF1ZXJ5T2JzZXJ2ZXJSZXN1bHRgIGluIGEgYFByb3h5YCB0aGF0IHJlY29yZHMgd2hpY2ggcHJvcGVydGllcyBhcmUgcmVhZCwgdmlhXG5cdCoge0BsaW5rIFF1ZXJ5T2JzZXJ2ZXIjdHJhY2tQcm9wfSAoYW5kIGFuIG9wdGlvbmFsIGBvblByb3BUcmFja2VkYCBjYWxsYmFjaykuIFVzZWQgYnkgZnJhbWV3b3JrXG5cdCogYWRhcHRlcnMgd2hlbiBgbm90aWZ5T25DaGFuZ2VQcm9wc2AgaXMgbm90IHNldCwgdG8gaW1wbGVtZW50IGl0cyBkZWZhdWx0IFwib25seSByZS1yZW5kZXIgb25cblx0KiBwcm9wZXJ0aWVzIHlvdSBhY3R1YWxseSByZWFkXCIgYmVoYXZpb3IuXG5cdCogQHBhcmFtIHJlc3VsdCAtIFRoZSByZXN1bHQgdG8gd3JhcC5cblx0KiBAcGFyYW0gb25Qcm9wVHJhY2tlZCAtIENhbGxlZCB3aXRoIHRoZSBuYW1lIG9mIGVhY2ggcHJvcGVydHkgdGhhdCBpcyByZWFkLlxuXHQqIEByZXR1cm5zIEEgcHJveHkgb2YgYHJlc3VsdGAgdGhhdCB0cmFja3MgcHJvcGVydHkgcmVhZHMuXG5cdCovXG5cdHRyYWNrUmVzdWx0KHJlc3VsdCwgb25Qcm9wVHJhY2tlZCkge1xuXHRcdHJldHVybiBuZXcgUHJveHkocmVzdWx0LCB7IGdldDogKHRhcmdldCwga2V5KSA9PiB7XG5cdFx0XHR0aGlzLnRyYWNrUHJvcChrZXkpO1xuXHRcdFx0b25Qcm9wVHJhY2tlZD8uKGtleSk7XG5cdFx0XHRyZXR1cm4gUmVmbGVjdC5nZXQodGFyZ2V0LCBrZXkpO1xuXHRcdH0gfSk7XG5cdH1cblx0LyoqXG5cdCogUmVjb3JkcyB0aGF0IHRoZSBnaXZlbiBgUXVlcnlPYnNlcnZlclJlc3VsdGAgcHJvcGVydHkgd2FzIHJlYWQsIHNvIGEgc3Vic2VxdWVudCB1cGRhdGUgb25seVxuXHQqIG5vdGlmaWVzIHRoaXMgb2JzZXJ2ZXIgaWYgYSB0cmFja2VkIHByb3BlcnR5IGFjdHVhbGx5IGNoYW5nZWQuIE5vcm1hbGx5IGNhbGxlZCBpbmRpcmVjdGx5IHZpYVxuXHQqIHtAbGluayBRdWVyeU9ic2VydmVyI3RyYWNrUmVzdWx0fSdzIHByb3h5OyBleHBvc2VkIGRpcmVjdGx5IGZvciBhZGFwdGVycyB0aGF0IHRyYWNrIHByb3BlcnR5XG5cdCogYWNjZXNzIHRoZW1zZWx2ZXMgKGUuZy4gdGhyb3VnaCB0aGVpciBvd24gcmVhY3Rpdml0eSBzeXN0ZW0pIGluc3RlYWQgb2YgdmlhIHRoZSBwcm94eS5cblx0KiBAcGFyYW0ga2V5IC0gVGhlIG5hbWUgb2YgdGhlIHByb3BlcnR5IHRoYXQgd2FzIHJlYWQuXG5cdCovXG5cdHRyYWNrUHJvcChrZXkpIHtcblx0XHR0aGlzLiN0cmFja2VkUHJvcHMuYWRkKGtleSk7XG5cdH1cblx0LyoqXG5cdCogUmV0dXJucyB0aGUgYFF1ZXJ5YCBpbnN0YW5jZSB0aGlzIG9ic2VydmVyIGlzIGN1cnJlbnRseSBvYnNlcnZpbmcuXG5cdCogQHJldHVybnMgVGhlIG9ic2VydmVkIHF1ZXJ5LlxuXHQqL1xuXHRnZXRDdXJyZW50UXVlcnkoKSB7XG5cdFx0cmV0dXJuIHRoaXMuI2N1cnJlbnRRdWVyeTtcblx0fVxuXHQvKipcblx0KiBSZWZldGNoZXMgdGhlIG9ic2VydmVkIHF1ZXJ5IGFuZCByZXR1cm5zIGEgcHJvbWlzZSB0aGF0IHJlc29sdmVzIHdpdGhcblx0KiB0aGUgcmVzdWx0aW5nIGBRdWVyeU9ic2VydmVyUmVzdWx0YC5cblx0KiBAcGFyYW0gb3B0aW9ucyAtIFNldCBgY2FuY2VsUmVmZXRjaGAgdG8gYGZhbHNlYCB0byBrZWVwIGEgcnVubmluZyBmZXRjaCBpbnN0ZWFkIG9mIGNhbmNlbGxpbmdcblx0KiBpdCwgYW5kIGB0aHJvd09uRXJyb3JgIHRvIGB0cnVlYCB0byByZWplY3Qgd2hlbiB0aGUgcmVmZXRjaCBmYWlscy5cblx0KiBAcmV0dXJucyBBIHByb21pc2UgdGhhdCByZXNvbHZlcyB3aXRoIHRoZSByZXN1bHQgYWZ0ZXIgdGhlIHJlZmV0Y2guXG5cdCogQGV4YW1wbGVcblx0KiBgYGB0c1xuXHQqIGNvbnN0IHJlc3VsdCA9IGF3YWl0IG9ic2VydmVyLnJlZmV0Y2goeyBjYW5jZWxSZWZldGNoOiBmYWxzZSB9KVxuXHQqIGNvbnNvbGUubG9nKHJlc3VsdC5kYXRhKVxuXHQqIGBgYFxuXHQqL1xuXHRyZWZldGNoKHsgLi4ub3B0aW9ucyB9ID0ge30pIHtcblx0XHRyZXR1cm4gdGhpcy5mZXRjaCh7IC4uLm9wdGlvbnMgfSk7XG5cdH1cblx0LyoqXG5cdCogRmV0Y2hlcyBhIHF1ZXJ5IGRlZmluZWQgYnkgdGhlIGdpdmVuIG9wdGlvbnMgd2l0aG91dCBhZmZlY3RpbmcgdGhpc1xuXHQqIG9ic2VydmVyJ3Mgb3duIHRyYWNrZWQgcXVlcnkgb3IgcmVzdWx0LCBhbmQgcmV0dXJucyBhIHByb21pc2UgdGhhdFxuXHQqIHJlc29sdmVzIHdpdGggdGhlIGBRdWVyeU9ic2VydmVyUmVzdWx0YCBmb3IgdGhhdCBmZXRjaC4gVGhpcyBpcyB1c2VmdWxcblx0KiBmb3IgcHJlZmV0Y2hpbmcgZGF0YSB0aGF0IGFub3RoZXIgb2JzZXJ2ZXIgKGUuZy4gYSBxdWVyeSBhYm91dCB0byBiZVxuXHQqIG5hdmlnYXRlZCB0bykgd2lsbCBuZWVkLCBhaGVhZCBvZiB0aW1lLlxuXHQqIEBwYXJhbSBvcHRpb25zIC0gVGhlIG9ic2VydmVyIG9wdGlvbnMgb2YgdGhlIHF1ZXJ5IHRvIGZldGNoLlxuXHQqIEByZXR1cm5zIEEgcHJvbWlzZSB0aGF0IHJlc29sdmVzIHdpdGggdGhlIHJlc3VsdCBmb3IgdGhlIGZldGNoZWQgcXVlcnkuXG5cdCogQGV4YW1wbGVcblx0KiBgYGB0c1xuXHQqIGNvbnN0IHJlc3VsdCA9IGF3YWl0IG9ic2VydmVyLmZldGNoT3B0aW1pc3RpYyh7XG5cdCogICBxdWVyeUtleTogWydwb3N0cycsIDJdLFxuXHQqICAgcXVlcnlGbjogKCkgPT4gZmV0Y2hQb3N0KDIpLFxuXHQqIH0pXG5cdCogY29uc29sZS5sb2cocmVzdWx0LmRhdGEpXG5cdCogYGBgXG5cdCovXG5cdGZldGNoT3B0aW1pc3RpYyhvcHRpb25zKSB7XG5cdFx0Y29uc3QgZGVmYXVsdGVkT3B0aW9ucyA9IHRoaXMuI2NsaWVudC5kZWZhdWx0UXVlcnlPcHRpb25zKG9wdGlvbnMpO1xuXHRcdGNvbnN0IHF1ZXJ5ID0gdGhpcy4jY2xpZW50LmdldFF1ZXJ5Q2FjaGUoKS5idWlsZCh0aGlzLiNjbGllbnQsIGRlZmF1bHRlZE9wdGlvbnMpO1xuXHRcdGxldCB1bnN1YnNjcmliZSA9ICgpID0+IHt9O1xuXHRcdGxldCByZXNvbHZlRWFybHk7XG5cdFx0Y29uc3QgY2FjaGVQcm9taXNlID0gbmV3IFByb21pc2UoKHJlc29sdmUpID0+IHtcblx0XHRcdHJlc29sdmVFYXJseSA9IHJlc29sdmU7XG5cdFx0XHR1bnN1YnNjcmliZSA9IHRoaXMuI2NsaWVudC5nZXRRdWVyeUNhY2hlKCkuc3Vic2NyaWJlKChldmVudCkgPT4ge1xuXHRcdFx0XHRpZiAoZXZlbnQudHlwZSA9PT0gXCJ1cGRhdGVkXCIgJiYgZXZlbnQucXVlcnkucXVlcnlIYXNoID09PSBxdWVyeS5xdWVyeUhhc2ggJiYgcXVlcnkuc3RhdGUuZGF0YSAhPT0gdm9pZCAwKSB7XG5cdFx0XHRcdFx0dW5zdWJzY3JpYmUoKTtcblx0XHRcdFx0XHRyZXNvbHZlKHRoaXMuY3JlYXRlUmVzdWx0KHF1ZXJ5LCBkZWZhdWx0ZWRPcHRpb25zKSk7XG5cdFx0XHRcdH1cblx0XHRcdH0pO1xuXHRcdH0pO1xuXHRcdHJldHVybiBQcm9taXNlLnJhY2UoW3F1ZXJ5LmZldGNoKGRlZmF1bHRlZE9wdGlvbnMpLnRoZW4oKCkgPT4ge1xuXHRcdFx0Y29uc3QgcmVzdWx0ID0gdGhpcy5jcmVhdGVSZXN1bHQocXVlcnksIGRlZmF1bHRlZE9wdGlvbnMpO1xuXHRcdFx0cmVzb2x2ZUVhcmx5Py4ocmVzdWx0KTtcblx0XHRcdHJldHVybiByZXN1bHQ7XG5cdFx0fSkuZmluYWxseSgoKSA9PiB7XG5cdFx0XHR1bnN1YnNjcmliZSgpO1xuXHRcdH0pLCBjYWNoZVByb21pc2VdKTtcblx0fVxuXHQvKipcblx0KiBGZXRjaGVzIHRoZSBvYnNlcnZlZCBxdWVyeSBhbmQgdXBkYXRlcyB0aGUgcmVzdWx0IG9uY2UgdGhlIGZldGNoIHNldHRsZXMuIFVzZWQgYnkgYHJlZmV0Y2hgIGFuZCxcblx0KiBpbiBgSW5maW5pdGVRdWVyeU9ic2VydmVyYCwgdG8gZmV0Y2ggbW9yZSBwYWdlcy5cblx0KiBAcGFyYW0gZmV0Y2hPcHRpb25zIC0gT3B0aW9ucyBmb3IgdGhpcyBmZXRjaC4gYGNhbmNlbFJlZmV0Y2hgIGRlZmF1bHRzIHRvIGB0cnVlYC5cblx0KiBAcmV0dXJucyBBIHByb21pc2UgdGhhdCByZXNvbHZlcyB3aXRoIHRoZSB1cGRhdGVkIHJlc3VsdC5cblx0Ki9cblx0ZmV0Y2goZmV0Y2hPcHRpb25zKSB7XG5cdFx0cmV0dXJuIHRoaXMuI2V4ZWN1dGVGZXRjaCh7XG5cdFx0XHQuLi5mZXRjaE9wdGlvbnMsXG5cdFx0XHRjYW5jZWxSZWZldGNoOiBmZXRjaE9wdGlvbnMuY2FuY2VsUmVmZXRjaCA/PyB0cnVlXG5cdFx0fSkudGhlbigoKSA9PiB7XG5cdFx0XHR0aGlzLnVwZGF0ZVJlc3VsdCgpO1xuXHRcdFx0cmV0dXJuIHRoaXMuI2N1cnJlbnRSZXN1bHQ7XG5cdFx0fSk7XG5cdH1cblx0I2V4ZWN1dGVGZXRjaChmZXRjaE9wdGlvbnMpIHtcblx0XHR0aGlzLiN1cGRhdGVRdWVyeSgpO1xuXHRcdGxldCBwcm9taXNlID0gdGhpcy4jY3VycmVudFF1ZXJ5LmZldGNoKHRoaXMub3B0aW9ucywgZmV0Y2hPcHRpb25zKTtcblx0XHRpZiAoIWZldGNoT3B0aW9ucz8udGhyb3dPbkVycm9yKSBwcm9taXNlID0gcHJvbWlzZS5jYXRjaChub29wKTtcblx0XHRyZXR1cm4gcHJvbWlzZTtcblx0fVxuXHQjc2hvdWxkU2NoZWR1bGVUaW1lcih0aW1lb3V0KSB7XG5cdFx0cmV0dXJuICFpc1NlcnZlcigpICYmIHJlc29sdmVRdWVyeVZhbHVlKHRoaXMub3B0aW9ucy5lbmFibGVkLCB0aGlzLiNjdXJyZW50UXVlcnkpICE9PSBmYWxzZSAmJiBpc1ZhbGlkVGltZW91dCh0aW1lb3V0KTtcblx0fVxuXHQjdXBkYXRlU3RhbGVUaW1lb3V0KCkge1xuXHRcdHRoaXMuI2NsZWFyU3RhbGVUaW1lb3V0KCk7XG5cdFx0Y29uc3Qgc3RhbGVUaW1lID0gcmVzb2x2ZVF1ZXJ5VmFsdWUodGhpcy5vcHRpb25zLnN0YWxlVGltZSwgdGhpcy4jY3VycmVudFF1ZXJ5KTtcblx0XHRpZiAodGhpcy4jY3VycmVudFJlc3VsdC5pc1N0YWxlIHx8ICF0aGlzLiNzaG91bGRTY2hlZHVsZVRpbWVyKHN0YWxlVGltZSkpIHJldHVybjtcblx0XHRjb25zdCB0aW1lb3V0ID0gdGltZVVudGlsU3RhbGUodGhpcy4jY3VycmVudFJlc3VsdC5kYXRhVXBkYXRlZEF0LCBzdGFsZVRpbWUpICsgMTtcblx0XHR0aGlzLiNzdGFsZVRpbWVvdXRJZCA9IHRpbWVvdXRNYW5hZ2VyLnNldFRpbWVvdXQoKCkgPT4ge1xuXHRcdFx0aWYgKCF0aGlzLiNjdXJyZW50UmVzdWx0LmlzU3RhbGUpIHRoaXMudXBkYXRlUmVzdWx0KCk7XG5cdFx0fSwgdGltZW91dCk7XG5cdH1cblx0I2NvbXB1dGVSZWZldGNoSW50ZXJ2YWwoKSB7XG5cdFx0cmV0dXJuIHJlc29sdmVRdWVyeVZhbHVlKHRoaXMub3B0aW9ucy5yZWZldGNoSW50ZXJ2YWwsIHRoaXMuI2N1cnJlbnRRdWVyeSkgPz8gZmFsc2U7XG5cdH1cblx0I3VwZGF0ZVJlZmV0Y2hJbnRlcnZhbChuZXh0SW50ZXJ2YWwpIHtcblx0XHR0aGlzLiNjbGVhclJlZmV0Y2hJbnRlcnZhbCgpO1xuXHRcdHRoaXMuI2N1cnJlbnRSZWZldGNoSW50ZXJ2YWwgPSBuZXh0SW50ZXJ2YWw7XG5cdFx0aWYgKHRoaXMuI2N1cnJlbnRSZWZldGNoSW50ZXJ2YWwgPT09IDAgfHwgIXRoaXMuI3Nob3VsZFNjaGVkdWxlVGltZXIodGhpcy4jY3VycmVudFJlZmV0Y2hJbnRlcnZhbCkpIHJldHVybjtcblx0XHR0aGlzLiNyZWZldGNoSW50ZXJ2YWxJZCA9IHRpbWVvdXRNYW5hZ2VyLnNldEludGVydmFsKCgpID0+IHtcblx0XHRcdGlmICh0aGlzLm9wdGlvbnMucmVmZXRjaEludGVydmFsSW5CYWNrZ3JvdW5kIHx8IGZvY3VzTWFuYWdlci5pc0ZvY3VzZWQoKSkgdGhpcy4jZXhlY3V0ZUZldGNoKCk7XG5cdFx0fSwgdGhpcy4jY3VycmVudFJlZmV0Y2hJbnRlcnZhbCk7XG5cdH1cblx0I3VwZGF0ZVRpbWVycygpIHtcblx0XHR0aGlzLiN1cGRhdGVTdGFsZVRpbWVvdXQoKTtcblx0XHR0aGlzLiN1cGRhdGVSZWZldGNoSW50ZXJ2YWwodGhpcy4jY29tcHV0ZVJlZmV0Y2hJbnRlcnZhbCgpKTtcblx0fVxuXHQjY2xlYXJTdGFsZVRpbWVvdXQoKSB7XG5cdFx0aWYgKHRoaXMuI3N0YWxlVGltZW91dElkICE9PSB2b2lkIDApIHtcblx0XHRcdHRpbWVvdXRNYW5hZ2VyLmNsZWFyVGltZW91dCh0aGlzLiNzdGFsZVRpbWVvdXRJZCk7XG5cdFx0XHR0aGlzLiNzdGFsZVRpbWVvdXRJZCA9IHZvaWQgMDtcblx0XHR9XG5cdH1cblx0I2NsZWFyUmVmZXRjaEludGVydmFsKCkge1xuXHRcdGlmICh0aGlzLiNyZWZldGNoSW50ZXJ2YWxJZCAhPT0gdm9pZCAwKSB7XG5cdFx0XHR0aW1lb3V0TWFuYWdlci5jbGVhckludGVydmFsKHRoaXMuI3JlZmV0Y2hJbnRlcnZhbElkKTtcblx0XHRcdHRoaXMuI3JlZmV0Y2hJbnRlcnZhbElkID0gdm9pZCAwO1xuXHRcdH1cblx0fVxuXHQvKipcblx0KiBDb21wdXRlcyB0aGUgcmVzdWx0IGZvciBhIHF1ZXJ5IGFuZCBvcHRpb25zIGZyb20gdGhlIHF1ZXJ5J3Mgc3RhdGUsIGFwcGx5aW5nIGBzZWxlY3RgLFxuXHQqIGBwbGFjZWhvbGRlckRhdGFgLCBhbmQgdGhlIGRlcml2ZWQgZmxhZ3MuIFN1YmNsYXNzZXMgb3ZlcnJpZGUgaXQgdG8gYWRkIHRoZWlyIG93biBmaWVsZHMuXG5cdCogQHBhcmFtIHF1ZXJ5IC0gVGhlIHF1ZXJ5IHRvIGNvbXB1dGUgdGhlIHJlc3VsdCBmb3IuXG5cdCogQHBhcmFtIG9wdGlvbnMgLSBUaGUgb2JzZXJ2ZXIgb3B0aW9ucyB0byBjb21wdXRlIHRoZSByZXN1bHQgd2l0aC5cblx0KiBAcmV0dXJucyBUaGUgY29tcHV0ZWQgcmVzdWx0LlxuXHQqL1xuXHRjcmVhdGVSZXN1bHQocXVlcnksIG9wdGlvbnMpIHtcblx0XHRjb25zdCBwcmV2UXVlcnkgPSB0aGlzLiNjdXJyZW50UXVlcnk7XG5cdFx0Y29uc3QgcHJldk9wdGlvbnMgPSB0aGlzLm9wdGlvbnM7XG5cdFx0Y29uc3QgcHJldlJlc3VsdCA9IHRoaXMuI2N1cnJlbnRSZXN1bHQ7XG5cdFx0Y29uc3QgcHJldlJlc3VsdFN0YXRlID0gdGhpcy4jY3VycmVudFJlc3VsdFN0YXRlO1xuXHRcdGNvbnN0IHByZXZSZXN1bHRPcHRpb25zID0gdGhpcy4jY3VycmVudFJlc3VsdE9wdGlvbnM7XG5cdFx0Y29uc3QgcXVlcnlJbml0aWFsU3RhdGUgPSBxdWVyeSAhPT0gcHJldlF1ZXJ5ID8gcXVlcnkuc3RhdGUgOiB0aGlzLiNjdXJyZW50UXVlcnlJbml0aWFsU3RhdGU7XG5cdFx0Y29uc3QgeyBzdGF0ZSB9ID0gcXVlcnk7XG5cdFx0bGV0IG5ld1N0YXRlID0geyAuLi5zdGF0ZSB9O1xuXHRcdGxldCBpc1BsYWNlaG9sZGVyRGF0YSA9IGZhbHNlO1xuXHRcdGxldCBkYXRhO1xuXHRcdGlmIChvcHRpb25zLl9vcHRpbWlzdGljUmVzdWx0cykge1xuXHRcdFx0Y29uc3QgbW91bnRlZCA9IHRoaXMuaGFzTGlzdGVuZXJzKCk7XG5cdFx0XHRjb25zdCBmZXRjaE9uTW91bnQgPSAhbW91bnRlZCAmJiBzaG91bGRGZXRjaE9uTW91bnQocXVlcnksIG9wdGlvbnMpO1xuXHRcdFx0Y29uc3QgZmV0Y2hPcHRpb25hbGx5ID0gbW91bnRlZCAmJiBzaG91bGRGZXRjaE9wdGlvbmFsbHkocXVlcnksIHByZXZRdWVyeSwgb3B0aW9ucywgcHJldk9wdGlvbnMpO1xuXHRcdFx0aWYgKGZldGNoT25Nb3VudCB8fCBmZXRjaE9wdGlvbmFsbHkpIG5ld1N0YXRlID0ge1xuXHRcdFx0XHQuLi5uZXdTdGF0ZSxcblx0XHRcdFx0Li4uZmV0Y2hTdGF0ZShzdGF0ZS5kYXRhLCBxdWVyeS5vcHRpb25zKVxuXHRcdFx0fTtcblx0XHRcdGlmIChvcHRpb25zLl9vcHRpbWlzdGljUmVzdWx0cyA9PT0gXCJpc1Jlc3RvcmluZ1wiKSBuZXdTdGF0ZS5mZXRjaFN0YXR1cyA9IFwiaWRsZVwiO1xuXHRcdH1cblx0XHRsZXQgeyBlcnJvciwgZXJyb3JVcGRhdGVkQXQsIHN0YXR1cyB9ID0gbmV3U3RhdGU7XG5cdFx0ZGF0YSA9IG5ld1N0YXRlLmRhdGE7XG5cdFx0bGV0IHNraXBTZWxlY3QgPSBmYWxzZTtcblx0XHRpZiAob3B0aW9ucy5wbGFjZWhvbGRlckRhdGEgIT09IHZvaWQgMCAmJiBkYXRhID09PSB2b2lkIDAgJiYgc3RhdHVzID09PSBcInBlbmRpbmdcIikge1xuXHRcdFx0bGV0IHBsYWNlaG9sZGVyRGF0YTtcblx0XHRcdGlmIChwcmV2UmVzdWx0Py5pc1BsYWNlaG9sZGVyRGF0YSAmJiBvcHRpb25zLnBsYWNlaG9sZGVyRGF0YSA9PT0gcHJldlJlc3VsdE9wdGlvbnM/LnBsYWNlaG9sZGVyRGF0YSkge1xuXHRcdFx0XHRwbGFjZWhvbGRlckRhdGEgPSBwcmV2UmVzdWx0LmRhdGE7XG5cdFx0XHRcdHNraXBTZWxlY3QgPSB0cnVlO1xuXHRcdFx0fSBlbHNlIHBsYWNlaG9sZGVyRGF0YSA9IHR5cGVvZiBvcHRpb25zLnBsYWNlaG9sZGVyRGF0YSA9PT0gXCJmdW5jdGlvblwiID8gb3B0aW9ucy5wbGFjZWhvbGRlckRhdGEodGhpcy4jbGFzdFF1ZXJ5V2l0aERlZmluZWREYXRhPy5zdGF0ZS5kYXRhLCB0aGlzLiNsYXN0UXVlcnlXaXRoRGVmaW5lZERhdGEpIDogb3B0aW9ucy5wbGFjZWhvbGRlckRhdGE7XG5cdFx0XHRpZiAocGxhY2Vob2xkZXJEYXRhICE9PSB2b2lkIDApIHtcblx0XHRcdFx0c3RhdHVzID0gXCJzdWNjZXNzXCI7XG5cdFx0XHRcdGRhdGEgPSByZXBsYWNlRGF0YShwcmV2UmVzdWx0Py5kYXRhLCBwbGFjZWhvbGRlckRhdGEsIG9wdGlvbnMpO1xuXHRcdFx0XHRpc1BsYWNlaG9sZGVyRGF0YSA9IHRydWU7XG5cdFx0XHR9XG5cdFx0fVxuXHRcdGlmIChvcHRpb25zLnNlbGVjdCAmJiBkYXRhICE9PSB2b2lkIDAgJiYgIXNraXBTZWxlY3QpIHtcblx0XHRcdGlmIChwcmV2UmVzdWx0ICYmIGRhdGEgPT09IHByZXZSZXN1bHRTdGF0ZT8uZGF0YSAmJiBvcHRpb25zLnNlbGVjdCA9PT0gdGhpcy4jc2VsZWN0Rm4pIGRhdGEgPSB0aGlzLiNzZWxlY3RSZXN1bHQ7XG5cdFx0XHRlbHNlIHRyeSB7XG5cdFx0XHRcdHRoaXMuI3NlbGVjdEZuID0gb3B0aW9ucy5zZWxlY3Q7XG5cdFx0XHRcdGRhdGEgPSBvcHRpb25zLnNlbGVjdChkYXRhKTtcblx0XHRcdFx0ZGF0YSA9IHJlcGxhY2VEYXRhKHByZXZSZXN1bHQ/LmRhdGEsIGRhdGEsIG9wdGlvbnMpO1xuXHRcdFx0XHR0aGlzLiNzZWxlY3RSZXN1bHQgPSBkYXRhO1xuXHRcdFx0XHR0aGlzLiNzZWxlY3RFcnJvciA9IG51bGw7XG5cdFx0XHR9IGNhdGNoIChzZWxlY3RFcnJvcikge1xuXHRcdFx0XHR0aGlzLiNzZWxlY3RFcnJvciA9IHNlbGVjdEVycm9yO1xuXHRcdFx0fVxuXHRcdH0gZWxzZSBpZiAoZGF0YSA9PT0gdm9pZCAwKSB0aGlzLiNzZWxlY3RFcnJvciA9IG51bGw7XG5cdFx0aWYgKHRoaXMuI3NlbGVjdEVycm9yKSB7XG5cdFx0XHRlcnJvciA9IHRoaXMuI3NlbGVjdEVycm9yO1xuXHRcdFx0ZGF0YSA9IHRoaXMuI3NlbGVjdFJlc3VsdDtcblx0XHRcdGVycm9yVXBkYXRlZEF0ID0gcHJldlJlc3VsdD8uZXJyb3IgPT09IGVycm9yID8gcHJldlJlc3VsdC5lcnJvclVwZGF0ZWRBdCA6IERhdGUubm93KCk7XG5cdFx0XHRzdGF0dXMgPSBcImVycm9yXCI7XG5cdFx0XHRpc1BsYWNlaG9sZGVyRGF0YSA9IGZhbHNlO1xuXHRcdH1cblx0XHRjb25zdCBpc0ZldGNoaW5nID0gbmV3U3RhdGUuZmV0Y2hTdGF0dXMgPT09IFwiZmV0Y2hpbmdcIjtcblx0XHRjb25zdCBpc1BlbmRpbmcgPSBzdGF0dXMgPT09IFwicGVuZGluZ1wiO1xuXHRcdGNvbnN0IGlzRXJyb3IgPSBzdGF0dXMgPT09IFwiZXJyb3JcIjtcblx0XHRjb25zdCBpc0xvYWRpbmcgPSBpc1BlbmRpbmcgJiYgaXNGZXRjaGluZztcblx0XHRjb25zdCBoYXNEYXRhID0gZGF0YSAhPT0gdm9pZCAwO1xuXHRcdHJldHVybiB7XG5cdFx0XHRzdGF0dXMsXG5cdFx0XHRmZXRjaFN0YXR1czogbmV3U3RhdGUuZmV0Y2hTdGF0dXMsXG5cdFx0XHRpc1BlbmRpbmcsXG5cdFx0XHRpc1N1Y2Nlc3M6IHN0YXR1cyA9PT0gXCJzdWNjZXNzXCIsXG5cdFx0XHRpc0Vycm9yLFxuXHRcdFx0aXNJbml0aWFsTG9hZGluZzogaXNMb2FkaW5nLFxuXHRcdFx0aXNMb2FkaW5nLFxuXHRcdFx0ZGF0YSxcblx0XHRcdGRhdGFVcGRhdGVkQXQ6IG5ld1N0YXRlLmRhdGFVcGRhdGVkQXQsXG5cdFx0XHRlcnJvcixcblx0XHRcdGVycm9yVXBkYXRlZEF0LFxuXHRcdFx0ZmFpbHVyZUNvdW50OiBuZXdTdGF0ZS5mZXRjaEZhaWx1cmVDb3VudCxcblx0XHRcdGZhaWx1cmVSZWFzb246IG5ld1N0YXRlLmZldGNoRmFpbHVyZVJlYXNvbixcblx0XHRcdGVycm9yVXBkYXRlQ291bnQ6IG5ld1N0YXRlLmVycm9yVXBkYXRlQ291bnQsXG5cdFx0XHRpc0ZldGNoZWQ6IHF1ZXJ5LmlzRmV0Y2hlZCgpLFxuXHRcdFx0aXNGZXRjaGVkQWZ0ZXJNb3VudDogbmV3U3RhdGUuZGF0YVVwZGF0ZUNvdW50ID4gcXVlcnlJbml0aWFsU3RhdGUuZGF0YVVwZGF0ZUNvdW50IHx8IG5ld1N0YXRlLmVycm9yVXBkYXRlQ291bnQgPiBxdWVyeUluaXRpYWxTdGF0ZS5lcnJvclVwZGF0ZUNvdW50LFxuXHRcdFx0aXNGZXRjaGluZyxcblx0XHRcdGlzUmVmZXRjaGluZzogaXNGZXRjaGluZyAmJiAhaXNQZW5kaW5nLFxuXHRcdFx0aXNMb2FkaW5nRXJyb3I6IGlzRXJyb3IgJiYgIWhhc0RhdGEsXG5cdFx0XHRpc1BhdXNlZDogbmV3U3RhdGUuZmV0Y2hTdGF0dXMgPT09IFwicGF1c2VkXCIsXG5cdFx0XHRpc1BsYWNlaG9sZGVyRGF0YSxcblx0XHRcdGlzUmVmZXRjaEVycm9yOiBpc0Vycm9yICYmIGhhc0RhdGEsXG5cdFx0XHRpc1N0YWxlOiBpc1N0YWxlKHF1ZXJ5LCBvcHRpb25zKSxcblx0XHRcdHJlZmV0Y2g6IHRoaXMucmVmZXRjaCxcblx0XHRcdGlzRW5hYmxlZDogcmVzb2x2ZVF1ZXJ5VmFsdWUob3B0aW9ucy5lbmFibGVkLCBxdWVyeSkgIT09IGZhbHNlXG5cdFx0fTtcblx0fVxuXHQvKipcblx0KiBSZWNvbXB1dGVzIGFuZCBzdG9yZXMgdGhlIGN1cnJlbnQgcmVzdWx0IGZyb20gdGhlIGN1cnJlbnQgcXVlcnkvb3B0aW9ucywgbm90aWZ5aW5nIGxpc3RlbmVyc1xuXHQqIGlmIGl0IGNoYW5nZWQuIEZyYW1ld29yayBhZGFwdGVycyBjYWxsIHRoaXMgcmlnaHQgYWZ0ZXIgc3Vic2NyaWJpbmcgdG8gbWFrZSBzdXJlIG5vIHF1ZXJ5XG5cdCogdXBkYXRlIHdhcyBtaXNzZWQgaW4gdGhlIGdhcCBiZXR3ZWVuIGNyZWF0aW5nIHRoZSBvYnNlcnZlciBhbmQgc3Vic2NyaWJpbmcgdG8gaXQuXG5cdCovXG5cdHVwZGF0ZVJlc3VsdCgpIHtcblx0XHRjb25zdCBwcmV2UmVzdWx0ID0gdGhpcy4jY3VycmVudFJlc3VsdDtcblx0XHRjb25zdCBuZXh0UmVzdWx0ID0gdGhpcy5jcmVhdGVSZXN1bHQodGhpcy4jY3VycmVudFF1ZXJ5LCB0aGlzLm9wdGlvbnMpO1xuXHRcdHRoaXMuI2N1cnJlbnRSZXN1bHRTdGF0ZSA9IHRoaXMuI2N1cnJlbnRRdWVyeS5zdGF0ZTtcblx0XHR0aGlzLiNjdXJyZW50UmVzdWx0T3B0aW9ucyA9IHRoaXMub3B0aW9ucztcblx0XHRpZiAodGhpcy4jY3VycmVudFJlc3VsdFN0YXRlLmRhdGEgIT09IHZvaWQgMCkgdGhpcy4jbGFzdFF1ZXJ5V2l0aERlZmluZWREYXRhID0gdGhpcy4jY3VycmVudFF1ZXJ5O1xuXHRcdGlmIChzaGFsbG93RXF1YWxPYmplY3RzKG5leHRSZXN1bHQsIHByZXZSZXN1bHQpKSByZXR1cm47XG5cdFx0dGhpcy4jY3VycmVudFJlc3VsdCA9IG5leHRSZXN1bHQ7XG5cdFx0Y29uc3Qgc2hvdWxkTm90aWZ5TGlzdGVuZXJzID0gKCkgPT4ge1xuXHRcdFx0aWYgKCFwcmV2UmVzdWx0KSByZXR1cm4gdHJ1ZTtcblx0XHRcdGNvbnN0IHsgbm90aWZ5T25DaGFuZ2VQcm9wcyB9ID0gdGhpcy5vcHRpb25zO1xuXHRcdFx0Y29uc3Qgbm90aWZ5T25DaGFuZ2VQcm9wc1ZhbHVlID0gdHlwZW9mIG5vdGlmeU9uQ2hhbmdlUHJvcHMgPT09IFwiZnVuY3Rpb25cIiA/IG5vdGlmeU9uQ2hhbmdlUHJvcHMoKSA6IG5vdGlmeU9uQ2hhbmdlUHJvcHM7XG5cdFx0XHRpZiAobm90aWZ5T25DaGFuZ2VQcm9wc1ZhbHVlID09PSBcImFsbFwiIHx8ICFub3RpZnlPbkNoYW5nZVByb3BzVmFsdWUgJiYgIXRoaXMuI3RyYWNrZWRQcm9wcy5zaXplKSByZXR1cm4gdHJ1ZTtcblx0XHRcdGlmICh0aGlzLm9wdGlvbnMudGhyb3dPbkVycm9yICYmIHRoaXMuI2N1cnJlbnRSZXN1bHQuZXJyb3IgIT09IHByZXZSZXN1bHQuZXJyb3IpIHJldHVybiB0cnVlO1xuXHRcdFx0Zm9yIChjb25zdCBrZXkgb2Ygbm90aWZ5T25DaGFuZ2VQcm9wc1ZhbHVlID8/IHRoaXMuI3RyYWNrZWRQcm9wcykgaWYgKHRoaXMuI2N1cnJlbnRSZXN1bHRba2V5XSAhPT0gcHJldlJlc3VsdFtrZXldKSByZXR1cm4gdHJ1ZTtcblx0XHRcdHJldHVybiBmYWxzZTtcblx0XHR9O1xuXHRcdGNvbnN0IG5vdGlmeUxpc3RlbmVycyA9IHNob3VsZE5vdGlmeUxpc3RlbmVycygpO1xuXHRcdG5vdGlmeU1hbmFnZXIuYmF0Y2goKCkgPT4ge1xuXHRcdFx0aWYgKG5vdGlmeUxpc3RlbmVycykgdGhpcy5saXN0ZW5lcnMuZm9yRWFjaCgobGlzdGVuZXIpID0+IHtcblx0XHRcdFx0bGlzdGVuZXIodGhpcy4jY3VycmVudFJlc3VsdCk7XG5cdFx0XHR9KTtcblx0XHRcdHRoaXMuI2NsaWVudC5nZXRRdWVyeUNhY2hlKCkubm90aWZ5KHtcblx0XHRcdFx0cXVlcnk6IHRoaXMuI2N1cnJlbnRRdWVyeSxcblx0XHRcdFx0dHlwZTogXCJvYnNlcnZlclJlc3VsdHNVcGRhdGVkXCJcblx0XHRcdH0pO1xuXHRcdH0pO1xuXHR9XG5cdCN1cGRhdGVRdWVyeSgpIHtcblx0XHRjb25zdCBxdWVyeSA9IHRoaXMuI2NsaWVudC5nZXRRdWVyeUNhY2hlKCkuYnVpbGQodGhpcy4jY2xpZW50LCB0aGlzLm9wdGlvbnMpO1xuXHRcdGlmIChxdWVyeSA9PT0gdGhpcy4jY3VycmVudFF1ZXJ5KSByZXR1cm47XG5cdFx0Y29uc3QgcHJldlF1ZXJ5ID0gdGhpcy4jY3VycmVudFF1ZXJ5O1xuXHRcdHRoaXMuI2N1cnJlbnRRdWVyeSA9IHF1ZXJ5O1xuXHRcdHRoaXMuI2N1cnJlbnRRdWVyeUluaXRpYWxTdGF0ZSA9IHF1ZXJ5LnN0YXRlO1xuXHRcdGlmICh0aGlzLmhhc0xpc3RlbmVycygpKSB7XG5cdFx0XHRwcmV2UXVlcnk/LnJlbW92ZU9ic2VydmVyKHRoaXMpO1xuXHRcdFx0cXVlcnkuYWRkT2JzZXJ2ZXIodGhpcyk7XG5cdFx0fVxuXHR9XG5cdC8qKlxuXHQqIFVwZGF0ZXMgdGhlIG9ic2VydmVyJ3MgcmVzdWx0IHdoZW4gdGhlIG9ic2VydmVkIHF1ZXJ5IGNoYW5nZXMsIGFuZCByZXNjaGVkdWxlcyBpdHMgdGltZXJzIGlmIGl0XG5cdCogaGFzIGxpc3RlbmVycy5cblx0KiBAaW50ZXJuYWxcblx0Ki9cblx0b25RdWVyeVVwZGF0ZSgpIHtcblx0XHR0aGlzLnVwZGF0ZVJlc3VsdCgpO1xuXHRcdGlmICh0aGlzLmhhc0xpc3RlbmVycygpKSB0aGlzLiN1cGRhdGVUaW1lcnMoKTtcblx0fVxufTtcbi8qKlxuKiBDaGVja3Mgd2hldGhlciBhIHF1ZXJ5IGhhcyBubyBkYXRhIHlldCBhbmQgc2hvdWxkIGRvIGl0cyBpbml0aWFsIGxvYWQgd2hlbiBhbiBvYnNlcnZlciBtb3VudHMuXG4qIEBwYXJhbSBxdWVyeSAtIFRoZSBxdWVyeSB0byBjaGVjay5cbiogQHBhcmFtIG9wdGlvbnMgLSBUaGUgb2JzZXJ2ZXIgb3B0aW9ucy5cbiogQHJldHVybnMgYHRydWVgIGlmIHRoZSBxdWVyeSBpcyBlbmFibGVkLCBoYXMgbm8gZGF0YSwgYW5kIGlzbid0IGluIGFuIGVycm9yIHN0YXRlIHdpdGhcbiogYHJldHJ5T25Nb3VudDogZmFsc2VgLlxuKi9cbmZ1bmN0aW9uIHNob3VsZExvYWRPbk1vdW50KHF1ZXJ5LCBvcHRpb25zKSB7XG5cdHJldHVybiByZXNvbHZlUXVlcnlWYWx1ZShvcHRpb25zLmVuYWJsZWQsIHF1ZXJ5KSAhPT0gZmFsc2UgJiYgcXVlcnkuc3RhdGUuZGF0YSA9PT0gdm9pZCAwICYmICEocXVlcnkuc3RhdGUuc3RhdHVzID09PSBcImVycm9yXCIgJiYgcmVzb2x2ZVF1ZXJ5VmFsdWUob3B0aW9ucy5yZXRyeU9uTW91bnQsIHF1ZXJ5KSA9PT0gZmFsc2UpO1xufVxuLyoqXG4qIENoZWNrcyB3aGV0aGVyIGEgcXVlcnkgc2hvdWxkIGZldGNoIHdoZW4gYW4gb2JzZXJ2ZXIgbW91bnRzOiBlaXRoZXIgZm9yIGl0cyBpbml0aWFsIGxvYWQsIG9yXG4qIGJlY2F1c2UgaXQgaGFzIGRhdGEgYW5kIGByZWZldGNoT25Nb3VudGAgYXNrcyBmb3IgYSByZWZldGNoLlxuKiBAcGFyYW0gcXVlcnkgLSBUaGUgcXVlcnkgdG8gY2hlY2suXG4qIEBwYXJhbSBvcHRpb25zIC0gVGhlIG9ic2VydmVyIG9wdGlvbnMuXG4qIEByZXR1cm5zIGB0cnVlYCBpZiB0aGUgcXVlcnkgc2hvdWxkIGZldGNoIG9uIG1vdW50LlxuKi9cbmZ1bmN0aW9uIHNob3VsZEZldGNoT25Nb3VudChxdWVyeSwgb3B0aW9ucykge1xuXHRyZXR1cm4gc2hvdWxkTG9hZE9uTW91bnQocXVlcnksIG9wdGlvbnMpIHx8IHF1ZXJ5LnN0YXRlLmRhdGEgIT09IHZvaWQgMCAmJiBzaG91bGRGZXRjaE9uKHF1ZXJ5LCBvcHRpb25zLCBvcHRpb25zLnJlZmV0Y2hPbk1vdW50KTtcbn1cbi8qKlxuKiBDaGVja3Mgd2hldGhlciBhIHF1ZXJ5IHNob3VsZCBmZXRjaCBmb3IgYSBgcmVmZXRjaE9uTW91bnRgLCBgcmVmZXRjaE9uV2luZG93Rm9jdXNgLCBvclxuKiBgcmVmZXRjaE9uUmVjb25uZWN0YCBvcHRpb24uXG4qIEBwYXJhbSBxdWVyeSAtIFRoZSBxdWVyeSB0byBjaGVjay5cbiogQHBhcmFtIG9wdGlvbnMgLSBUaGUgb2JzZXJ2ZXIgb3B0aW9ucy5cbiogQHBhcmFtIGZpZWxkIC0gVGhlIHZhbHVlIG9mIHRoZSBvcHRpb24gdG8gY2hlY2suXG4qIEByZXR1cm5zIGB0cnVlYCBpZiB0aGUgcXVlcnkgaXMgZW5hYmxlZCwgbm90IHN0YXRpYywgYW5kIHRoZSBvcHRpb24gaXMgYCdhbHdheXMnYCwgb3IgaXMgbm90XG4qIGBmYWxzZWAgYW5kIHRoZSBxdWVyeSBpcyBzdGFsZS5cbiovXG5mdW5jdGlvbiBzaG91bGRGZXRjaE9uKHF1ZXJ5LCBvcHRpb25zLCBmaWVsZCkge1xuXHRpZiAocmVzb2x2ZVF1ZXJ5VmFsdWUob3B0aW9ucy5lbmFibGVkLCBxdWVyeSkgIT09IGZhbHNlICYmIHJlc29sdmVRdWVyeVZhbHVlKG9wdGlvbnMuc3RhbGVUaW1lLCBxdWVyeSkgIT09IFwic3RhdGljXCIpIHtcblx0XHRjb25zdCB2YWx1ZSA9IHJlc29sdmVRdWVyeVZhbHVlKGZpZWxkLCBxdWVyeSk7XG5cdFx0cmV0dXJuIHZhbHVlID09PSBcImFsd2F5c1wiIHx8IHZhbHVlICE9PSBmYWxzZSAmJiBpc1N0YWxlKHF1ZXJ5LCBvcHRpb25zKTtcblx0fVxuXHRyZXR1cm4gZmFsc2U7XG59XG4vKipcbiogQ2hlY2tzIHdoZXRoZXIgYSBxdWVyeSBzaG91bGQgZmV0Y2ggYWZ0ZXIgdGhlIG9ic2VydmVyJ3Mgb3B0aW9ucyBjaGFuZ2UuXG4qIEBwYXJhbSBxdWVyeSAtIFRoZSBxdWVyeSBvYnNlcnZlZCB3aXRoIHRoZSBuZXcgb3B0aW9ucy5cbiogQHBhcmFtIHByZXZRdWVyeSAtIFRoZSBxdWVyeSBvYnNlcnZlZCB3aXRoIHRoZSBwcmV2aW91cyBvcHRpb25zLlxuKiBAcGFyYW0gb3B0aW9ucyAtIFRoZSBuZXcgb2JzZXJ2ZXIgb3B0aW9ucy5cbiogQHBhcmFtIHByZXZPcHRpb25zIC0gVGhlIHByZXZpb3VzIG9ic2VydmVyIG9wdGlvbnMuXG4qIEByZXR1cm5zIGB0cnVlYCBpZiB0aGUgcXVlcnkgY2hhbmdlZCBvciB3YXMgZGlzYWJsZWQgYmVmb3JlLCBpdCBpc24ndCBhIHN1c3BlbnNlIHF1ZXJ5IGluIGFuXG4qIGVycm9yIHN0YXRlLCBhbmQgaXQgaXMgc3RhbGUuXG4qL1xuZnVuY3Rpb24gc2hvdWxkRmV0Y2hPcHRpb25hbGx5KHF1ZXJ5LCBwcmV2UXVlcnksIG9wdGlvbnMsIHByZXZPcHRpb25zKSB7XG5cdHJldHVybiAocXVlcnkgIT09IHByZXZRdWVyeSB8fCByZXNvbHZlUXVlcnlWYWx1ZShwcmV2T3B0aW9ucy5lbmFibGVkLCBxdWVyeSkgPT09IGZhbHNlKSAmJiAoIW9wdGlvbnMuc3VzcGVuc2UgfHwgcXVlcnkuc3RhdGUuc3RhdHVzICE9PSBcImVycm9yXCIpICYmIGlzU3RhbGUocXVlcnksIG9wdGlvbnMpO1xufVxuLyoqXG4qIENoZWNrcyB3aGV0aGVyIGEgcXVlcnkgaXMgc3RhbGUgZm9yIHRoZSBnaXZlbiBvYnNlcnZlciBvcHRpb25zLlxuKiBAcGFyYW0gcXVlcnkgLSBUaGUgcXVlcnkgdG8gY2hlY2suXG4qIEBwYXJhbSBvcHRpb25zIC0gVGhlIG9ic2VydmVyIG9wdGlvbnMsIHdob3NlIGBlbmFibGVkYCBhbmQgYHN0YWxlVGltZWAgYXJlIHVzZWQuXG4qIEByZXR1cm5zIGB0cnVlYCBpZiB0aGUgcXVlcnkgaXMgZW5hYmxlZCBhbmQgaXRzIGRhdGEgaXMgc3RhbGUgZm9yIGBzdGFsZVRpbWVgLlxuKi9cbmZ1bmN0aW9uIGlzU3RhbGUocXVlcnksIG9wdGlvbnMpIHtcblx0cmV0dXJuIHJlc29sdmVRdWVyeVZhbHVlKG9wdGlvbnMuZW5hYmxlZCwgcXVlcnkpICE9PSBmYWxzZSAmJiBxdWVyeS5pc1N0YWxlQnlUaW1lKHJlc29sdmVRdWVyeVZhbHVlKG9wdGlvbnMuc3RhbGVUaW1lLCBxdWVyeSkpO1xufVxuZXhwb3J0IHsgUXVlcnlPYnNlcnZlciB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1xdWVyeU9ic2VydmVyLmpzLm1hcCIsImltcG9ydCB7IGhhc05leHRQYWdlLCBoYXNQcmV2aW91c1BhZ2UgfSBmcm9tIFwiLi9pbmZpbml0ZVF1ZXJ5QmVoYXZpb3IuanNcIjtcbmltcG9ydCB7IFF1ZXJ5T2JzZXJ2ZXIgfSBmcm9tIFwiLi9xdWVyeU9ic2VydmVyLmpzXCI7XG4vLyBzcmMvaW5maW5pdGVRdWVyeU9ic2VydmVyLnRzXG4vKipcbiogQW4gYEluZmluaXRlUXVlcnlPYnNlcnZlcmAgZXh0ZW5kcyBgUXVlcnlPYnNlcnZlcmAgdG8gb2JzZXJ2ZSBhbmQgc3dpdGNoXG4qIGJldHdlZW4gaW5maW5pdGUgcXVlcmllcy4gSXQgYXVnbWVudHMgdGhlIGJhc2UgYFF1ZXJ5T2JzZXJ2ZXJSZXN1bHRgIHdpdGhcbiogaW5maW5pdGUtcXVlcnktc3BlY2lmaWMgZmllbGRzIGFuZCBtZXRob2RzLCBzdWNoIGFzIGBoYXNOZXh0UGFnZWAgYW5kXG4qIGBmZXRjaE5leHRQYWdlYCwgYW5kIGlzIHRoZSBwcmltaXRpdmUgdGhhdCBmcmFtZXdvcmsgYWRhcHRlcnMgKGUuZy5cbiogYHVzZUluZmluaXRlUXVlcnlgKSBidWlsZCB0aGVpciBob29rcyBvbiB0b3Agb2YuXG4qIEBleGFtcGxlXG4qIGBgYHRzXG4qIGNvbnN0IG9ic2VydmVyID0gbmV3IEluZmluaXRlUXVlcnlPYnNlcnZlcihxdWVyeUNsaWVudCwge1xuKiAgIHF1ZXJ5S2V5OiBbJ3Byb2plY3RzJ10sXG4qICAgcXVlcnlGbjogKHsgcGFnZVBhcmFtIH0pID0+IGZldGNoUHJvamVjdHMocGFnZVBhcmFtKSxcbiogICBpbml0aWFsUGFnZVBhcmFtOiAwLFxuKiAgIGdldE5leHRQYWdlUGFyYW06IChsYXN0UGFnZSkgPT4gbGFzdFBhZ2UubmV4dEN1cnNvcixcbiogfSlcbipcbiogY29uc3QgdW5zdWJzY3JpYmUgPSBvYnNlcnZlci5zdWJzY3JpYmUoKHJlc3VsdCkgPT4gY29uc29sZS5sb2cocmVzdWx0KSlcbiogYGBgXG4qL1xudmFyIEluZmluaXRlUXVlcnlPYnNlcnZlciA9IGNsYXNzIGV4dGVuZHMgUXVlcnlPYnNlcnZlciB7XG5cdGNvbnN0cnVjdG9yKGNsaWVudCwgb3B0aW9ucykge1xuXHRcdHN1cGVyKGNsaWVudCwgb3B0aW9ucyk7XG5cdH1cblx0YmluZE1ldGhvZHMoKSB7XG5cdFx0c3VwZXIuYmluZE1ldGhvZHMoKTtcblx0XHR0aGlzLmZldGNoTmV4dFBhZ2UgPSB0aGlzLmZldGNoTmV4dFBhZ2UuYmluZCh0aGlzKTtcblx0XHR0aGlzLmZldGNoUHJldmlvdXNQYWdlID0gdGhpcy5mZXRjaFByZXZpb3VzUGFnZS5iaW5kKHRoaXMpO1xuXHR9XG5cdC8qKlxuXHQqIFVwZGF0ZXMgdGhlIG9ic2VydmVyJ3Mgb3B0aW9ucy4gQmVoYXZlcyB0aGUgc2FtZSBhc1xuXHQqIGBRdWVyeU9ic2VydmVyLnNldE9wdGlvbnNgLCBhZGRpdGlvbmFsbHkgbWFya2luZyB0aGUgb3B0aW9ucyBhc1xuXHQqIGJlbG9uZ2luZyB0byBhbiBpbmZpbml0ZSBxdWVyeSBiZWZvcmUgZGVsZWdhdGluZyB0byB0aGUgYmFzZVxuXHQqIGltcGxlbWVudGF0aW9uLlxuXHQqIEBwYXJhbSBvcHRpb25zIC0gVGhlIG5ldyBpbmZpbml0ZSBxdWVyeSBvYnNlcnZlciBvcHRpb25zLlxuXHQqL1xuXHRzZXRPcHRpb25zKG9wdGlvbnMpIHtcblx0XHRvcHRpb25zLl90eXBlID0gXCJpbmZpbml0ZVwiO1xuXHRcdHN1cGVyLnNldE9wdGlvbnMob3B0aW9ucyk7XG5cdH1cblx0LyoqXG5cdCogVGhlIGluZmluaXRlLXF1ZXJ5IGNvdW50ZXJwYXJ0IG9mIHtAbGluayBRdWVyeU9ic2VydmVyI2dldE9wdGltaXN0aWNSZXN1bHR9LCBtYXJraW5nIHRoZVxuXHQqIG9wdGlvbnMgYXMgYW4gaW5maW5pdGUgcXVlcnkgYmVmb3JlIGRlbGVnYXRpbmcgdG8gaXQuIENhbGxlZCBieSBmcmFtZXdvcmsgYWRhcHRlcnMgKGUuZy5cblx0KiBgdXNlSW5maW5pdGVRdWVyeWApIGFoZWFkIG9mIHN1YnNjcmliaW5nLCB0byBjb21wdXRlIHRoZSBjdXJyZW50IGBJbmZpbml0ZVF1ZXJ5T2JzZXJ2ZXJSZXN1bHRgXG5cdCogc3luY2hyb25vdXNseS5cblx0KiBAcGFyYW0gb3B0aW9ucyAtIFRoZSBkZWZhdWx0ZWQgaW5maW5pdGUgcXVlcnkgb2JzZXJ2ZXIgb3B0aW9ucyB0byBjb21wdXRlIHRoZSByZXN1bHQgZm9yLlxuXHQqIEByZXR1cm5zIFRoZSByZXN1bHQgZm9yIHRoZSBnaXZlbiBvcHRpb25zLlxuXHQqL1xuXHRnZXRPcHRpbWlzdGljUmVzdWx0KG9wdGlvbnMpIHtcblx0XHRvcHRpb25zLl90eXBlID0gXCJpbmZpbml0ZVwiO1xuXHRcdHJldHVybiBzdXBlci5nZXRPcHRpbWlzdGljUmVzdWx0KG9wdGlvbnMpO1xuXHR9XG5cdC8qKlxuXHQqIEZldGNoZXMgdGhlIG5leHQgcGFnZSBvZiB0aGUgaW5maW5pdGUgcXVlcnkgYW5kIHJldHVybnMgYSBwcm9taXNlIHRoYXRcblx0KiByZXNvbHZlcyB3aXRoIHRoZSByZXN1bHRpbmcgYEluZmluaXRlUXVlcnlPYnNlcnZlclJlc3VsdGAuIFRoZSBwYWdlXG5cdCogcGFyYW0gdXNlZCBmb3IgdGhlIGZldGNoIGlzIGRldGVybWluZWQgYnkgYGdldE5leHRQYWdlUGFyYW1gLCB3aGljaFxuXHQqIHJlY2VpdmVzIHRoZSBjdXJyZW50IHBhZ2VzL3BhZ2UgcGFyYW1zIGFuZCB3aG9zZSByZXN1bHQgYWxzbyBkZXRlcm1pbmVzXG5cdCogYGhhc05leHRQYWdlYC5cblx0KiBAcGFyYW0gb3B0aW9ucyAtIFNldCBgY2FuY2VsUmVmZXRjaGAgdG8gYGZhbHNlYCB0byBpZ25vcmUgdGhlIGNhbGwgd2hpbGUgYSBmZXRjaCBpcyBydW5uaW5nLFxuXHQqIGFuZCBgdGhyb3dPbkVycm9yYCB0byBgdHJ1ZWAgdG8gcmVqZWN0IHdoZW4gdGhlIGZldGNoIGZhaWxzLlxuXHQqIEByZXR1cm5zIEEgcHJvbWlzZSB0aGF0IHJlc29sdmVzIHdpdGggdGhlIHJlc3VsdCBhZnRlciB0aGUgbmV4dCBwYWdlIGlzIGZldGNoZWQuIFdpdGhcblx0KiBgY2FuY2VsUmVmZXRjaDogZmFsc2VgLCBhIHJ1bm5pbmcgZmV0Y2ggaXMgcmV1c2VkIGluc3RlYWQsIHNvIHRoZSBuZXh0IHBhZ2UgbWF5IG5vdCBiZSBmZXRjaGVkLlxuXHQqIEBzZWUge0BsaW5rIEluZmluaXRlUXVlcnlPYnNlcnZlciNmZXRjaFByZXZpb3VzUGFnZX1cblx0KiBAZXhhbXBsZVxuXHQqIGBgYHRzXG5cdCogY29uc3QgeyBoYXNOZXh0UGFnZSB9ID0gb2JzZXJ2ZXIuZ2V0Q3VycmVudFJlc3VsdCgpXG5cdCpcblx0KiBpZiAoaGFzTmV4dFBhZ2UpIHtcblx0KiAgIGF3YWl0IG9ic2VydmVyLmZldGNoTmV4dFBhZ2UoKVxuXHQqIH1cblx0KiBgYGBcblx0Ki9cblx0ZmV0Y2hOZXh0UGFnZShvcHRpb25zKSB7XG5cdFx0cmV0dXJuIHRoaXMuZmV0Y2goe1xuXHRcdFx0Li4ub3B0aW9ucyxcblx0XHRcdG1ldGE6IHsgZmV0Y2hNb3JlOiB7IGRpcmVjdGlvbjogXCJmb3J3YXJkXCIgfSB9XG5cdFx0fSk7XG5cdH1cblx0LyoqXG5cdCogRmV0Y2hlcyB0aGUgcHJldmlvdXMgcGFnZSBvZiB0aGUgaW5maW5pdGUgcXVlcnkgYW5kIHJldHVybnMgYSBwcm9taXNlXG5cdCogdGhhdCByZXNvbHZlcyB3aXRoIHRoZSByZXN1bHRpbmcgYEluZmluaXRlUXVlcnlPYnNlcnZlclJlc3VsdGAuIFRoZSBwYWdlXG5cdCogcGFyYW0gdXNlZCBmb3IgdGhlIGZldGNoIGlzIGRldGVybWluZWQgYnkgYGdldFByZXZpb3VzUGFnZVBhcmFtYCwgd2hpY2hcblx0KiByZWNlaXZlcyB0aGUgY3VycmVudCBwYWdlcy9wYWdlIHBhcmFtcyBhbmQgd2hvc2UgcmVzdWx0IGFsc28gZGV0ZXJtaW5lc1xuXHQqIGBoYXNQcmV2aW91c1BhZ2VgLlxuXHQqIEBwYXJhbSBvcHRpb25zIC0gU2V0IGBjYW5jZWxSZWZldGNoYCB0byBgZmFsc2VgIHRvIGlnbm9yZSB0aGUgY2FsbCB3aGlsZSBhIGZldGNoIGlzIHJ1bm5pbmcsXG5cdCogYW5kIGB0aHJvd09uRXJyb3JgIHRvIGB0cnVlYCB0byByZWplY3Qgd2hlbiB0aGUgZmV0Y2ggZmFpbHMuXG5cdCogQHJldHVybnMgQSBwcm9taXNlIHRoYXQgcmVzb2x2ZXMgd2l0aCB0aGUgcmVzdWx0IGFmdGVyIHRoZSBwcmV2aW91cyBwYWdlIGlzIGZldGNoZWQuIFdpdGhcblx0KiBgY2FuY2VsUmVmZXRjaDogZmFsc2VgLCBhIHJ1bm5pbmcgZmV0Y2ggaXMgcmV1c2VkIGluc3RlYWQsIHNvIHRoZSBwcmV2aW91cyBwYWdlIG1heSBub3QgYmUgZmV0Y2hlZC5cblx0KiBAc2VlIHtAbGluayBJbmZpbml0ZVF1ZXJ5T2JzZXJ2ZXIjZmV0Y2hOZXh0UGFnZX1cblx0KiBAZXhhbXBsZVxuXHQqIGBgYHRzXG5cdCogY29uc3QgeyBoYXNQcmV2aW91c1BhZ2UgfSA9IG9ic2VydmVyLmdldEN1cnJlbnRSZXN1bHQoKVxuXHQqXG5cdCogaWYgKGhhc1ByZXZpb3VzUGFnZSkge1xuXHQqICAgYXdhaXQgb2JzZXJ2ZXIuZmV0Y2hQcmV2aW91c1BhZ2UoKVxuXHQqIH1cblx0KiBgYGBcblx0Ki9cblx0ZmV0Y2hQcmV2aW91c1BhZ2Uob3B0aW9ucykge1xuXHRcdHJldHVybiB0aGlzLmZldGNoKHtcblx0XHRcdC4uLm9wdGlvbnMsXG5cdFx0XHRtZXRhOiB7IGZldGNoTW9yZTogeyBkaXJlY3Rpb246IFwiYmFja3dhcmRcIiB9IH1cblx0XHR9KTtcblx0fVxuXHRjcmVhdGVSZXN1bHQocXVlcnksIG9wdGlvbnMpIHtcblx0XHRjb25zdCB7IHN0YXRlIH0gPSBxdWVyeTtcblx0XHRjb25zdCBwYXJlbnRSZXN1bHQgPSBzdXBlci5jcmVhdGVSZXN1bHQocXVlcnksIG9wdGlvbnMpO1xuXHRcdGNvbnN0IHsgaXNGZXRjaGluZywgaXNSZWZldGNoaW5nLCBpc0Vycm9yLCBpc1JlZmV0Y2hFcnJvciB9ID0gcGFyZW50UmVzdWx0O1xuXHRcdGNvbnN0IGZldGNoRGlyZWN0aW9uID0gc3RhdGUuZmV0Y2hNZXRhPy5mZXRjaE1vcmU/LmRpcmVjdGlvbjtcblx0XHRjb25zdCBpc0ZldGNoTmV4dFBhZ2VFcnJvciA9IGlzRXJyb3IgJiYgZmV0Y2hEaXJlY3Rpb24gPT09IFwiZm9yd2FyZFwiO1xuXHRcdGNvbnN0IGlzRmV0Y2hpbmdOZXh0UGFnZSA9IGlzRmV0Y2hpbmcgJiYgZmV0Y2hEaXJlY3Rpb24gPT09IFwiZm9yd2FyZFwiO1xuXHRcdGNvbnN0IGlzRmV0Y2hQcmV2aW91c1BhZ2VFcnJvciA9IGlzRXJyb3IgJiYgZmV0Y2hEaXJlY3Rpb24gPT09IFwiYmFja3dhcmRcIjtcblx0XHRjb25zdCBpc0ZldGNoaW5nUHJldmlvdXNQYWdlID0gaXNGZXRjaGluZyAmJiBmZXRjaERpcmVjdGlvbiA9PT0gXCJiYWNrd2FyZFwiO1xuXHRcdHJldHVybiB7XG5cdFx0XHQuLi5wYXJlbnRSZXN1bHQsXG5cdFx0XHRmZXRjaE5leHRQYWdlOiB0aGlzLmZldGNoTmV4dFBhZ2UsXG5cdFx0XHRmZXRjaFByZXZpb3VzUGFnZTogdGhpcy5mZXRjaFByZXZpb3VzUGFnZSxcblx0XHRcdGhhc05leHRQYWdlOiBoYXNOZXh0UGFnZShvcHRpb25zLCBzdGF0ZS5kYXRhKSxcblx0XHRcdGhhc1ByZXZpb3VzUGFnZTogaGFzUHJldmlvdXNQYWdlKG9wdGlvbnMsIHN0YXRlLmRhdGEpLFxuXHRcdFx0aXNGZXRjaE5leHRQYWdlRXJyb3IsXG5cdFx0XHRpc0ZldGNoaW5nTmV4dFBhZ2UsXG5cdFx0XHRpc0ZldGNoUHJldmlvdXNQYWdlRXJyb3IsXG5cdFx0XHRpc0ZldGNoaW5nUHJldmlvdXNQYWdlLFxuXHRcdFx0aXNSZWZldGNoRXJyb3I6IGlzUmVmZXRjaEVycm9yICYmICFpc0ZldGNoTmV4dFBhZ2VFcnJvciAmJiAhaXNGZXRjaFByZXZpb3VzUGFnZUVycm9yLFxuXHRcdFx0aXNSZWZldGNoaW5nOiBpc1JlZmV0Y2hpbmcgJiYgIWlzRmV0Y2hpbmdOZXh0UGFnZSAmJiAhaXNGZXRjaGluZ1ByZXZpb3VzUGFnZVxuXHRcdH07XG5cdH1cbn07XG5leHBvcnQgeyBJbmZpbml0ZVF1ZXJ5T2JzZXJ2ZXIgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9aW5maW5pdGVRdWVyeU9ic2VydmVyLmpzLm1hcCIsImltcG9ydCB7IG5vdGlmeU1hbmFnZXIgfSBmcm9tIFwiLi9ub3RpZnlNYW5hZ2VyLmpzXCI7XG5pbXBvcnQgeyBjcmVhdGVSZXRyeWVyIH0gZnJvbSBcIi4vcmV0cnllci5qc1wiO1xuaW1wb3J0IHsgUmVtb3ZhYmxlIH0gZnJvbSBcIi4vcmVtb3ZhYmxlLmpzXCI7XG4vLyBzcmMvbXV0YXRpb24udHNcbi8qKlxuKiBSZXByZXNlbnRzIGEgc2luZ2xlIG11dGF0aW9uIGF0dGVtcHQuIEEgYE11dGF0aW9uYCBob2xkcyB0aGUgbXV0YXRpb24nc1xuKiBvcHRpb25zLCBzdGF0ZSAoZGF0YS9lcnJvci9zdGF0dXMpLCBhbmQgdGhlIGBNdXRhdGlvbk9ic2VydmVyYHMgY3VycmVudGx5XG4qIHN1YnNjcmliZWQgdG8gaXQuXG4qXG4qIEluc3RhbmNlcyBhcmUgY3JlYXRlZCBhbmQgbWFuYWdlZCBpbnRlcm5hbGx5IGJ5IGBNdXRhdGlvbkNhY2hlYDsgYXBwbGljYXRpb25cbiogY29kZSB0eXBpY2FsbHkgaW50ZXJhY3RzIHdpdGggbXV0YXRpb25zIGluZGlyZWN0bHkgdGhyb3VnaCBgUXVlcnlDbGllbnRgIG9yXG4qIGEgZnJhbWV3b3JrIGhvb2sgbGlrZSBgdXNlTXV0YXRpb25gLiBEaXJlY3QgYWNjZXNzIHRvIGEgYE11dGF0aW9uYCBpbnN0YW5jZVxuKiBpcyBwb3NzaWJsZSB2aWEgYG11dGF0aW9uQ2FjaGUuZmluZCgpYC9gZ2V0QWxsKClgIGZvciBpbnNwZWN0aW5nIGNhY2hlIHN0YXRlLlxuKiBAZXhhbXBsZVxuKiBgYGB0c1xuKiBjb25zdCBtdXRhdGlvbkNhY2hlID0gcXVlcnlDbGllbnQuZ2V0TXV0YXRpb25DYWNoZSgpXG4qXG4qIGNvbnN0IG11dGF0aW9uID0gbXV0YXRpb25DYWNoZS5maW5kKHsgbXV0YXRpb25LZXk6IFsnYWRkUG9zdCddIH0pXG4qIGBgYFxuKi9cbnZhciBNdXRhdGlvbiA9IGNsYXNzIGV4dGVuZHMgUmVtb3ZhYmxlIHtcblx0I2NsaWVudDtcblx0I29ic2VydmVycztcblx0I211dGF0aW9uQ2FjaGU7XG5cdCNyZXRyeWVyO1xuXHRjb25zdHJ1Y3Rvcihjb25maWcpIHtcblx0XHRzdXBlcigpO1xuXHRcdHRoaXMuI2NsaWVudCA9IGNvbmZpZy5jbGllbnQ7XG5cdFx0dGhpcy5tdXRhdGlvbklkID0gY29uZmlnLm11dGF0aW9uSWQ7XG5cdFx0dGhpcy4jbXV0YXRpb25DYWNoZSA9IGNvbmZpZy5tdXRhdGlvbkNhY2hlO1xuXHRcdHRoaXMuI29ic2VydmVycyA9IFtdO1xuXHRcdHRoaXMuc3RhdGUgPSBjb25maWcuc3RhdGUgfHwgZ2V0RGVmYXVsdFN0YXRlKCk7XG5cdFx0dGhpcy5zZXRPcHRpb25zKGNvbmZpZy5vcHRpb25zKTtcblx0XHR0aGlzLnNjaGVkdWxlR2MoKTtcblx0fVxuXHQvKipcblx0KiBSZXBsYWNlcyB0aGUgbXV0YXRpb24ncyBvcHRpb25zIGFuZCBhcHBsaWVzIHRoZWlyIGBnY1RpbWVgLlxuXHQqIEBpbnRlcm5hbFxuXHQqIEBwYXJhbSBvcHRpb25zIC0gVGhlIG5ldyBtdXRhdGlvbiBvcHRpb25zLlxuXHQqL1xuXHRzZXRPcHRpb25zKG9wdGlvbnMpIHtcblx0XHR0aGlzLm9wdGlvbnMgPSBvcHRpb25zO1xuXHRcdHRoaXMudXBkYXRlR2NUaW1lKHRoaXMub3B0aW9ucy5nY1RpbWUpO1xuXHR9XG5cdC8qKlxuXHQqIFRoZSBgbWV0YWAgb2JqZWN0IHBhc3NlZCBpbiB0aGUgbXV0YXRpb24ncyBvcHRpb25zLCBpZiBhbnkuXG5cdCogQHJldHVybnMgVGhlIG11dGF0aW9uJ3MgYG1ldGFgLCBvciBgdW5kZWZpbmVkYCBpZiBub25lIHdhcyBzZXQuXG5cdCovXG5cdGdldCBtZXRhKCkge1xuXHRcdHJldHVybiB0aGlzLm9wdGlvbnMubWV0YTtcblx0fVxuXHQvKipcblx0KiBTdWJzY3JpYmVzIGFuIG9ic2VydmVyIHRvIHRoZSBtdXRhdGlvbiBhbmQgc3RvcHMgaXRzIGdhcmJhZ2UgY29sbGVjdGlvbi5cblx0KiBAaW50ZXJuYWxcblx0KiBAcGFyYW0gb2JzZXJ2ZXIgLSBUaGUgb2JzZXJ2ZXIgdG8gYWRkLiBBZGRpbmcgYW4gb2JzZXJ2ZXIgdGhhdCBpcyBhbHJlYWR5IHN1YnNjcmliZWQgZG9lc1xuXHQqIG5vdGhpbmcuXG5cdCovXG5cdGFkZE9ic2VydmVyKG9ic2VydmVyKSB7XG5cdFx0aWYgKCF0aGlzLiNvYnNlcnZlcnMuaW5jbHVkZXMob2JzZXJ2ZXIpKSB7XG5cdFx0XHR0aGlzLiNvYnNlcnZlcnMucHVzaChvYnNlcnZlcik7XG5cdFx0XHR0aGlzLmNsZWFyR2NUaW1lb3V0KCk7XG5cdFx0XHR0aGlzLiNtdXRhdGlvbkNhY2hlLm5vdGlmeSh7XG5cdFx0XHRcdHR5cGU6IFwib2JzZXJ2ZXJBZGRlZFwiLFxuXHRcdFx0XHRtdXRhdGlvbjogdGhpcyxcblx0XHRcdFx0b2JzZXJ2ZXJcblx0XHRcdH0pO1xuXHRcdH1cblx0fVxuXHQvKipcblx0KiBVbnN1YnNjcmliZXMgYW4gb2JzZXJ2ZXIgZnJvbSB0aGUgbXV0YXRpb24uXG5cdCogQGludGVybmFsXG5cdCogQHBhcmFtIG9ic2VydmVyIC0gVGhlIG9ic2VydmVyIHRvIHJlbW92ZS4gR2FyYmFnZSBjb2xsZWN0aW9uIGlzIHNjaGVkdWxlZCBhZnRlcndhcmRzLlxuXHQqL1xuXHRyZW1vdmVPYnNlcnZlcihvYnNlcnZlcikge1xuXHRcdHRoaXMuI29ic2VydmVycyA9IHRoaXMuI29ic2VydmVycy5maWx0ZXIoKHgpID0+IHggIT09IG9ic2VydmVyKTtcblx0XHR0aGlzLnNjaGVkdWxlR2MoKTtcblx0XHR0aGlzLiNtdXRhdGlvbkNhY2hlLm5vdGlmeSh7XG5cdFx0XHR0eXBlOiBcIm9ic2VydmVyUmVtb3ZlZFwiLFxuXHRcdFx0bXV0YXRpb246IHRoaXMsXG5cdFx0XHRvYnNlcnZlclxuXHRcdH0pO1xuXHR9XG5cdG9wdGlvbmFsUmVtb3ZlKCkge1xuXHRcdGlmICghdGhpcy4jb2JzZXJ2ZXJzLmxlbmd0aCkge1xuXHRcdFx0aWYgKHRoaXMuc3RhdGUuc3RhdHVzID09PSBcInBlbmRpbmdcIikgdGhpcy5zY2hlZHVsZUdjKCk7XG5cdFx0XHRlbHNlIHRoaXMuI211dGF0aW9uQ2FjaGUucmVtb3ZlKHRoaXMpO1xuXHRcdH1cblx0fVxuXHQvKipcblx0KiBSZXN1bWVzIGEgbXV0YXRpb24gdGhhdCBpcyBjdXJyZW50bHkgcGF1c2VkIG9yIHdhcyByZXN0b3JlZCBmcm9tIGFcblx0KiBkZWh5ZHJhdGVkLCBzdGlsbC1gcGVuZGluZ2Agc3RhdGUuXG5cdCpcblx0KiAtIElmIHRoaXMgbXV0YXRpb24gaGFzIGFuIGFjdGl2ZSByZXRyeWVyIChpdCBwYXVzZWQgbWlkLWF0dGVtcHQsIGUuZy4gZHVlXG5cdCogICB0byB0aGUgbmV0d29yayBtb2RlIG9yIHNjb3BlLWJhc2VkIHF1ZXVpbmcpLCBpdHMgcmV0cnllciBpcyByZXN1bWVkLlxuXHQqIC0gT3RoZXJ3aXNlLCBpZiB0aGUgbXV0YXRpb24ncyBzdGF0dXMgaXMgc3RpbGwgYHBlbmRpbmdgIChlLmcuIGl0IHdhc1xuXHQqICAgZGVoeWRyYXRlZCB3aGlsZSBhbiBhdHRlbXB0IHdhcyBpbiBmbGlnaHQgYW5kIG5ldmVyIGdvdCBhIHJldHJ5ZXIgaW5cblx0KiAgIHRoaXMgaW5zdGFuY2UpLCBgZXhlY3V0ZWAgaXMgY2FsbGVkIGFnYWluIHdpdGggdGhlIGxhc3Qga25vd24gdmFyaWFibGVzLlxuXHQqIC0gT3RoZXJ3aXNlIHRoZSBtdXRhdGlvbiBoYXMgYWxyZWFkeSBzZXR0bGVkIGFuZCB0aGlzIHJlc29sdmVzIGltbWVkaWF0ZWx5XG5cdCogICB3aXRob3V0IHJ1bm5pbmcgYW55dGhpbmcgYWdhaW4uXG5cdCogQHJldHVybnMgQSBwcm9taXNlIHRoYXQgc2V0dGxlcyB3aXRoIHRoZSByZXN1bWVkIG11dGF0aW9uOiBpdCByZWplY3RzIGlmIHRoZSBtdXRhdGlvbiBmYWlscy5cblx0KiBJdCByZXNvbHZlcyBpbW1lZGlhdGVseSBpZiB0aGUgbXV0YXRpb24gaGFzIGFscmVhZHkgc2V0dGxlZC5cblx0KiBAc2VlIHtAbGluayBNdXRhdGlvbiNleGVjdXRlfVxuXHQqIEBleGFtcGxlXG5cdCogYGBgdHNcblx0KiAvLyB0eXBpY2FsbHkgZHJpdmVuIGJ5IHJlY29ubmVjdCBoYW5kbGluZywgZS5nLiBxdWVyeUNsaWVudC5yZXN1bWVQYXVzZWRNdXRhdGlvbnMoKVxuXHQqIGNvbnN0IG11dGF0aW9uID0gbXV0YXRpb25DYWNoZS5maW5kKHsgbXV0YXRpb25LZXk6IFsnYWRkUG9zdCddIH0pXG5cdCogYXdhaXQgbXV0YXRpb24/LmNvbnRpbnVlKClcblx0KiBgYGBcblx0Ki9cblx0Y29udGludWUoKSB7XG5cdFx0cmV0dXJuIHRoaXMuI3JldHJ5ZXI/LmNvbnRpbnVlKCkgPz8gKHRoaXMuc3RhdGUuc3RhdHVzID09PSBcInBlbmRpbmdcIiA/IHRoaXMuZXhlY3V0ZSh0aGlzLnN0YXRlLnZhcmlhYmxlcykgOiBQcm9taXNlLnJlc29sdmUoKSk7XG5cdH1cblx0LyoqXG5cdCogUnVucyB0aGUgbXV0YXRpb24gZnVuY3Rpb24gZm9yIHRoZSBnaXZlbiB2YXJpYWJsZXMgdGhyb3VnaCBhIHJldHJ5ZXIsIGFuZFxuXHQqIGRyaXZlcyB0aGUgbXV0YXRpb24ncyBzdGF0ZSBhbmQgbGlmZWN5Y2xlIGNhbGxiYWNrcyB0aHJvdWdoIHRvIHNldHRsZW1lbnQuXG5cdCpcblx0KiBJZiB0aGlzIG11dGF0aW9uJ3Mgc3RhdGUgaXMgYWxyZWFkeSBgcGVuZGluZ2Agd2hlbiBgZXhlY3V0ZWAgaXMgY2FsbGVkXG5cdCogKGkuZS4gaXQgd2FzIHJlc3RvcmVkLCBzdGlsbCBpbi1mbGlnaHQsIGZyb20gYSBkZWh5ZHJhdGVkIHN0YXRlKSwgdGhlXG5cdCogYG9uTXV0YXRlYCBzdGVwIGlzIHNraXBwZWQgYW5kIGEgYGNvbnRpbnVlYCBhY3Rpb24gaXMgZGlzcGF0Y2hlZCB0b1xuXHQqIHVucGF1c2UgaXQ7IG90aGVyd2lzZSBhIGBwZW5kaW5nYCBhY3Rpb24gaXMgZGlzcGF0Y2hlZCBmaXJzdCwgdGhlbiB0aGVcblx0KiBtdXRhdGlvbiBjYWNoZSdzIGBvbk11dGF0ZWAgYW5kIHRoZSBtdXRhdGlvbidzIG93biBgb25NdXRhdGVgIG9wdGlvbiBhcmVcblx0KiBhd2FpdGVkIGluIHRoYXQgb3JkZXIsIGFuZCB0aGUgcmVzdWx0aW5nIGNvbnRleHQgaXMgc3RvcmVkLlxuXHQqXG5cdCogVGhlIG11dGF0aW9uIGZ1bmN0aW9uIGlzIHRoZW4gcnVuIChzdWJqZWN0IHRvIGByZXRyeWAvYHJldHJ5RGVsYXlgL1xuXHQqIGBuZXR3b3JrTW9kZWAsIGFuZCB0byB0aGUgbXV0YXRpb24gY2FjaGUncyBzY29wZS1iYXNlZCBzZXJpYWxpemF0aW9uKS5cblx0KiBPbiBzdWNjZXNzLCB0aGUgY2FjaGUncyBgb25TdWNjZXNzYC9gb25TZXR0bGVkYCBjYWxsYmFja3MgcnVuIGJlZm9yZSB0aGVcblx0KiBtdXRhdGlvbidzIG93biBgb25TdWNjZXNzYC9gb25TZXR0bGVkYCBvcHRpb25zLCBhIGBzdWNjZXNzYCBhY3Rpb24gaXNcblx0KiBkaXNwYXRjaGVkLCBhbmQgdGhlIHJlc29sdmVkIGRhdGEgaXMgcmV0dXJuZWQuIE9uIGZhaWx1cmUsIHRoZSBzYW1lXG5cdCogY2FjaGUtdGhlbi1vcHRpb24gb3JkZXJpbmcgaXMgdXNlZCBmb3IgYG9uRXJyb3JgL2BvblNldHRsZWRgLCBidXQgZWFjaCBvZlxuXHQqIHRob3NlIGZvdXIgY2FsbGJhY2tzIGlzIGluZGl2aWR1YWxseSBjYXVnaHQgc28gdGhhdCBhIHRocm93aW5nIGNhbGxiYWNrXG5cdCogY2Fubm90IG1hc2sgdGhlIG9yaWdpbmFsIGVycm9yOyBhbiBgZXJyb3JgIGFjdGlvbiBpcyB0aGVuIGRpc3BhdGNoZWQgYW5kXG5cdCogdGhlIG9yaWdpbmFsIGVycm9yIGlzIHJlLXRocm93bi5cblx0KiBAcGFyYW0gdmFyaWFibGVzIC0gVGhlIHZhcmlhYmxlcyBwYXNzZWQgdG8gdGhlIGBtdXRhdGlvbkZuYC5cblx0KiBAcmV0dXJucyBBIHByb21pc2UgdGhhdCByZXNvbHZlcyB3aXRoIHRoZSBtdXRhdGlvbidzIGRhdGEsIG9yIHJlamVjdHMgd2l0aCBpdHMgZXJyb3IuXG5cdCogQHNlZSB7QGxpbmsgTXV0YXRpb24jY29udGludWV9XG5cdCogQGV4YW1wbGVcblx0KiBgYGB0c1xuXHQqIC8vIENhbGxlZCBpbnRlcm5hbGx5IGJ5IGBNdXRhdGlvbk9ic2VydmVyLm11dGF0ZWAgYW5kIGBNdXRhdGlvbi5jb250aW51ZWAg4oCUXG5cdCogLy8gYXBwbGljYXRpb25zIG5vcm1hbGx5IHRyaWdnZXIgbXV0YXRpb25zIHRocm91Z2ggdGhvc2UsIG5vdCB0aGlzIG1ldGhvZC5cblx0KiBjb25zdCBkYXRhID0gYXdhaXQgbXV0YXRpb24uZXhlY3V0ZSh2YXJpYWJsZXMpXG5cdCogYGBgXG5cdCovXG5cdGFzeW5jIGV4ZWN1dGUodmFyaWFibGVzKSB7XG5cdFx0Y29uc3Qgb25Db250aW51ZSA9ICgpID0+IHtcblx0XHRcdHRoaXMuI2Rpc3BhdGNoKHsgdHlwZTogXCJjb250aW51ZVwiIH0pO1xuXHRcdH07XG5cdFx0Y29uc3QgbXV0YXRpb25GbkNvbnRleHQgPSB7XG5cdFx0XHRjbGllbnQ6IHRoaXMuI2NsaWVudCxcblx0XHRcdG1ldGE6IHRoaXMub3B0aW9ucy5tZXRhLFxuXHRcdFx0bXV0YXRpb25LZXk6IHRoaXMub3B0aW9ucy5tdXRhdGlvbktleVxuXHRcdH07XG5cdFx0Y29uc3QgcmV0cnllciA9IHRoaXMuI3JldHJ5ZXIgPSBjcmVhdGVSZXRyeWVyKHtcblx0XHRcdGZuOiAoKSA9PiB7XG5cdFx0XHRcdGlmICghdGhpcy5vcHRpb25zLm11dGF0aW9uRm4pIHJldHVybiBQcm9taXNlLnJlamVjdCgvKiBAX19QVVJFX18gKi8gbmV3IEVycm9yKFwiTm8gbXV0YXRpb25GbiBmb3VuZFwiKSk7XG5cdFx0XHRcdHJldHVybiB0aGlzLm9wdGlvbnMubXV0YXRpb25Gbih2YXJpYWJsZXMsIG11dGF0aW9uRm5Db250ZXh0KTtcblx0XHRcdH0sXG5cdFx0XHRvbkZhaWw6IChmYWlsdXJlQ291bnQsIGVycm9yKSA9PiB7XG5cdFx0XHRcdHRoaXMuI2Rpc3BhdGNoKHtcblx0XHRcdFx0XHR0eXBlOiBcImZhaWxlZFwiLFxuXHRcdFx0XHRcdGZhaWx1cmVDb3VudCxcblx0XHRcdFx0XHRlcnJvclxuXHRcdFx0XHR9KTtcblx0XHRcdH0sXG5cdFx0XHRvblBhdXNlOiAoKSA9PiB7XG5cdFx0XHRcdHRoaXMuI2Rpc3BhdGNoKHsgdHlwZTogXCJwYXVzZVwiIH0pO1xuXHRcdFx0fSxcblx0XHRcdG9uQ29udGludWUsXG5cdFx0XHRyZXRyeTogdGhpcy5vcHRpb25zLnJldHJ5ID8/IDAsXG5cdFx0XHRyZXRyeURlbGF5OiB0aGlzLm9wdGlvbnMucmV0cnlEZWxheSxcblx0XHRcdG5ldHdvcmtNb2RlOiB0aGlzLm9wdGlvbnMubmV0d29ya01vZGUsXG5cdFx0XHRjYW5SdW46ICgpID0+IHRoaXMuI211dGF0aW9uQ2FjaGUuY2FuUnVuKHRoaXMpXG5cdFx0fSk7XG5cdFx0Y29uc3QgcmVzdG9yZWQgPSB0aGlzLnN0YXRlLnN0YXR1cyA9PT0gXCJwZW5kaW5nXCI7XG5cdFx0Y29uc3QgaXNQYXVzZWQgPSAhcmV0cnllci5jYW5TdGFydCgpO1xuXHRcdHRyeSB7XG5cdFx0XHRpZiAocmVzdG9yZWQpIG9uQ29udGludWUoKTtcblx0XHRcdGVsc2Uge1xuXHRcdFx0XHR0aGlzLiNkaXNwYXRjaCh7XG5cdFx0XHRcdFx0dHlwZTogXCJwZW5kaW5nXCIsXG5cdFx0XHRcdFx0dmFyaWFibGVzLFxuXHRcdFx0XHRcdGlzUGF1c2VkXG5cdFx0XHRcdH0pO1xuXHRcdFx0XHRpZiAodGhpcy4jbXV0YXRpb25DYWNoZS5jb25maWcub25NdXRhdGUpIGF3YWl0IHRoaXMuI211dGF0aW9uQ2FjaGUuY29uZmlnLm9uTXV0YXRlKHZhcmlhYmxlcywgdGhpcywgbXV0YXRpb25GbkNvbnRleHQpO1xuXHRcdFx0XHRjb25zdCBjb250ZXh0ID0gYXdhaXQgdGhpcy5vcHRpb25zLm9uTXV0YXRlPy4odmFyaWFibGVzLCBtdXRhdGlvbkZuQ29udGV4dCk7XG5cdFx0XHRcdGlmIChjb250ZXh0ICE9PSB0aGlzLnN0YXRlLmNvbnRleHQpIHRoaXMuI2Rpc3BhdGNoKHtcblx0XHRcdFx0XHR0eXBlOiBcInBlbmRpbmdcIixcblx0XHRcdFx0XHRjb250ZXh0LFxuXHRcdFx0XHRcdHZhcmlhYmxlcyxcblx0XHRcdFx0XHRpc1BhdXNlZFxuXHRcdFx0XHR9KTtcblx0XHRcdH1cblx0XHRcdGlmICh0aGlzLnN0YXRlLmlzUGF1c2VkICYmIHJldHJ5ZXIuY2FuU3RhcnQoKSkgb25Db250aW51ZSgpO1xuXHRcdFx0Y29uc3QgZGF0YSA9IGF3YWl0IHJldHJ5ZXIuc3RhcnQoKTtcblx0XHRcdGF3YWl0IHRoaXMuI211dGF0aW9uQ2FjaGUuY29uZmlnLm9uU3VjY2Vzcz8uKGRhdGEsIHZhcmlhYmxlcywgdGhpcy5zdGF0ZS5jb250ZXh0LCB0aGlzLCBtdXRhdGlvbkZuQ29udGV4dCk7XG5cdFx0XHRhd2FpdCB0aGlzLm9wdGlvbnMub25TdWNjZXNzPy4oZGF0YSwgdmFyaWFibGVzLCB0aGlzLnN0YXRlLmNvbnRleHQsIG11dGF0aW9uRm5Db250ZXh0KTtcblx0XHRcdGF3YWl0IHRoaXMuI211dGF0aW9uQ2FjaGUuY29uZmlnLm9uU2V0dGxlZD8uKGRhdGEsIG51bGwsIHRoaXMuc3RhdGUudmFyaWFibGVzLCB0aGlzLnN0YXRlLmNvbnRleHQsIHRoaXMsIG11dGF0aW9uRm5Db250ZXh0KTtcblx0XHRcdGF3YWl0IHRoaXMub3B0aW9ucy5vblNldHRsZWQ/LihkYXRhLCBudWxsLCB2YXJpYWJsZXMsIHRoaXMuc3RhdGUuY29udGV4dCwgbXV0YXRpb25GbkNvbnRleHQpO1xuXHRcdFx0dGhpcy4jZGlzcGF0Y2goe1xuXHRcdFx0XHR0eXBlOiBcInN1Y2Nlc3NcIixcblx0XHRcdFx0ZGF0YVxuXHRcdFx0fSk7XG5cdFx0XHRyZXR1cm4gZGF0YTtcblx0XHR9IGNhdGNoIChlcnJvcikge1xuXHRcdFx0dHJ5IHtcblx0XHRcdFx0YXdhaXQgdGhpcy4jbXV0YXRpb25DYWNoZS5jb25maWcub25FcnJvcj8uKGVycm9yLCB2YXJpYWJsZXMsIHRoaXMuc3RhdGUuY29udGV4dCwgdGhpcywgbXV0YXRpb25GbkNvbnRleHQpO1xuXHRcdFx0fSBjYXRjaCAoZSkge1xuXHRcdFx0XHRQcm9taXNlLnJlamVjdChlKTtcblx0XHRcdH1cblx0XHRcdHRyeSB7XG5cdFx0XHRcdGF3YWl0IHRoaXMub3B0aW9ucy5vbkVycm9yPy4oZXJyb3IsIHZhcmlhYmxlcywgdGhpcy5zdGF0ZS5jb250ZXh0LCBtdXRhdGlvbkZuQ29udGV4dCk7XG5cdFx0XHR9IGNhdGNoIChlKSB7XG5cdFx0XHRcdFByb21pc2UucmVqZWN0KGUpO1xuXHRcdFx0fVxuXHRcdFx0dHJ5IHtcblx0XHRcdFx0YXdhaXQgdGhpcy4jbXV0YXRpb25DYWNoZS5jb25maWcub25TZXR0bGVkPy4odm9pZCAwLCBlcnJvciwgdGhpcy5zdGF0ZS52YXJpYWJsZXMsIHRoaXMuc3RhdGUuY29udGV4dCwgdGhpcywgbXV0YXRpb25GbkNvbnRleHQpO1xuXHRcdFx0fSBjYXRjaCAoZSkge1xuXHRcdFx0XHRQcm9taXNlLnJlamVjdChlKTtcblx0XHRcdH1cblx0XHRcdHRyeSB7XG5cdFx0XHRcdGF3YWl0IHRoaXMub3B0aW9ucy5vblNldHRsZWQ/Lih2b2lkIDAsIGVycm9yLCB2YXJpYWJsZXMsIHRoaXMuc3RhdGUuY29udGV4dCwgbXV0YXRpb25GbkNvbnRleHQpO1xuXHRcdFx0fSBjYXRjaCAoZSkge1xuXHRcdFx0XHRQcm9taXNlLnJlamVjdChlKTtcblx0XHRcdH1cblx0XHRcdHRoaXMuI2Rpc3BhdGNoKHtcblx0XHRcdFx0dHlwZTogXCJlcnJvclwiLFxuXHRcdFx0XHRlcnJvclxuXHRcdFx0fSk7XG5cdFx0XHR0aHJvdyBlcnJvcjtcblx0XHR9IGZpbmFsbHkge1xuXHRcdFx0aWYgKHRoaXMuI3JldHJ5ZXIgPT09IHJldHJ5ZXIpIHRoaXMuI3JldHJ5ZXIgPSB2b2lkIDA7XG5cdFx0XHR0aGlzLiNtdXRhdGlvbkNhY2hlLnJ1bk5leHQodGhpcyk7XG5cdFx0fVxuXHR9XG5cdCNkaXNwYXRjaChhY3Rpb24pIHtcblx0XHRjb25zdCByZWR1Y2VyID0gKHN0YXRlKSA9PiB7XG5cdFx0XHRzd2l0Y2ggKGFjdGlvbi50eXBlKSB7XG5cdFx0XHRcdGNhc2UgXCJmYWlsZWRcIjogcmV0dXJuIHtcblx0XHRcdFx0XHQuLi5zdGF0ZSxcblx0XHRcdFx0XHRmYWlsdXJlQ291bnQ6IGFjdGlvbi5mYWlsdXJlQ291bnQsXG5cdFx0XHRcdFx0ZmFpbHVyZVJlYXNvbjogYWN0aW9uLmVycm9yXG5cdFx0XHRcdH07XG5cdFx0XHRcdGNhc2UgXCJwYXVzZVwiOiByZXR1cm4ge1xuXHRcdFx0XHRcdC4uLnN0YXRlLFxuXHRcdFx0XHRcdGlzUGF1c2VkOiB0cnVlXG5cdFx0XHRcdH07XG5cdFx0XHRcdGNhc2UgXCJjb250aW51ZVwiOiByZXR1cm4ge1xuXHRcdFx0XHRcdC4uLnN0YXRlLFxuXHRcdFx0XHRcdGlzUGF1c2VkOiBmYWxzZVxuXHRcdFx0XHR9O1xuXHRcdFx0XHRjYXNlIFwicGVuZGluZ1wiOiByZXR1cm4ge1xuXHRcdFx0XHRcdC4uLnN0YXRlLFxuXHRcdFx0XHRcdGNvbnRleHQ6IGFjdGlvbi5jb250ZXh0LFxuXHRcdFx0XHRcdGRhdGE6IHZvaWQgMCxcblx0XHRcdFx0XHRmYWlsdXJlQ291bnQ6IDAsXG5cdFx0XHRcdFx0ZmFpbHVyZVJlYXNvbjogbnVsbCxcblx0XHRcdFx0XHRlcnJvcjogbnVsbCxcblx0XHRcdFx0XHRpc1BhdXNlZDogYWN0aW9uLmlzUGF1c2VkLFxuXHRcdFx0XHRcdHN0YXR1czogXCJwZW5kaW5nXCIsXG5cdFx0XHRcdFx0dmFyaWFibGVzOiBhY3Rpb24udmFyaWFibGVzLFxuXHRcdFx0XHRcdHN1Ym1pdHRlZEF0OiBEYXRlLm5vdygpXG5cdFx0XHRcdH07XG5cdFx0XHRcdGNhc2UgXCJzdWNjZXNzXCI6IHJldHVybiB7XG5cdFx0XHRcdFx0Li4uc3RhdGUsXG5cdFx0XHRcdFx0ZGF0YTogYWN0aW9uLmRhdGEsXG5cdFx0XHRcdFx0ZmFpbHVyZUNvdW50OiAwLFxuXHRcdFx0XHRcdGZhaWx1cmVSZWFzb246IG51bGwsXG5cdFx0XHRcdFx0ZXJyb3I6IG51bGwsXG5cdFx0XHRcdFx0c3RhdHVzOiBcInN1Y2Nlc3NcIixcblx0XHRcdFx0XHRpc1BhdXNlZDogZmFsc2Vcblx0XHRcdFx0fTtcblx0XHRcdFx0Y2FzZSBcImVycm9yXCI6IHJldHVybiB7XG5cdFx0XHRcdFx0Li4uc3RhdGUsXG5cdFx0XHRcdFx0ZGF0YTogdm9pZCAwLFxuXHRcdFx0XHRcdGVycm9yOiBhY3Rpb24uZXJyb3IsXG5cdFx0XHRcdFx0ZmFpbHVyZUNvdW50OiBzdGF0ZS5mYWlsdXJlQ291bnQgKyAxLFxuXHRcdFx0XHRcdGZhaWx1cmVSZWFzb246IGFjdGlvbi5lcnJvcixcblx0XHRcdFx0XHRpc1BhdXNlZDogZmFsc2UsXG5cdFx0XHRcdFx0c3RhdHVzOiBcImVycm9yXCJcblx0XHRcdFx0fTtcblx0XHRcdH1cblx0XHR9O1xuXHRcdHRoaXMuc3RhdGUgPSByZWR1Y2VyKHRoaXMuc3RhdGUpO1xuXHRcdG5vdGlmeU1hbmFnZXIuYmF0Y2goKCkgPT4ge1xuXHRcdFx0dGhpcy4jb2JzZXJ2ZXJzLmZvckVhY2goKG9ic2VydmVyKSA9PiB7XG5cdFx0XHRcdG9ic2VydmVyLm9uTXV0YXRpb25VcGRhdGUoYWN0aW9uKTtcblx0XHRcdH0pO1xuXHRcdFx0dGhpcy4jbXV0YXRpb25DYWNoZS5ub3RpZnkoe1xuXHRcdFx0XHRtdXRhdGlvbjogdGhpcyxcblx0XHRcdFx0dHlwZTogXCJ1cGRhdGVkXCIsXG5cdFx0XHRcdGFjdGlvblxuXHRcdFx0fSk7XG5cdFx0fSk7XG5cdH1cbn07XG4vKipcbiogUmV0dXJucyB0aGUgaW5pdGlhbCBzdGF0ZSBvZiBhIG11dGF0aW9uOiBgJ2lkbGUnYCwgd2l0aCBubyBkYXRhLCBlcnJvciwgb3IgdmFyaWFibGVzLlxuKiBAcmV0dXJucyBUaGUgaW5pdGlhbCBtdXRhdGlvbiBzdGF0ZS5cbiovXG5mdW5jdGlvbiBnZXREZWZhdWx0U3RhdGUoKSB7XG5cdHJldHVybiB7XG5cdFx0Y29udGV4dDogdm9pZCAwLFxuXHRcdGRhdGE6IHZvaWQgMCxcblx0XHRlcnJvcjogbnVsbCxcblx0XHRmYWlsdXJlQ291bnQ6IDAsXG5cdFx0ZmFpbHVyZVJlYXNvbjogbnVsbCxcblx0XHRpc1BhdXNlZDogZmFsc2UsXG5cdFx0c3RhdHVzOiBcImlkbGVcIixcblx0XHR2YXJpYWJsZXM6IHZvaWQgMCxcblx0XHRzdWJtaXR0ZWRBdDogMFxuXHR9O1xufVxuZXhwb3J0IHsgTXV0YXRpb24sIGdldERlZmF1bHRTdGF0ZSB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1tdXRhdGlvbi5qcy5tYXAiLCJpbXBvcnQgeyBtYXRjaE11dGF0aW9uLCBub29wIH0gZnJvbSBcIi4vdXRpbHMuanNcIjtcbmltcG9ydCB7IFN1YnNjcmliYWJsZSB9IGZyb20gXCIuL3N1YnNjcmliYWJsZS5qc1wiO1xuaW1wb3J0IHsgbm90aWZ5TWFuYWdlciB9IGZyb20gXCIuL25vdGlmeU1hbmFnZXIuanNcIjtcbmltcG9ydCB7IE11dGF0aW9uIH0gZnJvbSBcIi4vbXV0YXRpb24uanNcIjtcbi8vIHNyYy9tdXRhdGlvbkNhY2hlLnRzXG4vKipcbiogVGhlIGBNdXRhdGlvbkNhY2hlYCBpcyB0aGUgc3RvcmFnZSBmb3IgbXV0YXRpb25zLlxuKlxuKiBOb3JtYWxseSwgeW91IHdpbGwgbm90IGludGVyYWN0IHdpdGggdGhlIGBNdXRhdGlvbkNhY2hlYCBkaXJlY3RseSBhbmQgaW5zdGVhZCB1c2UgYVxuKiBgUXVlcnlDbGllbnRgLiBZb3UgY2FuIHN1YnNjcmliZSB0byBpdCAoaW5oZXJpdGVkIGZyb20gYFN1YnNjcmliYWJsZWApIHRvIGJlIGluZm9ybWVkIG9mXG4qIHNhZmUva25vd24gdXBkYXRlcyB0byB0aGUgY2FjaGUsIHN1Y2ggYXMgbXV0YXRpb25zIGJlaW5nIGFkZGVkLCByZW1vdmVkLCBvciB1cGRhdGVkLlxuKiBAZXhhbXBsZVxuKiBgYGB0c1xuKiBjb25zdCB1bnN1YnNjcmliZSA9IG11dGF0aW9uQ2FjaGUuc3Vic2NyaWJlKChldmVudCkgPT4ge1xuKiAgIGNvbnNvbGUubG9nKGV2ZW50LnR5cGUsIGV2ZW50Lm11dGF0aW9uKVxuKiB9KVxuKiBgYGBcbiovXG52YXIgTXV0YXRpb25DYWNoZSA9IGNsYXNzIGV4dGVuZHMgU3Vic2NyaWJhYmxlIHtcblx0I211dGF0aW9ucztcblx0I3Njb3Blcztcblx0I211dGF0aW9uSWQ7XG5cdGNvbnN0cnVjdG9yKGNvbmZpZyA9IHt9KSB7XG5cdFx0c3VwZXIoKTtcblx0XHR0aGlzLmNvbmZpZyA9IGNvbmZpZztcblx0XHR0aGlzLiNtdXRhdGlvbnMgPSAvKiBAX19QVVJFX18gKi8gbmV3IFNldCgpO1xuXHRcdHRoaXMuI3Njb3BlcyA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgTWFwKCk7XG5cdFx0dGhpcy4jbXV0YXRpb25JZCA9IDA7XG5cdH1cblx0LyoqXG5cdCogQ3JlYXRlcyBhIG11dGF0aW9uIGFuZCBhZGRzIGl0IHRvIHRoZSBjYWNoZS5cblx0KiBAaW50ZXJuYWxcblx0KiBAcGFyYW0gY2xpZW50IC0gVGhlIGNsaWVudCB0aGUgbXV0YXRpb24gYmVsb25ncyB0bywgdXNlZCB0byBkZWZhdWx0IGl0cyBvcHRpb25zLlxuXHQqIEBwYXJhbSBvcHRpb25zIC0gVGhlIG11dGF0aW9uIG9wdGlvbnMuIFRoZXkgYXJlIGRlZmF1bHRlZCB3aXRoIHtAbGlua1xuXHQqIFF1ZXJ5Q2xpZW50I2RlZmF1bHRNdXRhdGlvbk9wdGlvbnN9LlxuXHQqIEBwYXJhbSBzdGF0ZSAtIFRoZSBpbml0aWFsIHN0YXRlIG9mIHRoZSBtdXRhdGlvbiwgZS5nLiB3aGVuIHJlc3RvcmluZyBhIGRlaHlkcmF0ZWQgbXV0YXRpb24uXG5cdCogQHJldHVybnMgVGhlIG5ldyBtdXRhdGlvbiwgYWxyZWFkeSBhZGRlZCB0byB0aGUgY2FjaGUuXG5cdCovXG5cdGJ1aWxkKGNsaWVudCwgb3B0aW9ucywgc3RhdGUpIHtcblx0XHRjb25zdCBtdXRhdGlvbiA9IG5ldyBNdXRhdGlvbih7XG5cdFx0XHRjbGllbnQsXG5cdFx0XHRtdXRhdGlvbkNhY2hlOiB0aGlzLFxuXHRcdFx0bXV0YXRpb25JZDogKyt0aGlzLiNtdXRhdGlvbklkLFxuXHRcdFx0b3B0aW9uczogY2xpZW50LmRlZmF1bHRNdXRhdGlvbk9wdGlvbnMob3B0aW9ucyksXG5cdFx0XHRzdGF0ZVxuXHRcdH0pO1xuXHRcdHRoaXMuYWRkKG11dGF0aW9uKTtcblx0XHRyZXR1cm4gbXV0YXRpb247XG5cdH1cblx0LyoqXG5cdCogQWRkcyBhIG11dGF0aW9uIHRvIHRoZSBjYWNoZS5cblx0KiBAaW50ZXJuYWxcblx0KiBAcGFyYW0gbXV0YXRpb24gLSBUaGUgbXV0YXRpb24gdG8gYWRkLiBJZiBpdCBoYXMgYSBgc2NvcGVgLCBpdCBpcyBxdWV1ZWQgaW4gdGhhdCBzY29wZS5cblx0Ki9cblx0YWRkKG11dGF0aW9uKSB7XG5cdFx0dGhpcy4jbXV0YXRpb25zLmFkZChtdXRhdGlvbik7XG5cdFx0Y29uc3Qgc2NvcGUgPSBzY29wZUZvcihtdXRhdGlvbik7XG5cdFx0aWYgKHR5cGVvZiBzY29wZSA9PT0gXCJzdHJpbmdcIikge1xuXHRcdFx0Y29uc3Qgc2NvcGVkTXV0YXRpb25zID0gdGhpcy4jc2NvcGVzLmdldChzY29wZSk7XG5cdFx0XHRpZiAoc2NvcGVkTXV0YXRpb25zKSBzY29wZWRNdXRhdGlvbnMucHVzaChtdXRhdGlvbik7XG5cdFx0XHRlbHNlIHRoaXMuI3Njb3Blcy5zZXQoc2NvcGUsIFttdXRhdGlvbl0pO1xuXHRcdH1cblx0XHR0aGlzLm5vdGlmeSh7XG5cdFx0XHR0eXBlOiBcImFkZGVkXCIsXG5cdFx0XHRtdXRhdGlvblxuXHRcdH0pO1xuXHR9XG5cdC8qKlxuXHQqIFJlbW92ZXMgYSBtdXRhdGlvbiBmcm9tIHRoZSBjYWNoZS5cblx0KiBAaW50ZXJuYWxcblx0KiBAcGFyYW0gbXV0YXRpb24gLSBUaGUgbXV0YXRpb24gdG8gcmVtb3ZlLCBhbHNvIGZyb20gaXRzIHNjb3BlJ3MgcXVldWUuXG5cdCovXG5cdHJlbW92ZShtdXRhdGlvbikge1xuXHRcdGlmICh0aGlzLiNtdXRhdGlvbnMuZGVsZXRlKG11dGF0aW9uKSkge1xuXHRcdFx0Y29uc3Qgc2NvcGUgPSBzY29wZUZvcihtdXRhdGlvbik7XG5cdFx0XHRpZiAodHlwZW9mIHNjb3BlID09PSBcInN0cmluZ1wiKSB7XG5cdFx0XHRcdGNvbnN0IHNjb3BlZE11dGF0aW9ucyA9IHRoaXMuI3Njb3Blcy5nZXQoc2NvcGUpO1xuXHRcdFx0XHRpZiAoc2NvcGVkTXV0YXRpb25zKSB7XG5cdFx0XHRcdFx0aWYgKHNjb3BlZE11dGF0aW9ucy5sZW5ndGggPiAxKSB7XG5cdFx0XHRcdFx0XHRjb25zdCBpbmRleCA9IHNjb3BlZE11dGF0aW9ucy5pbmRleE9mKG11dGF0aW9uKTtcblx0XHRcdFx0XHRcdGlmIChpbmRleCAhPT0gLTEpIHNjb3BlZE11dGF0aW9ucy5zcGxpY2UoaW5kZXgsIDEpO1xuXHRcdFx0XHRcdH0gZWxzZSBpZiAoc2NvcGVkTXV0YXRpb25zWzBdID09PSBtdXRhdGlvbikgdGhpcy4jc2NvcGVzLmRlbGV0ZShzY29wZSk7XG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHR9XG5cdFx0dGhpcy5ub3RpZnkoe1xuXHRcdFx0dHlwZTogXCJyZW1vdmVkXCIsXG5cdFx0XHRtdXRhdGlvblxuXHRcdH0pO1xuXHR9XG5cdC8qKlxuXHQqIENoZWNrcyB3aGV0aGVyIGEgbXV0YXRpb24gY2FuIHJ1biBub3csIGdpdmVuIHRoZSBvdGhlciBtdXRhdGlvbnMgaW4gaXRzIGBzY29wZWAuXG5cdCogQGludGVybmFsXG5cdCogQHBhcmFtIG11dGF0aW9uIC0gVGhlIG11dGF0aW9uIHRvIGNoZWNrLlxuXHQqIEByZXR1cm5zIGB0cnVlYCBpZiB0aGUgbXV0YXRpb24gaGFzIG5vIGBzY29wZWAsIG9yIG5vIG90aGVyIG11dGF0aW9uIGluIGl0cyBzY29wZSBpcyBwZW5kaW5nXG5cdCogYWhlYWQgb2YgaXQuXG5cdCovXG5cdGNhblJ1bihtdXRhdGlvbikge1xuXHRcdGNvbnN0IHNjb3BlID0gc2NvcGVGb3IobXV0YXRpb24pO1xuXHRcdGlmICh0eXBlb2Ygc2NvcGUgPT09IFwic3RyaW5nXCIpIHtcblx0XHRcdGNvbnN0IGZpcnN0UGVuZGluZ011dGF0aW9uID0gdGhpcy4jc2NvcGVzLmdldChzY29wZSk/LmZpbmQoKG0pID0+IG0uc3RhdGUuc3RhdHVzID09PSBcInBlbmRpbmdcIik7XG5cdFx0XHRyZXR1cm4gIWZpcnN0UGVuZGluZ011dGF0aW9uIHx8IGZpcnN0UGVuZGluZ011dGF0aW9uID09PSBtdXRhdGlvbjtcblx0XHR9IGVsc2UgcmV0dXJuIHRydWU7XG5cdH1cblx0LyoqXG5cdCogQ29udGludWVzIHRoZSBuZXh0IHBhdXNlZCBtdXRhdGlvbiBpbiB0aGUgc2FtZSBgc2NvcGVgIGFmdGVyIGEgbXV0YXRpb24gZmluaXNoZXMuXG5cdCogQGludGVybmFsXG5cdCogQHBhcmFtIG11dGF0aW9uIC0gVGhlIG11dGF0aW9uIHRoYXQgZmluaXNoZWQuXG5cdCogQHJldHVybnMgQSBwcm9taXNlIHRoYXQgcmVzb2x2ZXMgb25jZSB0aGUgbmV4dCBwYXVzZWQgbXV0YXRpb24gaW4gdGhlIHNhbWUgc2NvcGUgaGFzIGNvbnRpbnVlZCxcblx0KiBvciBpbW1lZGlhdGVseSBpZiB0aGVyZSBpcyBub25lLlxuXHQqL1xuXHRydW5OZXh0KG11dGF0aW9uKSB7XG5cdFx0Y29uc3Qgc2NvcGUgPSBzY29wZUZvcihtdXRhdGlvbik7XG5cdFx0aWYgKHR5cGVvZiBzY29wZSA9PT0gXCJzdHJpbmdcIikgcmV0dXJuICh0aGlzLiNzY29wZXMuZ2V0KHNjb3BlKT8uZmluZCgobSkgPT4gbSAhPT0gbXV0YXRpb24gJiYgbS5zdGF0ZS5pc1BhdXNlZCkpPy5jb250aW51ZSgpID8/IFByb21pc2UucmVzb2x2ZSgpO1xuXHRcdGVsc2UgcmV0dXJuIFByb21pc2UucmVzb2x2ZSgpO1xuXHR9XG5cdC8qKlxuXHQqIFJlbW92ZXMgYWxsIG11dGF0aW9ucyBmcm9tIHRoZSBjYWNoZS5cblx0KiBAZXhhbXBsZVxuXHQqIGBgYHRzXG5cdCogY29uc3QgbXV0YXRpb25DYWNoZSA9IHF1ZXJ5Q2xpZW50LmdldE11dGF0aW9uQ2FjaGUoKVxuXHQqXG5cdCogbXV0YXRpb25DYWNoZS5jbGVhcigpXG5cdCogYGBgXG5cdCovXG5cdGNsZWFyKCkge1xuXHRcdG5vdGlmeU1hbmFnZXIuYmF0Y2goKCkgPT4ge1xuXHRcdFx0Y29uc3QgbXV0YXRpb25zID0gdGhpcy5nZXRBbGwoKTtcblx0XHRcdHRoaXMuI211dGF0aW9ucy5jbGVhcigpO1xuXHRcdFx0dGhpcy4jc2NvcGVzLmNsZWFyKCk7XG5cdFx0XHRtdXRhdGlvbnMuZm9yRWFjaCgobXV0YXRpb24pID0+IHtcblx0XHRcdFx0dGhpcy5ub3RpZnkoe1xuXHRcdFx0XHRcdHR5cGU6IFwicmVtb3ZlZFwiLFxuXHRcdFx0XHRcdG11dGF0aW9uXG5cdFx0XHRcdH0pO1xuXHRcdFx0fSk7XG5cdFx0fSk7XG5cdH1cblx0LyoqXG5cdCogUmV0dXJucyBhbGwgbXV0YXRpb25zIHdpdGhpbiB0aGUgY2FjaGUuXG5cdCpcblx0KiBUaGlzIGlzIG5vdCB0eXBpY2FsbHkgbmVlZGVkIGZvciBtb3N0IGFwcGxpY2F0aW9ucywgYnV0IGNhbiBjb21lIGluIGhhbmR5IHdoZW4gbmVlZGluZyBtb3JlXG5cdCogaW5mb3JtYXRpb24gYWJvdXQgYSBtdXRhdGlvbiBpbiByYXJlIHNjZW5hcmlvcy5cblx0KiBAcmV0dXJucyBFdmVyeSBtdXRhdGlvbiBpbiB0aGUgY2FjaGUuXG5cdCogQGV4YW1wbGVcblx0KiBgYGB0c1xuXHQqIGNvbnN0IG11dGF0aW9uQ2FjaGUgPSBxdWVyeUNsaWVudC5nZXRNdXRhdGlvbkNhY2hlKClcblx0KlxuXHQqIGNvbnN0IG11dGF0aW9ucyA9IG11dGF0aW9uQ2FjaGUuZ2V0QWxsKClcblx0KiBgYGBcblx0Ki9cblx0Z2V0QWxsKCkge1xuXHRcdHJldHVybiBBcnJheS5mcm9tKHRoaXMuI211dGF0aW9ucyk7XG5cdH1cblx0LyoqXG5cdCogQSBzbGlnaHRseSBtb3JlIGFkdmFuY2VkIG1ldGhvZCB0aGF0IGNhbiBiZSB1c2VkIHRvIGdldCBhbiBleGlzdGluZyBtdXRhdGlvbiBpbnN0YW5jZSBmcm9tXG5cdCogdGhlIGNhY2hlLiBJZiB0aGUgbXV0YXRpb24gZG9lcyBub3QgZXhpc3QsIGB1bmRlZmluZWRgIGlzIHJldHVybmVkLlxuXHQqXG5cdCogVGhpcyBpcyBub3QgdHlwaWNhbGx5IG5lZWRlZCBmb3IgbW9zdCBhcHBsaWNhdGlvbnMsIGJ1dCBjYW4gY29tZSBpbiBoYW5keSB3aGVuIG5lZWRpbmcgbW9yZVxuXHQqIGluZm9ybWF0aW9uIGFib3V0IGEgbXV0YXRpb24gaW4gcmFyZSBzY2VuYXJpb3MuXG5cdCogQHBhcmFtIGZpbHRlcnMgLSBUaGUgZmlsdGVycyB0byBtYXRjaC4gYGV4YWN0YCBkZWZhdWx0cyB0byBgdHJ1ZWAuXG5cdCogQHJldHVybnMgVGhlIGZpcnN0IG1hdGNoaW5nIG11dGF0aW9uLCBvciBgdW5kZWZpbmVkYC5cblx0KiBAc2VlIHtAbGluayBNdXRhdGlvbkNhY2hlI2ZpbmRBbGx9XG5cdCogQGV4YW1wbGVcblx0KiBgYGB0c1xuXHQqIGNvbnN0IG11dGF0aW9uQ2FjaGUgPSBxdWVyeUNsaWVudC5nZXRNdXRhdGlvbkNhY2hlKClcblx0KlxuXHQqIGNvbnN0IG11dGF0aW9uID0gbXV0YXRpb25DYWNoZS5maW5kKHsgbXV0YXRpb25LZXk6IFsnYWRkUG9zdCddIH0pXG5cdCogYGBgXG5cdCovXG5cdGZpbmQoZmlsdGVycykge1xuXHRcdGNvbnN0IGRlZmF1bHRlZEZpbHRlcnMgPSB7XG5cdFx0XHRleGFjdDogdHJ1ZSxcblx0XHRcdC4uLmZpbHRlcnNcblx0XHR9O1xuXHRcdHJldHVybiB0aGlzLmdldEFsbCgpLmZpbmQoKG11dGF0aW9uKSA9PiBtYXRjaE11dGF0aW9uKGRlZmF1bHRlZEZpbHRlcnMsIG11dGF0aW9uKSk7XG5cdH1cblx0LyoqXG5cdCogQW4gZXZlbiBtb3JlIGFkdmFuY2VkIG1ldGhvZCB0aGF0IGNhbiBiZSB1c2VkIHRvIGdldCBleGlzdGluZyBtdXRhdGlvbiBpbnN0YW5jZXMgZnJvbSB0aGVcblx0KiBjYWNoZSB0aGF0IG1hdGNoIHRoZSBnaXZlbiBmaWx0ZXJzLiBJZiBubyBtdXRhdGlvbnMgbWF0Y2gsIGFuIGVtcHR5IGFycmF5IGlzIHJldHVybmVkLlxuXHQqXG5cdCogVGhpcyBpcyBub3QgdHlwaWNhbGx5IG5lZWRlZCBmb3IgbW9zdCBhcHBsaWNhdGlvbnMsIGJ1dCBjYW4gY29tZSBpbiBoYW5keSB3aGVuIG5lZWRpbmcgbW9yZVxuXHQqIGluZm9ybWF0aW9uIGFib3V0IG11dGF0aW9ucyBpbiByYXJlIHNjZW5hcmlvcy5cblx0KiBAcGFyYW0gZmlsdGVycyAtIFRoZSBmaWx0ZXJzIHRvIG1hdGNoLiBXaXRob3V0IGZpbHRlcnMsIGV2ZXJ5IG11dGF0aW9uIGlzIHJldHVybmVkLlxuXHQqIEByZXR1cm5zIFRoZSBtYXRjaGluZyBtdXRhdGlvbnMuXG5cdCogQHNlZSB7QGxpbmsgTXV0YXRpb25DYWNoZSNmaW5kfVxuXHQqIEBleGFtcGxlXG5cdCogYGBgdHNcblx0KiBjb25zdCBtdXRhdGlvbkNhY2hlID0gcXVlcnlDbGllbnQuZ2V0TXV0YXRpb25DYWNoZSgpXG5cdCpcblx0KiBjb25zdCBtdXRhdGlvbnMgPSBtdXRhdGlvbkNhY2hlLmZpbmRBbGwoeyBtdXRhdGlvbktleTogWydhZGRQb3N0J10gfSlcblx0KiBgYGBcblx0Ki9cblx0ZmluZEFsbChmaWx0ZXJzID0ge30pIHtcblx0XHRyZXR1cm4gdGhpcy5nZXRBbGwoKS5maWx0ZXIoKG11dGF0aW9uKSA9PiBtYXRjaE11dGF0aW9uKGZpbHRlcnMsIG11dGF0aW9uKSk7XG5cdH1cblx0LyoqXG5cdCogTm90aWZpZXMgZXZlcnkgY2FjaGUgbGlzdGVuZXIgb2YgYW4gZXZlbnQsIGluIG9uZSBiYXRjaC5cblx0KiBAaW50ZXJuYWxcblx0KiBAcGFyYW0gZXZlbnQgLSBUaGUgZXZlbnQgcGFzc2VkIHRvIGV2ZXJ5IGxpc3RlbmVyLlxuXHQqL1xuXHRub3RpZnkoZXZlbnQpIHtcblx0XHRub3RpZnlNYW5hZ2VyLmJhdGNoKCgpID0+IHtcblx0XHRcdHRoaXMubGlzdGVuZXJzLmZvckVhY2goKGxpc3RlbmVyKSA9PiB7XG5cdFx0XHRcdGxpc3RlbmVyKGV2ZW50KTtcblx0XHRcdH0pO1xuXHRcdH0pO1xuXHR9XG5cdC8qKlxuXHQqIENvbnRpbnVlcyBldmVyeSBwYXVzZWQgbXV0YXRpb24sIGUuZy4gd2hlbiB0aGUgYXBwIGNvbWVzIGJhY2sgb25saW5lLlxuXHQqIEBpbnRlcm5hbFxuXHQqIEByZXR1cm5zIEEgcHJvbWlzZSB0aGF0IHJlc29sdmVzIG9uY2UgZXZlcnkgcGF1c2VkIG11dGF0aW9uIGhhcyBjb250aW51ZWQgYW5kIHNldHRsZWQuXG5cdCovXG5cdHJlc3VtZVBhdXNlZE11dGF0aW9ucygpIHtcblx0XHRjb25zdCBwYXVzZWRNdXRhdGlvbnMgPSB0aGlzLmdldEFsbCgpLmZpbHRlcigoeCkgPT4geC5zdGF0ZS5pc1BhdXNlZCk7XG5cdFx0cmV0dXJuIG5vdGlmeU1hbmFnZXIuYmF0Y2goKCkgPT4gUHJvbWlzZS5hbGwocGF1c2VkTXV0YXRpb25zLm1hcCgobXV0YXRpb24pID0+IG11dGF0aW9uLmNvbnRpbnVlKCkuY2F0Y2gobm9vcCkpKSk7XG5cdH1cbn07XG4vKipcbiogUmV0dXJucyB0aGUgc2NvcGUgaWQgb2YgYSBtdXRhdGlvbiwgdXNlZCB0byBydW4gbXV0YXRpb25zIHdpdGggdGhlIHNhbWUgc2NvcGUgb25lIGFmdGVyIGFub3RoZXIuXG4qIEBwYXJhbSBtdXRhdGlvbiAtIFRoZSBtdXRhdGlvbiB0byByZWFkIHRoZSBzY29wZSBvZi5cbiogQHJldHVybnMgVGhlIG11dGF0aW9uJ3MgYHNjb3BlLmlkYCwgb3IgYHVuZGVmaW5lZGAgaWYgaXQgaGFzIG5vIHNjb3BlLlxuKi9cbmZ1bmN0aW9uIHNjb3BlRm9yKG11dGF0aW9uKSB7XG5cdHJldHVybiBtdXRhdGlvbi5vcHRpb25zLnNjb3BlPy5pZDtcbn1cbmV4cG9ydCB7IE11dGF0aW9uQ2FjaGUgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9bXV0YXRpb25DYWNoZS5qcy5tYXAiLCJpbXBvcnQgeyBoYXNoS2V5LCBzaGFsbG93RXF1YWxPYmplY3RzIH0gZnJvbSBcIi4vdXRpbHMuanNcIjtcbmltcG9ydCB7IFN1YnNjcmliYWJsZSB9IGZyb20gXCIuL3N1YnNjcmliYWJsZS5qc1wiO1xuaW1wb3J0IHsgbm90aWZ5TWFuYWdlciB9IGZyb20gXCIuL25vdGlmeU1hbmFnZXIuanNcIjtcbmltcG9ydCB7IGdldERlZmF1bHRTdGF0ZSB9IGZyb20gXCIuL211dGF0aW9uLmpzXCI7XG4vLyBzcmMvbXV0YXRpb25PYnNlcnZlci50c1xuLyoqXG4qIE9ic2VydmVzIGEgc2luZ2xlIG11dGF0aW9uIGFuZCBkZXJpdmVzIGEgYE11dGF0aW9uT2JzZXJ2ZXJSZXN1bHRgIGZyb20gaXQuXG4qIEEgZnJhbWV3b3JrIGhvb2sgbGlrZSBgdXNlTXV0YXRpb25gIGNyZWF0ZXMgb25lIGBNdXRhdGlvbk9ic2VydmVyYCBwZXIgaG9va1xuKiBjYWxsLCBrZWVwcyBpdCBzdGFibGUgYWNyb3NzIHJlLXJlbmRlcnMsIGNhbGxzIGBzZXRPcHRpb25zYCB3aGVuIHRoZSBvcHRpb25zXG4qIHBhc3NlZCB0byB0aGUgaG9vayBjaGFuZ2UsIHN1YnNjcmliZXMgdG8gaXQgdG8gcmUtcmVuZGVyIG9uIHVwZGF0ZXMsIGFuZFxuKiByZWFkcyBgZ2V0Q3VycmVudFJlc3VsdCgpYCBmb3IgdGhlIHZhbHVlIHRvIHJldHVybi4gQ2FsbGluZyBgbXV0YXRlKClgXG4qIGJ1aWxkcyBhIG5ldyB1bmRlcmx5aW5nIGBNdXRhdGlvbmAgaW4gdGhlIGBNdXRhdGlvbkNhY2hlYCBhbmQgZXhlY3V0ZXMgaXQuXG4qIEBleGFtcGxlXG4qIGBgYHRzXG4qIGNvbnN0IG9ic2VydmVyID0gbmV3IE11dGF0aW9uT2JzZXJ2ZXIocXVlcnlDbGllbnQsIHtcbiogICBtdXRhdGlvbkZuOiAodmFyaWFibGVzOiB7IHRpdGxlOiBzdHJpbmcgfSkgPT4gYWRkUG9zdCh2YXJpYWJsZXMpLFxuKiB9KVxuKiBgYGBcbiovXG52YXIgTXV0YXRpb25PYnNlcnZlciA9IGNsYXNzIGV4dGVuZHMgU3Vic2NyaWJhYmxlIHtcblx0I2NsaWVudDtcblx0I2N1cnJlbnRSZXN1bHQgPSB2b2lkIDA7XG5cdCNjdXJyZW50TXV0YXRpb247XG5cdCNtdXRhdGVPcHRpb25zO1xuXHRjb25zdHJ1Y3RvcihjbGllbnQsIG9wdGlvbnMpIHtcblx0XHRzdXBlcigpO1xuXHRcdHRoaXMuI2NsaWVudCA9IGNsaWVudDtcblx0XHR0aGlzLnNldE9wdGlvbnMob3B0aW9ucyk7XG5cdFx0dGhpcy5iaW5kTWV0aG9kcygpO1xuXHRcdHRoaXMuI3VwZGF0ZVJlc3VsdCgpO1xuXHR9XG5cdC8qKlxuXHQqIEJpbmRzIHRoZSBtZXRob2RzIG9mIHRoZSByZXN1bHQgKGBtdXRhdGVgIGFuZCBgcmVzZXRgKSB0byB0aGUgb2JzZXJ2ZXIsIHNvIHRoZXkga2VlcCB3b3JraW5nIHdoZW5cblx0KiBkZXN0cnVjdHVyZWQgZnJvbSBpdC5cblx0Ki9cblx0YmluZE1ldGhvZHMoKSB7XG5cdFx0dGhpcy5tdXRhdGUgPSB0aGlzLm11dGF0ZS5iaW5kKHRoaXMpO1xuXHRcdHRoaXMucmVzZXQgPSB0aGlzLnJlc2V0LmJpbmQodGhpcyk7XG5cdH1cblx0LyoqXG5cdCogVXBkYXRlcyB0aGUgb2JzZXJ2ZXIncyBvcHRpb25zLlxuXHQqXG5cdCogSWYgdGhlIG5ldyBgbXV0YXRpb25LZXlgIGRpZmZlcnMgZnJvbSB0aGUgcHJldmlvdXMgb25lIChhbmQgYm90aCB3ZXJlXG5cdCogZGVmaW5lZCksIHRoZSBvYnNlcnZlciBpcyByZXNldCwgZGV0YWNoaW5nIGl0IGZyb20gdGhlIG11dGF0aW9uIGl0IHdhc1xuXHQqIG9ic2VydmluZy4gT3RoZXJ3aXNlLCBpZiB0aGUgY3VycmVudGx5IG9ic2VydmVkIG11dGF0aW9uIGlzIHN0aWxsXG5cdCogYHBlbmRpbmdgLCBpdHMgb3B0aW9ucyBhcmUgdXBkYXRlZCBpbiBwbGFjZSBhcyB3ZWxsLlxuXHQqIEBwYXJhbSBvcHRpb25zIC0gVGhlIG5ldyBtdXRhdGlvbiBvYnNlcnZlciBvcHRpb25zLiBUaGV5IGFyZSBkZWZhdWx0ZWQgd2l0aCB7QGxpbmtcblx0KiBRdWVyeUNsaWVudCNkZWZhdWx0TXV0YXRpb25PcHRpb25zfSBiZWZvcmUgYmVpbmcgYXBwbGllZC5cblx0KiBAZXhhbXBsZVxuXHQqIGBgYHRzXG5cdCogb2JzZXJ2ZXIuc2V0T3B0aW9ucyh7XG5cdCogICBtdXRhdGlvbkZuOiAodmFyaWFibGVzOiB7IHRpdGxlOiBzdHJpbmcgfSkgPT4gYWRkUG9zdCh2YXJpYWJsZXMpLFxuXHQqICAgb25TdWNjZXNzOiAoZGF0YSkgPT4gY29uc29sZS5sb2coZGF0YSksXG5cdCogfSlcblx0KiBgYGBcblx0Ki9cblx0c2V0T3B0aW9ucyhvcHRpb25zKSB7XG5cdFx0Y29uc3QgcHJldk9wdGlvbnMgPSB0aGlzLm9wdGlvbnM7XG5cdFx0dGhpcy5vcHRpb25zID0gdGhpcy4jY2xpZW50LmRlZmF1bHRNdXRhdGlvbk9wdGlvbnMob3B0aW9ucyk7XG5cdFx0aWYgKCFzaGFsbG93RXF1YWxPYmplY3RzKHRoaXMub3B0aW9ucywgcHJldk9wdGlvbnMpKSB0aGlzLiNjbGllbnQuZ2V0TXV0YXRpb25DYWNoZSgpLm5vdGlmeSh7XG5cdFx0XHR0eXBlOiBcIm9ic2VydmVyT3B0aW9uc1VwZGF0ZWRcIixcblx0XHRcdG11dGF0aW9uOiB0aGlzLiNjdXJyZW50TXV0YXRpb24sXG5cdFx0XHRvYnNlcnZlcjogdGhpc1xuXHRcdH0pO1xuXHRcdGlmIChwcmV2T3B0aW9ucz8ubXV0YXRpb25LZXkgJiYgdGhpcy5vcHRpb25zLm11dGF0aW9uS2V5ICYmIGhhc2hLZXkocHJldk9wdGlvbnMubXV0YXRpb25LZXkpICE9PSBoYXNoS2V5KHRoaXMub3B0aW9ucy5tdXRhdGlvbktleSkpIHRoaXMucmVzZXQoKTtcblx0XHRlbHNlIGlmICh0aGlzLiNjdXJyZW50TXV0YXRpb24/LnN0YXRlLnN0YXR1cyA9PT0gXCJwZW5kaW5nXCIpIHRoaXMuI2N1cnJlbnRNdXRhdGlvbi5zZXRPcHRpb25zKHRoaXMub3B0aW9ucyk7XG5cdH1cblx0b25TdWJzY3JpYmUoKSB7XG5cdFx0aWYgKHRoaXMubGlzdGVuZXJzLnNpemUgPT09IDEgJiYgdGhpcy4jY3VycmVudE11dGF0aW9uKSB7XG5cdFx0XHR0aGlzLiNjdXJyZW50TXV0YXRpb24uYWRkT2JzZXJ2ZXIodGhpcyk7XG5cdFx0XHR0aGlzLiN1cGRhdGVSZXN1bHQoKTtcblx0XHR9XG5cdH1cblx0b25VbnN1YnNjcmliZSgpIHtcblx0XHRpZiAoIXRoaXMuaGFzTGlzdGVuZXJzKCkpIHRoaXMuI2N1cnJlbnRNdXRhdGlvbj8ucmVtb3ZlT2JzZXJ2ZXIodGhpcyk7XG5cdH1cblx0LyoqXG5cdCogVXBkYXRlcyB0aGUgb2JzZXJ2ZXIncyByZXN1bHQgd2hlbiB0aGUgb2JzZXJ2ZWQgbXV0YXRpb24gY2hhbmdlcywgYW5kIG5vdGlmaWVzIGl0cyBsaXN0ZW5lcnMuXG5cdCogQGludGVybmFsXG5cdCogQHBhcmFtIGFjdGlvbiAtIFRoZSBhY3Rpb24gdGhhdCB1cGRhdGVkIHRoZSBvYnNlcnZlZCBtdXRhdGlvbiwgcGFzc2VkIG9uIHRvIHRoZSBvYnNlcnZlcidzXG5cdCogY2FsbGJhY2tzLlxuXHQqL1xuXHRvbk11dGF0aW9uVXBkYXRlKGFjdGlvbikge1xuXHRcdHRoaXMuI3VwZGF0ZVJlc3VsdCgpO1xuXHRcdHRoaXMuI25vdGlmeShhY3Rpb24pO1xuXHR9XG5cdC8qKlxuXHQqIFJldHVybnMgdGhlIG9ic2VydmVyJ3MgY3VycmVudCByZXN1bHQsIGRlcml2ZWQgZnJvbSB0aGUgb2JzZXJ2ZWRcblx0KiBtdXRhdGlvbidzIHN0YXRlIChvciB0aGUgZGVmYXVsdCwgYGlkbGVgIHN0YXRlIGlmIG5vIG11dGF0aW9uIGhhcyBiZWVuXG5cdCogYnVpbHQgeWV0LCBlLmcuIGJlZm9yZSB0aGUgZmlyc3QgYG11dGF0ZSgpYCBjYWxsIG9yIGFmdGVyIGByZXNldCgpYCkuXG5cdCogQHJldHVybnMgVGhlIG9ic2VydmVyJ3MgbGF0ZXN0IHJlc3VsdC5cblx0Ki9cblx0Z2V0Q3VycmVudFJlc3VsdCgpIHtcblx0XHRyZXR1cm4gdGhpcy4jY3VycmVudFJlc3VsdDtcblx0fVxuXHQvKipcblx0KiBEZXRhY2hlcyB0aGUgb2JzZXJ2ZXIgZnJvbSB0aGUgbXV0YXRpb24gaXQgaXMgY3VycmVudGx5IG9ic2VydmluZyAoaWZcblx0KiBhbnkpIGFuZCByZXNldHMgdGhlIG9ic2VydmVkIHJlc3VsdCBiYWNrIHRvIGl0cyBkZWZhdWx0LCBgaWRsZWAgc3RhdGUuXG5cdCpcblx0KiBUaGlzIGRvZXMgbm90IGNhbmNlbCBhbiBpbi1mbGlnaHQgbXV0YXRpb247IHRoZSBtdXRhdGlvbiBpdHNlbGYga2VlcHNcblx0KiBydW5uaW5nIHRvIGNvbXBsZXRpb24gYW5kIGl0cyBvd24gY2FsbGJhY2tzIHN0aWxsIGZpcmUsIGJ1dCB0aGlzXG5cdCogb2JzZXJ2ZXIgc3RvcHMgcmVmbGVjdGluZyBpdHMgc3RhdGUgYW5kIGEgc3Vic2VxdWVudCBgbXV0YXRlKClgIGNhbGxcblx0KiB3aWxsIGJ1aWxkIGEgYnJhbmQgbmV3IG11dGF0aW9uLlxuXHQqIEBzZWUge0BsaW5rIE11dGF0aW9uT2JzZXJ2ZXIjbXV0YXRlfVxuXHQqIEBleGFtcGxlXG5cdCogYGBgdHNcblx0KiBvYnNlcnZlci5yZXNldCgpXG5cdCogYGBgXG5cdCovXG5cdHJlc2V0KCkge1xuXHRcdHRoaXMuI2N1cnJlbnRNdXRhdGlvbj8ucmVtb3ZlT2JzZXJ2ZXIodGhpcyk7XG5cdFx0dGhpcy4jY3VycmVudE11dGF0aW9uID0gdm9pZCAwO1xuXHRcdHRoaXMuI3VwZGF0ZVJlc3VsdCgpO1xuXHRcdHRoaXMuI25vdGlmeSgpO1xuXHR9XG5cdC8qKlxuXHQqIEJ1aWxkcyBhIG5ldyBgTXV0YXRpb25gIGluIHRoZSBgTXV0YXRpb25DYWNoZWAgdXNpbmcgdGhlIG9ic2VydmVyJ3Ncblx0KiBjdXJyZW50IG9wdGlvbnMsIGRldGFjaGVzIHRoaXMgb2JzZXJ2ZXIgZnJvbSBhbnkgcHJldmlvdXNseSBvYnNlcnZlZFxuXHQqIG11dGF0aW9uLCBhdHRhY2hlcyBpdCB0byB0aGUgbmV3IG9uZSwgYW5kIGV4ZWN1dGVzIGl0IHdpdGggdGhlIGdpdmVuXG5cdCogdmFyaWFibGVzLlxuXHQqXG5cdCogVGhlIG9wdGlvbmFsIHBlci1jYWxsIGBvcHRpb25zYCAoYG9uU3VjY2Vzc2AvYG9uRXJyb3JgL2BvblNldHRsZWRgKSBhcmVcblx0KiBpbnZva2VkIG9uY2UgdGhlIG11dGF0aW9uIHNldHRsZXMsIGluIGFkZGl0aW9uIHRvIGFueSBjYWxsYmFja3MgZGVmaW5lZFxuXHQqIG9uIHRoZSBvYnNlcnZlcidzIG93biBvcHRpb25zLlxuXHQqIEBwYXJhbSB2YXJpYWJsZXMgLSBUaGUgdmFyaWFibGVzIHBhc3NlZCB0byB0aGUgYG11dGF0aW9uRm5gLlxuXHQqIEBwYXJhbSBvcHRpb25zIC0gUGVyLWNhbGwgYG9uU3VjY2Vzc2AsIGBvbkVycm9yYCwgYW5kIGBvblNldHRsZWRgIGNhbGxiYWNrcy5cblx0KiBAcmV0dXJucyBBIHByb21pc2UgdGhhdCByZXNvbHZlcyB3aXRoIHRoZSBtdXRhdGlvbidzIGRhdGEsIG9yIHJlamVjdHMgd2l0aCBpdHMgZXJyb3IuXG5cdCogQGV4YW1wbGVcblx0KiBgYGB0c1xuXHQqIGF3YWl0IG9ic2VydmVyLm11dGF0ZShcblx0KiAgIHsgdGl0bGU6ICdOZXcgcG9zdCcgfSxcblx0KiAgIHsgb25TdWNjZXNzOiAoZGF0YSkgPT4gY29uc29sZS5sb2coZGF0YSkgfSxcblx0KiApXG5cdCogYGBgXG5cdCovXG5cdG11dGF0ZSh2YXJpYWJsZXMsIG9wdGlvbnMpIHtcblx0XHR0aGlzLiNtdXRhdGVPcHRpb25zID0gb3B0aW9ucztcblx0XHR0aGlzLiNjdXJyZW50TXV0YXRpb24/LnJlbW92ZU9ic2VydmVyKHRoaXMpO1xuXHRcdHRoaXMuI2N1cnJlbnRNdXRhdGlvbiA9IHRoaXMuI2NsaWVudC5nZXRNdXRhdGlvbkNhY2hlKCkuYnVpbGQodGhpcy4jY2xpZW50LCB0aGlzLm9wdGlvbnMpO1xuXHRcdHRoaXMuI2N1cnJlbnRNdXRhdGlvbi5hZGRPYnNlcnZlcih0aGlzKTtcblx0XHRyZXR1cm4gdGhpcy4jY3VycmVudE11dGF0aW9uLmV4ZWN1dGUodmFyaWFibGVzKTtcblx0fVxuXHQjdXBkYXRlUmVzdWx0KCkge1xuXHRcdGNvbnN0IHN0YXRlID0gdGhpcy4jY3VycmVudE11dGF0aW9uPy5zdGF0ZSA/PyBnZXREZWZhdWx0U3RhdGUoKTtcblx0XHR0aGlzLiNjdXJyZW50UmVzdWx0ID0ge1xuXHRcdFx0Li4uc3RhdGUsXG5cdFx0XHRpc1BlbmRpbmc6IHN0YXRlLnN0YXR1cyA9PT0gXCJwZW5kaW5nXCIsXG5cdFx0XHRpc1N1Y2Nlc3M6IHN0YXRlLnN0YXR1cyA9PT0gXCJzdWNjZXNzXCIsXG5cdFx0XHRpc0Vycm9yOiBzdGF0ZS5zdGF0dXMgPT09IFwiZXJyb3JcIixcblx0XHRcdGlzSWRsZTogc3RhdGUuc3RhdHVzID09PSBcImlkbGVcIixcblx0XHRcdG11dGF0ZTogdGhpcy5tdXRhdGUsXG5cdFx0XHRyZXNldDogdGhpcy5yZXNldFxuXHRcdH07XG5cdH1cblx0I25vdGlmeShhY3Rpb24pIHtcblx0XHRub3RpZnlNYW5hZ2VyLmJhdGNoKCgpID0+IHtcblx0XHRcdGNvbnN0IG11dGF0ZU9wdGlvbnMgPSB0aGlzLiNtdXRhdGVPcHRpb25zO1xuXHRcdFx0aWYgKG11dGF0ZU9wdGlvbnMgJiYgdGhpcy5oYXNMaXN0ZW5lcnMoKSkge1xuXHRcdFx0XHRjb25zdCB2YXJpYWJsZXMgPSB0aGlzLiNjdXJyZW50UmVzdWx0LnZhcmlhYmxlcztcblx0XHRcdFx0Y29uc3Qgb25NdXRhdGVSZXN1bHQgPSB0aGlzLiNjdXJyZW50UmVzdWx0LmNvbnRleHQ7XG5cdFx0XHRcdGNvbnN0IGNvbnRleHQgPSB7XG5cdFx0XHRcdFx0Y2xpZW50OiB0aGlzLiNjbGllbnQsXG5cdFx0XHRcdFx0bWV0YTogdGhpcy5vcHRpb25zLm1ldGEsXG5cdFx0XHRcdFx0bXV0YXRpb25LZXk6IHRoaXMub3B0aW9ucy5tdXRhdGlvbktleVxuXHRcdFx0XHR9O1xuXHRcdFx0XHRpZiAoYWN0aW9uPy50eXBlID09PSBcInN1Y2Nlc3NcIikge1xuXHRcdFx0XHRcdHRyeSB7XG5cdFx0XHRcdFx0XHRtdXRhdGVPcHRpb25zLm9uU3VjY2Vzcz8uKGFjdGlvbi5kYXRhLCB2YXJpYWJsZXMsIG9uTXV0YXRlUmVzdWx0LCBjb250ZXh0KTtcblx0XHRcdFx0XHR9IGNhdGNoIChlKSB7XG5cdFx0XHRcdFx0XHRQcm9taXNlLnJlamVjdChlKTtcblx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0dHJ5IHtcblx0XHRcdFx0XHRcdG11dGF0ZU9wdGlvbnMub25TZXR0bGVkPy4oYWN0aW9uLmRhdGEsIG51bGwsIHZhcmlhYmxlcywgb25NdXRhdGVSZXN1bHQsIGNvbnRleHQpO1xuXHRcdFx0XHRcdH0gY2F0Y2ggKGUpIHtcblx0XHRcdFx0XHRcdFByb21pc2UucmVqZWN0KGUpO1xuXHRcdFx0XHRcdH1cblx0XHRcdFx0fSBlbHNlIGlmIChhY3Rpb24/LnR5cGUgPT09IFwiZXJyb3JcIikge1xuXHRcdFx0XHRcdHRyeSB7XG5cdFx0XHRcdFx0XHRtdXRhdGVPcHRpb25zLm9uRXJyb3I/LihhY3Rpb24uZXJyb3IsIHZhcmlhYmxlcywgb25NdXRhdGVSZXN1bHQsIGNvbnRleHQpO1xuXHRcdFx0XHRcdH0gY2F0Y2ggKGUpIHtcblx0XHRcdFx0XHRcdFByb21pc2UucmVqZWN0KGUpO1xuXHRcdFx0XHRcdH1cblx0XHRcdFx0XHR0cnkge1xuXHRcdFx0XHRcdFx0bXV0YXRlT3B0aW9ucy5vblNldHRsZWQ/Lih2b2lkIDAsIGFjdGlvbi5lcnJvciwgdmFyaWFibGVzLCBvbk11dGF0ZVJlc3VsdCwgY29udGV4dCk7XG5cdFx0XHRcdFx0fSBjYXRjaCAoZSkge1xuXHRcdFx0XHRcdFx0UHJvbWlzZS5yZWplY3QoZSk7XG5cdFx0XHRcdFx0fVxuXHRcdFx0XHR9XG5cdFx0XHR9XG5cdFx0XHR0aGlzLmxpc3RlbmVycy5mb3JFYWNoKChsaXN0ZW5lcikgPT4ge1xuXHRcdFx0XHRsaXN0ZW5lcih0aGlzLiNjdXJyZW50UmVzdWx0KTtcblx0XHRcdH0pO1xuXHRcdH0pO1xuXHR9XG59O1xuZXhwb3J0IHsgTXV0YXRpb25PYnNlcnZlciB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1tdXRhdGlvbk9ic2VydmVyLmpzLm1hcCIsImltcG9ydCB7IHJlcGxhY2VFcXVhbERlZXAsIHNoYWxsb3dFcXVhbE9iamVjdHMgfSBmcm9tIFwiLi91dGlscy5qc1wiO1xuaW1wb3J0IHsgU3Vic2NyaWJhYmxlIH0gZnJvbSBcIi4vc3Vic2NyaWJhYmxlLmpzXCI7XG5pbXBvcnQgeyBub3RpZnlNYW5hZ2VyIH0gZnJvbSBcIi4vbm90aWZ5TWFuYWdlci5qc1wiO1xuaW1wb3J0IHsgUXVlcnlPYnNlcnZlciB9IGZyb20gXCIuL3F1ZXJ5T2JzZXJ2ZXIuanNcIjtcbi8vIHNyYy9xdWVyaWVzT2JzZXJ2ZXIudHNcbi8qKlxuKiBSZXR1cm5zIHRoZSBpdGVtcyBvZiBgYXJyYXkxYCB0aGF0IGFyZSBub3QgaW4gYGFycmF5MmAuXG4qIEBwYXJhbSBhcnJheTEgLSBUaGUgaXRlbXMgdG8gZmlsdGVyLlxuKiBAcGFyYW0gYXJyYXkyIC0gVGhlIGl0ZW1zIHRvIGV4Y2x1ZGUuXG4qIEByZXR1cm5zIEEgbmV3IGFycmF5IHdpdGggdGhlIGl0ZW1zIG9mIGBhcnJheTFgIHRoYXQgYXJlIG5vdCBpbiBgYXJyYXkyYC5cbiovXG5mdW5jdGlvbiBkaWZmZXJlbmNlKGFycmF5MSwgYXJyYXkyKSB7XG5cdGNvbnN0IGV4Y2x1ZGVTZXQgPSBuZXcgU2V0KGFycmF5Mik7XG5cdHJldHVybiBhcnJheTEuZmlsdGVyKCh4KSA9PiAhZXhjbHVkZVNldC5oYXMoeCkpO1xufVxuLyoqXG4qIEEgYFF1ZXJpZXNPYnNlcnZlcmAgd2F0Y2hlcyBhbiBhcnJheSBvZiBxdWVyaWVzIGF0IG9uY2UsIGV4cG9zaW5nIHRoZW0gYXNcbiogYSBzaW5nbGUgYXJyYXkgb2YgYFF1ZXJ5T2JzZXJ2ZXJSZXN1bHRgcyAob3IsIHdoZW4gYSBgY29tYmluZWAgb3B0aW9uIGlzXG4qIGdpdmVuLCBhcyBhIGNvbWJpbmVkIHZhbHVlIGRlcml2ZWQgZnJvbSB0aGF0IGFycmF5KS4gSXQgbWFuYWdlcyBvbmVcbiogaW50ZXJuYWwgYFF1ZXJ5T2JzZXJ2ZXJgIHBlciBxdWVyeSwgYW5kIGlzIHRoZSBwcmltaXRpdmUgdGhhdCBmcmFtZXdvcmtcbiogYWRhcHRlcnMgKGUuZy4gYHVzZVF1ZXJpZXNgKSBidWlsZCB0aGVpciBob29rcyBvbiB0b3Agb2YuXG4qIEBleGFtcGxlXG4qIGBgYHRzXG4qIGNvbnN0IG9ic2VydmVyID0gbmV3IFF1ZXJpZXNPYnNlcnZlcihxdWVyeUNsaWVudCwgW1xuKiAgIHsgcXVlcnlLZXk6IFsncG9zdCcsIDFdLCBxdWVyeUZuOiBmZXRjaFBvc3QgfSxcbiogICB7IHF1ZXJ5S2V5OiBbJ3Bvc3QnLCAyXSwgcXVlcnlGbjogZmV0Y2hQb3N0IH0sXG4qIF0pXG4qXG4qIGNvbnN0IHVuc3Vic2NyaWJlID0gb2JzZXJ2ZXIuc3Vic2NyaWJlKChyZXN1bHQpID0+IHtcbiogICBjb25zb2xlLmxvZyhyZXN1bHQpXG4qIH0pXG4qIGBgYFxuKi9cbnZhciBRdWVyaWVzT2JzZXJ2ZXIgPSBjbGFzcyBleHRlbmRzIFN1YnNjcmliYWJsZSB7XG5cdCNjbGllbnQ7XG5cdCNyZXN1bHQ7XG5cdCNxdWVyaWVzO1xuXHQjb3B0aW9ucztcblx0I29ic2VydmVycztcblx0I2NvbWJpbmVkUmVzdWx0O1xuXHQjbGFzdENvbWJpbmU7XG5cdCNsYXN0UmVzdWx0O1xuXHQjbGFzdFF1ZXJ5SGFzaGVzO1xuXHQjb2JzZXJ2ZXJNYXRjaGVzID0gW107XG5cdGNvbnN0cnVjdG9yKGNsaWVudCwgcXVlcmllcywgb3B0aW9ucykge1xuXHRcdHN1cGVyKCk7XG5cdFx0dGhpcy4jY2xpZW50ID0gY2xpZW50O1xuXHRcdHRoaXMuI29wdGlvbnMgPSBvcHRpb25zO1xuXHRcdHRoaXMuI3F1ZXJpZXMgPSBbXTtcblx0XHR0aGlzLiNvYnNlcnZlcnMgPSBbXTtcblx0XHR0aGlzLiNyZXN1bHQgPSBbXTtcblx0XHR0aGlzLnNldFF1ZXJpZXMocXVlcmllcyk7XG5cdH1cblx0b25TdWJzY3JpYmUoKSB7XG5cdFx0aWYgKHRoaXMubGlzdGVuZXJzLnNpemUgPT09IDEpIHRoaXMuI29ic2VydmVycy5mb3JFYWNoKChvYnNlcnZlcikgPT4ge1xuXHRcdFx0b2JzZXJ2ZXIuc3Vic2NyaWJlKChyZXN1bHQpID0+IHtcblx0XHRcdFx0dGhpcy4jb25VcGRhdGUob2JzZXJ2ZXIsIHJlc3VsdCk7XG5cdFx0XHR9KTtcblx0XHR9KTtcblx0fVxuXHRvblVuc3Vic2NyaWJlKCkge1xuXHRcdGlmICghdGhpcy5saXN0ZW5lcnMuc2l6ZSkgdGhpcy5kZXN0cm95KCk7XG5cdH1cblx0LyoqXG5cdCogU3RvcHMgb2JzZXJ2aW5nIGFsbCBxdWVyaWVzOiBjbGVhcnMgYWxsIGxpc3RlbmVycyBhbmQgZGVzdHJveXMgZXZlcnlcblx0KiB1bmRlcmx5aW5nIGBRdWVyeU9ic2VydmVyYCB0aGlzIG9ic2VydmVyIG1hbmFnZXMuXG5cdCovXG5cdGRlc3Ryb3koKSB7XG5cdFx0dGhpcy5saXN0ZW5lcnMgPSAvKiBAX19QVVJFX18gKi8gbmV3IFNldCgpO1xuXHRcdHRoaXMuI29ic2VydmVycy5mb3JFYWNoKChvYnNlcnZlcikgPT4ge1xuXHRcdFx0b2JzZXJ2ZXIuZGVzdHJveSgpO1xuXHRcdH0pO1xuXHR9XG5cdC8qKlxuXHQqIFJlcGxhY2VzIHRoZSBzZXQgb2YgcXVlcmllcyBiZWluZyBvYnNlcnZlZC4gRXhpc3RpbmcgYFF1ZXJ5T2JzZXJ2ZXJgc1xuXHQqIGFyZSByZXVzZWQgZm9yIHF1ZXJpZXMgdGhhdCBtYXRjaCBhbiBhbHJlYWR5LW9ic2VydmVkIHF1ZXJ5IGhhc2g7XG5cdCogb2JzZXJ2ZXJzIGZvciBxdWVyaWVzIHRoYXQgYXJlIG5vIGxvbmdlciBwcmVzZW50IGFyZSBkZXN0cm95ZWQsIGFuZCBuZXdcblx0KiBvYnNlcnZlcnMgYXJlIGNyZWF0ZWQgYW5kIHN1YnNjcmliZWQgdG8gZm9yIG5ld2x5IGFkZGVkIHF1ZXJpZXMuXG5cdCogQHBhcmFtIHF1ZXJpZXMgLSBUaGUgb3B0aW9ucyBvZiB0aGUgcXVlcmllcyB0byBvYnNlcnZlLlxuXHQqIEBwYXJhbSBvcHRpb25zIC0gUmVwbGFjZXMgdGhlIG9ic2VydmVyJ3Mgb3B0aW9ucywgZS5nLiBpdHMgYGNvbWJpbmVgIGZ1bmN0aW9uLlxuXHQqIEBleGFtcGxlXG5cdCogYGBgdHNcblx0KiBvYnNlcnZlci5zZXRRdWVyaWVzKFtcblx0KiAgIHsgcXVlcnlLZXk6IFsncG9zdCcsIDFdLCBxdWVyeUZuOiBmZXRjaFBvc3QgfSxcblx0KiAgIHsgcXVlcnlLZXk6IFsncG9zdCcsIDNdLCBxdWVyeUZuOiBmZXRjaFBvc3QgfSxcblx0KiBdKVxuXHQqIGBgYFxuXHQqL1xuXHRzZXRRdWVyaWVzKHF1ZXJpZXMsIG9wdGlvbnMpIHtcblx0XHR0aGlzLiNxdWVyaWVzID0gcXVlcmllcztcblx0XHR0aGlzLiNvcHRpb25zID0gb3B0aW9ucztcblx0XHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSB7XG5cdFx0XHRjb25zdCBxdWVyeUhhc2hlcyA9IHF1ZXJpZXMubWFwKChxdWVyeSkgPT4gdGhpcy4jY2xpZW50LmRlZmF1bHRRdWVyeU9wdGlvbnMocXVlcnkpLnF1ZXJ5SGFzaCk7XG5cdFx0XHRpZiAobmV3IFNldChxdWVyeUhhc2hlcykuc2l6ZSAhPT0gcXVlcnlIYXNoZXMubGVuZ3RoKSBjb25zb2xlLndhcm4oXCJbUXVlcmllc09ic2VydmVyXTogRHVwbGljYXRlIFF1ZXJpZXMgZm91bmQuIFRoaXMgbWlnaHQgcmVzdWx0IGluIHVuZXhwZWN0ZWQgYmVoYXZpb3IuXCIpO1xuXHRcdH1cblx0XHRub3RpZnlNYW5hZ2VyLmJhdGNoKCgpID0+IHtcblx0XHRcdGNvbnN0IHByZXZPYnNlcnZlcnMgPSB0aGlzLiNvYnNlcnZlcnM7XG5cdFx0XHRjb25zdCBuZXdPYnNlcnZlck1hdGNoZXMgPSB0aGlzLiNmaW5kTWF0Y2hpbmdPYnNlcnZlcnModGhpcy4jcXVlcmllcyk7XG5cdFx0XHRuZXdPYnNlcnZlck1hdGNoZXMuZm9yRWFjaCgobWF0Y2gpID0+IG1hdGNoLm9ic2VydmVyLnNldE9wdGlvbnMobWF0Y2guZGVmYXVsdGVkUXVlcnlPcHRpb25zKSk7XG5cdFx0XHRjb25zdCBuZXdPYnNlcnZlcnMgPSBuZXdPYnNlcnZlck1hdGNoZXMubWFwKChtYXRjaCkgPT4gbWF0Y2gub2JzZXJ2ZXIpO1xuXHRcdFx0Y29uc3QgbmV3UmVzdWx0ID0gbmV3T2JzZXJ2ZXJzLm1hcCgob2JzZXJ2ZXIpID0+IG9ic2VydmVyLmdldEN1cnJlbnRSZXN1bHQoKSk7XG5cdFx0XHRjb25zdCBoYXNMZW5ndGhDaGFuZ2UgPSBwcmV2T2JzZXJ2ZXJzLmxlbmd0aCAhPT0gbmV3T2JzZXJ2ZXJzLmxlbmd0aDtcblx0XHRcdGNvbnN0IGhhc0luZGV4Q2hhbmdlID0gbmV3T2JzZXJ2ZXJzLnNvbWUoKG9ic2VydmVyLCBpbmRleCkgPT4gb2JzZXJ2ZXIgIT09IHByZXZPYnNlcnZlcnNbaW5kZXhdKTtcblx0XHRcdGNvbnN0IGhhc1N0cnVjdHVyYWxDaGFuZ2UgPSBoYXNMZW5ndGhDaGFuZ2UgfHwgaGFzSW5kZXhDaGFuZ2U7XG5cdFx0XHRjb25zdCBoYXNSZXN1bHRDaGFuZ2UgPSBoYXNTdHJ1Y3R1cmFsQ2hhbmdlID8gdHJ1ZSA6IG5ld1Jlc3VsdC5zb21lKChyZXN1bHQsIGluZGV4KSA9PiB7XG5cdFx0XHRcdGNvbnN0IHByZXYgPSB0aGlzLiNyZXN1bHRbaW5kZXhdO1xuXHRcdFx0XHRyZXR1cm4gIXByZXYgfHwgIXNoYWxsb3dFcXVhbE9iamVjdHMocmVzdWx0LCBwcmV2KTtcblx0XHRcdH0pO1xuXHRcdFx0aWYgKCFoYXNTdHJ1Y3R1cmFsQ2hhbmdlICYmICFoYXNSZXN1bHRDaGFuZ2UpIHJldHVybjtcblx0XHRcdGlmIChoYXNTdHJ1Y3R1cmFsQ2hhbmdlKSB7XG5cdFx0XHRcdHRoaXMuI29ic2VydmVyTWF0Y2hlcyA9IG5ld09ic2VydmVyTWF0Y2hlcztcblx0XHRcdFx0dGhpcy4jb2JzZXJ2ZXJzID0gbmV3T2JzZXJ2ZXJzO1xuXHRcdFx0fVxuXHRcdFx0dGhpcy4jcmVzdWx0ID0gbmV3UmVzdWx0O1xuXHRcdFx0aWYgKCF0aGlzLmhhc0xpc3RlbmVycygpKSByZXR1cm47XG5cdFx0XHRpZiAoaGFzU3RydWN0dXJhbENoYW5nZSkge1xuXHRcdFx0XHRkaWZmZXJlbmNlKHByZXZPYnNlcnZlcnMsIG5ld09ic2VydmVycykuZm9yRWFjaCgob2JzZXJ2ZXIpID0+IHtcblx0XHRcdFx0XHRvYnNlcnZlci5kZXN0cm95KCk7XG5cdFx0XHRcdH0pO1xuXHRcdFx0XHRkaWZmZXJlbmNlKG5ld09ic2VydmVycywgcHJldk9ic2VydmVycykuZm9yRWFjaCgob2JzZXJ2ZXIpID0+IHtcblx0XHRcdFx0XHRvYnNlcnZlci5zdWJzY3JpYmUoKHJlc3VsdCkgPT4ge1xuXHRcdFx0XHRcdFx0dGhpcy4jb25VcGRhdGUob2JzZXJ2ZXIsIHJlc3VsdCk7XG5cdFx0XHRcdFx0fSk7XG5cdFx0XHRcdH0pO1xuXHRcdFx0fVxuXHRcdFx0dGhpcy4jbm90aWZ5KCk7XG5cdFx0fSk7XG5cdH1cblx0LyoqXG5cdCogUmV0dXJucyB0aGUgbW9zdCByZWNlbnRseSBjb21wdXRlZCBhcnJheSBvZiBgUXVlcnlPYnNlcnZlclJlc3VsdGBzLCBvbmVcblx0KiBwZXIgb2JzZXJ2ZWQgcXVlcnksIGluIHRoZSBzYW1lIG9yZGVyIGFzIHRoZSBxdWVyaWVzIHBhc3NlZCB0byB0aGVcblx0KiBjb25zdHJ1Y3RvciBvciBgc2V0UXVlcmllc2AuXG5cdCogQHJldHVybnMgVGhlIGN1cnJlbnQgcmVzdWx0cy5cblx0KiBAZXhhbXBsZVxuXHQqIGBgYHRzXG5cdCogY29uc3QgcmVzdWx0cyA9IG9ic2VydmVyLmdldEN1cnJlbnRSZXN1bHQoKVxuXHQqIGNvbnN0IGRhdGEgPSByZXN1bHRzLm1hcCgocmVzdWx0KSA9PiByZXN1bHQuZGF0YSlcblx0KiBgYGBcblx0Ki9cblx0Z2V0Q3VycmVudFJlc3VsdCgpIHtcblx0XHRyZXR1cm4gdGhpcy4jcmVzdWx0O1xuXHR9XG5cdC8qKlxuXHQqIFJldHVybnMgdGhlIHVuZGVybHlpbmcgYFF1ZXJ5YCBpbnN0YW5jZXMgY3VycmVudGx5IGJlaW5nIG9ic2VydmVkLCBpblxuXHQqIHRoZSBzYW1lIG9yZGVyIGFzIHRoZSBxdWVyaWVzIHBhc3NlZCB0byB0aGUgY29uc3RydWN0b3Igb3IgYHNldFF1ZXJpZXNgLlxuXHQqIEByZXR1cm5zIFRoZSBvYnNlcnZlZCBxdWVyaWVzLlxuXHQqL1xuXHRnZXRRdWVyaWVzKCkge1xuXHRcdHJldHVybiB0aGlzLiNvYnNlcnZlcnMubWFwKChvYnNlcnZlcikgPT4gb2JzZXJ2ZXIuZ2V0Q3VycmVudFF1ZXJ5KCkpO1xuXHR9XG5cdC8qKlxuXHQqIFJldHVybnMgdGhlIHVuZGVybHlpbmcgYFF1ZXJ5T2JzZXJ2ZXJgIGluc3RhbmNlcyB0aGlzIG9ic2VydmVyIG1hbmFnZXMsXG5cdCogaW4gdGhlIHNhbWUgb3JkZXIgYXMgdGhlIHF1ZXJpZXMgcGFzc2VkIHRvIHRoZSBjb25zdHJ1Y3RvciBvclxuXHQqIGBzZXRRdWVyaWVzYC5cblx0KiBAcmV0dXJucyBUaGUgbWFuYWdlZCBxdWVyeSBvYnNlcnZlcnMuXG5cdCovXG5cdGdldE9ic2VydmVycygpIHtcblx0XHRyZXR1cm4gdGhpcy4jb2JzZXJ2ZXJzO1xuXHR9XG5cdC8qKlxuXHQqIFRoZSBgUXVlcmllc09ic2VydmVyYCBjb3VudGVycGFydCBvZiB7QGxpbmsgUXVlcnlPYnNlcnZlciNnZXRPcHRpbWlzdGljUmVzdWx0fSDigJQgY29tcHV0ZXNcblx0KiB0aGUgcmVzdWx0IGZvciB0aGUgZ2l2ZW4gKGFscmVhZHktZGVmYXVsdGVkKSBxdWVyaWVzIHJpZ2h0IG5vdywgc3luY2hyb25vdXNseS4gQ2FsbGVkIGJ5XG5cdCogZnJhbWV3b3JrIGFkYXB0ZXJzIChlLmcuIGB1c2VRdWVyaWVzYCkgYWhlYWQgb2Ygc3Vic2NyaWJpbmcsIHJldHVybmluZyBhIHR1cGxlIG9mIHRoZSByYXdcblx0KiBwZXItcXVlcnkgcmVzdWx0cywgYSBmdW5jdGlvbiB0byBjb21wdXRlIHRoZSBjb21iaW5lZCByZXN1bHQgZnJvbSB0aGVtLCBhbmQgYSBmdW5jdGlvbiB0b1xuXHQqIHdyYXAgdGhlIHJlc3VsdHMgZm9yIHByb3BlcnR5LWFjY2VzcyB0cmFja2luZy5cblx0KiBAcGFyYW0gcXVlcmllcyAtIFRoZSBkZWZhdWx0ZWQgb3B0aW9ucyBvZiB0aGUgcXVlcmllcyB0byBjb21wdXRlIHRoZSByZXN1bHQgZm9yLlxuXHQqIEBwYXJhbSBjb21iaW5lIC0gVGhlIGBjb21iaW5lYCBmdW5jdGlvbiB1c2VkIGJ5IHRoZSByZXR1cm5lZCBgY29tYmluZVJlc3VsdGAsIGlmIGFueS5cblx0KiBAcmV0dXJucyBBIHR1cGxlIG9mIHRoZSBwZXItcXVlcnkgcmVzdWx0cywgYSBmdW5jdGlvbiB0aGF0IGNvbXB1dGVzIHRoZSBjb21iaW5lZCByZXN1bHQsIGFuZCBhXG5cdCogZnVuY3Rpb24gdGhhdCByZXR1cm5zIHRoZSByZXN1bHRzIHdyYXBwZWQgZm9yIHByb3BlcnR5LWFjY2VzcyB0cmFja2luZy5cblx0Ki9cblx0Z2V0T3B0aW1pc3RpY1Jlc3VsdChxdWVyaWVzLCBjb21iaW5lKSB7XG5cdFx0Y29uc3QgbWF0Y2hlcyA9IHRoaXMuI2ZpbmRNYXRjaGluZ09ic2VydmVycyhxdWVyaWVzKTtcblx0XHRjb25zdCByZXN1bHQgPSBtYXRjaGVzLm1hcCgobWF0Y2gpID0+IG1hdGNoLm9ic2VydmVyLmdldE9wdGltaXN0aWNSZXN1bHQobWF0Y2guZGVmYXVsdGVkUXVlcnlPcHRpb25zKSk7XG5cdFx0Y29uc3QgcXVlcnlIYXNoZXMgPSBtYXRjaGVzLm1hcCgobWF0Y2gpID0+IG1hdGNoLmRlZmF1bHRlZFF1ZXJ5T3B0aW9ucy5xdWVyeUhhc2gpO1xuXHRcdHJldHVybiBbXG5cdFx0XHRyZXN1bHQsXG5cdFx0XHQocikgPT4ge1xuXHRcdFx0XHRyZXR1cm4gdGhpcy4jY29tYmluZVJlc3VsdChyID8/IHJlc3VsdCwgY29tYmluZSwgcXVlcnlIYXNoZXMpO1xuXHRcdFx0fSxcblx0XHRcdCgpID0+IHtcblx0XHRcdFx0cmV0dXJuIHRoaXMuI3RyYWNrUmVzdWx0KHJlc3VsdCwgbWF0Y2hlcyk7XG5cdFx0XHR9XG5cdFx0XTtcblx0fVxuXHQjdHJhY2tSZXN1bHQocmVzdWx0LCBtYXRjaGVzKSB7XG5cdFx0Y29uc3QgdHJhY2tlZFByb3BzID0gLyogQF9fUFVSRV9fICovIG5ldyBTZXQoKTtcblx0XHRyZXR1cm4gbWF0Y2hlcy5tYXAoKG1hdGNoLCBpbmRleCkgPT4ge1xuXHRcdFx0Y29uc3Qgb2JzZXJ2ZXJSZXN1bHQgPSByZXN1bHRbaW5kZXhdO1xuXHRcdFx0cmV0dXJuICFtYXRjaC5kZWZhdWx0ZWRRdWVyeU9wdGlvbnMubm90aWZ5T25DaGFuZ2VQcm9wcyA/IG1hdGNoLm9ic2VydmVyLnRyYWNrUmVzdWx0KG9ic2VydmVyUmVzdWx0LCAoYWNjZXNzZWRQcm9wKSA9PiB7XG5cdFx0XHRcdGlmICghdHJhY2tlZFByb3BzLmhhcyhhY2Nlc3NlZFByb3ApKSB7XG5cdFx0XHRcdFx0dHJhY2tlZFByb3BzLmFkZChhY2Nlc3NlZFByb3ApO1xuXHRcdFx0XHRcdG1hdGNoZXMuZm9yRWFjaCgobSkgPT4ge1xuXHRcdFx0XHRcdFx0bS5vYnNlcnZlci50cmFja1Byb3AoYWNjZXNzZWRQcm9wKTtcblx0XHRcdFx0XHR9KTtcblx0XHRcdFx0fVxuXHRcdFx0fSkgOiBvYnNlcnZlclJlc3VsdDtcblx0XHR9KTtcblx0fVxuXHQjY29tYmluZVJlc3VsdChpbnB1dCwgY29tYmluZSwgcXVlcnlIYXNoZXMpIHtcblx0XHRpZiAoY29tYmluZSkge1xuXHRcdFx0Y29uc3QgbGFzdEhhc2hlcyA9IHRoaXMuI2xhc3RRdWVyeUhhc2hlcztcblx0XHRcdGNvbnN0IHF1ZXJ5SGFzaGVzQ2hhbmdlZCA9IHF1ZXJ5SGFzaGVzICE9PSB2b2lkIDAgJiYgbGFzdEhhc2hlcyAhPT0gdm9pZCAwICYmIChsYXN0SGFzaGVzLmxlbmd0aCAhPT0gcXVlcnlIYXNoZXMubGVuZ3RoIHx8IHF1ZXJ5SGFzaGVzLnNvbWUoKGhhc2gsIGkpID0+IGhhc2ggIT09IGxhc3RIYXNoZXNbaV0pKTtcblx0XHRcdGlmICh0aGlzLiNyZXN1bHQgIT09IHRoaXMuI2xhc3RSZXN1bHQgfHwgcXVlcnlIYXNoZXNDaGFuZ2VkIHx8IGNvbWJpbmUgIT09IHRoaXMuI2xhc3RDb21iaW5lKSB7XG5cdFx0XHRcdHRoaXMuI2xhc3RDb21iaW5lID0gY29tYmluZTtcblx0XHRcdFx0dGhpcy4jbGFzdFJlc3VsdCA9IHRoaXMuI3Jlc3VsdDtcblx0XHRcdFx0aWYgKHF1ZXJ5SGFzaGVzICE9PSB2b2lkIDApIHRoaXMuI2xhc3RRdWVyeUhhc2hlcyA9IHF1ZXJ5SGFzaGVzO1xuXHRcdFx0XHR0aGlzLiNjb21iaW5lZFJlc3VsdCA9IHJlcGxhY2VFcXVhbERlZXAodGhpcy4jY29tYmluZWRSZXN1bHQsIGNvbWJpbmUoaW5wdXQpKTtcblx0XHRcdH1cblx0XHRcdHJldHVybiB0aGlzLiNjb21iaW5lZFJlc3VsdDtcblx0XHR9XG5cdFx0cmV0dXJuIGlucHV0O1xuXHR9XG5cdCNzaG91bGRTa2lwQ29tYmluZSgpIHtcblx0XHRyZXR1cm4gIXRoaXMuI29wdGlvbnM/LmNvbWJpbmUgfHwgdGhpcy4jb2JzZXJ2ZXJzLnNvbWUoKG9ic2VydmVyLCBpbmRleCkgPT4ge1xuXHRcdFx0cmV0dXJuIG9ic2VydmVyLm9wdGlvbnMuc3VzcGVuc2UgJiYgdGhpcy4jcmVzdWx0W2luZGV4XT8uZGF0YSA9PT0gdm9pZCAwO1xuXHRcdH0pO1xuXHR9XG5cdCNmaW5kTWF0Y2hpbmdPYnNlcnZlcnMocXVlcmllcykge1xuXHRcdGNvbnN0IHByZXZPYnNlcnZlcnNNYXAgPSAvKiBAX19QVVJFX18gKi8gbmV3IE1hcCgpO1xuXHRcdHRoaXMuI29ic2VydmVycy5mb3JFYWNoKChvYnNlcnZlcikgPT4ge1xuXHRcdFx0Y29uc3Qga2V5ID0gb2JzZXJ2ZXIub3B0aW9ucy5xdWVyeUhhc2g7XG5cdFx0XHRpZiAoIWtleSkgcmV0dXJuO1xuXHRcdFx0Y29uc3QgcHJldmlvdXNPYnNlcnZlcnMgPSBwcmV2T2JzZXJ2ZXJzTWFwLmdldChrZXkpO1xuXHRcdFx0aWYgKHByZXZpb3VzT2JzZXJ2ZXJzKSBwcmV2aW91c09ic2VydmVycy5wdXNoKG9ic2VydmVyKTtcblx0XHRcdGVsc2UgcHJldk9ic2VydmVyc01hcC5zZXQoa2V5LCBbb2JzZXJ2ZXJdKTtcblx0XHR9KTtcblx0XHRjb25zdCBvYnNlcnZlcnMgPSBbXTtcblx0XHRxdWVyaWVzLmZvckVhY2goKG9wdGlvbnMpID0+IHtcblx0XHRcdGNvbnN0IGRlZmF1bHRlZE9wdGlvbnMgPSB0aGlzLiNjbGllbnQuZGVmYXVsdFF1ZXJ5T3B0aW9ucyhvcHRpb25zKTtcblx0XHRcdGNvbnN0IG9ic2VydmVyID0gcHJldk9ic2VydmVyc01hcC5nZXQoZGVmYXVsdGVkT3B0aW9ucy5xdWVyeUhhc2gpPy5zaGlmdCgpID8/IG5ldyBRdWVyeU9ic2VydmVyKHRoaXMuI2NsaWVudCwgZGVmYXVsdGVkT3B0aW9ucyk7XG5cdFx0XHRvYnNlcnZlcnMucHVzaCh7XG5cdFx0XHRcdGRlZmF1bHRlZFF1ZXJ5T3B0aW9uczogZGVmYXVsdGVkT3B0aW9ucyxcblx0XHRcdFx0b2JzZXJ2ZXJcblx0XHRcdH0pO1xuXHRcdH0pO1xuXHRcdHJldHVybiBvYnNlcnZlcnM7XG5cdH1cblx0I29uVXBkYXRlKG9ic2VydmVyLCByZXN1bHQpIHtcblx0XHRjb25zdCBpbmRleCA9IHRoaXMuI29ic2VydmVycy5pbmRleE9mKG9ic2VydmVyKTtcblx0XHRpZiAoaW5kZXggIT09IC0xKSB7XG5cdFx0XHR0aGlzLiNyZXN1bHQgPSB0aGlzLiNyZXN1bHQuc2xpY2UoKTtcblx0XHRcdHRoaXMuI3Jlc3VsdFtpbmRleF0gPSByZXN1bHQ7XG5cdFx0XHR0aGlzLiNub3RpZnkoKTtcblx0XHR9XG5cdH1cblx0I25vdGlmeSgpIHtcblx0XHRpZiAodGhpcy5oYXNMaXN0ZW5lcnMoKSkge1xuXHRcdFx0Y29uc3Qgc2hvdWxkU2tpcENvbWJpbmUgPSB0aGlzLiNzaG91bGRTa2lwQ29tYmluZSgpO1xuXHRcdFx0Y29uc3QgcHJldmlvdXNSZXN1bHQgPSB0aGlzLiNjb21iaW5lZFJlc3VsdDtcblx0XHRcdGNvbnN0IG5ld1Jlc3VsdCA9IHNob3VsZFNraXBDb21iaW5lID8gcHJldmlvdXNSZXN1bHQgOiB0aGlzLiNjb21iaW5lUmVzdWx0KHRoaXMuI3RyYWNrUmVzdWx0KHRoaXMuI3Jlc3VsdCwgdGhpcy4jb2JzZXJ2ZXJNYXRjaGVzKSwgdGhpcy4jb3B0aW9ucz8uY29tYmluZSk7XG5cdFx0XHRpZiAoc2hvdWxkU2tpcENvbWJpbmUgfHwgcHJldmlvdXNSZXN1bHQgIT09IG5ld1Jlc3VsdCkgbm90aWZ5TWFuYWdlci5iYXRjaCgoKSA9PiB7XG5cdFx0XHRcdHRoaXMubGlzdGVuZXJzLmZvckVhY2goKGxpc3RlbmVyKSA9PiB7XG5cdFx0XHRcdFx0bGlzdGVuZXIodGhpcy4jcmVzdWx0KTtcblx0XHRcdFx0fSk7XG5cdFx0XHR9KTtcblx0XHR9XG5cdH1cbn07XG5leHBvcnQgeyBRdWVyaWVzT2JzZXJ2ZXIgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9cXVlcmllc09ic2VydmVyLmpzLm1hcCIsImltcG9ydCB7IGhhc2hRdWVyeUtleUJ5T3B0aW9ucywgbWF0Y2hRdWVyeSB9IGZyb20gXCIuL3V0aWxzLmpzXCI7XG5pbXBvcnQgeyBTdWJzY3JpYmFibGUgfSBmcm9tIFwiLi9zdWJzY3JpYmFibGUuanNcIjtcbmltcG9ydCB7IG5vdGlmeU1hbmFnZXIgfSBmcm9tIFwiLi9ub3RpZnlNYW5hZ2VyLmpzXCI7XG5pbXBvcnQgeyBRdWVyeSB9IGZyb20gXCIuL3F1ZXJ5LmpzXCI7XG4vLyBzcmMvcXVlcnlDYWNoZS50c1xuLyoqXG4qIFRoZSBgUXVlcnlDYWNoZWAgaXMgdGhlIHN0b3JhZ2UgbWVjaGFuaXNtIGZvciBUYW5TdGFjayBRdWVyeS4gSXQgc3RvcmVzIGFsbCB0aGUgZGF0YSwgbWV0YVxuKiBpbmZvcm1hdGlvbiwgYW5kIHN0YXRlIG9mIHRoZSBxdWVyaWVzIGl0IGNvbnRhaW5zLlxuKlxuKiBOb3JtYWxseSwgeW91IHdpbGwgbm90IGludGVyYWN0IHdpdGggdGhlIGBRdWVyeUNhY2hlYCBkaXJlY3RseSBhbmQgaW5zdGVhZCB1c2UgYSBgUXVlcnlDbGllbnRgXG4qIGZvciBhIHNwZWNpZmljIGNhY2hlLiBZb3UgY2FuIHN1YnNjcmliZSB0byBpdCAoaW5oZXJpdGVkIGZyb20gYFN1YnNjcmliYWJsZWApIHRvIGJlIGluZm9ybWVkIG9mXG4qIHNhZmUva25vd24gdXBkYXRlcyB0byB0aGUgY2FjaGUsIHN1Y2ggYXMgcXVlcmllcyBiZWluZyBhZGRlZCwgcmVtb3ZlZCwgb3IgdXBkYXRlZCDigJQgdXBkYXRlcyBtYWRlXG4qIG91dHNpZGUgb2YgdGhlIGNhY2hlJ3Mgb3duIHRyYWNrZWQgbWVjaGFuaXNtcyAoZS5nLiBtdXRhdGluZyBhIHF1ZXJ5J3Mgc3RhdGUgb2JqZWN0IGRpcmVjdGx5KSBkb1xuKiBub3Qgbm90aWZ5IHN1YnNjcmliZXJzLlxuKiBAZXhhbXBsZVxuKiBgYGB0c1xuKiBjb25zdCB1bnN1YnNjcmliZSA9IHF1ZXJ5Q2FjaGUuc3Vic2NyaWJlKChldmVudCkgPT4ge1xuKiAgIGNvbnNvbGUubG9nKGV2ZW50LnR5cGUsIGV2ZW50LnF1ZXJ5KVxuKiB9KVxuKiBgYGBcbiovXG52YXIgUXVlcnlDYWNoZSA9IGNsYXNzIGV4dGVuZHMgU3Vic2NyaWJhYmxlIHtcblx0I3F1ZXJpZXM7XG5cdGNvbnN0cnVjdG9yKGNvbmZpZyA9IHt9KSB7XG5cdFx0c3VwZXIoKTtcblx0XHR0aGlzLmNvbmZpZyA9IGNvbmZpZztcblx0XHR0aGlzLiNxdWVyaWVzID0gLyogQF9fUFVSRV9fICovIG5ldyBNYXAoKTtcblx0fVxuXHQvKipcblx0KiBSZXR1cm5zIHRoZSBleGlzdGluZyBgUXVlcnlgIGluc3RhbmNlIGZvciB0aGUgZ2l2ZW4gb3B0aW9ucycgYHF1ZXJ5S2V5YC9gcXVlcnlIYXNoYCwgb3Jcblx0KiBidWlsZHMgYW5kIGFkZHMgYSBuZXcgb25lIHRvIHRoZSBjYWNoZSBpZiBub25lIGV4aXN0cyB5ZXQuIFVzZWQgYnkgZnJhbWV3b3JrIGFkYXB0ZXJzIGFuZFxuXHQqIHBsdWdpbnMgKGUuZy4gYnJvYWRjYXN0L3BlcnNpc3RlbmNlKSB0aGF0IG5lZWQgdG8gZ2V0LW9yLWNyZWF0ZSBhIGBRdWVyeWAgZGlyZWN0bHksIGJ5cGFzc2luZ1xuXHQqIHRoZSByZWFjdGl2ZSBgUXVlcnlPYnNlcnZlcmAgbWFjaGluZXJ5LlxuXHQqIEBwYXJhbSBjbGllbnQgLSBUaGUgY2xpZW50IHRoZSBxdWVyeSBiZWxvbmdzIHRvLCB1c2VkIHRvIGRlZmF1bHQgaXRzIG9wdGlvbnMuXG5cdCogQHBhcmFtIG9wdGlvbnMgLSBUaGUgcXVlcnkgb3B0aW9ucywgaW5jbHVkaW5nIHRoZSBgcXVlcnlLZXlgLiBBIG5ldyBxdWVyeSBpcyBjcmVhdGVkIHdpdGggdGhlXG5cdCogb3B0aW9ucyBkZWZhdWx0ZWQgYnkge0BsaW5rIFF1ZXJ5Q2xpZW50I2RlZmF1bHRRdWVyeU9wdGlvbnN9LlxuXHQqIEBwYXJhbSBzdGF0ZSAtIFRoZSBpbml0aWFsIHN0YXRlIG9mIGEgbmV3bHkgY3JlYXRlZCBxdWVyeSwgZS5nLiB3aGVuIGh5ZHJhdGluZy4gSWdub3JlZCBpZiB0aGVcblx0KiBxdWVyeSBhbHJlYWR5IGV4aXN0cy5cblx0KiBAcmV0dXJucyBUaGUgZXhpc3Rpbmcgb3IgbmV3bHkgY3JlYXRlZCBxdWVyeS5cblx0KiBAZXhhbXBsZVxuXHQqIGBgYHRzXG5cdCogY29uc3QgcXVlcnlDYWNoZSA9IHF1ZXJ5Q2xpZW50LmdldFF1ZXJ5Q2FjaGUoKVxuXHQqXG5cdCogY29uc3QgcXVlcnkgPSBxdWVyeUNhY2hlLmJ1aWxkKHF1ZXJ5Q2xpZW50LCB7XG5cdCogICBxdWVyeUtleTogWydwb3N0cyddLFxuXHQqICAgcXVlcnlGbjogZmV0Y2hQb3N0cyxcblx0KiB9KVxuXHQqIGBgYFxuXHQqL1xuXHRidWlsZChjbGllbnQsIG9wdGlvbnMsIHN0YXRlKSB7XG5cdFx0Y29uc3QgcXVlcnlLZXkgPSBvcHRpb25zLnF1ZXJ5S2V5O1xuXHRcdGNvbnN0IHF1ZXJ5SGFzaCA9IG9wdGlvbnMucXVlcnlIYXNoID8/IGhhc2hRdWVyeUtleUJ5T3B0aW9ucyhxdWVyeUtleSwgb3B0aW9ucyk7XG5cdFx0bGV0IHF1ZXJ5ID0gdGhpcy5nZXQocXVlcnlIYXNoKTtcblx0XHRpZiAoIXF1ZXJ5KSB7XG5cdFx0XHRxdWVyeSA9IG5ldyBRdWVyeSh7XG5cdFx0XHRcdGNsaWVudCxcblx0XHRcdFx0cXVlcnlLZXksXG5cdFx0XHRcdHF1ZXJ5SGFzaCxcblx0XHRcdFx0b3B0aW9uczogY2xpZW50LmRlZmF1bHRRdWVyeU9wdGlvbnMob3B0aW9ucyksXG5cdFx0XHRcdHN0YXRlLFxuXHRcdFx0XHRkZWZhdWx0T3B0aW9uczogY2xpZW50LmdldFF1ZXJ5RGVmYXVsdHMocXVlcnlLZXkpXG5cdFx0XHR9KTtcblx0XHRcdHRoaXMuYWRkKHF1ZXJ5KTtcblx0XHR9XG5cdFx0cmV0dXJuIHF1ZXJ5O1xuXHR9XG5cdC8qKlxuXHQqIEFkZHMgYSBxdWVyeSB0byB0aGUgY2FjaGUuXG5cdCogQGludGVybmFsXG5cdCogQHBhcmFtIHF1ZXJ5IC0gVGhlIHF1ZXJ5IHRvIGFkZC4gSWYgYSBxdWVyeSB3aXRoIHRoZSBzYW1lIGhhc2ggaXMgYWxyZWFkeSBjYWNoZWQsIG5vdGhpbmdcblx0KiBoYXBwZW5zLlxuXHQqL1xuXHRhZGQocXVlcnkpIHtcblx0XHRpZiAoIXRoaXMuI3F1ZXJpZXMuaGFzKHF1ZXJ5LnF1ZXJ5SGFzaCkpIHtcblx0XHRcdHRoaXMuI3F1ZXJpZXMuc2V0KHF1ZXJ5LnF1ZXJ5SGFzaCwgcXVlcnkpO1xuXHRcdFx0dGhpcy5ub3RpZnkoe1xuXHRcdFx0XHR0eXBlOiBcImFkZGVkXCIsXG5cdFx0XHRcdHF1ZXJ5XG5cdFx0XHR9KTtcblx0XHR9XG5cdH1cblx0LyoqXG5cdCogRGVzdHJveXMgdGhlIGdpdmVuIGBRdWVyeWAgYW5kIHJlbW92ZXMgaXQgZnJvbSB0aGUgY2FjaGUsIG5vdGlmeWluZyBzdWJzY3JpYmVycyB3aXRoIGFcblx0KiBgJ3JlbW92ZWQnYCBldmVudC4gQSBuby1vcCBpZiB0aGUgcXVlcnkgaXMgbm8gbG9uZ2VyIHRoZSBvbmUgY3VycmVudGx5IHN0b3JlZCB1bmRlciBpdHMgaGFzaFxuXHQqIChlLmcuIGl0IHdhcyBhbHJlYWR5IHJlcGxhY2VkKS4gVXNlZCBieSBwbHVnaW5zIChlLmcuIHRoZSBicm9hZGNhc3QgY2xpZW50KSB0aGF0IG1pcnJvclxuXHQqIHJlbW92YWxzIGFjcm9zcyBgUXVlcnlDYWNoZWAgaW5zdGFuY2VzLlxuXHQqIEBwYXJhbSBxdWVyeSAtIFRoZSBxdWVyeSB0byByZW1vdmUuXG5cdCogQGV4YW1wbGVcblx0KiBgYGB0c1xuXHQqIGNvbnN0IHF1ZXJ5Q2FjaGUgPSBxdWVyeUNsaWVudC5nZXRRdWVyeUNhY2hlKClcblx0KiBjb25zdCBxdWVyeSA9IHF1ZXJ5Q2FjaGUuZmluZCh7IHF1ZXJ5S2V5OiBbJ3Bvc3RzJ10gfSlcblx0KlxuXHQqIGlmIChxdWVyeSkge1xuXHQqICAgcXVlcnlDYWNoZS5yZW1vdmUocXVlcnkpXG5cdCogfVxuXHQqIGBgYFxuXHQqL1xuXHRyZW1vdmUocXVlcnkpIHtcblx0XHRpZiAodGhpcy4jcXVlcmllcy5nZXQocXVlcnkucXVlcnlIYXNoKSA9PT0gcXVlcnkpIHtcblx0XHRcdHF1ZXJ5LmRlc3Ryb3koKTtcblx0XHRcdHRoaXMuI3F1ZXJpZXMuZGVsZXRlKHF1ZXJ5LnF1ZXJ5SGFzaCk7XG5cdFx0XHR0aGlzLm5vdGlmeSh7XG5cdFx0XHRcdHR5cGU6IFwicmVtb3ZlZFwiLFxuXHRcdFx0XHRxdWVyeVxuXHRcdFx0fSk7XG5cdFx0fVxuXHR9XG5cdC8qKlxuXHQqIFJlbW92ZXMgYWxsIHF1ZXJpZXMgZnJvbSB0aGUgY2FjaGUuXG5cdCogQGV4YW1wbGVcblx0KiBgYGB0c1xuXHQqIGNvbnN0IHF1ZXJ5Q2FjaGUgPSBxdWVyeUNsaWVudC5nZXRRdWVyeUNhY2hlKClcblx0KlxuXHQqIHF1ZXJ5Q2FjaGUuY2xlYXIoKVxuXHQqIGBgYFxuXHQqL1xuXHRjbGVhcigpIHtcblx0XHRub3RpZnlNYW5hZ2VyLmJhdGNoKCgpID0+IHtcblx0XHRcdHRoaXMuZ2V0QWxsKCkuZm9yRWFjaCgocXVlcnkpID0+IHtcblx0XHRcdFx0dGhpcy5yZW1vdmUocXVlcnkpO1xuXHRcdFx0fSk7XG5cdFx0fSk7XG5cdH1cblx0LyoqXG5cdCogUmV0dXJucyB0aGUgYFF1ZXJ5YCBpbnN0YW5jZSBzdG9yZWQgdW5kZXIgdGhlIGdpdmVuIGBxdWVyeUhhc2hgLCBvciBgdW5kZWZpbmVkYCBpZiBub25lXG5cdCogZXhpc3RzLiBVbmxpa2Uge0BsaW5rIFF1ZXJ5Q2FjaGUjZmluZH0sIHRoaXMgbG9va3MgdXAgYnkgdGhlIGFscmVhZHktY29tcHV0ZWQgaGFzaCByYXRoZXJcblx0KiB0aGFuIGJ5IGBRdWVyeUZpbHRlcnNgLiBVc2VkIGJ5IHBsdWdpbnMgKGUuZy4gYnJvYWRjYXN0L2h5ZHJhdGlvbikgdGhhdCBhbHJlYWR5IGhhdmUgYSBoYXNoXG5cdCogdG8gbG9vayB1cCBkaXJlY3RseS5cblx0KiBAcGFyYW0gcXVlcnlIYXNoIC0gVGhlIGhhc2ggb2YgdGhlIHF1ZXJ5IHRvIGxvb2sgdXAuXG5cdCogQHJldHVybnMgVGhlIHF1ZXJ5IHN0b3JlZCB1bmRlciB0aGUgaGFzaCwgb3IgYHVuZGVmaW5lZGAuXG5cdCogQGV4YW1wbGVcblx0KiBgYGB0c1xuXHQqIGNvbnN0IHF1ZXJ5Q2FjaGUgPSBxdWVyeUNsaWVudC5nZXRRdWVyeUNhY2hlKClcblx0KiBjb25zdCBxdWVyeUhhc2ggPSBoYXNoS2V5KFsncG9zdHMnXSlcblx0KlxuXHQqIGNvbnN0IHF1ZXJ5ID0gcXVlcnlDYWNoZS5nZXQocXVlcnlIYXNoKVxuXHQqIGBgYFxuXHQqL1xuXHRnZXQocXVlcnlIYXNoKSB7XG5cdFx0cmV0dXJuIHRoaXMuI3F1ZXJpZXMuZ2V0KHF1ZXJ5SGFzaCk7XG5cdH1cblx0LyoqXG5cdCogUmV0dXJucyBhbGwgcXVlcmllcyB3aXRoaW4gdGhlIGNhY2hlLlxuXHQqIEByZXR1cm5zIEV2ZXJ5IHF1ZXJ5IGluIHRoZSBjYWNoZS5cblx0KiBAZXhhbXBsZVxuXHQqIGBgYHRzXG5cdCogY29uc3QgcXVlcnlDYWNoZSA9IHF1ZXJ5Q2xpZW50LmdldFF1ZXJ5Q2FjaGUoKVxuXHQqXG5cdCogY29uc3QgcXVlcmllcyA9IHF1ZXJ5Q2FjaGUuZ2V0QWxsKClcblx0KiBgYGBcblx0Ki9cblx0Z2V0QWxsKCkge1xuXHRcdHJldHVybiBbLi4udGhpcy4jcXVlcmllcy52YWx1ZXMoKV07XG5cdH1cblx0LyoqXG5cdCogQSBzbGlnaHRseSBtb3JlIGFkdmFuY2VkIG1ldGhvZCB0aGF0IGNhbiBiZSB1c2VkIHRvIGdldCBhbiBleGlzdGluZyBxdWVyeSBpbnN0YW5jZSBmcm9tIHRoZVxuXHQqIGNhY2hlLiBUaGlzIGluc3RhbmNlIG5vdCBvbmx5IGNvbnRhaW5zIGFsbCB0aGUgc3RhdGUgZm9yIHRoZSBxdWVyeSwgYnV0IGFsbCBvZiB0aGUgaW5zdGFuY2VzLFxuXHQqIGFuZCB1bmRlcmx5aW5nIGd1dHMgb2YgdGhlIHF1ZXJ5IGFzIHdlbGwuIElmIHRoZSBxdWVyeSBkb2VzIG5vdCBleGlzdCwgYHVuZGVmaW5lZGAgaXNcblx0KiByZXR1cm5lZC5cblx0KlxuXHQqIFRoaXMgaXMgbm90IHR5cGljYWxseSBuZWVkZWQgZm9yIG1vc3QgYXBwbGljYXRpb25zLCBidXQgY2FuIGNvbWUgaW4gaGFuZHkgd2hlbiBuZWVkaW5nIG1vcmVcblx0KiBpbmZvcm1hdGlvbiBhYm91dCBhIHF1ZXJ5IGluIHJhcmUgc2NlbmFyaW9zIChlLmcuIGxvb2tpbmcgYXQgYHF1ZXJ5LnN0YXRlLmRhdGFVcGRhdGVkQXRgIHRvXG5cdCogZGVjaWRlIHdoZXRoZXIgYSBxdWVyeSBpcyBmcmVzaCBlbm91Z2ggdG8gYmUgdXNlZCBhcyBhbiBpbml0aWFsIHZhbHVlKS5cblx0KiBAcGFyYW0gZmlsdGVycyAtIFRoZSBmaWx0ZXJzIHRvIG1hdGNoLCBpbmNsdWRpbmcgdGhlIHJlcXVpcmVkIGBxdWVyeUtleWAuIGBleGFjdGAgZGVmYXVsdHMgdG9cblx0KiBgdHJ1ZWAuXG5cdCogQHJldHVybnMgVGhlIGZpcnN0IG1hdGNoaW5nIHF1ZXJ5LCBvciBgdW5kZWZpbmVkYC5cblx0KiBAc2VlIHtAbGluayBRdWVyeUNhY2hlI2ZpbmRBbGx9XG5cdCogQGV4YW1wbGVcblx0KiBgYGB0c1xuXHQqIGNvbnN0IHF1ZXJ5Q2FjaGUgPSBxdWVyeUNsaWVudC5nZXRRdWVyeUNhY2hlKClcblx0KlxuXHQqIGNvbnN0IHF1ZXJ5ID0gcXVlcnlDYWNoZS5maW5kKHsgcXVlcnlLZXk6IFsncG9zdHMnXSB9KVxuXHQqIGBgYFxuXHQqL1xuXHRmaW5kKGZpbHRlcnMpIHtcblx0XHRjb25zdCBkZWZhdWx0ZWRGaWx0ZXJzID0ge1xuXHRcdFx0ZXhhY3Q6IHRydWUsXG5cdFx0XHQuLi5maWx0ZXJzXG5cdFx0fTtcblx0XHRyZXR1cm4gdGhpcy5nZXRBbGwoKS5maW5kKChxdWVyeSkgPT4gbWF0Y2hRdWVyeShkZWZhdWx0ZWRGaWx0ZXJzLCBxdWVyeSkpO1xuXHR9XG5cdC8qKlxuXHQqIEFuIGV2ZW4gbW9yZSBhZHZhbmNlZCBtZXRob2QgdGhhdCBjYW4gYmUgdXNlZCB0byBnZXQgZXhpc3RpbmcgcXVlcnkgaW5zdGFuY2VzIGZyb20gdGhlIGNhY2hlXG5cdCogdGhhdCBwYXJ0aWFsbHkgbWF0Y2ggYSBxdWVyeSBrZXkuIElmIG5vIHF1ZXJpZXMgbWF0Y2gsIGFuIGVtcHR5IGFycmF5IGlzIHJldHVybmVkLlxuXHQqXG5cdCogVGhpcyBpcyBub3QgdHlwaWNhbGx5IG5lZWRlZCBmb3IgbW9zdCBhcHBsaWNhdGlvbnMsIGJ1dCBjYW4gY29tZSBpbiBoYW5keSB3aGVuIG5lZWRpbmcgbW9yZVxuXHQqIGluZm9ybWF0aW9uIGFib3V0IHF1ZXJpZXMgaW4gcmFyZSBzY2VuYXJpb3MuXG5cdCogQHBhcmFtIGZpbHRlcnMgLSBUaGUgZmlsdGVycyB0byBtYXRjaC4gV2l0aG91dCBmaWx0ZXJzLCBldmVyeSBxdWVyeSBpcyByZXR1cm5lZC5cblx0KiBAcmV0dXJucyBUaGUgbWF0Y2hpbmcgcXVlcmllcy5cblx0KiBAc2VlIHtAbGluayBRdWVyeUNhY2hlI2ZpbmR9XG5cdCogQGV4YW1wbGVcblx0KiBgYGB0c1xuXHQqIGNvbnN0IHF1ZXJ5Q2FjaGUgPSBxdWVyeUNsaWVudC5nZXRRdWVyeUNhY2hlKClcblx0KlxuXHQqIGNvbnN0IHF1ZXJpZXMgPSBxdWVyeUNhY2hlLmZpbmRBbGwoeyBxdWVyeUtleTogWydwb3N0cyddIH0pXG5cdCogYGBgXG5cdCovXG5cdGZpbmRBbGwoZmlsdGVycyA9IHt9KSB7XG5cdFx0Y29uc3QgcXVlcmllcyA9IHRoaXMuZ2V0QWxsKCk7XG5cdFx0cmV0dXJuIE9iamVjdC5rZXlzKGZpbHRlcnMpLmxlbmd0aCA+IDAgPyBxdWVyaWVzLmZpbHRlcigocXVlcnkpID0+IG1hdGNoUXVlcnkoZmlsdGVycywgcXVlcnkpKSA6IHF1ZXJpZXM7XG5cdH1cblx0LyoqXG5cdCogTm90aWZpZXMgZXZlcnkgY2FjaGUgbGlzdGVuZXIgb2YgYW4gZXZlbnQsIGluIG9uZSBiYXRjaC5cblx0KiBAaW50ZXJuYWxcblx0KiBAcGFyYW0gZXZlbnQgLSBUaGUgZXZlbnQgcGFzc2VkIHRvIGV2ZXJ5IGxpc3RlbmVyLlxuXHQqL1xuXHRub3RpZnkoZXZlbnQpIHtcblx0XHRub3RpZnlNYW5hZ2VyLmJhdGNoKCgpID0+IHtcblx0XHRcdHRoaXMubGlzdGVuZXJzLmZvckVhY2goKGxpc3RlbmVyKSA9PiB7XG5cdFx0XHRcdGxpc3RlbmVyKGV2ZW50KTtcblx0XHRcdH0pO1xuXHRcdH0pO1xuXHR9XG5cdC8qKlxuXHQqIENhbGxzIHtAbGluayBRdWVyeSNvbkZvY3VzfSBvbiBldmVyeSBjYWNoZWQgcXVlcnksIGluIG9uZSBiYXRjaC5cblx0KiBAaW50ZXJuYWxcblx0Ki9cblx0b25Gb2N1cygpIHtcblx0XHRub3RpZnlNYW5hZ2VyLmJhdGNoKCgpID0+IHtcblx0XHRcdHRoaXMuZ2V0QWxsKCkuZm9yRWFjaCgocXVlcnkpID0+IHtcblx0XHRcdFx0cXVlcnkub25Gb2N1cygpO1xuXHRcdFx0fSk7XG5cdFx0fSk7XG5cdH1cblx0LyoqXG5cdCogQ2FsbHMge0BsaW5rIFF1ZXJ5I29uT25saW5lfSBvbiBldmVyeSBjYWNoZWQgcXVlcnksIGluIG9uZSBiYXRjaC5cblx0KiBAaW50ZXJuYWxcblx0Ki9cblx0b25PbmxpbmUoKSB7XG5cdFx0bm90aWZ5TWFuYWdlci5iYXRjaCgoKSA9PiB7XG5cdFx0XHR0aGlzLmdldEFsbCgpLmZvckVhY2goKHF1ZXJ5KSA9PiB7XG5cdFx0XHRcdHF1ZXJ5Lm9uT25saW5lKCk7XG5cdFx0XHR9KTtcblx0XHR9KTtcblx0fVxufTtcbmV4cG9ydCB7IFF1ZXJ5Q2FjaGUgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9cXVlcnlDYWNoZS5qcy5tYXAiLCJpbXBvcnQgeyBmdW5jdGlvbmFsVXBkYXRlLCBoYXNoS2V5LCBoYXNoUXVlcnlLZXlCeU9wdGlvbnMsIG5vb3AsIHBhcnRpYWxNYXRjaEtleSwgcmVzb2x2ZVF1ZXJ5VmFsdWUsIHNraXBUb2tlbiB9IGZyb20gXCIuL3V0aWxzLmpzXCI7XG5pbXBvcnQgeyBmb2N1c01hbmFnZXIgfSBmcm9tIFwiLi9mb2N1c01hbmFnZXIuanNcIjtcbmltcG9ydCB7IG5vdGlmeU1hbmFnZXIgfSBmcm9tIFwiLi9ub3RpZnlNYW5hZ2VyLmpzXCI7XG5pbXBvcnQgeyBvbmxpbmVNYW5hZ2VyIH0gZnJvbSBcIi4vb25saW5lTWFuYWdlci5qc1wiO1xuaW1wb3J0IHsgTXV0YXRpb25DYWNoZSB9IGZyb20gXCIuL211dGF0aW9uQ2FjaGUuanNcIjtcbmltcG9ydCB7IFF1ZXJ5Q2FjaGUgfSBmcm9tIFwiLi9xdWVyeUNhY2hlLmpzXCI7XG4vLyBzcmMvcXVlcnlDbGllbnQudHNcbi8qKlxuKiBgUXVlcnlDbGllbnRgIGlzIHVzZWQgdG8gaW50ZXJhY3Qgd2l0aCBhIGNhY2hlIG9mIHF1ZXJpZXMgYW5kIG11dGF0aW9ucy4gSXQgb3ducyBhXG4qIGBRdWVyeUNhY2hlYCBhbmQgYSBgTXV0YXRpb25DYWNoZWAgKGNyZWF0aW5nIGRlZmF1bHQgb25lcyBpZiBub25lIGFyZSBwYXNzZWQgaW4pIGFuZCBob2xkc1xuKiB0aGUgZGVmYXVsdCBvcHRpb25zIHRoYXQgYXJlIGFwcGxpZWQgdG8gcXVlcmllcyBhbmQgbXV0YXRpb25zIGNyZWF0ZWQgdGhyb3VnaCBpdC5cbiogQGV4YW1wbGVcbiogYGBgdHNcbiogY29uc3QgcXVlcnlDbGllbnQgPSBuZXcgUXVlcnlDbGllbnQoe1xuKiAgIGRlZmF1bHRPcHRpb25zOiB7XG4qICAgICBxdWVyaWVzOiB7XG4qICAgICAgIHN0YWxlVGltZTogSW5maW5pdHksXG4qICAgICB9LFxuKiAgIH0sXG4qIH0pXG4qXG4qIGF3YWl0IHF1ZXJ5Q2xpZW50LnF1ZXJ5KHsgcXVlcnlLZXk6IFsncG9zdHMnXSwgcXVlcnlGbjogZmV0Y2hQb3N0cyB9KVxuKiBgYGBcbiovXG52YXIgUXVlcnlDbGllbnQgPSBjbGFzcyB7XG5cdCNxdWVyeUNhY2hlO1xuXHQjbXV0YXRpb25DYWNoZTtcblx0I2RlZmF1bHRPcHRpb25zO1xuXHQjcXVlcnlEZWZhdWx0cztcblx0I211dGF0aW9uRGVmYXVsdHM7XG5cdCNtb3VudENvdW50O1xuXHQjdW5zdWJzY3JpYmVGb2N1cztcblx0I3Vuc3Vic2NyaWJlT25saW5lO1xuXHRjb25zdHJ1Y3Rvcihjb25maWcgPSB7fSkge1xuXHRcdHRoaXMuI3F1ZXJ5Q2FjaGUgPSBjb25maWcucXVlcnlDYWNoZSB8fCBuZXcgUXVlcnlDYWNoZSgpO1xuXHRcdHRoaXMuI211dGF0aW9uQ2FjaGUgPSBjb25maWcubXV0YXRpb25DYWNoZSB8fCBuZXcgTXV0YXRpb25DYWNoZSgpO1xuXHRcdHRoaXMuI2RlZmF1bHRPcHRpb25zID0gY29uZmlnLmRlZmF1bHRPcHRpb25zIHx8IHt9O1xuXHRcdHRoaXMuI3F1ZXJ5RGVmYXVsdHMgPSAvKiBAX19QVVJFX18gKi8gbmV3IE1hcCgpO1xuXHRcdHRoaXMuI211dGF0aW9uRGVmYXVsdHMgPSAvKiBAX19QVVJFX18gKi8gbmV3IE1hcCgpO1xuXHRcdHRoaXMuI21vdW50Q291bnQgPSAwO1xuXHR9XG5cdC8qKlxuXHQqIENhbGxlZCBieSBhIGZyYW1ld29yayBhZGFwdGVyJ3MgYFF1ZXJ5Q2xpZW50UHJvdmlkZXJgLWVxdWl2YWxlbnQgd2hlbiBpdCBtb3VudHMsIHRvIHN0YXJ0XG5cdCogbGlzdGVuaW5nIGZvciBmb2N1cy9vbmxpbmUgZXZlbnRzIGFuZCByZXN1bWUgcGF1c2VkIG11dGF0aW9ucy4gUmVmLWNvdW50ZWQgdmlhIGFuIGludGVybmFsXG5cdCogbW91bnQgY291bnQsIHNvIG5lc3RlZCBvciBtdWx0aXBsZSBwcm92aWRlcnMgc2hhcmluZyB0aGUgc2FtZSBgUXVlcnlDbGllbnRgIGRvbid0IHRlYXIgZG93blxuXHQqIHRoZSBzaGFyZWQgbGlzdGVuZXJzIHVudGlsIHRoZSBsYXN0IG9uZSB1bm1vdW50cy5cblx0Ki9cblx0bW91bnQoKSB7XG5cdFx0dGhpcy4jbW91bnRDb3VudCsrO1xuXHRcdGlmICh0aGlzLiNtb3VudENvdW50ICE9PSAxKSByZXR1cm47XG5cdFx0dGhpcy4jdW5zdWJzY3JpYmVGb2N1cyA9IGZvY3VzTWFuYWdlci5zdWJzY3JpYmUoYXN5bmMgKGZvY3VzZWQpID0+IHtcblx0XHRcdGlmIChmb2N1c2VkKSB7XG5cdFx0XHRcdGF3YWl0IHRoaXMucmVzdW1lUGF1c2VkTXV0YXRpb25zKCk7XG5cdFx0XHRcdHRoaXMuI3F1ZXJ5Q2FjaGUub25Gb2N1cygpO1xuXHRcdFx0fVxuXHRcdH0pO1xuXHRcdHRoaXMuI3Vuc3Vic2NyaWJlT25saW5lID0gb25saW5lTWFuYWdlci5zdWJzY3JpYmUoYXN5bmMgKG9ubGluZSkgPT4ge1xuXHRcdFx0aWYgKG9ubGluZSkge1xuXHRcdFx0XHRhd2FpdCB0aGlzLnJlc3VtZVBhdXNlZE11dGF0aW9ucygpO1xuXHRcdFx0XHR0aGlzLiNxdWVyeUNhY2hlLm9uT25saW5lKCk7XG5cdFx0XHR9XG5cdFx0fSk7XG5cdH1cblx0LyoqXG5cdCogVGhlIGludmVyc2Ugb2Yge0BsaW5rIFF1ZXJ5Q2xpZW50I21vdW50fSDigJQgY2FsbGVkIGJ5IGEgZnJhbWV3b3JrIGFkYXB0ZXInc1xuXHQqIGBRdWVyeUNsaWVudFByb3ZpZGVyYC1lcXVpdmFsZW50IHdoZW4gaXQgdW5tb3VudHMuIE9ubHkgdGVhcnMgZG93biB0aGUgZm9jdXMvb25saW5lXG5cdCogbGlzdGVuZXJzIG9uY2UgdGhlIG1vdW50IGNvdW50IHJldHVybnMgdG8gYDBgLlxuXHQqL1xuXHR1bm1vdW50KCkge1xuXHRcdHRoaXMuI21vdW50Q291bnQtLTtcblx0XHRpZiAodGhpcy4jbW91bnRDb3VudCAhPT0gMCkgcmV0dXJuO1xuXHRcdHRoaXMuI3Vuc3Vic2NyaWJlRm9jdXM/LigpO1xuXHRcdHRoaXMuI3Vuc3Vic2NyaWJlRm9jdXMgPSB2b2lkIDA7XG5cdFx0dGhpcy4jdW5zdWJzY3JpYmVPbmxpbmU/LigpO1xuXHRcdHRoaXMuI3Vuc3Vic2NyaWJlT25saW5lID0gdm9pZCAwO1xuXHR9XG5cdC8qKlxuXHQqIFJldHVybnMgdGhlIG51bWJlciBvZiBxdWVyaWVzIGluIHRoZSBjYWNoZSB0aGF0IGFyZSBjdXJyZW50bHkgZmV0Y2hpbmcsIG9wdGlvbmFsbHlcblx0KiBtYXRjaGluZyBhIHNldCBvZiBmaWx0ZXJzLiBUaGlzIGluY2x1ZGVzIGJhY2tncm91bmQtZmV0Y2hpbmcsIGxvYWRpbmcgbmV3IHBhZ2VzLCBhbmRcblx0KiBsb2FkaW5nIG1vcmUgaW5maW5pdGUgcXVlcnkgcmVzdWx0cy5cblx0KiBAcGFyYW0gZmlsdGVycyAtIE5hcnJvd3MgZG93biB3aGljaCBmZXRjaGluZyBxdWVyaWVzIGFyZSBjb3VudGVkLiBXaXRob3V0IGZpbHRlcnMsIGV2ZXJ5XG5cdCogZmV0Y2hpbmcgcXVlcnkgaXMgY291bnRlZC5cblx0KiBAcmV0dXJucyBUaGUgbnVtYmVyIG9mIG1hdGNoaW5nIHF1ZXJpZXMgd2hvc2UgYGZldGNoU3RhdHVzYCBpcyBgJ2ZldGNoaW5nJ2AuXG5cdCogQGV4YW1wbGVcblx0KiBgYGB0c1xuXHQqIGlmIChxdWVyeUNsaWVudC5pc0ZldGNoaW5nKCkpIHtcblx0KiAgIGNvbnNvbGUubG9nKCdBdCBsZWFzdCBvbmUgcXVlcnkgaXMgZmV0Y2hpbmchJylcblx0KiB9XG5cdCogYGBgXG5cdCovXG5cdGlzRmV0Y2hpbmcoZmlsdGVycykge1xuXHRcdHJldHVybiB0aGlzLiNxdWVyeUNhY2hlLmZpbmRBbGwoe1xuXHRcdFx0Li4uZmlsdGVycyxcblx0XHRcdGZldGNoU3RhdHVzOiBcImZldGNoaW5nXCJcblx0XHR9KS5sZW5ndGg7XG5cdH1cblx0LyoqXG5cdCogUmV0dXJucyB0aGUgbnVtYmVyIG9mIG11dGF0aW9ucyBpbiB0aGUgY2FjaGUgdGhhdCBhcmUgY3VycmVudGx5IHBlbmRpbmcsIG9wdGlvbmFsbHlcblx0KiBtYXRjaGluZyBhIHNldCBvZiBmaWx0ZXJzLlxuXHQqIEBwYXJhbSBmaWx0ZXJzIC0gTmFycm93cyBkb3duIHdoaWNoIHBlbmRpbmcgbXV0YXRpb25zIGFyZSBjb3VudGVkLiBXaXRob3V0IGZpbHRlcnMsIGV2ZXJ5XG5cdCogcGVuZGluZyBtdXRhdGlvbiBpcyBjb3VudGVkLlxuXHQqIEByZXR1cm5zIFRoZSBudW1iZXIgb2YgbWF0Y2hpbmcgbXV0YXRpb25zIHdob3NlIGBzdGF0dXNgIGlzIGAncGVuZGluZydgLlxuXHQqIEBleGFtcGxlXG5cdCogYGBgdHNcblx0KiBpZiAocXVlcnlDbGllbnQuaXNNdXRhdGluZygpKSB7XG5cdCogICBjb25zb2xlLmxvZygnQXQgbGVhc3Qgb25lIG11dGF0aW9uIGlzIHBlbmRpbmchJylcblx0KiB9XG5cdCogYGBgXG5cdCovXG5cdGlzTXV0YXRpbmcoZmlsdGVycykge1xuXHRcdHJldHVybiB0aGlzLiNtdXRhdGlvbkNhY2hlLmZpbmRBbGwoe1xuXHRcdFx0Li4uZmlsdGVycyxcblx0XHRcdHN0YXR1czogXCJwZW5kaW5nXCJcblx0XHR9KS5sZW5ndGg7XG5cdH1cblx0LyoqXG5cdCogSW1wZXJhdGl2ZSAobm9uLXJlYWN0aXZlKSB3YXkgdG8gcmV0cmlldmUgZGF0YSBmb3IgYSBRdWVyeUtleS5cblx0KiBTaG91bGQgb25seSBiZSB1c2VkIGluIGNhbGxiYWNrcyBvciBmdW5jdGlvbnMgd2hlcmUgcmVhZGluZyB0aGUgbGF0ZXN0IGRhdGEgaXMgbmVjZXNzYXJ5LCBlLmcuIGZvciBvcHRpbWlzdGljIHVwZGF0ZXMuXG5cdCpcblx0KiBIaW50OiBEbyBub3QgdXNlIHRoaXMgZnVuY3Rpb24gaW5zaWRlIGEgY29tcG9uZW50LCBiZWNhdXNlIGl0IHdvbid0IHJlY2VpdmUgdXBkYXRlcy5cblx0KiBVc2UgYHVzZVF1ZXJ5YCB0byBjcmVhdGUgYSBgUXVlcnlPYnNlcnZlcmAgdGhhdCBzdWJzY3JpYmVzIHRvIGNoYW5nZXMuXG5cdCogQHBhcmFtIHF1ZXJ5S2V5IC0gVGhlIHF1ZXJ5IGtleSBvZiB0aGUgcXVlcnkgdG8gcmVhZC5cblx0KiBAcmV0dXJucyBUaGUgY2FjaGVkIGRhdGEgZm9yIHRoZSBxdWVyeSwgb3IgYHVuZGVmaW5lZGAgaWYgbm8gcXVlcnkgd2l0aCB0aGlzIGtleSBoYXMgYmVlbiBvYnNlcnZlZCB5ZXQuXG5cdCogQHNlZSB7QGxpbmsgUXVlcnlDbGllbnQjZ2V0UXVlcmllc0RhdGF9XG5cdCovXG5cdGdldFF1ZXJ5RGF0YShxdWVyeUtleSkge1xuXHRcdGNvbnN0IG9wdGlvbnMgPSB0aGlzLmRlZmF1bHRRdWVyeU9wdGlvbnMoeyBxdWVyeUtleSB9KTtcblx0XHRyZXR1cm4gdGhpcy4jcXVlcnlDYWNoZS5nZXQob3B0aW9ucy5xdWVyeUhhc2gpPy5zdGF0ZS5kYXRhO1xuXHR9XG5cdC8qKlxuXHQqIFJldHVybnMgdGhlIGNhY2hlZCBkYXRhIG9mIGEgcXVlcnksIG9yIGZldGNoZXMgaXQgaWYgdGhlcmUgaXMgbm9uZS4gV2l0aCBgcmV2YWxpZGF0ZUlmU3RhbGVgLFxuXHQqIHN0YWxlIGNhY2hlZCBkYXRhIGlzIGFsc28gcmVmZXRjaGVkIGluIHRoZSBiYWNrZ3JvdW5kLlxuXHQqIEBwYXJhbSBvcHRpb25zIC0gVGhlIHF1ZXJ5IG9wdGlvbnMuIElmIHRoZSBxdWVyeSBoYXMgbm8gY2FjaGVkIGRhdGEgeWV0LCBpdCBpcyBmZXRjaGVkIHdpdGhcblx0KiB0aGVzZSBvcHRpb25zLlxuXHQqIEByZXR1cm5zIEEgcHJvbWlzZSB0aGF0IHJlc29sdmVzIHRvIHRoZSBjYWNoZWQgZGF0YSwgb3IgdG8gdGhlIGZldGNoZWQgZGF0YSBpZiBub3RoaW5nIHdhc1xuXHQqIGNhY2hlZCB5ZXQuXG5cdCogQGRlcHJlY2F0ZWQgVXNlIHF1ZXJ5Q2xpZW50LnF1ZXJ5KHsgLi4ub3B0aW9ucywgc3RhbGVUaW1lOiAnc3RhdGljJyB9KSBpbnN0ZWFkLiBUaGlzIG1ldGhvZCB3aWxsIGJlIHJlbW92ZWQgaW4gdGhlIG5leHQgbWFqb3IgdmVyc2lvbi5cblx0Ki9cblx0ZW5zdXJlUXVlcnlEYXRhKG9wdGlvbnMpIHtcblx0XHRjb25zdCBkZWZhdWx0ZWRPcHRpb25zID0gdGhpcy5kZWZhdWx0UXVlcnlPcHRpb25zKG9wdGlvbnMpO1xuXHRcdGNvbnN0IHF1ZXJ5ID0gdGhpcy4jcXVlcnlDYWNoZS5idWlsZCh0aGlzLCBkZWZhdWx0ZWRPcHRpb25zKTtcblx0XHRjb25zdCBjYWNoZWREYXRhID0gcXVlcnkuc3RhdGUuZGF0YTtcblx0XHRpZiAoY2FjaGVkRGF0YSA9PT0gdm9pZCAwKSByZXR1cm4gdGhpcy5mZXRjaFF1ZXJ5KG9wdGlvbnMpO1xuXHRcdGlmIChvcHRpb25zLnJldmFsaWRhdGVJZlN0YWxlICYmIHF1ZXJ5LmlzU3RhbGVCeVRpbWUocmVzb2x2ZVF1ZXJ5VmFsdWUoZGVmYXVsdGVkT3B0aW9ucy5zdGFsZVRpbWUsIHF1ZXJ5KSkpIHRoaXMucHJlZmV0Y2hRdWVyeShkZWZhdWx0ZWRPcHRpb25zKTtcblx0XHRyZXR1cm4gUHJvbWlzZS5yZXNvbHZlKGNhY2hlZERhdGEpO1xuXHR9XG5cdC8qKlxuXHQqIEltcGVyYXRpdmUgKG5vbi1yZWFjdGl2ZSkgd2F5IHRvIHJldHJpZXZlIHRoZSBjYWNoZWQgZGF0YSBvZiBtdWx0aXBsZSBxdWVyaWVzIGF0IG9uY2UuXG5cdCogT25seSBxdWVyaWVzIG1hdGNoaW5nIHRoZSBnaXZlbiBmaWx0ZXJzIGFyZSByZXR1cm5lZDsgaWYgbm9uZSBtYXRjaCwgYW4gZW1wdHkgYXJyYXkgaXNcblx0KiByZXR1cm5lZC5cblx0KlxuXHQqIEJlY2F1c2UgdGhlIG1hdGNoZWQgcXVlcmllcyBjYW4gaG9sZCBkYXRhIG9mIGRpZmZlcmVudCBzaGFwZXMgKGUuZy4gYSBicm9hZCBmaWx0ZXIgY2FuIG1hdGNoXG5cdCogcXVlcmllcyB3aXRoIHVucmVsYXRlZCBkYXRhIHR5cGVzKSwgdGhlIGBUUXVlcnlGbkRhdGFgIGdlbmVyaWMgZGVmYXVsdHMgdG8gYHVua25vd25gIHJhdGhlclxuXHQqIHRoYW4gYmVpbmcgaW5mZXJyZWQuIFBhc3NpbmcgYSBtb3JlIHNwZWNpZmljIHR5cGUgaXMgYSBjb252ZW5pZW5jZSBmb3IgY2FsbCBzaXRlcyB0aGF0IGtub3dcblx0KiBldmVyeSBtYXRjaGVkIHF1ZXJ5IGhvbGRzIHRoZSBzYW1lIHNoYXBlIOKAlCBpdCBpcyBub3QgY2hlY2tlZCBhZ2FpbnN0IHRoZSBhY3R1YWwgY2FjaGVcblx0KiBjb250ZW50cy5cblx0KiBAcGFyYW0gZmlsdGVycyAtIFRoZSBmaWx0ZXJzIHRoYXQgc2VsZWN0IHdoaWNoIHF1ZXJpZXMgdG8gcmVhZC5cblx0KiBAcmV0dXJucyBBbiBhcnJheSBvZiBxdWVyeSBrZXkgYW5kIGRhdGEgcGFpcnMuIFRoZSBkYXRhIGlzIGB1bmRlZmluZWRgIGZvciBhIHF1ZXJ5IHdpdGggbm8gY2FjaGVkIGRhdGEuXG5cdCogQHNlZSB7QGxpbmsgUXVlcnlDbGllbnQjZ2V0UXVlcnlEYXRhfVxuXHQqIEBleGFtcGxlXG5cdCogYGBgdHNcblx0KiBjb25zdCBkYXRhID0gcXVlcnlDbGllbnQuZ2V0UXVlcmllc0RhdGEoeyBxdWVyeUtleTogWydwb3N0cyddIH0pXG5cdCogYGBgXG5cdCovXG5cdGdldFF1ZXJpZXNEYXRhKGZpbHRlcnMpIHtcblx0XHRyZXR1cm4gdGhpcy4jcXVlcnlDYWNoZS5maW5kQWxsKGZpbHRlcnMpLm1hcCgoeyBxdWVyeUtleSwgc3RhdGUgfSkgPT4ge1xuXHRcdFx0cmV0dXJuIFtxdWVyeUtleSwgc3RhdGUuZGF0YV07XG5cdFx0fSk7XG5cdH1cblx0LyoqXG5cdCogU3luY2hyb25vdXMgd2F5IHRvIGltbWVkaWF0ZWx5IHVwZGF0ZSBhIHF1ZXJ5J3MgY2FjaGVkIGRhdGEuIElmIHRoZSB1cGRhdGVyIChvciB0aGUgdmFsdWVcblx0KiBwYXNzZWQpIHJlc29sdmVzIHRvIGB1bmRlZmluZWRgLCB0aGUgY2FjaGUgaXMgbGVmdCB1bnRvdWNoZWQgYW5kIG5vIHF1ZXJ5IGlzIGNyZWF0ZWQ7XG5cdCogb3RoZXJ3aXNlLCBpZiB0aGUgcXVlcnkgZG9lcyBub3QgZXhpc3QgeWV0LCBpdCB3aWxsIGJlIGNyZWF0ZWQuIFRvIHVwZGF0ZSBtdWx0aXBsZSBxdWVyaWVzXG5cdCogYXQgb25jZSBieSBwYXJ0aWFsbHkgbWF0Y2hpbmcgcXVlcnkga2V5cywgdXNlIHtAbGluayBRdWVyeUNsaWVudCNzZXRRdWVyaWVzRGF0YX0gaW5zdGVhZC5cblx0KlxuXHQqIFVwZGF0ZXMgbXVzdCBiZSBwZXJmb3JtZWQgaW1tdXRhYmx5OiBkbyBub3QgbXV0YXRlIGBvbGREYXRhYCwgb3IgZGF0YSBwcmV2aW91c2x5IHJldHJpZXZlZFxuXHQqIHZpYSB7QGxpbmsgUXVlcnlDbGllbnQjZ2V0UXVlcnlEYXRhfSwgaW4gcGxhY2UuXG5cdCogQHBhcmFtIHF1ZXJ5S2V5IC0gVGhlIHF1ZXJ5IGtleSB0byBzZXQgZGF0YSBmb3IuXG5cdCogQHBhcmFtIHVwZGF0ZXIgLSBFaXRoZXIgdGhlIG5ldyBkYXRhLCBvciBhIGZ1bmN0aW9uIHRoYXQgcmVjZWl2ZXMgdGhlIGN1cnJlbnQgZGF0YSAod2hpY2hcblx0KiBtYXkgYmUgYHVuZGVmaW5lZGApIGFuZCByZXR1cm5zIHRoZSBuZXcgZGF0YS5cblx0KiBAcGFyYW0gb3B0aW9ucyAtIFNldCBgdXBkYXRlZEF0YCB0byBvdmVycmlkZSB0aGUgdGltZXN0YW1wIHRoZSB3cml0dGVuIGRhdGEgaXMgcmVjb3JkZWQgd2l0aC5cblx0KiBAcmV0dXJucyBUaGUgZGF0YSB0aGF0IHdhcyB3cml0dGVuLCBvciBgdW5kZWZpbmVkYCBpZiB0aGUgdXBkYXRlciByZXR1cm5lZCBgdW5kZWZpbmVkYCDigJQgaW4gdGhhdCBjYXNlXG5cdCogdGhlIHdyaXRlIGlzIHNraXBwZWQgYW5kIHRoZSBjYWNoZSBpcyBsZWZ0IHVuY2hhbmdlZC5cblx0KiBAZXhhbXBsZVxuXHQqIGBgYHRzXG5cdCogcXVlcnlDbGllbnQuc2V0UXVlcnlEYXRhKFsncG9zdHMnXSwgbmV3UG9zdHMpXG5cdCpcblx0KiAvLyBPciwgdXNpbmcgYW4gdXBkYXRlciBmdW5jdGlvbiB0aGF0IHJlY2VpdmVzIHRoZSBjdXJyZW50IGRhdGE6XG5cdCogcXVlcnlDbGllbnQuc2V0UXVlcnlEYXRhKFsncG9zdHMnXSwgKG9sZFBvc3RzKSA9PiBbLi4ub2xkUG9zdHMsIG5ld1Bvc3RdKVxuXHQqIGBgYFxuXHQqL1xuXHRzZXRRdWVyeURhdGEocXVlcnlLZXksIHVwZGF0ZXIsIG9wdGlvbnMpIHtcblx0XHRjb25zdCBkZWZhdWx0ZWRPcHRpb25zID0gdGhpcy5kZWZhdWx0UXVlcnlPcHRpb25zKHsgcXVlcnlLZXkgfSk7XG5cdFx0Y29uc3QgcHJldkRhdGEgPSB0aGlzLiNxdWVyeUNhY2hlLmdldChkZWZhdWx0ZWRPcHRpb25zLnF1ZXJ5SGFzaCk/LnN0YXRlLmRhdGE7XG5cdFx0Y29uc3QgZGF0YSA9IGZ1bmN0aW9uYWxVcGRhdGUodXBkYXRlciwgcHJldkRhdGEpO1xuXHRcdGlmIChkYXRhID09PSB2b2lkIDApIHJldHVybjtcblx0XHRyZXR1cm4gdGhpcy4jcXVlcnlDYWNoZS5idWlsZCh0aGlzLCBkZWZhdWx0ZWRPcHRpb25zKS5zZXREYXRhKGRhdGEsIHtcblx0XHRcdC4uLm9wdGlvbnMsXG5cdFx0XHRtYW51YWw6IHRydWVcblx0XHR9KTtcblx0fVxuXHQvKipcblx0KiBTeW5jaHJvbm91cyB3YXkgdG8gaW1tZWRpYXRlbHkgdXBkYXRlIHRoZSBjYWNoZWQgZGF0YSBvZiBtdWx0aXBsZSBxdWVyaWVzIGF0IG9uY2UsIHVzaW5nXG5cdCogZmlsdGVycyBvciBwYXJ0aWFsIHF1ZXJ5IGtleSBtYXRjaGluZy4gT25seSBxdWVyaWVzIHRoYXQgYWxyZWFkeSBleGlzdCBhbmQgbWF0Y2ggdGhlIGdpdmVuXG5cdCogZmlsdGVycyBhcmUgdXBkYXRlZDsgbm8gbmV3IGNhY2hlIGVudHJpZXMgYXJlIGNyZWF0ZWQuIEludGVybmFsbHkgdGhpcyBjYWxsc1xuXHQqIHtAbGluayBRdWVyeUNsaWVudCNzZXRRdWVyeURhdGF9IGZvciBlYWNoIG1hdGNoaW5nIHF1ZXJ5LlxuXHQqIEBwYXJhbSBmaWx0ZXJzIC0gVGhlIGZpbHRlcnMgdGhhdCBzZWxlY3Qgd2hpY2ggZXhpc3RpbmcgcXVlcmllcyB0byB1cGRhdGUuXG5cdCogQHBhcmFtIHVwZGF0ZXIgLSBFaXRoZXIgdGhlIG5ldyBkYXRhLCBvciBhIGZ1bmN0aW9uIHRoYXQgcmVjZWl2ZXMgZWFjaCBtYXRjaGVkIHF1ZXJ5J3MgY3VycmVudFxuXHQqIGRhdGEgKHdoaWNoIG1heSBiZSBgdW5kZWZpbmVkYCkgYW5kIHJldHVybnMgdGhlIG5ldyBkYXRhLlxuXHQqIEBwYXJhbSBvcHRpb25zIC0gU2V0IGB1cGRhdGVkQXRgIHRvIG92ZXJyaWRlIHRoZSB0aW1lc3RhbXAgdGhlIHdyaXR0ZW4gZGF0YSBpcyByZWNvcmRlZCB3aXRoLlxuXHQqIEByZXR1cm5zIE9uZSBgW3F1ZXJ5S2V5LCBkYXRhXWAgdHVwbGUgcGVyIG1hdGNoZWQgcXVlcnksIGluIHRoZSBzYW1lIHNoYXBlIGFuZCB3aXRoIHRoZSBzYW1lXG5cdCogYHVuZGVmaW5lZGAgY2FzZSBhcyB7QGxpbmsgUXVlcnlDbGllbnQjc2V0UXVlcnlEYXRhfS5cblx0KiBAZXhhbXBsZVxuXHQqIGBgYHRzXG5cdCogcXVlcnlDbGllbnQuc2V0UXVlcmllc0RhdGEoeyBxdWVyeUtleTogWydwb3N0cyddIH0sIChvbGRQb3N0cykgPT5cblx0KiAgIG9sZFBvc3RzID8gb2xkUG9zdHMuZmlsdGVyKChwb3N0KSA9PiBwb3N0LmlkICE9PSBkZWxldGVkSWQpIDogb2xkUG9zdHMsXG5cdCogKVxuXHQqIGBgYFxuXHQqL1xuXHRzZXRRdWVyaWVzRGF0YShmaWx0ZXJzLCB1cGRhdGVyLCBvcHRpb25zKSB7XG5cdFx0cmV0dXJuIG5vdGlmeU1hbmFnZXIuYmF0Y2goKCkgPT4gdGhpcy4jcXVlcnlDYWNoZS5maW5kQWxsKGZpbHRlcnMpLm1hcCgoeyBxdWVyeUtleSB9KSA9PiBbcXVlcnlLZXksIHRoaXMuc2V0UXVlcnlEYXRhKHF1ZXJ5S2V5LCB1cGRhdGVyLCBvcHRpb25zKV0pKTtcblx0fVxuXHQvKipcblx0KiBJbXBlcmF0aXZlIChub24tcmVhY3RpdmUpIHdheSB0byByZXRyaWV2ZSBhbiBleGlzdGluZyBxdWVyeSdzIHN0YXRlLiBJZiB0aGUgcXVlcnkgZG9lcyBub3Rcblx0KiBleGlzdCwgYHVuZGVmaW5lZGAgaXMgcmV0dXJuZWQuXG5cdCogQHBhcmFtIHF1ZXJ5S2V5IC0gVGhlIHF1ZXJ5IGtleSBvZiB0aGUgcXVlcnkgdG8gcmVhZC5cblx0KiBAcmV0dXJucyBUaGUgcXVlcnkncyBzdGF0ZSwgb3IgYHVuZGVmaW5lZGAgaWYgbm8gcXVlcnkgd2l0aCB0aGlzIGtleSBleGlzdHMuXG5cdCogQGV4YW1wbGVcblx0KiBgYGB0c1xuXHQqIGNvbnN0IHN0YXRlID0gcXVlcnlDbGllbnQuZ2V0UXVlcnlTdGF0ZShbJ3Bvc3RzJ10pXG5cdCogY29uc29sZS5sb2coc3RhdGU/LmRhdGFVcGRhdGVkQXQpXG5cdCogYGBgXG5cdCovXG5cdGdldFF1ZXJ5U3RhdGUocXVlcnlLZXkpIHtcblx0XHRjb25zdCBvcHRpb25zID0gdGhpcy5kZWZhdWx0UXVlcnlPcHRpb25zKHsgcXVlcnlLZXkgfSk7XG5cdFx0cmV0dXJuIHRoaXMuI3F1ZXJ5Q2FjaGUuZ2V0KG9wdGlvbnMucXVlcnlIYXNoKT8uc3RhdGU7XG5cdH1cblx0LyoqXG5cdCogUmVtb3ZlcyBxdWVyaWVzIGZyb20gdGhlIGNhY2hlIHRoYXQgbWF0Y2ggdGhlIGdpdmVuIGZpbHRlcnMuIFVubGlrZVxuXHQqIHtAbGluayBRdWVyeUNsaWVudCNpbnZhbGlkYXRlUXVlcmllc30gb3Ige0BsaW5rIFF1ZXJ5Q2xpZW50I3JlZmV0Y2hRdWVyaWVzfSwgdGhpcyByZW1vdmVzXG5cdCogbWF0Y2hpbmcgcXVlcmllcyBmcm9tIHRoZSBjYWNoZSBpbnN0ZWFkIG9mIHJlZmV0Y2hpbmcgdGhlbS4gV2l0aG91dCBmaWx0ZXJzLCBldmVyeSBxdWVyeSBpblxuXHQqIHRoZSBjYWNoZSBpcyByZW1vdmVkLlxuXHQqIEBwYXJhbSBmaWx0ZXJzIC0gVGhlIGZpbHRlcnMgdGhhdCBzZWxlY3Qgd2hpY2ggcXVlcmllcyB0byByZW1vdmUuIFdpdGhvdXQgZmlsdGVycywgZXZlcnkgcXVlcnlcblx0KiBpcyByZW1vdmVkLlxuXHQqIEBleGFtcGxlXG5cdCogYGBgdHNcblx0KiBxdWVyeUNsaWVudC5yZW1vdmVRdWVyaWVzKHsgcXVlcnlLZXk6IFsncG9zdHMnXSwgZXhhY3Q6IHRydWUgfSlcblx0KiBgYGBcblx0Ki9cblx0cmVtb3ZlUXVlcmllcyhmaWx0ZXJzKSB7XG5cdFx0Y29uc3QgcXVlcnlDYWNoZSA9IHRoaXMuI3F1ZXJ5Q2FjaGU7XG5cdFx0bm90aWZ5TWFuYWdlci5iYXRjaCgoKSA9PiB7XG5cdFx0XHRxdWVyeUNhY2hlLmZpbmRBbGwoZmlsdGVycykuZm9yRWFjaCgocXVlcnkpID0+IHtcblx0XHRcdFx0cXVlcnlDYWNoZS5yZW1vdmUocXVlcnkpO1xuXHRcdFx0fSk7XG5cdFx0fSk7XG5cdH1cblx0LyoqXG5cdCogUmVzZXRzIHF1ZXJpZXMgbWF0Y2hpbmcgdGhlIGdpdmVuIGZpbHRlcnMgYmFjayB0byB0aGVpciBpbml0aWFsIHN0YXRlIChlLmcuIGFueVxuXHQqIGBpbml0aWFsRGF0YWApLCBub3RpZnlpbmcgc3Vic2NyaWJlcnMgcmF0aGVyIHRoYW4gcmVtb3ZpbmcgdGhlbS4gQWN0aXZlIHF1ZXJpZXMgYW1vbmcgdGhlXG5cdCogbWF0Y2hlZCBzZXQgYXJlIHRoZW4gcmVmZXRjaGVkLCBhbmQgdGhlIHJldHVybmVkIHByb21pc2UgcmVzb2x2ZXMgb25jZSB0aGF0IHJlZmV0Y2ggc2V0dGxlcy5cblx0KiBAcGFyYW0gZmlsdGVycyAtIFRoZSBmaWx0ZXJzIHRoYXQgc2VsZWN0IHdoaWNoIHF1ZXJpZXMgdG8gcmVzZXQuIFdpdGhvdXQgZmlsdGVycywgZXZlcnkgcXVlcnlcblx0KiBpcyByZXNldC5cblx0KiBAcGFyYW0gb3B0aW9ucyAtIFBhc3NlZCB0byB0aGUgcmVmZXRjaCBvZiB0aGUgYWN0aXZlIG1hdGNoZWQgcXVlcmllcywgZS5nLiBgY2FuY2VsUmVmZXRjaGAgYW5kXG5cdCogYHRocm93T25FcnJvcmAuXG5cdCogQHJldHVybnMgQSBwcm9taXNlIHRoYXQgcmVzb2x2ZXMgb25jZSB0aGUgcmVmZXRjaCBvZiB0aGUgYWN0aXZlIG1hdGNoZWQgcXVlcmllcyBzZXR0bGVzLlxuXHQqIEBleGFtcGxlXG5cdCogYGBgdHNcblx0KiBhd2FpdCBxdWVyeUNsaWVudC5yZXNldFF1ZXJpZXMoeyBxdWVyeUtleTogWydwb3N0cyddLCBleGFjdDogdHJ1ZSB9KVxuXHQqIGBgYFxuXHQqL1xuXHRyZXNldFF1ZXJpZXMoZmlsdGVycywgb3B0aW9ucykge1xuXHRcdGNvbnN0IHF1ZXJ5Q2FjaGUgPSB0aGlzLiNxdWVyeUNhY2hlO1xuXHRcdHJldHVybiBub3RpZnlNYW5hZ2VyLmJhdGNoKCgpID0+IHtcblx0XHRcdGNvbnN0IG1hdGNoZWQgPSBxdWVyeUNhY2hlLmZpbmRBbGwoZmlsdGVycyk7XG5cdFx0XHRjb25zdCBxdWVyaWVzVG9SZWZldGNoID0gbmV3IFNldChtYXRjaGVkKTtcblx0XHRcdG1hdGNoZWQuZm9yRWFjaCgocXVlcnkpID0+IHtcblx0XHRcdFx0cXVlcnkucmVzZXQoKTtcblx0XHRcdH0pO1xuXHRcdFx0cmV0dXJuIHRoaXMucmVmZXRjaFF1ZXJpZXMoe1xuXHRcdFx0XHR0eXBlOiBcImFjdGl2ZVwiLFxuXHRcdFx0XHRwcmVkaWNhdGU6IChxdWVyeSkgPT4gcXVlcmllc1RvUmVmZXRjaC5oYXMocXVlcnkpXG5cdFx0XHR9LCBvcHRpb25zKTtcblx0XHR9KTtcblx0fVxuXHQvKipcblx0KiBDYW5jZWxzIG91dGdvaW5nIGZldGNoZXMgZm9yIHF1ZXJpZXMgbWF0Y2hpbmcgdGhlIGdpdmVuIGZpbHRlcnMuIE1vc3QgdXNlZnVsIHdoZW4gcGVyZm9ybWluZ1xuXHQqIG9wdGltaXN0aWMgdXBkYXRlcywgc2luY2UgYW55IG91dGdvaW5nIHJlZmV0Y2ggdGhhdCByZXNvbHZlcyBhZnRlcndhcmRzIHdvdWxkIG90aGVyd2lzZVxuXHQqIG92ZXJ3cml0ZSB0aGUgb3B0aW1pc3RpYyB1cGRhdGUuIEJ5IGRlZmF1bHQgKGByZXZlcnQ6IHRydWVgKSwgYSBjYW5jZWxsZWQgcXVlcnkncyBkYXRhIGlzXG5cdCogcmV2ZXJ0ZWQgdG8gaXRzIHN0YXRlIGJlZm9yZSB0aGUgb3V0Z29pbmcgZmV0Y2ggc3RhcnRlZC5cblx0KlxuXHQqIFRoZSByZXR1cm5lZCBwcm9taXNlIG5ldmVyIHJlamVjdHMsIGV2ZW4gaWYgaW5kaXZpZHVhbCBjYW5jZWxsYXRpb25zIGZhaWwuXG5cdCogQHBhcmFtIGZpbHRlcnMgLSBUaGUgZmlsdGVycyB0aGF0IHNlbGVjdCB3aGljaCBxdWVyaWVzIHRvIGNhbmNlbC4gV2l0aG91dCBmaWx0ZXJzLCBldmVyeSBxdWVyeVxuXHQqIGlzIGNhbmNlbGxlZC5cblx0KiBAcGFyYW0gY2FuY2VsT3B0aW9ucyAtIFBhc3NlZCB0byBlYWNoIG1hdGNoZWQgcXVlcnkncyBjYW5jZWxsYXRpb24uIGByZXZlcnRgIGRlZmF1bHRzIHRvXG5cdCogYHRydWVgLlxuXHQqIEByZXR1cm5zIEEgcHJvbWlzZSB0aGF0IHJlc29sdmVzIG9uY2UgZXZlcnkgY2FuY2VsbGF0aW9uIGhhcyBzZXR0bGVkLlxuXHQqIEBleGFtcGxlXG5cdCogYGBgdHNcblx0KiBhd2FpdCBxdWVyeUNsaWVudC5jYW5jZWxRdWVyaWVzKHsgcXVlcnlLZXk6IFsncG9zdHMnXSwgZXhhY3Q6IHRydWUgfSlcblx0KiBgYGBcblx0Ki9cblx0Y2FuY2VsUXVlcmllcyhmaWx0ZXJzLCBjYW5jZWxPcHRpb25zID0ge30pIHtcblx0XHRjb25zdCBkZWZhdWx0ZWRDYW5jZWxPcHRpb25zID0ge1xuXHRcdFx0cmV2ZXJ0OiB0cnVlLFxuXHRcdFx0Li4uY2FuY2VsT3B0aW9uc1xuXHRcdH07XG5cdFx0Y29uc3QgcHJvbWlzZXMgPSBub3RpZnlNYW5hZ2VyLmJhdGNoKCgpID0+IHRoaXMuI3F1ZXJ5Q2FjaGUuZmluZEFsbChmaWx0ZXJzKS5tYXAoKHF1ZXJ5KSA9PiBxdWVyeS5jYW5jZWwoZGVmYXVsdGVkQ2FuY2VsT3B0aW9ucykpKTtcblx0XHRyZXR1cm4gUHJvbWlzZS5hbGwocHJvbWlzZXMpLnRoZW4obm9vcCkuY2F0Y2gobm9vcCk7XG5cdH1cblx0LyoqXG5cdCogTWFya3MgcXVlcmllcyBtYXRjaGluZyB0aGUgZ2l2ZW4gZmlsdGVycyBhcyBpbnZhbGlkYXRlZC4gVW5saWtlXG5cdCoge0BsaW5rIFF1ZXJ5Q2xpZW50I3JlbW92ZVF1ZXJpZXN9LCBpbnZhbGlkYXRlZCBxdWVyaWVzIHN0YXkgaW4gdGhlIGNhY2hlLlxuXHQqXG5cdCogVW5sZXNzIGBmaWx0ZXJzLnJlZmV0Y2hUeXBlYCBpcyBgJ25vbmUnYCwgbWF0Y2hpbmcgcXVlcmllcyBhcmUgdGhlbiByZWZldGNoZWQgdmlhXG5cdCoge0BsaW5rIFF1ZXJ5Q2xpZW50I3JlZmV0Y2hRdWVyaWVzfSwgdXNpbmcgYGZpbHRlcnMucmVmZXRjaFR5cGVgIGlmIHNldCwgb3RoZXJ3aXNlXG5cdCogYGZpbHRlcnMudHlwZWAsIG90aGVyd2lzZSBgJ2FjdGl2ZSdgLlxuXHQqIEBwYXJhbSBmaWx0ZXJzIC0gVGhlIGZpbHRlcnMgdGhhdCBzZWxlY3Qgd2hpY2ggcXVlcmllcyB0byBpbnZhbGlkYXRlLCBwbHVzIGByZWZldGNoVHlwZWAgdG9cblx0KiBjb250cm9sIHdoaWNoIG9mIHRoZW0gdG8gcmVmZXRjaCBhZnRlcndhcmRzLiBXaXRob3V0IGZpbHRlcnMsIGV2ZXJ5IHF1ZXJ5IGlzIGludmFsaWRhdGVkLlxuXHQqIEBwYXJhbSBvcHRpb25zIC0gUGFzc2VkIHRvIHtAbGluayBRdWVyeUNsaWVudCNyZWZldGNoUXVlcmllc30sIGUuZy4gYGNhbmNlbFJlZmV0Y2hgIGFuZFxuXHQqIGB0aHJvd09uRXJyb3JgLlxuXHQqIEByZXR1cm5zIEEgcHJvbWlzZSB0aGF0IHJlc29sdmVzIG9uY2UgdGhlIHJlZmV0Y2ggc2V0dGxlcywgb3IgaW1tZWRpYXRlbHkgaWYgYHJlZmV0Y2hUeXBlYCBpc1xuXHQqIGAnbm9uZSdgLlxuXHQqIEBleGFtcGxlXG5cdCogYGBgdHNcblx0KiBhd2FpdCBxdWVyeUNsaWVudC5pbnZhbGlkYXRlUXVlcmllcyh7IHF1ZXJ5S2V5OiBbJ3Bvc3RzJ10sIHJlZmV0Y2hUeXBlOiAnYWN0aXZlJyB9KVxuXHQqIGBgYFxuXHQqL1xuXHRpbnZhbGlkYXRlUXVlcmllcyhmaWx0ZXJzLCBvcHRpb25zID0ge30pIHtcblx0XHRyZXR1cm4gbm90aWZ5TWFuYWdlci5iYXRjaCgoKSA9PiB7XG5cdFx0XHR0aGlzLiNxdWVyeUNhY2hlLmZpbmRBbGwoZmlsdGVycykuZm9yRWFjaCgocXVlcnkpID0+IHtcblx0XHRcdFx0cXVlcnkuaW52YWxpZGF0ZSgpO1xuXHRcdFx0fSk7XG5cdFx0XHRpZiAoZmlsdGVycz8ucmVmZXRjaFR5cGUgPT09IFwibm9uZVwiKSByZXR1cm4gUHJvbWlzZS5yZXNvbHZlKCk7XG5cdFx0XHRyZXR1cm4gdGhpcy5yZWZldGNoUXVlcmllcyh7XG5cdFx0XHRcdC4uLmZpbHRlcnMsXG5cdFx0XHRcdHR5cGU6IGZpbHRlcnM/LnJlZmV0Y2hUeXBlID8/IGZpbHRlcnM/LnR5cGUgPz8gXCJhY3RpdmVcIlxuXHRcdFx0fSwgb3B0aW9ucyk7XG5cdFx0fSk7XG5cdH1cblx0LyoqXG5cdCogUmVmZXRjaGVzIHF1ZXJpZXMgbWF0Y2hpbmcgdGhlIGdpdmVuIGZpbHRlcnMsIHJlZ2FyZGxlc3Mgb2Ygd2hldGhlciB0aGV5IGFyZSBzdGFsZS4gV2l0aG91dFxuXHQqIGZpbHRlcnMsIGV2ZXJ5IHF1ZXJ5IGluIHRoZSBjYWNoZSBpcyByZWZldGNoZWQuIFF1ZXJpZXMgdGhhdCBhcmUgZGlzYWJsZWQsIG9yIHN0YXRpYyAob25seVxuXHQqIGhhdmUgb2JzZXJ2ZXJzIHdpdGggYSBzdGF0aWMgYHN0YWxlVGltZWApLCBhcmUgbmV2ZXIgcmVmZXRjaGVkLlxuXHQqXG5cdCogQnkgZGVmYXVsdCAoYGNhbmNlbFJlZmV0Y2g6IHRydWVgKSwgYSBjdXJyZW50bHkgcnVubmluZyBmZXRjaCBpcyBjYW5jZWxsZWQgYmVmb3JlIHRoZSBuZXdcblx0KiBvbmUgc3RhcnRzLiBUaGUgcmV0dXJuZWQgcHJvbWlzZSBkb2VzIG5vdCByZWplY3Qgb24gaW5kaXZpZHVhbCBxdWVyeSBmYWlsdXJlcyB1bmxlc3Ncblx0KiBgdGhyb3dPbkVycm9yYCBpcyBgdHJ1ZWAuXG5cdCpcblx0KiBJbml0aWFsbHkgcGF1c2VkIGZldGNoZXMgZG8gbm90IGRlbGF5IHRoZSByZXR1cm5lZCBwcm9taXNlLiBUaGVpciBsYXRlciBlcnJvcnMgYXJlIGhhbmRsZWRcblx0KiBldmVuIHdoZW4gYHRocm93T25FcnJvcmAgaXMgYHRydWVgLlxuXHQqIEBwYXJhbSBmaWx0ZXJzIC0gVGhlIGZpbHRlcnMgdGhhdCBzZWxlY3Qgd2hpY2ggcXVlcmllcyB0byByZWZldGNoLiBXaXRob3V0IGZpbHRlcnMsIGV2ZXJ5IHF1ZXJ5XG5cdCogaW4gdGhlIGNhY2hlIGlzIGluY2x1ZGVkLlxuXHQqIEBwYXJhbSBvcHRpb25zIC0gU2V0IGBjYW5jZWxSZWZldGNoYCB0byBgZmFsc2VgIHRvIGtlZXAgYSBydW5uaW5nIGZldGNoIGluc3RlYWQgb2YgY2FuY2VsbGluZ1xuXHQqIGl0LCBhbmQgYHRocm93T25FcnJvcmAgdG8gYHRydWVgIHRvIHJlamVjdCB3aGVuIGEgcmVmZXRjaCB0aGF0IHdhcyBub3QgaW5pdGlhbGx5IHBhdXNlZCBmYWlscy5cblx0KiBAcmV0dXJucyBBIHByb21pc2UgdGhhdCByZXNvbHZlcyBvbmNlIGFsbCBtYXRjaGluZyByZWZldGNoZXMgdGhhdCB3ZXJlIG5vdCBpbml0aWFsbHkgcGF1c2VkXG5cdCogaGF2ZSBzZXR0bGVkLlxuXHQqIEBleGFtcGxlXG5cdCogYGBgdHNcblx0KiAvLyByZWZldGNoIGFsbCBhY3RpdmUgcXVlcmllcyBwYXJ0aWFsbHkgbWF0Y2hpbmcgYSBxdWVyeSBrZXk6XG5cdCogYXdhaXQgcXVlcnlDbGllbnQucmVmZXRjaFF1ZXJpZXMoeyBxdWVyeUtleTogWydwb3N0cyddLCB0eXBlOiAnYWN0aXZlJyB9KVxuXHQqIGBgYFxuXHQqL1xuXHRyZWZldGNoUXVlcmllcyhmaWx0ZXJzLCBvcHRpb25zID0ge30pIHtcblx0XHRjb25zdCBmZXRjaE9wdGlvbnMgPSB7XG5cdFx0XHQuLi5vcHRpb25zLFxuXHRcdFx0Y2FuY2VsUmVmZXRjaDogb3B0aW9ucy5jYW5jZWxSZWZldGNoID8/IHRydWVcblx0XHR9O1xuXHRcdGNvbnN0IHByb21pc2VzID0gbm90aWZ5TWFuYWdlci5iYXRjaCgoKSA9PiB0aGlzLiNxdWVyeUNhY2hlLmZpbmRBbGwoZmlsdGVycykuZmlsdGVyKChxdWVyeSkgPT4gIXF1ZXJ5LmlzRGlzYWJsZWQoKSAmJiAhcXVlcnkuaXNTdGF0aWMoKSkubWFwKChxdWVyeSkgPT4ge1xuXHRcdFx0bGV0IHByb21pc2UgPSBxdWVyeS5mZXRjaCh2b2lkIDAsIGZldGNoT3B0aW9ucyk7XG5cdFx0XHRjb25zdCBpc1BhdXNlZCA9IHF1ZXJ5LnN0YXRlLmZldGNoU3RhdHVzID09PSBcInBhdXNlZFwiO1xuXHRcdFx0aWYgKCFmZXRjaE9wdGlvbnMudGhyb3dPbkVycm9yIHx8IGlzUGF1c2VkKSBwcm9taXNlID0gcHJvbWlzZS5jYXRjaChub29wKTtcblx0XHRcdHJldHVybiBpc1BhdXNlZCA/IFByb21pc2UucmVzb2x2ZSgpIDogcHJvbWlzZTtcblx0XHR9KSk7XG5cdFx0cmV0dXJuIFByb21pc2UuYWxsKHByb21pc2VzKS50aGVuKG5vb3ApO1xuXHR9XG5cdC8qKlxuXHQqIEFzeW5jaHJvbm91cyBtZXRob2QgdG8gZmV0Y2ggYW5kIGNhY2hlIGEgcXVlcnksIHJlc29sdmluZyB3aXRoIHRoZSBkYXRhIG9yIHRocm93aW5nIHdpdGhcblx0KiB0aGUgZXJyb3IuXG5cdCpcblx0KiBJZiB0aGUgcXVlcnkgYWxyZWFkeSBleGlzdHMgaW4gdGhlIGNhY2hlIGFuZCBpdHMgZGF0YSBpcyBub3Qgc3RhbGUgKHBlciB0aGUgZ2l2ZW5cblx0KiBgc3RhbGVUaW1lYCksIHRoZSBjYWNoZWQgZGF0YSBpcyByZXR1cm5lZCB3aXRob3V0IGZldGNoaW5nLiBPdGhlcndpc2UsIHRoZSBxdWVyeSBpcyBmZXRjaGVkXG5cdCogYW5kIHRoZSBwcm9taXNlIHJlc29sdmVzIG9uY2UgdGhlIGZldGNoIHNldHRsZXMuIElmIGEgYHNlbGVjdGAgZnVuY3Rpb24gaXMgcHJvdmlkZWQsIGl0IGlzXG5cdCogYXBwbGllZCB0byB0aGUgZGF0YSBpbiBib3RoIGNhc2VzIChjYWNoZWQgb3IgZnJlc2hseSBmZXRjaGVkKSBiZWZvcmUgaXQgaXMgcmV0dXJuZWQuXG5cdCpcblx0KiBVbmxpa2UgYSByZWFjdGl2ZSBvYnNlcnZlciwgcmV0cmllcyBhcmUgZGlzYWJsZWQgYnkgZGVmYXVsdCBoZXJlIChgcmV0cnk6IGZhbHNlYCkgdW5sZXNzXG5cdCogZXhwbGljaXRseSBjb25maWd1cmVkLCBzaW5jZSB0aGVyZSBpcyBubyBjb21wb25lbnQgdG8gY2F0Y2ggYSB0aHJvd24gZXJyb3IgYW5kIHJldHJ5IHRocm91Z2hcblx0KiByZS1yZW5kZXIuXG5cdCpcblx0KiBUaGUgYWNjZXB0ZWQgb3B0aW9ucyBhcmUgYFF1ZXJ5T2JzZXJ2ZXJPcHRpb25zYCBtaW51cyB0aGUgZmllbGRzIHRoYXQgb25seSBtYWtlIHNlbnNlIGZvciBhXG5cdCogcmVhY3RpdmUgb2JzZXJ2ZXIg4oCUIGBlbmFibGVkYCwgYHJlZmV0Y2hJbnRlcnZhbGAsIGByZWZldGNoSW50ZXJ2YWxJbkJhY2tncm91bmRgLFxuXHQqIGByZWZldGNoT25XaW5kb3dGb2N1c2AsIGByZWZldGNoT25SZWNvbm5lY3RgLCBgcmVmZXRjaE9uTW91bnRgLCBgcmV0cnlPbk1vdW50YCxcblx0KiBgbm90aWZ5T25DaGFuZ2VQcm9wc2AsIGB0aHJvd09uRXJyb3JgLCBgc3VzcGVuc2VgLCBhbmQgYHBsYWNlaG9sZGVyRGF0YWAgYXJlIG5vdCBwYXJ0IG9mIHRoaXNcblx0KiBtZXRob2QncyBvcHRpb25zLlxuXHQqXG5cdCogVGhpcyBtZXRob2QgcmVwbGFjZXMgdGhlIGRlcHJlY2F0ZWQgYGZldGNoUXVlcnlgLCBhbmQg4oCUIGNvbWJpbmVkIHdpdGhcblx0KiBgeyBzdGFsZVRpbWU6ICdzdGF0aWMnIH1gIOKAlCB0aGUgZGVwcmVjYXRlZCBgZW5zdXJlUXVlcnlEYXRhYC5cblx0KiBAcGFyYW0gb3B0aW9ucyAtIFRoZSBxdWVyeSBvcHRpb25zLCBpbmNsdWRpbmcgdGhlIGBxdWVyeUtleWAgYW5kIHRoZSBgcXVlcnlGbmAgdXNlZCBpZiB0aGVcblx0KiBxdWVyeSBuZWVkcyB0byBmZXRjaC5cblx0KiBAcmV0dXJucyBBIHByb21pc2UgdGhhdCByZXNvbHZlcyB0byB0aGUgZGF0YSwgb3IgdG8gdGhlIHJlc3VsdCBvZiBgc2VsZWN0YCBpZiBwcm92aWRlZC4gSXRcblx0KiByZWplY3RzIHdpdGggdGhlIGVycm9yIGZyb20gdGhlIGZldGNoIG9yIGZyb20gYHNlbGVjdGAuXG5cdCogQGV4YW1wbGVcblx0KiBgYGB0c1xuXHQqIHRyeSB7XG5cdCogICBjb25zdCBkYXRhID0gYXdhaXQgcXVlcnlDbGllbnQucXVlcnkoeyBxdWVyeUtleSwgcXVlcnlGbiwgc3RhbGVUaW1lOiAxMDAwMCB9KVxuXHQqIH0gY2F0Y2ggKGVycm9yKSB7XG5cdCogICBjb25zb2xlLmxvZyhlcnJvcilcblx0KiB9XG5cdCogYGBgXG5cdCovXG5cdGFzeW5jIHF1ZXJ5KG9wdGlvbnMpIHtcblx0XHRjb25zdCBkZWZhdWx0ZWRPcHRpb25zID0gdGhpcy5kZWZhdWx0UXVlcnlPcHRpb25zKG9wdGlvbnMpO1xuXHRcdGlmIChkZWZhdWx0ZWRPcHRpb25zLnJldHJ5ID09PSB2b2lkIDApIGRlZmF1bHRlZE9wdGlvbnMucmV0cnkgPSBmYWxzZTtcblx0XHRjb25zdCBxdWVyeSA9IHRoaXMuI3F1ZXJ5Q2FjaGUuYnVpbGQodGhpcywgZGVmYXVsdGVkT3B0aW9ucyk7XG5cdFx0Y29uc3QgcXVlcnlEYXRhID0gcXVlcnkuaXNTdGFsZUJ5VGltZShyZXNvbHZlUXVlcnlWYWx1ZShkZWZhdWx0ZWRPcHRpb25zLnN0YWxlVGltZSwgcXVlcnkpKSA/IGF3YWl0IHF1ZXJ5LmZldGNoKGRlZmF1bHRlZE9wdGlvbnMpIDogcXVlcnkuc3RhdGUuZGF0YTtcblx0XHRjb25zdCBzZWxlY3QgPSBkZWZhdWx0ZWRPcHRpb25zLnNlbGVjdDtcblx0XHRpZiAoc2VsZWN0KSByZXR1cm4gc2VsZWN0KHF1ZXJ5RGF0YSk7XG5cdFx0cmV0dXJuIHF1ZXJ5RGF0YTtcblx0fVxuXHQvKipcblx0KiBGZXRjaGVzIGFuZCBjYWNoZXMgYSBxdWVyeSwgb3IgcmV0dXJucyBpdHMgY2FjaGVkIGRhdGEgaWYgaXQgaXNuJ3Qgc3RhbGUuIFVubGlrZSBpbiBvYnNlcnZlcnMsXG5cdCogdGhlIGZldGNoIGlzbid0IHJldHJpZWQgdW5sZXNzIGByZXRyeWAgaXMgc2V0LlxuXHQqIEBwYXJhbSBvcHRpb25zIC0gVGhlIHF1ZXJ5IG9wdGlvbnMsIGluY2x1ZGluZyB0aGUgYHF1ZXJ5S2V5YCBhbmQgdGhlIGBxdWVyeUZuYCB1c2VkIGlmIHRoZVxuXHQqIHF1ZXJ5IG5lZWRzIHRvIGZldGNoLlxuXHQqIEByZXR1cm5zIEEgcHJvbWlzZSB0aGF0IHJlc29sdmVzIHRvIHRoZSBjYWNoZWQgb3IgZmV0Y2hlZCBkYXRhLCBvciByZWplY3RzIHdpdGggdGhlIGZldGNoXG5cdCogZXJyb3IuXG5cdCogQGRlcHJlY2F0ZWQgVXNlIHF1ZXJ5Q2xpZW50LnF1ZXJ5KG9wdGlvbnMpIGluc3RlYWQuIFRoaXMgbWV0aG9kIHdpbGwgYmUgcmVtb3ZlZCBpbiB0aGUgbmV4dCBtYWpvciB2ZXJzaW9uLlxuXHQqL1xuXHRmZXRjaFF1ZXJ5KG9wdGlvbnMpIHtcblx0XHRjb25zdCBkZWZhdWx0ZWRPcHRpb25zID0gdGhpcy5kZWZhdWx0UXVlcnlPcHRpb25zKG9wdGlvbnMpO1xuXHRcdGlmIChkZWZhdWx0ZWRPcHRpb25zLnJldHJ5ID09PSB2b2lkIDApIGRlZmF1bHRlZE9wdGlvbnMucmV0cnkgPSBmYWxzZTtcblx0XHRjb25zdCBxdWVyeSA9IHRoaXMuI3F1ZXJ5Q2FjaGUuYnVpbGQodGhpcywgZGVmYXVsdGVkT3B0aW9ucyk7XG5cdFx0cmV0dXJuIHF1ZXJ5LmlzU3RhbGVCeVRpbWUocmVzb2x2ZVF1ZXJ5VmFsdWUoZGVmYXVsdGVkT3B0aW9ucy5zdGFsZVRpbWUsIHF1ZXJ5KSkgPyBxdWVyeS5mZXRjaChkZWZhdWx0ZWRPcHRpb25zKSA6IFByb21pc2UucmVzb2x2ZShxdWVyeS5zdGF0ZS5kYXRhKTtcblx0fVxuXHQvKipcblx0KiBGZXRjaGVzIGFuZCBjYWNoZXMgYSBxdWVyeSBsaWtlIHtAbGluayBRdWVyeUNsaWVudCNmZXRjaFF1ZXJ5fSwgYnV0IGlnbm9yZXMgdGhlIHJlc3VsdCBhbmQgYW55XG5cdCogZXJyb3IuXG5cdCogQHBhcmFtIG9wdGlvbnMgLSBUaGUgcXVlcnkgb3B0aW9ucywgaW5jbHVkaW5nIHRoZSBgcXVlcnlLZXlgIGFuZCB0aGUgYHF1ZXJ5Rm5gIHVzZWQgaWYgdGhlXG5cdCogcXVlcnkgbmVlZHMgdG8gZmV0Y2guXG5cdCogQHJldHVybnMgQSBwcm9taXNlIHRoYXQgcmVzb2x2ZXMgb25jZSB0aGUgZmV0Y2ggc2V0dGxlcy4gSXQgbmV2ZXIgcmVqZWN0cy5cblx0KiBAZGVwcmVjYXRlZCBVc2UgcXVlcnlDbGllbnQucXVlcnkob3B0aW9ucykgaW5zdGVhZC4gWW91IGNhbiBzd2FsbG93IGVycm9ycyB3aXRoIGAuY2F0Y2gobm9vcClgLiBUaGlzIG1ldGhvZCB3aWxsIGJlIHJlbW92ZWQgaW4gdGhlIG5leHQgbWFqb3IgdmVyc2lvbi5cblx0Ki9cblx0cHJlZmV0Y2hRdWVyeShvcHRpb25zKSB7XG5cdFx0cmV0dXJuIHRoaXMuZmV0Y2hRdWVyeShvcHRpb25zKS50aGVuKG5vb3ApLmNhdGNoKG5vb3ApO1xuXHR9XG5cdC8qKlxuXHQqIEFzeW5jaHJvbm91cyBtZXRob2QgdG8gZmV0Y2ggYW5kIGNhY2hlIGFuIGluZmluaXRlIHF1ZXJ5LCByZXNvbHZpbmcgd2l0aCBhblxuXHQqIHtAbGluayBJbmZpbml0ZURhdGF9IG9iamVjdCBvciB0aHJvd2luZyB3aXRoIHRoZSBlcnJvci5cblx0KlxuXHQqIEJlaGF2ZXMgbGlrZSB7QGxpbmsgUXVlcnlDbGllbnQjcXVlcnl9LCBhY2NlcHRpbmcgdGhlIHNhbWUgb3B0aW9ucyAobWludXNcblx0KiBgaW5pdGlhbFBhZ2VQYXJhbWApLCBwbHVzIHRoZSByZXF1aXJlZCBgaW5pdGlhbFBhZ2VQYXJhbWAsIGFuZCBhbiBvcHRpb25hbCBgcGFnZXNgIC9cblx0KiBgZ2V0TmV4dFBhZ2VQYXJhbWAgcGFpciB1c2VkIHRvIHJlZmV0Y2ggYSBmaXhlZCBudW1iZXIgb2YgcGFnZXMgZnJvbSB0aGUgc3RhcnQuXG5cdCpcblx0KiBUaGlzIG1ldGhvZCByZXBsYWNlcyB0aGUgZGVwcmVjYXRlZCBgZmV0Y2hJbmZpbml0ZVF1ZXJ5YCwgYW5kIOKAlCBjb21iaW5lZCB3aXRoXG5cdCogYHsgc3RhbGVUaW1lOiAnc3RhdGljJyB9YCDigJQgdGhlIGRlcHJlY2F0ZWQgYGVuc3VyZUluZmluaXRlUXVlcnlEYXRhYC5cblx0KiBAcGFyYW0gb3B0aW9ucyAtIFRoZSBpbmZpbml0ZSBxdWVyeSBvcHRpb25zLCBpbmNsdWRpbmcgdGhlIGBxdWVyeUtleWAsIHRoZSBgcXVlcnlGbmAsIGFuZCB0aGVcblx0KiBgaW5pdGlhbFBhZ2VQYXJhbWAuXG5cdCogQHJldHVybnMgQSBwcm9taXNlIHRoYXQgcmVzb2x2ZXMgdG8gdGhlIHtAbGluayBJbmZpbml0ZURhdGF9LCBvciB0byB0aGUgcmVzdWx0IG9mIGBzZWxlY3RgIGlmXG5cdCogcHJvdmlkZWQuIEl0IHJlamVjdHMgd2l0aCB0aGUgZXJyb3IgZnJvbSB0aGUgZmV0Y2ggb3IgZnJvbSBgc2VsZWN0YC5cblx0KiBAZXhhbXBsZVxuXHQqIGBgYHRzXG5cdCogdHJ5IHtcblx0KiAgIGNvbnN0IGRhdGEgPSBhd2FpdCBxdWVyeUNsaWVudC5pbmZpbml0ZVF1ZXJ5KHsgcXVlcnlLZXksIHF1ZXJ5Rm4sIGluaXRpYWxQYWdlUGFyYW06IDAgfSlcblx0KiAgIGNvbnNvbGUubG9nKGRhdGEucGFnZXMpXG5cdCogfSBjYXRjaCAoZXJyb3IpIHtcblx0KiAgIGNvbnNvbGUubG9nKGVycm9yKVxuXHQqIH1cblx0KiBgYGBcblx0Ki9cblx0aW5maW5pdGVRdWVyeShvcHRpb25zKSB7XG5cdFx0b3B0aW9ucy5fdHlwZSA9IFwiaW5maW5pdGVcIjtcblx0XHRyZXR1cm4gdGhpcy5xdWVyeShvcHRpb25zKTtcblx0fVxuXHQvKipcblx0KiBGZXRjaGVzIGFuZCBjYWNoZXMgYW4gaW5maW5pdGUgcXVlcnksIG9yIHJldHVybnMgaXRzIGNhY2hlZCBkYXRhIGlmIGl0IGlzbid0IHN0YWxlLlxuXHQqIEBwYXJhbSBvcHRpb25zIC0gVGhlIGluZmluaXRlIHF1ZXJ5IG9wdGlvbnMsIGluY2x1ZGluZyB0aGUgYHF1ZXJ5S2V5YCwgdGhlIGBxdWVyeUZuYCwgYW5kIHRoZVxuXHQqIGBpbml0aWFsUGFnZVBhcmFtYC5cblx0KiBAcmV0dXJucyBBIHByb21pc2UgdGhhdCByZXNvbHZlcyB0byB0aGUgY2FjaGVkIG9yIGZldGNoZWQge0BsaW5rIEluZmluaXRlRGF0YX0sIG9yIHJlamVjdHMgd2l0aFxuXHQqIHRoZSBmZXRjaCBlcnJvci5cblx0KiBAZGVwcmVjYXRlZCBVc2UgcXVlcnlDbGllbnQuaW5maW5pdGVRdWVyeShvcHRpb25zKSBpbnN0ZWFkLiBUaGlzIG1ldGhvZCB3aWxsIGJlIHJlbW92ZWQgaW4gdGhlIG5leHQgbWFqb3IgdmVyc2lvbi5cblx0Ki9cblx0ZmV0Y2hJbmZpbml0ZVF1ZXJ5KG9wdGlvbnMpIHtcblx0XHRvcHRpb25zLl90eXBlID0gXCJpbmZpbml0ZVwiO1xuXHRcdHJldHVybiB0aGlzLmZldGNoUXVlcnkob3B0aW9ucyk7XG5cdH1cblx0LyoqXG5cdCogRmV0Y2hlcyBhbmQgY2FjaGVzIGFuIGluZmluaXRlIHF1ZXJ5IGxpa2Uge0BsaW5rIFF1ZXJ5Q2xpZW50I2ZldGNoSW5maW5pdGVRdWVyeX0sIGJ1dCBpZ25vcmVzXG5cdCogdGhlIHJlc3VsdCBhbmQgYW55IGVycm9yLlxuXHQqIEBwYXJhbSBvcHRpb25zIC0gVGhlIGluZmluaXRlIHF1ZXJ5IG9wdGlvbnMsIGluY2x1ZGluZyB0aGUgYHF1ZXJ5S2V5YCwgdGhlIGBxdWVyeUZuYCwgYW5kIHRoZVxuXHQqIGBpbml0aWFsUGFnZVBhcmFtYC5cblx0KiBAcmV0dXJucyBBIHByb21pc2UgdGhhdCByZXNvbHZlcyBvbmNlIHRoZSBmZXRjaCBzZXR0bGVzLiBJdCBuZXZlciByZWplY3RzLlxuXHQqIEBkZXByZWNhdGVkIFVzZSBxdWVyeUNsaWVudC5pbmZpbml0ZVF1ZXJ5KG9wdGlvbnMpIGluc3RlYWQuIFlvdSBjYW4gc3dhbGxvdyBlcnJvcnMgd2l0aCBgLmNhdGNoKG5vb3ApYC4gVGhpcyBtZXRob2Qgd2lsbCBiZSByZW1vdmVkIGluIHRoZSBuZXh0IG1ham9yIHZlcnNpb24uXG5cdCovXG5cdHByZWZldGNoSW5maW5pdGVRdWVyeShvcHRpb25zKSB7XG5cdFx0cmV0dXJuIHRoaXMuZmV0Y2hJbmZpbml0ZVF1ZXJ5KG9wdGlvbnMpLnRoZW4obm9vcCkuY2F0Y2gobm9vcCk7XG5cdH1cblx0LyoqXG5cdCogUmV0dXJucyB0aGUgY2FjaGVkIGRhdGEgb2YgYW4gaW5maW5pdGUgcXVlcnksIG9yIGZldGNoZXMgaXQgaWYgdGhlcmUgaXMgbm9uZS4gV2l0aFxuXHQqIGByZXZhbGlkYXRlSWZTdGFsZWAsIHN0YWxlIGNhY2hlZCBkYXRhIGlzIGFsc28gcmVmZXRjaGVkIGluIHRoZSBiYWNrZ3JvdW5kLlxuXHQqIEBwYXJhbSBvcHRpb25zIC0gVGhlIGluZmluaXRlIHF1ZXJ5IG9wdGlvbnMuIElmIHRoZSBxdWVyeSBoYXMgbm8gY2FjaGVkIGRhdGEgeWV0LCBpdCBpcyBmZXRjaGVkXG5cdCogd2l0aCB0aGVzZSBvcHRpb25zLlxuXHQqIEByZXR1cm5zIEEgcHJvbWlzZSB0aGF0IHJlc29sdmVzIHRvIHRoZSBjYWNoZWQge0BsaW5rIEluZmluaXRlRGF0YX0sIG9yIHRvIHRoZSBmZXRjaGVkIGRhdGEgaWZcblx0KiBub3RoaW5nIHdhcyBjYWNoZWQgeWV0LlxuXHQqIEBkZXByZWNhdGVkIFVzZSBxdWVyeUNsaWVudC5pbmZpbml0ZVF1ZXJ5KHsgLi4ub3B0aW9ucywgc3RhbGVUaW1lOiAnc3RhdGljJyB9KSBpbnN0ZWFkLiBUaGlzIG1ldGhvZCB3aWxsIGJlIHJlbW92ZWQgaW4gdGhlIG5leHQgbWFqb3IgdmVyc2lvbi5cblx0Ki9cblx0ZW5zdXJlSW5maW5pdGVRdWVyeURhdGEob3B0aW9ucykge1xuXHRcdG9wdGlvbnMuX3R5cGUgPSBcImluZmluaXRlXCI7XG5cdFx0cmV0dXJuIHRoaXMuZW5zdXJlUXVlcnlEYXRhKG9wdGlvbnMpO1xuXHR9XG5cdC8qKlxuXHQqIFJlc3VtZXMgbXV0YXRpb25zIHRoYXQgd2VyZSBwYXVzZWQgYmVjYXVzZSB0aGVyZSB3YXMgbm8gbmV0d29yayBjb25uZWN0aW9uLiBEb2VzIG5vdGhpbmdcblx0KiAocmVzb2x2aW5nIGltbWVkaWF0ZWx5KSBpZiB0aGUgY2xpZW50IGlzIGN1cnJlbnRseSBvZmZsaW5lLlxuXHQqIEByZXR1cm5zIEEgcHJvbWlzZSB0aGF0IHJlc29sdmVzIG9uY2UgdGhlIHJlc3VtZWQgbXV0YXRpb25zIGhhdmUgc2V0dGxlZC5cblx0KiBAZXhhbXBsZVxuXHQqIGBgYHRzXG5cdCogaW1wb3J0IHsgUXVlcnlDbGllbnQgfSBmcm9tICdAdGFuc3RhY2svcXVlcnktY29yZSdcblx0KlxuXHQqIGNvbnN0IHF1ZXJ5Q2xpZW50ID0gbmV3IFF1ZXJ5Q2xpZW50KClcblx0KiBhd2FpdCBxdWVyeUNsaWVudC5yZXN1bWVQYXVzZWRNdXRhdGlvbnMoKVxuXHQqIGBgYFxuXHQqL1xuXHRyZXN1bWVQYXVzZWRNdXRhdGlvbnMoKSB7XG5cdFx0aWYgKG9ubGluZU1hbmFnZXIuaXNPbmxpbmUoKSkgcmV0dXJuIHRoaXMuI211dGF0aW9uQ2FjaGUucmVzdW1lUGF1c2VkTXV0YXRpb25zKCk7XG5cdFx0cmV0dXJuIFByb21pc2UucmVzb2x2ZSgpO1xuXHR9XG5cdC8qKlxuXHQqIFJldHVybnMgdGhlIHF1ZXJ5IGNhY2hlIHRoaXMgY2xpZW50IGlzIGNvbm5lY3RlZCB0by5cblx0KiBAcmV0dXJucyBUaGUge0BsaW5rIFF1ZXJ5Q2FjaGV9IGluc3RhbmNlLlxuXHQqIEBleGFtcGxlXG5cdCogYGBgdHNcblx0KiBpbXBvcnQgeyBRdWVyeUNsaWVudCB9IGZyb20gJ0B0YW5zdGFjay9xdWVyeS1jb3JlJ1xuXHQqXG5cdCogY29uc3QgcXVlcnlDbGllbnQgPSBuZXcgUXVlcnlDbGllbnQoKVxuXHQqIGNvbnN0IHF1ZXJ5Q2FjaGUgPSBxdWVyeUNsaWVudC5nZXRRdWVyeUNhY2hlKClcblx0KiBjb25zdCBxdWVyaWVzID0gcXVlcnlDYWNoZS5maW5kQWxsKHsgcXVlcnlLZXk6IFsncG9zdHMnXSB9KVxuXHQqIGBgYFxuXHQqL1xuXHRnZXRRdWVyeUNhY2hlKCkge1xuXHRcdHJldHVybiB0aGlzLiNxdWVyeUNhY2hlO1xuXHR9XG5cdC8qKlxuXHQqIFJldHVybnMgdGhlIG11dGF0aW9uIGNhY2hlIHRoaXMgY2xpZW50IGlzIGNvbm5lY3RlZCB0by5cblx0KiBAcmV0dXJucyBUaGUge0BsaW5rIE11dGF0aW9uQ2FjaGV9IGluc3RhbmNlLlxuXHQqIEBleGFtcGxlXG5cdCogYGBgdHNcblx0KiBpbXBvcnQgeyBRdWVyeUNsaWVudCB9IGZyb20gJ0B0YW5zdGFjay9xdWVyeS1jb3JlJ1xuXHQqXG5cdCogY29uc3QgcXVlcnlDbGllbnQgPSBuZXcgUXVlcnlDbGllbnQoKVxuXHQqIGNvbnN0IG11dGF0aW9uQ2FjaGUgPSBxdWVyeUNsaWVudC5nZXRNdXRhdGlvbkNhY2hlKClcblx0KiBjb25zdCBtdXRhdGlvbnMgPSBtdXRhdGlvbkNhY2hlLmZpbmRBbGwoeyBzdGF0dXM6ICdwZW5kaW5nJyB9KVxuXHQqIGBgYFxuXHQqL1xuXHRnZXRNdXRhdGlvbkNhY2hlKCkge1xuXHRcdHJldHVybiB0aGlzLiNtdXRhdGlvbkNhY2hlO1xuXHR9XG5cdC8qKlxuXHQqIFJldHVybnMgdGhlIGRlZmF1bHQgb3B0aW9ucyB0aGF0IHdlcmUgc2V0IHdoZW4gY3JlYXRpbmcgdGhlIGNsaWVudCwgb3IgdmlhXG5cdCoge0BsaW5rIFF1ZXJ5Q2xpZW50I3NldERlZmF1bHRPcHRpb25zfS5cblx0KiBAcmV0dXJucyBUaGUgY2xpZW50J3MgY3VycmVudCBkZWZhdWx0IG9wdGlvbnMuXG5cdCogQGV4YW1wbGVcblx0KiBgYGB0c1xuXHQqIGltcG9ydCB7IFF1ZXJ5Q2xpZW50IH0gZnJvbSAnQHRhbnN0YWNrL3F1ZXJ5LWNvcmUnXG5cdCpcblx0KiBjb25zdCBxdWVyeUNsaWVudCA9IG5ldyBRdWVyeUNsaWVudCgpXG5cdCogY29uc3QgZGVmYXVsdE9wdGlvbnMgPSBxdWVyeUNsaWVudC5nZXREZWZhdWx0T3B0aW9ucygpXG5cdCogYGBgXG5cdCovXG5cdGdldERlZmF1bHRPcHRpb25zKCkge1xuXHRcdHJldHVybiB0aGlzLiNkZWZhdWx0T3B0aW9ucztcblx0fVxuXHQvKipcblx0KiBEeW5hbWljYWxseSBzZXRzIHRoZSBkZWZhdWx0IG9wdGlvbnMgZm9yIHRoaXMgY2xpZW50LCBvdmVyd3JpdGluZyBhbnkgcHJldmlvdXNseSBkZWZpbmVkXG5cdCogZGVmYXVsdCBvcHRpb25zLlxuXHQqIEBwYXJhbSBvcHRpb25zIC0gVGhlIG5ldyBkZWZhdWx0IG9wdGlvbnMgZm9yIHF1ZXJpZXMgYW5kIG11dGF0aW9ucy5cblx0KiBAc2VlIHtAbGluayBRdWVyeUNsaWVudCNnZXREZWZhdWx0T3B0aW9uc31cblx0KiBAZXhhbXBsZVxuXHQqIGBgYHRzXG5cdCogaW1wb3J0IHsgUXVlcnlDbGllbnQgfSBmcm9tICdAdGFuc3RhY2svcXVlcnktY29yZSdcblx0KlxuXHQqIGNvbnN0IHF1ZXJ5Q2xpZW50ID0gbmV3IFF1ZXJ5Q2xpZW50KClcblx0KiBxdWVyeUNsaWVudC5zZXREZWZhdWx0T3B0aW9ucyh7XG5cdCogICBxdWVyaWVzOiB7XG5cdCogICAgIHN0YWxlVGltZTogSW5maW5pdHksXG5cdCogICB9LFxuXHQqIH0pXG5cdCogYGBgXG5cdCovXG5cdHNldERlZmF1bHRPcHRpb25zKG9wdGlvbnMpIHtcblx0XHR0aGlzLiNkZWZhdWx0T3B0aW9ucyA9IG9wdGlvbnM7XG5cdH1cblx0LyoqXG5cdCogU2V0cyBkZWZhdWx0IG9wdGlvbnMgZm9yIHF1ZXJpZXMgd2hvc2UgcXVlcnkga2V5IHBhcnRpYWxseSBtYXRjaGVzIHRoZSBnaXZlbiBgcXVlcnlLZXlgLlxuXHQqXG5cdCogSWYgc2V2ZXJhbCByZWdpc3RlcmVkIHF1ZXJ5IGRlZmF1bHRzIG1hdGNoIGEgZ2l2ZW4gcXVlcnkga2V5LCB0aGV5IGFyZSBtZXJnZWQgdG9nZXRoZXIgaW5cblx0KiByZWdpc3RyYXRpb24gb3JkZXIgYnkge0BsaW5rIFF1ZXJ5Q2xpZW50I2dldFF1ZXJ5RGVmYXVsdHN9LCBzbyByZWdpc3RlciBkZWZhdWx0cyBmcm9tIHRoZVxuXHQqIG1vc3QgZ2VuZXJpYyBrZXkgdG8gdGhlIGxlYXN0IGdlbmVyaWMgb25lIOKAlCBtb3JlIHNwZWNpZmljIGRlZmF1bHRzIHNob3VsZCBiZSByZWdpc3RlcmVkXG5cdCogYWZ0ZXIgbW9yZSBnZW5lcmljIG9uZXMgc28gdGhleSB0YWtlIHByZWNlZGVuY2UuXG5cdCogQHBhcmFtIHF1ZXJ5S2V5IC0gVGhlIHF1ZXJ5IGtleSB0aGF0IHF1ZXJ5IGtleXMgYXJlIHBhcnRpYWxseSBtYXRjaGVkIGFnYWluc3QuXG5cdCogQHBhcmFtIG9wdGlvbnMgLSBUaGUgZGVmYXVsdCBvcHRpb25zIGFwcGxpZWQgdG8gbWF0Y2hpbmcgcXVlcmllcy5cblx0KiBAZXhhbXBsZVxuXHQqIGBgYHRzXG5cdCogcXVlcnlDbGllbnQuc2V0UXVlcnlEZWZhdWx0cyhbJ3Bvc3RzJ10sIHsgcXVlcnlGbjogZmV0Y2hQb3N0cyB9KVxuXHQqXG5cdCogYXdhaXQgcXVlcnlDbGllbnQucXVlcnkoeyBxdWVyeUtleTogWydwb3N0cyddIH0pXG5cdCogYGBgXG5cdCovXG5cdHNldFF1ZXJ5RGVmYXVsdHMocXVlcnlLZXksIG9wdGlvbnMpIHtcblx0XHR0aGlzLiNxdWVyeURlZmF1bHRzLnNldChoYXNoS2V5KHF1ZXJ5S2V5KSwge1xuXHRcdFx0cXVlcnlLZXksXG5cdFx0XHRkZWZhdWx0T3B0aW9uczogb3B0aW9uc1xuXHRcdH0pO1xuXHR9XG5cdC8qKlxuXHQqIFJldHVybnMgdGhlIGRlZmF1bHQgb3B0aW9ucyByZWdpc3RlcmVkIGZvciBxdWVyaWVzIHdob3NlIHF1ZXJ5IGtleSBwYXJ0aWFsbHkgbWF0Y2hlcyB0aGVcblx0KiBnaXZlbiBgcXVlcnlLZXlgLCB2aWEge0BsaW5rIFF1ZXJ5Q2xpZW50I3NldFF1ZXJ5RGVmYXVsdHN9LiBJZiBtdWx0aXBsZSByZWdpc3RlcmVkIGRlZmF1bHRzXG5cdCogbWF0Y2gsIHRoZXkgYXJlIG1lcmdlZCB0b2dldGhlciBpbiByZWdpc3RyYXRpb24gb3JkZXIuXG5cdCogQHBhcmFtIHF1ZXJ5S2V5IC0gVGhlIHF1ZXJ5IGtleSB0byBsb29rIHVwIHJlZ2lzdGVyZWQgZGVmYXVsdHMgZm9yLlxuXHQqIEByZXR1cm5zIFRoZSBtZXJnZWQgZGVmYXVsdCBvcHRpb25zIG9mIGV2ZXJ5IHJlZ2lzdHJhdGlvbiB0aGF0IG1hdGNoZXMsIG9yIGFuIGVtcHR5IG9iamVjdCBpZlxuXHQqIG5vbmUgbWF0Y2guXG5cdCogQGV4YW1wbGVcblx0KiBgYGB0c1xuXHQqIGNvbnN0IGRlZmF1bHRPcHRpb25zID0gcXVlcnlDbGllbnQuZ2V0UXVlcnlEZWZhdWx0cyhbJ3Bvc3RzJ10pXG5cdCogYGBgXG5cdCovXG5cdGdldFF1ZXJ5RGVmYXVsdHMocXVlcnlLZXkpIHtcblx0XHRjb25zdCBkZWZhdWx0cyA9IFsuLi50aGlzLiNxdWVyeURlZmF1bHRzLnZhbHVlcygpXTtcblx0XHRjb25zdCByZXN1bHQgPSB7fTtcblx0XHRkZWZhdWx0cy5mb3JFYWNoKChxdWVyeURlZmF1bHQpID0+IHtcblx0XHRcdGlmIChwYXJ0aWFsTWF0Y2hLZXkocXVlcnlLZXksIHF1ZXJ5RGVmYXVsdC5xdWVyeUtleSkpIE9iamVjdC5hc3NpZ24ocmVzdWx0LCBxdWVyeURlZmF1bHQuZGVmYXVsdE9wdGlvbnMpO1xuXHRcdH0pO1xuXHRcdHJldHVybiByZXN1bHQ7XG5cdH1cblx0LyoqXG5cdCogU2V0cyBkZWZhdWx0IG9wdGlvbnMgZm9yIG11dGF0aW9ucyB3aG9zZSBtdXRhdGlvbiBrZXkgcGFydGlhbGx5IG1hdGNoZXMgdGhlIGdpdmVuXG5cdCogYG11dGF0aW9uS2V5YC4gQXMgd2l0aCB7QGxpbmsgUXVlcnlDbGllbnQjc2V0UXVlcnlEZWZhdWx0c30sIHRoZSBvcmRlciBvZiByZWdpc3RyYXRpb25cblx0KiBtYXR0ZXJzIHdoZW4gc2V2ZXJhbCByZWdpc3RlcmVkIGRlZmF1bHRzIG1hdGNoIHRoZSBzYW1lIG11dGF0aW9uIGtleS5cblx0KiBAcGFyYW0gbXV0YXRpb25LZXkgLSBUaGUgbXV0YXRpb24ga2V5IHRoYXQgbXV0YXRpb24ga2V5cyBhcmUgcGFydGlhbGx5IG1hdGNoZWQgYWdhaW5zdC5cblx0KiBAcGFyYW0gb3B0aW9ucyAtIFRoZSBkZWZhdWx0IG9wdGlvbnMgYXBwbGllZCB0byBtYXRjaGluZyBtdXRhdGlvbnMuXG5cdCogQHNlZSB7QGxpbmsgUXVlcnlDbGllbnQjZ2V0TXV0YXRpb25EZWZhdWx0c31cblx0KiBAZXhhbXBsZVxuXHQqIGBgYHRzXG5cdCogcXVlcnlDbGllbnQuc2V0TXV0YXRpb25EZWZhdWx0cyhbJ2FkZFBvc3QnXSwgeyBtdXRhdGlvbkZuOiBhZGRQb3N0IH0pXG5cdCogYGBgXG5cdCovXG5cdHNldE11dGF0aW9uRGVmYXVsdHMobXV0YXRpb25LZXksIG9wdGlvbnMpIHtcblx0XHR0aGlzLiNtdXRhdGlvbkRlZmF1bHRzLnNldChoYXNoS2V5KG11dGF0aW9uS2V5KSwge1xuXHRcdFx0bXV0YXRpb25LZXksXG5cdFx0XHRkZWZhdWx0T3B0aW9uczogb3B0aW9uc1xuXHRcdH0pO1xuXHR9XG5cdC8qKlxuXHQqIFJldHVybnMgdGhlIGRlZmF1bHQgb3B0aW9ucyByZWdpc3RlcmVkIGZvciBtdXRhdGlvbnMgd2hvc2UgbXV0YXRpb24ga2V5IHBhcnRpYWxseSBtYXRjaGVzXG5cdCogdGhlIGdpdmVuIGBtdXRhdGlvbktleWAsIHZpYSB7QGxpbmsgUXVlcnlDbGllbnQjc2V0TXV0YXRpb25EZWZhdWx0c30uIElmIG11bHRpcGxlIHJlZ2lzdGVyZWRcblx0KiBkZWZhdWx0cyBtYXRjaCwgdGhleSBhcmUgbWVyZ2VkIHRvZ2V0aGVyIGluIHJlZ2lzdHJhdGlvbiBvcmRlci5cblx0KiBAcGFyYW0gbXV0YXRpb25LZXkgLSBUaGUgbXV0YXRpb24ga2V5IHRvIGxvb2sgdXAgcmVnaXN0ZXJlZCBkZWZhdWx0cyBmb3IuXG5cdCogQHJldHVybnMgVGhlIG1lcmdlZCBkZWZhdWx0IG9wdGlvbnMgb2YgZXZlcnkgcmVnaXN0cmF0aW9uIHRoYXQgbWF0Y2hlcywgb3IgYW4gZW1wdHkgb2JqZWN0IGlmXG5cdCogbm9uZSBtYXRjaC5cblx0KiBAZXhhbXBsZVxuXHQqIGBgYHRzXG5cdCogY29uc3QgZGVmYXVsdE9wdGlvbnMgPSBxdWVyeUNsaWVudC5nZXRNdXRhdGlvbkRlZmF1bHRzKFsnYWRkUG9zdCddKVxuXHQqIGBgYFxuXHQqL1xuXHRnZXRNdXRhdGlvbkRlZmF1bHRzKG11dGF0aW9uS2V5KSB7XG5cdFx0Y29uc3QgZGVmYXVsdHMgPSBbLi4udGhpcy4jbXV0YXRpb25EZWZhdWx0cy52YWx1ZXMoKV07XG5cdFx0Y29uc3QgcmVzdWx0ID0ge307XG5cdFx0ZGVmYXVsdHMuZm9yRWFjaCgocXVlcnlEZWZhdWx0KSA9PiB7XG5cdFx0XHRpZiAocGFydGlhbE1hdGNoS2V5KG11dGF0aW9uS2V5LCBxdWVyeURlZmF1bHQubXV0YXRpb25LZXkpKSBPYmplY3QuYXNzaWduKHJlc3VsdCwgcXVlcnlEZWZhdWx0LmRlZmF1bHRPcHRpb25zKTtcblx0XHR9KTtcblx0XHRyZXR1cm4gcmVzdWx0O1xuXHR9XG5cdC8qKlxuXHQqIENhbGxlZCBieSBmcmFtZXdvcmsgYWRhcHRlcnMgKGUuZy4gaW5zaWRlIGB1c2VRdWVyeWApIHRvIHJlc29sdmUgdGhlIG9wdGlvbnMgcGFzc2VkIGJ5IHRoZVxuXHQqIGNhbGxlciBpbnRvIHRoZWlyIGZpbmFsLCBkZWZhdWx0ZWQgZm9ybTogbWVyZ2luZyB0aGUgY2xpZW50J3Mgb3duIGBkZWZhdWx0T3B0aW9ucy5xdWVyaWVzYCxcblx0KiB0aGVuIGBxdWVyeUNsaWVudC5zZXRRdWVyeURlZmF1bHRzYCBmb3IgdGhlIGdpdmVuIGBxdWVyeUtleWAsIHRoZW4gdGhlIGNhbGxlcidzIG9wdGlvbnMgb25cblx0KiB0b3AuIEEgbm8tb3AgaWYgdGhlIG9wdGlvbnMgYXJlIGFscmVhZHkgZGVmYXVsdGVkIChgX2RlZmF1bHRlZDogdHJ1ZWApLlxuXHQqIEBwYXJhbSBvcHRpb25zIC0gVGhlIHF1ZXJ5IG9wdGlvbnMgcGFzc2VkIGJ5IHRoZSBjYWxsZXIuXG5cdCogQHJldHVybnMgVGhlIGRlZmF1bHRlZCBvcHRpb25zLCB3aXRoIGBxdWVyeUhhc2hgIGFuZCBkZXBlbmRlbnQgZGVmYXVsdHMgKGUuZy5cblx0KiBgcmVmZXRjaE9uUmVjb25uZWN0YCkgZmlsbGVkIGluLlxuXHQqL1xuXHRkZWZhdWx0UXVlcnlPcHRpb25zKG9wdGlvbnMpIHtcblx0XHRpZiAob3B0aW9ucy5fZGVmYXVsdGVkKSByZXR1cm4gb3B0aW9ucztcblx0XHRjb25zdCBkZWZhdWx0ZWRPcHRpb25zID0ge1xuXHRcdFx0Li4udGhpcy4jZGVmYXVsdE9wdGlvbnMucXVlcmllcyxcblx0XHRcdC4uLnRoaXMuZ2V0UXVlcnlEZWZhdWx0cyhvcHRpb25zLnF1ZXJ5S2V5KSxcblx0XHRcdC4uLm9wdGlvbnMsXG5cdFx0XHRfZGVmYXVsdGVkOiB0cnVlXG5cdFx0fTtcblx0XHRpZiAoIWRlZmF1bHRlZE9wdGlvbnMucXVlcnlIYXNoKSBkZWZhdWx0ZWRPcHRpb25zLnF1ZXJ5SGFzaCA9IGhhc2hRdWVyeUtleUJ5T3B0aW9ucyhkZWZhdWx0ZWRPcHRpb25zLnF1ZXJ5S2V5LCBkZWZhdWx0ZWRPcHRpb25zKTtcblx0XHRpZiAoZGVmYXVsdGVkT3B0aW9ucy5yZWZldGNoT25SZWNvbm5lY3QgPT09IHZvaWQgMCkgZGVmYXVsdGVkT3B0aW9ucy5yZWZldGNoT25SZWNvbm5lY3QgPSBkZWZhdWx0ZWRPcHRpb25zLm5ldHdvcmtNb2RlICE9PSBcImFsd2F5c1wiO1xuXHRcdGlmIChkZWZhdWx0ZWRPcHRpb25zLnRocm93T25FcnJvciA9PT0gdm9pZCAwKSBkZWZhdWx0ZWRPcHRpb25zLnRocm93T25FcnJvciA9ICEhZGVmYXVsdGVkT3B0aW9ucy5zdXNwZW5zZTtcblx0XHRpZiAoIWRlZmF1bHRlZE9wdGlvbnMubmV0d29ya01vZGUgJiYgZGVmYXVsdGVkT3B0aW9ucy5wZXJzaXN0ZXIpIGRlZmF1bHRlZE9wdGlvbnMubmV0d29ya01vZGUgPSBcIm9mZmxpbmVGaXJzdFwiO1xuXHRcdGlmIChkZWZhdWx0ZWRPcHRpb25zLnF1ZXJ5Rm4gPT09IHNraXBUb2tlbikgZGVmYXVsdGVkT3B0aW9ucy5lbmFibGVkID0gZmFsc2U7XG5cdFx0cmV0dXJuIGRlZmF1bHRlZE9wdGlvbnM7XG5cdH1cblx0LyoqXG5cdCogVGhlIG11dGF0aW9uIGNvdW50ZXJwYXJ0IG9mIHtAbGluayBRdWVyeUNsaWVudCNkZWZhdWx0UXVlcnlPcHRpb25zfS4gQ2FsbGVkIGJ5IGZyYW1ld29ya1xuXHQqIGFkYXB0ZXJzIChlLmcuIGluc2lkZSBgdXNlTXV0YXRpb25gKSB0byBtZXJnZSB0aGUgY2xpZW50J3MgYGRlZmF1bHRPcHRpb25zLm11dGF0aW9uc2AsIHRoZW5cblx0KiBgcXVlcnlDbGllbnQuc2V0TXV0YXRpb25EZWZhdWx0c2AgZm9yIHRoZSBnaXZlbiBgbXV0YXRpb25LZXlgLCB0aGVuIHRoZSBjYWxsZXIncyBvcHRpb25zIG9uXG5cdCogdG9wLiBBIG5vLW9wIGlmIHRoZSBvcHRpb25zIGFyZSBhbHJlYWR5IGRlZmF1bHRlZCAoYF9kZWZhdWx0ZWQ6IHRydWVgKS5cblx0KiBAcGFyYW0gb3B0aW9ucyAtIFRoZSBtdXRhdGlvbiBvcHRpb25zIHBhc3NlZCBieSB0aGUgY2FsbGVyLlxuXHQqIEByZXR1cm5zIFRoZSBkZWZhdWx0ZWQgb3B0aW9ucy5cblx0Ki9cblx0ZGVmYXVsdE11dGF0aW9uT3B0aW9ucyhvcHRpb25zKSB7XG5cdFx0aWYgKG9wdGlvbnM/Ll9kZWZhdWx0ZWQpIHJldHVybiBvcHRpb25zO1xuXHRcdHJldHVybiB7XG5cdFx0XHQuLi50aGlzLiNkZWZhdWx0T3B0aW9ucy5tdXRhdGlvbnMsXG5cdFx0XHQuLi5vcHRpb25zPy5tdXRhdGlvbktleSAmJiB0aGlzLmdldE11dGF0aW9uRGVmYXVsdHMob3B0aW9ucy5tdXRhdGlvbktleSksXG5cdFx0XHQuLi5vcHRpb25zLFxuXHRcdFx0X2RlZmF1bHRlZDogdHJ1ZVxuXHRcdH07XG5cdH1cblx0LyoqXG5cdCogQ2xlYXJzIGJvdGggdGhlIHF1ZXJ5IGNhY2hlIGFuZCB0aGUgbXV0YXRpb24gY2FjaGUgdGhpcyBjbGllbnQgaXMgY29ubmVjdGVkIHRvLlxuXHQqIEBleGFtcGxlXG5cdCogYGBgdHNcblx0KiBpbXBvcnQgeyBRdWVyeUNsaWVudCB9IGZyb20gJ0B0YW5zdGFjay9xdWVyeS1jb3JlJ1xuXHQqXG5cdCogY29uc3QgcXVlcnlDbGllbnQgPSBuZXcgUXVlcnlDbGllbnQoKVxuXHQqIHF1ZXJ5Q2xpZW50LmNsZWFyKClcblx0KiBgYGBcblx0Ki9cblx0Y2xlYXIoKSB7XG5cdFx0dGhpcy4jcXVlcnlDYWNoZS5jbGVhcigpO1xuXHRcdHRoaXMuI211dGF0aW9uQ2FjaGUuY2xlYXIoKTtcblx0fVxufTtcbmV4cG9ydCB7IFF1ZXJ5Q2xpZW50IH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXF1ZXJ5Q2xpZW50LmpzLm1hcCIsImltcG9ydCB7IGFkZENvbnN1bWVBd2FyZVNpZ25hbCwgYWRkVG9FbmQsIGZldGNoU2lnbmFsIH0gZnJvbSBcIi4vdXRpbHMuanNcIjtcbi8vIHNyYy9zdHJlYW1lZFF1ZXJ5LnRzXG4vKipcbiogVGhpcyBpcyBhIGhlbHBlciBmdW5jdGlvbiB0byBjcmVhdGUgYSBxdWVyeSBmdW5jdGlvbiB0aGF0IHN0cmVhbXMgZGF0YSBmcm9tIGFuIEFzeW5jSXRlcmFibGUuXG4qIERhdGEgd2lsbCBiZSBhbiBBcnJheSBvZiBhbGwgdGhlIGNodW5rcyByZWNlaXZlZC5cbiogVGhlIHF1ZXJ5IHdpbGwgYmUgaW4gYSAncGVuZGluZycgc3RhdGUgdW50aWwgdGhlIGZpcnN0IGNodW5rIG9mIGRhdGEgaXMgcmVjZWl2ZWQsIGJ1dCB3aWxsIGdvIHRvICdzdWNjZXNzJyBhZnRlciB0aGF0LlxuKiBUaGUgcXVlcnkgd2lsbCBzdGF5IGluIGZldGNoU3RhdHVzICdmZXRjaGluZycgdW50aWwgdGhlIHN0cmVhbSBlbmRzLlxuKiBFeHBsaWNpdCBjYW5jZWxsYXRpb24gc3RvcHMgZnVydGhlciBjYWNoZSB1cGRhdGVzLCBldmVuIGlmIGBzdHJlYW1GbmAgZG9lcyBub3QgcmVhZCBgc2lnbmFsYC5cbiogSWYgYHN0cmVhbUZuYCBkb2VzIG5vdCByZWFkIGBzaWduYWxgLCB0aGUgc3RyZWFtIGNvbnRpbnVlcyBhZnRlciB0aGUgbGFzdCBvYnNlcnZlciB1bnN1YnNjcmliZXMuXG4qIEBwYXJhbSBvcHRpb25zIC0gVGhlIGBzdHJlYW1GbmAgdGhhdCByZXR1cm5zIGFuIEFzeW5jSXRlcmFibGUgdG8gc3RyZWFtIGRhdGEgZnJvbSwgYW5kIHRoZSBvcHRpb25hbFxuKiBgcmVmZXRjaE1vZGVgLCBgcmVkdWNlcmAsIGFuZCBgaW5pdGlhbFZhbHVlYCBvcHRpb25zLlxuKiBAcmV0dXJucyBBIHF1ZXJ5IGZ1bmN0aW9uIHRvIHBhc3MgYXMgYHF1ZXJ5Rm5gLlxuKiBAZXhhbXBsZVxuKiBgYGB0c1xuKiBhd2FpdCBxdWVyeUNsaWVudC5xdWVyeSh7XG4qICAgcXVlcnlLZXk6IFsnZGF0YSddLFxuKiAgIHF1ZXJ5Rm46IHN0cmVhbWVkUXVlcnkoe1xuKiAgICAgc3RyZWFtRm46IGZldGNoRGF0YUluQ2h1bmtzLFxuKiAgIH0pLFxuKiB9KVxuKiBgYGBcbiovXG5mdW5jdGlvbiBzdHJlYW1lZFF1ZXJ5KHsgc3RyZWFtRm4sIHJlZmV0Y2hNb2RlID0gXCJyZXNldFwiLCByZWR1Y2VyID0gKGl0ZW1zLCBjaHVuaykgPT4gYWRkVG9FbmQoaXRlbXMsIGNodW5rKSwgaW5pdGlhbFZhbHVlID0gW10gfSkge1xuXHRyZXR1cm4gYXN5bmMgKGNvbnRleHQpID0+IHtcblx0XHRjb25zdCBzaWduYWwgPSBjb250ZXh0W2ZldGNoU2lnbmFsXTtcblx0XHRpZiAoc2lnbmFsPy5hYm9ydGVkKSByZXR1cm4gaW5pdGlhbFZhbHVlO1xuXHRcdGNvbnN0IHF1ZXJ5ID0gY29udGV4dC5jbGllbnQuZ2V0UXVlcnlDYWNoZSgpLmZpbmQoe1xuXHRcdFx0cXVlcnlLZXk6IGNvbnRleHQucXVlcnlLZXksXG5cdFx0XHRleGFjdDogdHJ1ZVxuXHRcdH0pO1xuXHRcdGNvbnN0IGlzUmVmZXRjaCA9ICEhcXVlcnkgJiYgcXVlcnkuaXNGZXRjaGVkKCk7XG5cdFx0aWYgKGlzUmVmZXRjaCAmJiByZWZldGNoTW9kZSA9PT0gXCJyZXNldFwiKSBxdWVyeS5zZXRTdGF0ZSh7XG5cdFx0XHQuLi5xdWVyeS5yZXNldFN0YXRlLFxuXHRcdFx0ZmV0Y2hTdGF0dXM6IFwiZmV0Y2hpbmdcIlxuXHRcdH0pO1xuXHRcdGxldCByZXN1bHQgPSBpbml0aWFsVmFsdWU7XG5cdFx0bGV0IGNhbmNlbGxlZCA9IGZhbHNlO1xuXHRcdGNvbnN0IHN0cmVhbUZuQ29udGV4dCA9IGFkZENvbnN1bWVBd2FyZVNpZ25hbCh7XG5cdFx0XHRjbGllbnQ6IGNvbnRleHQuY2xpZW50LFxuXHRcdFx0bWV0YTogY29udGV4dC5tZXRhLFxuXHRcdFx0cXVlcnlLZXk6IGNvbnRleHQucXVlcnlLZXksXG5cdFx0XHRwYWdlUGFyYW06IGNvbnRleHQucGFnZVBhcmFtLFxuXHRcdFx0ZGlyZWN0aW9uOiBjb250ZXh0LmRpcmVjdGlvblxuXHRcdH0sICgpID0+IGNvbnRleHQuc2lnbmFsLCAoKSA9PiBjYW5jZWxsZWQgPSB0cnVlLCBzaWduYWwpO1xuXHRcdGNvbnN0IGlzU3RyZWFtSW5hY3RpdmUgPSAoKSA9PiBjYW5jZWxsZWQgfHwgc2lnbmFsPy5hYm9ydGVkID09PSB0cnVlO1xuXHRcdGNvbnN0IHN0cmVhbSA9IGF3YWl0IHN0cmVhbUZuKHN0cmVhbUZuQ29udGV4dCk7XG5cdFx0Y29uc3QgaXNSZXBsYWNlUmVmZXRjaCA9IGlzUmVmZXRjaCAmJiByZWZldGNoTW9kZSA9PT0gXCJyZXBsYWNlXCI7XG5cdFx0Zm9yIGF3YWl0IChjb25zdCBjaHVuayBvZiBzdHJlYW0pIHtcblx0XHRcdGlmIChpc1N0cmVhbUluYWN0aXZlKCkpIGJyZWFrO1xuXHRcdFx0aWYgKGlzUmVwbGFjZVJlZmV0Y2gpIHJlc3VsdCA9IHJlZHVjZXIocmVzdWx0LCBjaHVuayk7XG5cdFx0XHRlbHNlIGNvbnRleHQuY2xpZW50LnNldFF1ZXJ5RGF0YShjb250ZXh0LnF1ZXJ5S2V5LCAocHJldikgPT4gcmVkdWNlcihwcmV2ID09PSB2b2lkIDAgPyBpbml0aWFsVmFsdWUgOiBwcmV2LCBjaHVuaykpO1xuXHRcdH1cblx0XHRpZiAoaXNSZXBsYWNlUmVmZXRjaCAmJiAhaXNTdHJlYW1JbmFjdGl2ZSgpKSBjb250ZXh0LmNsaWVudC5zZXRRdWVyeURhdGEoY29udGV4dC5xdWVyeUtleSwgcmVzdWx0KTtcblx0XHRjb25zdCBkYXRhID0gY29udGV4dC5jbGllbnQuZ2V0UXVlcnlEYXRhKGNvbnRleHQucXVlcnlLZXkpO1xuXHRcdHJldHVybiBkYXRhID09PSB2b2lkIDAgPyBpbml0aWFsVmFsdWUgOiBkYXRhO1xuXHR9O1xufVxuZXhwb3J0IHsgc3RyZWFtZWRRdWVyeSB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1zdHJlYW1lZFF1ZXJ5LmpzLm1hcCIsIi8vIHNyYy90eXBlcy50c1xuLyogaXN0YW5idWwgaWdub3JlIGZpbGUgKi9cbmNvbnN0IGRhdGFUYWdTeW1ib2wgPSBTeW1ib2woKTtcbmNvbnN0IGRhdGFUYWdFcnJvclN5bWJvbCA9IFN5bWJvbCgpO1xuY29uc3QgdW5zZXRNYXJrZXIgPSBTeW1ib2woKTtcbmV4cG9ydCB7IGRhdGFUYWdFcnJvclN5bWJvbCwgZGF0YVRhZ1N5bWJvbCwgdW5zZXRNYXJrZXIgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9dHlwZXMuanMubWFwIiwiXCJ1c2UgY2xpZW50XCI7XG5pbXBvcnQgeyB1c2VRdWVyeUNsaWVudCB9IGZyb20gXCIuL1F1ZXJ5Q2xpZW50UHJvdmlkZXIuanNcIjtcbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgaHlkcmF0ZSB9IGZyb20gXCJAdGFuc3RhY2svcXVlcnktY29yZVwiO1xuLy8gc3JjL0h5ZHJhdGlvbkJvdW5kYXJ5LnRzeFxuLyoqXG4qIGBIeWRyYXRpb25Cb3VuZGFyeWAgYWRkcyBhIHByZXZpb3VzbHkgZGVoeWRyYXRlZCBzdGF0ZSBpbnRvIHRoZSBgcXVlcnlDbGllbnRgIHRoYXQgd291bGQgYmUgcmV0dXJuZWQgYnlcbiogYHVzZVF1ZXJ5Q2xpZW50KClgLiBJZiB0aGUgY2xpZW50IGFscmVhZHkgY29udGFpbnMgZGF0YSwgdGhlIG5ldyBxdWVyaWVzIHdpbGwgYmUgaW50ZWxsaWdlbnRseSBtZXJnZWQgYmFzZWQgb25cbiogdXBkYXRlIHRpbWVzdGFtcC5cbipcbiogTm90ZTogT25seSBgcXVlcmllc2AgY2FuIGJlIGRlaHlkcmF0ZWQgd2l0aCBhbiBgSHlkcmF0aW9uQm91bmRhcnlgLlxuKiBAcGFyYW0gcHJvcHMgLSBUaGUgZGVoeWRyYXRlZCBgc3RhdGVgIHRvIGh5ZHJhdGUsIHRoZSBoeWRyYXRlIGBvcHRpb25zYCwgYW4gb3B0aW9uYWwgY3VzdG9tXG4qIGBxdWVyeUNsaWVudGAsIGFuZCB0aGUgYGNoaWxkcmVuYCB0byByZW5kZXIuXG4qIEByZXR1cm5zIFRoZSBwcm92aWRlZCBgY2hpbGRyZW5gLCByZW5kZXJlZCB1bmNvbmRpdGlvbmFsbHkuIE5ldyBxdWVyaWVzIGluIGBzdGF0ZWAgYXJlIGh5ZHJhdGVkIGludG8gdGhlXG4qIGNhY2hlIGR1cmluZyByZW5kZXI7IGZvciBxdWVyaWVzIGFscmVhZHkgaW4gdGhlIGNhY2hlLCBvbmx5IG5ld2VyIGRlaHlkcmF0ZWQgZGF0YSBpcyBoeWRyYXRlZCwgaW4gYW4gZWZmZWN0XG4qIGFmdGVyIGNvbW1pdC5cbiogQGV4YW1wbGVcbiogYGBgdHN4XG4qIGltcG9ydCB7IEh5ZHJhdGlvbkJvdW5kYXJ5IH0gZnJvbSAnQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5J1xuKlxuKiBmdW5jdGlvbiBBcHAoKSB7XG4qICAgcmV0dXJuIDxIeWRyYXRpb25Cb3VuZGFyeSBzdGF0ZT17ZGVoeWRyYXRlZFN0YXRlfT4uLi48L0h5ZHJhdGlvbkJvdW5kYXJ5PlxuKiB9XG4qIGBgYFxuKiBAZXhhbXBsZVxuKiBTZXJ2ZXItc2lkZSBwcmVmZXRjaCBoYW5kZWQgb2ZmIHRvIHRoZSBjbGllbnQgdmlhIGBkZWh5ZHJhdGVgOlxuKiBgYGB0c3hcbiogaW1wb3J0IHsgSHlkcmF0aW9uQm91bmRhcnksIGRlaHlkcmF0ZSwgbm9vcCB9IGZyb20gJ0B0YW5zdGFjay9yZWFjdC1xdWVyeSdcbipcbiogYXN5bmMgZnVuY3Rpb24gU2VydmVyQ29tcG9uZW50KCkge1xuKiAgIGNvbnN0IHF1ZXJ5Q2xpZW50ID0gZ2V0UXVlcnlDbGllbnQoKVxuKlxuKiAgIGF3YWl0IHF1ZXJ5Q2xpZW50XG4qICAgICAucXVlcnkoe1xuKiAgICAgICBxdWVyeUtleTogWydwb3N0cyddLFxuKiAgICAgICBxdWVyeUZuOiBmZXRjaFBvc3RzLFxuKiAgICAgfSlcbiogICAgIC5jYXRjaChub29wKVxuKlxuKiAgIHJldHVybiAoXG4qICAgICA8SHlkcmF0aW9uQm91bmRhcnkgc3RhdGU9e2RlaHlkcmF0ZShxdWVyeUNsaWVudCl9PlxuKiAgICAgICA8UG9zdHMgLz5cbiogICAgIDwvSHlkcmF0aW9uQm91bmRhcnk+XG4qICAgKVxuKiB9XG4qIGBgYFxuKi9cbmNvbnN0IEh5ZHJhdGlvbkJvdW5kYXJ5ID0gKHsgY2hpbGRyZW4sIG9wdGlvbnMgPSB7fSwgc3RhdGUsIHF1ZXJ5Q2xpZW50IH0pID0+IHtcblx0Y29uc3QgY2xpZW50ID0gdXNlUXVlcnlDbGllbnQocXVlcnlDbGllbnQpO1xuXHRjb25zdCBvcHRpb25zUmVmID0gUmVhY3QudXNlUmVmKG9wdGlvbnMpO1xuXHRSZWFjdC51c2VFZmZlY3QoKCkgPT4ge1xuXHRcdG9wdGlvbnNSZWYuY3VycmVudCA9IG9wdGlvbnM7XG5cdH0pO1xuXHRjb25zdCBoeWRyYXRpb25RdWV1ZSA9IFJlYWN0LnVzZU1lbW8oKCkgPT4ge1xuXHRcdGlmIChzdGF0ZSkge1xuXHRcdFx0aWYgKHR5cGVvZiBzdGF0ZSAhPT0gXCJvYmplY3RcIikgcmV0dXJuO1xuXHRcdFx0Y29uc3QgcXVlcnlDYWNoZSA9IGNsaWVudC5nZXRRdWVyeUNhY2hlKCk7XG5cdFx0XHRjb25zdCBxdWVyaWVzID0gc3RhdGUucXVlcmllcyB8fCBbXTtcblx0XHRcdGNvbnN0IG5ld1F1ZXJpZXMgPSBbXTtcblx0XHRcdGNvbnN0IGV4aXN0aW5nUXVlcmllcyA9IFtdO1xuXHRcdFx0Zm9yIChjb25zdCBkZWh5ZHJhdGVkUXVlcnkgb2YgcXVlcmllcykge1xuXHRcdFx0XHRjb25zdCBleGlzdGluZ1F1ZXJ5ID0gcXVlcnlDYWNoZS5nZXQoZGVoeWRyYXRlZFF1ZXJ5LnF1ZXJ5SGFzaCk7XG5cdFx0XHRcdGlmICghZXhpc3RpbmdRdWVyeSkgbmV3UXVlcmllcy5wdXNoKGRlaHlkcmF0ZWRRdWVyeSk7XG5cdFx0XHRcdGVsc2UgaWYgKGRlaHlkcmF0ZWRRdWVyeS5zdGF0ZS5kYXRhVXBkYXRlZEF0ID4gZXhpc3RpbmdRdWVyeS5zdGF0ZS5kYXRhVXBkYXRlZEF0IHx8IGRlaHlkcmF0ZWRRdWVyeS5wcm9taXNlICYmIGV4aXN0aW5nUXVlcnkuc3RhdGUuc3RhdHVzICE9PSBcInBlbmRpbmdcIiAmJiBleGlzdGluZ1F1ZXJ5LnN0YXRlLmZldGNoU3RhdHVzICE9PSBcImZldGNoaW5nXCIgJiYgZGVoeWRyYXRlZFF1ZXJ5LmRlaHlkcmF0ZWRBdCA+IGV4aXN0aW5nUXVlcnkuc3RhdGUuZGF0YVVwZGF0ZWRBdCkgZXhpc3RpbmdRdWVyaWVzLnB1c2goZGVoeWRyYXRlZFF1ZXJ5KTtcblx0XHRcdH1cblx0XHRcdGlmIChuZXdRdWVyaWVzLmxlbmd0aCA+IDApIGh5ZHJhdGUoY2xpZW50LCB7IHF1ZXJpZXM6IG5ld1F1ZXJpZXMgfSwgb3B0aW9uc1JlZi5jdXJyZW50KTtcblx0XHRcdGlmIChleGlzdGluZ1F1ZXJpZXMubGVuZ3RoID4gMCkgcmV0dXJuIGV4aXN0aW5nUXVlcmllcztcblx0XHR9XG5cdH0sIFtjbGllbnQsIHN0YXRlXSk7XG5cdFJlYWN0LnVzZUVmZmVjdCgoKSA9PiB7XG5cdFx0aWYgKGh5ZHJhdGlvblF1ZXVlKSBoeWRyYXRlKGNsaWVudCwgeyBxdWVyaWVzOiBoeWRyYXRpb25RdWV1ZSB9LCBvcHRpb25zUmVmLmN1cnJlbnQpO1xuXHR9LCBbY2xpZW50LCBoeWRyYXRpb25RdWV1ZV0pO1xuXHRyZXR1cm4gY2hpbGRyZW47XG59O1xuZXhwb3J0IHsgSHlkcmF0aW9uQm91bmRhcnkgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9SHlkcmF0aW9uQm91bmRhcnkuanMubWFwIiwiXCJ1c2UgY2xpZW50XCI7XG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tIFwicmVhY3RcIjtcbi8vIHNyYy9Jc1Jlc3RvcmluZ1Byb3ZpZGVyLnRzXG5jb25zdCBJc1Jlc3RvcmluZ0NvbnRleHQgPSBSZWFjdC5jcmVhdGVDb250ZXh0KGZhbHNlKTtcbi8qKlxuKiBJZiB5b3UgYXJlIHVzaW5nIGBQZXJzaXN0UXVlcnlDbGllbnRQcm92aWRlcmAsIHlvdSBjYW4gYWxzbyB1c2UgdGhlIGB1c2VJc1Jlc3RvcmluZ2AgaG9vayBhbG9uZ3NpZGUgaXQgdG9cbiogY2hlY2sgaWYgYSByZXN0b3JlIGlzIGN1cnJlbnRseSBpbiBwcm9ncmVzcy4gYHVzZVF1ZXJ5YCBhbmQgZnJpZW5kcyBhbHNvIGNoZWNrIHRoaXMgaW50ZXJuYWxseSB0byBhdm9pZFxuKiByYWNlIGNvbmRpdGlvbnMgYmV0d2VlbiB0aGUgcmVzdG9yZSBhbmQgbW91bnRpbmcgcXVlcmllcy5cbiogQHJldHVybnMgYHRydWVgIHdoaWxlIGEgcGVyc2lzdGVkIGNsaWVudCBpcyBiZWluZyByZXN0b3JlZCwgYGZhbHNlYCBvdGhlcndpc2UuXG4qL1xuY29uc3QgdXNlSXNSZXN0b3JpbmcgPSAoKSA9PiBSZWFjdC51c2VDb250ZXh0KElzUmVzdG9yaW5nQ29udGV4dCk7XG4vKipcbiogVGhlIFByb3ZpZGVyIHRoYXQgYFBlcnNpc3RRdWVyeUNsaWVudFByb3ZpZGVyYCB1c2VzIHRvIHNpZ25hbCB3aGV0aGVyIGEgcGVyc2lzdGVkIGNsaWVudCBpcyBjdXJyZW50bHlcbiogYmVpbmcgcmVzdG9yZWQsIHJlYWQgYnkgYHVzZUlzUmVzdG9yaW5nYC5cbiovXG5jb25zdCBJc1Jlc3RvcmluZ1Byb3ZpZGVyID0gSXNSZXN0b3JpbmdDb250ZXh0LlByb3ZpZGVyO1xuZXhwb3J0IHsgSXNSZXN0b3JpbmdQcm92aWRlciwgdXNlSXNSZXN0b3JpbmcgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9SXNSZXN0b3JpbmdQcm92aWRlci5qcy5tYXAiLCJcInVzZSBjbGllbnRcIjtcbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsganN4IH0gZnJvbSBcInJlYWN0L2pzeC1ydW50aW1lXCI7XG4vLyBzcmMvUXVlcnlFcnJvclJlc2V0Qm91bmRhcnkudHN4XG4vKipcbiogQ3JlYXRlcyB0aGUgdmFsdWUgc2hhcmVkIHRocm91Z2ggdGhlIGJvdW5kYXJ5J3MgY29udGV4dCwgd2hpY2ggdHJhY2tzIHdoZXRoZXIgYSByZXNldCB3YXNcbiogcmVxdWVzdGVkLlxuKiBAcmV0dXJucyBUaGUgYGNsZWFyUmVzZXRgLCBgaXNSZXNldGAsIGFuZCBgcmVzZXRgIGZ1bmN0aW9ucyBvZiB0aGUgYm91bmRhcnkuXG4qL1xuZnVuY3Rpb24gY3JlYXRlVmFsdWUoKSB7XG5cdGxldCBpc1Jlc2V0ID0gZmFsc2U7XG5cdHJldHVybiB7XG5cdFx0LyoqXG5cdFx0KiBDbGVhcnMgdGhlIHJlc2V0IHN0YXRlLCBzbyBxdWVyaWVzIGtub3cgbm90IHRvIHRyeSBhZ2FpbiB1bnRpbCB0aGUgYm91bmRhcnkgaXMgcmVzZXQgYWdhaW4uXG5cdFx0Ki9cblx0XHRjbGVhclJlc2V0OiAoKSA9PiB7XG5cdFx0XHRpc1Jlc2V0ID0gZmFsc2U7XG5cdFx0fSxcblx0XHQvKipcblx0XHQqIFJlc2V0cyBhbnkgcXVlcnkgZXJyb3JzIHdpdGhpbiB0aGUgYm91bmRhcnksIHNvIHF1ZXJpZXMga25vdyB0aGV5IGNhbiB0cnkgYWdhaW4uXG5cdFx0Ki9cblx0XHRyZXNldDogKCkgPT4ge1xuXHRcdFx0aXNSZXNldCA9IHRydWU7XG5cdFx0fSxcblx0XHQvKipcblx0XHQqIFJldHVybnMgd2hldGhlciB0aGUgYm91bmRhcnkgaGFzIGJlZW4gcmVzZXQgYW5kIG5vdCB5ZXQgY2xlYXJlZC5cblx0XHQqIEByZXR1cm5zIGB0cnVlYCBpZiB0aGUgYm91bmRhcnkgaGFzIGJlZW4gcmVzZXQgYW5kIG5vdCB5ZXQgY2xlYXJlZC5cblx0XHQqL1xuXHRcdGlzUmVzZXQ6ICgpID0+IHtcblx0XHRcdHJldHVybiBpc1Jlc2V0O1xuXHRcdH1cblx0fTtcbn1cbmNvbnN0IFF1ZXJ5RXJyb3JSZXNldEJvdW5kYXJ5Q29udGV4dCA9IFJlYWN0LmNyZWF0ZUNvbnRleHQoY3JlYXRlVmFsdWUoKSk7XG4vKipcbiogVGhpcyBob29rIHdpbGwgcmVzZXQgYW55IHF1ZXJ5IGVycm9ycyB3aXRoaW4gdGhlIGNsb3Nlc3QgYFF1ZXJ5RXJyb3JSZXNldEJvdW5kYXJ5YC4gSWYgdGhlcmUgaXMgbm8gYm91bmRhcnlcbiogZGVmaW5lZCBpdCB3aWxsIHJlc2V0IHRoZW0gZ2xvYmFsbHkuXG4qIEByZXR1cm5zIFRoZSBib3VuZGFyeSdzIHtAbGluayBRdWVyeUVycm9yUmVzZXRCb3VuZGFyeVZhbHVlfS5cbiogQGV4YW1wbGVcbiogYGBgdHN4XG4qIGltcG9ydCB7IEVycm9yQm91bmRhcnkgfSBmcm9tICdyZWFjdC1lcnJvci1ib3VuZGFyeSdcbiogaW1wb3J0IHsgdXNlUXVlcnlFcnJvclJlc2V0Qm91bmRhcnkgfSBmcm9tICdAdGFuc3RhY2svcmVhY3QtcXVlcnknXG4qXG4qIGZ1bmN0aW9uIEFwcCh7IGNoaWxkcmVuIH06IHsgY2hpbGRyZW46IFJlYWN0LlJlYWN0Tm9kZSB9KSB7XG4qICAgY29uc3QgeyByZXNldCB9ID0gdXNlUXVlcnlFcnJvclJlc2V0Qm91bmRhcnkoKVxuKlxuKiAgIHJldHVybiAoXG4qICAgICA8RXJyb3JCb3VuZGFyeVxuKiAgICAgICBvblJlc2V0PXtyZXNldH1cbiogICAgICAgZmFsbGJhY2tSZW5kZXI9eyh7IHJlc2V0RXJyb3JCb3VuZGFyeSB9KSA9PiAoXG4qICAgICAgICAgPGRpdj5cbiogICAgICAgICAgIFRoZXJlIHdhcyBhbiBlcnJvciFcbiogICAgICAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gcmVzZXRFcnJvckJvdW5kYXJ5KCl9PlRyeSBhZ2FpbjwvYnV0dG9uPlxuKiAgICAgICAgIDwvZGl2PlxuKiAgICAgICApfVxuKiAgICAgPlxuKiAgICAgICB7Y2hpbGRyZW59XG4qICAgICA8L0Vycm9yQm91bmRhcnk+XG4qICAgKVxuKiB9XG4qIGBgYFxuKi9cbmNvbnN0IHVzZVF1ZXJ5RXJyb3JSZXNldEJvdW5kYXJ5ID0gKCkgPT4gUmVhY3QudXNlQ29udGV4dChRdWVyeUVycm9yUmVzZXRCb3VuZGFyeUNvbnRleHQpO1xuLyoqXG4qIFdoZW4gdXNpbmcgYHN1c3BlbnNlYCBvciBgdGhyb3dPbkVycm9yYCBpbiB5b3VyIHF1ZXJpZXMsIHlvdSBuZWVkIGEgd2F5IHRvIGxldCBxdWVyaWVzIGtub3cgdGhhdCB5b3Ugd2FudCB0b1xuKiB0cnkgYWdhaW4gd2hlbiByZS1yZW5kZXJpbmcgYWZ0ZXIgc29tZSBlcnJvciBvY2N1cnJlZC4gV2l0aCB0aGUgYFF1ZXJ5RXJyb3JSZXNldEJvdW5kYXJ5YCBjb21wb25lbnQgeW91IGNhblxuKiByZXNldCBhbnkgcXVlcnkgZXJyb3JzIHdpdGhpbiB0aGUgYm91bmRhcmllcyBvZiB0aGUgY29tcG9uZW50LlxuKiBAcGFyYW0gcHJvcHMgLSBUaGUgYGNoaWxkcmVuYCB0byByZW5kZXIuXG4qIEByZXR1cm5zIFRoZSBgY2hpbGRyZW5gLCByZW5kZXJlZCBhcy1pcywgb3IgY2FsbGVkIHdpdGggdGhlIGJvdW5kYXJ5J3Mge0BsaW5rIFF1ZXJ5RXJyb3JSZXNldEJvdW5kYXJ5VmFsdWV9XG4qIGlmIGBjaGlsZHJlbmAgaXMgYSBmdW5jdGlvbi5cbiogQGV4YW1wbGVcbiogYGBgdHN4XG4qIGltcG9ydCB7IEVycm9yQm91bmRhcnkgfSBmcm9tICdyZWFjdC1lcnJvci1ib3VuZGFyeSdcbiogaW1wb3J0IHsgUXVlcnlFcnJvclJlc2V0Qm91bmRhcnkgfSBmcm9tICdAdGFuc3RhY2svcmVhY3QtcXVlcnknXG4qXG4qIGZ1bmN0aW9uIEFwcCgpIHtcbiogICByZXR1cm4gKFxuKiAgICAgPFF1ZXJ5RXJyb3JSZXNldEJvdW5kYXJ5PlxuKiAgICAgICB7KHsgcmVzZXQgfSkgPT4gKFxuKiAgICAgICAgIDxFcnJvckJvdW5kYXJ5XG4qICAgICAgICAgICBvblJlc2V0PXtyZXNldH1cbiogICAgICAgICAgIGZhbGxiYWNrUmVuZGVyPXsoeyByZXNldEVycm9yQm91bmRhcnkgfSkgPT4gKFxuKiAgICAgICAgICAgICA8ZGl2PlxuKiAgICAgICAgICAgICAgIFRoZXJlIHdhcyBhbiBlcnJvciFcbiogICAgICAgICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9eygpID0+IHJlc2V0RXJyb3JCb3VuZGFyeSgpfT5UcnkgYWdhaW48L2J1dHRvbj5cbiogICAgICAgICAgICAgPC9kaXY+XG4qICAgICAgICAgICApfVxuKiAgICAgICAgID5cbiogICAgICAgICAgIDxQYWdlIC8+XG4qICAgICAgICAgPC9FcnJvckJvdW5kYXJ5PlxuKiAgICAgICApfVxuKiAgICAgPC9RdWVyeUVycm9yUmVzZXRCb3VuZGFyeT5cbiogICApXG4qIH1cbiogYGBgXG4qL1xuY29uc3QgUXVlcnlFcnJvclJlc2V0Qm91bmRhcnkgPSAoeyBjaGlsZHJlbiB9KSA9PiB7XG5cdGNvbnN0IFt2YWx1ZV0gPSBSZWFjdC51c2VTdGF0ZSgoKSA9PiBjcmVhdGVWYWx1ZSgpKTtcblx0cmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBqc3goUXVlcnlFcnJvclJlc2V0Qm91bmRhcnlDb250ZXh0LlByb3ZpZGVyLCB7XG5cdFx0dmFsdWUsXG5cdFx0Y2hpbGRyZW46IHR5cGVvZiBjaGlsZHJlbiA9PT0gXCJmdW5jdGlvblwiID8gY2hpbGRyZW4odmFsdWUpIDogY2hpbGRyZW5cblx0fSk7XG59O1xuZXhwb3J0IHsgUXVlcnlFcnJvclJlc2V0Qm91bmRhcnksIHVzZVF1ZXJ5RXJyb3JSZXNldEJvdW5kYXJ5IH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPVF1ZXJ5RXJyb3JSZXNldEJvdW5kYXJ5LmpzLm1hcCIsIlwidXNlIGNsaWVudFwiO1xuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBzaG91bGRUaHJvd0Vycm9yIH0gZnJvbSBcIkB0YW5zdGFjay9xdWVyeS1jb3JlXCI7XG4vLyBzcmMvZXJyb3JCb3VuZGFyeVV0aWxzLnRzXG4vKipcbiogVHVybnMgb2ZmIGByZXRyeU9uTW91bnRgIGZvciBhIHF1ZXJ5IHRoYXQgdGhyb3dzIGl0cyBlcnJvcnMgKHdpdGggYHN1c3BlbnNlYCBvciBgdGhyb3dPbkVycm9yYCksXG4qIHVubGVzcyB0aGUgZXJyb3IgYm91bmRhcnkgaGFzIGJlZW4gcmVzZXQsIHNvIGEgcmVtb3VudCBkb2Vzbid0IHJldHJ5IHRoZSBmYWlsZWQgcXVlcnkgYmVmb3JlIHRoZVxuKiB1c2VyIHJlc2V0cyB0aGUgYm91bmRhcnkuIE11dGF0ZXMgdGhlIG9wdGlvbnMuXG4qIEBwYXJhbSBvcHRpb25zIC0gVGhlIGRlZmF1bHRlZCBxdWVyeSBvcHRpb25zIHRvIGFkanVzdC5cbiogQHBhcmFtIGVycm9yUmVzZXRCb3VuZGFyeSAtIFRoZSB2YWx1ZSBvZiB0aGUgbmVhcmVzdCBgUXVlcnlFcnJvclJlc2V0Qm91bmRhcnlgLlxuKiBAcGFyYW0gcXVlcnkgLSBUaGUgcXVlcnksIHVzZWQgdG8gZXZhbHVhdGUgYSBgdGhyb3dPbkVycm9yYCBmdW5jdGlvbiBhZ2FpbnN0IGl0cyBlcnJvci5cbiovXG5jb25zdCBlbnN1cmVQcmV2ZW50RXJyb3JCb3VuZGFyeVJldHJ5ID0gKG9wdGlvbnMsIGVycm9yUmVzZXRCb3VuZGFyeSwgcXVlcnkpID0+IHtcblx0Y29uc3QgdGhyb3dPbkVycm9yID0gcXVlcnk/LnN0YXRlLnN0YXR1cyA9PT0gXCJlcnJvclwiICYmIHR5cGVvZiBvcHRpb25zLnRocm93T25FcnJvciA9PT0gXCJmdW5jdGlvblwiID8gc2hvdWxkVGhyb3dFcnJvcihvcHRpb25zLnRocm93T25FcnJvciwgW3F1ZXJ5LnN0YXRlLmVycm9yLCBxdWVyeV0pIDogb3B0aW9ucy50aHJvd09uRXJyb3I7XG5cdGlmIChvcHRpb25zLnN1c3BlbnNlIHx8IHRocm93T25FcnJvcikge1xuXHRcdGlmICghZXJyb3JSZXNldEJvdW5kYXJ5LmlzUmVzZXQoKSkgb3B0aW9ucy5yZXRyeU9uTW91bnQgPSBmYWxzZTtcblx0fVxufTtcbi8qKlxuKiBDbGVhcnMgdGhlIHJlc2V0IHN0YXRlIG9mIHRoZSBlcnJvciBib3VuZGFyeSBhZnRlciB0aGUgY29tcG9uZW50IG1vdW50cywgc28gbGF0ZXIgZXJyb3JzIGFyZVxuKiB0aHJvd24gdG8gdGhlIGJvdW5kYXJ5IGFnYWluLlxuKiBAcGFyYW0gZXJyb3JSZXNldEJvdW5kYXJ5IC0gVGhlIHZhbHVlIG9mIHRoZSBuZWFyZXN0IGBRdWVyeUVycm9yUmVzZXRCb3VuZGFyeWAuXG4qL1xuY29uc3QgdXNlQ2xlYXJSZXNldEVycm9yQm91bmRhcnkgPSAoZXJyb3JSZXNldEJvdW5kYXJ5KSA9PiB7XG5cdFJlYWN0LnVzZUVmZmVjdCgoKSA9PiB7XG5cdFx0ZXJyb3JSZXNldEJvdW5kYXJ5LmNsZWFyUmVzZXQoKTtcblx0fSwgW2Vycm9yUmVzZXRCb3VuZGFyeV0pO1xufTtcbi8qKlxuKiBDaGVja3Mgd2hldGhlciB0aGUgcXVlcnkgZXJyb3Igc2hvdWxkIGJlIHRocm93biB0byB0aGUgbmVhcmVzdCBlcnJvciBib3VuZGFyeTogdGhlIHF1ZXJ5IGVycm9yZWRcbiogYW5kIGlzbid0IGZldGNoaW5nLCB0aGUgYm91bmRhcnkgaGFzbid0IGJlZW4gcmVzZXQsIGFuZCBlaXRoZXIgYHN1c3BlbnNlYCBpcyBlbmFibGVkIHdpdGggbm8gZGF0YVxuKiBvciBgdGhyb3dPbkVycm9yYCBzYXlzIHNvLlxuKiBAcGFyYW0gcGFyYW1zIC0gVGhlIG9ic2VydmVyIGByZXN1bHRgLCB0aGUgYGVycm9yUmVzZXRCb3VuZGFyeWAsIHRoZSBgdGhyb3dPbkVycm9yYCBvcHRpb24sIHRoZVxuKiBgcXVlcnlgLCBhbmQgdGhlIGBzdXNwZW5zZWAgb3B0aW9uLlxuKiBAcmV0dXJucyBgdHJ1ZWAgaWYgdGhlIGVycm9yIHNob3VsZCBiZSB0aHJvd24uXG4qL1xuY29uc3QgZ2V0SGFzRXJyb3IgPSAoeyByZXN1bHQsIGVycm9yUmVzZXRCb3VuZGFyeSwgdGhyb3dPbkVycm9yLCBxdWVyeSwgc3VzcGVuc2UgfSkgPT4ge1xuXHRyZXR1cm4gcmVzdWx0LmlzRXJyb3IgJiYgIWVycm9yUmVzZXRCb3VuZGFyeS5pc1Jlc2V0KCkgJiYgIXJlc3VsdC5pc0ZldGNoaW5nICYmIHF1ZXJ5ICYmIChzdXNwZW5zZSAmJiByZXN1bHQuZGF0YSA9PT0gdm9pZCAwIHx8IHNob3VsZFRocm93RXJyb3IodGhyb3dPbkVycm9yLCBbcmVzdWx0LmVycm9yLCBxdWVyeV0pKTtcbn07XG5leHBvcnQgeyBlbnN1cmVQcmV2ZW50RXJyb3JCb3VuZGFyeVJldHJ5LCBnZXRIYXNFcnJvciwgdXNlQ2xlYXJSZXNldEVycm9yQm91bmRhcnkgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9ZXJyb3JCb3VuZGFyeVV0aWxzLmpzLm1hcCIsIi8vIHNyYy9zdXNwZW5zZS50c1xuLyoqXG4qIFRoZSBkZWZhdWx0IGB0aHJvd09uRXJyb3JgIG9mIHRoZSBzdXNwZW5zZSBob29rczogdGhyb3dzIHRoZSBlcnJvciB0byB0aGUgbmVhcmVzdCBlcnJvciBib3VuZGFyeVxuKiBvbmx5IGlmIHRoZSBxdWVyeSBoYXMgbm8gZGF0YSB0byBzaG93LlxuKiBAcGFyYW0gX2Vycm9yIC0gVGhlIGVycm9yIG9mIHRoZSBxdWVyeS4gVW51c2VkLlxuKiBAcGFyYW0gcXVlcnkgLSBUaGUgcXVlcnkgdGhhdCBlcnJvcmVkLlxuKiBAcmV0dXJucyBgdHJ1ZWAgaWYgdGhlIHF1ZXJ5IGhhcyBubyBkYXRhLlxuKi9cbmNvbnN0IGRlZmF1bHRUaHJvd09uRXJyb3IgPSAoX2Vycm9yLCBxdWVyeSkgPT4gcXVlcnkuc3RhdGUuZGF0YSA9PT0gdm9pZCAwO1xuLyoqXG4qIFJhaXNlcyBgc3RhbGVUaW1lYCBhbmQgYSBudW1lcmljIGBnY1RpbWVgIHRvIGF0IGxlYXN0IDEwMDBtcyB3aGVuIGBzdXNwZW5zZWAgaXMgZW5hYmxlZCwgc28gYVxuKiBjb21wb25lbnQgdGhhdCByZW1vdW50cyBhZnRlciBzdXNwZW5kaW5nIGRvZXNuJ3QgcmVmZXRjaCByaWdodCBhd2F5IG9yIGZpbmQgdGhlIHF1ZXJ5IGdhcmJhZ2VcbiogY29sbGVjdGVkLiBBIGAnc3RhdGljJ2AgYHN0YWxlVGltZWAgaXMga2VwdCBhcyBpcy4gTXV0YXRlcyB0aGUgb3B0aW9ucy5cbiogQHBhcmFtIGRlZmF1bHRlZE9wdGlvbnMgLSBUaGUgZGVmYXVsdGVkIHF1ZXJ5IG9wdGlvbnMgdG8gYWRqdXN0LlxuKi9cbmNvbnN0IGVuc3VyZVN1c3BlbnNlVGltZXJzID0gKGRlZmF1bHRlZE9wdGlvbnMpID0+IHtcblx0aWYgKGRlZmF1bHRlZE9wdGlvbnMuc3VzcGVuc2UpIHtcblx0XHRjb25zdCBNSU5fU1VTUEVOU0VfVElNRV9NUyA9IDFlMztcblx0XHRjb25zdCBjbGFtcCA9ICh2YWx1ZSkgPT4gdmFsdWUgPT09IFwic3RhdGljXCIgPyB2YWx1ZSA6IE1hdGgubWF4KHZhbHVlID8/IE1JTl9TVVNQRU5TRV9USU1FX01TLCBNSU5fU1VTUEVOU0VfVElNRV9NUyk7XG5cdFx0Y29uc3Qgb3JpZ2luYWxTdGFsZVRpbWUgPSBkZWZhdWx0ZWRPcHRpb25zLnN0YWxlVGltZTtcblx0XHRkZWZhdWx0ZWRPcHRpb25zLnN0YWxlVGltZSA9IHR5cGVvZiBvcmlnaW5hbFN0YWxlVGltZSA9PT0gXCJmdW5jdGlvblwiID8gKC4uLmFyZ3MpID0+IGNsYW1wKG9yaWdpbmFsU3RhbGVUaW1lKC4uLmFyZ3MpKSA6IGNsYW1wKG9yaWdpbmFsU3RhbGVUaW1lKTtcblx0XHRpZiAodHlwZW9mIGRlZmF1bHRlZE9wdGlvbnMuZ2NUaW1lID09PSBcIm51bWJlclwiKSBkZWZhdWx0ZWRPcHRpb25zLmdjVGltZSA9IE1hdGgubWF4KGRlZmF1bHRlZE9wdGlvbnMuZ2NUaW1lLCBNSU5fU1VTUEVOU0VfVElNRV9NUyk7XG5cdH1cbn07XG4vKipcbiogQ2hlY2tzIHdoZXRoZXIgYSBxdWVyeSBzaG91bGQgc3VzcGVuZDogYHN1c3BlbnNlYCBpcyBlbmFibGVkIGFuZCB0aGUgcmVzdWx0IGlzIHN0aWxsIGBwZW5kaW5nYC5cbiogQHBhcmFtIGRlZmF1bHRlZE9wdGlvbnMgLSBUaGUgZGVmYXVsdGVkIHF1ZXJ5IG9wdGlvbnMsIGlmIGFueS5cbiogQHBhcmFtIHJlc3VsdCAtIFRoZSBjdXJyZW50IHJlc3VsdCBvZiB0aGUgb2JzZXJ2ZXIuXG4qIEByZXR1cm5zIGB0cnVlYCBpZiB0aGUgY29tcG9uZW50IHNob3VsZCBzdXNwZW5kLlxuKi9cbmNvbnN0IHNob3VsZFN1c3BlbmQgPSAoZGVmYXVsdGVkT3B0aW9ucywgcmVzdWx0KSA9PiBkZWZhdWx0ZWRPcHRpb25zPy5zdXNwZW5zZSAmJiByZXN1bHQuaXNQZW5kaW5nO1xuLyoqXG4qIEZldGNoZXMgdGhlIHF1ZXJ5IGZvciBhIHN1c3BlbmRpbmcgY29tcG9uZW50LCB3aXRob3V0IGFmZmVjdGluZyB0aGUgb2JzZXJ2ZXIncyBvd24gcmVzdWx0LiBJZlxuKiB0aGUgZmV0Y2ggZmFpbHMsIHRoZSByZXNldCBzdGF0ZSBvZiB0aGUgZXJyb3IgYm91bmRhcnkgaXMgY2xlYXJlZCwgc28gdGhlIGVycm9yIGlzIHRocm93biB0byBpdC5cbiogQHBhcmFtIGRlZmF1bHRlZE9wdGlvbnMgLSBUaGUgZGVmYXVsdGVkIHF1ZXJ5IG9wdGlvbnMgdG8gZmV0Y2ggd2l0aC5cbiogQHBhcmFtIG9ic2VydmVyIC0gVGhlIG9ic2VydmVyIG9mIHRoZSBxdWVyeS5cbiogQHBhcmFtIGVycm9yUmVzZXRCb3VuZGFyeSAtIFRoZSB2YWx1ZSBvZiB0aGUgbmVhcmVzdCBgUXVlcnlFcnJvclJlc2V0Qm91bmRhcnlgLlxuKiBAcmV0dXJucyBBIHByb21pc2UgdGhhdCByZXNvbHZlcyBvbmNlIHRoZSBmZXRjaCBzZXR0bGVzLiBJdCBuZXZlciByZWplY3RzLlxuKi9cbmNvbnN0IGZldGNoT3B0aW1pc3RpYyA9IChkZWZhdWx0ZWRPcHRpb25zLCBvYnNlcnZlciwgZXJyb3JSZXNldEJvdW5kYXJ5KSA9PiBvYnNlcnZlci5mZXRjaE9wdGltaXN0aWMoZGVmYXVsdGVkT3B0aW9ucykuY2F0Y2goKCkgPT4ge1xuXHRlcnJvclJlc2V0Qm91bmRhcnkuY2xlYXJSZXNldCgpO1xufSk7XG5leHBvcnQgeyBkZWZhdWx0VGhyb3dPbkVycm9yLCBlbnN1cmVTdXNwZW5zZVRpbWVycywgZmV0Y2hPcHRpbWlzdGljLCBzaG91bGRTdXNwZW5kIH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXN1c3BlbnNlLmpzLm1hcCIsIlwidXNlIGNsaWVudFwiO1xuaW1wb3J0IHsgdXNlUXVlcnlDbGllbnQgfSBmcm9tIFwiLi9RdWVyeUNsaWVudFByb3ZpZGVyLmpzXCI7XG5pbXBvcnQgeyB1c2VJc1Jlc3RvcmluZyB9IGZyb20gXCIuL0lzUmVzdG9yaW5nUHJvdmlkZXIuanNcIjtcbmltcG9ydCB7IHVzZVF1ZXJ5RXJyb3JSZXNldEJvdW5kYXJ5IH0gZnJvbSBcIi4vUXVlcnlFcnJvclJlc2V0Qm91bmRhcnkuanNcIjtcbmltcG9ydCB7IGVuc3VyZVByZXZlbnRFcnJvckJvdW5kYXJ5UmV0cnksIGdldEhhc0Vycm9yLCB1c2VDbGVhclJlc2V0RXJyb3JCb3VuZGFyeSB9IGZyb20gXCIuL2Vycm9yQm91bmRhcnlVdGlscy5qc1wiO1xuaW1wb3J0IHsgZW5zdXJlU3VzcGVuc2VUaW1lcnMsIGZldGNoT3B0aW1pc3RpYywgc2hvdWxkU3VzcGVuZCB9IGZyb20gXCIuL3N1c3BlbnNlLmpzXCI7XG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IFF1ZXJpZXNPYnNlcnZlciwgUXVlcnlPYnNlcnZlciwgbm9vcCwgbm90aWZ5TWFuYWdlciB9IGZyb20gXCJAdGFuc3RhY2svcXVlcnktY29yZVwiO1xuLy8gc3JjL3VzZVF1ZXJpZXMudHNcbi8qKlxuKiBUaGUgYHVzZVF1ZXJpZXNgIGhvb2sgY2FuIGJlIHVzZWQgdG8gZmV0Y2ggYSB2YXJpYWJsZSBudW1iZXIgb2YgcXVlcmllcy5cbipcbiogVGhlIGBxdWVyaWVzYCBrZXkgYWNjZXB0cyBhbiBhcnJheSB3aXRoIHF1ZXJ5IG9wdGlvbiBvYmplY3RzIG1vc3RseSBpZGVudGljYWwgdG8gYHVzZVF1ZXJ5YCDigJQgdGhlIHRvcC1sZXZlbFxuKiBgc3Vic2NyaWJlZGAgb3B0aW9uIGlzbid0IGFjY2VwdGVkIHBlciBxdWVyeSAoc2VlIGBwbGFjZWhvbGRlckRhdGFgIGJlbG93IGZvciBhbm90aGVyIGRpZmZlcmVuY2UpLiBBIGN1c3RvbVxuKiBgUXVlcnlDbGllbnRgIGlzIHN1cHBsaWVkIG9uY2UsIGFzIGB1c2VRdWVyaWVzYCcgb3duIHRvcC1sZXZlbCBzZWNvbmQgYXJndW1lbnQsIHJhdGhlciB0aGFuIHBlciBxdWVyeS5cbipcbiogSGF2aW5nIHRoZSBzYW1lIHF1ZXJ5IGtleSBtb3JlIHRoYW4gb25jZSBpbiB0aGUgYXJyYXkgb2YgcXVlcnkgb2JqZWN0cyBtYXkgY2F1c2Ugc29tZSBkYXRhIHRvIGJlIHNoYXJlZFxuKiBiZXR3ZWVuIHF1ZXJpZXMuIFRvIGF2b2lkIHRoaXMsIGNvbnNpZGVyIGRlLWR1cGxpY2F0aW5nIHRoZSBxdWVyaWVzIGFuZCBtYXAgdGhlIHJlc3VsdHMgYmFjayB0byB0aGUgZGVzaXJlZFxuKiBzdHJ1Y3R1cmUuXG4qXG4qIFRoZSBgY29tYmluZWAgb3B0aW9uIGNhbiBiZSB1c2VkIHRvIGNvbWJpbmUgdGhlIHJlc3VsdHMgb2YgdGhlIHF1ZXJpZXMgaW50byBhIHNpbmdsZSB2YWx1ZS4gVGhlIHJlc3VsdCB3aWxsXG4qIGJlIHN0cnVjdHVyYWxseSBzaGFyZWQgdG8gYmUgYXMgcmVmZXJlbnRpYWxseSBzdGFibGUgYXMgcG9zc2libGUuXG4qIEBwYXJhbSBvcHRpb25zIC0gVGhlIGBxdWVyaWVzYCBhcnJheSB0byBydW4sIGFuZCB0aGUgb3B0aW9uYWwgYGNvbWJpbmVgIGFuZCBgc3Vic2NyaWJlZGAgb3B0aW9ucy5cbiogQHBhcmFtIHF1ZXJ5Q2xpZW50IC0gVXNlIHRoaXMgdG8gcHJvdmlkZSBhIGN1c3RvbSBgUXVlcnlDbGllbnRgLiBPdGhlcndpc2UsIHRoZSBvbmUgZnJvbSB0aGUgbmVhcmVzdCBjb250ZXh0XG4qIHdpbGwgYmUgdXNlZC5cbiogQHJldHVybnMgVGhlIGNvbWJpbmVkIHJlc3VsdC4gV2l0aG91dCBgY29tYmluZWAsIHRoaXMgaXMgYW4gYXJyYXkgd2l0aCBhbGwgdGhlIHF1ZXJ5IHJlc3VsdHMsIGluIHRoZSBzYW1lXG4qIG9yZGVyIGFzIHRoZSBpbnB1dC4gV2hlbiBgY29tYmluZWAgaXMgcHJvdmlkZWQsIHRoaXMgaXMgdGhlIHZhbHVlIHJldHVybmVkIGJ5IGBjb21iaW5lYCBpbnN0ZWFkLlxuKiBAdGhyb3dzIHtFcnJvcn0gVGhlIGVycm9yIG9mIHRoZSBmaXJzdCBxdWVyeSB0aGF0IHNob3VsZCBiZSB0aHJvd24gdG8gdGhlIG5lYXJlc3QgZXJyb3IgYm91bmRhcnkgKHNlZVxuKiBgdGhyb3dPbkVycm9yYCkuIFdoaWxlIHN1c3BlbmRpbmcsIGl0IHRocm93cyBhIHByb21pc2UgaW5zdGVhZC5cbiogQHJlbWFya3MgVGhlIGBjb21iaW5lYCBmdW5jdGlvbiBvbmx5IHJlLXJ1bnMgaWYgaXQgY2hhbmdlZCByZWZlcmVudGlhbGx5LCBvciBpZiBhbnkgb2YgdGhlIHF1ZXJ5IHJlc3VsdHNcbiogY2hhbmdlZC4gQW4gaW5saW5lZCBgY29tYmluZWAgZnVuY3Rpb24sIGFzIHNob3duIGluIHRoZSBleGFtcGxlIGJlbG93LCB0aGVyZWZvcmUgcnVucyBvbiBldmVyeSByZW5kZXIg4oCUIHdyYXBcbiogaXQgaW4gYHVzZUNhbGxiYWNrYCwgb3IgZXh0cmFjdCBpdCB0byBhIHN0YWJsZSBmdW5jdGlvbiByZWZlcmVuY2UgaWYgaXQgZG9lc24ndCBoYXZlIGFueSBkZXBlbmRlbmNpZXMsIHRvXG4qIGF2b2lkIHRoYXQuXG4qXG4qIFVubGlrZSBgdXNlUXVlcnlgLCBgdXNlUXVlcmllc2AgY2Fubm90IGluZmVyIHRoZSBgZGF0YWAgYXJndW1lbnQgb2YgYW4gX2lubGluZV8gYHNlbGVjdGAgZnJvbSBpdHMgc2libGluZ1xuKiBgcXVlcnlGbmAuIEJlY2F1c2UgYHVzZVF1ZXJpZXNgIGluZmVycyB0aGUgdHlwZSBvZiB0aGUgd2hvbGUgYHF1ZXJpZXNgIGFycmF5IGF0IG9uY2UsIHRoZSBgc2VsZWN0YCBwYXJhbWV0ZXJcbiogb2YgYSBxdWVyeSBvYmplY3Qgd3JpdHRlbiBpbmxpbmUgY2Fubm90IGJlIGNvbnRleHR1YWxseSB0eXBlZCBmcm9tIHRoYXQgc2FtZSBvYmplY3QncyBgcXVlcnlGbmAsIHNvIGl0IGZhbGxzXG4qIGJhY2sgdG8gYHVua25vd25gIOKAlCBhIFtrbm93biBUeXBlU2NyaXB0IGxpbWl0YXRpb25dKGh0dHBzOi8vZ2l0aHViLmNvbS9UYW5TdGFjay9xdWVyeS9pc3N1ZXMvNjU1NikuIEFubm90YXRlXG4qIHRoZSBgc2VsZWN0YCBwYXJhbWV0ZXIgZXhwbGljaXRseSwgb3IgZGVmaW5lIHRoZSBxdWVyeSB3aXRoIHtAbGluayBxdWVyeU9wdGlvbnN9LCB3aGljaCByZXNvbHZlcyBpdHMgdHlwZXMgaW5cbiogYSBzaW5nbGUgb2JqZWN0IF9iZWZvcmVfIGl0IHJlYWNoZXMgYHVzZVF1ZXJpZXNgLCB0byB3b3JrIGFyb3VuZCB0aGlzIOKAlCBzZWUgdGhlIGV4YW1wbGUgYmVsb3cuIFRoZSBzYW1lXG4qIGxpbWl0YXRpb24gYXBwbGllcyB0byB7QGxpbmsgdXNlU3VzcGVuc2VRdWVyaWVzfS5cbipcbiogYHBsYWNlaG9sZGVyRGF0YWAgaXMgc3VwcG9ydGVkIGhlcmUgdG9vLCBidXQgdW5saWtlIGB1c2VRdWVyeWAsIGl0IGRvZXNuJ3QgcmVjZWl2ZSBpbmZvcm1hdGlvbiBmcm9tXG4qIHByZXZpb3VzbHkgcmVuZGVyZWQgcXVlcmllcywgYmVjYXVzZSB0aGUgbnVtYmVyIG9mIHF1ZXJpZXMgY2FuIGRpZmZlciBiZXR3ZWVuIHJlbmRlcnMuXG4qIEBleGFtcGxlXG4qIGBgYHRzeFxuKiBpbXBvcnQgeyB1c2VRdWVyaWVzIH0gZnJvbSAnQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5J1xuKlxuKiBmdW5jdGlvbiBQb3N0cyh7IGlkcyB9OiB7IGlkczogQXJyYXk8bnVtYmVyPiB9KSB7XG4qICAgY29uc3QgcG9zdFF1ZXJpZXMgPSB1c2VRdWVyaWVzKHtcbiogICAgIHF1ZXJpZXM6IGlkcy5tYXAoKGlkKSA9PiAoe1xuKiAgICAgICBxdWVyeUtleTogWydwb3N0JywgaWRdLFxuKiAgICAgICBxdWVyeUZuOiAoKSA9PiBmZXRjaFBvc3QoaWQpLFxuKiAgICAgICBzdGFsZVRpbWU6IEluZmluaXR5LFxuKiAgICAgfSkpLFxuKiAgIH0pXG4qXG4qICAgcmV0dXJuIChcbiogICAgIDx1bD5cbiogICAgICAge3Bvc3RRdWVyaWVzLm1hcCgocXVlcnksIGluZGV4KSA9PiB7XG4qICAgICAgICAgaWYgKHF1ZXJ5LmlzUGVuZGluZykgcmV0dXJuIDxsaSBrZXk9e2lkc1tpbmRleF19PkxvYWRpbmcuLi48L2xpPlxuKiAgICAgICAgIGlmIChxdWVyeS5pc0Vycm9yKSByZXR1cm4gPGxpIGtleT17aWRzW2luZGV4XX0+RXJyb3I6IHtxdWVyeS5lcnJvci5tZXNzYWdlfTwvbGk+XG4qICAgICAgICAgcmV0dXJuIDxsaSBrZXk9e2lkc1tpbmRleF19PntxdWVyeS5kYXRhLnRpdGxlfTwvbGk+XG4qICAgICAgIH0pfVxuKiAgICAgPC91bD5cbiogICApXG4qIH1cbiogYGBgXG4qIEBleGFtcGxlXG4qIENvbWJpbmluZyByZXN1bHRzIGludG8gYSBzaW5nbGUgdmFsdWU6XG4qIGBgYHRzeFxuKiBpbXBvcnQgeyB1c2VRdWVyaWVzIH0gZnJvbSAnQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5J1xuKlxuKiBmdW5jdGlvbiBQb3N0cyh7IGlkcyB9OiB7IGlkczogQXJyYXk8bnVtYmVyPiB9KSB7XG4qICAgY29uc3QgeyBkYXRhLCBpc1BlbmRpbmcsIGlzRXJyb3IgfSA9IHVzZVF1ZXJpZXMoe1xuKiAgICAgcXVlcmllczogaWRzLm1hcCgoaWQpID0+ICh7XG4qICAgICAgIHF1ZXJ5S2V5OiBbJ3Bvc3QnLCBpZF0sXG4qICAgICAgIHF1ZXJ5Rm46ICgpID0+IGZldGNoUG9zdChpZCksXG4qICAgICB9KSksXG4qICAgICBjb21iaW5lOiAocG9zdFF1ZXJpZXMpID0+IHtcbiogICAgICAgcmV0dXJuIHtcbiogICAgICAgICBkYXRhOiBwb3N0UXVlcmllcy5tYXAoKHF1ZXJ5KSA9PiBxdWVyeS5kYXRhKSxcbiogICAgICAgICBpc1BlbmRpbmc6IHBvc3RRdWVyaWVzLnNvbWUoKHF1ZXJ5KSA9PiBxdWVyeS5pc1BlbmRpbmcpLFxuKiAgICAgICAgIGlzRXJyb3I6IHBvc3RRdWVyaWVzLnNvbWUoKHF1ZXJ5KSA9PiBxdWVyeS5pc0Vycm9yKSxcbiogICAgICAgfVxuKiAgICAgfSxcbiogICB9KVxuKlxuKiAgIGlmIChpc1BlbmRpbmcpIHJldHVybiAnTG9hZGluZy4uLidcbiogICBpZiAoaXNFcnJvcikgcmV0dXJuICdFcnJvciBsb2FkaW5nIHBvc3RzJ1xuKlxuKiAgIHJldHVybiAoXG4qICAgICA8dWw+XG4qICAgICAgIHtkYXRhLm1hcCgocG9zdCkgPT4gKFxuKiAgICAgICAgIDxsaSBrZXk9e3Bvc3Q/LmlkfT57cG9zdD8udGl0bGV9PC9saT5cbiogICAgICAgKSl9XG4qICAgICA8L3VsPlxuKiAgIClcbiogfVxuKiBgYGBcbiogQGV4YW1wbGVcbiogVHlwaW5nIGBzZWxlY3RgIHZpYSB7QGxpbmsgcXVlcnlPcHRpb25zfS4gTm90ZSB0aGF0IHNwcmVhZGluZyBhIGBxdWVyeU9wdGlvbnNgIHJlc3VsdCBhbmQgb3ZlcnJpZGluZ1xuKiBgc2VsZWN0YCBpbmxpbmUgc3RpbGwgZmFsbHMgYmFjayB0byBgdW5rbm93bmAg4oCUIHdyYXAgdGhlIHNwcmVhZCBpbiBgcXVlcnlPcHRpb25zYCBhZ2FpbiBzbyB0aGUgb3ZlcnJpZGUgaXNcbiogcmVzb2x2ZWQgYmVmb3JlIGl0IHJlYWNoZXMgYHVzZVF1ZXJpZXNgOlxuKiBgYGB0c3hcbiogaW1wb3J0IHsgcXVlcnlPcHRpb25zLCB1c2VRdWVyaWVzIH0gZnJvbSAnQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5J1xuKlxuKiBjb25zdCBwb3N0T3B0aW9ucyA9IChpZDogbnVtYmVyKSA9PlxuKiAgIHF1ZXJ5T3B0aW9ucyh7XG4qICAgICBxdWVyeUtleTogWydwb3N0JywgaWRdLFxuKiAgICAgcXVlcnlGbjogKCkgPT4gZmV0Y2hQb3N0KGlkKSxcbiogICB9KVxuKlxuKiBmdW5jdGlvbiBQb3N0VGl0bGUoeyBpZCB9OiB7IGlkOiBudW1iZXIgfSkge1xuKiAgIGNvbnN0IFt7IGRhdGE6IGJyb2tlbiB9XSA9IHVzZVF1ZXJpZXMoe1xuKiAgICAgcXVlcmllczogW1xuKiAgICAgICB7XG4qICAgICAgICAgLi4ucG9zdE9wdGlvbnMoaWQpLFxuKiAgICAgICAgIC8vIOKdjCBgZGF0YWAgaXMgYHVua25vd25gIGhlcmVcbiogICAgICAgICBzZWxlY3Q6IChkYXRhKSA9PiBkYXRhLnRpdGxlLFxuKiAgICAgICB9LFxuKiAgICAgXSxcbiogICB9KVxuKlxuKiAgIGNvbnN0IFt7IGRhdGE6IGZpeGVkIH1dID0gdXNlUXVlcmllcyh7XG4qICAgICBxdWVyaWVzOiBbXG4qICAgICAgIHF1ZXJ5T3B0aW9ucyh7XG4qICAgICAgICAgLi4ucG9zdE9wdGlvbnMoaWQpLFxuKiAgICAgICAgIC8vIOKchSBgZGF0YWAgaXMgYFBvc3RgXG4qICAgICAgICAgc2VsZWN0OiAoZGF0YSkgPT4gZGF0YS50aXRsZSxcbiogICAgICAgfSksXG4qICAgICBdLFxuKiAgIH0pXG4qXG4qICAgcmV0dXJuIDxoMT57Zml4ZWR9PC9oMT5cbiogfVxuKiBgYGBcbiovXG5mdW5jdGlvbiB1c2VRdWVyaWVzKHsgcXVlcmllcywgLi4ub3B0aW9ucyB9LCBxdWVyeUNsaWVudCkge1xuXHRjb25zdCBjbGllbnQgPSB1c2VRdWVyeUNsaWVudChxdWVyeUNsaWVudCk7XG5cdGNvbnN0IGlzUmVzdG9yaW5nID0gdXNlSXNSZXN0b3JpbmcoKTtcblx0Y29uc3QgZXJyb3JSZXNldEJvdW5kYXJ5ID0gdXNlUXVlcnlFcnJvclJlc2V0Qm91bmRhcnkoKTtcblx0Y29uc3Qgc3Vic2NyaWJlZCA9IG9wdGlvbnMuc3Vic2NyaWJlZCAhPT0gZmFsc2U7XG5cdGNvbnN0IGRlZmF1bHRlZFF1ZXJpZXMgPSBSZWFjdC51c2VNZW1vKCgpID0+IHF1ZXJpZXMubWFwKChvcHRzKSA9PiB7XG5cdFx0Y29uc3QgZGVmYXVsdGVkT3B0aW9ucyA9IGNsaWVudC5kZWZhdWx0UXVlcnlPcHRpb25zKG9wdHMpO1xuXHRcdGRlZmF1bHRlZE9wdGlvbnMuX29wdGltaXN0aWNSZXN1bHRzID0gaXNSZXN0b3JpbmcgPyBcImlzUmVzdG9yaW5nXCIgOiBzdWJzY3JpYmVkID8gXCJvcHRpbWlzdGljXCIgOiB2b2lkIDA7XG5cdFx0cmV0dXJuIGRlZmF1bHRlZE9wdGlvbnM7XG5cdH0pLCBbXG5cdFx0cXVlcmllcyxcblx0XHRjbGllbnQsXG5cdFx0aXNSZXN0b3JpbmcsXG5cdFx0c3Vic2NyaWJlZFxuXHRdKTtcblx0ZGVmYXVsdGVkUXVlcmllcy5mb3JFYWNoKChxdWVyeU9wdGlvbnMpID0+IHtcblx0XHRlbnN1cmVTdXNwZW5zZVRpbWVycyhxdWVyeU9wdGlvbnMpO1xuXHRcdGNvbnN0IHF1ZXJ5ID0gY2xpZW50LmdldFF1ZXJ5Q2FjaGUoKS5nZXQocXVlcnlPcHRpb25zLnF1ZXJ5SGFzaCk7XG5cdFx0ZW5zdXJlUHJldmVudEVycm9yQm91bmRhcnlSZXRyeShxdWVyeU9wdGlvbnMsIGVycm9yUmVzZXRCb3VuZGFyeSwgcXVlcnkpO1xuXHR9KTtcblx0dXNlQ2xlYXJSZXNldEVycm9yQm91bmRhcnkoZXJyb3JSZXNldEJvdW5kYXJ5KTtcblx0Y29uc3QgW29ic2VydmVyXSA9IFJlYWN0LnVzZVN0YXRlKCgpID0+IG5ldyBRdWVyaWVzT2JzZXJ2ZXIoY2xpZW50LCBkZWZhdWx0ZWRRdWVyaWVzLCBvcHRpb25zKSk7XG5cdGNvbnN0IFtvcHRpbWlzdGljUmVzdWx0LCBnZXRDb21iaW5lZFJlc3VsdCwgdHJhY2tSZXN1bHRdID0gb2JzZXJ2ZXIuZ2V0T3B0aW1pc3RpY1Jlc3VsdChkZWZhdWx0ZWRRdWVyaWVzLCBvcHRpb25zLmNvbWJpbmUpO1xuXHRSZWFjdC51c2VFZmZlY3QoKCkgPT4ge1xuXHRcdG9ic2VydmVyLnNldFF1ZXJpZXMoZGVmYXVsdGVkUXVlcmllcywgb3B0aW9ucyk7XG5cdH0sIFtcblx0XHRkZWZhdWx0ZWRRdWVyaWVzLFxuXHRcdG9wdGlvbnMsXG5cdFx0b2JzZXJ2ZXJcblx0XSk7XG5cdGNvbnN0IHNob3VsZFN1YnNjcmliZSA9ICFpc1Jlc3RvcmluZyAmJiBzdWJzY3JpYmVkO1xuXHRSZWFjdC51c2VTeW5jRXh0ZXJuYWxTdG9yZShSZWFjdC51c2VDYWxsYmFjaygob25TdG9yZUNoYW5nZSkgPT4gc2hvdWxkU3Vic2NyaWJlID8gb2JzZXJ2ZXIuc3Vic2NyaWJlKG5vdGlmeU1hbmFnZXIuYmF0Y2hDYWxscyhvblN0b3JlQ2hhbmdlKSkgOiBub29wLCBbb2JzZXJ2ZXIsIHNob3VsZFN1YnNjcmliZV0pLCAoKSA9PiBvYnNlcnZlci5nZXRDdXJyZW50UmVzdWx0KCksICgpID0+IG9ic2VydmVyLmdldEN1cnJlbnRSZXN1bHQoKSk7XG5cdGNvbnN0IHN1c3BlbnNlUHJvbWlzZXMgPSBvcHRpbWlzdGljUmVzdWx0LnNvbWUoKHJlc3VsdCwgaW5kZXgpID0+IHNob3VsZFN1c3BlbmQoZGVmYXVsdGVkUXVlcmllc1tpbmRleF0sIHJlc3VsdCkpID8gb3B0aW1pc3RpY1Jlc3VsdC5mbGF0TWFwKChyZXN1bHQsIGluZGV4KSA9PiB7XG5cdFx0Y29uc3Qgb3B0cyA9IGRlZmF1bHRlZFF1ZXJpZXNbaW5kZXhdO1xuXHRcdGlmIChvcHRzICYmIHNob3VsZFN1c3BlbmQob3B0cywgcmVzdWx0KSkge1xuXHRcdFx0Y29uc3QgcXVlcnlPYnNlcnZlciA9IG5ldyBRdWVyeU9ic2VydmVyKGNsaWVudCwgb3B0cyk7XG5cdFx0XHRyZXR1cm4gZmV0Y2hPcHRpbWlzdGljKG9wdHMsIHF1ZXJ5T2JzZXJ2ZXIsIGVycm9yUmVzZXRCb3VuZGFyeSk7XG5cdFx0fVxuXHRcdHJldHVybiBbXTtcblx0fSkgOiBbXTtcblx0aWYgKHN1c3BlbnNlUHJvbWlzZXMubGVuZ3RoID4gMCkgdGhyb3cgUHJvbWlzZS5hbGwoc3VzcGVuc2VQcm9taXNlcyk7XG5cdGNvbnN0IGZpcnN0U2luZ2xlUmVzdWx0V2hpY2hTaG91bGRUaHJvdyA9IG9wdGltaXN0aWNSZXN1bHQuZmluZCgocmVzdWx0LCBpbmRleCkgPT4ge1xuXHRcdGNvbnN0IHF1ZXJ5ID0gZGVmYXVsdGVkUXVlcmllc1tpbmRleF07XG5cdFx0cmV0dXJuIHF1ZXJ5ICYmIGdldEhhc0Vycm9yKHtcblx0XHRcdHJlc3VsdCxcblx0XHRcdGVycm9yUmVzZXRCb3VuZGFyeSxcblx0XHRcdHRocm93T25FcnJvcjogcXVlcnkudGhyb3dPbkVycm9yLFxuXHRcdFx0cXVlcnk6IGNsaWVudC5nZXRRdWVyeUNhY2hlKCkuZ2V0KHF1ZXJ5LnF1ZXJ5SGFzaCksXG5cdFx0XHRzdXNwZW5zZTogcXVlcnkuc3VzcGVuc2Vcblx0XHR9KTtcblx0fSk7XG5cdGlmIChmaXJzdFNpbmdsZVJlc3VsdFdoaWNoU2hvdWxkVGhyb3cpIHRocm93IGZpcnN0U2luZ2xlUmVzdWx0V2hpY2hTaG91bGRUaHJvdy5lcnJvcjtcblx0cmV0dXJuIGdldENvbWJpbmVkUmVzdWx0KHRyYWNrUmVzdWx0KCkpO1xufVxuZXhwb3J0IHsgdXNlUXVlcmllcyB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD11c2VRdWVyaWVzLmpzLm1hcCIsIlwidXNlIGNsaWVudFwiO1xuaW1wb3J0IHsgdXNlUXVlcnlDbGllbnQgfSBmcm9tIFwiLi9RdWVyeUNsaWVudFByb3ZpZGVyLmpzXCI7XG5pbXBvcnQgeyB1c2VJc1Jlc3RvcmluZyB9IGZyb20gXCIuL0lzUmVzdG9yaW5nUHJvdmlkZXIuanNcIjtcbmltcG9ydCB7IHVzZVF1ZXJ5RXJyb3JSZXNldEJvdW5kYXJ5IH0gZnJvbSBcIi4vUXVlcnlFcnJvclJlc2V0Qm91bmRhcnkuanNcIjtcbmltcG9ydCB7IGVuc3VyZVByZXZlbnRFcnJvckJvdW5kYXJ5UmV0cnksIGdldEhhc0Vycm9yLCB1c2VDbGVhclJlc2V0RXJyb3JCb3VuZGFyeSB9IGZyb20gXCIuL2Vycm9yQm91bmRhcnlVdGlscy5qc1wiO1xuaW1wb3J0IHsgZW5zdXJlU3VzcGVuc2VUaW1lcnMsIGZldGNoT3B0aW1pc3RpYywgc2hvdWxkU3VzcGVuZCB9IGZyb20gXCIuL3N1c3BlbnNlLmpzXCI7XG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IG5vb3AsIG5vdGlmeU1hbmFnZXIgfSBmcm9tIFwiQHRhbnN0YWNrL3F1ZXJ5LWNvcmVcIjtcbi8vIHNyYy91c2VCYXNlUXVlcnkudHNcbi8qKlxuKiBCYXNlIGltcGxlbWVudGF0aW9uIHNoYXJlZCBieSBgdXNlUXVlcnlgLCBgdXNlSW5maW5pdGVRdWVyeWAsIGB1c2VTdXNwZW5zZVF1ZXJ5YCwgYW5kXG4qIGB1c2VTdXNwZW5zZUluZmluaXRlUXVlcnlgLlxuKiBAcGFyYW0gb3B0aW9ucyAtIFRoZSBvcHRpb25zIHBhc3NlZCB0byB0aGUgY2FsbGluZyBob29rLlxuKiBAcGFyYW0gT2JzZXJ2ZXIgLSBUaGUgb2JzZXJ2ZXIgY2xhc3MgZnJvbSBxdWVyeS1jb3JlIChgUXVlcnlPYnNlcnZlcmAgb3JcbiogYEluZmluaXRlUXVlcnlPYnNlcnZlcmApLlxuKiBAcGFyYW0gcXVlcnlDbGllbnQgLSBVc2UgdGhpcyB0byB1c2UgYSBjdXN0b20gYFF1ZXJ5Q2xpZW50YC4gT3RoZXJ3aXNlLCB0aGUgb25lIGZyb20gdGhlIG5lYXJlc3RcbiogY29udGV4dCB3aWxsIGJlIHVzZWQuXG4qIEByZXR1cm5zIFRoZSBxdWVyeSByZXN1bHQsIHRyYWNraW5nIHdoaWNoIHByb3BlcnRpZXMgYXJlIHJlYWQgdW5sZXNzIGBub3RpZnlPbkNoYW5nZVByb3BzYCBpc1xuKiBzZXQuXG4qIEB0aHJvd3Mge0Vycm9yfSBJZiBgb3B0aW9uc2AgaXMgbm90IGFuIG9iamVjdCAob3V0c2lkZSBwcm9kdWN0aW9uKSwgb3IgdGhlIHF1ZXJ5IGVycm9yIHdoZW4gaXQgc2hvdWxkIGJlXG4qIHRocm93biB0byB0aGUgbmVhcmVzdCBlcnJvciBib3VuZGFyeSAoc2VlIGB0aHJvd09uRXJyb3JgKS4gV2hpbGUgc3VzcGVuZGluZywgaXQgdGhyb3dzIGEgcHJvbWlzZSBpbnN0ZWFkLlxuKi9cbmZ1bmN0aW9uIHVzZUJhc2VRdWVyeShvcHRpb25zLCBPYnNlcnZlciwgcXVlcnlDbGllbnQpIHtcblx0aWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikge1xuXHRcdGlmICh0eXBlb2Ygb3B0aW9ucyAhPT0gXCJvYmplY3RcIiB8fCBBcnJheS5pc0FycmF5KG9wdGlvbnMpKSB0aHJvdyBuZXcgRXJyb3IoXCJCYWQgYXJndW1lbnQgdHlwZS4gU3RhcnRpbmcgd2l0aCB2NSwgb25seSB0aGUgXFxcIk9iamVjdFxcXCIgZm9ybSBpcyBhbGxvd2VkIHdoZW4gY2FsbGluZyBxdWVyeSByZWxhdGVkIGZ1bmN0aW9ucy4gUGxlYXNlIHVzZSB0aGUgZXJyb3Igc3RhY2sgdG8gZmluZCB0aGUgY3VscHJpdCBjYWxsLiBNb3JlIGluZm8gaGVyZTogaHR0cHM6Ly90YW5zdGFjay5jb20vcXVlcnkvbGF0ZXN0L2RvY3MvcmVhY3QvZ3VpZGVzL21pZ3JhdGluZy10by12NSNzdXBwb3J0cy1hLXNpbmdsZS1zaWduYXR1cmUtb25lLW9iamVjdFwiKTtcblx0fVxuXHRjb25zdCBpc1Jlc3RvcmluZyA9IHVzZUlzUmVzdG9yaW5nKCk7XG5cdGNvbnN0IGVycm9yUmVzZXRCb3VuZGFyeSA9IHVzZVF1ZXJ5RXJyb3JSZXNldEJvdW5kYXJ5KCk7XG5cdGNvbnN0IGNsaWVudCA9IHVzZVF1ZXJ5Q2xpZW50KHF1ZXJ5Q2xpZW50KTtcblx0Y29uc3QgZGVmYXVsdGVkT3B0aW9ucyA9IGNsaWVudC5kZWZhdWx0UXVlcnlPcHRpb25zKG9wdGlvbnMpO1xuXHRjb25zdCBxdWVyeSA9IGNsaWVudC5nZXRRdWVyeUNhY2hlKCkuZ2V0KGRlZmF1bHRlZE9wdGlvbnMucXVlcnlIYXNoKTtcblx0aWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikge1xuXHRcdGlmICghZGVmYXVsdGVkT3B0aW9ucy5xdWVyeUZuKSBjb25zb2xlLmVycm9yKGBbJHtkZWZhdWx0ZWRPcHRpb25zLnF1ZXJ5SGFzaH1dOiBObyBxdWVyeUZuIHdhcyBwYXNzZWQgYXMgYW4gb3B0aW9uLCBhbmQgbm8gZGVmYXVsdCBxdWVyeUZuIHdhcyBmb3VuZC4gVGhlIHF1ZXJ5Rm4gcGFyYW1ldGVyIGlzIG9ubHkgb3B0aW9uYWwgd2hlbiB1c2luZyBhIGRlZmF1bHQgcXVlcnlGbi4gTW9yZSBpbmZvIGhlcmU6IGh0dHBzOi8vdGFuc3RhY2suY29tL3F1ZXJ5L2xhdGVzdC9kb2NzL2ZyYW1ld29yay9yZWFjdC9ndWlkZXMvZGVmYXVsdC1xdWVyeS1mdW5jdGlvbmApO1xuXHR9XG5cdGNvbnN0IHN1YnNjcmliZWQgPSBvcHRpb25zLnN1YnNjcmliZWQgIT09IGZhbHNlO1xuXHRkZWZhdWx0ZWRPcHRpb25zLl9vcHRpbWlzdGljUmVzdWx0cyA9IGlzUmVzdG9yaW5nID8gXCJpc1Jlc3RvcmluZ1wiIDogc3Vic2NyaWJlZCA/IFwib3B0aW1pc3RpY1wiIDogdm9pZCAwO1xuXHRlbnN1cmVTdXNwZW5zZVRpbWVycyhkZWZhdWx0ZWRPcHRpb25zKTtcblx0ZW5zdXJlUHJldmVudEVycm9yQm91bmRhcnlSZXRyeShkZWZhdWx0ZWRPcHRpb25zLCBlcnJvclJlc2V0Qm91bmRhcnksIHF1ZXJ5KTtcblx0dXNlQ2xlYXJSZXNldEVycm9yQm91bmRhcnkoZXJyb3JSZXNldEJvdW5kYXJ5KTtcblx0Y29uc3QgW29ic2VydmVyXSA9IFJlYWN0LnVzZVN0YXRlKCgpID0+IG5ldyBPYnNlcnZlcihjbGllbnQsIGRlZmF1bHRlZE9wdGlvbnMpKTtcblx0Y29uc3QgcmVzdWx0ID0gb2JzZXJ2ZXIuZ2V0T3B0aW1pc3RpY1Jlc3VsdChkZWZhdWx0ZWRPcHRpb25zKTtcblx0UmVhY3QudXNlRWZmZWN0KCgpID0+IHtcblx0XHRvYnNlcnZlci5zZXRPcHRpb25zKGRlZmF1bHRlZE9wdGlvbnMpO1xuXHR9LCBbZGVmYXVsdGVkT3B0aW9ucywgb2JzZXJ2ZXJdKTtcblx0Y29uc3Qgc2hvdWxkU3Vic2NyaWJlID0gIWlzUmVzdG9yaW5nICYmIHN1YnNjcmliZWQ7XG5cdFJlYWN0LnVzZVN5bmNFeHRlcm5hbFN0b3JlKFJlYWN0LnVzZUNhbGxiYWNrKChvblN0b3JlQ2hhbmdlKSA9PiB7XG5cdFx0Y29uc3QgdW5zdWJzY3JpYmUgPSBzaG91bGRTdWJzY3JpYmUgPyBvYnNlcnZlci5zdWJzY3JpYmUobm90aWZ5TWFuYWdlci5iYXRjaENhbGxzKG9uU3RvcmVDaGFuZ2UpKSA6IG5vb3A7XG5cdFx0b2JzZXJ2ZXIudXBkYXRlUmVzdWx0KCk7XG5cdFx0cmV0dXJuIHVuc3Vic2NyaWJlO1xuXHR9LCBbb2JzZXJ2ZXIsIHNob3VsZFN1YnNjcmliZV0pLCAoKSA9PiBvYnNlcnZlci5nZXRDdXJyZW50UmVzdWx0KCksICgpID0+IG9ic2VydmVyLmdldEN1cnJlbnRSZXN1bHQoKSk7XG5cdGlmIChzaG91bGRTdXNwZW5kKGRlZmF1bHRlZE9wdGlvbnMsIHJlc3VsdCkpIHRocm93IGZldGNoT3B0aW1pc3RpYyhkZWZhdWx0ZWRPcHRpb25zLCBvYnNlcnZlciwgZXJyb3JSZXNldEJvdW5kYXJ5KTtcblx0aWYgKGdldEhhc0Vycm9yKHtcblx0XHRyZXN1bHQsXG5cdFx0ZXJyb3JSZXNldEJvdW5kYXJ5LFxuXHRcdHRocm93T25FcnJvcjogZGVmYXVsdGVkT3B0aW9ucy50aHJvd09uRXJyb3IsXG5cdFx0cXVlcnksXG5cdFx0c3VzcGVuc2U6IGRlZmF1bHRlZE9wdGlvbnMuc3VzcGVuc2Vcblx0fSkpIHRocm93IHJlc3VsdC5lcnJvcjtcblx0cmV0dXJuICFkZWZhdWx0ZWRPcHRpb25zLm5vdGlmeU9uQ2hhbmdlUHJvcHMgPyBvYnNlcnZlci50cmFja1Jlc3VsdChyZXN1bHQpIDogcmVzdWx0O1xufVxuZXhwb3J0IHsgdXNlQmFzZVF1ZXJ5IH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXVzZUJhc2VRdWVyeS5qcy5tYXAiLCJcInVzZSBjbGllbnRcIjtcbmltcG9ydCB7IHVzZUJhc2VRdWVyeSB9IGZyb20gXCIuL3VzZUJhc2VRdWVyeS5qc1wiO1xuaW1wb3J0IHsgUXVlcnlPYnNlcnZlciB9IGZyb20gXCJAdGFuc3RhY2svcXVlcnktY29yZVwiO1xuLy8gc3JjL3VzZVF1ZXJ5LnRzXG5mdW5jdGlvbiB1c2VRdWVyeShvcHRpb25zLCBxdWVyeUNsaWVudCkge1xuXHRyZXR1cm4gdXNlQmFzZVF1ZXJ5KG9wdGlvbnMsIFF1ZXJ5T2JzZXJ2ZXIsIHF1ZXJ5Q2xpZW50KTtcbn1cbmV4cG9ydCB7IHVzZVF1ZXJ5IH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXVzZVF1ZXJ5LmpzLm1hcCIsIlwidXNlIGNsaWVudFwiO1xuaW1wb3J0IHsgZGVmYXVsdFRocm93T25FcnJvciB9IGZyb20gXCIuL3N1c3BlbnNlLmpzXCI7XG5pbXBvcnQgeyB1c2VCYXNlUXVlcnkgfSBmcm9tIFwiLi91c2VCYXNlUXVlcnkuanNcIjtcbmltcG9ydCB7IFF1ZXJ5T2JzZXJ2ZXIsIHNraXBUb2tlbiB9IGZyb20gXCJAdGFuc3RhY2svcXVlcnktY29yZVwiO1xuLy8gc3JjL3VzZVN1c3BlbnNlUXVlcnkudHNcbi8qKlxuKiBUaGUgb3B0aW9ucyBmb3IgYHVzZVN1c3BlbnNlUXVlcnlgIGFyZSB0aGUgc2FtZSBhcyBmb3IgYHVzZVF1ZXJ5YCwgZXhjZXB0IGZvciBgdGhyb3dPbkVycm9yYCwgYGVuYWJsZWRgLCBhbmRcbiogYHBsYWNlaG9sZGVyRGF0YWAg4oCUIGFuZCBgcXVlcnlGbmAgbWF5IG5vdCBiZSBgc2tpcFRva2VuYCwgc2luY2UgU3VzcGVuc2UgaG9va3MgY2FuJ3QgcmVuZGVyIGEgXCJkaXNhYmxlZFwiIHN0YXRlLlxuKlxuKiBDYXZlYXQ6IGNhbmNlbGxhdGlvbiBkb2VzIG5vdCB3b3JrLlxuKiBAcGFyYW0gb3B0aW9ucyAtIFRoZSB7QGxpbmsgVXNlU3VzcGVuc2VRdWVyeU9wdGlvbnN9IHRvIHVzZSDigJQgdGhlIHNhbWUgb3B0aW9ucyBhcyBgdXNlUXVlcnlgLCBtaW51cyB0aGUgb25lcyBsaXN0ZWQgYWJvdmUuXG4qIEBwYXJhbSBxdWVyeUNsaWVudCAtIFVzZSB0aGlzIHRvIHVzZSBhIGN1c3RvbSBgUXVlcnlDbGllbnRgLiBPdGhlcndpc2UsIHRoZSBvbmUgZnJvbSB0aGUgbmVhcmVzdCBjb250ZXh0IHdpbGxcbiogYmUgdXNlZC5cbiogQHJldHVybnMgVGhlIHNhbWUgb2JqZWN0IGFzIGB1c2VRdWVyeWAsIGV4Y2VwdCB0aGF0IGBkYXRhYCBpcyBndWFyYW50ZWVkIHRvIGJlIGRlZmluZWQsIGBpc1BsYWNlaG9sZGVyRGF0YWBcbiogaXMgbWlzc2luZywgYW5kIGBzdGF0dXNgIGlzIGVpdGhlciBgc3VjY2Vzc2Agb3IgYGVycm9yYCAod2l0aCB0aGUgZGVyaXZlZCBmbGFncyBzZXQgYWNjb3JkaW5nbHkpLlxuKiBAcmVtYXJrcyBNdWx0aXBsZSBgdXNlU3VzcGVuc2VRdWVyeWAgY2FsbHMgaW4gdGhlIHNhbWUgY29tcG9uZW50IHN1c3BlbmQgc2VyaWFsbHksIGNhdXNpbmcgYSByZXF1ZXN0XG4qIHdhdGVyZmFsbCDigJQgZWFjaCBvbmUgYmxvY2tzIHJlbmRlcmluZyB1bnRpbCBpdCByZXNvbHZlcywgc28gdGhlIG5leHQgZG9lc24ndCBldmVuIHN0YXJ0IGZldGNoaW5nIHVudGlsIHRoZW4uXG4qIFVzZSB7QGxpbmsgdXNlU3VzcGVuc2VRdWVyaWVzfSBpbnN0ZWFkIHdoZW4geW91IGhhdmUgbW9yZSB0aGFuIG9uZSBzdXNwZW5zZWZ1bCBxdWVyeSBpbiBhIGNvbXBvbmVudCwgc28gdGhleVxuKiBmZXRjaCBpbiBwYXJhbGxlbC5cbiogQGV4YW1wbGVcbiogVGhlIHF1ZXJ5IGVycm9yIGlzIHRocm93biBpZiB0aGUgZmV0Y2ggZmFpbHMgYW5kIG5vIGNhY2hlZCBkYXRhIGV4aXN0cyB5ZXQsIHNvIGFuIGVycm9yIGJvdW5kYXJ5IGlzXG4qIHJlcXVpcmVkIGFyb3VuZCBgPFN1c3BlbnNlPmAuIEEgZmFpbGVkIGJhY2tncm91bmQgcmVmZXRjaCBpbnN0ZWFkIGNvbnRpbnVlcyB0byByZW5kZXIgdGhlIGNhY2hlZCBkYXRhLlxuKiBVc2Uge0BsaW5rIFF1ZXJ5RXJyb3JSZXNldEJvdW5kYXJ5fSB0byBsZXQgdGhlIHVzZXIgcmV0cnkgYWZ0ZXIgc3VjaCBhbiBlcnJvcjpcbiogYGBgdHN4XG4qIGltcG9ydCB7IFN1c3BlbnNlIH0gZnJvbSAncmVhY3QnXG4qIGltcG9ydCB7IEVycm9yQm91bmRhcnkgfSBmcm9tICdyZWFjdC1lcnJvci1ib3VuZGFyeSdcbiogaW1wb3J0IHsgUXVlcnlFcnJvclJlc2V0Qm91bmRhcnksIHVzZVN1c3BlbnNlUXVlcnkgfSBmcm9tICdAdGFuc3RhY2svcmVhY3QtcXVlcnknXG4qXG4qIGZ1bmN0aW9uIFBvc3RzKCkge1xuKiAgIC8vIGBkYXRhYCBpcyBndWFyYW50ZWVkIHRvIGJlIGRlZmluZWQgaGVyZSDigJQgbm8gYGlzUGVuZGluZ2AgY2hlY2sgbmVlZGVkLlxuKiAgIGNvbnN0IHsgZGF0YSwgaXNGZXRjaGluZyB9ID0gdXNlU3VzcGVuc2VRdWVyeSh7XG4qICAgICBxdWVyeUtleTogWydwb3N0cyddLFxuKiAgICAgcXVlcnlGbjogZmV0Y2hQb3N0cyxcbiogICB9KVxuKlxuKiAgIHJldHVybiAoXG4qICAgICA8ZGl2PlxuKiAgICAgICA8aDE+UG9zdHMge2lzRmV0Y2hpbmcgPyAnKHJlZnJlc2hpbmcuLi4pJyA6IG51bGx9PC9oMT5cbiogICAgICAgPHVsPlxuKiAgICAgICAgIHtkYXRhLm1hcCgocG9zdCkgPT4gKFxuKiAgICAgICAgICAgPGxpIGtleT17cG9zdC5pZH0+e3Bvc3QudGl0bGV9PC9saT5cbiogICAgICAgICApKX1cbiogICAgICAgPC91bD5cbiogICAgIDwvZGl2PlxuKiAgIClcbiogfVxuKlxuKiBmdW5jdGlvbiBBcHAoKSB7XG4qICAgcmV0dXJuIChcbiogICAgIDxRdWVyeUVycm9yUmVzZXRCb3VuZGFyeT5cbiogICAgICAgeyh7IHJlc2V0IH0pID0+IChcbiogICAgICAgICA8RXJyb3JCb3VuZGFyeVxuKiAgICAgICAgICAgb25SZXNldD17cmVzZXR9XG4qICAgICAgICAgICBmYWxsYmFja1JlbmRlcj17KHsgcmVzZXRFcnJvckJvdW5kYXJ5IH0pID0+IChcbiogICAgICAgICAgICAgPGRpdj5cbiogICAgICAgICAgICAgICBUaGVyZSB3YXMgYW4gZXJyb3IhXG4qICAgICAgICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiByZXNldEVycm9yQm91bmRhcnkoKX0+VHJ5IGFnYWluPC9idXR0b24+XG4qICAgICAgICAgICAgIDwvZGl2PlxuKiAgICAgICAgICAgKX1cbiogICAgICAgICA+XG4qICAgICAgICAgICA8U3VzcGVuc2UgZmFsbGJhY2s9ezxoMT5Mb2FkaW5nIHBvc3RzLi4uPC9oMT59PlxuKiAgICAgICAgICAgICA8UG9zdHMgLz5cbiogICAgICAgICAgIDwvU3VzcGVuc2U+XG4qICAgICAgICAgPC9FcnJvckJvdW5kYXJ5PlxuKiAgICAgICApfVxuKiAgICAgPC9RdWVyeUVycm9yUmVzZXRCb3VuZGFyeT5cbiogICApXG4qIH1cbiogYGBgXG4qL1xuZnVuY3Rpb24gdXNlU3VzcGVuc2VRdWVyeShvcHRpb25zLCBxdWVyeUNsaWVudCkge1xuXHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSB7XG5cdFx0aWYgKG9wdGlvbnMucXVlcnlGbiA9PT0gc2tpcFRva2VuKSBjb25zb2xlLmVycm9yKFwic2tpcFRva2VuIGlzIG5vdCBhbGxvd2VkIGZvciB1c2VTdXNwZW5zZVF1ZXJ5XCIpO1xuXHR9XG5cdHJldHVybiB1c2VCYXNlUXVlcnkoe1xuXHRcdC4uLm9wdGlvbnMsXG5cdFx0ZW5hYmxlZDogdHJ1ZSxcblx0XHRzdXNwZW5zZTogdHJ1ZSxcblx0XHR0aHJvd09uRXJyb3I6IGRlZmF1bHRUaHJvd09uRXJyb3IsXG5cdFx0cGxhY2Vob2xkZXJEYXRhOiB2b2lkIDBcblx0fSwgUXVlcnlPYnNlcnZlciwgcXVlcnlDbGllbnQpO1xufVxuZXhwb3J0IHsgdXNlU3VzcGVuc2VRdWVyeSB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD11c2VTdXNwZW5zZVF1ZXJ5LmpzLm1hcCIsIlwidXNlIGNsaWVudFwiO1xuaW1wb3J0IHsgZGVmYXVsdFRocm93T25FcnJvciB9IGZyb20gXCIuL3N1c3BlbnNlLmpzXCI7XG5pbXBvcnQgeyB1c2VCYXNlUXVlcnkgfSBmcm9tIFwiLi91c2VCYXNlUXVlcnkuanNcIjtcbmltcG9ydCB7IEluZmluaXRlUXVlcnlPYnNlcnZlciwgc2tpcFRva2VuIH0gZnJvbSBcIkB0YW5zdGFjay9xdWVyeS1jb3JlXCI7XG4vLyBzcmMvdXNlU3VzcGVuc2VJbmZpbml0ZVF1ZXJ5LnRzXG4vKipcbiogVGhlIG9wdGlvbnMgZm9yIGB1c2VTdXNwZW5zZUluZmluaXRlUXVlcnlgIGFyZSB0aGUgc2FtZSBhcyBmb3IgYHVzZUluZmluaXRlUXVlcnlgLCBleGNlcHQgZm9yIGB0aHJvd09uRXJyb3JgLFxuKiBgZW5hYmxlZGAsIGFuZCBgcGxhY2Vob2xkZXJEYXRhYC5cbipcbiogQ2F2ZWF0OiBjYW5jZWxsYXRpb24gZG9lcyBub3Qgd29yay5cbiogQHBhcmFtIG9wdGlvbnMgLSBUaGUge0BsaW5rIFVzZVN1c3BlbnNlSW5maW5pdGVRdWVyeU9wdGlvbnN9IHRvIHVzZSDigJQgdGhlIHNhbWUgb3B0aW9ucyBhcyBgdXNlSW5maW5pdGVRdWVyeWAsIG1pbnVzIHRoZSBvbmVzIGxpc3RlZCBhYm92ZS5cbiogQHBhcmFtIHF1ZXJ5Q2xpZW50IC0gVXNlIHRoaXMgdG8gdXNlIGEgY3VzdG9tIGBRdWVyeUNsaWVudGAuIE90aGVyd2lzZSwgdGhlIG9uZSBmcm9tIHRoZSBuZWFyZXN0IGNvbnRleHQgd2lsbFxuKiBiZSB1c2VkLlxuKiBAcmV0dXJucyBUaGUgc2FtZSBvYmplY3QgYXMgYHVzZUluZmluaXRlUXVlcnlgLCBleGNlcHQgdGhhdCBgZGF0YWAgaXMgZ3VhcmFudGVlZCB0byBiZSBkZWZpbmVkLFxuKiBgaXNQbGFjZWhvbGRlckRhdGFgIGlzIG1pc3NpbmcsIGFuZCBgc3RhdHVzYCBpcyBlaXRoZXIgYHN1Y2Nlc3NgIG9yIGBlcnJvcmAgKHdpdGggdGhlIGRlcml2ZWQgZmxhZ3Mgc2V0XG4qIGFjY29yZGluZ2x5KS5cbiogQHJlbWFya3MgTXVsdGlwbGUgc3VzcGVuc2VmdWwgcXVlcnkgY2FsbHMgaW4gdGhlIHNhbWUgY29tcG9uZW50IHN1c3BlbmQgc2VyaWFsbHksIGNhdXNpbmcgYSByZXF1ZXN0XG4qIHdhdGVyZmFsbCDigJQgZWFjaCBvbmUgYmxvY2tzIHJlbmRlcmluZyB1bnRpbCBpdCByZXNvbHZlcywgc28gdGhlIG5leHQgZG9lc24ndCBldmVuIHN0YXJ0IGZldGNoaW5nIHVudGlsXG4qIHRoZW4uIFRoZXJlJ3Mgbm8gd2F5IHRvIHBhcmFsbGVsaXplIG11bHRpcGxlIGluZmluaXRlIHF1ZXJpZXMgdW5kZXIgU3VzcGVuc2UuIEFsc28ga2VlcCBpbiBtaW5kIHRoYXRcbiogaW1wZXJhdGl2ZSBmZXRjaCBjYWxscywgc3VjaCBhcyBgZmV0Y2hOZXh0UGFnZWAsIG1heSBpbnRlcmZlcmUgd2l0aCB0aGUgZGVmYXVsdCByZWZldGNoIGJlaGF2aW9yLFxuKiByZXN1bHRpbmcgaW4gb3V0ZGF0ZWQgZGF0YS4gTWFrZSBzdXJlIHRvIGNhbGwgdGhlc2UgZnVuY3Rpb25zIG9ubHkgaW4gcmVzcG9uc2UgdG8gdXNlciBhY3Rpb25zLCBvciBhZGRcbiogY29uZGl0aW9ucyBsaWtlIGBoYXNOZXh0UGFnZSAmJiAhaXNGZXRjaGluZ2AuXG4qIEBzZWUge0BsaW5rIHVzZUluZmluaXRlUXVlcnl9IGZvciB0aGUgbm9uLVN1c3BlbnNlIHZlcnNpb24gb2YgdGhpcyBob29rLlxuKiBAZXhhbXBsZVxuKiBUaGUgcXVlcnkgZXJyb3IgaXMgdGhyb3duIGlmIGEgZmV0Y2ggZmFpbHMgYW5kIG5vIGNhY2hlZCBkYXRhIGV4aXN0cyB5ZXQsIHNvIGFuIGVycm9yIGJvdW5kYXJ5IGlzXG4qIHJlcXVpcmVkIGFyb3VuZCBgPFN1c3BlbnNlPmAuIEEgZmFpbGVkIGJhY2tncm91bmQgcmVmZXRjaCBpbnN0ZWFkIGNvbnRpbnVlcyB0byByZW5kZXIgdGhlIGNhY2hlZCBkYXRhLlxuKiBVc2Uge0BsaW5rIFF1ZXJ5RXJyb3JSZXNldEJvdW5kYXJ5fSB0byBsZXQgdGhlIHVzZXIgcmV0cnkgYWZ0ZXIgc3VjaCBhbiBlcnJvcjpcbiogYGBgdHN4XG4qIGltcG9ydCB7IFN1c3BlbnNlIH0gZnJvbSAncmVhY3QnXG4qIGltcG9ydCB7IEVycm9yQm91bmRhcnkgfSBmcm9tICdyZWFjdC1lcnJvci1ib3VuZGFyeSdcbiogaW1wb3J0IHtcbiogICBRdWVyeUVycm9yUmVzZXRCb3VuZGFyeSxcbiogICB1c2VTdXNwZW5zZUluZmluaXRlUXVlcnksXG4qIH0gZnJvbSAnQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5J1xuKlxuKiBmdW5jdGlvbiBQcm9qZWN0cygpIHtcbiogICAvLyBgZGF0YWAgaXMgZ3VhcmFudGVlZCB0byBiZSBkZWZpbmVkIGhlcmUg4oCUIG5vIGBpc1BlbmRpbmdgIGNoZWNrIG5lZWRlZC5cbiogICBjb25zdCB7IGRhdGEsIGZldGNoTmV4dFBhZ2UsIGhhc05leHRQYWdlLCBpc0ZldGNoaW5nLCBpc0ZldGNoaW5nTmV4dFBhZ2UgfSA9XG4qICAgICB1c2VTdXNwZW5zZUluZmluaXRlUXVlcnkoe1xuKiAgICAgICBxdWVyeUtleTogWydwcm9qZWN0cyddLFxuKiAgICAgICBxdWVyeUZuOiAoeyBwYWdlUGFyYW0gfSkgPT4gZmV0Y2hQcm9qZWN0cyhwYWdlUGFyYW0pLFxuKiAgICAgICBpbml0aWFsUGFnZVBhcmFtOiAwLFxuKiAgICAgICBnZXROZXh0UGFnZVBhcmFtOiAobGFzdFBhZ2UpID0+IGxhc3RQYWdlLm5leHRJZCxcbiogICAgIH0pXG4qXG4qICAgcmV0dXJuIChcbiogICAgIDxkaXY+XG4qICAgICAgIDx1bD5cbiogICAgICAgICB7ZGF0YS5wYWdlcy5tYXAoKHBhZ2UpID0+XG4qICAgICAgICAgICBwYWdlLnByb2plY3RzLm1hcCgocHJvamVjdCkgPT4gPGxpIGtleT17cHJvamVjdC5pZH0+e3Byb2plY3QubmFtZX08L2xpPiksXG4qICAgICAgICAgKX1cbiogICAgICAgPC91bD5cbiogICAgICAgPGJ1dHRvblxuKiAgICAgICAgIG9uQ2xpY2s9eygpID0+IGZldGNoTmV4dFBhZ2UoKX1cbiogICAgICAgICBkaXNhYmxlZD17IWhhc05leHRQYWdlIHx8IGlzRmV0Y2hpbmd9XG4qICAgICAgID5cbiogICAgICAgICB7aXNGZXRjaGluZ05leHRQYWdlXG4qICAgICAgICAgICA/ICdMb2FkaW5nIG1vcmUuLi4nXG4qICAgICAgICAgICA6IGhhc05leHRQYWdlXG4qICAgICAgICAgICAgID8gJ0xvYWQgTW9yZSdcbiogICAgICAgICAgICAgOiAnTm90aGluZyBtb3JlIHRvIGxvYWQnfVxuKiAgICAgICA8L2J1dHRvbj5cbiogICAgIDwvZGl2PlxuKiAgIClcbiogfVxuKlxuKiBmdW5jdGlvbiBBcHAoKSB7XG4qICAgcmV0dXJuIChcbiogICAgIDxRdWVyeUVycm9yUmVzZXRCb3VuZGFyeT5cbiogICAgICAgeyh7IHJlc2V0IH0pID0+IChcbiogICAgICAgICA8RXJyb3JCb3VuZGFyeVxuKiAgICAgICAgICAgb25SZXNldD17cmVzZXR9XG4qICAgICAgICAgICBmYWxsYmFja1JlbmRlcj17KHsgcmVzZXRFcnJvckJvdW5kYXJ5IH0pID0+IChcbiogICAgICAgICAgICAgPGRpdj5cbiogICAgICAgICAgICAgICBUaGVyZSB3YXMgYW4gZXJyb3IhXG4qICAgICAgICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiByZXNldEVycm9yQm91bmRhcnkoKX0+VHJ5IGFnYWluPC9idXR0b24+XG4qICAgICAgICAgICAgIDwvZGl2PlxuKiAgICAgICAgICAgKX1cbiogICAgICAgICA+XG4qICAgICAgICAgICA8U3VzcGVuc2UgZmFsbGJhY2s9ezxoMT5Mb2FkaW5nIHByb2plY3RzLi4uPC9oMT59PlxuKiAgICAgICAgICAgICA8UHJvamVjdHMgLz5cbiogICAgICAgICAgIDwvU3VzcGVuc2U+XG4qICAgICAgICAgPC9FcnJvckJvdW5kYXJ5PlxuKiAgICAgICApfVxuKiAgICAgPC9RdWVyeUVycm9yUmVzZXRCb3VuZGFyeT5cbiogICApXG4qIH1cbiogYGBgXG4qL1xuZnVuY3Rpb24gdXNlU3VzcGVuc2VJbmZpbml0ZVF1ZXJ5KG9wdGlvbnMsIHF1ZXJ5Q2xpZW50KSB7XG5cdGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIHtcblx0XHRpZiAob3B0aW9ucy5xdWVyeUZuID09PSBza2lwVG9rZW4pIGNvbnNvbGUuZXJyb3IoXCJza2lwVG9rZW4gaXMgbm90IGFsbG93ZWQgZm9yIHVzZVN1c3BlbnNlSW5maW5pdGVRdWVyeVwiKTtcblx0fVxuXHRyZXR1cm4gdXNlQmFzZVF1ZXJ5KHtcblx0XHQuLi5vcHRpb25zLFxuXHRcdGVuYWJsZWQ6IHRydWUsXG5cdFx0c3VzcGVuc2U6IHRydWUsXG5cdFx0dGhyb3dPbkVycm9yOiBkZWZhdWx0VGhyb3dPbkVycm9yLFxuXHRcdHBsYWNlaG9sZGVyRGF0YTogdm9pZCAwXG5cdH0sIEluZmluaXRlUXVlcnlPYnNlcnZlciwgcXVlcnlDbGllbnQpO1xufVxuZXhwb3J0IHsgdXNlU3VzcGVuc2VJbmZpbml0ZVF1ZXJ5IH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXVzZVN1c3BlbnNlSW5maW5pdGVRdWVyeS5qcy5tYXAiLCJcInVzZSBjbGllbnRcIjtcbmltcG9ydCB7IGRlZmF1bHRUaHJvd09uRXJyb3IgfSBmcm9tIFwiLi9zdXNwZW5zZS5qc1wiO1xuaW1wb3J0IHsgdXNlUXVlcmllcyB9IGZyb20gXCIuL3VzZVF1ZXJpZXMuanNcIjtcbmltcG9ydCB7IHNraXBUb2tlbiB9IGZyb20gXCJAdGFuc3RhY2svcXVlcnktY29yZVwiO1xuLy8gc3JjL3VzZVN1c3BlbnNlUXVlcmllcy50c1xuZnVuY3Rpb24gdXNlU3VzcGVuc2VRdWVyaWVzKG9wdGlvbnMsIHF1ZXJ5Q2xpZW50KSB7XG5cdHJldHVybiB1c2VRdWVyaWVzKHtcblx0XHQuLi5vcHRpb25zLFxuXHRcdHF1ZXJpZXM6IG9wdGlvbnMucXVlcmllcy5tYXAoKHF1ZXJ5KSA9PiB7XG5cdFx0XHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSB7XG5cdFx0XHRcdGlmIChxdWVyeS5xdWVyeUZuID09PSBza2lwVG9rZW4pIGNvbnNvbGUuZXJyb3IoXCJza2lwVG9rZW4gaXMgbm90IGFsbG93ZWQgZm9yIHVzZVN1c3BlbnNlUXVlcmllc1wiKTtcblx0XHRcdH1cblx0XHRcdHJldHVybiB7XG5cdFx0XHRcdC4uLnF1ZXJ5LFxuXHRcdFx0XHRzdXNwZW5zZTogdHJ1ZSxcblx0XHRcdFx0dGhyb3dPbkVycm9yOiBkZWZhdWx0VGhyb3dPbkVycm9yLFxuXHRcdFx0XHRlbmFibGVkOiB0cnVlLFxuXHRcdFx0XHRwbGFjZWhvbGRlckRhdGE6IHZvaWQgMFxuXHRcdFx0fTtcblx0XHR9KVxuXHR9LCBxdWVyeUNsaWVudCk7XG59XG5leHBvcnQgeyB1c2VTdXNwZW5zZVF1ZXJpZXMgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9dXNlU3VzcGVuc2VRdWVyaWVzLmpzLm1hcCIsImltcG9ydCB7IHVzZVF1ZXJ5Q2xpZW50IH0gZnJvbSBcIi4vUXVlcnlDbGllbnRQcm92aWRlci5qc1wiO1xuaW1wb3J0IHsgbm9vcCB9IGZyb20gXCJAdGFuc3RhY2svcXVlcnktY29yZVwiO1xuLy8gc3JjL3VzZVByZWZldGNoUXVlcnkudHN4XG4vKipcbiogYHVzZVByZWZldGNoUXVlcnlgIGRvZXMgbm90IHJldHVybiBhbnl0aGluZywgaXQgc2hvdWxkIGJlIHVzZWQganVzdCB0byBmaXJlIGEgcHJlZmV0Y2ggZHVyaW5nIHJlbmRlciwgYmVmb3JlXG4qIGEgc3VzcGVuc2UgYm91bmRhcnkgdGhhdCB3cmFwcyBhIGNvbXBvbmVudCB0aGF0IHVzZXMgYHVzZVN1c3BlbnNlUXVlcnlgLiBZb3UgY2FuIHBhc3MgZXZlcnl0aGluZyB0b1xuKiBgdXNlUHJlZmV0Y2hRdWVyeWAgdGhhdCB5b3UgY2FuIHBhc3MgdG8gYHF1ZXJ5Q2xpZW50LnF1ZXJ5YCwgdGhvdWdoIGBxdWVyeUtleWAgaXMgYWx3YXlzIHJlcXVpcmVkLCBhbmRcbiogYHF1ZXJ5Rm5gIGlzIHJlcXVpcmVkIHVubGVzcyBhIGRlZmF1bHQgcXVlcnkgZnVuY3Rpb24gaGFzIGJlZW4gZGVmaW5lZC5cbipcbiogVGhlIHByZWZldGNoIGlzIHNraXBwZWQgaWYgdGhlIHF1ZXJ5IGFscmVhZHkgaGFzIGFueSBjYWNoZWQgc3RhdGUg4oCUIGluY2x1ZGluZyBhIGBwZW5kaW5nYC9gZXJyb3JgIHN0YXRlIGxlZnRcbiogb3ZlciBmcm9tIGEgcHJldmlvdXMgYXR0ZW1wdCDigJQgc28gY2FsbGluZyB0aGlzIG9uIGV2ZXJ5IHJlbmRlciBpcyBjaGVhcCBhbmQgd29uJ3QgcmVmZXRjaCBkYXRhIHRoYXQnc1xuKiBhbHJlYWR5IHRoZXJlIG9yIGFscmVhZHkgaW4gZmxpZ2h0LlxuKiBAcGFyYW0gb3B0aW9ucyAtIFRoZSB7QGxpbmsgVXNlUHJlZmV0Y2hRdWVyeU9wdGlvbnN9IHRvIHVzZSDigJQgZXZlcnl0aGluZyB5b3UgY2FuIHBhc3MgdG8gYHF1ZXJ5Q2xpZW50LnF1ZXJ5YC5cbiogQHBhcmFtIHF1ZXJ5Q2xpZW50IC0gVXNlIHRoaXMgdG8gdXNlIGEgY3VzdG9tIGBRdWVyeUNsaWVudGAuIE90aGVyd2lzZSwgdGhlIG9uZSBmcm9tIHRoZSBuZWFyZXN0IGNvbnRleHQgd2lsbFxuKiBiZSB1c2VkLlxuKiBAZXhhbXBsZVxuKiBgYGB0c3hcbiogaW1wb3J0IHsgU3VzcGVuc2UgfSBmcm9tICdyZWFjdCdcbiogaW1wb3J0IHsgdXNlUHJlZmV0Y2hRdWVyeSB9IGZyb20gJ0B0YW5zdGFjay9yZWFjdC1xdWVyeSdcbipcbiogZnVuY3Rpb24gQXBwKCkge1xuKiAgIC8vIEZpcmUgdGhlIHByZWZldGNoIGR1cmluZyByZW5kZXIsIGJlZm9yZSB0aGUgc3VzcGVuc2UgYm91bmRhcnkgYmVsb3cuXG4qICAgdXNlUHJlZmV0Y2hRdWVyeSh7XG4qICAgICBxdWVyeUtleTogWydwb3N0cyddLFxuKiAgICAgcXVlcnlGbjogZmV0Y2hQb3N0cyxcbiogICB9KVxuKlxuKiAgIHJldHVybiAoXG4qICAgICA8U3VzcGVuc2UgZmFsbGJhY2s9ezxoMT5Mb2FkaW5nIHBvc3RzLi4uPC9oMT59PlxuKiAgICAgICA8UG9zdHMgLz5cbiogICAgIDwvU3VzcGVuc2U+XG4qICAgKVxuKiB9XG4qIGBgYFxuKi9cbmZ1bmN0aW9uIHVzZVByZWZldGNoUXVlcnkob3B0aW9ucywgcXVlcnlDbGllbnQpIHtcblx0Y29uc3QgY2xpZW50ID0gdXNlUXVlcnlDbGllbnQocXVlcnlDbGllbnQpO1xuXHRpZiAoIWNsaWVudC5nZXRRdWVyeVN0YXRlKG9wdGlvbnMucXVlcnlLZXkpKSBjbGllbnQucXVlcnkob3B0aW9ucykuY2F0Y2gobm9vcCk7XG59XG5leHBvcnQgeyB1c2VQcmVmZXRjaFF1ZXJ5IH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXVzZVByZWZldGNoUXVlcnkuanMubWFwIiwiaW1wb3J0IHsgdXNlUXVlcnlDbGllbnQgfSBmcm9tIFwiLi9RdWVyeUNsaWVudFByb3ZpZGVyLmpzXCI7XG5pbXBvcnQgeyBub29wIH0gZnJvbSBcIkB0YW5zdGFjay9xdWVyeS1jb3JlXCI7XG4vLyBzcmMvdXNlUHJlZmV0Y2hJbmZpbml0ZVF1ZXJ5LnRzeFxuLyoqXG4qIGB1c2VQcmVmZXRjaEluZmluaXRlUXVlcnlgIGRvZXMgbm90IHJldHVybiBhbnl0aGluZywgaXQgc2hvdWxkIGJlIHVzZWQganVzdCB0byBmaXJlIGEgcHJlZmV0Y2ggZHVyaW5nIHJlbmRlcixcbiogYmVmb3JlIGEgc3VzcGVuc2UgYm91bmRhcnkgdGhhdCB3cmFwcyBhIGNvbXBvbmVudCB0aGF0IHVzZXMgYHVzZVN1c3BlbnNlSW5maW5pdGVRdWVyeWAuIFlvdSBjYW4gcGFzc1xuKiBldmVyeXRoaW5nIHRvIGB1c2VQcmVmZXRjaEluZmluaXRlUXVlcnlgIHRoYXQgeW91IGNhbiBwYXNzIHRvIGBxdWVyeUNsaWVudC5pbmZpbml0ZVF1ZXJ5YCwgdGhvdWdoXG4qIGBxdWVyeUtleWAsIGBpbml0aWFsUGFnZVBhcmFtYCwgYW5kIGBnZXROZXh0UGFnZVBhcmFtYCBhcmUgYWx3YXlzIHJlcXVpcmVkLCBhbmQgYHF1ZXJ5Rm5gIGlzIHJlcXVpcmVkIHVubGVzc1xuKiBhIGRlZmF1bHQgcXVlcnkgZnVuY3Rpb24gaGFzIGJlZW4gZGVmaW5lZC5cbipcbiogYGdldE5leHRQYWdlUGFyYW1gIHJlY2VpdmVzIGJvdGggdGhlIGxhc3QgcGFnZSBvZiB0aGUgaW5maW5pdGUgbGlzdCBvZiBkYXRhIGFuZCB0aGUgZnVsbCBhcnJheSBvZiBhbGwgcGFnZXMsXG4qIGFzIHdlbGwgYXMgcGFnZVBhcmFtIGluZm9ybWF0aW9uLCBhbmQgc2hvdWxkIHJldHVybiBhIHNpbmdsZSB2YXJpYWJsZSB0aGF0IHdpbGwgYmUgcGFzc2VkIHRvIHlvdXIgcXVlcnlcbiogZnVuY3Rpb24gYXMgYGNvbnRleHQucGFnZVBhcmFtYC4gUmV0dXJuIGB1bmRlZmluZWRgIG9yIGBudWxsYCB0byBpbmRpY2F0ZSB0aGVyZSBpcyBubyBuZXh0IHBhZ2UgYXZhaWxhYmxlLlxuKlxuKiBUaGUgcHJlZmV0Y2ggaXMgc2tpcHBlZCBpZiB0aGUgcXVlcnkgYWxyZWFkeSBoYXMgYW55IGNhY2hlZCBzdGF0ZSDigJQgaW5jbHVkaW5nIGEgYHBlbmRpbmdgL2BlcnJvcmAgc3RhdGUgbGVmdFxuKiBvdmVyIGZyb20gYSBwcmV2aW91cyBhdHRlbXB0IOKAlCBzbyBjYWxsaW5nIHRoaXMgb24gZXZlcnkgcmVuZGVyIGlzIGNoZWFwIGFuZCB3b24ndCByZWZldGNoIGRhdGEgdGhhdCdzXG4qIGFscmVhZHkgdGhlcmUgb3IgYWxyZWFkeSBpbiBmbGlnaHQuXG4qIEBwYXJhbSBvcHRpb25zIC0gVGhlIHtAbGluayBVc2VQcmVmZXRjaEluZmluaXRlUXVlcnlPcHRpb25zfSB0byB1c2Ug4oCUIGV2ZXJ5dGhpbmcgeW91IGNhbiBwYXNzIHRvIGBxdWVyeUNsaWVudC5pbmZpbml0ZVF1ZXJ5YC5cbiogQHBhcmFtIHF1ZXJ5Q2xpZW50IC0gVXNlIHRoaXMgdG8gdXNlIGEgY3VzdG9tIGBRdWVyeUNsaWVudGAuIE90aGVyd2lzZSwgdGhlIG9uZSBmcm9tIHRoZSBuZWFyZXN0IGNvbnRleHQgd2lsbFxuKiBiZSB1c2VkLlxuKiBAZXhhbXBsZVxuKiBgYGB0c3hcbiogaW1wb3J0IHsgU3VzcGVuc2UgfSBmcm9tICdyZWFjdCdcbiogaW1wb3J0IHsgaW5maW5pdGVRdWVyeU9wdGlvbnMsIHVzZVByZWZldGNoSW5maW5pdGVRdWVyeSB9IGZyb20gJ0B0YW5zdGFjay9yZWFjdC1xdWVyeSdcbipcbiogY29uc3QgcHJvamVjdHNPcHRpb25zID0gaW5maW5pdGVRdWVyeU9wdGlvbnMoe1xuKiAgIHF1ZXJ5S2V5OiBbJ3Byb2plY3RzJ10sXG4qICAgcXVlcnlGbjogKHsgcGFnZVBhcmFtIH0pID0+IGZldGNoUHJvamVjdHMocGFnZVBhcmFtKSxcbiogICBpbml0aWFsUGFnZVBhcmFtOiAwLFxuKiAgIGdldE5leHRQYWdlUGFyYW06IChsYXN0UGFnZSkgPT4gbGFzdFBhZ2UubmV4dElkLFxuKiB9KVxuKlxuKiBmdW5jdGlvbiBBcHAoKSB7XG4qICAgLy8gRmlyZSB0aGUgcHJlZmV0Y2ggZHVyaW5nIHJlbmRlciwgYmVmb3JlIHRoZSBzdXNwZW5zZSBib3VuZGFyeSBiZWxvdy5cbiogICB1c2VQcmVmZXRjaEluZmluaXRlUXVlcnkocHJvamVjdHNPcHRpb25zKVxuKlxuKiAgIHJldHVybiAoXG4qICAgICA8U3VzcGVuc2UgZmFsbGJhY2s9ezxoMT5Mb2FkaW5nIHByb2plY3RzLi4uPC9oMT59PlxuKiAgICAgICA8UHJvamVjdHMgLz5cbiogICAgIDwvU3VzcGVuc2U+XG4qICAgKVxuKiB9XG4qIGBgYFxuKi9cbmZ1bmN0aW9uIHVzZVByZWZldGNoSW5maW5pdGVRdWVyeShvcHRpb25zLCBxdWVyeUNsaWVudCkge1xuXHRjb25zdCBjbGllbnQgPSB1c2VRdWVyeUNsaWVudChxdWVyeUNsaWVudCk7XG5cdGlmICghY2xpZW50LmdldFF1ZXJ5U3RhdGUob3B0aW9ucy5xdWVyeUtleSkpIGNsaWVudC5pbmZpbml0ZVF1ZXJ5KG9wdGlvbnMpLmNhdGNoKG5vb3ApO1xufVxuZXhwb3J0IHsgdXNlUHJlZmV0Y2hJbmZpbml0ZVF1ZXJ5IH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXVzZVByZWZldGNoSW5maW5pdGVRdWVyeS5qcy5tYXAiLCIvLyBzcmMvcXVlcnlPcHRpb25zLnRzXG5mdW5jdGlvbiBxdWVyeU9wdGlvbnMob3B0aW9ucykge1xuXHRyZXR1cm4gb3B0aW9ucztcbn1cbmV4cG9ydCB7IHF1ZXJ5T3B0aW9ucyB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1xdWVyeU9wdGlvbnMuanMubWFwIiwiLy8gc3JjL2luZmluaXRlUXVlcnlPcHRpb25zLnRzXG5mdW5jdGlvbiBpbmZpbml0ZVF1ZXJ5T3B0aW9ucyhvcHRpb25zKSB7XG5cdHJldHVybiBvcHRpb25zO1xufVxuZXhwb3J0IHsgaW5maW5pdGVRdWVyeU9wdGlvbnMgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9aW5maW5pdGVRdWVyeU9wdGlvbnMuanMubWFwIiwiXCJ1c2UgY2xpZW50XCI7XG5pbXBvcnQgeyB1c2VRdWVyeUNsaWVudCB9IGZyb20gXCIuL1F1ZXJ5Q2xpZW50UHJvdmlkZXIuanNcIjtcbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgbm90aWZ5TWFuYWdlciB9IGZyb20gXCJAdGFuc3RhY2svcXVlcnktY29yZVwiO1xuLy8gc3JjL3VzZUlzRmV0Y2hpbmcudHNcbi8qKlxuKiBUaGUgYHVzZUlzRmV0Y2hpbmdgIGhvb2sgcmV0dXJucyB0aGUgYG51bWJlcmAgb2YgdGhlIHF1ZXJpZXMgdGhhdCB5b3VyIGFwcGxpY2F0aW9uIGlzIGxvYWRpbmcgb3IgZmV0Y2hpbmcgaW5cbiogdGhlIGJhY2tncm91bmQgKHVzZWZ1bCBmb3IgYXBwLXdpZGUgbG9hZGluZyBpbmRpY2F0b3JzKS5cbiogQHBhcmFtIGZpbHRlcnMgLSBUaGUge0BsaW5rIFF1ZXJ5RmlsdGVyc30gdG8gbmFycm93IGRvd24gdGhlIG1hdGNoZWQgcXVlcmllcy5cbiogQHBhcmFtIHF1ZXJ5Q2xpZW50IC0gVXNlIHRoaXMgdG8gdXNlIGEgY3VzdG9tIGBRdWVyeUNsaWVudGAuIE90aGVyd2lzZSwgdGhlIG9uZSBmcm9tIHRoZSBuZWFyZXN0IGNvbnRleHQgd2lsbFxuKiBiZSB1c2VkLlxuKiBAcmV0dXJucyBXaWxsIGJlIHRoZSBgbnVtYmVyYCBvZiB0aGUgcXVlcmllcyB0aGF0IHlvdXIgYXBwbGljYXRpb24gaXMgY3VycmVudGx5IGxvYWRpbmcgb3IgZmV0Y2hpbmcgaW4gdGhlXG4qIGJhY2tncm91bmQuXG4qIEBleGFtcGxlXG4qIGBgYHRzeFxuKiBpbXBvcnQgeyB1c2VJc0ZldGNoaW5nIH0gZnJvbSAnQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5J1xuKlxuKiBmdW5jdGlvbiBQb3N0c0ZldGNoaW5nSW5kaWNhdG9yKCkge1xuKiAgIC8vIEhvdyBtYW55IHF1ZXJpZXMgbWF0Y2hpbmcgdGhlIHBvc3RzIHByZWZpeCBhcmUgZmV0Y2hpbmc/XG4qICAgY29uc3QgaXNGZXRjaGluZ1Bvc3RzID0gdXNlSXNGZXRjaGluZyh7IHF1ZXJ5S2V5OiBbJ3Bvc3RzJ10gfSlcbipcbiogICByZXR1cm4gaXNGZXRjaGluZ1Bvc3RzID8gPHNwYW4+UmVmcmVzaGluZyBwb3N0cy4uLjwvc3Bhbj4gOiBudWxsXG4qIH1cbiogYGBgXG4qIEBleGFtcGxlXG4qIEEgZ2xvYmFsIGxvYWRpbmcgaW5kaWNhdG9yIGZvciBhbnkgcXVlcnkgZmV0Y2hpbmcgaW4gdGhlIGJhY2tncm91bmQsIG5vdCBqdXN0IHRoZSBvbmVzIG9uIHNjcmVlbjpcbiogYGBgdHN4XG4qIGltcG9ydCB7IHVzZUlzRmV0Y2hpbmcgfSBmcm9tICdAdGFuc3RhY2svcmVhY3QtcXVlcnknXG4qXG4qIGZ1bmN0aW9uIEdsb2JhbExvYWRpbmdJbmRpY2F0b3IoKSB7XG4qICAgY29uc3QgaXNGZXRjaGluZyA9IHVzZUlzRmV0Y2hpbmcoKVxuKlxuKiAgIHJldHVybiBpc0ZldGNoaW5nID8gKFxuKiAgICAgPGRpdj5RdWVyaWVzIGFyZSBmZXRjaGluZyBpbiB0aGUgYmFja2dyb3VuZC4uLjwvZGl2PlxuKiAgICkgOiBudWxsXG4qIH1cbiogYGBgXG4qL1xuZnVuY3Rpb24gdXNlSXNGZXRjaGluZyhmaWx0ZXJzLCBxdWVyeUNsaWVudCkge1xuXHRjb25zdCBjbGllbnQgPSB1c2VRdWVyeUNsaWVudChxdWVyeUNsaWVudCk7XG5cdGNvbnN0IHF1ZXJ5Q2FjaGUgPSBjbGllbnQuZ2V0UXVlcnlDYWNoZSgpO1xuXHRyZXR1cm4gUmVhY3QudXNlU3luY0V4dGVybmFsU3RvcmUoUmVhY3QudXNlQ2FsbGJhY2soKG9uU3RvcmVDaGFuZ2UpID0+IHF1ZXJ5Q2FjaGUuc3Vic2NyaWJlKG5vdGlmeU1hbmFnZXIuYmF0Y2hDYWxscyhvblN0b3JlQ2hhbmdlKSksIFtxdWVyeUNhY2hlXSksICgpID0+IGNsaWVudC5pc0ZldGNoaW5nKGZpbHRlcnMpLCAoKSA9PiBjbGllbnQuaXNGZXRjaGluZyhmaWx0ZXJzKSk7XG59XG5leHBvcnQgeyB1c2VJc0ZldGNoaW5nIH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXVzZUlzRmV0Y2hpbmcuanMubWFwIiwiXCJ1c2UgY2xpZW50XCI7XG5pbXBvcnQgeyB1c2VRdWVyeUNsaWVudCB9IGZyb20gXCIuL1F1ZXJ5Q2xpZW50UHJvdmlkZXIuanNcIjtcbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgbm90aWZ5TWFuYWdlciwgcmVwbGFjZUVxdWFsRGVlcCB9IGZyb20gXCJAdGFuc3RhY2svcXVlcnktY29yZVwiO1xuLy8gc3JjL3VzZU11dGF0aW9uU3RhdGUudHNcbi8qKlxuKiBUaGUgYHVzZUlzTXV0YXRpbmdgIGhvb2sgcmV0dXJucyB0aGUgYG51bWJlcmAgb2YgbXV0YXRpb25zIHRoYXQgeW91ciBhcHBsaWNhdGlvbiBjdXJyZW50bHkgaGFzIGBwZW5kaW5nYFxuKiAodXNlZnVsIGZvciBhcHAtd2lkZSBsb2FkaW5nIGluZGljYXRvcnMpLlxuKiBAcGFyYW0gZmlsdGVycyAtIFRoZSB7QGxpbmsgTXV0YXRpb25GaWx0ZXJzfSB0byBuYXJyb3cgZG93biB0aGUgbWF0Y2hlZCBtdXRhdGlvbnMuXG4qIEBwYXJhbSBxdWVyeUNsaWVudCAtIFVzZSB0aGlzIHRvIHVzZSBhIGN1c3RvbSBgUXVlcnlDbGllbnRgLiBPdGhlcndpc2UsIHRoZSBvbmUgZnJvbSB0aGUgbmVhcmVzdCBjb250ZXh0IHdpbGxcbiogYmUgdXNlZC5cbiogQHJldHVybnMgV2lsbCBiZSB0aGUgYG51bWJlcmAgb2YgdGhlIG11dGF0aW9ucyB0aGF0IHlvdXIgYXBwbGljYXRpb24gY3VycmVudGx5IGhhcyBgcGVuZGluZ2AuXG4qIEBleGFtcGxlXG4qIGBgYHRzeFxuKiBpbXBvcnQgeyB1c2VJc011dGF0aW5nIH0gZnJvbSAnQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5J1xuKlxuKiBmdW5jdGlvbiBQb3N0c011dGF0aW5nSW5kaWNhdG9yKCkge1xuKiAgIC8vIEhvdyBtYW55IG11dGF0aW9ucyBtYXRjaGluZyB0aGUgcG9zdHMgcHJlZml4IGFyZSBpbiBwcm9ncmVzcz9cbiogICBjb25zdCBpc011dGF0aW5nUG9zdHMgPSB1c2VJc011dGF0aW5nKHsgbXV0YXRpb25LZXk6IFsncG9zdHMnXSB9KVxuKlxuKiAgIHJldHVybiBpc011dGF0aW5nUG9zdHMgPyA8c3Bhbj5TYXZpbmcgcG9zdHMuLi48L3NwYW4+IDogbnVsbFxuKiB9XG4qIGBgYFxuKi9cbmZ1bmN0aW9uIHVzZUlzTXV0YXRpbmcoZmlsdGVycywgcXVlcnlDbGllbnQpIHtcblx0Y29uc3QgY2xpZW50ID0gdXNlUXVlcnlDbGllbnQocXVlcnlDbGllbnQpO1xuXHRyZXR1cm4gdXNlTXV0YXRpb25TdGF0ZSh7IGZpbHRlcnM6IHtcblx0XHQuLi5maWx0ZXJzLFxuXHRcdHN0YXR1czogXCJwZW5kaW5nXCJcblx0fSB9LCBjbGllbnQpLmxlbmd0aDtcbn1cbi8qKlxuKiBDcmVhdGVzIHNuYXBzaG90IGdldHRlcnMgdGhhdCBzaGFyZSBlcXVhbCBzZWxlY3RlZCByZXN1bHRzIGFjcm9zcyByZW5kZXJzLlxuKiBBIG5ldyBnZXR0ZXIgaXMgY3JlYXRlZCBvbiBlYWNoIHJlbmRlci4gRWFjaCBnZXR0ZXIgY2FjaGVzIGl0cyBzbmFwc2hvdCB1bnRpbCB0aGUgbWF0Y2hpbmcgbXV0YXRpb25zXG4qIG9yIHRoZWlyIHN0YXRlcyBjaGFuZ2UuXG4qIEByZXR1cm5zIEEgZmFjdG9yeSBmb3Igc25hcHNob3QgZ2V0dGVycyB3aXRoIGEgc2hhcmVkIHJlc3VsdCBjYWNoZS5cbiovXG5mdW5jdGlvbiBjcmVhdGVTbmFwc2hvdEZhY3RvcnkoKSB7XG5cdGxldCBwcmV2aW91c1Jlc3VsdDtcblx0cmV0dXJuIChtdXRhdGlvbkNhY2hlLCBvcHRpb25zKSA9PiB7XG5cdFx0bGV0IGlucHV0cyA9IFtdO1xuXHRcdGxldCBzbmFwc2hvdDtcblx0XHRyZXR1cm4gKCkgPT4ge1xuXHRcdFx0Y29uc3QgbXV0YXRpb25zID0gbXV0YXRpb25DYWNoZS5maW5kQWxsKG9wdGlvbnMuZmlsdGVycyk7XG5cdFx0XHRjb25zdCBuZXh0SW5wdXRzID0gbXV0YXRpb25zLmZsYXRNYXAoKG11dGF0aW9uKSA9PiBbbXV0YXRpb24sIG11dGF0aW9uLnN0YXRlXSk7XG5cdFx0XHRpZiAoIXNuYXBzaG90IHx8IG5leHRJbnB1dHMubGVuZ3RoICE9PSBpbnB1dHMubGVuZ3RoIHx8IG5leHRJbnB1dHMuc29tZSgoaW5wdXQsIGluZGV4KSA9PiAhT2JqZWN0LmlzKGlucHV0LCBpbnB1dHNbaW5kZXhdKSkpIHtcblx0XHRcdFx0aW5wdXRzID0gbmV4dElucHV0cztcblx0XHRcdFx0c25hcHNob3QgPSByZXBsYWNlRXF1YWxEZWVwKHByZXZpb3VzUmVzdWx0LCBtdXRhdGlvbnMubWFwKChtdXRhdGlvbikgPT4gb3B0aW9ucy5zZWxlY3QgPyBvcHRpb25zLnNlbGVjdChtdXRhdGlvbikgOiBtdXRhdGlvbi5zdGF0ZSkpO1xuXHRcdFx0XHRwcmV2aW91c1Jlc3VsdCA9IHNuYXBzaG90O1xuXHRcdFx0fVxuXHRcdFx0cmV0dXJuIHNuYXBzaG90O1xuXHRcdH07XG5cdH07XG59XG4vKipcbiogYHVzZU11dGF0aW9uU3RhdGVgIGlzIGEgaG9vayB0aGF0IGdpdmVzIHlvdSBhY2Nlc3MgdG8gYWxsIG11dGF0aW9ucyBpbiB0aGUgYE11dGF0aW9uQ2FjaGVgLiBZb3UgY2FuIHBhc3NcbiogYGZpbHRlcnNgICh7QGxpbmsgTXV0YXRpb25GaWx0ZXJzfSkgdG8gbmFycm93IGRvd24geW91ciBtdXRhdGlvbnMsIGFuZCBgc2VsZWN0YCB0byB0cmFuc2Zvcm0gdGhlIG11dGF0aW9uXG4qIHN0YXRlLlxuKiBAcGFyYW0gb3B0aW9ucyAtIFRoZSBgZmlsdGVyc2AgdG8gbmFycm93IGRvd24gbWF0Y2hlZCBtdXRhdGlvbnMsIGFuZCBhbiBvcHRpb25hbCBgc2VsZWN0YCB0byB0cmFuc2Zvcm0gdGhlXG4qIG11dGF0aW9uIHN0YXRlLlxuKiBAcGFyYW0gcXVlcnlDbGllbnQgLSBVc2UgdGhpcyB0byB1c2UgYSBjdXN0b20gYFF1ZXJ5Q2xpZW50YC4gT3RoZXJ3aXNlLCB0aGUgb25lIGZyb20gdGhlIG5lYXJlc3QgY29udGV4dCB3aWxsXG4qIGJlIHVzZWQuXG4qIEByZXR1cm5zIFdpbGwgYmUgYW4gQXJyYXkgb2Ygd2hhdGV2ZXIgYHNlbGVjdGAgcmV0dXJucyBmb3IgZWFjaCBtYXRjaGluZyBtdXRhdGlvbi5cbiogQGV4YW1wbGVcbiogR2V0IGFsbCB2YXJpYWJsZXMgb2YgYWxsIHJ1bm5pbmcgbXV0YXRpb25zOlxuKiBgYGB0c3hcbiogaW1wb3J0IHsgdXNlTXV0YXRpb25TdGF0ZSB9IGZyb20gJ0B0YW5zdGFjay9yZWFjdC1xdWVyeSdcbipcbiogZnVuY3Rpb24gUGVuZGluZ1Bvc3RzKCkge1xuKiAgIGNvbnN0IHBlbmRpbmdWYXJpYWJsZXMgPSB1c2VNdXRhdGlvblN0YXRlKHtcbiogICAgIGZpbHRlcnM6IHsgc3RhdHVzOiAncGVuZGluZycgfSxcbiogICAgIHNlbGVjdDogKG11dGF0aW9uKSA9PiBtdXRhdGlvbi5zdGF0ZS52YXJpYWJsZXMsXG4qICAgfSlcbipcbiogICByZXR1cm4gPD57cGVuZGluZ1ZhcmlhYmxlcy5sZW5ndGh9IHBvc3RzIHNhdmluZy4uLjwvPlxuKiB9XG4qIGBgYFxuKiBAZXhhbXBsZVxuKiBHZXQgYWxsIGRhdGEgZm9yIHNwZWNpZmljIG11dGF0aW9ucyB2aWEgdGhlIGBtdXRhdGlvbktleWA6XG4qIGBgYHRzeFxuKiBpbXBvcnQgeyB1c2VNdXRhdGlvbiwgdXNlTXV0YXRpb25TdGF0ZSB9IGZyb20gJ0B0YW5zdGFjay9yZWFjdC1xdWVyeSdcbipcbiogY29uc3QgbXV0YXRpb25LZXkgPSBbJ3Bvc3RzJ11cbipcbiogZnVuY3Rpb24gUG9zdHMoKSB7XG4qICAgLy8gU29tZSBtdXRhdGlvbiB0aGF0IHdlIHdhbnQgdG8gZ2V0IHRoZSBzdGF0ZSBmb3JcbiogICBjb25zdCBtdXRhdGlvbiA9IHVzZU11dGF0aW9uKHtcbiogICAgIG11dGF0aW9uS2V5LFxuKiAgICAgbXV0YXRpb25GbjogY3JlYXRlUG9zdHMsXG4qICAgfSlcbipcbiogICBjb25zdCBzYXZlZFBvc3RzID0gdXNlTXV0YXRpb25TdGF0ZSh7XG4qICAgICAvLyB0aGlzIG11dGF0aW9uIGtleSBuZWVkcyB0byBtYXRjaCB0aGUgbXV0YXRpb24ga2V5IG9mIHRoZSBnaXZlbiBtdXRhdGlvbiAoc2VlIGFib3ZlKVxuKiAgICAgZmlsdGVyczogeyBtdXRhdGlvbktleSwgc3RhdHVzOiAnc3VjY2VzcycgfSxcbiogICAgIHNlbGVjdDogKG11dGF0aW9uKSA9PiBtdXRhdGlvbi5zdGF0ZS5kYXRhLFxuKiAgIH0pXG4qXG4qICAgcmV0dXJuIChcbiogICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gbXV0YXRpb24ubXV0YXRlKFsnTmV3IFBvc3QnXSl9PlxuKiAgICAgICBDcmVhdGUgcG9zdCAoe3NhdmVkUG9zdHMubGVuZ3RofSBzYXZlZCBzbyBmYXIpXG4qICAgICA8L2J1dHRvbj5cbiogICApXG4qIH1cbiogYGBgXG4qIEBleGFtcGxlXG4qIEFjY2VzcyB0aGUgbGF0ZXN0IHN1Y2Nlc3NmdWwgbXV0YXRpb24gZGF0YSB2aWEgdGhlIGBtdXRhdGlvbktleWAuIEVhY2ggaW52b2NhdGlvbiBvZiBgbXV0YXRlYCBhZGRzIGEgbmV3XG4qIGVudHJ5IHRvIHRoZSBtdXRhdGlvbiBjYWNoZSBmb3IgYGdjVGltZWAgbWlsbGlzZWNvbmRzIOKAlCB3aXRoIHRoZSBgc3RhdHVzOiAnc3VjY2VzcydgIGZpbHRlciBiZWxvdywgY2hlY2sgdGhlXG4qIGxhc3QgaXRlbSB0aGF0IGB1c2VNdXRhdGlvblN0YXRlYCByZXR1cm5zIHRvIGdldCB0aGUgbGF0ZXN0IHN1Y2Nlc3NmdWwgaW52b2NhdGlvbjpcbiogYGBgdHN4XG4qIGltcG9ydCB7IHVzZU11dGF0aW9uU3RhdGUgfSBmcm9tICdAdGFuc3RhY2svcmVhY3QtcXVlcnknXG4qXG4qIGZ1bmN0aW9uIExhdGVzdFBvc3QoKSB7XG4qICAgY29uc3Qgc2F2ZWRQb3N0cyA9IHVzZU11dGF0aW9uU3RhdGUoe1xuKiAgICAgZmlsdGVyczogeyBtdXRhdGlvbktleTogWydwb3N0cyddLCBzdGF0dXM6ICdzdWNjZXNzJyB9LFxuKiAgICAgc2VsZWN0OiAobXV0YXRpb24pID0+IG11dGF0aW9uLnN0YXRlLmRhdGEsXG4qICAgfSlcbipcbiogICBjb25zdCBsYXRlc3RTYXZlZFBvc3QgPSBzYXZlZFBvc3RzW3NhdmVkUG9zdHMubGVuZ3RoIC0gMV1cbipcbiogICByZXR1cm4gPD57bGF0ZXN0U2F2ZWRQb3N0ID8gJ1NhdmVkJyA6ICdOb3RoaW5nIHNhdmVkIHlldCd9PC8+XG4qIH1cbiogYGBgXG4qL1xuZnVuY3Rpb24gdXNlTXV0YXRpb25TdGF0ZShvcHRpb25zID0ge30sIHF1ZXJ5Q2xpZW50KSB7XG5cdGNvbnN0IG11dGF0aW9uQ2FjaGUgPSB1c2VRdWVyeUNsaWVudChxdWVyeUNsaWVudCkuZ2V0TXV0YXRpb25DYWNoZSgpO1xuXHRjb25zdCBbY3JlYXRlU25hcHNob3RdID0gUmVhY3QudXNlU3RhdGUoKCkgPT4gY3JlYXRlU25hcHNob3RGYWN0b3J5KCkpO1xuXHRjb25zdCBnZXRTbmFwc2hvdCA9IGNyZWF0ZVNuYXBzaG90KG11dGF0aW9uQ2FjaGUsIG9wdGlvbnMpO1xuXHRyZXR1cm4gUmVhY3QudXNlU3luY0V4dGVybmFsU3RvcmUoUmVhY3QudXNlQ2FsbGJhY2soKG9uU3RvcmVDaGFuZ2UpID0+IG11dGF0aW9uQ2FjaGUuc3Vic2NyaWJlKG5vdGlmeU1hbmFnZXIuYmF0Y2hDYWxscyhvblN0b3JlQ2hhbmdlKSksIFttdXRhdGlvbkNhY2hlXSksIGdldFNuYXBzaG90LCBnZXRTbmFwc2hvdCk7XG59XG5leHBvcnQgeyB1c2VJc011dGF0aW5nLCB1c2VNdXRhdGlvblN0YXRlIH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXVzZU11dGF0aW9uU3RhdGUuanMubWFwIiwiXCJ1c2UgY2xpZW50XCI7XG5pbXBvcnQgeyB1c2VRdWVyeUNsaWVudCB9IGZyb20gXCIuL1F1ZXJ5Q2xpZW50UHJvdmlkZXIuanNcIjtcbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgTXV0YXRpb25PYnNlcnZlciwgbm9vcCwgbm90aWZ5TWFuYWdlciwgc2hvdWxkVGhyb3dFcnJvciB9IGZyb20gXCJAdGFuc3RhY2svcXVlcnktY29yZVwiO1xuLy8gc3JjL3VzZU11dGF0aW9uLnRzXG4vKipcbiogVW5saWtlIHF1ZXJpZXMsIG11dGF0aW9ucyBhcmUgdHlwaWNhbGx5IHVzZWQgdG8gY3JlYXRlL3VwZGF0ZS9kZWxldGUgZGF0YSBvciBwZXJmb3JtIHNlcnZlciBzaWRlLWVmZmVjdHMuXG4qIGB1c2VNdXRhdGlvbmAgaXMgdGhlIGhvb2sgZm9yIHRoYXQuXG4qIEBwYXJhbSBvcHRpb25zIC0gVGhlIHtAbGluayBVc2VNdXRhdGlvbk9wdGlvbnN9IHRvIHVzZSDigJQgZXZlcnl0aGluZyB5b3UgY2FuIHBhc3MgdG8gYHVzZU11dGF0aW9uYC5cbiogQHBhcmFtIHF1ZXJ5Q2xpZW50IC0gVXNlIHRoaXMgdG8gdXNlIGEgY3VzdG9tIGBRdWVyeUNsaWVudGAuIE90aGVyd2lzZSwgdGhlIG9uZSBmcm9tIHRoZSBuZWFyZXN0IGNvbnRleHQgd2lsbFxuKiBiZSB1c2VkLlxuKiBAcmV0dXJucyBgbXV0YXRlYC9gbXV0YXRlQXN5bmNgIGFsc28gYWNjZXB0IHBlci1jYWxsIGBvblN1Y2Nlc3NgL2BvbkVycm9yYC9gb25TZXR0bGVkYCBjYWxsYmFja3MgYXMgYSBzZWNvbmRcbiogYXJndW1lbnQsIHVzZWZ1bCBmb3IgdHJpZ2dlcmluZyBjYWxsLXNpdGUgc2lkZSBlZmZlY3RzIChlLmcuIG5hdmlnYXRpb24pIHdpdGhvdXQgY291cGxpbmcgdGhlbSB0byB0aGUgc2hhcmVkXG4qIG11dGF0aW9uIGRlZmluaXRpb24uIEhvb2stbGV2ZWwgY2FsbGJhY2tzIChwYXNzZWQgdG8gYG9wdGlvbnNgKSBmaXJlIGZvciBldmVyeSBtdXRhdGlvbjsgcGVyLWNhbGwgY2FsbGJhY2tzXG4qIGZpcmUgb25seSBmb3IgdGhlIGxhdGVzdCBjYWxsIHlvdSd2ZSBtYWRlLCBhbmQgb25seSB3aGlsZSB0aGUgY29tcG9uZW50IGlzIHN0aWxsIG1vdW50ZWQg4oCUIHVubW91bnRpbmcgYmVmb3JlXG4qIHRoZSBtdXRhdGlvbiBzZXR0bGVzIHJlbW92ZXMgdGhlIHN1YnNjcmlwdGlvbiBhbmQgcHJldmVudHMgdGhlbSBmcm9tIGZpcmluZy5cbiogQHRocm93cyB7RXJyb3J9IFRoZSBtdXRhdGlvbiBlcnJvciwgd2hlbiBgdGhyb3dPbkVycm9yYCBpcyBgdHJ1ZWAgb3IgcmV0dXJucyBgdHJ1ZWAgZm9yIGl0LCBzbyB0aGF0IGl0IGlzXG4qIHRocm93biB0byB0aGUgbmVhcmVzdCBlcnJvciBib3VuZGFyeS5cbiogQHNlZSB7QGxpbmsgbXV0YXRpb25PcHRpb25zfSB0byBzaGFyZSB0aGVzZSBvcHRpb25zIGFjcm9zcyBtdWx0aXBsZSBgdXNlTXV0YXRpb25gIGNhbGwgc2l0ZXMsIG9yIHRvIGxvb2tcbiogdGhlIG11dGF0aW9uIHVwIGVsc2V3aGVyZSB2aWEgaXRzIGBtdXRhdGlvbktleWAgKGUuZy4gd2l0aCBgdXNlTXV0YXRpb25TdGF0ZWApLlxuKiBAZXhhbXBsZVxuKiBgYGB0c3hcbiogaW1wb3J0IHsgdXNlTXV0YXRpb24sIHVzZVF1ZXJ5Q2xpZW50IH0gZnJvbSAnQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5J1xuKlxuKiBmdW5jdGlvbiBBZGRUb2RvKCkge1xuKiAgIGNvbnN0IHF1ZXJ5Q2xpZW50ID0gdXNlUXVlcnlDbGllbnQoKVxuKlxuKiAgIGNvbnN0IGFkZE11dGF0aW9uID0gdXNlTXV0YXRpb24oe1xuKiAgICAgbXV0YXRpb25GbjogYWRkVG9kbyxcbiogICAgIG9uU3VjY2VzczogKCkgPT4gcXVlcnlDbGllbnQuaW52YWxpZGF0ZVF1ZXJpZXMoeyBxdWVyeUtleTogWyd0b2RvcyddIH0pLFxuKiAgIH0pXG4qXG4qICAgcmV0dXJuIChcbiogICAgIDxidXR0b25cbiogICAgICAgb25DbGljaz17KCkgPT5cbiogICAgICAgICBhZGRNdXRhdGlvbi5tdXRhdGUoJ0l0ZW0nLCB7XG4qICAgICAgICAgICBvbkVycm9yOiAoZXJyb3IpID0+IGNvbnNvbGUuZXJyb3IoJ0ZhaWxlZCB0byBhZGQgaXRlbTonLCBlcnJvciksXG4qICAgICAgICAgfSlcbiogICAgICAgfVxuKiAgICAgPlxuKiAgICAgICBBZGRcbiogICAgIDwvYnV0dG9uPlxuKiAgIClcbiogfVxuKiBgYGBcbiogQGV4YW1wbGVcbiogUmVuZGVyaW5nIHRoZSBtdXRhdGlvbidzIG93biBzdGF0ZSwgcmF0aGVyIHRoYW4ganVzdCBmaXJpbmcgaXQgb2ZmOlxuKiBgYGB0c3hcbiogaW1wb3J0IHsgdXNlTXV0YXRpb24sIHVzZVF1ZXJ5Q2xpZW50IH0gZnJvbSAnQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5J1xuKlxuKiBmdW5jdGlvbiBBZGRUb2RvKCkge1xuKiAgIGNvbnN0IHF1ZXJ5Q2xpZW50ID0gdXNlUXVlcnlDbGllbnQoKVxuKlxuKiAgIGNvbnN0IGFkZE11dGF0aW9uID0gdXNlTXV0YXRpb24oe1xuKiAgICAgbXV0YXRpb25GbjogYWRkVG9kbyxcbiogICAgIG9uU3VjY2VzczogKCkgPT4gcXVlcnlDbGllbnQuaW52YWxpZGF0ZVF1ZXJpZXMoeyBxdWVyeUtleTogWyd0b2RvcyddIH0pLFxuKiAgIH0pXG4qXG4qICAgcmV0dXJuIChcbiogICAgIDxkaXY+XG4qICAgICAgIHthZGRNdXRhdGlvbi5pc1BlbmRpbmcgPyAoXG4qICAgICAgICAgJ0FkZGluZyB0b2RvLi4uJ1xuKiAgICAgICApIDogKFxuKiAgICAgICAgIDw+XG4qICAgICAgICAgICB7YWRkTXV0YXRpb24uaXNFcnJvciA/IChcbiogICAgICAgICAgICAgPGRpdj5BbiBlcnJvciBvY2N1cnJlZDoge2FkZE11dGF0aW9uLmVycm9yLm1lc3NhZ2V9PC9kaXY+XG4qICAgICAgICAgICApIDogbnVsbH1cbiogICAgICAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gYWRkTXV0YXRpb24ubXV0YXRlKCdJdGVtJyl9PkFkZDwvYnV0dG9uPlxuKiAgICAgICAgIDwvPlxuKiAgICAgICApfVxuKiAgICAgPC9kaXY+XG4qICAgKVxuKiB9XG4qIGBgYFxuKiBAZXhhbXBsZVxuKiBPcHRpbWlzdGljIHVwZGF0ZSB2aWEgYG9uTXV0YXRlYCwgcm9sbGluZyBiYWNrIG9uIGBvbkVycm9yYDpcbiogYGBgdHN4XG4qIGltcG9ydCB7IHVzZU11dGF0aW9uLCB1c2VRdWVyeUNsaWVudCB9IGZyb20gJ0B0YW5zdGFjay9yZWFjdC1xdWVyeSdcbipcbiogZnVuY3Rpb24gQWRkVG9kbygpIHtcbiogICBjb25zdCBxdWVyeUNsaWVudCA9IHVzZVF1ZXJ5Q2xpZW50KClcbipcbiogICBjb25zdCBhZGRNdXRhdGlvbiA9IHVzZU11dGF0aW9uKHtcbiogICAgIG11dGF0aW9uRm46IGFkZFRvZG8sXG4qICAgICBvbk11dGF0ZTogYXN5bmMgKG5ld1RvZG8pID0+IHtcbiogICAgICAgYXdhaXQgcXVlcnlDbGllbnQuY2FuY2VsUXVlcmllcyh7IHF1ZXJ5S2V5OiBbJ3RvZG9zJ10gfSlcbiogICAgICAgY29uc3QgcHJldmlvdXNUb2RvcyA9IHF1ZXJ5Q2xpZW50LmdldFF1ZXJ5RGF0YTxBcnJheTxzdHJpbmc+PihbJ3RvZG9zJ10pXG4qXG4qICAgICAgIHF1ZXJ5Q2xpZW50LnNldFF1ZXJ5RGF0YTxBcnJheTxzdHJpbmc+PihbJ3RvZG9zJ10sIChvbGQpID0+IFtcbiogICAgICAgICAuLi4ob2xkID8/IFtdKSxcbiogICAgICAgICBuZXdUb2RvLFxuKiAgICAgICBdKVxuKlxuKiAgICAgICAvLyBQYXNzZWQgdG8gYG9uRXJyb3JgIGFzIGBvbk11dGF0ZVJlc3VsdGAgaWYgdGhlIG11dGF0aW9uIGZhaWxzLlxuKiAgICAgICByZXR1cm4geyBwcmV2aW91c1RvZG9zIH1cbiogICAgIH0sXG4qICAgICBvbkVycm9yOiAoX2VyciwgX25ld1RvZG8sIG9uTXV0YXRlUmVzdWx0KSA9PiB7XG4qICAgICAgIHF1ZXJ5Q2xpZW50LnNldFF1ZXJ5RGF0YShbJ3RvZG9zJ10sIG9uTXV0YXRlUmVzdWx0Py5wcmV2aW91c1RvZG9zKVxuKiAgICAgfSxcbiogICAgIG9uU2V0dGxlZDogKCkgPT4ge1xuKiAgICAgICBxdWVyeUNsaWVudC5pbnZhbGlkYXRlUXVlcmllcyh7IHF1ZXJ5S2V5OiBbJ3RvZG9zJ10gfSlcbiogICAgIH0sXG4qICAgfSlcbipcbiogICByZXR1cm4gKFxuKiAgICAgPGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBhZGRNdXRhdGlvbi5tdXRhdGUoJ0l0ZW0nKX0+QWRkPC9idXR0b24+XG4qICAgKVxuKiB9XG4qIGBgYFxuKiBAZXhhbXBsZVxuKiBDYWxsYmFja3MgcGFzc2VkIHBlciBjYWxsIHRvIGBtdXRhdGVgIG9ubHkgZmlyZSBmb3IgdGhlIGxhc3QgY2FsbCDigJQgYG11dGF0ZUFzeW5jYCBnaXZlcyB5b3UgYVxuKiBwcm9taXNlIHBlciBjYWxsIGluc3RlYWQsIHNvIHlvdSBjYW4gd2FpdCBmb3IgYWxsIG9mIHRoZW0gd2hlbiB0aGV5IHN1Y2NlZWQ6XG4qIGBgYHRzeFxuKiBpbXBvcnQgeyB1c2VNdXRhdGlvbiwgdXNlUXVlcnlDbGllbnQgfSBmcm9tICdAdGFuc3RhY2svcmVhY3QtcXVlcnknXG4qXG4qIGZ1bmN0aW9uIEFkZFRvZG9zKCkge1xuKiAgIGNvbnN0IHF1ZXJ5Q2xpZW50ID0gdXNlUXVlcnlDbGllbnQoKVxuKlxuKiAgIGNvbnN0IGFkZE11dGF0aW9uID0gdXNlTXV0YXRpb24oe1xuKiAgICAgbXV0YXRpb25GbjogYWRkVG9kbyxcbiogICAgIG9uU3VjY2VzczogKCkgPT4gcXVlcnlDbGllbnQuaW52YWxpZGF0ZVF1ZXJpZXMoeyBxdWVyeUtleTogWyd0b2RvcyddIH0pLFxuKiAgIH0pXG4qXG4qICAgYXN5bmMgZnVuY3Rpb24gaGFuZGxlQWRkQWxsKHRvZG9zOiBBcnJheTxzdHJpbmc+KSB7XG4qICAgICB0cnkge1xuKiAgICAgICBhd2FpdCBQcm9taXNlLmFsbCh0b2Rvcy5tYXAoKHRvZG8pID0+IGFkZE11dGF0aW9uLm11dGF0ZUFzeW5jKHRvZG8pKSlcbiogICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4qICAgICAgIGNvbnNvbGUuZXJyb3IoJ0ZhaWxlZCB0byBhZGQgdG9kb3M6JywgZXJyb3IpXG4qICAgICB9XG4qICAgfVxuKlxuKiAgIHJldHVybiAoXG4qICAgICA8YnV0dG9uIG9uQ2xpY2s9eygpID0+IGhhbmRsZUFkZEFsbChbJ1RvZG8gMScsICdUb2RvIDInLCAnVG9kbyAzJ10pfT5cbiogICAgICAgQWRkIGFsbFxuKiAgICAgPC9idXR0b24+XG4qICAgKVxuKiB9XG4qIGBgYFxuKiBAZXhhbXBsZVxuKiBJZiBzb21lIG9mIHRoZSBtdXRhdGlvbnMgYWJvdmUgY2FuIGZhaWwgaW5kZXBlbmRlbnRseSBvZiB0aGUgb3RoZXJzLCBhbmQgeW91IHdhbnQgdG8ga25vdyB3aGljaCBvbmVzXG4qIGRpZCDigJQgcmF0aGVyIHRoYW4gbG9zaW5nIHRoYXQgaW5mb3JtYXRpb24gdGhlIG1vbWVudCB0aGUgZmlyc3Qgb25lIHJlamVjdHMg4oCUIHN3YXAgYFByb21pc2UuYWxsYCBmb3JcbiogYFByb21pc2UuYWxsU2V0dGxlZGA6XG4qIGBgYHRzeFxuKiBpbXBvcnQgeyB1c2VNdXRhdGlvbiwgdXNlUXVlcnlDbGllbnQgfSBmcm9tICdAdGFuc3RhY2svcmVhY3QtcXVlcnknXG4qXG4qIGZ1bmN0aW9uIEFkZFRvZG9zKCkge1xuKiAgIGNvbnN0IHF1ZXJ5Q2xpZW50ID0gdXNlUXVlcnlDbGllbnQoKVxuKlxuKiAgIGNvbnN0IGFkZE11dGF0aW9uID0gdXNlTXV0YXRpb24oe1xuKiAgICAgbXV0YXRpb25GbjogYWRkVG9kbyxcbiogICAgIG9uU3VjY2VzczogKCkgPT4gcXVlcnlDbGllbnQuaW52YWxpZGF0ZVF1ZXJpZXMoeyBxdWVyeUtleTogWyd0b2RvcyddIH0pLFxuKiAgIH0pXG4qXG4qICAgYXN5bmMgZnVuY3Rpb24gaGFuZGxlQWRkQWxsKHRvZG9zOiBBcnJheTxzdHJpbmc+KSB7XG4qICAgICBjb25zdCBhZGRSZXN1bHRzID0gYXdhaXQgUHJvbWlzZS5hbGxTZXR0bGVkKFxuKiAgICAgICB0b2Rvcy5tYXAoKHRvZG8pID0+IGFkZE11dGF0aW9uLm11dGF0ZUFzeW5jKHRvZG8pKSxcbiogICAgIClcbipcbiogICAgIGFkZFJlc3VsdHMuZm9yRWFjaCgoYWRkUmVzdWx0LCBpbmRleCkgPT4ge1xuKiAgICAgICBpZiAoYWRkUmVzdWx0LnN0YXR1cyA9PT0gJ3JlamVjdGVkJykge1xuKiAgICAgICAgIGNvbnNvbGUuZXJyb3IoYEZhaWxlZCB0byBhZGQgXCIke3RvZG9zW2luZGV4XX1cIjpgLCBhZGRSZXN1bHQucmVhc29uKVxuKiAgICAgICB9XG4qICAgICB9KVxuKiAgIH1cbipcbiogICByZXR1cm4gKFxuKiAgICAgPGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBoYW5kbGVBZGRBbGwoWydUb2RvIDEnLCAnVG9kbyAyJywgJ1RvZG8gMyddKX0+XG4qICAgICAgIEFkZCBhbGxcbiogICAgIDwvYnV0dG9uPlxuKiAgIClcbiogfVxuKiBgYGBcbiovXG5mdW5jdGlvbiB1c2VNdXRhdGlvbihvcHRpb25zLCBxdWVyeUNsaWVudCkge1xuXHRjb25zdCBjbGllbnQgPSB1c2VRdWVyeUNsaWVudChxdWVyeUNsaWVudCk7XG5cdGNvbnN0IFtvYnNlcnZlcl0gPSBSZWFjdC51c2VTdGF0ZSgoKSA9PiBuZXcgTXV0YXRpb25PYnNlcnZlcihjbGllbnQsIG9wdGlvbnMpKTtcblx0UmVhY3QudXNlRWZmZWN0KCgpID0+IHtcblx0XHRvYnNlcnZlci5zZXRPcHRpb25zKG9wdGlvbnMpO1xuXHR9LCBbb2JzZXJ2ZXIsIG9wdGlvbnNdKTtcblx0Y29uc3QgcmVzdWx0ID0gUmVhY3QudXNlU3luY0V4dGVybmFsU3RvcmUoUmVhY3QudXNlQ2FsbGJhY2soKG9uU3RvcmVDaGFuZ2UpID0+IG9ic2VydmVyLnN1YnNjcmliZShub3RpZnlNYW5hZ2VyLmJhdGNoQ2FsbHMob25TdG9yZUNoYW5nZSkpLCBbb2JzZXJ2ZXJdKSwgKCkgPT4gb2JzZXJ2ZXIuZ2V0Q3VycmVudFJlc3VsdCgpLCAoKSA9PiBvYnNlcnZlci5nZXRDdXJyZW50UmVzdWx0KCkpO1xuXHRjb25zdCBtdXRhdGUgPSBSZWFjdC51c2VDYWxsYmFjaygoLi4uYXJncykgPT4ge1xuXHRcdG9ic2VydmVyLm11dGF0ZShhcmdzWzBdLCBhcmdzWzFdKS5jYXRjaChub29wKTtcblx0fSwgW29ic2VydmVyXSk7XG5cdGlmIChyZXN1bHQuZXJyb3IgJiYgc2hvdWxkVGhyb3dFcnJvcihvYnNlcnZlci5vcHRpb25zLnRocm93T25FcnJvciwgW3Jlc3VsdC5lcnJvcl0pKSB0aHJvdyByZXN1bHQuZXJyb3I7XG5cdHJldHVybiB7XG5cdFx0Li4ucmVzdWx0LFxuXHRcdG11dGF0ZSxcblx0XHRtdXRhdGVBc3luYzogcmVzdWx0Lm11dGF0ZVxuXHR9O1xufVxuZXhwb3J0IHsgdXNlTXV0YXRpb24gfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9dXNlTXV0YXRpb24uanMubWFwIiwiLy8gc3JjL211dGF0aW9uT3B0aW9ucy50c1xuZnVuY3Rpb24gbXV0YXRpb25PcHRpb25zKG9wdGlvbnMpIHtcblx0cmV0dXJuIG9wdGlvbnM7XG59XG5leHBvcnQgeyBtdXRhdGlvbk9wdGlvbnMgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9bXV0YXRpb25PcHRpb25zLmpzLm1hcCIsIlwidXNlIGNsaWVudFwiO1xuaW1wb3J0IHsgdXNlQmFzZVF1ZXJ5IH0gZnJvbSBcIi4vdXNlQmFzZVF1ZXJ5LmpzXCI7XG5pbXBvcnQgeyBJbmZpbml0ZVF1ZXJ5T2JzZXJ2ZXIgfSBmcm9tIFwiQHRhbnN0YWNrL3F1ZXJ5LWNvcmVcIjtcbi8vIHNyYy91c2VJbmZpbml0ZVF1ZXJ5LnRzXG5mdW5jdGlvbiB1c2VJbmZpbml0ZVF1ZXJ5KG9wdGlvbnMsIHF1ZXJ5Q2xpZW50KSB7XG5cdHJldHVybiB1c2VCYXNlUXVlcnkob3B0aW9ucywgSW5maW5pdGVRdWVyeU9ic2VydmVyLCBxdWVyeUNsaWVudCk7XG59XG5leHBvcnQgeyB1c2VJbmZpbml0ZVF1ZXJ5IH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXVzZUluZmluaXRlUXVlcnkuanMubWFwIiwiaW1wb3J0IHsgUXVlcnlDbGllbnRDb250ZXh0LCBRdWVyeUNsaWVudFByb3ZpZGVyLCB1c2VRdWVyeUNsaWVudCB9IGZyb20gXCIuL1F1ZXJ5Q2xpZW50UHJvdmlkZXIuanNcIjtcbmltcG9ydCB7IEh5ZHJhdGlvbkJvdW5kYXJ5IH0gZnJvbSBcIi4vSHlkcmF0aW9uQm91bmRhcnkuanNcIjtcbmltcG9ydCB7IElzUmVzdG9yaW5nUHJvdmlkZXIsIHVzZUlzUmVzdG9yaW5nIH0gZnJvbSBcIi4vSXNSZXN0b3JpbmdQcm92aWRlci5qc1wiO1xuaW1wb3J0IHsgUXVlcnlFcnJvclJlc2V0Qm91bmRhcnksIHVzZVF1ZXJ5RXJyb3JSZXNldEJvdW5kYXJ5IH0gZnJvbSBcIi4vUXVlcnlFcnJvclJlc2V0Qm91bmRhcnkuanNcIjtcbmltcG9ydCB7IHVzZVF1ZXJpZXMgfSBmcm9tIFwiLi91c2VRdWVyaWVzLmpzXCI7XG5pbXBvcnQgeyB1c2VRdWVyeSB9IGZyb20gXCIuL3VzZVF1ZXJ5LmpzXCI7XG5pbXBvcnQgeyB1c2VTdXNwZW5zZVF1ZXJ5IH0gZnJvbSBcIi4vdXNlU3VzcGVuc2VRdWVyeS5qc1wiO1xuaW1wb3J0IHsgdXNlU3VzcGVuc2VJbmZpbml0ZVF1ZXJ5IH0gZnJvbSBcIi4vdXNlU3VzcGVuc2VJbmZpbml0ZVF1ZXJ5LmpzXCI7XG5pbXBvcnQgeyB1c2VTdXNwZW5zZVF1ZXJpZXMgfSBmcm9tIFwiLi91c2VTdXNwZW5zZVF1ZXJpZXMuanNcIjtcbmltcG9ydCB7IHVzZVByZWZldGNoUXVlcnkgfSBmcm9tIFwiLi91c2VQcmVmZXRjaFF1ZXJ5LmpzXCI7XG5pbXBvcnQgeyB1c2VQcmVmZXRjaEluZmluaXRlUXVlcnkgfSBmcm9tIFwiLi91c2VQcmVmZXRjaEluZmluaXRlUXVlcnkuanNcIjtcbmltcG9ydCB7IHF1ZXJ5T3B0aW9ucyB9IGZyb20gXCIuL3F1ZXJ5T3B0aW9ucy5qc1wiO1xuaW1wb3J0IHsgaW5maW5pdGVRdWVyeU9wdGlvbnMgfSBmcm9tIFwiLi9pbmZpbml0ZVF1ZXJ5T3B0aW9ucy5qc1wiO1xuaW1wb3J0IHsgdXNlSXNGZXRjaGluZyB9IGZyb20gXCIuL3VzZUlzRmV0Y2hpbmcuanNcIjtcbmltcG9ydCB7IHVzZUlzTXV0YXRpbmcsIHVzZU11dGF0aW9uU3RhdGUgfSBmcm9tIFwiLi91c2VNdXRhdGlvblN0YXRlLmpzXCI7XG5pbXBvcnQgeyB1c2VNdXRhdGlvbiB9IGZyb20gXCIuL3VzZU11dGF0aW9uLmpzXCI7XG5pbXBvcnQgeyBtdXRhdGlvbk9wdGlvbnMgfSBmcm9tIFwiLi9tdXRhdGlvbk9wdGlvbnMuanNcIjtcbmltcG9ydCB7IHVzZUluZmluaXRlUXVlcnkgfSBmcm9tIFwiLi91c2VJbmZpbml0ZVF1ZXJ5LmpzXCI7XG5leHBvcnQgKiBmcm9tIFwiQHRhbnN0YWNrL3F1ZXJ5LWNvcmVcIjtcbi8vIHNyYy9pbmRleC50c1xuLyogaXN0YW5idWwgaWdub3JlIGZpbGUgKi9cbmV4cG9ydCB7IEh5ZHJhdGlvbkJvdW5kYXJ5LCBJc1Jlc3RvcmluZ1Byb3ZpZGVyLCBRdWVyeUNsaWVudENvbnRleHQsIFF1ZXJ5Q2xpZW50UHJvdmlkZXIsIFF1ZXJ5RXJyb3JSZXNldEJvdW5kYXJ5LCBpbmZpbml0ZVF1ZXJ5T3B0aW9ucywgbXV0YXRpb25PcHRpb25zLCBxdWVyeU9wdGlvbnMsIHVzZUluZmluaXRlUXVlcnksIHVzZUlzRmV0Y2hpbmcsIHVzZUlzTXV0YXRpbmcsIHVzZUlzUmVzdG9yaW5nLCB1c2VNdXRhdGlvbiwgdXNlTXV0YXRpb25TdGF0ZSwgdXNlUHJlZmV0Y2hJbmZpbml0ZVF1ZXJ5LCB1c2VQcmVmZXRjaFF1ZXJ5LCB1c2VRdWVyaWVzLCB1c2VRdWVyeSwgdXNlUXVlcnlDbGllbnQsIHVzZVF1ZXJ5RXJyb3JSZXNldEJvdW5kYXJ5LCB1c2VTdXNwZW5zZUluZmluaXRlUXVlcnksIHVzZVN1c3BlbnNlUXVlcmllcywgdXNlU3VzcGVuc2VRdWVyeSB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1pbmRleC5qcy5tYXAiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7OztBQU9BLElBQU0scUJBQUEsYUFBMkIsY0FBYyxLQUFLLENBQUM7Ozs7Ozs7OztBQVNyRCxJQUFNLGtCQUFrQixnQkFBZ0I7Q0FDdkMsTUFBTSxTQUFBLGFBQWUsV0FBVyxrQkFBa0I7Q0FDbEQsSUFBSSxhQUFhLE9BQU87Q0FDeEIsSUFBSSxDQUFDLFFBQVEsTUFBTSxJQUFJLE1BQU0sd0RBQXdEO0NBQ3JGLE9BQU87QUFDUjs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQW1CQSxJQUFNLHVCQUF1QixFQUFFLFFBQVEsZUFBZTtDQUNyRCxhQUFNLGdCQUFnQjtFQUNyQixPQUFPLE1BQU07RUFDYixhQUFhO0dBQ1osT0FBTyxRQUFRO0VBQ2hCO0NBQ0QsR0FBRyxDQUFDLE1BQU0sQ0FBQztDQUNYLE9BQXVCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFJLG1CQUFtQixVQUFVO0VBQ3ZELE9BQU87RUFDUDtDQUNELENBQUM7QUFDRjs7QUNsREEsSUFBTSx5QkFBeUI7Q0FDOUIsYUFBYSxVQUFVLFVBQVUsV0FBVyxVQUFVLEtBQUs7Q0FDM0QsZUFBZSxjQUFjLGFBQWEsU0FBUztDQUNuRCxjQUFjLFVBQVUsVUFBVSxZQUFZLFVBQVUsS0FBSztDQUM3RCxnQkFBZ0IsZUFBZSxjQUFjLFVBQVU7QUFDeEQ7Ozs7Ozs7Ozs7OztBQVlBLElBQUksaUJBQWlCLE1BQU07Q0FDMUIsWUFBWTtDQUNaLGtCQUFrQjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0EwQmxCLG1CQUFtQixVQUFVO0VBRTNCLElBQUksS0FBSyxtQkFBbUIsYUFBYSxLQUFLLFdBQVcsUUFBUSxNQUFNLDhHQUE4RztHQUNwTCxVQUFVLEtBQUs7R0FDZjtFQUNELENBQUM7RUFFRixLQUFLLFlBQVk7RUFDMEIsS0FBSyxrQkFBa0I7Q0FDbkU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBdUJBLFdBQVcsVUFBVSxPQUFPO0VBQ2dCLEtBQUssa0JBQWtCO0VBQ2xFLE9BQU8sS0FBSyxVQUFVLFdBQVcsVUFBVSxLQUFLO0NBQ2pEOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FrQkEsYUFBYSxXQUFXO0VBQ3ZCLEtBQUssVUFBVSxhQUFhLFNBQVM7Q0FDdEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBb0JBLFlBQVksVUFBVSxPQUFPO0VBQ2UsS0FBSyxrQkFBa0I7RUFDbEUsT0FBTyxLQUFLLFVBQVUsWUFBWSxVQUFVLEtBQUs7Q0FDbEQ7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQWtCQSxjQUFjLFlBQVk7RUFDekIsS0FBSyxVQUFVLGNBQWMsVUFBVTtDQUN4QztBQUNEOzs7O0FBSUEsSUFBTSxpQkFBaUIsSUFBSSxlQUFlOzs7Ozs7Ozs7QUFTMUMsU0FBUyxxQkFBcUIsVUFBVTtDQUN2QyxXQUFXLFVBQVUsQ0FBQztBQUN2Qjs7Ozs7QUMzSkEsSUFBTSxXQUFXLE9BQU8sV0FBVyxlQUFlLFVBQVU7QUFDNUQsU0FBUyxPQUFPLENBQUM7Ozs7Ozs7O0FBUWpCLFNBQVMsaUJBQWlCLFNBQVMsT0FBTztDQUN6QyxPQUFPLE9BQU8sWUFBWSxhQUFhLFFBQVEsS0FBSyxJQUFJO0FBQ3pEOzs7Ozs7QUFNQSxTQUFTLGVBQWUsT0FBTztDQUM5QixPQUFPLE9BQU8sVUFBVSxZQUFZLFNBQVMsS0FBSyxVQUFVO0FBQzdEOzs7Ozs7OztBQVFBLFNBQVMsZUFBZSxXQUFXLFdBQVc7Q0FDN0MsT0FBTyxLQUFLLElBQUksYUFBYSxhQUFhLEtBQUssS0FBSyxJQUFJLEdBQUcsQ0FBQztBQUM3RDs7Ozs7Ozs7QUFRQSxTQUFTLGtCQUFrQixPQUFPLE9BQU87Q0FDeEMsT0FBTyxPQUFPLFVBQVUsYUFBYSxNQUFNLEtBQUssSUFBSTtBQUNyRDs7Ozs7Ozs7Ozs7Ozs7OztBQWdCQSxTQUFTLFdBQVcsU0FBUyxPQUFPO0NBQ25DLE1BQU0sRUFBRSxPQUFPLE9BQU8sT0FBTyxhQUFhLFdBQVcsVUFBVSxVQUFVO0NBQ3pFLElBQUksVUFBVTtFQUNiLElBQUksT0FDQztPQUFBLE1BQU0sY0FBYyxzQkFBc0IsVUFBVSxNQUFNLE9BQU8sR0FBRyxPQUFPO0VBQUEsT0FDekUsSUFBSSxDQUFDLGdCQUFnQixNQUFNLFVBQVUsUUFBUSxHQUFHLE9BQU87Q0FDL0Q7Q0FDQSxJQUFJLFNBQVMsT0FBTztFQUNuQixNQUFNLFdBQVcsTUFBTSxTQUFTO0VBQ2hDLElBQUksU0FBUyxZQUFZLENBQUMsVUFBVSxPQUFPO0VBQzNDLElBQUksU0FBUyxjQUFjLFVBQVUsT0FBTztDQUM3QztDQUNBLElBQUksT0FBTyxVQUFVLGFBQWEsTUFBTSxRQUFRLE1BQU0sT0FBTyxPQUFPO0NBQ3BFLElBQUksZUFBZSxnQkFBZ0IsTUFBTSxNQUFNLGFBQWEsT0FBTztDQUNuRSxJQUFJLGFBQWEsQ0FBQyxVQUFVLEtBQUssR0FBRyxPQUFPO0NBQzNDLE9BQU87QUFDUjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFpQkEsU0FBUyxjQUFjLFNBQVMsVUFBVTtDQUN6QyxNQUFNLEVBQUUsT0FBTyxRQUFRLFdBQVcsZ0JBQWdCO0NBQ2xELElBQUksYUFBYTtFQUNoQixJQUFJLENBQUMsU0FBUyxRQUFRLGFBQWEsT0FBTztFQUMxQyxJQUFJLE9BQ0M7T0FBQSxRQUFRLFNBQVMsUUFBUSxXQUFXLE1BQU0sUUFBUSxXQUFXLEdBQUcsT0FBTztFQUFBLE9BQ3JFLElBQUksQ0FBQyxnQkFBZ0IsU0FBUyxRQUFRLGFBQWEsV0FBVyxHQUFHLE9BQU87Q0FDaEY7Q0FDQSxJQUFJLFVBQVUsU0FBUyxNQUFNLFdBQVcsUUFBUSxPQUFPO0NBQ3ZELElBQUksYUFBYSxDQUFDLFVBQVUsUUFBUSxHQUFHLE9BQU87Q0FDOUMsT0FBTztBQUNSOzs7Ozs7O0FBT0EsU0FBUyxzQkFBc0IsVUFBVSxTQUFTO0NBQ2pELFFBQVEsU0FBUyxrQkFBa0IsUUFBQSxDQUFTLFFBQVE7QUFDckQ7Ozs7Ozs7Ozs7OztBQVlBLFNBQVMsUUFBUSxVQUFVO0NBQzFCLE9BQU8sS0FBSyxVQUFVLFdBQVcsR0FBRyxRQUFRLGNBQWMsR0FBRyxJQUFJLE9BQU8sS0FBSyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxRQUFRLFFBQVEsUUFBUTtFQUNoSCxPQUFPLE9BQU8sSUFBSTtFQUNsQixPQUFPO0NBQ1IsR0FBRyxDQUFDLENBQUMsSUFBSSxHQUFHO0FBQ2I7QUFDQSxTQUFTLGdCQUFnQixHQUFHLEdBQUc7Q0FDOUIsSUFBSSxNQUFNLEdBQUcsT0FBTztDQUNwQixJQUFJLE9BQU8sTUFBTSxPQUFPLEdBQUcsT0FBTztDQUNsQyxJQUFJLEtBQUssS0FBSyxPQUFPLE1BQU0sWUFBWSxPQUFPLE1BQU0sVUFBVTtFQUM3RCxJQUFJLE1BQU0sUUFBUSxDQUFDLEtBQUssTUFBTSxRQUFRLENBQUMsR0FBRztHQUN6QyxJQUFJLEVBQUUsU0FBUyxFQUFFLFFBQVEsT0FBTztHQUNoQyxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksRUFBRSxRQUFRLEtBQUssSUFBSSxDQUFDLGdCQUFnQixFQUFFLElBQUksRUFBRSxFQUFFLEdBQUcsT0FBTztHQUM1RSxPQUFPO0VBQ1I7RUFDQSxNQUFNLFFBQVEsT0FBTyxLQUFLLENBQUM7RUFDM0IsS0FBSyxNQUFNLE9BQU8sT0FBTyxJQUFJLENBQUMsZ0JBQWdCLEVBQUUsTUFBTSxFQUFFLElBQUksR0FBRyxPQUFPO0VBQ3RFLE9BQU87Q0FDUjtDQUNBLE9BQU87QUFDUjtBQUNBLElBQU0sU0FBUyxPQUFPLFVBQVU7QUFDaEMsU0FBUyxpQkFBaUIsR0FBRyxHQUFHLFFBQVEsR0FBRztDQUMxQyxJQUFJLE1BQU0sR0FBRyxPQUFPO0NBQ3BCLElBQUksUUFBUSxLQUFLLE9BQU87Q0FDeEIsTUFBTSxRQUFRLGFBQWEsQ0FBQyxLQUFLLGFBQWEsQ0FBQztDQUMvQyxJQUFJLENBQUMsU0FBUyxFQUFFLGNBQWMsQ0FBQyxLQUFLLGNBQWMsQ0FBQyxJQUFJLE9BQU87Q0FDOUQsTUFBTSxTQUFTLFFBQVEsSUFBSSxPQUFPLEtBQUssQ0FBQyxFQUFBLENBQUc7Q0FDM0MsTUFBTSxTQUFTLFFBQVEsSUFBSSxPQUFPLEtBQUssQ0FBQztDQUN4QyxNQUFNLFFBQVEsT0FBTztDQUNyQixNQUFNLE9BQU8sUUFBUSxJQUFJLE1BQU0sS0FBSyxJQUFJLENBQUM7Q0FDekMsSUFBSSxhQUFhO0NBQ2pCLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxPQUFPLEtBQUs7RUFDL0IsTUFBTSxNQUFNLFFBQVEsSUFBSSxPQUFPO0VBQy9CLE1BQU0sUUFBUSxFQUFFO0VBQ2hCLE1BQU0sUUFBUSxFQUFFO0VBQ2hCLElBQUksVUFBVSxPQUFPO0dBQ3BCLEtBQUssT0FBTztHQUNaLElBQUksUUFBUSxJQUFJLFFBQVEsT0FBTyxLQUFLLEdBQUcsR0FBRyxHQUFHO0dBQzdDO0VBQ0Q7RUFDQSxJQUFJLFVBQVUsUUFBUSxVQUFVLFFBQVEsT0FBTyxVQUFVLFlBQVksT0FBTyxVQUFVLFVBQVU7R0FDL0YsS0FBSyxPQUFPO0dBQ1o7RUFDRDtFQUNBLE1BQU0sSUFBSSxpQkFBaUIsT0FBTyxPQUFPLFFBQVEsQ0FBQztFQUNsRCxLQUFLLE9BQU87RUFDWixJQUFJLE1BQU0sT0FBTztDQUNsQjtDQUNBLE9BQU8sVUFBVSxTQUFTLGVBQWUsUUFBUSxJQUFJO0FBQ3REOzs7Ozs7O0FBT0EsU0FBUyxvQkFBb0IsR0FBRyxHQUFHO0NBQ2xDLElBQUksQ0FBQyxLQUFLLE9BQU8sS0FBSyxDQUFDLENBQUMsQ0FBQyxXQUFXLE9BQU8sS0FBSyxDQUFDLENBQUMsQ0FBQyxRQUFRLE9BQU87Q0FDbEUsS0FBSyxNQUFNLE9BQU8sT0FBTyxLQUFLLENBQUMsR0FBRyxJQUFJLENBQUMsT0FBTyxLQUFLLEdBQUcsR0FBRyxLQUFLLEVBQUUsU0FBUyxFQUFFLE1BQU0sT0FBTztDQUN4RixPQUFPO0FBQ1I7Ozs7OztBQU1BLFNBQVMsYUFBYSxPQUFPO0NBQzVCLE9BQU8sTUFBTSxRQUFRLEtBQUssS0FBSyxNQUFNLFdBQVcsT0FBTyxLQUFLLEtBQUssQ0FBQyxDQUFDO0FBQ3BFOzs7Ozs7O0FBT0EsU0FBUyxjQUFjLEdBQUc7Q0FDekIsSUFBSSxDQUFDLG1CQUFtQixDQUFDLEdBQUcsT0FBTztDQUNuQyxNQUFNLGtCQUFrQixPQUFPLGVBQWUsQ0FBQztDQUMvQyxNQUFNLE9BQU8saUJBQWlCO0NBQzlCLElBQUksU0FBUyxLQUFLLEdBQUcsT0FBTztDQUM1QixJQUFJLE9BQU8sU0FBUyxZQUFZLE9BQU87Q0FDdkMsTUFBTSxPQUFPLEtBQUs7Q0FDbEIsSUFBSSxDQUFDLG1CQUFtQixJQUFJLEdBQUcsT0FBTztDQUN0QyxJQUFJLENBQUMsS0FBSyxlQUFlLGVBQWUsR0FBRyxPQUFPO0NBQ2xELElBQUksb0JBQW9CLE9BQU8sV0FBVyxPQUFPO0NBQ2pELE9BQU87QUFDUjs7Ozs7O0FBTUEsU0FBUyxtQkFBbUIsR0FBRztDQUM5QixPQUFPLE9BQU8sVUFBVSxTQUFTLEtBQUssQ0FBQyxNQUFNO0FBQzlDOzs7Ozs7QUFNQSxTQUFTLE1BQU0sU0FBUztDQUN2QixPQUFPLElBQUksU0FBUyxZQUFZO0VBQy9CLGVBQWUsV0FBVyxTQUFTLE9BQU87Q0FDM0MsQ0FBQztBQUNGOzs7Ozs7Ozs7OztBQVdBLFNBQVMsWUFBWSxVQUFVLE1BQU0sU0FBUztDQUM3QyxJQUFJLE9BQU8sUUFBUSxzQkFBc0IsWUFBWSxPQUFPLFFBQVEsa0JBQWtCLFVBQVUsSUFBSTtNQUMvRixJQUFJLFFBQVEsc0JBQXNCLE9BQ0ssSUFBSTtFQUM5QyxPQUFPLGlCQUFpQixVQUFVLElBQUk7Q0FDdkMsU0FBUyxPQUFPO0VBQ2YsUUFBUSxNQUFNLDBKQUEwSixRQUFRLFVBQVUsS0FBSyxPQUFPO0VBQ3RNLE1BQU07Q0FDUDtDQUdELE9BQU87QUFDUjs7Ozs7Ozs7Ozs7Ozs7OztBQWdCQSxTQUFTLGlCQUFpQixjQUFjO0NBQ3ZDLE9BQU87QUFDUjs7Ozs7Ozs7O0FBU0EsU0FBUyxTQUFTLE9BQU8sTUFBTSxNQUFNLEdBQUc7Q0FDdkMsTUFBTSxXQUFXLENBQUMsR0FBRyxPQUFPLElBQUk7Q0FDaEMsT0FBTyxPQUFPLFNBQVMsU0FBUyxNQUFNLFNBQVMsTUFBTSxDQUFDLEdBQUcsSUFBSTtBQUM5RDs7Ozs7Ozs7O0FBU0EsU0FBUyxXQUFXLE9BQU8sTUFBTSxNQUFNLEdBQUc7Q0FDekMsTUFBTSxXQUFXLENBQUMsTUFBTSxHQUFHLEtBQUs7Q0FDaEMsT0FBTyxPQUFPLFNBQVMsU0FBUyxNQUFNLFNBQVMsTUFBTSxHQUFHLEdBQUcsSUFBSTtBQUNoRTs7Ozs7Ozs7Ozs7OztBQWFBLElBQU0sWUFBWSxPQUFPOzs7Ozs7Ozs7QUFTekIsU0FBUyxjQUFjLFNBQVMsY0FBYztDQUU1QyxJQUFJLFFBQVEsWUFBWSxXQUFXLFFBQVEsTUFBTSx5R0FBeUcsUUFBUSxVQUFVLEVBQUU7Q0FFL0ssSUFBSSxDQUFDLFFBQVEsV0FBVyxjQUFjLGdCQUFnQixhQUFhLGFBQWE7Q0FDaEYsSUFBSSxDQUFDLFFBQVEsV0FBVyxRQUFRLFlBQVksV0FBVyxhQUFhLFFBQVEsdUJBQXVCLElBQUksTUFBTSxxQkFBcUIsUUFBUSxVQUFVLEVBQUUsQ0FBQztDQUN2SixPQUFPLFFBQVE7QUFDaEI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFtQkEsU0FBUyxpQkFBaUIsY0FBYyxRQUFRO0NBQy9DLElBQUksT0FBTyxpQkFBaUIsWUFBWSxPQUFPLGFBQWEsR0FBRyxNQUFNO0NBQ3JFLE9BQU8sQ0FBQyxDQUFDO0FBQ1Y7QUFDQSxJQUFNLGNBQWMsT0FBTzs7Ozs7Ozs7Ozs7QUFXM0IsU0FBUyxzQkFBc0IsUUFBUSxXQUFXLGFBQWEsZ0JBQWdCO0NBQzlFLElBQUksV0FBVztDQUNmLElBQUk7Q0FDSixPQUFPLGlCQUFpQixRQUFRO0dBQzlCLGNBQWMsRUFBRSxPQUFPLGVBQWU7RUFDdkMsUUFBUTtHQUNQLFlBQVk7R0FDWixXQUFXO0lBQ1YsV0FBVyxVQUFVO0lBQ3JCLElBQUksVUFBVSxPQUFPO0lBQ3JCLFdBQVc7SUFDWCxJQUFJLE9BQU8sU0FBUyxZQUFZO1NBQzNCLE9BQU8saUJBQWlCLFNBQVMsYUFBYSxFQUFFLE1BQU0sS0FBSyxDQUFDO0lBQ2pFLE9BQU87R0FDUjtFQUNEO0NBQ0QsQ0FBQztDQUNELE9BQU87QUFDUjs7QUN0WEEsSUFBSSxtQkFBbUJBOzs7OztBQUt2QixJQUFNQyxtQkFBaUIsV0FBVzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFpQmxDLElBQU0scUJBQXFCO0NBQzFCLFVBQUE7Ozs7OztDQU1BLFlBQVksZUFBZTtFQUMxQixhQUFhO0NBQ2Q7QUFDRDs7Ozs7OztBQzVCQSxJQUFJLGVBQWUsTUFBTTtDQUN4QixjQUFjO0VBQ2IsS0FBSyw0QkFBNEIsSUFBSSxJQUFJO0VBQ3pDLEtBQUssWUFBWSxLQUFLLFVBQVUsS0FBSyxJQUFJO0NBQzFDOzs7Ozs7Ozs7Ozs7Ozs7O0NBZ0JBLFVBQVUsVUFBVTtFQUNuQixLQUFLLFVBQVUsSUFBSSxRQUFRO0VBQzNCLEtBQUssWUFBWTtFQUNqQixhQUFhO0dBQ1osS0FBSyxVQUFVLE9BQU8sUUFBUTtHQUM5QixLQUFLLGNBQWM7RUFDcEI7Q0FDRDs7Ozs7Q0FLQSxlQUFlO0VBQ2QsT0FBTyxLQUFLLFVBQVUsT0FBTztDQUM5Qjs7Ozs7Q0FLQSxjQUFjLENBQUM7Ozs7O0NBS2YsZ0JBQWdCLENBQUM7QUFDbEI7Ozs7Ozs7QUM1Q0EsSUFBSSxlQUFlLGNBQWMsYUFBYTtDQUM3QztDQUNBO0NBQ0E7Q0FDQSxjQUFjO0VBQ2IsTUFBTTtFQUNOLEtBQUssVUFBVSxZQUFZO0dBQzFCLElBQUksT0FBTyxXQUFXLGVBQWUsT0FBTyxrQkFBa0I7SUFDN0QsTUFBTSxpQkFBaUIsUUFBUTtJQUMvQixPQUFPLGlCQUFpQixvQkFBb0IsVUFBVSxLQUFLO0lBQzNELGFBQWE7S0FDWixPQUFPLG9CQUFvQixvQkFBb0IsUUFBUTtJQUN4RDtHQUNEO0VBQ0Q7Q0FDRDtDQUNBLGNBQWM7RUFDYixJQUFJLENBQUMsS0FBSyxVQUFVLEtBQUssaUJBQWlCLEtBQUssTUFBTTtDQUN0RDtDQUNBLGdCQUFnQjtFQUNmLElBQUksQ0FBQyxLQUFLLGFBQWEsR0FBRztHQUN6QixLQUFLLFdBQVc7R0FDaEIsS0FBSyxXQUFXLEtBQUs7RUFDdEI7Q0FDRDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBMkJBLGlCQUFpQixPQUFPO0VBQ3ZCLEtBQUssU0FBUztFQUNkLEtBQUssV0FBVztFQUNoQixLQUFLLFdBQVcsT0FBTyxZQUFZO0dBQ2xDLElBQUksT0FBTyxZQUFZLFdBQVcsS0FBSyxXQUFXLE9BQU87UUFDcEQsS0FBSyxRQUFRO0VBQ25CLENBQUM7Q0FDRjs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQW1CQSxXQUFXLFNBQVM7RUFDbkIsSUFBSSxLQUFLLGFBQWEsU0FBUztHQUM5QixLQUFLLFdBQVc7R0FDaEIsS0FBSyxRQUFRO0VBQ2Q7Q0FDRDs7OztDQUlBLFVBQVU7RUFDVCxNQUFNLFlBQVksS0FBSyxVQUFVO0VBQ2pDLEtBQUssVUFBVSxTQUFTLGFBQWE7R0FDcEMsU0FBUyxTQUFTO0VBQ25CLENBQUM7Q0FDRjs7Ozs7Q0FLQSxZQUFZO0VBQ1gsSUFBSSxPQUFPLEtBQUssYUFBYSxXQUFXLE9BQU8sS0FBSztFQUNwRCxPQUFPLFdBQVcsVUFBVSxvQkFBb0I7Q0FDakQ7QUFDRDs7OztBQUlBLElBQU0sZUFBZSxJQUFJLGFBQWE7Ozs7Ozs7OztBQ3RHdEMsU0FBUyxlQUFlLFNBQVM7Q0FDaEMsSUFBSTtDQUNKLFFBQVEsTUFBTSxXQUFXO0VBQ3hCLE9BQU87RUFDUCxPQUFPO0NBQ1IsR0FBRyxJQUFJLENBQUMsRUFBRSxRQUFRLElBQUk7Q0FDdEIsSUFBSSxTQUFTLEtBQUssR0FBRyxPQUFPLEVBQUUsS0FBSztBQUNwQzs7Ozs7O0FBTUEsU0FBUyxrQkFBa0IsVUFBVTtDQUNwQyxPQUFPO0VBQ04sYUFBYSxTQUFTLFFBQVE7RUFDOUIsT0FBTyxTQUFTO0VBQ2hCLEdBQUcsU0FBUyxRQUFRLFNBQVMsRUFBRSxPQUFPLFNBQVMsUUFBUSxNQUFNO0VBQzdELEdBQUcsU0FBUyxRQUFRLEVBQUUsTUFBTSxTQUFTLEtBQUs7Q0FDM0M7QUFDRDs7Ozs7Ozs7Ozs7QUFXQSxTQUFTLGlCQUFpQixPQUFPLGVBQWUsb0JBQW9CO0NBQ25FLE1BQU0sVUFBVSxNQUFNLFNBQVMsS0FBSyxhQUFhLENBQUMsQ0FBQyxPQUFPLFVBQVU7RUFDbkUsSUFBSSxxQkFBcUIsS0FBSyxNQUFNLE9BQU8sT0FBTyxRQUFRLE9BQU8sS0FBSztFQUMzQixRQUFRLE1BQU0sK0RBQStELE1BQU0sVUFBVSxLQUFLLE1BQU0sa0RBQWtEO0VBQ3JNLE9BQU8sUUFBUSx1QkFBdUIsSUFBSSxNQUFNLFVBQVUsQ0FBQztDQUM1RCxDQUFDO0NBQ0QsU0FBUyxNQUFNLElBQUk7Q0FDbkIsT0FBTztBQUNSOzs7Ozs7Ozs7Ozs7QUFZQSxTQUFTLGVBQWUsT0FBTyxlQUFlLG9CQUFvQjtDQUNqRSxPQUFPO0VBQ04sY0FBYyxLQUFLLElBQUk7RUFDdkIsT0FBTztHQUNOLEdBQUcsTUFBTTtHQUNULEdBQUcsTUFBTSxNQUFNLFNBQVMsS0FBSyxLQUFLLEVBQUUsTUFBTSxnQkFBZ0IsY0FBYyxNQUFNLE1BQU0sSUFBSSxJQUFJLE1BQU0sTUFBTSxLQUFLO0VBQzlHO0VBQ0EsVUFBVSxNQUFNO0VBQ2hCLFdBQVcsTUFBTTtFQUNqQixHQUFHLE1BQU0sTUFBTSxXQUFXLGFBQWEsRUFBRSxTQUFTLGlCQUFpQixPQUFPLGVBQWUsa0JBQWtCLEVBQUU7RUFDN0csR0FBRyxNQUFNLFFBQVEsRUFBRSxNQUFNLE1BQU0sS0FBSztFQUNwQyxHQUFHLE1BQU0sYUFBYSxFQUFFLFdBQVcsTUFBTSxVQUFVO0NBQ3BEO0FBQ0Q7Ozs7Ozs7QUFPQSxTQUFTLCtCQUErQixVQUFVO0NBQ2pELE9BQU8sU0FBUyxNQUFNO0FBQ3ZCOzs7Ozs7O0FBT0EsU0FBUyw0QkFBNEIsT0FBTztDQUMzQyxPQUFPLE1BQU0sTUFBTSxXQUFXO0FBQy9COzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQXVCQSxTQUFTLFVBQVUsUUFBUSxVQUFVLENBQUMsR0FBRztDQUN4QyxNQUFNLGlCQUFpQixRQUFRLDJCQUEyQixPQUFPLGtCQUFrQixDQUFDLENBQUMsV0FBVywyQkFBMkI7Q0FDM0gsTUFBTSxZQUFZLE9BQU8saUJBQWlCLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxTQUFTLGFBQWEsZUFBZSxRQUFRLElBQUksQ0FBQyxrQkFBa0IsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDO0NBQ3hJLE1BQU0sY0FBYyxRQUFRLHdCQUF3QixPQUFPLGtCQUFrQixDQUFDLENBQUMsV0FBVyx3QkFBd0I7Q0FDbEgsTUFBTSxxQkFBcUIsUUFBUSxzQkFBc0IsT0FBTyxrQkFBa0IsQ0FBQyxDQUFDLFdBQVc7Q0FDL0YsTUFBTSxnQkFBZ0IsUUFBUSxpQkFBaUIsT0FBTyxrQkFBa0IsQ0FBQyxDQUFDLFdBQVc7Q0FDckYsT0FBTztFQUNOO0VBQ0EsU0FBUyxPQUFPLGNBQWMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLFNBQVMsVUFBVSxZQUFZLEtBQUssSUFBSSxDQUFDLGVBQWUsT0FBTyxlQUFlLGtCQUFrQixDQUFDLElBQUksQ0FBQyxDQUFDO0NBQ2pKO0FBQ0Q7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFzQkEsU0FBUyxRQUFRLFFBQVEsaUJBQWlCLFNBQVM7Q0FDbEQsTUFBTSxnQkFBZ0IsT0FBTyxpQkFBaUI7Q0FDOUMsTUFBTSxhQUFhLE9BQU8sY0FBYztDQUN4QyxNQUFNLGtCQUFrQixTQUFTLGdCQUFnQixtQkFBbUIsT0FBTyxrQkFBa0IsQ0FBQyxDQUFDLFNBQVM7Q0FDeEcsZ0JBQWdCLFdBQVcsU0FBUyxFQUFFLE9BQU8sR0FBRyxzQkFBc0I7RUFDckUsY0FBYyxNQUFNLFFBQVE7R0FDM0IsR0FBRyxPQUFPLGtCQUFrQixDQUFDLENBQUMsU0FBUztHQUN2QyxHQUFHLFNBQVMsZ0JBQWdCO0dBQzVCLEdBQUc7RUFDSixHQUFHLEtBQUs7Q0FDVCxDQUFDO0NBQ0QsZ0JBQWdCLFNBQVMsU0FBUyxFQUFFLFVBQVUsT0FBTyxXQUFXLE1BQU0sU0FBUyxjQUFjLGdCQUFnQjtFQUM1RyxNQUFNLFdBQVcsVUFBVSxlQUFlLE9BQU8sSUFBSSxLQUFLO0VBQzFELE1BQU0sVUFBVSxNQUFNLFNBQVMsS0FBSyxJQUFJLFVBQVUsT0FBTyxNQUFNO0VBQy9ELE1BQU0sT0FBTyxZQUFZLEtBQUssSUFBSSxVQUFVLGtCQUFrQixnQkFBZ0IsT0FBTyxJQUFJO0VBQ3pGLElBQUksUUFBUSxXQUFXLElBQUksU0FBUztFQUNwQyxNQUFNLHlCQUF5QixPQUFPLE1BQU0sV0FBVztFQUN2RCxNQUFNLDBCQUEwQixPQUFPLE1BQU0sZ0JBQWdCO0VBQzdELElBQUksT0FBTztHQUNWLE1BQU0sbUJBQW1CLFlBQVksZUFBZSxNQUFNLE1BQU07R0FDaEUsSUFBSSxNQUFNLGdCQUFnQixNQUFNLE1BQU0saUJBQWlCLGtCQUFrQjtJQUN4RSxNQUFNLEVBQUUsYUFBYSxVQUFVLEdBQUcsb0JBQW9CO0lBQ3RELE1BQU0sU0FBUztLQUNkLEdBQUc7S0FDSDtLQUNBLEdBQUcsTUFBTSxXQUFXLGFBQWEsU0FBUyxLQUFLLEtBQUs7TUFDbkQsUUFBUTtNQUNSLGVBQWU7TUFDZixHQUFHLENBQUMsMkJBQTJCLEVBQUUsYUFBYSxPQUFPO0tBQ3REO0lBQ0QsQ0FBQztHQUNGO0VBQ0QsT0FBTyxRQUFRLFdBQVcsTUFBTSxRQUFRO0dBQ3ZDLEdBQUcsT0FBTyxrQkFBa0IsQ0FBQyxDQUFDLFNBQVM7R0FDdkMsR0FBRyxTQUFTLGdCQUFnQjtHQUM1QjtHQUNBO0dBQ0E7R0FDQSxPQUFPO0VBQ1IsR0FBRztHQUNGLEdBQUc7R0FDSDtHQUNBLGFBQWE7R0FDYixRQUFRLE1BQU0sV0FBVyxhQUFhLFNBQVMsS0FBSyxJQUFJLFlBQVksTUFBTTtHQUMxRSxHQUFHLE1BQU0sV0FBVyxhQUFhLFNBQVMsS0FBSyxLQUFLLEVBQUUsZUFBZSxhQUFhO0VBQ25GLENBQUM7RUFDRCxJQUFJLFdBQVcsQ0FBQyxZQUFZLENBQUMsMEJBQTBCLENBQUMsMkJBQTJCLGVBQWUsTUFBTSxNQUFNLGVBQWUsTUFBTSxNQUFNLEtBQUssR0FBRyxFQUFFLGdCQUFnQixRQUFRLFFBQVEsT0FBTyxDQUFDLENBQUMsS0FBSyxlQUFlLEVBQUUsQ0FBQyxDQUFDLENBQUMsTUFBTSxJQUFJO0NBQ2hPLENBQUM7QUFDRjs7Ozs7O0FDNUxBLElBQU0sbUJBQW1COzs7Ozs7QUFNekIsU0FBUyxzQkFBc0I7Q0FDOUIsSUFBSSxRQUFRLENBQUM7Q0FDYixJQUFJLGVBQWU7Q0FDbkIsSUFBSSxZQUFZLGFBQWE7RUFDNUIsU0FBUztDQUNWO0NBQ0EsSUFBSSxpQkFBaUIsYUFBYTtFQUNqQyxTQUFTO0NBQ1Y7Q0FDQSxJQUFJLGFBQWE7Q0FDakIsTUFBTSxZQUFZLGFBQWE7RUFDOUIsSUFBSSxjQUFjLE1BQU0sS0FBSyxRQUFRO09BQ2hDLGlCQUFpQjtHQUNyQixTQUFTLFFBQVE7RUFDbEIsQ0FBQztDQUNGO0NBQ0EsTUFBTSxjQUFjO0VBQ25CLE1BQU0sZ0JBQWdCO0VBQ3RCLFFBQVEsQ0FBQztFQUNULElBQUksY0FBYyxRQUFRLGlCQUFpQjtHQUMxQyxvQkFBb0I7SUFDbkIsY0FBYyxTQUFTLGFBQWE7S0FDbkMsU0FBUyxRQUFRO0lBQ2xCLENBQUM7R0FDRixDQUFDO0VBQ0YsQ0FBQztDQUNGO0NBQ0EsT0FBTzs7Ozs7Ozs7O0VBU04sUUFBUSxhQUFhO0dBQ3BCLElBQUk7R0FDSjtHQUNBLElBQUk7SUFDSCxTQUFTLFNBQVM7R0FDbkIsVUFBVTtJQUNUO0lBQ0EsSUFBSSxDQUFDLGNBQWMsTUFBTTtHQUMxQjtHQUNBLE9BQU87RUFDUjs7Ozs7O0VBTUEsYUFBYSxhQUFhO0dBQ3pCLFFBQVEsR0FBRyxTQUFTO0lBQ25CLGVBQWU7S0FDZCxTQUFTLEdBQUcsSUFBSTtJQUNqQixDQUFDO0dBQ0Y7RUFDRDs7Ozs7RUFLQTs7Ozs7O0VBTUEsb0JBQW9CLE9BQU87R0FDMUIsV0FBVztFQUNaOzs7Ozs7Ozs7Ozs7OztFQWNBLHlCQUF5QixPQUFPO0dBQy9CLGdCQUFnQjtFQUNqQjs7Ozs7Ozs7Ozs7Ozs7Ozs7OztFQW1CQSxlQUFlLE9BQU87R0FDckIsYUFBYTtFQUNkO0NBQ0Q7QUFDRDs7OztBQUlBLElBQU0sZ0JBQWdCLG9CQUFvQjs7Ozs7Ozs7Ozs7QUNuSDFDLElBQUksZ0JBQWdCLGNBQWMsYUFBYTtDQUM5QyxVQUFVO0NBQ1Y7Q0FDQTtDQUNBLGNBQWM7RUFDYixNQUFNO0VBQ04sS0FBSyxVQUFVLGFBQWE7R0FDM0IsSUFBSSxPQUFPLFdBQVcsZUFBZSxPQUFPLGtCQUFrQjtJQUM3RCxNQUFNLHVCQUF1QixTQUFTLElBQUk7SUFDMUMsTUFBTSx3QkFBd0IsU0FBUyxLQUFLO0lBQzVDLE9BQU8saUJBQWlCLFVBQVUsZ0JBQWdCLEtBQUs7SUFDdkQsT0FBTyxpQkFBaUIsV0FBVyxpQkFBaUIsS0FBSztJQUN6RCxhQUFhO0tBQ1osT0FBTyxvQkFBb0IsVUFBVSxjQUFjO0tBQ25ELE9BQU8sb0JBQW9CLFdBQVcsZUFBZTtJQUN0RDtHQUNEO0VBQ0Q7Q0FDRDtDQUNBLGNBQWM7RUFDYixJQUFJLENBQUMsS0FBSyxVQUFVLEtBQUssaUJBQWlCLEtBQUssTUFBTTtDQUN0RDtDQUNBLGdCQUFnQjtFQUNmLElBQUksQ0FBQyxLQUFLLGFBQWEsR0FBRztHQUN6QixLQUFLLFdBQVc7R0FDaEIsS0FBSyxXQUFXLEtBQUs7RUFDdEI7Q0FDRDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FvQkEsaUJBQWlCLE9BQU87RUFDdkIsS0FBSyxTQUFTO0VBQ2QsS0FBSyxXQUFXO0VBQ2hCLEtBQUssV0FBVyxNQUFNLEtBQUssVUFBVSxLQUFLLElBQUksQ0FBQztDQUNoRDs7Ozs7Ozs7Ozs7Ozs7O0NBZUEsVUFBVSxRQUFRO0VBQ2pCLElBQUksS0FBSyxZQUFZLFFBQVE7R0FDNUIsS0FBSyxVQUFVO0dBQ2YsS0FBSyxVQUFVLFNBQVMsYUFBYTtJQUNwQyxTQUFTLE1BQU07R0FDaEIsQ0FBQztFQUNGO0NBQ0Q7Ozs7O0NBS0EsV0FBVztFQUNWLE9BQU8sS0FBSztDQUNiO0FBQ0Q7Ozs7QUFJQSxJQUFNLGdCQUFnQixJQUFJLGNBQWM7Ozs7Ozs7QUN0RnhDLFNBQVMsa0JBQWtCLGNBQWM7Q0FDeEMsT0FBTyxLQUFLLElBQUksTUFBTSxLQUFLLGNBQWMsR0FBRztBQUM3Qzs7Ozs7O0FBTUEsU0FBUyxTQUFTLGFBQWE7Q0FDOUIsUUFBUSxlQUFlLGNBQWMsV0FBVyxjQUFjLFNBQVMsSUFBSTtBQUM1RTs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQW1CQSxJQUFJLGlCQUFpQixjQUFjLE1BQU07Q0FDeEMsWUFBWSxTQUFTO0VBQ3BCLE1BQU0sZ0JBQWdCO0VBQ3RCLEtBQUssU0FBUyxTQUFTO0VBQ3ZCLEtBQUssU0FBUyxTQUFTO0NBQ3hCO0FBQ0Q7Ozs7Ozs7QUFPQSxTQUFTLGlCQUFpQixPQUFPO0NBQ2hDLE9BQU8saUJBQWlCO0FBQ3pCOzs7Ozs7Ozs7O0FBVUEsU0FBUyxjQUFjLFFBQVE7Q0FDOUIsSUFBSSxtQkFBbUI7Q0FDdkIsSUFBSSxlQUFlO0NBQ25CLElBQUk7Q0FDSixJQUFJLFNBQVM7Q0FDYixJQUFJO0NBQ0osSUFBSTtDQUNKLE1BQU0sVUFBVSxJQUFJLFNBQVMsU0FBUyxXQUFXO0VBQ2hELGlCQUFpQjtFQUNqQixnQkFBZ0I7Q0FDakIsQ0FBQztDQUNELFFBQVEsTUFBTSxJQUFJO0NBQ2xCLE1BQU0sbUJBQW1CLFdBQVc7Q0FDcEMsTUFBTSxVQUFVLGtCQUFrQjtFQUNqQyxJQUFJLENBQUMsV0FBVyxHQUFHO0dBQ2xCLE1BQU0sUUFBUSxJQUFJLGVBQWUsYUFBYTtHQUM5QyxPQUFPLEtBQUs7R0FDWixPQUFPLFdBQVcsS0FBSztFQUN4QjtDQUNEO0NBQ0EsTUFBTSxvQkFBb0I7RUFDekIsbUJBQW1CO0NBQ3BCO0NBQ0EsTUFBTSxzQkFBc0I7RUFDM0IsbUJBQW1CO0NBQ3BCO0NBQ0EsTUFBTSxvQkFBb0IsYUFBYSxVQUFVLE1BQU0sT0FBTyxnQkFBZ0IsWUFBWSxjQUFjLFNBQVMsTUFBTSxPQUFPLE9BQU87Q0FDckksTUFBTSxpQkFBaUIsU0FBUyxPQUFPLFdBQVcsS0FBSyxPQUFPLE9BQU87Q0FDckUsTUFBTSxXQUFXLFVBQVU7RUFDMUIsSUFBSSxDQUFDLFdBQVcsR0FBRztHQUNsQixhQUFhO0dBQ2IsU0FBUztHQUNULGVBQWUsS0FBSztFQUNyQjtDQUNEO0NBQ0EsTUFBTSxVQUFVLFVBQVU7RUFDekIsSUFBSSxDQUFDLFdBQVcsR0FBRztHQUNsQixhQUFhO0dBQ2IsU0FBUztHQUNULGNBQWMsS0FBSztFQUNwQjtDQUNEO0NBQ0EsTUFBTSxTQUFTLGNBQWM7RUFDNUIsT0FBTyxJQUFJLFNBQVMsb0JBQW9CO0dBQ3ZDLGNBQWMsVUFBVTtJQUN2QixJQUFJLFdBQVcsS0FBSyxVQUFVLEdBQUcsZ0JBQWdCLEtBQUs7R0FDdkQ7R0FDQSxPQUFPLFVBQVU7RUFDbEIsQ0FBQyxDQUFDLENBQUMsV0FBVztHQUNiLGFBQWEsS0FBSztHQUNsQixJQUFJLENBQUMsV0FBVyxHQUFHLE9BQU8sYUFBYTtFQUN4QyxDQUFDO0NBQ0Y7Q0FDQSxNQUFNLFlBQVk7RUFDakIsSUFBSSxXQUFXLEdBQUc7RUFDbEIsSUFBSTtFQUNKLE1BQU0saUJBQWlCLGlCQUFpQixJQUFJLE9BQU8saUJBQWlCLEtBQUs7RUFDekUsSUFBSTtHQUNILGlCQUFpQixrQkFBa0IsT0FBTyxHQUFHO0VBQzlDLFNBQVMsT0FBTztHQUNmLGlCQUFpQixRQUFRLE9BQU8sS0FBSztFQUN0QztFQUNBLFFBQVEsUUFBUSxjQUFjLENBQUMsQ0FBQyxLQUFLLE9BQU8sQ0FBQyxDQUFDLE9BQU8sVUFBVTtHQUM5RCxJQUFJLFdBQVcsR0FBRztHQUNsQixNQUFNLFFBQVEsT0FBTyxVQUFVQyxXQUFTLElBQUksSUFBSTtHQUNoRCxNQUFNLGFBQWEsT0FBTyxjQUFjO0dBQ3hDLE1BQU0sUUFBUSxPQUFPLGVBQWUsYUFBYSxXQUFXLGNBQWMsS0FBSyxJQUFJO0dBQ25GLE1BQU0sY0FBYyxVQUFVLFFBQVEsT0FBTyxVQUFVLFlBQVksZUFBZSxTQUFTLE9BQU8sVUFBVSxjQUFjLE1BQU0sY0FBYyxLQUFLO0dBQ25KLElBQUksb0JBQW9CLENBQUMsYUFBYTtJQUNyQyxPQUFPLEtBQUs7SUFDWjtHQUNEO0dBQ0E7R0FDQSxPQUFPLFNBQVMsY0FBYyxLQUFLO0dBQ25DLE1BQU0sS0FBSyxDQUFDLENBQUMsV0FBVztJQUN2QixPQUFPLFdBQVcsS0FBSyxZQUFZLElBQUksS0FBSyxJQUFJLE1BQU0sV0FBVztHQUNsRSxDQUFDLENBQUMsQ0FBQyxXQUFXO0lBQ2IsSUFBSSxrQkFBa0IsT0FBTyxLQUFLO1NBQzdCLElBQUk7R0FDVixDQUFDO0VBQ0YsQ0FBQztDQUNGO0NBQ0EsT0FBTztFQUNOO0VBQ0EsY0FBYztFQUNkO0VBQ0EsZ0JBQWdCO0dBQ2YsYUFBYTtHQUNiLE9BQU87RUFDUjtFQUNBO0VBQ0E7RUFDQTtFQUNBLGFBQWE7R0FDWixJQUFJLFNBQVMsR0FBRyxJQUFJO1FBQ2YsTUFBTSxRQUFRLENBQUMsQ0FBQyxLQUFLLEdBQUc7R0FDN0IsT0FBTztFQUNSO0NBQ0Q7QUFDRDs7Ozs7O0FDM0pBLElBQUksWUFBWSxNQUFNO0NBQ3JCOzs7Ozs7Q0FNQSxVQUFVO0VBQ1QsS0FBSyxlQUFlO0NBQ3JCOzs7OztDQUtBLGFBQWE7RUFDWixLQUFLLGVBQWU7RUFDcEIsSUFBSSxlQUFlLEtBQUssTUFBTSxHQUFHLEtBQUssYUFBYSxlQUFlLGlCQUFpQjtHQUNsRixLQUFLLGVBQWU7RUFDckIsR0FBRyxLQUFLLE1BQU07Q0FDZjs7Ozs7O0NBTUEsYUFBYSxXQUFXO0VBQ3ZCLEtBQUssU0FBUyxLQUFLLElBQUksS0FBSyxVQUFVLEdBQUcsY0FBY0MsV0FBUyxJQUFJLFdBQVcsSUFBSTtDQUNwRjs7OztDQUlBLGlCQUFpQjtFQUNoQixJQUFJLEtBQUssZUFBZSxLQUFLLEdBQUc7R0FDL0IsZUFBZSxhQUFhLEtBQUssVUFBVTtHQUMzQyxLQUFLLGFBQWEsS0FBSztFQUN4QjtDQUNEO0FBQ0Q7Ozs7Ozs7Ozs7QUNuQ0EsU0FBUyxzQkFBc0IsT0FBTztDQUNyQyxPQUFPLEVBQUUsVUFBVSxTQUFTLFVBQVU7RUFDckMsTUFBTSxVQUFVLFFBQVE7RUFDeEIsTUFBTSxZQUFZLFFBQVEsY0FBYyxNQUFNLFdBQVc7RUFDekQsTUFBTSxXQUFXLFFBQVEsTUFBTSxNQUFNLFNBQVMsQ0FBQztFQUMvQyxNQUFNLGdCQUFnQixRQUFRLE1BQU0sTUFBTSxjQUFjLENBQUM7RUFDekQsSUFBSSxTQUFTO0dBQ1osT0FBTyxDQUFDO0dBQ1IsWUFBWSxDQUFDO0VBQ2Q7RUFDQSxJQUFJLGNBQWM7RUFDbEIsTUFBTSxVQUFVLFlBQVk7R0FDM0IsSUFBSSxZQUFZO0dBQ2hCLE1BQU0sZ0JBQWdCO0dBQ3RCLE1BQU0scUJBQXFCLFdBQVc7SUFDckMsc0JBQXNCLGNBQWMsUUFBUSxjQUFjLFlBQVksTUFBTSxjQUFjLFlBQVk7R0FDdkc7R0FDQSxNQUFNLFVBQVUsY0FBYyxRQUFRLFNBQVMsUUFBUSxZQUFZO0dBQ25FLE1BQU0sWUFBWSxPQUFPLE1BQU0sT0FBTyxhQUFhO0lBQ2xELElBQUksV0FBVyxPQUFPLFFBQVEsT0FBTyxRQUFRLE9BQU8sTUFBTTtJQUMxRCxJQUFJLFNBQVMsUUFBUSxLQUFLLE1BQU0sUUFBUSxPQUFPLFFBQVEsUUFBUSxJQUFJO0lBQ25FLE1BQU0sNkJBQTZCO0tBQ2xDLE1BQU0saUJBQWlCO01BQ3RCLFFBQVEsUUFBUTtNQUNoQixVQUFVLFFBQVE7TUFDbEIsV0FBVztNQUNYLFdBQVcsV0FBVyxhQUFhO01BQ25DLE1BQU0sUUFBUSxRQUFRO0tBQ3ZCO0tBQ0Esa0JBQWtCLGNBQWM7S0FDaEMsT0FBTztJQUNSO0lBQ0EsTUFBTSxpQkFBaUIscUJBQXFCO0lBQzVDLE1BQU0sT0FBTyxNQUFNLFFBQVEsY0FBYztJQUN6QyxNQUFNLEVBQUUsYUFBYSxRQUFRO0lBQzdCLE1BQU0sUUFBUSxXQUFXLGFBQWE7SUFDdEMsT0FBTztLQUNOLE9BQU8sTUFBTSxLQUFLLE9BQU8sTUFBTSxRQUFRO0tBQ3ZDLFlBQVksTUFBTSxLQUFLLFlBQVksT0FBTyxRQUFRO0lBQ25EO0dBQ0Q7R0FDQSxJQUFJLGFBQWEsU0FBUyxRQUFRO0lBQ2pDLE1BQU0sV0FBVyxjQUFjO0lBQy9CLE1BQU0sY0FBYyxXQUFXLHVCQUF1QjtJQUN0RCxNQUFNLFVBQVU7S0FDZixPQUFPO0tBQ1AsWUFBWTtJQUNiO0lBQ0EsU0FBUyxNQUFNLFVBQVUsU0FBUyxZQUFZLFNBQVMsT0FBTyxHQUFHLFFBQVE7R0FDMUUsT0FBTztJQUNOLE1BQU0saUJBQWlCLFNBQVMsU0FBUztJQUN6QyxHQUFHO0tBQ0YsTUFBTSxRQUFRLGdCQUFnQixJQUFJLGNBQWMsT0FBTyxLQUFLLElBQUksUUFBUSxtQkFBbUIsY0FBYyxLQUFLLGlCQUFpQixTQUFTLE1BQU07S0FDOUksSUFBSSxjQUFjLEtBQUssU0FBUyxNQUFNO0tBQ3RDLFNBQVMsTUFBTSxVQUFVLFFBQVEsS0FBSztLQUN0QztJQUNELFNBQVMsY0FBYztHQUN4QjtHQUNBLE9BQU87RUFDUjtFQUNBLElBQUksUUFBUSxRQUFRLFdBQVcsUUFBUSxnQkFBZ0I7R0FDdEQsT0FBTyxRQUFRLFFBQVEsWUFBWSxTQUFTO0lBQzNDLFFBQVEsUUFBUTtJQUNoQixVQUFVLFFBQVE7SUFDbEIsTUFBTSxRQUFRLFFBQVE7SUFDdEIsUUFBUSxRQUFRO0dBQ2pCLEdBQUcsS0FBSztFQUNUO09BQ0ssUUFBUSxVQUFVO0NBQ3hCLEVBQUU7QUFDSDs7Ozs7OztBQU9BLFNBQVMsaUJBQWlCLFNBQVMsRUFBRSxPQUFPLGNBQWM7Q0FDekQsTUFBTSxZQUFZLE1BQU0sU0FBUztDQUNqQyxPQUFPLE1BQU0sU0FBUyxJQUFJLFFBQVEsaUJBQWlCLE1BQU0sWUFBWSxPQUFPLFdBQVcsWUFBWSxVQUFVLElBQUksS0FBSztBQUN2SDs7Ozs7Ozs7O0FBU0EsU0FBUyxxQkFBcUIsU0FBUyxFQUFFLE9BQU8sY0FBYztDQUM3RCxPQUFPLE1BQU0sU0FBUyxJQUFJLFFBQVEsdUJBQXVCLE1BQU0sSUFBSSxPQUFPLFdBQVcsSUFBSSxVQUFVLElBQUksS0FBSztBQUM3Rzs7Ozs7OztBQU9BLFNBQVMsWUFBWSxTQUFTLE1BQU07Q0FDbkMsSUFBSSxDQUFDLE1BQU0sT0FBTztDQUNsQixPQUFPLGlCQUFpQixTQUFTLElBQUksS0FBSztBQUMzQzs7Ozs7Ozs7QUFRQSxTQUFTLGdCQUFnQixTQUFTLE1BQU07Q0FDdkMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxRQUFRLHNCQUFzQixPQUFPO0NBQ25ELE9BQU8scUJBQXFCLFNBQVMsSUFBSSxLQUFLO0FBQy9DOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ2xHQSxJQUFJLFFBQVEsY0FBYyxVQUFVO0NBQ25DO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBLFlBQVksUUFBUTtFQUNuQixNQUFNO0VBQ04sS0FBSyx1QkFBdUI7RUFDNUIsS0FBSyxrQkFBa0IsT0FBTztFQUM5QixLQUFLLFdBQVcsT0FBTyxPQUFPO0VBQzlCLEtBQUssWUFBWSxDQUFDO0VBQ2xCLEtBQUssVUFBVSxPQUFPO0VBQ3RCLEtBQUssU0FBUyxLQUFLLFFBQVEsY0FBYztFQUN6QyxLQUFLLFdBQVcsT0FBTztFQUN2QixLQUFLLFlBQVksT0FBTztFQUN4QixLQUFLLGdCQUFnQkMsa0JBQWdCLEtBQUssT0FBTztFQUNqRCxLQUFLLFFBQVEsT0FBTyxTQUFTLEtBQUs7RUFDbEMsS0FBSyxXQUFXO0NBQ2pCOzs7OztDQUtBLElBQUksT0FBTztFQUNWLE9BQU8sS0FBSyxRQUFRO0NBQ3JCOzs7Ozs7Q0FNQSxJQUFJLFlBQVk7RUFDZixPQUFPLEtBQUs7Q0FDYjs7Ozs7O0NBTUEsSUFBSSxVQUFVO0VBQ2IsT0FBTyxLQUFLLFVBQVU7Q0FDdkI7Ozs7Ozs7Q0FPQSxXQUFXLFNBQVM7RUFDbkIsS0FBSyxVQUFVO0dBQ2QsR0FBRyxLQUFLO0dBQ1IsR0FBRztFQUNKO0VBQ0EsSUFBSSxTQUFTLE9BQU8sS0FBSyxhQUFhLFFBQVE7RUFDOUMsS0FBSyxhQUFhLEtBQUssUUFBUSxNQUFNO0VBQ3JDLElBQUksS0FBSyxTQUFTLEtBQUssTUFBTSxTQUFTLEtBQUssR0FBRztHQUM3QyxNQUFNLGVBQWVBLGtCQUFnQixLQUFLLE9BQU87R0FDakQsSUFBSSxhQUFhLFNBQVMsS0FBSyxHQUFHO0lBQ2pDLEtBQUssU0FBUyxhQUFhLGFBQWEsTUFBTSxhQUFhLGFBQWEsQ0FBQztJQUN6RSxLQUFLLGdCQUFnQjtHQUN0QjtFQUNEO0NBQ0Q7Q0FDQSxpQkFBaUI7RUFDaEIsSUFBSSxDQUFDLEtBQUssVUFBVSxVQUFVLEtBQUssTUFBTSxnQkFBZ0IsUUFBUSxLQUFLLE9BQU8sT0FBTyxJQUFJO0NBQ3pGOzs7Ozs7Ozs7Q0FTQSxRQUFRLFNBQVMsU0FBUztFQUN6QixNQUFNLE9BQU8sWUFBWSxLQUFLLE1BQU0sTUFBTSxTQUFTLEtBQUssT0FBTztFQUMvRCxLQUFLLFVBQVU7R0FDZDtHQUNBLE1BQU07R0FDTixlQUFlLFNBQVM7R0FDeEIsUUFBUSxTQUFTO0VBQ2xCLENBQUM7RUFDRCxPQUFPO0NBQ1I7Ozs7Ozs7Q0FPQSxTQUFTLE9BQU87RUFDZixLQUFLLFVBQVU7R0FDZCxNQUFNO0dBQ047RUFDRCxDQUFDO0NBQ0Y7Ozs7Ozs7Ozs7Ozs7Q0FhQSxPQUFPLFNBQVM7RUFDZixNQUFNLFVBQVUsS0FBSyxVQUFVO0VBQy9CLEtBQUssVUFBVSxPQUFPLE9BQU87RUFDN0IsT0FBTyxVQUFVLFFBQVEsS0FBSyxJQUFJLENBQUMsQ0FBQyxNQUFNLElBQUksSUFBSSxRQUFRLFFBQVE7Q0FDbkU7Ozs7Ozs7Q0FPQSxVQUFVO0VBQ1QsTUFBTSxRQUFRO0VBQ2QsS0FBSyxPQUFPLEVBQUUsUUFBUSxLQUFLLENBQUM7Q0FDN0I7Ozs7OztDQU1BLElBQUksYUFBYTtFQUNoQixPQUFPLEtBQUs7Q0FDYjs7Ozs7O0NBTUEsUUFBUTtFQUNQLEtBQUssUUFBUTtFQUNiLEtBQUssU0FBUyxLQUFLLFVBQVU7Q0FDOUI7Ozs7OztDQU1BLFdBQVc7RUFDVixPQUFPLEtBQUssVUFBVSxNQUFNLGFBQWEsa0JBQWtCLFNBQVMsUUFBUSxTQUFTLElBQUksTUFBTSxLQUFLO0NBQ3JHOzs7Ozs7Ozs7O0NBVUEsYUFBYTtFQUNaLElBQUksS0FBSyxrQkFBa0IsSUFBSSxHQUFHLE9BQU8sQ0FBQyxLQUFLLFNBQVM7RUFDeEQsT0FBTyxLQUFLLFFBQVEsWUFBWSxhQUFhLENBQUMsS0FBSyxVQUFVO0NBQzlEOzs7Ozs7Q0FNQSxZQUFZO0VBQ1gsT0FBTyxLQUFLLE1BQU0sa0JBQWtCLEtBQUssTUFBTSxtQkFBbUI7Q0FDbkU7Ozs7OztDQU1BLFdBQVc7RUFDVixJQUFJLEtBQUssTUFBTSxTQUFTLEtBQUssR0FBRyxPQUFPO0VBQ3ZDLElBQUksS0FBSyxrQkFBa0IsSUFBSSxHQUFHLE9BQU8sS0FBSyxVQUFVLE1BQU0sYUFBYSxrQkFBa0IsU0FBUyxRQUFRLFdBQVcsSUFBSSxNQUFNLFFBQVE7RUFDM0ksT0FBTztDQUNSOzs7Ozs7Ozs7Ozs7Ozs7OztDQWlCQSxVQUFVO0VBQ1QsSUFBSSxLQUFLLGtCQUFrQixJQUFJLEdBQUcsT0FBTyxLQUFLLFVBQVUsTUFBTSxhQUFhLFNBQVMsaUJBQWlCLENBQUMsQ0FBQyxPQUFPO0VBQzlHLE9BQU8sS0FBSyxNQUFNLFNBQVMsS0FBSyxLQUFLLEtBQUssTUFBTTtDQUNqRDs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FpQkEsY0FBYyxZQUFZLEdBQUc7RUFDNUIsSUFBSSxLQUFLLE1BQU0sU0FBUyxLQUFLLEdBQUcsT0FBTztFQUN2QyxJQUFJLGNBQWMsVUFBVSxPQUFPO0VBQ25DLElBQUksS0FBSyxNQUFNLGVBQWUsT0FBTztFQUNyQyxPQUFPLENBQUMsZUFBZSxLQUFLLE1BQU0sZUFBZSxTQUFTO0NBQzNEOzs7Ozs7Q0FNQSxVQUFVO0VBQ1QsS0FBSyxVQUFVLE1BQU0sTUFBTSxFQUFFLHlCQUF5QixDQUFDLENBQUMsRUFBRSxRQUFRLEVBQUUsZUFBZSxNQUFNLENBQUM7RUFDMUYsS0FBSyxVQUFVLFNBQVM7Q0FDekI7Ozs7OztDQU1BLFdBQVc7RUFDVixLQUFLLFVBQVUsTUFBTSxNQUFNLEVBQUUsdUJBQXVCLENBQUMsQ0FBQyxFQUFFLFFBQVEsRUFBRSxlQUFlLE1BQU0sQ0FBQztFQUN4RixLQUFLLFVBQVUsU0FBUztDQUN6Qjs7Ozs7OztDQU9BLFlBQVksVUFBVTtFQUNyQixJQUFJLENBQUMsS0FBSyxVQUFVLFNBQVMsUUFBUSxHQUFHO0dBQ3ZDLEtBQUssVUFBVSxLQUFLLFFBQVE7R0FDNUIsS0FBSyxlQUFlO0dBQ3BCLEtBQUssT0FBTyxPQUFPO0lBQ2xCLE1BQU07SUFDTixPQUFPO0lBQ1A7R0FDRCxDQUFDO0VBQ0Y7Q0FDRDs7Ozs7Ozs7Q0FRQSxlQUFlLFVBQVU7RUFDeEIsTUFBTSxRQUFRLEtBQUssVUFBVSxRQUFRLFFBQVE7RUFDN0MsSUFBSSxVQUFVLElBQUk7R0FDakIsS0FBSyxVQUFVLE9BQU8sT0FBTyxDQUFDO0dBQzlCLElBQUksQ0FBQyxLQUFLLFVBQVUsUUFBUTtJQUMzQixJQUFJLEtBQUssVUFBVTtLQUNsQixJQUFJLEtBQUssd0JBQXdCLEtBQUssTUFBTSxnQkFBZ0IsWUFBWSxLQUFLLE1BQU0sV0FBVyxXQUFXLEtBQUssU0FBUyxPQUFPLEVBQUUsUUFBUSxLQUFLLENBQUM7VUFDekksS0FBSyxTQUFTLFlBQVk7SUFDaEM7SUFDQSxLQUFLLFdBQVc7R0FDakI7R0FDQSxLQUFLLE9BQU8sT0FBTztJQUNsQixNQUFNO0lBQ04sT0FBTztJQUNQO0dBQ0QsQ0FBQztFQUNGO0NBQ0Q7Ozs7Ozs7Ozs7O0NBV0Esb0JBQW9CO0VBQ25CLE9BQU8sS0FBSyxVQUFVO0NBQ3ZCOzs7Ozs7Ozs7O0NBVUEsYUFBYTtFQUNaLElBQUksQ0FBQyxLQUFLLE1BQU0sZUFBZSxLQUFLLFVBQVUsRUFBRSxNQUFNLGFBQWEsQ0FBQztDQUNyRTs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBa0JBLE1BQU0sTUFBTSxTQUFTLGNBQWM7RUFDbEMsSUFBSSxLQUFLLE1BQU0sZ0JBQWdCLFVBQVUsS0FBSyxVQUFVLE9BQU8sTUFBTSxZQUFZO0dBQ2hGLElBQUksS0FBSyxNQUFNLFNBQVMsS0FBSyxLQUFLLGNBQWMsZUFBZSxLQUFLLE9BQU8sRUFBRSxRQUFRLEtBQUssQ0FBQztRQUN0RixJQUFJLEtBQUssWUFBWSxLQUFLLGVBQWU7SUFDN0MsS0FBSyxTQUFTLGNBQWM7SUFDNUIsT0FBTyxLQUFLO0dBQ2I7RUFDRDtFQUNBLElBQUksU0FBUyxLQUFLLFdBQVcsT0FBTztFQUNwQyxJQUFJLENBQUMsS0FBSyxRQUFRLFNBQVM7R0FDMUIsTUFBTSxXQUFXLEtBQUssVUFBVSxNQUFNLE1BQU0sRUFBRSxRQUFRLE9BQU87R0FDN0QsSUFBSSxVQUFVLEtBQUssV0FBVyxTQUFTLE9BQU87RUFDL0M7RUFFQyxJQUFJLENBQUMsTUFBTSxRQUFRLEtBQUssUUFBUSxRQUFRLEdBQUcsUUFBUSxNQUFNLHFJQUFxSTtFQUUvTCxNQUFNLGtCQUFrQixJQUFJLGdCQUFnQjtFQUM1QyxNQUFNLHFCQUFxQixXQUFXO0dBQ3JDLE9BQU8saUJBQWlCLFFBQVE7S0FDOUIsY0FBYztLQUNkLE9BQU8sZ0JBQWdCO0tBQ3ZCLFlBQVk7SUFDYjtJQUNBLFFBQVE7S0FDUCxZQUFZO0tBQ1osV0FBVztNQUNWLEtBQUssdUJBQXVCO01BQzVCLE9BQU8sZ0JBQWdCO0tBQ3hCO0lBQ0Q7R0FDRCxDQUFDO0VBQ0Y7RUFDQSxNQUFNLGdCQUFnQjtHQUNyQixNQUFNLFVBQVUsY0FBYyxLQUFLLFNBQVMsWUFBWTtHQUN4RCxNQUFNLDZCQUE2QjtJQUNsQyxNQUFNLGlCQUFpQjtLQUN0QixRQUFRLEtBQUs7S0FDYixVQUFVLEtBQUs7S0FDZixNQUFNLEtBQUs7SUFDWjtJQUNBLGtCQUFrQixjQUFjO0lBQ2hDLE9BQU87R0FDUjtHQUNBLE1BQU0saUJBQWlCLHFCQUFxQjtHQUM1QyxLQUFLLHVCQUF1QjtHQUM1QixJQUFJLEtBQUssUUFBUSxXQUFXLE9BQU8sS0FBSyxRQUFRLFVBQVUsU0FBUyxnQkFBZ0IsSUFBSTtHQUN2RixPQUFPLFFBQVEsY0FBYztFQUM5QjtFQUNBLE1BQU0sMkJBQTJCO0dBQ2hDLE1BQU0sVUFBVTtJQUNmO0lBQ0EsU0FBUyxLQUFLO0lBQ2QsVUFBVSxLQUFLO0lBQ2YsUUFBUSxLQUFLO0lBQ2IsT0FBTyxLQUFLO0lBQ1o7R0FDRDtHQUNBLGtCQUFrQixPQUFPO0dBQ3pCLE9BQU87RUFDUjtFQUNBLE1BQU0sVUFBVSxtQkFBbUI7RUFDbkMsQ0FBQyxLQUFLLGVBQWUsYUFBYSxzQkFBc0IsS0FBSyxRQUFRLEtBQUssSUFBSSxLQUFLLFFBQVEsU0FBQSxFQUFXLFFBQVEsU0FBUyxJQUFJO0VBQzNILEtBQUssZUFBZSxLQUFLO0VBQ3pCLElBQUksS0FBSyxNQUFNLGdCQUFnQixVQUFVLEtBQUssTUFBTSxjQUFjLFFBQVEsY0FBYyxNQUFNLEtBQUssVUFBVTtHQUM1RyxNQUFNO0dBQ04sTUFBTSxRQUFRLGNBQWM7RUFDN0IsQ0FBQztFQUNELE1BQU0sVUFBVSxLQUFLLFdBQVcsY0FBYztHQUM3QyxnQkFBZ0IsY0FBYztHQUM5QixJQUFJLFFBQVE7R0FDWixXQUFXLFVBQVU7SUFDcEIsSUFBSSxpQkFBaUIsa0JBQWtCLE1BQU0sUUFBUSxLQUFLLFNBQVM7S0FDbEUsR0FBRyxLQUFLO0tBQ1IsYUFBYTtJQUNkLENBQUM7SUFDRCxnQkFBZ0IsTUFBTTtHQUN2QjtHQUNBLFNBQVMsY0FBYyxVQUFVO0lBQ2hDLEtBQUssVUFBVTtLQUNkLE1BQU07S0FDTjtLQUNBO0lBQ0QsQ0FBQztHQUNGO0dBQ0EsZUFBZTtJQUNkLEtBQUssVUFBVSxFQUFFLE1BQU0sUUFBUSxDQUFDO0dBQ2pDO0dBQ0Esa0JBQWtCO0lBQ2pCLEtBQUssVUFBVSxFQUFFLE1BQU0sV0FBVyxDQUFDO0dBQ3BDO0dBQ0EsT0FBTyxRQUFRLFFBQVE7R0FDdkIsWUFBWSxRQUFRLFFBQVE7R0FDNUIsYUFBYSxRQUFRLFFBQVE7R0FDN0IsY0FBYztFQUNmLENBQUM7RUFDRCxNQUFNLGdCQUFnQixZQUFZO0dBQ2pDLElBQUk7SUFDSCxNQUFNLE9BQU8sTUFBTSxRQUFRO0lBQzNCLElBQUksU0FBUyxLQUFLLEdBQUc7S0FDdUIsUUFBUSxNQUFNLHlJQUF5SSxLQUFLLFdBQVc7S0FDbE4sTUFBTSxJQUFJLE1BQU0sR0FBRyxLQUFLLFVBQVUsbUJBQW1CO0lBQ3REO0lBQ0EsS0FBSyxRQUFRLElBQUk7SUFDakIsS0FBSyxPQUFPLE9BQU8sWUFBWSxNQUFNLElBQUk7SUFDekMsS0FBSyxPQUFPLE9BQU8sWUFBWSxNQUFNLEtBQUssTUFBTSxPQUFPLElBQUk7SUFDM0QsT0FBTztHQUNSLFNBQVMsT0FBTztJQUNmLElBQUksaUJBQWlCLGdCQUFnQjtLQUNwQyxJQUFJLE1BQU0sUUFBUTtNQUNqQixJQUFJLEtBQUssYUFBYSxXQUFXLEtBQUssZUFBZSxPQUFPLEtBQUs7TUFDakUsTUFBTTtLQUNQLE9BQU8sSUFBSSxNQUFNLFFBQVE7TUFDeEIsSUFBSSxLQUFLLE1BQU0sU0FBUyxLQUFLLEdBQUcsTUFBTTtNQUN0QyxPQUFPLEtBQUssTUFBTTtLQUNuQjtJQUNEO0lBQ0EsS0FBSyxVQUFVO0tBQ2QsTUFBTTtLQUNOO0lBQ0QsQ0FBQztJQUNELEtBQUssT0FBTyxPQUFPLFVBQVUsT0FBTyxJQUFJO0lBQ3hDLEtBQUssT0FBTyxPQUFPLFlBQVksS0FBSyxNQUFNLE1BQU0sT0FBTyxJQUFJO0lBQzNELE1BQU07R0FDUCxVQUFVO0lBQ1QsSUFBSSxLQUFLLGFBQWEsU0FBUztLQUM5QixLQUFLLFdBQVcsS0FBSztLQUNyQixLQUFLLGdCQUFnQixLQUFLO0lBQzNCO0lBQ0EsS0FBSyxXQUFXO0dBQ2pCO0VBQ0QsRUFBQSxDQUFHO0VBQ0gsS0FBSyxnQkFBZ0I7RUFDckIsUUFBUSxNQUFNO0VBQ2QsT0FBTztDQUNSO0NBQ0EsVUFBVSxRQUFRO0VBQ2pCLE1BQU0sV0FBVyxVQUFVO0dBQzFCLFFBQVEsT0FBTyxNQUFmO0lBQ0MsS0FBSyxVQUFVLE9BQU87S0FDckIsR0FBRztLQUNILG1CQUFtQixPQUFPO0tBQzFCLG9CQUFvQixPQUFPO0lBQzVCO0lBQ0EsS0FBSyxTQUFTLE9BQU87S0FDcEIsR0FBRztLQUNILGFBQWE7SUFDZDtJQUNBLEtBQUssWUFBWSxPQUFPO0tBQ3ZCLEdBQUc7S0FDSCxhQUFhO0lBQ2Q7SUFDQSxLQUFLLFNBQVMsT0FBTztLQUNwQixHQUFHO0tBQ0gsR0FBRyxXQUFXLE1BQU0sTUFBTSxLQUFLLE9BQU87S0FDdEMsV0FBVyxPQUFPLFFBQVE7SUFDM0I7SUFDQSxLQUFLO0tBQ0osTUFBTSxXQUFXO01BQ2hCLEdBQUc7TUFDSCxHQUFHLGFBQWEsT0FBTyxNQUFNLE9BQU8sYUFBYTtNQUNqRCxpQkFBaUIsTUFBTSxrQkFBa0I7TUFDekMsR0FBRyxDQUFDLE9BQU8sVUFBVTtPQUNwQixhQUFhO09BQ2IsbUJBQW1CO09BQ25CLG9CQUFvQjtNQUNyQjtLQUNEO0tBQ0EsS0FBSyxlQUFlLE9BQU8sU0FBUyxXQUFXLEtBQUs7S0FDcEQsT0FBTztJQUNSLEtBQUs7S0FDSixNQUFNLFFBQVEsT0FBTztLQUNyQixPQUFPO01BQ04sR0FBRztNQUNIO01BQ0Esa0JBQWtCLE1BQU0sbUJBQW1CO01BQzNDLGdCQUFnQixLQUFLLElBQUk7TUFDekIsbUJBQW1CLE1BQU0sb0JBQW9CO01BQzdDLG9CQUFvQjtNQUNwQixhQUFhO01BQ2IsUUFBUTtNQUNSLGVBQWU7S0FDaEI7SUFDRCxLQUFLLGNBQWMsT0FBTztLQUN6QixHQUFHO0tBQ0gsZUFBZTtJQUNoQjtJQUNBLEtBQUssWUFBWSxPQUFPO0tBQ3ZCLEdBQUc7S0FDSCxHQUFHLE9BQU87SUFDWDtHQUNEO0VBQ0Q7RUFDQSxLQUFLLFFBQVEsUUFBUSxLQUFLLEtBQUs7RUFDL0IsY0FBYyxZQUFZO0dBQ3pCLEtBQUssVUFBVSxNQUFNLENBQUMsQ0FBQyxTQUFTLGFBQWE7SUFDNUMsU0FBUyxjQUFjO0dBQ3hCLENBQUM7R0FDRCxLQUFLLE9BQU8sT0FBTztJQUNsQixPQUFPO0lBQ1AsTUFBTTtJQUNOO0dBQ0QsQ0FBQztFQUNGLENBQUM7Q0FDRjtBQUNEOzs7Ozs7Ozs7QUFTQSxTQUFTLFdBQVcsTUFBTSxTQUFTO0NBQ2xDLE9BQU87RUFDTixtQkFBbUI7RUFDbkIsb0JBQW9CO0VBQ3BCLGFBQWEsU0FBUyxRQUFRLFdBQVcsSUFBSSxhQUFhO0VBQzFELEdBQUcsU0FBUyxLQUFLLEtBQUs7R0FDckIsT0FBTztHQUNQLFFBQVE7RUFDVDtDQUNEO0FBQ0Q7Ozs7Ozs7QUFPQSxTQUFTLGFBQWEsTUFBTSxlQUFlO0NBQzFDLE9BQU87RUFDTjtFQUNBLGVBQWUsaUJBQWlCLEtBQUssSUFBSTtFQUN6QyxPQUFPO0VBQ1AsZUFBZTtFQUNmLFFBQVE7Q0FDVDtBQUNEOzs7Ozs7O0FBT0EsU0FBU0Esa0JBQWdCLFNBQVM7Q0FDakMsTUFBTSxPQUFPLE9BQU8sUUFBUSxnQkFBZ0IsYUFBYSxRQUFRLFlBQVksSUFBSSxRQUFRO0NBQ3pGLE1BQU0sVUFBVSxTQUFTLEtBQUs7Q0FDOUIsTUFBTSx1QkFBdUIsVUFBVSxPQUFPLFFBQVEseUJBQXlCLGFBQWEsUUFBUSxxQkFBcUIsSUFBSSxRQUFRLHVCQUF1QjtDQUM1SixPQUFPO0VBQ047RUFDQSxpQkFBaUI7RUFDakIsZUFBZSxVQUFVLHdCQUF3QixLQUFLLElBQUksSUFBSTtFQUM5RCxPQUFPO0VBQ1Asa0JBQWtCO0VBQ2xCLGdCQUFnQjtFQUNoQixtQkFBbUI7RUFDbkIsb0JBQW9CO0VBQ3BCLFdBQVc7RUFDWCxlQUFlO0VBQ2YsUUFBUSxVQUFVLFlBQVk7RUFDOUIsYUFBYTtDQUNkO0FBQ0Q7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQzVrQkEsSUFBSSxnQkFBZ0IsY0FBYyxhQUFhO0NBQzlDO0NBQ0EsZ0JBQWdCLEtBQUs7Q0FDckIsNEJBQTRCLEtBQUs7Q0FDakMsaUJBQWlCLEtBQUs7Q0FDdEI7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0EsZ0NBQWdDLElBQUksSUFBSTtDQUN4QyxZQUFZLFFBQVEsU0FBUztFQUM1QixNQUFNO0VBQ04sS0FBSyxVQUFVO0VBQ2YsS0FBSyxVQUFVO0VBQ2YsS0FBSyxlQUFlO0VBQ3BCLEtBQUssWUFBWTtFQUNqQixLQUFLLFdBQVcsT0FBTztDQUN4Qjs7Ozs7Q0FLQSxjQUFjO0VBQ2IsS0FBSyxVQUFVLEtBQUssUUFBUSxLQUFLLElBQUk7Q0FDdEM7Q0FDQSxjQUFjO0VBQ2IsSUFBSSxLQUFLLFVBQVUsU0FBUyxHQUFHO0dBQzlCLEtBQUssY0FBYyxZQUFZLElBQUk7R0FDbkMsSUFBSSxtQkFBbUIsS0FBSyxlQUFlLEtBQUssT0FBTyxHQUFHLEtBQUssY0FBYztRQUN4RSxLQUFLLGFBQWE7R0FDdkIsS0FBSyxjQUFjO0VBQ3BCO0NBQ0Q7Q0FDQSxnQkFBZ0I7RUFDZixJQUFJLENBQUMsS0FBSyxhQUFhLEdBQUcsS0FBSyxRQUFRO0NBQ3hDOzs7Ozs7O0NBT0EseUJBQXlCO0VBQ3hCLE9BQU8sY0FBYyxLQUFLLGVBQWUsS0FBSyxTQUFTLEtBQUssUUFBUSxrQkFBa0I7Q0FDdkY7Ozs7Ozs7Q0FPQSwyQkFBMkI7RUFDMUIsT0FBTyxjQUFjLEtBQUssZUFBZSxLQUFLLFNBQVMsS0FBSyxRQUFRLG9CQUFvQjtDQUN6Rjs7Ozs7O0NBTUEsVUFBVTtFQUNULEtBQUssNEJBQTRCLElBQUksSUFBSTtFQUN6QyxLQUFLLG1CQUFtQjtFQUN4QixLQUFLLHNCQUFzQjtFQUMzQixLQUFLLGNBQWMsZUFBZSxJQUFJO0NBQ3ZDOzs7Ozs7Ozs7Ozs7Ozs7OztDQWlCQSxXQUFXLFNBQVM7RUFDbkIsTUFBTSxjQUFjLEtBQUs7RUFDekIsTUFBTSxZQUFZLEtBQUs7RUFDdkIsS0FBSyxVQUFVLEtBQUssUUFBUSxvQkFBb0IsT0FBTztFQUN2RCxJQUFJLEtBQUssUUFBUSxZQUFZLEtBQUssS0FBSyxPQUFPLEtBQUssUUFBUSxZQUFZLGFBQWEsT0FBTyxLQUFLLFFBQVEsWUFBWSxjQUFjLE9BQU8sa0JBQWtCLEtBQUssUUFBUSxTQUFTLEtBQUssYUFBYSxNQUFNLFdBQVcsTUFBTSxJQUFJLE1BQU0sdUVBQXVFO0VBQzNTLEtBQUssYUFBYTtFQUNsQixLQUFLLGNBQWMsV0FBVyxLQUFLLE9BQU87RUFDMUMsSUFBSSxZQUFZLGNBQWMsQ0FBQyxvQkFBb0IsS0FBSyxTQUFTLFdBQVcsR0FBRyxLQUFLLFFBQVEsY0FBYyxDQUFDLENBQUMsT0FBTztHQUNsSCxNQUFNO0dBQ04sT0FBTyxLQUFLO0dBQ1osVUFBVTtFQUNYLENBQUM7RUFDRCxNQUFNLFVBQVUsS0FBSyxhQUFhO0VBQ2xDLElBQUksV0FBVyxzQkFBc0IsS0FBSyxlQUFlLFdBQVcsS0FBSyxTQUFTLFdBQVcsR0FBRyxLQUFLLGNBQWM7RUFDbkgsS0FBSyxhQUFhO0VBQ2xCLElBQUksWUFBWSxLQUFLLGtCQUFrQixhQUFhLGtCQUFrQixLQUFLLFFBQVEsU0FBUyxLQUFLLGFBQWEsTUFBTSxrQkFBa0IsWUFBWSxTQUFTLEtBQUssYUFBYSxLQUFLLGtCQUFrQixLQUFLLFFBQVEsV0FBVyxLQUFLLGFBQWEsTUFBTSxrQkFBa0IsWUFBWSxXQUFXLEtBQUssYUFBYSxJQUFJLEtBQUssb0JBQW9CO0VBQzVVLE1BQU0sc0JBQXNCLEtBQUssd0JBQXdCO0VBQ3pELElBQUksWUFBWSxLQUFLLGtCQUFrQixhQUFhLGtCQUFrQixLQUFLLFFBQVEsU0FBUyxLQUFLLGFBQWEsTUFBTSxrQkFBa0IsWUFBWSxTQUFTLEtBQUssYUFBYSxLQUFLLHdCQUF3QixLQUFLLDBCQUEwQixLQUFLLHVCQUF1QixtQkFBbUI7Q0FDelI7Ozs7Ozs7OztDQVNBLG9CQUFvQixTQUFTO0VBQzVCLE1BQU0sUUFBUSxLQUFLLFFBQVEsY0FBYyxDQUFDLENBQUMsTUFBTSxLQUFLLFNBQVMsT0FBTztFQUN0RSxNQUFNLFNBQVMsS0FBSyxhQUFhLE9BQU8sT0FBTztFQUMvQyxJQUFJLENBQUMsb0JBQW9CLEtBQUssaUJBQWlCLEdBQUcsTUFBTSxHQUFHO0dBQzFELEtBQUssaUJBQWlCO0dBQ3RCLEtBQUssd0JBQXdCLEtBQUs7R0FDbEMsS0FBSyxzQkFBc0IsS0FBSyxjQUFjO0VBQy9DO0VBQ0EsT0FBTztDQUNSOzs7Ozs7Ozs7Ozs7O0NBYUEsbUJBQW1CO0VBQ2xCLE9BQU8sS0FBSztDQUNiOzs7Ozs7Ozs7O0NBVUEsWUFBWSxRQUFRLGVBQWU7RUFDbEMsT0FBTyxJQUFJLE1BQU0sUUFBUSxFQUFFLE1BQU0sUUFBUSxRQUFRO0dBQ2hELEtBQUssVUFBVSxHQUFHO0dBQ2xCLGdCQUFnQixHQUFHO0dBQ25CLE9BQU8sUUFBUSxJQUFJLFFBQVEsR0FBRztFQUMvQixFQUFFLENBQUM7Q0FDSjs7Ozs7Ozs7Q0FRQSxVQUFVLEtBQUs7RUFDZCxLQUFLLGNBQWMsSUFBSSxHQUFHO0NBQzNCOzs7OztDQUtBLGtCQUFrQjtFQUNqQixPQUFPLEtBQUs7Q0FDYjs7Ozs7Ozs7Ozs7OztDQWFBLFFBQVEsRUFBRSxHQUFHLFlBQVksQ0FBQyxHQUFHO0VBQzVCLE9BQU8sS0FBSyxNQUFNLEVBQUUsR0FBRyxRQUFRLENBQUM7Q0FDakM7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQWtCQSxnQkFBZ0IsU0FBUztFQUN4QixNQUFNLG1CQUFtQixLQUFLLFFBQVEsb0JBQW9CLE9BQU87RUFDakUsTUFBTSxRQUFRLEtBQUssUUFBUSxjQUFjLENBQUMsQ0FBQyxNQUFNLEtBQUssU0FBUyxnQkFBZ0I7RUFDL0UsSUFBSSxvQkFBb0IsQ0FBQztFQUN6QixJQUFJO0VBQ0osTUFBTSxlQUFlLElBQUksU0FBUyxZQUFZO0dBQzdDLGVBQWU7R0FDZixjQUFjLEtBQUssUUFBUSxjQUFjLENBQUMsQ0FBQyxXQUFXLFVBQVU7SUFDL0QsSUFBSSxNQUFNLFNBQVMsYUFBYSxNQUFNLE1BQU0sY0FBYyxNQUFNLGFBQWEsTUFBTSxNQUFNLFNBQVMsS0FBSyxHQUFHO0tBQ3pHLFlBQVk7S0FDWixRQUFRLEtBQUssYUFBYSxPQUFPLGdCQUFnQixDQUFDO0lBQ25EO0dBQ0QsQ0FBQztFQUNGLENBQUM7RUFDRCxPQUFPLFFBQVEsS0FBSyxDQUFDLE1BQU0sTUFBTSxnQkFBZ0IsQ0FBQyxDQUFDLFdBQVc7R0FDN0QsTUFBTSxTQUFTLEtBQUssYUFBYSxPQUFPLGdCQUFnQjtHQUN4RCxlQUFlLE1BQU07R0FDckIsT0FBTztFQUNSLENBQUMsQ0FBQyxDQUFDLGNBQWM7R0FDaEIsWUFBWTtFQUNiLENBQUMsR0FBRyxZQUFZLENBQUM7Q0FDbEI7Ozs7Ozs7Q0FPQSxNQUFNLGNBQWM7RUFDbkIsT0FBTyxLQUFLLGNBQWM7R0FDekIsR0FBRztHQUNILGVBQWUsYUFBYSxpQkFBaUI7RUFDOUMsQ0FBQyxDQUFDLENBQUMsV0FBVztHQUNiLEtBQUssYUFBYTtHQUNsQixPQUFPLEtBQUs7RUFDYixDQUFDO0NBQ0Y7Q0FDQSxjQUFjLGNBQWM7RUFDM0IsS0FBSyxhQUFhO0VBQ2xCLElBQUksVUFBVSxLQUFLLGNBQWMsTUFBTSxLQUFLLFNBQVMsWUFBWTtFQUNqRSxJQUFJLENBQUMsY0FBYyxjQUFjLFVBQVUsUUFBUSxNQUFNLElBQUk7RUFDN0QsT0FBTztDQUNSO0NBQ0EscUJBQXFCLFNBQVM7RUFDN0IsT0FBTyxDQUFDQyxXQUFTLEtBQUssa0JBQWtCLEtBQUssUUFBUSxTQUFTLEtBQUssYUFBYSxNQUFNLFNBQVMsZUFBZSxPQUFPO0NBQ3RIO0NBQ0Esc0JBQXNCO0VBQ3JCLEtBQUssbUJBQW1CO0VBQ3hCLE1BQU0sWUFBWSxrQkFBa0IsS0FBSyxRQUFRLFdBQVcsS0FBSyxhQUFhO0VBQzlFLElBQUksS0FBSyxlQUFlLFdBQVcsQ0FBQyxLQUFLLHFCQUFxQixTQUFTLEdBQUc7RUFDMUUsTUFBTSxVQUFVLGVBQWUsS0FBSyxlQUFlLGVBQWUsU0FBUyxJQUFJO0VBQy9FLEtBQUssa0JBQWtCLGVBQWUsaUJBQWlCO0dBQ3RELElBQUksQ0FBQyxLQUFLLGVBQWUsU0FBUyxLQUFLLGFBQWE7RUFDckQsR0FBRyxPQUFPO0NBQ1g7Q0FDQSwwQkFBMEI7RUFDekIsT0FBTyxrQkFBa0IsS0FBSyxRQUFRLGlCQUFpQixLQUFLLGFBQWEsS0FBSztDQUMvRTtDQUNBLHVCQUF1QixjQUFjO0VBQ3BDLEtBQUssc0JBQXNCO0VBQzNCLEtBQUssMEJBQTBCO0VBQy9CLElBQUksS0FBSyw0QkFBNEIsS0FBSyxDQUFDLEtBQUsscUJBQXFCLEtBQUssdUJBQXVCLEdBQUc7RUFDcEcsS0FBSyxxQkFBcUIsZUFBZSxrQkFBa0I7R0FDMUQsSUFBSSxLQUFLLFFBQVEsK0JBQStCLGFBQWEsVUFBVSxHQUFHLEtBQUssY0FBYztFQUM5RixHQUFHLEtBQUssdUJBQXVCO0NBQ2hDO0NBQ0EsZ0JBQWdCO0VBQ2YsS0FBSyxvQkFBb0I7RUFDekIsS0FBSyx1QkFBdUIsS0FBSyx3QkFBd0IsQ0FBQztDQUMzRDtDQUNBLHFCQUFxQjtFQUNwQixJQUFJLEtBQUssb0JBQW9CLEtBQUssR0FBRztHQUNwQyxlQUFlLGFBQWEsS0FBSyxlQUFlO0dBQ2hELEtBQUssa0JBQWtCLEtBQUs7RUFDN0I7Q0FDRDtDQUNBLHdCQUF3QjtFQUN2QixJQUFJLEtBQUssdUJBQXVCLEtBQUssR0FBRztHQUN2QyxlQUFlLGNBQWMsS0FBSyxrQkFBa0I7R0FDcEQsS0FBSyxxQkFBcUIsS0FBSztFQUNoQztDQUNEOzs7Ozs7OztDQVFBLGFBQWEsT0FBTyxTQUFTO0VBQzVCLE1BQU0sWUFBWSxLQUFLO0VBQ3ZCLE1BQU0sY0FBYyxLQUFLO0VBQ3pCLE1BQU0sYUFBYSxLQUFLO0VBQ3hCLE1BQU0sa0JBQWtCLEtBQUs7RUFDN0IsTUFBTSxvQkFBb0IsS0FBSztFQUMvQixNQUFNLG9CQUFvQixVQUFVLFlBQVksTUFBTSxRQUFRLEtBQUs7RUFDbkUsTUFBTSxFQUFFLFVBQVU7RUFDbEIsSUFBSSxXQUFXLEVBQUUsR0FBRyxNQUFNO0VBQzFCLElBQUksb0JBQW9CO0VBQ3hCLElBQUk7RUFDSixJQUFJLFFBQVEsb0JBQW9CO0dBQy9CLE1BQU0sVUFBVSxLQUFLLGFBQWE7R0FDbEMsTUFBTSxlQUFlLENBQUMsV0FBVyxtQkFBbUIsT0FBTyxPQUFPO0dBQ2xFLE1BQU0sa0JBQWtCLFdBQVcsc0JBQXNCLE9BQU8sV0FBVyxTQUFTLFdBQVc7R0FDL0YsSUFBSSxnQkFBZ0IsaUJBQWlCLFdBQVc7SUFDL0MsR0FBRztJQUNILEdBQUcsV0FBVyxNQUFNLE1BQU0sTUFBTSxPQUFPO0dBQ3hDO0dBQ0EsSUFBSSxRQUFRLHVCQUF1QixlQUFlLFNBQVMsY0FBYztFQUMxRTtFQUNBLElBQUksRUFBRSxPQUFPLGdCQUFnQixXQUFXO0VBQ3hDLE9BQU8sU0FBUztFQUNoQixJQUFJLGFBQWE7RUFDakIsSUFBSSxRQUFRLG9CQUFvQixLQUFLLEtBQUssU0FBUyxLQUFLLEtBQUssV0FBVyxXQUFXO0dBQ2xGLElBQUk7R0FDSixJQUFJLFlBQVkscUJBQXFCLFFBQVEsb0JBQW9CLG1CQUFtQixpQkFBaUI7SUFDcEcsa0JBQWtCLFdBQVc7SUFDN0IsYUFBYTtHQUNkLE9BQU8sa0JBQWtCLE9BQU8sUUFBUSxvQkFBb0IsYUFBYSxRQUFRLGdCQUFnQixLQUFLLDJCQUEyQixNQUFNLE1BQU0sS0FBSyx5QkFBeUIsSUFBSSxRQUFRO0dBQ3ZMLElBQUksb0JBQW9CLEtBQUssR0FBRztJQUMvQixTQUFTO0lBQ1QsT0FBTyxZQUFZLFlBQVksTUFBTSxpQkFBaUIsT0FBTztJQUM3RCxvQkFBb0I7R0FDckI7RUFDRDtFQUNBLElBQUksUUFBUSxVQUFVLFNBQVMsS0FBSyxLQUFLLENBQUMsWUFBWTtHQUNyRCxJQUFJLGNBQWMsU0FBUyxpQkFBaUIsUUFBUSxRQUFRLFdBQVcsS0FBSyxXQUFXLE9BQU8sS0FBSztRQUM5RixJQUFJO0lBQ1IsS0FBSyxZQUFZLFFBQVE7SUFDekIsT0FBTyxRQUFRLE9BQU8sSUFBSTtJQUMxQixPQUFPLFlBQVksWUFBWSxNQUFNLE1BQU0sT0FBTztJQUNsRCxLQUFLLGdCQUFnQjtJQUNyQixLQUFLLGVBQWU7R0FDckIsU0FBUyxhQUFhO0lBQ3JCLEtBQUssZUFBZTtHQUNyQjtFQUNELE9BQU8sSUFBSSxTQUFTLEtBQUssR0FBRyxLQUFLLGVBQWU7RUFDaEQsSUFBSSxLQUFLLGNBQWM7R0FDdEIsUUFBUSxLQUFLO0dBQ2IsT0FBTyxLQUFLO0dBQ1osaUJBQWlCLFlBQVksVUFBVSxRQUFRLFdBQVcsaUJBQWlCLEtBQUssSUFBSTtHQUNwRixTQUFTO0dBQ1Qsb0JBQW9CO0VBQ3JCO0VBQ0EsTUFBTSxhQUFhLFNBQVMsZ0JBQWdCO0VBQzVDLE1BQU0sWUFBWSxXQUFXO0VBQzdCLE1BQU0sVUFBVSxXQUFXO0VBQzNCLE1BQU0sWUFBWSxhQUFhO0VBQy9CLE1BQU0sVUFBVSxTQUFTLEtBQUs7RUFDOUIsT0FBTztHQUNOO0dBQ0EsYUFBYSxTQUFTO0dBQ3RCO0dBQ0EsV0FBVyxXQUFXO0dBQ3RCO0dBQ0Esa0JBQWtCO0dBQ2xCO0dBQ0E7R0FDQSxlQUFlLFNBQVM7R0FDeEI7R0FDQTtHQUNBLGNBQWMsU0FBUztHQUN2QixlQUFlLFNBQVM7R0FDeEIsa0JBQWtCLFNBQVM7R0FDM0IsV0FBVyxNQUFNLFVBQVU7R0FDM0IscUJBQXFCLFNBQVMsa0JBQWtCLGtCQUFrQixtQkFBbUIsU0FBUyxtQkFBbUIsa0JBQWtCO0dBQ25JO0dBQ0EsY0FBYyxjQUFjLENBQUM7R0FDN0IsZ0JBQWdCLFdBQVcsQ0FBQztHQUM1QixVQUFVLFNBQVMsZ0JBQWdCO0dBQ25DO0dBQ0EsZ0JBQWdCLFdBQVc7R0FDM0IsU0FBUyxRQUFRLE9BQU8sT0FBTztHQUMvQixTQUFTLEtBQUs7R0FDZCxXQUFXLGtCQUFrQixRQUFRLFNBQVMsS0FBSyxNQUFNO0VBQzFEO0NBQ0Q7Ozs7OztDQU1BLGVBQWU7RUFDZCxNQUFNLGFBQWEsS0FBSztFQUN4QixNQUFNLGFBQWEsS0FBSyxhQUFhLEtBQUssZUFBZSxLQUFLLE9BQU87RUFDckUsS0FBSyxzQkFBc0IsS0FBSyxjQUFjO0VBQzlDLEtBQUssd0JBQXdCLEtBQUs7RUFDbEMsSUFBSSxLQUFLLG9CQUFvQixTQUFTLEtBQUssR0FBRyxLQUFLLDRCQUE0QixLQUFLO0VBQ3BGLElBQUksb0JBQW9CLFlBQVksVUFBVSxHQUFHO0VBQ2pELEtBQUssaUJBQWlCO0VBQ3RCLE1BQU0sOEJBQThCO0dBQ25DLElBQUksQ0FBQyxZQUFZLE9BQU87R0FDeEIsTUFBTSxFQUFFLHdCQUF3QixLQUFLO0dBQ3JDLE1BQU0sMkJBQTJCLE9BQU8sd0JBQXdCLGFBQWEsb0JBQW9CLElBQUk7R0FDckcsSUFBSSw2QkFBNkIsU0FBUyxDQUFDLDRCQUE0QixDQUFDLEtBQUssY0FBYyxNQUFNLE9BQU87R0FDeEcsSUFBSSxLQUFLLFFBQVEsZ0JBQWdCLEtBQUssZUFBZSxVQUFVLFdBQVcsT0FBTyxPQUFPO0dBQ3hGLEtBQUssTUFBTSxPQUFPLDRCQUE0QixLQUFLLGVBQWUsSUFBSSxLQUFLLGVBQWUsU0FBUyxXQUFXLE1BQU0sT0FBTztHQUMzSCxPQUFPO0VBQ1I7RUFDQSxNQUFNLGtCQUFrQixzQkFBc0I7RUFDOUMsY0FBYyxZQUFZO0dBQ3pCLElBQUksaUJBQWlCLEtBQUssVUFBVSxTQUFTLGFBQWE7SUFDekQsU0FBUyxLQUFLLGNBQWM7R0FDN0IsQ0FBQztHQUNELEtBQUssUUFBUSxjQUFjLENBQUMsQ0FBQyxPQUFPO0lBQ25DLE9BQU8sS0FBSztJQUNaLE1BQU07R0FDUCxDQUFDO0VBQ0YsQ0FBQztDQUNGO0NBQ0EsZUFBZTtFQUNkLE1BQU0sUUFBUSxLQUFLLFFBQVEsY0FBYyxDQUFDLENBQUMsTUFBTSxLQUFLLFNBQVMsS0FBSyxPQUFPO0VBQzNFLElBQUksVUFBVSxLQUFLLGVBQWU7RUFDbEMsTUFBTSxZQUFZLEtBQUs7RUFDdkIsS0FBSyxnQkFBZ0I7RUFDckIsS0FBSyw0QkFBNEIsTUFBTTtFQUN2QyxJQUFJLEtBQUssYUFBYSxHQUFHO0dBQ3hCLFdBQVcsZUFBZSxJQUFJO0dBQzlCLE1BQU0sWUFBWSxJQUFJO0VBQ3ZCO0NBQ0Q7Ozs7OztDQU1BLGdCQUFnQjtFQUNmLEtBQUssYUFBYTtFQUNsQixJQUFJLEtBQUssYUFBYSxHQUFHLEtBQUssY0FBYztDQUM3QztBQUNEOzs7Ozs7OztBQVFBLFNBQVMsa0JBQWtCLE9BQU8sU0FBUztDQUMxQyxPQUFPLGtCQUFrQixRQUFRLFNBQVMsS0FBSyxNQUFNLFNBQVMsTUFBTSxNQUFNLFNBQVMsS0FBSyxLQUFLLEVBQUUsTUFBTSxNQUFNLFdBQVcsV0FBVyxrQkFBa0IsUUFBUSxjQUFjLEtBQUssTUFBTTtBQUNyTDs7Ozs7Ozs7QUFRQSxTQUFTLG1CQUFtQixPQUFPLFNBQVM7Q0FDM0MsT0FBTyxrQkFBa0IsT0FBTyxPQUFPLEtBQUssTUFBTSxNQUFNLFNBQVMsS0FBSyxLQUFLLGNBQWMsT0FBTyxTQUFTLFFBQVEsY0FBYztBQUNoSTs7Ozs7Ozs7OztBQVVBLFNBQVMsY0FBYyxPQUFPLFNBQVMsT0FBTztDQUM3QyxJQUFJLGtCQUFrQixRQUFRLFNBQVMsS0FBSyxNQUFNLFNBQVMsa0JBQWtCLFFBQVEsV0FBVyxLQUFLLE1BQU0sVUFBVTtFQUNwSCxNQUFNLFFBQVEsa0JBQWtCLE9BQU8sS0FBSztFQUM1QyxPQUFPLFVBQVUsWUFBWSxVQUFVLFNBQVMsUUFBUSxPQUFPLE9BQU87Q0FDdkU7Q0FDQSxPQUFPO0FBQ1I7Ozs7Ozs7Ozs7QUFVQSxTQUFTLHNCQUFzQixPQUFPLFdBQVcsU0FBUyxhQUFhO0NBQ3RFLFFBQVEsVUFBVSxhQUFhLGtCQUFrQixZQUFZLFNBQVMsS0FBSyxNQUFNLFdBQVcsQ0FBQyxRQUFRLFlBQVksTUFBTSxNQUFNLFdBQVcsWUFBWSxRQUFRLE9BQU8sT0FBTztBQUMzSzs7Ozs7OztBQU9BLFNBQVMsUUFBUSxPQUFPLFNBQVM7Q0FDaEMsT0FBTyxrQkFBa0IsUUFBUSxTQUFTLEtBQUssTUFBTSxTQUFTLE1BQU0sY0FBYyxrQkFBa0IsUUFBUSxXQUFXLEtBQUssQ0FBQztBQUM5SDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNoZkEsSUFBSSx3QkFBd0IsY0FBYyxjQUFjO0NBQ3ZELFlBQVksUUFBUSxTQUFTO0VBQzVCLE1BQU0sUUFBUSxPQUFPO0NBQ3RCO0NBQ0EsY0FBYztFQUNiLE1BQU0sWUFBWTtFQUNsQixLQUFLLGdCQUFnQixLQUFLLGNBQWMsS0FBSyxJQUFJO0VBQ2pELEtBQUssb0JBQW9CLEtBQUssa0JBQWtCLEtBQUssSUFBSTtDQUMxRDs7Ozs7Ozs7Q0FRQSxXQUFXLFNBQVM7RUFDbkIsUUFBUSxRQUFRO0VBQ2hCLE1BQU0sV0FBVyxPQUFPO0NBQ3pCOzs7Ozs7Ozs7Q0FTQSxvQkFBb0IsU0FBUztFQUM1QixRQUFRLFFBQVE7RUFDaEIsT0FBTyxNQUFNLG9CQUFvQixPQUFPO0NBQ3pDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FxQkEsY0FBYyxTQUFTO0VBQ3RCLE9BQU8sS0FBSyxNQUFNO0dBQ2pCLEdBQUc7R0FDSCxNQUFNLEVBQUUsV0FBVyxFQUFFLFdBQVcsVUFBVSxFQUFFO0VBQzdDLENBQUM7Q0FDRjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBcUJBLGtCQUFrQixTQUFTO0VBQzFCLE9BQU8sS0FBSyxNQUFNO0dBQ2pCLEdBQUc7R0FDSCxNQUFNLEVBQUUsV0FBVyxFQUFFLFdBQVcsV0FBVyxFQUFFO0VBQzlDLENBQUM7Q0FDRjtDQUNBLGFBQWEsT0FBTyxTQUFTO0VBQzVCLE1BQU0sRUFBRSxVQUFVO0VBQ2xCLE1BQU0sZUFBZSxNQUFNLGFBQWEsT0FBTyxPQUFPO0VBQ3RELE1BQU0sRUFBRSxZQUFZLGNBQWMsU0FBUyxtQkFBbUI7RUFDOUQsTUFBTSxpQkFBaUIsTUFBTSxXQUFXLFdBQVc7RUFDbkQsTUFBTSx1QkFBdUIsV0FBVyxtQkFBbUI7RUFDM0QsTUFBTSxxQkFBcUIsY0FBYyxtQkFBbUI7RUFDNUQsTUFBTSwyQkFBMkIsV0FBVyxtQkFBbUI7RUFDL0QsTUFBTSx5QkFBeUIsY0FBYyxtQkFBbUI7RUFDaEUsT0FBTztHQUNOLEdBQUc7R0FDSCxlQUFlLEtBQUs7R0FDcEIsbUJBQW1CLEtBQUs7R0FDeEIsYUFBYSxZQUFZLFNBQVMsTUFBTSxJQUFJO0dBQzVDLGlCQUFpQixnQkFBZ0IsU0FBUyxNQUFNLElBQUk7R0FDcEQ7R0FDQTtHQUNBO0dBQ0E7R0FDQSxnQkFBZ0Isa0JBQWtCLENBQUMsd0JBQXdCLENBQUM7R0FDNUQsY0FBYyxnQkFBZ0IsQ0FBQyxzQkFBc0IsQ0FBQztFQUN2RDtDQUNEO0FBQ0Q7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQzVHQSxJQUFJLFdBQVcsY0FBYyxVQUFVO0NBQ3RDO0NBQ0E7Q0FDQTtDQUNBO0NBQ0EsWUFBWSxRQUFRO0VBQ25CLE1BQU07RUFDTixLQUFLLFVBQVUsT0FBTztFQUN0QixLQUFLLGFBQWEsT0FBTztFQUN6QixLQUFLLGlCQUFpQixPQUFPO0VBQzdCLEtBQUssYUFBYSxDQUFDO0VBQ25CLEtBQUssUUFBUSxPQUFPLFNBQVMsZ0JBQWdCO0VBQzdDLEtBQUssV0FBVyxPQUFPLE9BQU87RUFDOUIsS0FBSyxXQUFXO0NBQ2pCOzs7Ozs7Q0FNQSxXQUFXLFNBQVM7RUFDbkIsS0FBSyxVQUFVO0VBQ2YsS0FBSyxhQUFhLEtBQUssUUFBUSxNQUFNO0NBQ3RDOzs7OztDQUtBLElBQUksT0FBTztFQUNWLE9BQU8sS0FBSyxRQUFRO0NBQ3JCOzs7Ozs7O0NBT0EsWUFBWSxVQUFVO0VBQ3JCLElBQUksQ0FBQyxLQUFLLFdBQVcsU0FBUyxRQUFRLEdBQUc7R0FDeEMsS0FBSyxXQUFXLEtBQUssUUFBUTtHQUM3QixLQUFLLGVBQWU7R0FDcEIsS0FBSyxlQUFlLE9BQU87SUFDMUIsTUFBTTtJQUNOLFVBQVU7SUFDVjtHQUNELENBQUM7RUFDRjtDQUNEOzs7Ozs7Q0FNQSxlQUFlLFVBQVU7RUFDeEIsS0FBSyxhQUFhLEtBQUssV0FBVyxRQUFRLE1BQU0sTUFBTSxRQUFRO0VBQzlELEtBQUssV0FBVztFQUNoQixLQUFLLGVBQWUsT0FBTztHQUMxQixNQUFNO0dBQ04sVUFBVTtHQUNWO0VBQ0QsQ0FBQztDQUNGO0NBQ0EsaUJBQWlCO0VBQ2hCLElBQUksQ0FBQyxLQUFLLFdBQVcsUUFBUTtHQUM1QixJQUFJLEtBQUssTUFBTSxXQUFXLFdBQVcsS0FBSyxXQUFXO1FBQ2hELEtBQUssZUFBZSxPQUFPLElBQUk7RUFDckM7Q0FDRDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQXNCQSxXQUFXO0VBQ1YsT0FBTyxLQUFLLFVBQVUsU0FBUyxNQUFNLEtBQUssTUFBTSxXQUFXLFlBQVksS0FBSyxRQUFRLEtBQUssTUFBTSxTQUFTLElBQUksUUFBUSxRQUFRO0NBQzdIOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBK0JBLE1BQU0sUUFBUSxXQUFXO0VBQ3hCLE1BQU0sbUJBQW1CO0dBQ3hCLEtBQUssVUFBVSxFQUFFLE1BQU0sV0FBVyxDQUFDO0VBQ3BDO0VBQ0EsTUFBTSxvQkFBb0I7R0FDekIsUUFBUSxLQUFLO0dBQ2IsTUFBTSxLQUFLLFFBQVE7R0FDbkIsYUFBYSxLQUFLLFFBQVE7RUFDM0I7RUFDQSxNQUFNLFVBQVUsS0FBSyxXQUFXLGNBQWM7R0FDN0MsVUFBVTtJQUNULElBQUksQ0FBQyxLQUFLLFFBQVEsWUFBWSxPQUFPLFFBQVEsdUJBQXVCLElBQUksTUFBTSxxQkFBcUIsQ0FBQztJQUNwRyxPQUFPLEtBQUssUUFBUSxXQUFXLFdBQVcsaUJBQWlCO0dBQzVEO0dBQ0EsU0FBUyxjQUFjLFVBQVU7SUFDaEMsS0FBSyxVQUFVO0tBQ2QsTUFBTTtLQUNOO0tBQ0E7SUFDRCxDQUFDO0dBQ0Y7R0FDQSxlQUFlO0lBQ2QsS0FBSyxVQUFVLEVBQUUsTUFBTSxRQUFRLENBQUM7R0FDakM7R0FDQTtHQUNBLE9BQU8sS0FBSyxRQUFRLFNBQVM7R0FDN0IsWUFBWSxLQUFLLFFBQVE7R0FDekIsYUFBYSxLQUFLLFFBQVE7R0FDMUIsY0FBYyxLQUFLLGVBQWUsT0FBTyxJQUFJO0VBQzlDLENBQUM7RUFDRCxNQUFNLFdBQVcsS0FBSyxNQUFNLFdBQVc7RUFDdkMsTUFBTSxXQUFXLENBQUMsUUFBUSxTQUFTO0VBQ25DLElBQUk7R0FDSCxJQUFJLFVBQVUsV0FBVztRQUNwQjtJQUNKLEtBQUssVUFBVTtLQUNkLE1BQU07S0FDTjtLQUNBO0lBQ0QsQ0FBQztJQUNELElBQUksS0FBSyxlQUFlLE9BQU8sVUFBVSxNQUFNLEtBQUssZUFBZSxPQUFPLFNBQVMsV0FBVyxNQUFNLGlCQUFpQjtJQUNySCxNQUFNLFVBQVUsTUFBTSxLQUFLLFFBQVEsV0FBVyxXQUFXLGlCQUFpQjtJQUMxRSxJQUFJLFlBQVksS0FBSyxNQUFNLFNBQVMsS0FBSyxVQUFVO0tBQ2xELE1BQU07S0FDTjtLQUNBO0tBQ0E7SUFDRCxDQUFDO0dBQ0Y7R0FDQSxJQUFJLEtBQUssTUFBTSxZQUFZLFFBQVEsU0FBUyxHQUFHLFdBQVc7R0FDMUQsTUFBTSxPQUFPLE1BQU0sUUFBUSxNQUFNO0dBQ2pDLE1BQU0sS0FBSyxlQUFlLE9BQU8sWUFBWSxNQUFNLFdBQVcsS0FBSyxNQUFNLFNBQVMsTUFBTSxpQkFBaUI7R0FDekcsTUFBTSxLQUFLLFFBQVEsWUFBWSxNQUFNLFdBQVcsS0FBSyxNQUFNLFNBQVMsaUJBQWlCO0dBQ3JGLE1BQU0sS0FBSyxlQUFlLE9BQU8sWUFBWSxNQUFNLE1BQU0sS0FBSyxNQUFNLFdBQVcsS0FBSyxNQUFNLFNBQVMsTUFBTSxpQkFBaUI7R0FDMUgsTUFBTSxLQUFLLFFBQVEsWUFBWSxNQUFNLE1BQU0sV0FBVyxLQUFLLE1BQU0sU0FBUyxpQkFBaUI7R0FDM0YsS0FBSyxVQUFVO0lBQ2QsTUFBTTtJQUNOO0dBQ0QsQ0FBQztHQUNELE9BQU87RUFDUixTQUFTLE9BQU87R0FDZixJQUFJO0lBQ0gsTUFBTSxLQUFLLGVBQWUsT0FBTyxVQUFVLE9BQU8sV0FBVyxLQUFLLE1BQU0sU0FBUyxNQUFNLGlCQUFpQjtHQUN6RyxTQUFTLEdBQUc7SUFDWCxRQUFRLE9BQU8sQ0FBQztHQUNqQjtHQUNBLElBQUk7SUFDSCxNQUFNLEtBQUssUUFBUSxVQUFVLE9BQU8sV0FBVyxLQUFLLE1BQU0sU0FBUyxpQkFBaUI7R0FDckYsU0FBUyxHQUFHO0lBQ1gsUUFBUSxPQUFPLENBQUM7R0FDakI7R0FDQSxJQUFJO0lBQ0gsTUFBTSxLQUFLLGVBQWUsT0FBTyxZQUFZLEtBQUssR0FBRyxPQUFPLEtBQUssTUFBTSxXQUFXLEtBQUssTUFBTSxTQUFTLE1BQU0saUJBQWlCO0dBQzlILFNBQVMsR0FBRztJQUNYLFFBQVEsT0FBTyxDQUFDO0dBQ2pCO0dBQ0EsSUFBSTtJQUNILE1BQU0sS0FBSyxRQUFRLFlBQVksS0FBSyxHQUFHLE9BQU8sV0FBVyxLQUFLLE1BQU0sU0FBUyxpQkFBaUI7R0FDL0YsU0FBUyxHQUFHO0lBQ1gsUUFBUSxPQUFPLENBQUM7R0FDakI7R0FDQSxLQUFLLFVBQVU7SUFDZCxNQUFNO0lBQ047R0FDRCxDQUFDO0dBQ0QsTUFBTTtFQUNQLFVBQVU7R0FDVCxJQUFJLEtBQUssYUFBYSxTQUFTLEtBQUssV0FBVyxLQUFLO0dBQ3BELEtBQUssZUFBZSxRQUFRLElBQUk7RUFDakM7Q0FDRDtDQUNBLFVBQVUsUUFBUTtFQUNqQixNQUFNLFdBQVcsVUFBVTtHQUMxQixRQUFRLE9BQU8sTUFBZjtJQUNDLEtBQUssVUFBVSxPQUFPO0tBQ3JCLEdBQUc7S0FDSCxjQUFjLE9BQU87S0FDckIsZUFBZSxPQUFPO0lBQ3ZCO0lBQ0EsS0FBSyxTQUFTLE9BQU87S0FDcEIsR0FBRztLQUNILFVBQVU7SUFDWDtJQUNBLEtBQUssWUFBWSxPQUFPO0tBQ3ZCLEdBQUc7S0FDSCxVQUFVO0lBQ1g7SUFDQSxLQUFLLFdBQVcsT0FBTztLQUN0QixHQUFHO0tBQ0gsU0FBUyxPQUFPO0tBQ2hCLE1BQU0sS0FBSztLQUNYLGNBQWM7S0FDZCxlQUFlO0tBQ2YsT0FBTztLQUNQLFVBQVUsT0FBTztLQUNqQixRQUFRO0tBQ1IsV0FBVyxPQUFPO0tBQ2xCLGFBQWEsS0FBSyxJQUFJO0lBQ3ZCO0lBQ0EsS0FBSyxXQUFXLE9BQU87S0FDdEIsR0FBRztLQUNILE1BQU0sT0FBTztLQUNiLGNBQWM7S0FDZCxlQUFlO0tBQ2YsT0FBTztLQUNQLFFBQVE7S0FDUixVQUFVO0lBQ1g7SUFDQSxLQUFLLFNBQVMsT0FBTztLQUNwQixHQUFHO0tBQ0gsTUFBTSxLQUFLO0tBQ1gsT0FBTyxPQUFPO0tBQ2QsY0FBYyxNQUFNLGVBQWU7S0FDbkMsZUFBZSxPQUFPO0tBQ3RCLFVBQVU7S0FDVixRQUFRO0lBQ1Q7R0FDRDtFQUNEO0VBQ0EsS0FBSyxRQUFRLFFBQVEsS0FBSyxLQUFLO0VBQy9CLGNBQWMsWUFBWTtHQUN6QixLQUFLLFdBQVcsU0FBUyxhQUFhO0lBQ3JDLFNBQVMsaUJBQWlCLE1BQU07R0FDakMsQ0FBQztHQUNELEtBQUssZUFBZSxPQUFPO0lBQzFCLFVBQVU7SUFDVixNQUFNO0lBQ047R0FDRCxDQUFDO0VBQ0YsQ0FBQztDQUNGO0FBQ0Q7Ozs7O0FBS0EsU0FBUyxrQkFBa0I7Q0FDMUIsT0FBTztFQUNOLFNBQVMsS0FBSztFQUNkLE1BQU0sS0FBSztFQUNYLE9BQU87RUFDUCxjQUFjO0VBQ2QsZUFBZTtFQUNmLFVBQVU7RUFDVixRQUFRO0VBQ1IsV0FBVyxLQUFLO0VBQ2hCLGFBQWE7Q0FDZDtBQUNEOzs7Ozs7Ozs7Ozs7Ozs7QUNwU0EsSUFBSSxnQkFBZ0IsY0FBYyxhQUFhO0NBQzlDO0NBQ0E7Q0FDQTtDQUNBLFlBQVksU0FBUyxDQUFDLEdBQUc7RUFDeEIsTUFBTTtFQUNOLEtBQUssU0FBUztFQUNkLEtBQUssNkJBQTZCLElBQUksSUFBSTtFQUMxQyxLQUFLLDBCQUEwQixJQUFJLElBQUk7RUFDdkMsS0FBSyxjQUFjO0NBQ3BCOzs7Ozs7Ozs7O0NBVUEsTUFBTSxRQUFRLFNBQVMsT0FBTztFQUM3QixNQUFNLFdBQVcsSUFBSSxTQUFTO0dBQzdCO0dBQ0EsZUFBZTtHQUNmLFlBQVksRUFBRSxLQUFLO0dBQ25CLFNBQVMsT0FBTyx1QkFBdUIsT0FBTztHQUM5QztFQUNELENBQUM7RUFDRCxLQUFLLElBQUksUUFBUTtFQUNqQixPQUFPO0NBQ1I7Ozs7OztDQU1BLElBQUksVUFBVTtFQUNiLEtBQUssV0FBVyxJQUFJLFFBQVE7RUFDNUIsTUFBTSxRQUFRLFNBQVMsUUFBUTtFQUMvQixJQUFJLE9BQU8sVUFBVSxVQUFVO0dBQzlCLE1BQU0sa0JBQWtCLEtBQUssUUFBUSxJQUFJLEtBQUs7R0FDOUMsSUFBSSxpQkFBaUIsZ0JBQWdCLEtBQUssUUFBUTtRQUM3QyxLQUFLLFFBQVEsSUFBSSxPQUFPLENBQUMsUUFBUSxDQUFDO0VBQ3hDO0VBQ0EsS0FBSyxPQUFPO0dBQ1gsTUFBTTtHQUNOO0VBQ0QsQ0FBQztDQUNGOzs7Ozs7Q0FNQSxPQUFPLFVBQVU7RUFDaEIsSUFBSSxLQUFLLFdBQVcsT0FBTyxRQUFRLEdBQUc7R0FDckMsTUFBTSxRQUFRLFNBQVMsUUFBUTtHQUMvQixJQUFJLE9BQU8sVUFBVSxVQUFVO0lBQzlCLE1BQU0sa0JBQWtCLEtBQUssUUFBUSxJQUFJLEtBQUs7SUFDOUMsSUFBSSxpQkFBaUI7S0FDcEIsSUFBSSxnQkFBZ0IsU0FBUyxHQUFHO01BQy9CLE1BQU0sUUFBUSxnQkFBZ0IsUUFBUSxRQUFRO01BQzlDLElBQUksVUFBVSxJQUFJLGdCQUFnQixPQUFPLE9BQU8sQ0FBQztLQUNsRCxPQUFPLElBQUksZ0JBQWdCLE9BQU8sVUFBVSxLQUFLLFFBQVEsT0FBTyxLQUFLO0lBQ3RFO0dBQ0Q7RUFDRDtFQUNBLEtBQUssT0FBTztHQUNYLE1BQU07R0FDTjtFQUNELENBQUM7Q0FDRjs7Ozs7Ozs7Q0FRQSxPQUFPLFVBQVU7RUFDaEIsTUFBTSxRQUFRLFNBQVMsUUFBUTtFQUMvQixJQUFJLE9BQU8sVUFBVSxVQUFVO0dBQzlCLE1BQU0sdUJBQXVCLEtBQUssUUFBUSxJQUFJLEtBQUssQ0FBQyxFQUFFLE1BQU0sTUFBTSxFQUFFLE1BQU0sV0FBVyxTQUFTO0dBQzlGLE9BQU8sQ0FBQyx3QkFBd0IseUJBQXlCO0VBQzFELE9BQU8sT0FBTztDQUNmOzs7Ozs7OztDQVFBLFFBQVEsVUFBVTtFQUNqQixNQUFNLFFBQVEsU0FBUyxRQUFRO0VBQy9CLElBQUksT0FBTyxVQUFVLFVBQVUsUUFBUSxLQUFLLFFBQVEsSUFBSSxLQUFLLENBQUMsRUFBRSxNQUFNLE1BQU0sTUFBTSxZQUFZLEVBQUUsTUFBTSxRQUFRLEVBQUEsRUFBSSxTQUFTLEtBQUssUUFBUSxRQUFRO09BQzNJLE9BQU8sUUFBUSxRQUFRO0NBQzdCOzs7Ozs7Ozs7O0NBVUEsUUFBUTtFQUNQLGNBQWMsWUFBWTtHQUN6QixNQUFNLFlBQVksS0FBSyxPQUFPO0dBQzlCLEtBQUssV0FBVyxNQUFNO0dBQ3RCLEtBQUssUUFBUSxNQUFNO0dBQ25CLFVBQVUsU0FBUyxhQUFhO0lBQy9CLEtBQUssT0FBTztLQUNYLE1BQU07S0FDTjtJQUNELENBQUM7R0FDRixDQUFDO0VBQ0YsQ0FBQztDQUNGOzs7Ozs7Ozs7Ozs7OztDQWNBLFNBQVM7RUFDUixPQUFPLE1BQU0sS0FBSyxLQUFLLFVBQVU7Q0FDbEM7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBaUJBLEtBQUssU0FBUztFQUNiLE1BQU0sbUJBQW1CO0dBQ3hCLE9BQU87R0FDUCxHQUFHO0VBQ0o7RUFDQSxPQUFPLEtBQUssT0FBTyxDQUFDLENBQUMsTUFBTSxhQUFhLGNBQWMsa0JBQWtCLFFBQVEsQ0FBQztDQUNsRjs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FpQkEsUUFBUSxVQUFVLENBQUMsR0FBRztFQUNyQixPQUFPLEtBQUssT0FBTyxDQUFDLENBQUMsUUFBUSxhQUFhLGNBQWMsU0FBUyxRQUFRLENBQUM7Q0FDM0U7Ozs7OztDQU1BLE9BQU8sT0FBTztFQUNiLGNBQWMsWUFBWTtHQUN6QixLQUFLLFVBQVUsU0FBUyxhQUFhO0lBQ3BDLFNBQVMsS0FBSztHQUNmLENBQUM7RUFDRixDQUFDO0NBQ0Y7Ozs7OztDQU1BLHdCQUF3QjtFQUN2QixNQUFNLGtCQUFrQixLQUFLLE9BQU8sQ0FBQyxDQUFDLFFBQVEsTUFBTSxFQUFFLE1BQU0sUUFBUTtFQUNwRSxPQUFPLGNBQWMsWUFBWSxRQUFRLElBQUksZ0JBQWdCLEtBQUssYUFBYSxTQUFTLFNBQVMsQ0FBQyxDQUFDLE1BQU0sSUFBSSxDQUFDLENBQUMsQ0FBQztDQUNqSDtBQUNEOzs7Ozs7QUFNQSxTQUFTLFNBQVMsVUFBVTtDQUMzQixPQUFPLFNBQVMsUUFBUSxPQUFPO0FBQ2hDOzs7Ozs7Ozs7Ozs7Ozs7O0FDOU1BLElBQUksbUJBQW1CLGNBQWMsYUFBYTtDQUNqRDtDQUNBLGlCQUFpQixLQUFLO0NBQ3RCO0NBQ0E7Q0FDQSxZQUFZLFFBQVEsU0FBUztFQUM1QixNQUFNO0VBQ04sS0FBSyxVQUFVO0VBQ2YsS0FBSyxXQUFXLE9BQU87RUFDdkIsS0FBSyxZQUFZO0VBQ2pCLEtBQUssY0FBYztDQUNwQjs7Ozs7Q0FLQSxjQUFjO0VBQ2IsS0FBSyxTQUFTLEtBQUssT0FBTyxLQUFLLElBQUk7RUFDbkMsS0FBSyxRQUFRLEtBQUssTUFBTSxLQUFLLElBQUk7Q0FDbEM7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQWtCQSxXQUFXLFNBQVM7RUFDbkIsTUFBTSxjQUFjLEtBQUs7RUFDekIsS0FBSyxVQUFVLEtBQUssUUFBUSx1QkFBdUIsT0FBTztFQUMxRCxJQUFJLENBQUMsb0JBQW9CLEtBQUssU0FBUyxXQUFXLEdBQUcsS0FBSyxRQUFRLGlCQUFpQixDQUFDLENBQUMsT0FBTztHQUMzRixNQUFNO0dBQ04sVUFBVSxLQUFLO0dBQ2YsVUFBVTtFQUNYLENBQUM7RUFDRCxJQUFJLGFBQWEsZUFBZSxLQUFLLFFBQVEsZUFBZSxRQUFRLFlBQVksV0FBVyxNQUFNLFFBQVEsS0FBSyxRQUFRLFdBQVcsR0FBRyxLQUFLLE1BQU07T0FDMUksSUFBSSxLQUFLLGtCQUFrQixNQUFNLFdBQVcsV0FBVyxLQUFLLGlCQUFpQixXQUFXLEtBQUssT0FBTztDQUMxRztDQUNBLGNBQWM7RUFDYixJQUFJLEtBQUssVUFBVSxTQUFTLEtBQUssS0FBSyxrQkFBa0I7R0FDdkQsS0FBSyxpQkFBaUIsWUFBWSxJQUFJO0dBQ3RDLEtBQUssY0FBYztFQUNwQjtDQUNEO0NBQ0EsZ0JBQWdCO0VBQ2YsSUFBSSxDQUFDLEtBQUssYUFBYSxHQUFHLEtBQUssa0JBQWtCLGVBQWUsSUFBSTtDQUNyRTs7Ozs7OztDQU9BLGlCQUFpQixRQUFRO0VBQ3hCLEtBQUssY0FBYztFQUNuQixLQUFLLFFBQVEsTUFBTTtDQUNwQjs7Ozs7OztDQU9BLG1CQUFtQjtFQUNsQixPQUFPLEtBQUs7Q0FDYjs7Ozs7Ozs7Ozs7Ozs7O0NBZUEsUUFBUTtFQUNQLEtBQUssa0JBQWtCLGVBQWUsSUFBSTtFQUMxQyxLQUFLLG1CQUFtQixLQUFLO0VBQzdCLEtBQUssY0FBYztFQUNuQixLQUFLLFFBQVE7Q0FDZDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBcUJBLE9BQU8sV0FBVyxTQUFTO0VBQzFCLEtBQUssaUJBQWlCO0VBQ3RCLEtBQUssa0JBQWtCLGVBQWUsSUFBSTtFQUMxQyxLQUFLLG1CQUFtQixLQUFLLFFBQVEsaUJBQWlCLENBQUMsQ0FBQyxNQUFNLEtBQUssU0FBUyxLQUFLLE9BQU87RUFDeEYsS0FBSyxpQkFBaUIsWUFBWSxJQUFJO0VBQ3RDLE9BQU8sS0FBSyxpQkFBaUIsUUFBUSxTQUFTO0NBQy9DO0NBQ0EsZ0JBQWdCO0VBQ2YsTUFBTSxRQUFRLEtBQUssa0JBQWtCLFNBQVMsZ0JBQWdCO0VBQzlELEtBQUssaUJBQWlCO0dBQ3JCLEdBQUc7R0FDSCxXQUFXLE1BQU0sV0FBVztHQUM1QixXQUFXLE1BQU0sV0FBVztHQUM1QixTQUFTLE1BQU0sV0FBVztHQUMxQixRQUFRLE1BQU0sV0FBVztHQUN6QixRQUFRLEtBQUs7R0FDYixPQUFPLEtBQUs7RUFDYjtDQUNEO0NBQ0EsUUFBUSxRQUFRO0VBQ2YsY0FBYyxZQUFZO0dBQ3pCLE1BQU0sZ0JBQWdCLEtBQUs7R0FDM0IsSUFBSSxpQkFBaUIsS0FBSyxhQUFhLEdBQUc7SUFDekMsTUFBTSxZQUFZLEtBQUssZUFBZTtJQUN0QyxNQUFNLGlCQUFpQixLQUFLLGVBQWU7SUFDM0MsTUFBTSxVQUFVO0tBQ2YsUUFBUSxLQUFLO0tBQ2IsTUFBTSxLQUFLLFFBQVE7S0FDbkIsYUFBYSxLQUFLLFFBQVE7SUFDM0I7SUFDQSxJQUFJLFFBQVEsU0FBUyxXQUFXO0tBQy9CLElBQUk7TUFDSCxjQUFjLFlBQVksT0FBTyxNQUFNLFdBQVcsZ0JBQWdCLE9BQU87S0FDMUUsU0FBUyxHQUFHO01BQ1gsUUFBUSxPQUFPLENBQUM7S0FDakI7S0FDQSxJQUFJO01BQ0gsY0FBYyxZQUFZLE9BQU8sTUFBTSxNQUFNLFdBQVcsZ0JBQWdCLE9BQU87S0FDaEYsU0FBUyxHQUFHO01BQ1gsUUFBUSxPQUFPLENBQUM7S0FDakI7SUFDRCxPQUFPLElBQUksUUFBUSxTQUFTLFNBQVM7S0FDcEMsSUFBSTtNQUNILGNBQWMsVUFBVSxPQUFPLE9BQU8sV0FBVyxnQkFBZ0IsT0FBTztLQUN6RSxTQUFTLEdBQUc7TUFDWCxRQUFRLE9BQU8sQ0FBQztLQUNqQjtLQUNBLElBQUk7TUFDSCxjQUFjLFlBQVksS0FBSyxHQUFHLE9BQU8sT0FBTyxXQUFXLGdCQUFnQixPQUFPO0tBQ25GLFNBQVMsR0FBRztNQUNYLFFBQVEsT0FBTyxDQUFDO0tBQ2pCO0lBQ0Q7R0FDRDtHQUNBLEtBQUssVUFBVSxTQUFTLGFBQWE7SUFDcEMsU0FBUyxLQUFLLGNBQWM7R0FDN0IsQ0FBQztFQUNGLENBQUM7Q0FDRjtBQUNEOzs7Ozs7OztBQ3ZMQSxTQUFTLFdBQVcsUUFBUSxRQUFRO0NBQ25DLE1BQU0sYUFBYSxJQUFJLElBQUksTUFBTTtDQUNqQyxPQUFPLE9BQU8sUUFBUSxNQUFNLENBQUMsV0FBVyxJQUFJLENBQUMsQ0FBQztBQUMvQzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQW1CQSxJQUFJLGtCQUFrQixjQUFjLGFBQWE7Q0FDaEQ7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0EsbUJBQW1CLENBQUM7Q0FDcEIsWUFBWSxRQUFRLFNBQVMsU0FBUztFQUNyQyxNQUFNO0VBQ04sS0FBSyxVQUFVO0VBQ2YsS0FBSyxXQUFXO0VBQ2hCLEtBQUssV0FBVyxDQUFDO0VBQ2pCLEtBQUssYUFBYSxDQUFDO0VBQ25CLEtBQUssVUFBVSxDQUFDO0VBQ2hCLEtBQUssV0FBVyxPQUFPO0NBQ3hCO0NBQ0EsY0FBYztFQUNiLElBQUksS0FBSyxVQUFVLFNBQVMsR0FBRyxLQUFLLFdBQVcsU0FBUyxhQUFhO0dBQ3BFLFNBQVMsV0FBVyxXQUFXO0lBQzlCLEtBQUssVUFBVSxVQUFVLE1BQU07R0FDaEMsQ0FBQztFQUNGLENBQUM7Q0FDRjtDQUNBLGdCQUFnQjtFQUNmLElBQUksQ0FBQyxLQUFLLFVBQVUsTUFBTSxLQUFLLFFBQVE7Q0FDeEM7Ozs7O0NBS0EsVUFBVTtFQUNULEtBQUssNEJBQTRCLElBQUksSUFBSTtFQUN6QyxLQUFLLFdBQVcsU0FBUyxhQUFhO0dBQ3JDLFNBQVMsUUFBUTtFQUNsQixDQUFDO0NBQ0Y7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FnQkEsV0FBVyxTQUFTLFNBQVM7RUFDNUIsS0FBSyxXQUFXO0VBQ2hCLEtBQUssV0FBVztFQUMyQjtHQUMxQyxNQUFNLGNBQWMsUUFBUSxLQUFLLFVBQVUsS0FBSyxRQUFRLG9CQUFvQixLQUFLLENBQUMsQ0FBQyxTQUFTO0dBQzVGLElBQUksSUFBSSxJQUFJLFdBQVcsQ0FBQyxDQUFDLFNBQVMsWUFBWSxRQUFRLFFBQVEsS0FBSyx1RkFBdUY7RUFDM0o7RUFDQSxjQUFjLFlBQVk7R0FDekIsTUFBTSxnQkFBZ0IsS0FBSztHQUMzQixNQUFNLHFCQUFxQixLQUFLLHVCQUF1QixLQUFLLFFBQVE7R0FDcEUsbUJBQW1CLFNBQVMsVUFBVSxNQUFNLFNBQVMsV0FBVyxNQUFNLHFCQUFxQixDQUFDO0dBQzVGLE1BQU0sZUFBZSxtQkFBbUIsS0FBSyxVQUFVLE1BQU0sUUFBUTtHQUNyRSxNQUFNLFlBQVksYUFBYSxLQUFLLGFBQWEsU0FBUyxpQkFBaUIsQ0FBQztHQUM1RSxNQUFNLGtCQUFrQixjQUFjLFdBQVcsYUFBYTtHQUM5RCxNQUFNLGlCQUFpQixhQUFhLE1BQU0sVUFBVSxVQUFVLGFBQWEsY0FBYyxNQUFNO0dBQy9GLE1BQU0sc0JBQXNCLG1CQUFtQjtHQUMvQyxNQUFNLGtCQUFrQixzQkFBc0IsT0FBTyxVQUFVLE1BQU0sUUFBUSxVQUFVO0lBQ3RGLE1BQU0sT0FBTyxLQUFLLFFBQVE7SUFDMUIsT0FBTyxDQUFDLFFBQVEsQ0FBQyxvQkFBb0IsUUFBUSxJQUFJO0dBQ2xELENBQUM7R0FDRCxJQUFJLENBQUMsdUJBQXVCLENBQUMsaUJBQWlCO0dBQzlDLElBQUkscUJBQXFCO0lBQ3hCLEtBQUssbUJBQW1CO0lBQ3hCLEtBQUssYUFBYTtHQUNuQjtHQUNBLEtBQUssVUFBVTtHQUNmLElBQUksQ0FBQyxLQUFLLGFBQWEsR0FBRztHQUMxQixJQUFJLHFCQUFxQjtJQUN4QixXQUFXLGVBQWUsWUFBWSxDQUFDLENBQUMsU0FBUyxhQUFhO0tBQzdELFNBQVMsUUFBUTtJQUNsQixDQUFDO0lBQ0QsV0FBVyxjQUFjLGFBQWEsQ0FBQyxDQUFDLFNBQVMsYUFBYTtLQUM3RCxTQUFTLFdBQVcsV0FBVztNQUM5QixLQUFLLFVBQVUsVUFBVSxNQUFNO0tBQ2hDLENBQUM7SUFDRixDQUFDO0dBQ0Y7R0FDQSxLQUFLLFFBQVE7RUFDZCxDQUFDO0NBQ0Y7Ozs7Ozs7Ozs7OztDQVlBLG1CQUFtQjtFQUNsQixPQUFPLEtBQUs7Q0FDYjs7Ozs7O0NBTUEsYUFBYTtFQUNaLE9BQU8sS0FBSyxXQUFXLEtBQUssYUFBYSxTQUFTLGdCQUFnQixDQUFDO0NBQ3BFOzs7Ozs7O0NBT0EsZUFBZTtFQUNkLE9BQU8sS0FBSztDQUNiOzs7Ozs7Ozs7Ozs7Q0FZQSxvQkFBb0IsU0FBUyxTQUFTO0VBQ3JDLE1BQU0sVUFBVSxLQUFLLHVCQUF1QixPQUFPO0VBQ25ELE1BQU0sU0FBUyxRQUFRLEtBQUssVUFBVSxNQUFNLFNBQVMsb0JBQW9CLE1BQU0scUJBQXFCLENBQUM7RUFDckcsTUFBTSxjQUFjLFFBQVEsS0FBSyxVQUFVLE1BQU0sc0JBQXNCLFNBQVM7RUFDaEYsT0FBTztHQUNOO0lBQ0MsTUFBTTtJQUNOLE9BQU8sS0FBSyxlQUFlLEtBQUssUUFBUSxTQUFTLFdBQVc7R0FDN0Q7U0FDTTtJQUNMLE9BQU8sS0FBSyxhQUFhLFFBQVEsT0FBTztHQUN6QztFQUNEO0NBQ0Q7Q0FDQSxhQUFhLFFBQVEsU0FBUztFQUM3QixNQUFNLCtCQUErQixJQUFJLElBQUk7RUFDN0MsT0FBTyxRQUFRLEtBQUssT0FBTyxVQUFVO0dBQ3BDLE1BQU0saUJBQWlCLE9BQU87R0FDOUIsT0FBTyxDQUFDLE1BQU0sc0JBQXNCLHNCQUFzQixNQUFNLFNBQVMsWUFBWSxpQkFBaUIsaUJBQWlCO0lBQ3RILElBQUksQ0FBQyxhQUFhLElBQUksWUFBWSxHQUFHO0tBQ3BDLGFBQWEsSUFBSSxZQUFZO0tBQzdCLFFBQVEsU0FBUyxNQUFNO01BQ3RCLEVBQUUsU0FBUyxVQUFVLFlBQVk7S0FDbEMsQ0FBQztJQUNGO0dBQ0QsQ0FBQyxJQUFJO0VBQ04sQ0FBQztDQUNGO0NBQ0EsZUFBZSxPQUFPLFNBQVMsYUFBYTtFQUMzQyxJQUFJLFNBQVM7R0FDWixNQUFNLGFBQWEsS0FBSztHQUN4QixNQUFNLHFCQUFxQixnQkFBZ0IsS0FBSyxLQUFLLGVBQWUsS0FBSyxNQUFNLFdBQVcsV0FBVyxZQUFZLFVBQVUsWUFBWSxNQUFNLE1BQU0sTUFBTSxTQUFTLFdBQVcsRUFBRTtHQUMvSyxJQUFJLEtBQUssWUFBWSxLQUFLLGVBQWUsc0JBQXNCLFlBQVksS0FBSyxjQUFjO0lBQzdGLEtBQUssZUFBZTtJQUNwQixLQUFLLGNBQWMsS0FBSztJQUN4QixJQUFJLGdCQUFnQixLQUFLLEdBQUcsS0FBSyxtQkFBbUI7SUFDcEQsS0FBSyxrQkFBa0IsaUJBQWlCLEtBQUssaUJBQWlCLFFBQVEsS0FBSyxDQUFDO0dBQzdFO0dBQ0EsT0FBTyxLQUFLO0VBQ2I7RUFDQSxPQUFPO0NBQ1I7Q0FDQSxxQkFBcUI7RUFDcEIsT0FBTyxDQUFDLEtBQUssVUFBVSxXQUFXLEtBQUssV0FBVyxNQUFNLFVBQVUsVUFBVTtHQUMzRSxPQUFPLFNBQVMsUUFBUSxZQUFZLEtBQUssUUFBUSxNQUFNLEVBQUUsU0FBUyxLQUFLO0VBQ3hFLENBQUM7Q0FDRjtDQUNBLHVCQUF1QixTQUFTO0VBQy9CLE1BQU0sbUNBQW1DLElBQUksSUFBSTtFQUNqRCxLQUFLLFdBQVcsU0FBUyxhQUFhO0dBQ3JDLE1BQU0sTUFBTSxTQUFTLFFBQVE7R0FDN0IsSUFBSSxDQUFDLEtBQUs7R0FDVixNQUFNLG9CQUFvQixpQkFBaUIsSUFBSSxHQUFHO0dBQ2xELElBQUksbUJBQW1CLGtCQUFrQixLQUFLLFFBQVE7UUFDakQsaUJBQWlCLElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQztFQUMxQyxDQUFDO0VBQ0QsTUFBTSxZQUFZLENBQUM7RUFDbkIsUUFBUSxTQUFTLFlBQVk7R0FDNUIsTUFBTSxtQkFBbUIsS0FBSyxRQUFRLG9CQUFvQixPQUFPO0dBQ2pFLE1BQU0sV0FBVyxpQkFBaUIsSUFBSSxpQkFBaUIsU0FBUyxDQUFDLEVBQUUsTUFBTSxLQUFLLElBQUksY0FBYyxLQUFLLFNBQVMsZ0JBQWdCO0dBQzlILFVBQVUsS0FBSztJQUNkLHVCQUF1QjtJQUN2QjtHQUNELENBQUM7RUFDRixDQUFDO0VBQ0QsT0FBTztDQUNSO0NBQ0EsVUFBVSxVQUFVLFFBQVE7RUFDM0IsTUFBTSxRQUFRLEtBQUssV0FBVyxRQUFRLFFBQVE7RUFDOUMsSUFBSSxVQUFVLElBQUk7R0FDakIsS0FBSyxVQUFVLEtBQUssUUFBUSxNQUFNO0dBQ2xDLEtBQUssUUFBUSxTQUFTO0dBQ3RCLEtBQUssUUFBUTtFQUNkO0NBQ0Q7Q0FDQSxVQUFVO0VBQ1QsSUFBSSxLQUFLLGFBQWEsR0FBRztHQUN4QixNQUFNLG9CQUFvQixLQUFLLG1CQUFtQjtHQUNsRCxNQUFNLGlCQUFpQixLQUFLO0dBQzVCLE1BQU0sWUFBWSxvQkFBb0IsaUJBQWlCLEtBQUssZUFBZSxLQUFLLGFBQWEsS0FBSyxTQUFTLEtBQUssZ0JBQWdCLEdBQUcsS0FBSyxVQUFVLE9BQU87R0FDekosSUFBSSxxQkFBcUIsbUJBQW1CLFdBQVcsY0FBYyxZQUFZO0lBQ2hGLEtBQUssVUFBVSxTQUFTLGFBQWE7S0FDcEMsU0FBUyxLQUFLLE9BQU87SUFDdEIsQ0FBQztHQUNGLENBQUM7RUFDRjtDQUNEO0FBQ0Q7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQzVPQSxJQUFJLGFBQWEsY0FBYyxhQUFhO0NBQzNDO0NBQ0EsWUFBWSxTQUFTLENBQUMsR0FBRztFQUN4QixNQUFNO0VBQ04sS0FBSyxTQUFTO0VBQ2QsS0FBSywyQkFBMkIsSUFBSSxJQUFJO0NBQ3pDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBc0JBLE1BQU0sUUFBUSxTQUFTLE9BQU87RUFDN0IsTUFBTSxXQUFXLFFBQVE7RUFDekIsTUFBTSxZQUFZLFFBQVEsYUFBYSxzQkFBc0IsVUFBVSxPQUFPO0VBQzlFLElBQUksUUFBUSxLQUFLLElBQUksU0FBUztFQUM5QixJQUFJLENBQUMsT0FBTztHQUNYLFFBQVEsSUFBSSxNQUFNO0lBQ2pCO0lBQ0E7SUFDQTtJQUNBLFNBQVMsT0FBTyxvQkFBb0IsT0FBTztJQUMzQztJQUNBLGdCQUFnQixPQUFPLGlCQUFpQixRQUFRO0dBQ2pELENBQUM7R0FDRCxLQUFLLElBQUksS0FBSztFQUNmO0VBQ0EsT0FBTztDQUNSOzs7Ozs7O0NBT0EsSUFBSSxPQUFPO0VBQ1YsSUFBSSxDQUFDLEtBQUssU0FBUyxJQUFJLE1BQU0sU0FBUyxHQUFHO0dBQ3hDLEtBQUssU0FBUyxJQUFJLE1BQU0sV0FBVyxLQUFLO0dBQ3hDLEtBQUssT0FBTztJQUNYLE1BQU07SUFDTjtHQUNELENBQUM7RUFDRjtDQUNEOzs7Ozs7Ozs7Ozs7Ozs7OztDQWlCQSxPQUFPLE9BQU87RUFDYixJQUFJLEtBQUssU0FBUyxJQUFJLE1BQU0sU0FBUyxNQUFNLE9BQU87R0FDakQsTUFBTSxRQUFRO0dBQ2QsS0FBSyxTQUFTLE9BQU8sTUFBTSxTQUFTO0dBQ3BDLEtBQUssT0FBTztJQUNYLE1BQU07SUFDTjtHQUNELENBQUM7RUFDRjtDQUNEOzs7Ozs7Ozs7O0NBVUEsUUFBUTtFQUNQLGNBQWMsWUFBWTtHQUN6QixLQUFLLE9BQU8sQ0FBQyxDQUFDLFNBQVMsVUFBVTtJQUNoQyxLQUFLLE9BQU8sS0FBSztHQUNsQixDQUFDO0VBQ0YsQ0FBQztDQUNGOzs7Ozs7Ozs7Ozs7Ozs7O0NBZ0JBLElBQUksV0FBVztFQUNkLE9BQU8sS0FBSyxTQUFTLElBQUksU0FBUztDQUNuQzs7Ozs7Ozs7Ozs7Q0FXQSxTQUFTO0VBQ1IsT0FBTyxDQUFDLEdBQUcsS0FBSyxTQUFTLE9BQU8sQ0FBQztDQUNsQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBcUJBLEtBQUssU0FBUztFQUNiLE1BQU0sbUJBQW1CO0dBQ3hCLE9BQU87R0FDUCxHQUFHO0VBQ0o7RUFDQSxPQUFPLEtBQUssT0FBTyxDQUFDLENBQUMsTUFBTSxVQUFVLFdBQVcsa0JBQWtCLEtBQUssQ0FBQztDQUN6RTs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FpQkEsUUFBUSxVQUFVLENBQUMsR0FBRztFQUNyQixNQUFNLFVBQVUsS0FBSyxPQUFPO0VBQzVCLE9BQU8sT0FBTyxLQUFLLE9BQU8sQ0FBQyxDQUFDLFNBQVMsSUFBSSxRQUFRLFFBQVEsVUFBVSxXQUFXLFNBQVMsS0FBSyxDQUFDLElBQUk7Q0FDbEc7Ozs7OztDQU1BLE9BQU8sT0FBTztFQUNiLGNBQWMsWUFBWTtHQUN6QixLQUFLLFVBQVUsU0FBUyxhQUFhO0lBQ3BDLFNBQVMsS0FBSztHQUNmLENBQUM7RUFDRixDQUFDO0NBQ0Y7Ozs7O0NBS0EsVUFBVTtFQUNULGNBQWMsWUFBWTtHQUN6QixLQUFLLE9BQU8sQ0FBQyxDQUFDLFNBQVMsVUFBVTtJQUNoQyxNQUFNLFFBQVE7R0FDZixDQUFDO0VBQ0YsQ0FBQztDQUNGOzs7OztDQUtBLFdBQVc7RUFDVixjQUFjLFlBQVk7R0FDekIsS0FBSyxPQUFPLENBQUMsQ0FBQyxTQUFTLFVBQVU7SUFDaEMsTUFBTSxTQUFTO0dBQ2hCLENBQUM7RUFDRixDQUFDO0NBQ0Y7QUFDRDs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ25OQSxJQUFJLGNBQWMsTUFBTTtDQUN2QjtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0EsWUFBWSxTQUFTLENBQUMsR0FBRztFQUN4QixLQUFLLGNBQWMsT0FBTyxjQUFjLElBQUksV0FBVztFQUN2RCxLQUFLLGlCQUFpQixPQUFPLGlCQUFpQixJQUFJLGNBQWM7RUFDaEUsS0FBSyxrQkFBa0IsT0FBTyxrQkFBa0IsQ0FBQztFQUNqRCxLQUFLLGlDQUFpQyxJQUFJLElBQUk7RUFDOUMsS0FBSyxvQ0FBb0MsSUFBSSxJQUFJO0VBQ2pELEtBQUssY0FBYztDQUNwQjs7Ozs7OztDQU9BLFFBQVE7RUFDUCxLQUFLO0VBQ0wsSUFBSSxLQUFLLGdCQUFnQixHQUFHO0VBQzVCLEtBQUssb0JBQW9CLGFBQWEsVUFBVSxPQUFPLFlBQVk7R0FDbEUsSUFBSSxTQUFTO0lBQ1osTUFBTSxLQUFLLHNCQUFzQjtJQUNqQyxLQUFLLFlBQVksUUFBUTtHQUMxQjtFQUNELENBQUM7RUFDRCxLQUFLLHFCQUFxQixjQUFjLFVBQVUsT0FBTyxXQUFXO0dBQ25FLElBQUksUUFBUTtJQUNYLE1BQU0sS0FBSyxzQkFBc0I7SUFDakMsS0FBSyxZQUFZLFNBQVM7R0FDM0I7RUFDRCxDQUFDO0NBQ0Y7Ozs7OztDQU1BLFVBQVU7RUFDVCxLQUFLO0VBQ0wsSUFBSSxLQUFLLGdCQUFnQixHQUFHO0VBQzVCLEtBQUssb0JBQW9CO0VBQ3pCLEtBQUssb0JBQW9CLEtBQUs7RUFDOUIsS0FBSyxxQkFBcUI7RUFDMUIsS0FBSyxxQkFBcUIsS0FBSztDQUNoQzs7Ozs7Ozs7Ozs7Ozs7O0NBZUEsV0FBVyxTQUFTO0VBQ25CLE9BQU8sS0FBSyxZQUFZLFFBQVE7R0FDL0IsR0FBRztHQUNILGFBQWE7RUFDZCxDQUFDLENBQUMsQ0FBQztDQUNKOzs7Ozs7Ozs7Ozs7OztDQWNBLFdBQVcsU0FBUztFQUNuQixPQUFPLEtBQUssZUFBZSxRQUFRO0dBQ2xDLEdBQUc7R0FDSCxRQUFRO0VBQ1QsQ0FBQyxDQUFDLENBQUM7Q0FDSjs7Ozs7Ozs7Ozs7Q0FXQSxhQUFhLFVBQVU7RUFDdEIsTUFBTSxVQUFVLEtBQUssb0JBQW9CLEVBQUUsU0FBUyxDQUFDO0VBQ3JELE9BQU8sS0FBSyxZQUFZLElBQUksUUFBUSxTQUFTLENBQUMsRUFBRSxNQUFNO0NBQ3ZEOzs7Ozs7Ozs7O0NBVUEsZ0JBQWdCLFNBQVM7RUFDeEIsTUFBTSxtQkFBbUIsS0FBSyxvQkFBb0IsT0FBTztFQUN6RCxNQUFNLFFBQVEsS0FBSyxZQUFZLE1BQU0sTUFBTSxnQkFBZ0I7RUFDM0QsTUFBTSxhQUFhLE1BQU0sTUFBTTtFQUMvQixJQUFJLGVBQWUsS0FBSyxHQUFHLE9BQU8sS0FBSyxXQUFXLE9BQU87RUFDekQsSUFBSSxRQUFRLHFCQUFxQixNQUFNLGNBQWMsa0JBQWtCLGlCQUFpQixXQUFXLEtBQUssQ0FBQyxHQUFHLEtBQUssY0FBYyxnQkFBZ0I7RUFDL0ksT0FBTyxRQUFRLFFBQVEsVUFBVTtDQUNsQzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQW1CQSxlQUFlLFNBQVM7RUFDdkIsT0FBTyxLQUFLLFlBQVksUUFBUSxPQUFPLENBQUMsQ0FBQyxLQUFLLEVBQUUsVUFBVSxZQUFZO0dBQ3JFLE9BQU8sQ0FBQyxVQUFVLE1BQU0sSUFBSTtFQUM3QixDQUFDO0NBQ0Y7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBdUJBLGFBQWEsVUFBVSxTQUFTLFNBQVM7RUFDeEMsTUFBTSxtQkFBbUIsS0FBSyxvQkFBb0IsRUFBRSxTQUFTLENBQUM7RUFDOUQsTUFBTSxXQUFXLEtBQUssWUFBWSxJQUFJLGlCQUFpQixTQUFTLENBQUMsRUFBRSxNQUFNO0VBQ3pFLE1BQU0sT0FBTyxpQkFBaUIsU0FBUyxRQUFRO0VBQy9DLElBQUksU0FBUyxLQUFLLEdBQUc7RUFDckIsT0FBTyxLQUFLLFlBQVksTUFBTSxNQUFNLGdCQUFnQixDQUFDLENBQUMsUUFBUSxNQUFNO0dBQ25FLEdBQUc7R0FDSCxRQUFRO0VBQ1QsQ0FBQztDQUNGOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBbUJBLGVBQWUsU0FBUyxTQUFTLFNBQVM7RUFDekMsT0FBTyxjQUFjLFlBQVksS0FBSyxZQUFZLFFBQVEsT0FBTyxDQUFDLENBQUMsS0FBSyxFQUFFLGVBQWUsQ0FBQyxVQUFVLEtBQUssYUFBYSxVQUFVLFNBQVMsT0FBTyxDQUFDLENBQUMsQ0FBQztDQUNwSjs7Ozs7Ozs7Ozs7O0NBWUEsY0FBYyxVQUFVO0VBQ3ZCLE1BQU0sVUFBVSxLQUFLLG9CQUFvQixFQUFFLFNBQVMsQ0FBQztFQUNyRCxPQUFPLEtBQUssWUFBWSxJQUFJLFFBQVEsU0FBUyxDQUFDLEVBQUU7Q0FDakQ7Ozs7Ozs7Ozs7Ozs7Q0FhQSxjQUFjLFNBQVM7RUFDdEIsTUFBTSxhQUFhLEtBQUs7RUFDeEIsY0FBYyxZQUFZO0dBQ3pCLFdBQVcsUUFBUSxPQUFPLENBQUMsQ0FBQyxTQUFTLFVBQVU7SUFDOUMsV0FBVyxPQUFPLEtBQUs7R0FDeEIsQ0FBQztFQUNGLENBQUM7Q0FDRjs7Ozs7Ozs7Ozs7Ozs7O0NBZUEsYUFBYSxTQUFTLFNBQVM7RUFDOUIsTUFBTSxhQUFhLEtBQUs7RUFDeEIsT0FBTyxjQUFjLFlBQVk7R0FDaEMsTUFBTSxVQUFVLFdBQVcsUUFBUSxPQUFPO0dBQzFDLE1BQU0sbUJBQW1CLElBQUksSUFBSSxPQUFPO0dBQ3hDLFFBQVEsU0FBUyxVQUFVO0lBQzFCLE1BQU0sTUFBTTtHQUNiLENBQUM7R0FDRCxPQUFPLEtBQUssZUFBZTtJQUMxQixNQUFNO0lBQ04sWUFBWSxVQUFVLGlCQUFpQixJQUFJLEtBQUs7R0FDakQsR0FBRyxPQUFPO0VBQ1gsQ0FBQztDQUNGOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FrQkEsY0FBYyxTQUFTLGdCQUFnQixDQUFDLEdBQUc7RUFDMUMsTUFBTSx5QkFBeUI7R0FDOUIsUUFBUTtHQUNSLEdBQUc7RUFDSjtFQUNBLE1BQU0sV0FBVyxjQUFjLFlBQVksS0FBSyxZQUFZLFFBQVEsT0FBTyxDQUFDLENBQUMsS0FBSyxVQUFVLE1BQU0sT0FBTyxzQkFBc0IsQ0FBQyxDQUFDO0VBQ2pJLE9BQU8sUUFBUSxJQUFJLFFBQVEsQ0FBQyxDQUFDLEtBQUssSUFBSSxDQUFDLENBQUMsTUFBTSxJQUFJO0NBQ25EOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBbUJBLGtCQUFrQixTQUFTLFVBQVUsQ0FBQyxHQUFHO0VBQ3hDLE9BQU8sY0FBYyxZQUFZO0dBQ2hDLEtBQUssWUFBWSxRQUFRLE9BQU8sQ0FBQyxDQUFDLFNBQVMsVUFBVTtJQUNwRCxNQUFNLFdBQVc7R0FDbEIsQ0FBQztHQUNELElBQUksU0FBUyxnQkFBZ0IsUUFBUSxPQUFPLFFBQVEsUUFBUTtHQUM1RCxPQUFPLEtBQUssZUFBZTtJQUMxQixHQUFHO0lBQ0gsTUFBTSxTQUFTLGVBQWUsU0FBUyxRQUFRO0dBQ2hELEdBQUcsT0FBTztFQUNYLENBQUM7Q0FDRjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBd0JBLGVBQWUsU0FBUyxVQUFVLENBQUMsR0FBRztFQUNyQyxNQUFNLGVBQWU7R0FDcEIsR0FBRztHQUNILGVBQWUsUUFBUSxpQkFBaUI7RUFDekM7RUFDQSxNQUFNLFdBQVcsY0FBYyxZQUFZLEtBQUssWUFBWSxRQUFRLE9BQU8sQ0FBQyxDQUFDLFFBQVEsVUFBVSxDQUFDLE1BQU0sV0FBVyxLQUFLLENBQUMsTUFBTSxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssVUFBVTtHQUN2SixJQUFJLFVBQVUsTUFBTSxNQUFNLEtBQUssR0FBRyxZQUFZO0dBQzlDLE1BQU0sV0FBVyxNQUFNLE1BQU0sZ0JBQWdCO0dBQzdDLElBQUksQ0FBQyxhQUFhLGdCQUFnQixVQUFVLFVBQVUsUUFBUSxNQUFNLElBQUk7R0FDeEUsT0FBTyxXQUFXLFFBQVEsUUFBUSxJQUFJO0VBQ3ZDLENBQUMsQ0FBQztFQUNGLE9BQU8sUUFBUSxJQUFJLFFBQVEsQ0FBQyxDQUFDLEtBQUssSUFBSTtDQUN2Qzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FtQ0EsTUFBTSxNQUFNLFNBQVM7RUFDcEIsTUFBTSxtQkFBbUIsS0FBSyxvQkFBb0IsT0FBTztFQUN6RCxJQUFJLGlCQUFpQixVQUFVLEtBQUssR0FBRyxpQkFBaUIsUUFBUTtFQUNoRSxNQUFNLFFBQVEsS0FBSyxZQUFZLE1BQU0sTUFBTSxnQkFBZ0I7RUFDM0QsTUFBTSxZQUFZLE1BQU0sY0FBYyxrQkFBa0IsaUJBQWlCLFdBQVcsS0FBSyxDQUFDLElBQUksTUFBTSxNQUFNLE1BQU0sZ0JBQWdCLElBQUksTUFBTSxNQUFNO0VBQ2hKLE1BQU0sU0FBUyxpQkFBaUI7RUFDaEMsSUFBSSxRQUFRLE9BQU8sT0FBTyxTQUFTO0VBQ25DLE9BQU87Q0FDUjs7Ozs7Ozs7OztDQVVBLFdBQVcsU0FBUztFQUNuQixNQUFNLG1CQUFtQixLQUFLLG9CQUFvQixPQUFPO0VBQ3pELElBQUksaUJBQWlCLFVBQVUsS0FBSyxHQUFHLGlCQUFpQixRQUFRO0VBQ2hFLE1BQU0sUUFBUSxLQUFLLFlBQVksTUFBTSxNQUFNLGdCQUFnQjtFQUMzRCxPQUFPLE1BQU0sY0FBYyxrQkFBa0IsaUJBQWlCLFdBQVcsS0FBSyxDQUFDLElBQUksTUFBTSxNQUFNLGdCQUFnQixJQUFJLFFBQVEsUUFBUSxNQUFNLE1BQU0sSUFBSTtDQUNwSjs7Ozs7Ozs7O0NBU0EsY0FBYyxTQUFTO0VBQ3RCLE9BQU8sS0FBSyxXQUFXLE9BQU8sQ0FBQyxDQUFDLEtBQUssSUFBSSxDQUFDLENBQUMsTUFBTSxJQUFJO0NBQ3REOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBeUJBLGNBQWMsU0FBUztFQUN0QixRQUFRLFFBQVE7RUFDaEIsT0FBTyxLQUFLLE1BQU0sT0FBTztDQUMxQjs7Ozs7Ozs7O0NBU0EsbUJBQW1CLFNBQVM7RUFDM0IsUUFBUSxRQUFRO0VBQ2hCLE9BQU8sS0FBSyxXQUFXLE9BQU87Q0FDL0I7Ozs7Ozs7OztDQVNBLHNCQUFzQixTQUFTO0VBQzlCLE9BQU8sS0FBSyxtQkFBbUIsT0FBTyxDQUFDLENBQUMsS0FBSyxJQUFJLENBQUMsQ0FBQyxNQUFNLElBQUk7Q0FDOUQ7Ozs7Ozs7Ozs7Q0FVQSx3QkFBd0IsU0FBUztFQUNoQyxRQUFRLFFBQVE7RUFDaEIsT0FBTyxLQUFLLGdCQUFnQixPQUFPO0NBQ3BDOzs7Ozs7Ozs7Ozs7O0NBYUEsd0JBQXdCO0VBQ3ZCLElBQUksY0FBYyxTQUFTLEdBQUcsT0FBTyxLQUFLLGVBQWUsc0JBQXNCO0VBQy9FLE9BQU8sUUFBUSxRQUFRO0NBQ3hCOzs7Ozs7Ozs7Ozs7O0NBYUEsZ0JBQWdCO0VBQ2YsT0FBTyxLQUFLO0NBQ2I7Ozs7Ozs7Ozs7Ozs7Q0FhQSxtQkFBbUI7RUFDbEIsT0FBTyxLQUFLO0NBQ2I7Ozs7Ozs7Ozs7Ozs7Q0FhQSxvQkFBb0I7RUFDbkIsT0FBTyxLQUFLO0NBQ2I7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQWtCQSxrQkFBa0IsU0FBUztFQUMxQixLQUFLLGtCQUFrQjtDQUN4Qjs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FpQkEsaUJBQWlCLFVBQVUsU0FBUztFQUNuQyxLQUFLLGVBQWUsSUFBSSxRQUFRLFFBQVEsR0FBRztHQUMxQztHQUNBLGdCQUFnQjtFQUNqQixDQUFDO0NBQ0Y7Ozs7Ozs7Ozs7Ozs7Q0FhQSxpQkFBaUIsVUFBVTtFQUMxQixNQUFNLFdBQVcsQ0FBQyxHQUFHLEtBQUssZUFBZSxPQUFPLENBQUM7RUFDakQsTUFBTSxTQUFTLENBQUM7RUFDaEIsU0FBUyxTQUFTLGlCQUFpQjtHQUNsQyxJQUFJLGdCQUFnQixVQUFVLGFBQWEsUUFBUSxHQUFHLE9BQU8sT0FBTyxRQUFRLGFBQWEsY0FBYztFQUN4RyxDQUFDO0VBQ0QsT0FBTztDQUNSOzs7Ozs7Ozs7Ozs7O0NBYUEsb0JBQW9CLGFBQWEsU0FBUztFQUN6QyxLQUFLLGtCQUFrQixJQUFJLFFBQVEsV0FBVyxHQUFHO0dBQ2hEO0dBQ0EsZ0JBQWdCO0VBQ2pCLENBQUM7Q0FDRjs7Ozs7Ozs7Ozs7OztDQWFBLG9CQUFvQixhQUFhO0VBQ2hDLE1BQU0sV0FBVyxDQUFDLEdBQUcsS0FBSyxrQkFBa0IsT0FBTyxDQUFDO0VBQ3BELE1BQU0sU0FBUyxDQUFDO0VBQ2hCLFNBQVMsU0FBUyxpQkFBaUI7R0FDbEMsSUFBSSxnQkFBZ0IsYUFBYSxhQUFhLFdBQVcsR0FBRyxPQUFPLE9BQU8sUUFBUSxhQUFhLGNBQWM7RUFDOUcsQ0FBQztFQUNELE9BQU87Q0FDUjs7Ozs7Ozs7OztDQVVBLG9CQUFvQixTQUFTO0VBQzVCLElBQUksUUFBUSxZQUFZLE9BQU87RUFDL0IsTUFBTSxtQkFBbUI7R0FDeEIsR0FBRyxLQUFLLGdCQUFnQjtHQUN4QixHQUFHLEtBQUssaUJBQWlCLFFBQVEsUUFBUTtHQUN6QyxHQUFHO0dBQ0gsWUFBWTtFQUNiO0VBQ0EsSUFBSSxDQUFDLGlCQUFpQixXQUFXLGlCQUFpQixZQUFZLHNCQUFzQixpQkFBaUIsVUFBVSxnQkFBZ0I7RUFDL0gsSUFBSSxpQkFBaUIsdUJBQXVCLEtBQUssR0FBRyxpQkFBaUIscUJBQXFCLGlCQUFpQixnQkFBZ0I7RUFDM0gsSUFBSSxpQkFBaUIsaUJBQWlCLEtBQUssR0FBRyxpQkFBaUIsZUFBZSxDQUFDLENBQUMsaUJBQWlCO0VBQ2pHLElBQUksQ0FBQyxpQkFBaUIsZUFBZSxpQkFBaUIsV0FBVyxpQkFBaUIsY0FBYztFQUNoRyxJQUFJLGlCQUFpQixZQUFZLFdBQVcsaUJBQWlCLFVBQVU7RUFDdkUsT0FBTztDQUNSOzs7Ozs7Ozs7Q0FTQSx1QkFBdUIsU0FBUztFQUMvQixJQUFJLFNBQVMsWUFBWSxPQUFPO0VBQ2hDLE9BQU87R0FDTixHQUFHLEtBQUssZ0JBQWdCO0dBQ3hCLEdBQUcsU0FBUyxlQUFlLEtBQUssb0JBQW9CLFFBQVEsV0FBVztHQUN2RSxHQUFHO0dBQ0gsWUFBWTtFQUNiO0NBQ0Q7Ozs7Ozs7Ozs7O0NBV0EsUUFBUTtFQUNQLEtBQUssWUFBWSxNQUFNO0VBQ3ZCLEtBQUssZUFBZSxNQUFNO0NBQzNCO0FBQ0Q7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUMvckJBLFNBQVMsY0FBYyxFQUFFLFVBQVUsY0FBYyxTQUFTLFdBQVcsT0FBTyxVQUFVLFNBQVMsT0FBTyxLQUFLLEdBQUcsZUFBZSxDQUFDLEtBQUs7Q0FDbEksT0FBTyxPQUFPLFlBQVk7RUFDekIsTUFBTSxTQUFTLFFBQVE7RUFDdkIsSUFBSSxRQUFRLFNBQVMsT0FBTztFQUM1QixNQUFNLFFBQVEsUUFBUSxPQUFPLGNBQWMsQ0FBQyxDQUFDLEtBQUs7R0FDakQsVUFBVSxRQUFRO0dBQ2xCLE9BQU87RUFDUixDQUFDO0VBQ0QsTUFBTSxZQUFZLENBQUMsQ0FBQyxTQUFTLE1BQU0sVUFBVTtFQUM3QyxJQUFJLGFBQWEsZ0JBQWdCLFNBQVMsTUFBTSxTQUFTO0dBQ3hELEdBQUcsTUFBTTtHQUNULGFBQWE7RUFDZCxDQUFDO0VBQ0QsSUFBSSxTQUFTO0VBQ2IsSUFBSSxZQUFZO0VBQ2hCLE1BQU0sa0JBQWtCLHNCQUFzQjtHQUM3QyxRQUFRLFFBQVE7R0FDaEIsTUFBTSxRQUFRO0dBQ2QsVUFBVSxRQUFRO0dBQ2xCLFdBQVcsUUFBUTtHQUNuQixXQUFXLFFBQVE7RUFDcEIsU0FBUyxRQUFRLGNBQWMsWUFBWSxNQUFNLE1BQU07RUFDdkQsTUFBTSx5QkFBeUIsYUFBYSxRQUFRLFlBQVk7RUFDaEUsTUFBTSxTQUFTLE1BQU0sU0FBUyxlQUFlO0VBQzdDLE1BQU0sbUJBQW1CLGFBQWEsZ0JBQWdCO0VBQ3RELFdBQVcsTUFBTSxTQUFTLFFBQVE7R0FDakMsSUFBSSxpQkFBaUIsR0FBRztHQUN4QixJQUFJLGtCQUFrQixTQUFTLFFBQVEsUUFBUSxLQUFLO1FBQy9DLFFBQVEsT0FBTyxhQUFhLFFBQVEsV0FBVyxTQUFTLFFBQVEsU0FBUyxLQUFLLElBQUksZUFBZSxNQUFNLEtBQUssQ0FBQztFQUNuSDtFQUNBLElBQUksb0JBQW9CLENBQUMsaUJBQWlCLEdBQUcsUUFBUSxPQUFPLGFBQWEsUUFBUSxVQUFVLE1BQU07RUFDakcsTUFBTSxPQUFPLFFBQVEsT0FBTyxhQUFhLFFBQVEsUUFBUTtFQUN6RCxPQUFPLFNBQVMsS0FBSyxJQUFJLGVBQWU7Q0FDekM7QUFDRDs7O0FDdERBLElBQU0sZ0JBQWdCLE9BQU87QUFDN0IsSUFBTSxxQkFBcUIsT0FBTztBQUNsQyxJQUFNLGNBQWMsT0FBTzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUMyQzNCLElBQU0scUJBQXFCLEVBQUUsVUFBVSxVQUFVLENBQUMsR0FBRyxPQUFPLGtCQUFrQjtDQUM3RSxNQUFNLFNBQVMsZUFBZSxXQUFXO0NBQ3pDLE1BQU0sYUFBQSxhQUFtQixPQUFPLE9BQU87Q0FDdkMsYUFBTSxnQkFBZ0I7RUFDckIsV0FBVyxVQUFVO0NBQ3RCLENBQUM7Q0FDRCxNQUFNLGlCQUFBLGFBQXVCLGNBQWM7RUFDMUMsSUFBSSxPQUFPO0dBQ1YsSUFBSSxPQUFPLFVBQVUsVUFBVTtHQUMvQixNQUFNLGFBQWEsT0FBTyxjQUFjO0dBQ3hDLE1BQU0sVUFBVSxNQUFNLFdBQVcsQ0FBQztHQUNsQyxNQUFNLGFBQWEsQ0FBQztHQUNwQixNQUFNLGtCQUFrQixDQUFDO0dBQ3pCLEtBQUssTUFBTSxtQkFBbUIsU0FBUztJQUN0QyxNQUFNLGdCQUFnQixXQUFXLElBQUksZ0JBQWdCLFNBQVM7SUFDOUQsSUFBSSxDQUFDLGVBQWUsV0FBVyxLQUFLLGVBQWU7U0FDOUMsSUFBSSxnQkFBZ0IsTUFBTSxnQkFBZ0IsY0FBYyxNQUFNLGlCQUFpQixnQkFBZ0IsV0FBVyxjQUFjLE1BQU0sV0FBVyxhQUFhLGNBQWMsTUFBTSxnQkFBZ0IsY0FBYyxnQkFBZ0IsZUFBZSxjQUFjLE1BQU0sZUFBZSxnQkFBZ0IsS0FBSyxlQUFlO0dBQ3BUO0dBQ0EsSUFBSSxXQUFXLFNBQVMsR0FBRyxRQUFRLFFBQVEsRUFBRSxTQUFTLFdBQVcsR0FBRyxXQUFXLE9BQU87R0FDdEYsSUFBSSxnQkFBZ0IsU0FBUyxHQUFHLE9BQU87RUFDeEM7Q0FDRCxHQUFHLENBQUMsUUFBUSxLQUFLLENBQUM7Q0FDbEIsYUFBTSxnQkFBZ0I7RUFDckIsSUFBSSxnQkFBZ0IsUUFBUSxRQUFRLEVBQUUsU0FBUyxlQUFlLEdBQUcsV0FBVyxPQUFPO0NBQ3BGLEdBQUcsQ0FBQyxRQUFRLGNBQWMsQ0FBQztDQUMzQixPQUFPO0FBQ1I7O0FDdEVBLElBQU0scUJBQUEsYUFBMkIsY0FBYyxLQUFLOzs7Ozs7O0FBT3BELElBQU0sdUJBQUEsYUFBNkIsV0FBVyxrQkFBa0I7Ozs7O0FBS2hFLElBQU0sc0JBQXNCLG1CQUFtQjs7Ozs7OztBQ04vQyxTQUFTLGNBQWM7Q0FDdEIsSUFBSSxVQUFVO0NBQ2QsT0FBTzs7OztFQUlOLGtCQUFrQjtHQUNqQixVQUFVO0VBQ1g7Ozs7RUFJQSxhQUFhO0dBQ1osVUFBVTtFQUNYOzs7OztFQUtBLGVBQWU7R0FDZCxPQUFPO0VBQ1I7Q0FDRDtBQUNEO0FBQ0EsSUFBTSxpQ0FBQSxhQUF1QyxjQUFjLFlBQVksQ0FBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUE2QnhFLElBQU0sbUNBQUEsYUFBeUMsV0FBVyw4QkFBOEI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFrQ3hGLElBQU0sMkJBQTJCLEVBQUUsZUFBZTtDQUNqRCxNQUFNLENBQUMsU0FBQSxhQUFlLGVBQWUsWUFBWSxDQUFDO0NBQ2xELE9BQXVCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFJLCtCQUErQixVQUFVO0VBQ25FO0VBQ0EsVUFBVSxPQUFPLGFBQWEsYUFBYSxTQUFTLEtBQUssSUFBSTtDQUM5RCxDQUFDO0FBQ0Y7Ozs7Ozs7Ozs7QUMxRkEsSUFBTSxtQ0FBbUMsU0FBUyxvQkFBb0IsVUFBVTtDQUMvRSxNQUFNLGVBQWUsT0FBTyxNQUFNLFdBQVcsV0FBVyxPQUFPLFFBQVEsaUJBQWlCLGFBQWEsaUJBQWlCLFFBQVEsY0FBYyxDQUFDLE1BQU0sTUFBTSxPQUFPLEtBQUssQ0FBQyxJQUFJLFFBQVE7Q0FDbEwsSUFBSSxRQUFRLFlBQVksY0FDbkI7TUFBQSxDQUFDLG1CQUFtQixRQUFRLEdBQUcsUUFBUSxlQUFlO0NBQUE7QUFFNUQ7Ozs7OztBQU1BLElBQU0sOEJBQThCLHVCQUF1QjtDQUMxRCxhQUFNLGdCQUFnQjtFQUNyQixtQkFBbUIsV0FBVztDQUMvQixHQUFHLENBQUMsa0JBQWtCLENBQUM7QUFDeEI7Ozs7Ozs7OztBQVNBLElBQU0sZUFBZSxFQUFFLFFBQVEsb0JBQW9CLGNBQWMsT0FBTyxlQUFlO0NBQ3RGLE9BQU8sT0FBTyxXQUFXLENBQUMsbUJBQW1CLFFBQVEsS0FBSyxDQUFDLE9BQU8sY0FBYyxVQUFVLFlBQVksT0FBTyxTQUFTLEtBQUssS0FBSyxpQkFBaUIsY0FBYyxDQUFDLE9BQU8sT0FBTyxLQUFLLENBQUM7QUFDckw7Ozs7Ozs7OztBQzlCQSxJQUFNLHVCQUF1QixRQUFRLFVBQVUsTUFBTSxNQUFNLFNBQVMsS0FBSzs7Ozs7OztBQU96RSxJQUFNLHdCQUF3QixxQkFBcUI7Q0FDbEQsSUFBSSxpQkFBaUIsVUFBVTtFQUM5QixNQUFNLHVCQUF1QjtFQUM3QixNQUFNLFNBQVMsVUFBVSxVQUFVLFdBQVcsUUFBUSxLQUFLLElBQUksU0FBUyxzQkFBc0Isb0JBQW9CO0VBQ2xILE1BQU0sb0JBQW9CLGlCQUFpQjtFQUMzQyxpQkFBaUIsWUFBWSxPQUFPLHNCQUFzQixjQUFjLEdBQUcsU0FBUyxNQUFNLGtCQUFrQixHQUFHLElBQUksQ0FBQyxJQUFJLE1BQU0saUJBQWlCO0VBQy9JLElBQUksT0FBTyxpQkFBaUIsV0FBVyxVQUFVLGlCQUFpQixTQUFTLEtBQUssSUFBSSxpQkFBaUIsUUFBUSxvQkFBb0I7Q0FDbEk7QUFDRDs7Ozs7OztBQU9BLElBQU0saUJBQWlCLGtCQUFrQixXQUFXLGtCQUFrQixZQUFZLE9BQU87Ozs7Ozs7OztBQVN6RixJQUFNLG1CQUFtQixrQkFBa0IsVUFBVSx1QkFBdUIsU0FBUyxnQkFBZ0IsZ0JBQWdCLENBQUMsQ0FBQyxZQUFZO0NBQ2xJLG1CQUFtQixXQUFXO0FBQy9CLENBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDaUdELFNBQVMsV0FBVyxFQUFFLFNBQVMsR0FBRyxXQUFXLGFBQWE7Q0FDekQsTUFBTSxTQUFTLGVBQWUsV0FBVztDQUN6QyxNQUFNLGNBQWMsZUFBZTtDQUNuQyxNQUFNLHFCQUFxQiwyQkFBMkI7Q0FDdEQsTUFBTSxhQUFhLFFBQVEsZUFBZTtDQUMxQyxNQUFNLG1CQUFBLGFBQXlCLGNBQWMsUUFBUSxLQUFLLFNBQVM7RUFDbEUsTUFBTSxtQkFBbUIsT0FBTyxvQkFBb0IsSUFBSTtFQUN4RCxpQkFBaUIscUJBQXFCLGNBQWMsZ0JBQWdCLGFBQWEsZUFBZSxLQUFLO0VBQ3JHLE9BQU87Q0FDUixDQUFDLEdBQUc7RUFDSDtFQUNBO0VBQ0E7RUFDQTtDQUNELENBQUM7Q0FDRCxpQkFBaUIsU0FBUyxpQkFBaUI7RUFDMUMscUJBQXFCLFlBQVk7RUFDakMsTUFBTSxRQUFRLE9BQU8sY0FBYyxDQUFDLENBQUMsSUFBSSxhQUFhLFNBQVM7RUFDL0QsZ0NBQWdDLGNBQWMsb0JBQW9CLEtBQUs7Q0FDeEUsQ0FBQztDQUNELDJCQUEyQixrQkFBa0I7Q0FDN0MsTUFBTSxDQUFDLFlBQUEsYUFBa0IsZUFBZSxJQUFJLGdCQUFnQixRQUFRLGtCQUFrQixPQUFPLENBQUM7Q0FDOUYsTUFBTSxDQUFDLGtCQUFrQixtQkFBbUIsZUFBZSxTQUFTLG9CQUFvQixrQkFBa0IsUUFBUSxPQUFPO0NBQ3pILGFBQU0sZ0JBQWdCO0VBQ3JCLFNBQVMsV0FBVyxrQkFBa0IsT0FBTztDQUM5QyxHQUFHO0VBQ0Y7RUFDQTtFQUNBO0NBQ0QsQ0FBQztDQUNELE1BQU0sa0JBQWtCLENBQUMsZUFBZTtDQUN4QyxhQUFNLHFCQUFBLGFBQTJCLGFBQWEsa0JBQWtCLGtCQUFrQixTQUFTLFVBQVUsY0FBYyxXQUFXLGFBQWEsQ0FBQyxJQUFJLE1BQU0sQ0FBQyxVQUFVLGVBQWUsQ0FBQyxTQUFTLFNBQVMsaUJBQWlCLFNBQVMsU0FBUyxpQkFBaUIsQ0FBQztDQUN4UCxNQUFNLG1CQUFtQixpQkFBaUIsTUFBTSxRQUFRLFVBQVUsY0FBYyxpQkFBaUIsUUFBUSxNQUFNLENBQUMsSUFBSSxpQkFBaUIsU0FBUyxRQUFRLFVBQVU7RUFDL0osTUFBTSxPQUFPLGlCQUFpQjtFQUM5QixJQUFJLFFBQVEsY0FBYyxNQUFNLE1BQU0sR0FFckMsT0FBTyxnQkFBZ0IsTUFBTSxJQURILGNBQWMsUUFBUSxJQUNuQixHQUFlLGtCQUFrQjtFQUUvRCxPQUFPLENBQUM7Q0FDVCxDQUFDLElBQUksQ0FBQztDQUNOLElBQUksaUJBQWlCLFNBQVMsR0FBRyxNQUFNLFFBQVEsSUFBSSxnQkFBZ0I7Q0FDbkUsTUFBTSxvQ0FBb0MsaUJBQWlCLE1BQU0sUUFBUSxVQUFVO0VBQ2xGLE1BQU0sUUFBUSxpQkFBaUI7RUFDL0IsT0FBTyxTQUFTLFlBQVk7R0FDM0I7R0FDQTtHQUNBLGNBQWMsTUFBTTtHQUNwQixPQUFPLE9BQU8sY0FBYyxDQUFDLENBQUMsSUFBSSxNQUFNLFNBQVM7R0FDakQsVUFBVSxNQUFNO0VBQ2pCLENBQUM7Q0FDRixDQUFDO0NBQ0QsSUFBSSxtQ0FBbUMsTUFBTSxrQ0FBa0M7Q0FDL0UsT0FBTyxrQkFBa0IsWUFBWSxDQUFDO0FBQ3ZDOzs7Ozs7Ozs7Ozs7Ozs7QUN6S0EsU0FBUyxhQUFhLFNBQVMsVUFBVSxhQUFhO0NBRXBELElBQUksT0FBTyxZQUFZLFlBQVksTUFBTSxRQUFRLE9BQU8sR0FBRyxNQUFNLElBQUksTUFBTSxnU0FBZ1M7Q0FFNVcsTUFBTSxjQUFjLGVBQWU7Q0FDbkMsTUFBTSxxQkFBcUIsMkJBQTJCO0NBQ3RELE1BQU0sU0FBUyxlQUFlLFdBQVc7Q0FDekMsTUFBTSxtQkFBbUIsT0FBTyxvQkFBb0IsT0FBTztDQUMzRCxNQUFNLFFBQVEsT0FBTyxjQUFjLENBQUMsQ0FBQyxJQUFJLGlCQUFpQixTQUFTO0NBRWxFLElBQUksQ0FBQyxpQkFBaUIsU0FBUyxRQUFRLE1BQU0sSUFBSSxpQkFBaUIsVUFBVSxtUEFBbVA7Q0FFaFUsTUFBTSxhQUFhLFFBQVEsZUFBZTtDQUMxQyxpQkFBaUIscUJBQXFCLGNBQWMsZ0JBQWdCLGFBQWEsZUFBZSxLQUFLO0NBQ3JHLHFCQUFxQixnQkFBZ0I7Q0FDckMsZ0NBQWdDLGtCQUFrQixvQkFBb0IsS0FBSztDQUMzRSwyQkFBMkIsa0JBQWtCO0NBQzdDLE1BQU0sQ0FBQyxZQUFBLGFBQWtCLGVBQWUsSUFBSSxTQUFTLFFBQVEsZ0JBQWdCLENBQUM7Q0FDOUUsTUFBTSxTQUFTLFNBQVMsb0JBQW9CLGdCQUFnQjtDQUM1RCxhQUFNLGdCQUFnQjtFQUNyQixTQUFTLFdBQVcsZ0JBQWdCO0NBQ3JDLEdBQUcsQ0FBQyxrQkFBa0IsUUFBUSxDQUFDO0NBQy9CLE1BQU0sa0JBQWtCLENBQUMsZUFBZTtDQUN4QyxhQUFNLHFCQUFBLGFBQTJCLGFBQWEsa0JBQWtCO0VBQy9ELE1BQU0sY0FBYyxrQkFBa0IsU0FBUyxVQUFVLGNBQWMsV0FBVyxhQUFhLENBQUMsSUFBSTtFQUNwRyxTQUFTLGFBQWE7RUFDdEIsT0FBTztDQUNSLEdBQUcsQ0FBQyxVQUFVLGVBQWUsQ0FBQyxTQUFTLFNBQVMsaUJBQWlCLFNBQVMsU0FBUyxpQkFBaUIsQ0FBQztDQUNyRyxJQUFJLGNBQWMsa0JBQWtCLE1BQU0sR0FBRyxNQUFNLGdCQUFnQixrQkFBa0IsVUFBVSxrQkFBa0I7Q0FDakgsSUFBSSxZQUFZO0VBQ2Y7RUFDQTtFQUNBLGNBQWMsaUJBQWlCO0VBQy9CO0VBQ0EsVUFBVSxpQkFBaUI7Q0FDNUIsQ0FBQyxHQUFHLE1BQU0sT0FBTztDQUNqQixPQUFPLENBQUMsaUJBQWlCLHNCQUFzQixTQUFTLFlBQVksTUFBTSxJQUFJO0FBQy9FOztBQ3ZEQSxTQUFTLFNBQVMsU0FBUyxhQUFhO0NBQ3ZDLE9BQU8sYUFBYSxTQUFTLGVBQWUsV0FBVztBQUN4RDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ2dFQSxTQUFTLGlCQUFpQixTQUFTLGFBQWE7Q0FFOUMsSUFBSSxRQUFRLFlBQVksV0FBVyxRQUFRLE1BQU0sK0NBQStDO0NBRWpHLE9BQU8sYUFBYTtFQUNuQixHQUFHO0VBQ0gsU0FBUztFQUNULFVBQVU7RUFDVixjQUFjO0VBQ2QsaUJBQWlCLEtBQUs7Q0FDdkIsR0FBRyxlQUFlLFdBQVc7QUFDOUI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDUUEsU0FBUyx5QkFBeUIsU0FBUyxhQUFhO0NBRXRELElBQUksUUFBUSxZQUFZLFdBQVcsUUFBUSxNQUFNLHVEQUF1RDtDQUV6RyxPQUFPLGFBQWE7RUFDbkIsR0FBRztFQUNILFNBQVM7RUFDVCxVQUFVO0VBQ1YsY0FBYztFQUNkLGlCQUFpQixLQUFLO0NBQ3ZCLEdBQUcsdUJBQXVCLFdBQVc7QUFDdEM7O0FDL0ZBLFNBQVMsbUJBQW1CLFNBQVMsYUFBYTtDQUNqRCxPQUFPLFdBQVc7RUFDakIsR0FBRztFQUNILFNBQVMsUUFBUSxRQUFRLEtBQUssVUFBVTtHQUV0QyxJQUFJLE1BQU0sWUFBWSxXQUFXLFFBQVEsTUFBTSxpREFBaUQ7R0FFakcsT0FBTztJQUNOLEdBQUc7SUFDSCxVQUFVO0lBQ1YsY0FBYztJQUNkLFNBQVM7SUFDVCxpQkFBaUIsS0FBSztHQUN2QjtFQUNELENBQUM7Q0FDRixHQUFHLFdBQVc7QUFDZjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ2NBLFNBQVMsaUJBQWlCLFNBQVMsYUFBYTtDQUMvQyxNQUFNLFNBQVMsZUFBZSxXQUFXO0NBQ3pDLElBQUksQ0FBQyxPQUFPLGNBQWMsUUFBUSxRQUFRLEdBQUcsT0FBTyxNQUFNLE9BQU8sQ0FBQyxDQUFDLE1BQU0sSUFBSTtBQUM5RTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ01BLFNBQVMseUJBQXlCLFNBQVMsYUFBYTtDQUN2RCxNQUFNLFNBQVMsZUFBZSxXQUFXO0NBQ3pDLElBQUksQ0FBQyxPQUFPLGNBQWMsUUFBUSxRQUFRLEdBQUcsT0FBTyxjQUFjLE9BQU8sQ0FBQyxDQUFDLE1BQU0sSUFBSTtBQUN0Rjs7QUM5Q0EsU0FBUyxhQUFhLFNBQVM7Q0FDOUIsT0FBTztBQUNSOztBQ0ZBLFNBQVMscUJBQXFCLFNBQVM7Q0FDdEMsT0FBTztBQUNSOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ21DQSxTQUFTLGNBQWMsU0FBUyxhQUFhO0NBQzVDLE1BQU0sU0FBUyxlQUFlLFdBQVc7Q0FDekMsTUFBTSxhQUFhLE9BQU8sY0FBYztDQUN4QyxPQUFBLGFBQWEscUJBQUEsYUFBMkIsYUFBYSxrQkFBa0IsV0FBVyxVQUFVLGNBQWMsV0FBVyxhQUFhLENBQUMsR0FBRyxDQUFDLFVBQVUsQ0FBQyxTQUFTLE9BQU8sV0FBVyxPQUFPLFNBQVMsT0FBTyxXQUFXLE9BQU8sQ0FBQztBQUN4Tjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDbEJBLFNBQVMsY0FBYyxTQUFTLGFBQWE7Q0FDNUMsTUFBTSxTQUFTLGVBQWUsV0FBVztDQUN6QyxPQUFPLGlCQUFpQixFQUFFLFNBQVM7RUFDbEMsR0FBRztFQUNILFFBQVE7Q0FDVCxFQUFFLEdBQUcsTUFBTSxDQUFDLENBQUM7QUFDZDs7Ozs7OztBQU9BLFNBQVMsd0JBQXdCO0NBQ2hDLElBQUk7Q0FDSixRQUFRLGVBQWUsWUFBWTtFQUNsQyxJQUFJLFNBQVMsQ0FBQztFQUNkLElBQUk7RUFDSixhQUFhO0dBQ1osTUFBTSxZQUFZLGNBQWMsUUFBUSxRQUFRLE9BQU87R0FDdkQsTUFBTSxhQUFhLFVBQVUsU0FBUyxhQUFhLENBQUMsVUFBVSxTQUFTLEtBQUssQ0FBQztHQUM3RSxJQUFJLENBQUMsWUFBWSxXQUFXLFdBQVcsT0FBTyxVQUFVLFdBQVcsTUFBTSxPQUFPLFVBQVUsQ0FBQyxPQUFPLEdBQUcsT0FBTyxPQUFPLE1BQU0sQ0FBQyxHQUFHO0lBQzVILFNBQVM7SUFDVCxXQUFXLGlCQUFpQixnQkFBZ0IsVUFBVSxLQUFLLGFBQWEsUUFBUSxTQUFTLFFBQVEsT0FBTyxRQUFRLElBQUksU0FBUyxLQUFLLENBQUM7SUFDbkksaUJBQWlCO0dBQ2xCO0dBQ0EsT0FBTztFQUNSO0NBQ0Q7QUFDRDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQXNFQSxTQUFTLGlCQUFpQixVQUFVLENBQUMsR0FBRyxhQUFhO0NBQ3BELE1BQU0sZ0JBQWdCLGVBQWUsV0FBVyxDQUFDLENBQUMsaUJBQWlCO0NBQ25FLE1BQU0sQ0FBQyxrQkFBQSxhQUF3QixlQUFlLHNCQUFzQixDQUFDO0NBQ3JFLE1BQU0sY0FBYyxlQUFlLGVBQWUsT0FBTztDQUN6RCxPQUFBLGFBQWEscUJBQUEsYUFBMkIsYUFBYSxrQkFBa0IsY0FBYyxVQUFVLGNBQWMsV0FBVyxhQUFhLENBQUMsR0FBRyxDQUFDLGFBQWEsQ0FBQyxHQUFHLGFBQWEsV0FBVztBQUNwTDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUM2Q0EsU0FBUyxZQUFZLFNBQVMsYUFBYTtDQUMxQyxNQUFNLFNBQVMsZUFBZSxXQUFXO0NBQ3pDLE1BQU0sQ0FBQyxZQUFBLGFBQWtCLGVBQWUsSUFBSSxpQkFBaUIsUUFBUSxPQUFPLENBQUM7Q0FDN0UsYUFBTSxnQkFBZ0I7RUFDckIsU0FBUyxXQUFXLE9BQU87Q0FDNUIsR0FBRyxDQUFDLFVBQVUsT0FBTyxDQUFDO0NBQ3RCLE1BQU0sU0FBQSxhQUFlLHFCQUFBLGFBQTJCLGFBQWEsa0JBQWtCLFNBQVMsVUFBVSxjQUFjLFdBQVcsYUFBYSxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsU0FBUyxTQUFTLGlCQUFpQixTQUFTLFNBQVMsaUJBQWlCLENBQUM7Q0FDN04sTUFBTSxTQUFBLGFBQWUsYUFBYSxHQUFHLFNBQVM7RUFDN0MsU0FBUyxPQUFPLEtBQUssSUFBSSxLQUFLLEVBQUUsQ0FBQyxDQUFDLE1BQU0sSUFBSTtDQUM3QyxHQUFHLENBQUMsUUFBUSxDQUFDO0NBQ2IsSUFBSSxPQUFPLFNBQVMsaUJBQWlCLFNBQVMsUUFBUSxjQUFjLENBQUMsT0FBTyxLQUFLLENBQUMsR0FBRyxNQUFNLE9BQU87Q0FDbEcsT0FBTztFQUNOLEdBQUc7RUFDSDtFQUNBLGFBQWEsT0FBTztDQUNyQjtBQUNEOztBQzVMQSxTQUFTLGdCQUFnQixTQUFTO0NBQ2pDLE9BQU87QUFDUjs7QUNDQSxTQUFTLGlCQUFpQixTQUFTLGFBQWE7Q0FDL0MsT0FBTyxhQUFhLFNBQVMsdUJBQXVCLFdBQVc7QUFDaEUiLCJ4X2dvb2dsZV9pZ25vcmVMaXN0IjpbMCwxLDIsMyw0LDUsNiw3LDgsOSwxMCwxMSwxMiwxMywxNCwxNSwxNiwxNywxOCwxOSwyMCwyMSwyMiwyMywyNCwyNSwyNiwyNywyOCwyOSwzMCwzMSwzMiwzMywzNCwzNSwzNiwzNywzOCwzOSw0MCw0MSw0Miw0M119