import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/indicadores/CardMetaIndicador.tsx");const React = __vite__cjsImport0_react;const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];/**
* Card de Apresentação de Meta Pactuada (CardMetaIndicador)
* Exibe título, meta, realizado, percentual de atingimento, barra de progresso e badge de status.
*/
import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=0fd2848a";
import { AlertTriangle, CheckCircle2, Clock, Target } from "/node_modules/.vite/deps/lucide-react.js?v=0fd2848a";
var _jsxFileName = "E:/Projetos VSCODE/visa_braunas/src/components/indicadores/CardMetaIndicador.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=0fd2848a";
export const CardMetaIndicador = ({ indicador, onClick }) => {
	const { codigo, titulo, descricao, unidade, progresso } = indicador;
	const { meta_pactuada, realizado, percentual_atingido, status } = progresso;
	// Determinação semântica do estado de atingimento
	const isAtingida = percentual_atingido >= 100 || status?.toLowerCase() === "atingida";
	const isAtencao = !isAtingida && (percentual_atingido >= 50 || status?.toLowerCase() === "em andamento");
	const isAlerta = !isAtingida && !isAtencao;
	const statusConfig = isAtingida ? {
		label: "Meta Atingida",
		bgBadge: "bg-emerald-50 dark:bg-emerald-950/40",
		textBadge: "text-emerald-700 dark:text-emerald-300",
		borderBadge: "border-emerald-200 dark:border-emerald-800",
		barColor: "bg-emerald-500",
		icon: CheckCircle2
	} : isAtencao ? {
		label: "Em Andamento",
		bgBadge: "bg-amber-50 dark:bg-amber-950/40",
		textBadge: "text-amber-700 dark:text-amber-300",
		borderBadge: "border-amber-200 dark:border-amber-800",
		barColor: "bg-amber-500",
		icon: Clock
	} : {
		label: "Meta Crítica",
		bgBadge: "bg-rose-50 dark:bg-rose-950/40",
		textBadge: "text-rose-700 dark:text-rose-300",
		borderBadge: "border-rose-200 dark:border-rose-800",
		barColor: "bg-rose-500",
		icon: AlertTriangle
	};
	const StatusIcon = statusConfig.icon;
	const percentualLimitado = Math.min(Math.max(percentual_atingido, 0), 100);
	return /* @__PURE__ */ _jsxDEV("div", {
		onClick,
		className: `bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-xs transition-all ${onClick ? "cursor-pointer hover:border-teal-500/60 dark:hover:border-teal-500/60 hover:shadow-md" : ""}`,
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex items-start justify-between gap-3 mb-3",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ _jsxDEV("span", {
						className: "inline-flex items-center px-2 py-0.5 rounded text-[11px] font-bold font-mono bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700",
						children: codigo
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 71,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("span", {
						className: "text-[11px] text-slate-400 font-medium",
						children: "SUS / Pacto"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 74,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 70,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("span", {
					className: `inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-semibold border ${statusConfig.bgBadge} ${statusConfig.textBadge} ${statusConfig.borderBadge}`,
					children: [/* @__PURE__ */ _jsxDEV(StatusIcon, { className: "w-3 h-3 shrink-0" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 80,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("span", { children: statusConfig.label }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 81,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 77,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 69,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "mb-4",
				children: [/* @__PURE__ */ _jsxDEV("h3", {
					className: "text-sm font-bold text-slate-900 dark:text-white line-clamp-2 leading-snug",
					children: titulo
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 87,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("p", {
					className: "text-xs text-slate-500 dark:text-slate-400 mt-1 line-clamp-2 leading-relaxed",
					children: descricao
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 90,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 86,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "grid grid-cols-2 gap-3 py-3 px-3.5 bg-slate-50 dark:bg-slate-800/50 rounded-lg mb-3",
				children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
					className: "text-[10px] uppercase font-bold text-slate-400 block tracking-wider",
					children: "Realizado"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 98,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "text-lg font-bold text-slate-900 dark:text-white tabular-nums mt-0.5",
					children: [
						realizado.toLocaleString("pt-BR"),
						" ",
						/* @__PURE__ */ _jsxDEV("span", {
							className: "text-xs font-normal text-slate-500",
							children: unidade
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 103,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 101,
					columnNumber: 11
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 97,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "text-right",
					children: [/* @__PURE__ */ _jsxDEV("span", {
						className: "text-[10px] uppercase font-bold text-slate-400 block tracking-wider",
						children: "Meta Pactuada"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 108,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "text-lg font-bold text-slate-700 dark:text-slate-300 tabular-nums mt-0.5",
						children: [
							meta_pactuada.toLocaleString("pt-BR"),
							" ",
							/* @__PURE__ */ _jsxDEV("span", {
								className: "text-xs font-normal text-slate-500",
								children: unidade
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 113,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 111,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 107,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 96,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "space-y-1.5",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center justify-between text-xs",
					children: [/* @__PURE__ */ _jsxDEV("span", {
						className: "text-slate-500 dark:text-slate-400 text-[11px] font-medium flex items-center gap-1",
						children: [/* @__PURE__ */ _jsxDEV(Target, { className: "w-3 h-3 text-slate-400" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 122,
							columnNumber: 13
						}, this), "Progresso Acumulado"]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 121,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("span", {
						className: "font-bold text-slate-900 dark:text-white tabular-nums",
						children: [percentual_atingido.toFixed(1), "%"]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 125,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 120,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "w-full bg-slate-100 dark:bg-slate-800 h-2.5 rounded-full overflow-hidden p-0.5",
					children: /* @__PURE__ */ _jsxDEV("div", {
						className: `h-full rounded-full transition-all duration-500 ${statusConfig.barColor}`,
						style: { width: `${percentualLimitado}%` }
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 131,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 130,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 119,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 60,
		columnNumber: 5
	}, this);
};
_c = CardMetaIndicador;
export default CardMetaIndicador;
var _c;
$RefreshReg$(_c, "CardMetaIndicador");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/indicadores/CardMetaIndicador.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("E:/Projetos VSCODE/visa_braunas/src/components/indicadores/CardMetaIndicador.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("E:/Projetos VSCODE/visa_braunas/src/components/indicadores/CardMetaIndicador.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "E:/Projetos VSCODE/visa_braunas/src/components/indicadores/CardMetaIndicador.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7OztBQUtBLE9BQU8sV0FBVztBQUNsQixTQUFTLGVBQWUsY0FBYyxPQUFhLGNBQWM7OztBQVFqRSxPQUFPLE1BQU0scUJBQXVELEVBQ2xFLFdBQ0EsY0FDSTtDQUNKLE1BQU0sRUFBRSxRQUFRLFFBQVEsV0FBVyxTQUFTLGNBQWM7Q0FDMUQsTUFBTSxFQUFFLGVBQWUsV0FBVyxxQkFBcUIsV0FBVzs7Q0FHbEUsTUFBTSxhQUFhLHVCQUF1QixPQUFPLFFBQVEsWUFBWSxNQUFNO0NBQzNFLE1BQU0sWUFDSixDQUFDLGVBQ0EsdUJBQXVCLE1BQU0sUUFBUSxZQUFZLE1BQU07Q0FDMUQsTUFBTSxXQUFXLENBQUMsY0FBYyxDQUFDO0NBRWpDLE1BQU0sZUFBZSxhQUNqQjtFQUNFLE9BQU87RUFDUCxTQUFTO0VBQ1QsV0FBVztFQUNYLGFBQWE7RUFDYixVQUFVO0VBQ1YsTUFBTTtDQUNSLElBQ0EsWUFDQTtFQUNFLE9BQU87RUFDUCxTQUFTO0VBQ1QsV0FBVztFQUNYLGFBQWE7RUFDYixVQUFVO0VBQ1YsTUFBTTtDQUNSLElBQ0E7RUFDRSxPQUFPO0VBQ1AsU0FBUztFQUNULFdBQVc7RUFDWCxhQUFhO0VBQ2IsVUFBVTtFQUNWLE1BQU07Q0FDUjtDQUVKLE1BQU0sYUFBYSxhQUFhO0NBQ2hDLE1BQU0scUJBQXFCLEtBQUssSUFBSSxLQUFLLElBQUkscUJBQXFCLENBQUMsR0FBRyxHQUFHO0NBRXpFLE9BQ0Usd0JBQUMsT0FBRDtFQUNXO0VBQ1QsV0FBVyxvSEFDVCxVQUNJLDBGQUNBO1lBTFI7R0FTRSx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLFFBQUQ7TUFBTSxXQUFVO2dCQUNiO0tBQ0c7Ozs7ZUFDTix3QkFBQyxRQUFEO01BQU0sV0FBVTtnQkFBeUM7S0FBaUI7Ozs7YUFDdkU7Ozs7O2NBRUwsd0JBQUMsUUFBRDtLQUNFLFdBQVcsOEZBQThGLGFBQWEsUUFBUSxHQUFHLGFBQWEsVUFBVSxHQUFHLGFBQWE7ZUFEMUssQ0FHRSx3QkFBQyxZQUFELEVBQVksV0FBVSxtQkFBb0I7Ozs7ZUFDMUMsd0JBQUMsUUFBRCxZQUFPLGFBQWEsTUFBWTs7OzthQUM1Qjs7Ozs7WUFDSDs7Ozs7O0dBR0wsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLE1BQUQ7S0FBSSxXQUFVO2VBQ1g7SUFDQzs7OztjQUNKLHdCQUFDLEtBQUQ7S0FBRyxXQUFVO2VBQ1Y7SUFDQTs7OztZQUNBOzs7Ozs7R0FHTCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFFBQUQ7S0FBTSxXQUFVO2VBQXNFO0lBRWhGOzs7O2NBQ04sd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZjtNQUNHLFVBQVUsZUFBZSxPQUFPO01BQUc7TUFDcEMsd0JBQUMsUUFBRDtPQUFNLFdBQVU7aUJBQXNDO01BQWM7Ozs7O0tBQ2pFOzs7OztZQUNGOzs7O2NBRUwsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLFFBQUQ7TUFBTSxXQUFVO2dCQUFzRTtLQUVoRjs7OztlQUNOLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmO09BQ0csY0FBYyxlQUFlLE9BQU87T0FBRztPQUN4Qyx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBc0M7T0FBYzs7Ozs7TUFDakU7Ozs7O2FBQ0Y7Ozs7O1lBQ0Y7Ozs7OztHQUdMLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsUUFBRDtNQUFNLFdBQVU7Z0JBQWhCLENBQ0Usd0JBQUMsUUFBRCxFQUFRLFdBQVUseUJBQTBCOzs7O2dCQUFDLHFCQUV6Qzs7Ozs7ZUFDTix3QkFBQyxRQUFEO01BQU0sV0FBVTtnQkFBaEIsQ0FDRyxvQkFBb0IsUUFBUSxDQUFDLEdBQUUsR0FDNUI7Ozs7O2FBQ0g7Ozs7O2NBRUwsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFDYix3QkFBQyxPQUFEO01BQ0UsV0FBVyxtREFBbUQsYUFBYTtNQUMzRSxPQUFPLEVBQUUsT0FBTyxHQUFHLG1CQUFtQixHQUFHO0tBQzFDOzs7OztJQUNFOzs7O1lBQ0Y7Ozs7OztFQUNGOzs7Ozs7QUFFVDs7QUFFQSxlQUFlIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkNhcmRNZXRhSW5kaWNhZG9yLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyIvKipcclxuICogQ2FyZCBkZSBBcHJlc2VudGHDp8OjbyBkZSBNZXRhIFBhY3R1YWRhIChDYXJkTWV0YUluZGljYWRvcilcclxuICogRXhpYmUgdMOtdHVsbywgbWV0YSwgcmVhbGl6YWRvLCBwZXJjZW50dWFsIGRlIGF0aW5naW1lbnRvLCBiYXJyYSBkZSBwcm9ncmVzc28gZSBiYWRnZSBkZSBzdGF0dXMuXHJcbiAqL1xyXG5cclxuaW1wb3J0IFJlYWN0IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgeyBBbGVydFRyaWFuZ2xlLCBDaGVja0NpcmNsZTIsIENsb2NrLCBJbmZvLCBUYXJnZXQgfSBmcm9tIFwibHVjaWRlLXJlYWN0XCI7XHJcbmltcG9ydCB7IEluZGljYWRvck1ldGFJdGVtIH0gZnJvbSBcIi4uLy4uL3R5cGVzL2luZGljYWRvcmVzXCI7XHJcblxyXG5pbnRlcmZhY2UgQ2FyZE1ldGFJbmRpY2Fkb3JQcm9wcyB7XHJcbiAgaW5kaWNhZG9yOiBJbmRpY2Fkb3JNZXRhSXRlbTtcclxuICBvbkNsaWNrPzogKCkgPT4gdm9pZDtcclxufVxyXG5cclxuZXhwb3J0IGNvbnN0IENhcmRNZXRhSW5kaWNhZG9yOiBSZWFjdC5GQzxDYXJkTWV0YUluZGljYWRvclByb3BzPiA9ICh7XHJcbiAgaW5kaWNhZG9yLFxyXG4gIG9uQ2xpY2ssXHJcbn0pID0+IHtcclxuICBjb25zdCB7IGNvZGlnbywgdGl0dWxvLCBkZXNjcmljYW8sIHVuaWRhZGUsIHByb2dyZXNzbyB9ID0gaW5kaWNhZG9yO1xyXG4gIGNvbnN0IHsgbWV0YV9wYWN0dWFkYSwgcmVhbGl6YWRvLCBwZXJjZW50dWFsX2F0aW5naWRvLCBzdGF0dXMgfSA9IHByb2dyZXNzbztcclxuXHJcbiAgLy8gRGV0ZXJtaW5hw6fDo28gc2Vtw6JudGljYSBkbyBlc3RhZG8gZGUgYXRpbmdpbWVudG9cclxuICBjb25zdCBpc0F0aW5naWRhID0gcGVyY2VudHVhbF9hdGluZ2lkbyA+PSAxMDAgfHwgc3RhdHVzPy50b0xvd2VyQ2FzZSgpID09PSBcImF0aW5naWRhXCI7XHJcbiAgY29uc3QgaXNBdGVuY2FvID1cclxuICAgICFpc0F0aW5naWRhICYmXHJcbiAgICAocGVyY2VudHVhbF9hdGluZ2lkbyA+PSA1MCB8fCBzdGF0dXM/LnRvTG93ZXJDYXNlKCkgPT09IFwiZW0gYW5kYW1lbnRvXCIpO1xyXG4gIGNvbnN0IGlzQWxlcnRhID0gIWlzQXRpbmdpZGEgJiYgIWlzQXRlbmNhbztcclxuXHJcbiAgY29uc3Qgc3RhdHVzQ29uZmlnID0gaXNBdGluZ2lkYVxyXG4gICAgPyB7XHJcbiAgICAgICAgbGFiZWw6IFwiTWV0YSBBdGluZ2lkYVwiLFxyXG4gICAgICAgIGJnQmFkZ2U6IFwiYmctZW1lcmFsZC01MCBkYXJrOmJnLWVtZXJhbGQtOTUwLzQwXCIsXHJcbiAgICAgICAgdGV4dEJhZGdlOiBcInRleHQtZW1lcmFsZC03MDAgZGFyazp0ZXh0LWVtZXJhbGQtMzAwXCIsXHJcbiAgICAgICAgYm9yZGVyQmFkZ2U6IFwiYm9yZGVyLWVtZXJhbGQtMjAwIGRhcms6Ym9yZGVyLWVtZXJhbGQtODAwXCIsXHJcbiAgICAgICAgYmFyQ29sb3I6IFwiYmctZW1lcmFsZC01MDBcIixcclxuICAgICAgICBpY29uOiBDaGVja0NpcmNsZTIsXHJcbiAgICAgIH1cclxuICAgIDogaXNBdGVuY2FvXHJcbiAgICA/IHtcclxuICAgICAgICBsYWJlbDogXCJFbSBBbmRhbWVudG9cIixcclxuICAgICAgICBiZ0JhZGdlOiBcImJnLWFtYmVyLTUwIGRhcms6YmctYW1iZXItOTUwLzQwXCIsXHJcbiAgICAgICAgdGV4dEJhZGdlOiBcInRleHQtYW1iZXItNzAwIGRhcms6dGV4dC1hbWJlci0zMDBcIixcclxuICAgICAgICBib3JkZXJCYWRnZTogXCJib3JkZXItYW1iZXItMjAwIGRhcms6Ym9yZGVyLWFtYmVyLTgwMFwiLFxyXG4gICAgICAgIGJhckNvbG9yOiBcImJnLWFtYmVyLTUwMFwiLFxyXG4gICAgICAgIGljb246IENsb2NrLFxyXG4gICAgICB9XHJcbiAgICA6IHtcclxuICAgICAgICBsYWJlbDogXCJNZXRhIENyw610aWNhXCIsXHJcbiAgICAgICAgYmdCYWRnZTogXCJiZy1yb3NlLTUwIGRhcms6Ymctcm9zZS05NTAvNDBcIixcclxuICAgICAgICB0ZXh0QmFkZ2U6IFwidGV4dC1yb3NlLTcwMCBkYXJrOnRleHQtcm9zZS0zMDBcIixcclxuICAgICAgICBib3JkZXJCYWRnZTogXCJib3JkZXItcm9zZS0yMDAgZGFyazpib3JkZXItcm9zZS04MDBcIixcclxuICAgICAgICBiYXJDb2xvcjogXCJiZy1yb3NlLTUwMFwiLFxyXG4gICAgICAgIGljb246IEFsZXJ0VHJpYW5nbGUsXHJcbiAgICAgIH07XHJcblxyXG4gIGNvbnN0IFN0YXR1c0ljb24gPSBzdGF0dXNDb25maWcuaWNvbjtcclxuICBjb25zdCBwZXJjZW50dWFsTGltaXRhZG8gPSBNYXRoLm1pbihNYXRoLm1heChwZXJjZW50dWFsX2F0aW5naWRvLCAwKSwgMTAwKTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXZcclxuICAgICAgb25DbGljaz17b25DbGlja31cclxuICAgICAgY2xhc3NOYW1lPXtgYmctd2hpdGUgZGFyazpiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtODAwIHJvdW5kZWQteGwgcC01IHNoYWRvdy14cyB0cmFuc2l0aW9uLWFsbCAke1xyXG4gICAgICAgIG9uQ2xpY2tcclxuICAgICAgICAgID8gXCJjdXJzb3ItcG9pbnRlciBob3Zlcjpib3JkZXItdGVhbC01MDAvNjAgZGFyazpob3Zlcjpib3JkZXItdGVhbC01MDAvNjAgaG92ZXI6c2hhZG93LW1kXCJcclxuICAgICAgICAgIDogXCJcIlxyXG4gICAgICB9YH1cclxuICAgID5cclxuICAgICAgey8qIFRvcG8gZG8gQ2FyZDogQ8OzZGlnbyBlIEJhZGdlIGRlIFN0YXR1cyAqL31cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLXN0YXJ0IGp1c3RpZnktYmV0d2VlbiBnYXAtMyBtYi0zXCI+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIHB4LTIgcHktMC41IHJvdW5kZWQgdGV4dC1bMTFweF0gZm9udC1ib2xkIGZvbnQtbW9ubyBiZy1zbGF0ZS0xMDAgZGFyazpiZy1zbGF0ZS04MDAgdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTMwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDBcIj5cclxuICAgICAgICAgICAge2NvZGlnb31cclxuICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtc2xhdGUtNDAwIGZvbnQtbWVkaXVtXCI+U1VTIC8gUGFjdG88L3NwYW4+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIDxzcGFuXHJcbiAgICAgICAgICBjbGFzc05hbWU9e2BpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgcHgtMi41IHB5LTAuNSByb3VuZGVkLWZ1bGwgdGV4dC1bMTFweF0gZm9udC1zZW1pYm9sZCBib3JkZXIgJHtzdGF0dXNDb25maWcuYmdCYWRnZX0gJHtzdGF0dXNDb25maWcudGV4dEJhZGdlfSAke3N0YXR1c0NvbmZpZy5ib3JkZXJCYWRnZX1gfVxyXG4gICAgICAgID5cclxuICAgICAgICAgIDxTdGF0dXNJY29uIGNsYXNzTmFtZT1cInctMyBoLTMgc2hyaW5rLTBcIiAvPlxyXG4gICAgICAgICAgPHNwYW4+e3N0YXR1c0NvbmZpZy5sYWJlbH08L3NwYW4+XHJcbiAgICAgICAgPC9zcGFuPlxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIHsvKiBUw610dWxvIGUgRGVzY3Jpw6fDo28gVMOpY25pY2EgKi99XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNFwiPlxyXG4gICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGUgbGluZS1jbGFtcC0yIGxlYWRpbmctc251Z1wiPlxyXG4gICAgICAgICAge3RpdHVsb31cclxuICAgICAgICA8L2gzPlxyXG4gICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS01MDAgZGFyazp0ZXh0LXNsYXRlLTQwMCBtdC0xIGxpbmUtY2xhbXAtMiBsZWFkaW5nLXJlbGF4ZWRcIj5cclxuICAgICAgICAgIHtkZXNjcmljYW99XHJcbiAgICAgICAgPC9wPlxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIHsvKiBWYWxvcmVzOiBSZWFsaXphZG8gdnMgTWV0YSBQYWN0dWFkYSAqL31cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0yIGdhcC0zIHB5LTMgcHgtMy41IGJnLXNsYXRlLTUwIGRhcms6Ymctc2xhdGUtODAwLzUwIHJvdW5kZWQtbGcgbWItM1wiPlxyXG4gICAgICAgIDxkaXY+XHJcbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB1cHBlcmNhc2UgZm9udC1ib2xkIHRleHQtc2xhdGUtNDAwIGJsb2NrIHRyYWNraW5nLXdpZGVyXCI+XHJcbiAgICAgICAgICAgIFJlYWxpemFkb1xyXG4gICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGUgdGFidWxhci1udW1zIG10LTAuNVwiPlxyXG4gICAgICAgICAgICB7cmVhbGl6YWRvLnRvTG9jYWxlU3RyaW5nKFwicHQtQlJcIil9e1wiIFwifVxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtbm9ybWFsIHRleHQtc2xhdGUtNTAwXCI+e3VuaWRhZGV9PC9zcGFuPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1yaWdodFwiPlxyXG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdXBwZXJjYXNlIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTQwMCBibG9jayB0cmFja2luZy13aWRlclwiPlxyXG4gICAgICAgICAgICBNZXRhIFBhY3R1YWRhXHJcbiAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1ib2xkIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0zMDAgdGFidWxhci1udW1zIG10LTAuNVwiPlxyXG4gICAgICAgICAgICB7bWV0YV9wYWN0dWFkYS50b0xvY2FsZVN0cmluZyhcInB0LUJSXCIpfXtcIiBcIn1cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LW5vcm1hbCB0ZXh0LXNsYXRlLTUwMFwiPnt1bmlkYWRlfTwvc3Bhbj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIHsvKiBCYXJyYSBkZSBQcm9ncmVzc28gVmlzdWFsICovfVxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMS41XCI+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gdGV4dC14c1wiPlxyXG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS01MDAgZGFyazp0ZXh0LXNsYXRlLTQwMCB0ZXh0LVsxMXB4XSBmb250LW1lZGl1bSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMVwiPlxyXG4gICAgICAgICAgICA8VGFyZ2V0IGNsYXNzTmFtZT1cInctMyBoLTMgdGV4dC1zbGF0ZS00MDBcIiAvPlxyXG4gICAgICAgICAgICBQcm9ncmVzc28gQWN1bXVsYWRvXHJcbiAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlIHRhYnVsYXItbnVtc1wiPlxyXG4gICAgICAgICAgICB7cGVyY2VudHVhbF9hdGluZ2lkby50b0ZpeGVkKDEpfSVcclxuICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctc2xhdGUtMTAwIGRhcms6Ymctc2xhdGUtODAwIGgtMi41IHJvdW5kZWQtZnVsbCBvdmVyZmxvdy1oaWRkZW4gcC0wLjVcIj5cclxuICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgY2xhc3NOYW1lPXtgaC1mdWxsIHJvdW5kZWQtZnVsbCB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi01MDAgJHtzdGF0dXNDb25maWcuYmFyQ29sb3J9YH1cclxuICAgICAgICAgICAgc3R5bGU9e3sgd2lkdGg6IGAke3BlcmNlbnR1YWxMaW1pdGFkb30lYCB9fVxyXG4gICAgICAgICAgLz5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgQ2FyZE1ldGFJbmRpY2Fkb3I7XHJcbiJdfQ==