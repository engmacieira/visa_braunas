import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/LoginPage.tsx");const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport6_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport6_react_jsxDevRuntime["Fragment"];/**
* Tela de Autenticação do Servidor (LoginPage)
* Formulário institucional com validação, tratamento de erros da API,
* feedback de loading e preenchimento rápido de perfis para teste operacional.
*/
import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=0fd2848a";
import { useLocation, useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=0fd2848a";
import { AlertTriangle, KeyRound, Lock, Mail, Shield } from "/node_modules/.vite/deps/lucide-react.js?v=0fd2848a";
import { APP_CONFIG } from "/src/config/app.config.ts";
import { useAuth } from "/src/contexts/AuthContext.tsx";
import authService from "/src/services/authService.ts";
var _jsxFileName = "E:/Projetos VSCODE/visa_braunas/src/pages/LoginPage.tsx";
import __vite__cjsImport6_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=0fd2848a";
var _s = $RefreshSig$();
export const LoginPage = () => {
	_s();
	const { login } = useAuth();
	const navigate = useNavigate();
	const location = useLocation();
	const [email, setEmail] = useState("");
	const [senha, setSenha] = useState("");
	const [isSubmitting, setIsSubmitting] = useState(false);
	const [errorMessage, setErrorMessage] = useState(null);
	// Destino pós-login (respeitando redirecionamento de ProtectedRoute)
	const from = location.state?.from?.pathname || "/";
	const handleSubmit = async (e) => {
		e.preventDefault();
		setErrorMessage(null);
		const cleanEmail = email.trim();
		if (!cleanEmail) {
			setErrorMessage("Por favor, informe seu e-mail institucional.");
			return;
		}
		if (!senha) {
			setErrorMessage("Por favor, digite sua senha de acesso.");
			return;
		}
		setIsSubmitting(true);
		try {
			await login({
				email: cleanEmail,
				senha
			});
			navigate(from, { replace: true });
		} catch (err) {
			setErrorMessage(authService.getErrorMessage(err));
		} finally {
			setIsSubmitting(false);
		}
	};
	const handlePreFill = (userEmail, userPass) => {
		setEmail(userEmail);
		setSenha(userPass);
		setErrorMessage(null);
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "min-h-screen bg-slate-900 text-slate-100 flex flex-col justify-between p-4 sm:p-6 lg:p-8 antialiased",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "w-full max-w-md mx-auto text-center pt-6 sm:pt-10",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-teal-600 text-white shadow-lg mb-4",
						children: /* @__PURE__ */ _jsxDEV(Shield, { className: "w-7 h-7" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 64,
							columnNumber: 11
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 63,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("h1", {
						className: "text-2xl sm:text-3xl font-bold tracking-tight text-white",
						children: APP_CONFIG.nome
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 66,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("p", {
						className: "text-xs sm:text-sm text-slate-400 mt-1",
						children: [
							APP_CONFIG.secretaria,
							" · ",
							APP_CONFIG.municipio,
							"/",
							APP_CONFIG.uf
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 69,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 62,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "w-full max-w-md mx-auto my-8 bg-slate-800/80 backdrop-blur-md border border-slate-700/60 rounded-2xl p-6 sm:p-8 shadow-2xl",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "mb-6",
						children: [/* @__PURE__ */ _jsxDEV("h2", {
							className: "text-lg font-semibold text-white",
							children: "Acesso do Servidor"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 77,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("p", {
							className: "text-xs text-slate-400 mt-0.5",
							children: "Entre com suas credenciais funcionais para acessar os serviços de fiscalização."
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 80,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 76,
						columnNumber: 9
					}, this),
					errorMessage && /* @__PURE__ */ _jsxDEV("div", {
						className: "mb-5 p-3 rounded-lg bg-rose-950/60 border border-rose-800/60 text-rose-200 text-xs flex items-start gap-2.5",
						children: [/* @__PURE__ */ _jsxDEV(AlertTriangle, { className: "w-4 h-4 text-rose-400 shrink-0 mt-0.5" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 87,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							className: "leading-relaxed",
							children: errorMessage
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 88,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 86,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("form", {
						onSubmit: handleSubmit,
						className: "space-y-4",
						children: [
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
								htmlFor: "email",
								className: "block text-xs font-medium text-slate-300 mb-1.5",
								children: "E-mail Institucional"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 94,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "relative",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400",
									children: /* @__PURE__ */ _jsxDEV(Mail, { className: "w-4 h-4" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 102,
										columnNumber: 17
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 101,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("input", {
									id: "email",
									type: "email",
									value: email,
									onChange: (e) => setEmail(e.target.value),
									placeholder: "servidor@braunas.mg.gov.br",
									required: true,
									disabled: isSubmitting,
									className: "w-full pl-9 pr-3 py-2 bg-slate-900/80 border border-slate-700 rounded-lg text-sm text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-teal-500 focus:border-transparent transition-all disabled:opacity-50"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 104,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 100,
								columnNumber: 13
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 93,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
								htmlFor: "senha",
								className: "block text-xs font-medium text-slate-300 mb-1.5",
								children: "Senha"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 118,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "relative",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400",
									children: /* @__PURE__ */ _jsxDEV(Lock, { className: "w-4 h-4" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 126,
										columnNumber: 17
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 125,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("input", {
									id: "senha",
									type: "password",
									value: senha,
									onChange: (e) => setSenha(e.target.value),
									placeholder: "••••••••••••",
									required: true,
									disabled: isSubmitting,
									className: "w-full pl-9 pr-3 py-2 bg-slate-900/80 border border-slate-700 rounded-lg text-sm text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-teal-500 focus:border-transparent transition-all disabled:opacity-50"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 128,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 124,
								columnNumber: 13
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 117,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("button", {
								type: "submit",
								disabled: isSubmitting,
								className: "w-full mt-2 py-2.5 px-4 bg-teal-600 hover:bg-teal-500 text-white text-sm font-semibold rounded-lg shadow-sm hover:shadow transition-all focus:outline-none focus:ring-2 focus:ring-teal-400 focus:ring-offset-2 focus:ring-offset-slate-800 disabled:opacity-60 flex items-center justify-center gap-2",
								children: isSubmitting ? /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("div", { className: "w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 148,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Autenticando..." }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 149,
									columnNumber: 17
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 147,
									columnNumber: 15
								}, this) : /* @__PURE__ */ _jsxDEV("span", { children: "Entrar no Sistema" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 152,
									columnNumber: 15
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 141,
								columnNumber: 11
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 92,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "mt-8 pt-5 border-t border-slate-700/60",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-1.5 text-xs font-medium text-slate-400 mb-2.5",
							children: [/* @__PURE__ */ _jsxDEV(KeyRound, { className: "w-3.5 h-3.5 text-teal-400" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 160,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: [
								"Acesso Rápido (Contas de Teste - ",
								APP_CONFIG.municipio,
								"):"
							] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 161,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 159,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "grid grid-cols-2 gap-2 text-[11px]",
							children: [
								/* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => handlePreFill("admin@braunas.mg.gov.br", "AdminMaster@2026"),
									className: "p-2 text-left bg-slate-900/60 hover:bg-slate-700/60 border border-slate-700/60 rounded-md transition-colors",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "font-semibold text-purple-300",
										children: "Admin Master"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 172,
										columnNumber: 15
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "text-slate-400 text-[10px] truncate",
										children: "admin@braunas.mg.gov.br"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 173,
										columnNumber: 15
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 165,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => handlePreFill("coordenador.visa@braunas.mg.gov.br", "CoordVisa@2026"),
									className: "p-2 text-left bg-slate-900/60 hover:bg-slate-700/60 border border-slate-700/60 rounded-md transition-colors",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "font-semibold text-blue-300",
										children: "Coordenador"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 188,
										columnNumber: 15
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "text-slate-400 text-[10px] truncate",
										children: "coordenador.visa@..."
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 189,
										columnNumber: 15
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 178,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => handlePreFill("fiscal1.visa@braunas.mg.gov.br", "Fiscal1@2026"),
									className: "p-2 text-left bg-slate-900/60 hover:bg-slate-700/60 border border-slate-700/60 rounded-md transition-colors",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "font-semibold text-teal-300",
										children: "Fiscal Sanitário"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 201,
										columnNumber: 15
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "text-slate-400 text-[10px] truncate",
										children: "fiscal1.visa@..."
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 202,
										columnNumber: 15
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 194,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => handlePreFill("digitador.visa@braunas.mg.gov.br", "Digitador@2026"),
									className: "p-2 text-left bg-slate-900/60 hover:bg-slate-700/60 border border-slate-700/60 rounded-md transition-colors",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "font-semibold text-slate-300",
										children: "Digitador"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 217,
										columnNumber: 15
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "text-slate-400 text-[10px] truncate",
										children: "digitador.visa@..."
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 218,
										columnNumber: 15
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 207,
									columnNumber: 13
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 164,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 158,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 75,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "w-full max-w-md mx-auto text-center pb-4 text-xs text-slate-500",
				children: [/* @__PURE__ */ _jsxDEV("p", { children: [
					APP_CONFIG.orgao,
					" · Versão ",
					APP_CONFIG.versao
				] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 228,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("p", {
					className: "text-[11px] text-slate-600 mt-0.5",
					children: "Acesso restrito a servidores autorizados da Vigilância Sanitária Municipal."
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 231,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 227,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 60,
		columnNumber: 5
	}, this);
};
_s(LoginPage, "eEawrInmvRhMhwR0pg44pD0d++k=", false, function() {
	return [
		useAuth,
		useNavigate,
		useLocation
	];
});
_c = LoginPage;
export default LoginPage;
var _c;
$RefreshReg$(_c, "LoginPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/LoginPage.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("E:/Projetos VSCODE/visa_braunas/src/pages/LoginPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("E:/Projetos VSCODE/visa_braunas/src/pages/LoginPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "E:/Projetos VSCODE/visa_braunas/src/pages/LoginPage.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7Ozs7QUFNQSxPQUFPLFNBQVMsZ0JBQWdCO0FBQ2hDLFNBQVMsYUFBYSxtQkFBbUI7QUFDekMsU0FBUyxlQUFlLFVBQVUsTUFBTSxNQUFNLGNBQWM7QUFDNUQsU0FBUyxrQkFBa0I7QUFDM0IsU0FBUyxlQUFlO0FBQ3hCLE9BQU8saUJBQWlCOzs7O0FBRXhCLE9BQU8sTUFBTSxrQkFBNEI7O0NBQ3ZDLE1BQU0sRUFBRSxVQUFVLFFBQVE7Q0FDMUIsTUFBTSxXQUFXLFlBQVk7Q0FDN0IsTUFBTSxXQUFXLFlBQVk7Q0FFN0IsTUFBTSxDQUFDLE9BQU8sWUFBWSxTQUFTLEVBQUU7Q0FDckMsTUFBTSxDQUFDLE9BQU8sWUFBWSxTQUFTLEVBQUU7Q0FDckMsTUFBTSxDQUFDLGNBQWMsbUJBQW1CLFNBQVMsS0FBSztDQUN0RCxNQUFNLENBQUMsY0FBYyxtQkFBbUIsU0FBd0IsSUFBSTs7Q0FHcEUsTUFBTSxPQUNILFNBQVMsT0FBMkMsTUFBTSxZQUFZO0NBRXpFLE1BQU0sZUFBZSxPQUFPLE1BQXVCO0VBQ2pELEVBQUUsZUFBZTtFQUNqQixnQkFBZ0IsSUFBSTtFQUVwQixNQUFNLGFBQWEsTUFBTSxLQUFLO0VBQzlCLElBQUksQ0FBQyxZQUFZO0dBQ2YsZ0JBQWdCLDhDQUE4QztHQUM5RDtFQUNGO0VBQ0EsSUFBSSxDQUFDLE9BQU87R0FDVixnQkFBZ0Isd0NBQXdDO0dBQ3hEO0VBQ0Y7RUFFQSxnQkFBZ0IsSUFBSTtFQUNwQixJQUFJO0dBQ0YsTUFBTSxNQUFNO0lBQUUsT0FBTztJQUFZO0dBQU0sQ0FBQztHQUN4QyxTQUFTLE1BQU0sRUFBRSxTQUFTLEtBQUssQ0FBQztFQUNsQyxTQUFTLEtBQUs7R0FDWixnQkFBZ0IsWUFBWSxnQkFBZ0IsR0FBRyxDQUFDO0VBQ2xELFVBQVU7R0FDUixnQkFBZ0IsS0FBSztFQUN2QjtDQUNGO0NBRUEsTUFBTSxpQkFBaUIsV0FBbUIsYUFBcUI7RUFDN0QsU0FBUyxTQUFTO0VBQ2xCLFNBQVMsUUFBUTtFQUNqQixnQkFBZ0IsSUFBSTtDQUN0QjtDQUVBLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBZjtHQUVFLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWY7S0FDRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFDYix3QkFBQyxRQUFELEVBQVEsV0FBVSxVQUFXOzs7OztLQUMxQjs7Ozs7S0FDTCx3QkFBQyxNQUFEO01BQUksV0FBVTtnQkFDWCxXQUFXO0tBQ1Y7Ozs7O0tBQ0osd0JBQUMsS0FBRDtNQUFHLFdBQVU7Z0JBQWI7T0FDRyxXQUFXO09BQVc7T0FBSSxXQUFXO09BQVU7T0FBRSxXQUFXO01BQzVEOzs7Ozs7SUFDQTs7Ozs7O0dBR0wsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZjtLQUNFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQW1DO01BRTdDOzs7O2dCQUNKLHdCQUFDLEtBQUQ7T0FBRyxXQUFVO2lCQUFnQztNQUUxQzs7OztjQUNBOzs7Ozs7S0FFSixnQkFDQyx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLGVBQUQsRUFBZSxXQUFVLHdDQUF5Qzs7OztnQkFDbEUsd0JBQUMsUUFBRDtPQUFNLFdBQVU7aUJBQW1CO01BQW1COzs7O2NBQ25EOzs7Ozs7S0FHUCx3QkFBQyxRQUFEO01BQU0sVUFBVTtNQUFjLFdBQVU7Z0JBQXhDO09BQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7UUFDRSxTQUFRO1FBQ1IsV0FBVTtrQkFDWDtPQUVNOzs7O2lCQUNQLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQ2Isd0JBQUMsTUFBRCxFQUFNLFdBQVUsVUFBVzs7Ozs7UUFDeEI7Ozs7a0JBQ0wsd0JBQUMsU0FBRDtTQUNFLElBQUc7U0FDSCxNQUFLO1NBQ0wsT0FBTztTQUNQLFdBQVcsTUFBTSxTQUFTLEVBQUUsT0FBTyxLQUFLO1NBQ3hDLGFBQVk7U0FDWjtTQUNBLFVBQVU7U0FDVixXQUFVO1FBQ1g7Ozs7Z0JBQ0U7Ozs7O2VBQ0Y7Ozs7O09BRUwsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7UUFDRSxTQUFRO1FBQ1IsV0FBVTtrQkFDWDtPQUVNOzs7O2lCQUNQLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQ2Isd0JBQUMsTUFBRCxFQUFNLFdBQVUsVUFBVzs7Ozs7UUFDeEI7Ozs7a0JBQ0wsd0JBQUMsU0FBRDtTQUNFLElBQUc7U0FDSCxNQUFLO1NBQ0wsT0FBTztTQUNQLFdBQVcsTUFBTSxTQUFTLEVBQUUsT0FBTyxLQUFLO1NBQ3hDLGFBQVk7U0FDWjtTQUNBLFVBQVU7U0FDVixXQUFVO1FBQ1g7Ozs7Z0JBQ0U7Ozs7O2VBQ0Y7Ozs7O09BRUwsd0JBQUMsVUFBRDtRQUNFLE1BQUs7UUFDTCxVQUFVO1FBQ1YsV0FBVTtrQkFFVCxlQUNDLGdEQUNFLHdCQUFDLE9BQUQsRUFBSyxXQUFVLCtFQUFnRjs7OztrQkFDL0Ysd0JBQUMsUUFBRCxZQUFNLGtCQUFxQjs7OztnQkFDM0I7Ozs7bUJBRUYsd0JBQUMsUUFBRCxZQUFNLG9CQUF1Qjs7Ozs7T0FFekI7Ozs7O01BQ0o7Ozs7OztLQUdOLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxVQUFELEVBQVUsV0FBVSw0QkFBNkI7Ozs7aUJBQ2pELHdCQUFDLFFBQUQ7UUFBTTtRQUFrQyxXQUFXO1FBQVU7T0FBUTs7OztlQUNsRTs7Ozs7Z0JBRUwsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWY7UUFDRSx3QkFBQyxVQUFEO1NBQ0UsTUFBSztTQUNMLGVBQ0UsY0FBYywyQkFBMkIsa0JBQWtCO1NBRTdELFdBQVU7bUJBTFosQ0FPRSx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZ0M7U0FBaUI7Ozs7bUJBQ2hFLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFzQztTQUVoRDs7OztpQkFDQzs7Ozs7O1FBRVIsd0JBQUMsVUFBRDtTQUNFLE1BQUs7U0FDTCxlQUNFLGNBQ0Usc0NBQ0EsZ0JBQ0Y7U0FFRixXQUFVO21CQVJaLENBVUUsd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQThCO1NBQWdCOzs7O21CQUM3RCx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBc0M7U0FFaEQ7Ozs7aUJBQ0M7Ozs7OztRQUVSLHdCQUFDLFVBQUQ7U0FDRSxNQUFLO1NBQ0wsZUFDRSxjQUFjLGtDQUFrQyxjQUFjO1NBRWhFLFdBQVU7bUJBTFosQ0FPRSx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBOEI7U0FBcUI7Ozs7bUJBQ2xFLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFzQztTQUVoRDs7OztpQkFDQzs7Ozs7O1FBRVIsd0JBQUMsVUFBRDtTQUNFLE1BQUs7U0FDTCxlQUNFLGNBQ0Usb0NBQ0EsZ0JBQ0Y7U0FFRixXQUFVO21CQVJaLENBVUUsd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQStCO1NBQWM7Ozs7bUJBQzVELHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFzQztTQUVoRDs7OztpQkFDQzs7Ozs7O09BQ0w7Ozs7O2NBQ0Y7Ozs7OztJQUNGOzs7Ozs7R0FHTCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsS0FBRDtLQUNHLFdBQVc7S0FBTTtLQUFXLFdBQVc7SUFDdkM7Ozs7Y0FDSCx3QkFBQyxLQUFEO0tBQUcsV0FBVTtlQUFvQztJQUU5Qzs7OztZQUNBOzs7Ozs7RUFDRjs7Ozs7O0FBRVQ7Ozs7Ozs7OztBQUVBLGVBQWUiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiTG9naW5QYWdlLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyIvKipcclxuICogVGVsYSBkZSBBdXRlbnRpY2HDp8OjbyBkbyBTZXJ2aWRvciAoTG9naW5QYWdlKVxyXG4gKiBGb3JtdWzDoXJpbyBpbnN0aXR1Y2lvbmFsIGNvbSB2YWxpZGHDp8OjbywgdHJhdGFtZW50byBkZSBlcnJvcyBkYSBBUEksXHJcbiAqIGZlZWRiYWNrIGRlIGxvYWRpbmcgZSBwcmVlbmNoaW1lbnRvIHLDoXBpZG8gZGUgcGVyZmlzIHBhcmEgdGVzdGUgb3BlcmFjaW9uYWwuXHJcbiAqL1xyXG5cclxuaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7IHVzZUxvY2F0aW9uLCB1c2VOYXZpZ2F0ZSB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCI7XHJcbmltcG9ydCB7IEFsZXJ0VHJpYW5nbGUsIEtleVJvdW5kLCBMb2NrLCBNYWlsLCBTaGllbGQgfSBmcm9tIFwibHVjaWRlLXJlYWN0XCI7XHJcbmltcG9ydCB7IEFQUF9DT05GSUcgfSBmcm9tIFwiLi4vY29uZmlnL2FwcC5jb25maWdcIjtcclxuaW1wb3J0IHsgdXNlQXV0aCB9IGZyb20gXCIuLi9jb250ZXh0cy9BdXRoQ29udGV4dFwiO1xyXG5pbXBvcnQgYXV0aFNlcnZpY2UgZnJvbSBcIi4uL3NlcnZpY2VzL2F1dGhTZXJ2aWNlXCI7XHJcblxyXG5leHBvcnQgY29uc3QgTG9naW5QYWdlOiBSZWFjdC5GQyA9ICgpID0+IHtcclxuICBjb25zdCB7IGxvZ2luIH0gPSB1c2VBdXRoKCk7XHJcbiAgY29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpO1xyXG4gIGNvbnN0IGxvY2F0aW9uID0gdXNlTG9jYXRpb24oKTtcclxuXHJcbiAgY29uc3QgW2VtYWlsLCBzZXRFbWFpbF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbc2VuaGEsIHNldFNlbmhhXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtpc1N1Ym1pdHRpbmcsIHNldElzU3VibWl0dGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2Vycm9yTWVzc2FnZSwgc2V0RXJyb3JNZXNzYWdlXSA9IHVzZVN0YXRlPHN0cmluZyB8IG51bGw+KG51bGwpO1xyXG5cclxuICAvLyBEZXN0aW5vIHDDs3MtbG9naW4gKHJlc3BlaXRhbmRvIHJlZGlyZWNpb25hbWVudG8gZGUgUHJvdGVjdGVkUm91dGUpXHJcbiAgY29uc3QgZnJvbSA9XHJcbiAgICAobG9jYXRpb24uc3RhdGUgYXMgeyBmcm9tPzogeyBwYXRobmFtZTogc3RyaW5nIH0gfSk/LmZyb20/LnBhdGhuYW1lIHx8IFwiL1wiO1xyXG5cclxuICBjb25zdCBoYW5kbGVTdWJtaXQgPSBhc3luYyAoZTogUmVhY3QuRm9ybUV2ZW50KSA9PiB7XHJcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XHJcbiAgICBzZXRFcnJvck1lc3NhZ2UobnVsbCk7XHJcblxyXG4gICAgY29uc3QgY2xlYW5FbWFpbCA9IGVtYWlsLnRyaW0oKTtcclxuICAgIGlmICghY2xlYW5FbWFpbCkge1xyXG4gICAgICBzZXRFcnJvck1lc3NhZ2UoXCJQb3IgZmF2b3IsIGluZm9ybWUgc2V1IGUtbWFpbCBpbnN0aXR1Y2lvbmFsLlwiKTtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG4gICAgaWYgKCFzZW5oYSkge1xyXG4gICAgICBzZXRFcnJvck1lc3NhZ2UoXCJQb3IgZmF2b3IsIGRpZ2l0ZSBzdWEgc2VuaGEgZGUgYWNlc3NvLlwiKTtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG5cclxuICAgIHNldElzU3VibWl0dGluZyh0cnVlKTtcclxuICAgIHRyeSB7XHJcbiAgICAgIGF3YWl0IGxvZ2luKHsgZW1haWw6IGNsZWFuRW1haWwsIHNlbmhhIH0pO1xyXG4gICAgICBuYXZpZ2F0ZShmcm9tLCB7IHJlcGxhY2U6IHRydWUgfSk7XHJcbiAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgc2V0RXJyb3JNZXNzYWdlKGF1dGhTZXJ2aWNlLmdldEVycm9yTWVzc2FnZShlcnIpKTtcclxuICAgIH0gZmluYWxseSB7XHJcbiAgICAgIHNldElzU3VibWl0dGluZyhmYWxzZSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlUHJlRmlsbCA9ICh1c2VyRW1haWw6IHN0cmluZywgdXNlclBhc3M6IHN0cmluZykgPT4ge1xyXG4gICAgc2V0RW1haWwodXNlckVtYWlsKTtcclxuICAgIHNldFNlbmhhKHVzZXJQYXNzKTtcclxuICAgIHNldEVycm9yTWVzc2FnZShudWxsKTtcclxuICB9O1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJtaW4taC1zY3JlZW4gYmctc2xhdGUtOTAwIHRleHQtc2xhdGUtMTAwIGZsZXggZmxleC1jb2wganVzdGlmeS1iZXR3ZWVuIHAtNCBzbTpwLTYgbGc6cC04IGFudGlhbGlhc2VkXCI+XHJcbiAgICAgIHsvKiBUb3BvIEluc3RpdHVjaW9uYWwgKi99XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsIG1heC13LW1kIG14LWF1dG8gdGV4dC1jZW50ZXIgcHQtNiBzbTpwdC0xMFwiPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHctMTQgaC0xNCByb3VuZGVkLTJ4bCBiZy10ZWFsLTYwMCB0ZXh0LXdoaXRlIHNoYWRvdy1sZyBtYi00XCI+XHJcbiAgICAgICAgICA8U2hpZWxkIGNsYXNzTmFtZT1cInctNyBoLTdcIiAvPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBzbTp0ZXh0LTN4bCBmb250LWJvbGQgdHJhY2tpbmctdGlnaHQgdGV4dC13aGl0ZVwiPlxyXG4gICAgICAgICAge0FQUF9DT05GSUcubm9tZX1cclxuICAgICAgICA8L2gxPlxyXG4gICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgc206dGV4dC1zbSB0ZXh0LXNsYXRlLTQwMCBtdC0xXCI+XHJcbiAgICAgICAgICB7QVBQX0NPTkZJRy5zZWNyZXRhcmlhfSDCtyB7QVBQX0NPTkZJRy5tdW5pY2lwaW99L3tBUFBfQ09ORklHLnVmfVxyXG4gICAgICAgIDwvcD5cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICB7LyogQ2FydMOjbyBkZSBMb2dpbiAqL31cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgbWF4LXctbWQgbXgtYXV0byBteS04IGJnLXNsYXRlLTgwMC84MCBiYWNrZHJvcC1ibHVyLW1kIGJvcmRlciBib3JkZXItc2xhdGUtNzAwLzYwIHJvdW5kZWQtMnhsIHAtNiBzbTpwLTggc2hhZG93LTJ4bFwiPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNlwiPlxyXG4gICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1zZW1pYm9sZCB0ZXh0LXdoaXRlXCI+XHJcbiAgICAgICAgICAgIEFjZXNzbyBkbyBTZXJ2aWRvclxyXG4gICAgICAgICAgPC9oMj5cclxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS00MDAgbXQtMC41XCI+XHJcbiAgICAgICAgICAgIEVudHJlIGNvbSBzdWFzIGNyZWRlbmNpYWlzIGZ1bmNpb25haXMgcGFyYSBhY2Vzc2FyIG9zIHNlcnZpw6dvcyBkZSBmaXNjYWxpemHDp8Ojby5cclxuICAgICAgICAgIDwvcD5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAge2Vycm9yTWVzc2FnZSAmJiAoXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTUgcC0zIHJvdW5kZWQtbGcgYmctcm9zZS05NTAvNjAgYm9yZGVyIGJvcmRlci1yb3NlLTgwMC82MCB0ZXh0LXJvc2UtMjAwIHRleHQteHMgZmxleCBpdGVtcy1zdGFydCBnYXAtMi41XCI+XHJcbiAgICAgICAgICAgIDxBbGVydFRyaWFuZ2xlIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1yb3NlLTQwMCBzaHJpbmstMCBtdC0wLjVcIiAvPlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJsZWFkaW5nLXJlbGF4ZWRcIj57ZXJyb3JNZXNzYWdlfTwvc3Bhbj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICl9XHJcblxyXG4gICAgICAgIDxmb3JtIG9uU3VibWl0PXtoYW5kbGVTdWJtaXR9IGNsYXNzTmFtZT1cInNwYWNlLXktNFwiPlxyXG4gICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgaHRtbEZvcj1cImVtYWlsXCJcclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtc2xhdGUtMzAwIG1iLTEuNVwiXHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICBFLW1haWwgSW5zdGl0dWNpb25hbFxyXG4gICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlXCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSBpbnNldC15LTAgbGVmdC0wIHBsLTMgZmxleCBpdGVtcy1jZW50ZXIgcG9pbnRlci1ldmVudHMtbm9uZSB0ZXh0LXNsYXRlLTQwMFwiPlxyXG4gICAgICAgICAgICAgICAgPE1haWwgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICBpZD1cImVtYWlsXCJcclxuICAgICAgICAgICAgICAgIHR5cGU9XCJlbWFpbFwiXHJcbiAgICAgICAgICAgICAgICB2YWx1ZT17ZW1haWx9XHJcbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEVtYWlsKGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwic2Vydmlkb3JAYnJhdW5hcy5tZy5nb3YuYnJcIlxyXG4gICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgIGRpc2FibGVkPXtpc1N1Ym1pdHRpbmd9XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcGwtOSBwci0zIHB5LTIgYmctc2xhdGUtOTAwLzgwIGJvcmRlciBib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQtbGcgdGV4dC1zbSB0ZXh0LXdoaXRlIHBsYWNlaG9sZGVyLXNsYXRlLTUwMCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctdGVhbC01MDAgZm9jdXM6Ym9yZGVyLXRyYW5zcGFyZW50IHRyYW5zaXRpb24tYWxsIGRpc2FibGVkOm9wYWNpdHktNTBcIlxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgaHRtbEZvcj1cInNlbmhhXCJcclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtc2xhdGUtMzAwIG1iLTEuNVwiXHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICBTZW5oYVxyXG4gICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlXCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSBpbnNldC15LTAgbGVmdC0wIHBsLTMgZmxleCBpdGVtcy1jZW50ZXIgcG9pbnRlci1ldmVudHMtbm9uZSB0ZXh0LXNsYXRlLTQwMFwiPlxyXG4gICAgICAgICAgICAgICAgPExvY2sgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICBpZD1cInNlbmhhXCJcclxuICAgICAgICAgICAgICAgIHR5cGU9XCJwYXNzd29yZFwiXHJcbiAgICAgICAgICAgICAgICB2YWx1ZT17c2VuaGF9XHJcbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFNlbmhhKGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwi4oCi4oCi4oCi4oCi4oCi4oCi4oCi4oCi4oCi4oCi4oCi4oCiXCJcclxuICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICBkaXNhYmxlZD17aXNTdWJtaXR0aW5nfVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHBsLTkgcHItMyBweS0yIGJnLXNsYXRlLTkwMC84MCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCByb3VuZGVkLWxnIHRleHQtc20gdGV4dC13aGl0ZSBwbGFjZWhvbGRlci1zbGF0ZS01MDAgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLXRlYWwtNTAwIGZvY3VzOmJvcmRlci10cmFuc3BhcmVudCB0cmFuc2l0aW9uLWFsbCBkaXNhYmxlZDpvcGFjaXR5LTUwXCJcclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgdHlwZT1cInN1Ym1pdFwiXHJcbiAgICAgICAgICAgIGRpc2FibGVkPXtpc1N1Ym1pdHRpbmd9XHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBtdC0yIHB5LTIuNSBweC00IGJnLXRlYWwtNjAwIGhvdmVyOmJnLXRlYWwtNTAwIHRleHQtd2hpdGUgdGV4dC1zbSBmb250LXNlbWlib2xkIHJvdW5kZWQtbGcgc2hhZG93LXNtIGhvdmVyOnNoYWRvdyB0cmFuc2l0aW9uLWFsbCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctdGVhbC00MDAgZm9jdXM6cmluZy1vZmZzZXQtMiBmb2N1czpyaW5nLW9mZnNldC1zbGF0ZS04MDAgZGlzYWJsZWQ6b3BhY2l0eS02MCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMlwiXHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIHtpc1N1Ym1pdHRpbmcgPyAoXHJcbiAgICAgICAgICAgICAgPD5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy00IGgtNCBib3JkZXItMiBib3JkZXItd2hpdGUgYm9yZGVyLXQtdHJhbnNwYXJlbnQgcm91bmRlZC1mdWxsIGFuaW1hdGUtc3BpblwiIC8+XHJcbiAgICAgICAgICAgICAgICA8c3Bhbj5BdXRlbnRpY2FuZG8uLi48L3NwYW4+XHJcbiAgICAgICAgICAgICAgPC8+XHJcbiAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgPHNwYW4+RW50cmFyIG5vIFNpc3RlbWE8L3NwYW4+XHJcbiAgICAgICAgICAgICl9XHJcbiAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICA8L2Zvcm0+XHJcblxyXG4gICAgICAgIHsvKiBBdGFsaG9zIHBhcmEgQ29udGFzIFNlZWQgZGUgRGVtb25zdHJhw6fDo28gKi99XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC04IHB0LTUgYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTcwMC82MFwiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1zbGF0ZS00MDAgbWItMi41XCI+XHJcbiAgICAgICAgICAgIDxLZXlSb3VuZCBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNSB0ZXh0LXRlYWwtNDAwXCIgLz5cclxuICAgICAgICAgICAgPHNwYW4+QWNlc3NvIFLDoXBpZG8gKENvbnRhcyBkZSBUZXN0ZSAtIHtBUFBfQ09ORklHLm11bmljaXBpb30pOjwvc3Bhbj5cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMiBnYXAtMiB0ZXh0LVsxMXB4XVwiPlxyXG4gICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT5cclxuICAgICAgICAgICAgICAgIGhhbmRsZVByZUZpbGwoXCJhZG1pbkBicmF1bmFzLm1nLmdvdi5iclwiLCBcIkFkbWluTWFzdGVyQDIwMjZcIilcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0yIHRleHQtbGVmdCBiZy1zbGF0ZS05MDAvNjAgaG92ZXI6Ymctc2xhdGUtNzAwLzYwIGJvcmRlciBib3JkZXItc2xhdGUtNzAwLzYwIHJvdW5kZWQtbWQgdHJhbnNpdGlvbi1jb2xvcnNcIlxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtcHVycGxlLTMwMFwiPkFkbWluIE1hc3RlcjwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDAgdGV4dC1bMTBweF0gdHJ1bmNhdGVcIj5cclxuICAgICAgICAgICAgICAgIGFkbWluQGJyYXVuYXMubWcuZ292LmJyXHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvYnV0dG9uPlxyXG5cclxuICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+XHJcbiAgICAgICAgICAgICAgICBoYW5kbGVQcmVGaWxsKFxyXG4gICAgICAgICAgICAgICAgICBcImNvb3JkZW5hZG9yLnZpc2FAYnJhdW5hcy5tZy5nb3YuYnJcIixcclxuICAgICAgICAgICAgICAgICAgXCJDb29yZFZpc2FAMjAyNlwiXHJcbiAgICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMiB0ZXh0LWxlZnQgYmctc2xhdGUtOTAwLzYwIGhvdmVyOmJnLXNsYXRlLTcwMC82MCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMC82MCByb3VuZGVkLW1kIHRyYW5zaXRpb24tY29sb3JzXCJcclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LWJsdWUtMzAwXCI+Q29vcmRlbmFkb3I8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNDAwIHRleHQtWzEwcHhdIHRydW5jYXRlXCI+XHJcbiAgICAgICAgICAgICAgICBjb29yZGVuYWRvci52aXNhQC4uLlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2J1dHRvbj5cclxuXHJcbiAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PlxyXG4gICAgICAgICAgICAgICAgaGFuZGxlUHJlRmlsbChcImZpc2NhbDEudmlzYUBicmF1bmFzLm1nLmdvdi5iclwiLCBcIkZpc2NhbDFAMjAyNlwiKVxyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTIgdGV4dC1sZWZ0IGJnLXNsYXRlLTkwMC82MCBob3ZlcjpiZy1zbGF0ZS03MDAvNjAgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAvNjAgcm91bmRlZC1tZCB0cmFuc2l0aW9uLWNvbG9yc1wiXHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC10ZWFsLTMwMFwiPkZpc2NhbCBTYW5pdMOhcmlvPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMCB0ZXh0LVsxMHB4XSB0cnVuY2F0ZVwiPlxyXG4gICAgICAgICAgICAgICAgZmlzY2FsMS52aXNhQC4uLlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2J1dHRvbj5cclxuXHJcbiAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PlxyXG4gICAgICAgICAgICAgICAgaGFuZGxlUHJlRmlsbChcclxuICAgICAgICAgICAgICAgICAgXCJkaWdpdGFkb3IudmlzYUBicmF1bmFzLm1nLmdvdi5iclwiLFxyXG4gICAgICAgICAgICAgICAgICBcIkRpZ2l0YWRvckAyMDI2XCJcclxuICAgICAgICAgICAgICAgIClcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0yIHRleHQtbGVmdCBiZy1zbGF0ZS05MDAvNjAgaG92ZXI6Ymctc2xhdGUtNzAwLzYwIGJvcmRlciBib3JkZXItc2xhdGUtNzAwLzYwIHJvdW5kZWQtbWQgdHJhbnNpdGlvbi1jb2xvcnNcIlxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtc2xhdGUtMzAwXCI+RGlnaXRhZG9yPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMCB0ZXh0LVsxMHB4XSB0cnVuY2F0ZVwiPlxyXG4gICAgICAgICAgICAgICAgZGlnaXRhZG9yLnZpc2FALi4uXHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgey8qIFJvZGFww6kgT2ZpY2lhbCBkYSBUZWxhIGRlIExvZ2luICovfVxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBtYXgtdy1tZCBteC1hdXRvIHRleHQtY2VudGVyIHBiLTQgdGV4dC14cyB0ZXh0LXNsYXRlLTUwMFwiPlxyXG4gICAgICAgIDxwPlxyXG4gICAgICAgICAge0FQUF9DT05GSUcub3JnYW99IMK3IFZlcnPDo28ge0FQUF9DT05GSUcudmVyc2FvfVxyXG4gICAgICAgIDwvcD5cclxuICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LXNsYXRlLTYwMCBtdC0wLjVcIj5cclxuICAgICAgICAgIEFjZXNzbyByZXN0cml0byBhIHNlcnZpZG9yZXMgYXV0b3JpemFkb3MgZGEgVmlnaWzDom5jaWEgU2FuaXTDoXJpYSBNdW5pY2lwYWwuXHJcbiAgICAgICAgPC9wPlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBMb2dpblBhZ2U7XHJcbiJdfQ==