import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/licenciamento/AlvaraViewPage.tsx");const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport6_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport6_react_jsxDevRuntime["Fragment"];/**
* Visualização e Impressão de Alvará Sanitário Expedido
* Rota: /licenciamento/alvaras/:id
* Incorpora AlvaraImpressaoView e disponibiliza atalhos de impressão direta e link do QR Code.
*/
import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=0fd2848a";
import { Link, useParams } from "/node_modules/.vite/deps/react-router-dom.js?v=0fd2848a";
import { AlertTriangle, ArrowLeft, Check, Copy, ExternalLink, Printer, QrCode, ShieldCheck } from "/node_modules/.vite/deps/lucide-react.js?v=0fd2848a";
import { ROUTES } from "/src/config/routes.config.ts";
import { useAlvaraDetalhe } from "/src/hooks/useLicenciamento.ts";
import { AlvaraImpressaoView } from "/src/components/licenciamento/AlvaraImpressaoView.tsx";
var _jsxFileName = "E:/Projetos VSCODE/visa_braunas/src/pages/licenciamento/AlvaraViewPage.tsx";
import __vite__cjsImport6_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=0fd2848a";
var _s = $RefreshSig$();
export const AlvaraViewPage = () => {
	_s();
	const { id } = useParams();
	const { data: alvara, isLoading, isError } = useAlvaraDetalhe(id);
	const [copiado, setCopiado] = useState(false);
	if (isLoading) {
		return /* @__PURE__ */ _jsxDEV("div", {
			className: "p-16 text-center text-slate-400 text-xs flex flex-col items-center justify-center",
			children: [/* @__PURE__ */ _jsxDEV("div", { className: "w-6 h-6 border-2 border-teal-500 border-t-transparent rounded-full animate-spin mb-3" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 31,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Carregando documento oficial do Alvará Sanitário..." }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 32,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 30,
			columnNumber: 7
		}, this);
	}
	if (isError || !alvara) {
		return /* @__PURE__ */ _jsxDEV("div", {
			className: "p-8 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl text-center space-y-4 max-w-xl mx-auto mt-8",
			children: [
				/* @__PURE__ */ _jsxDEV(AlertTriangle, { className: "w-10 h-10 text-rose-500 mx-auto" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 40,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("h2", {
					className: "text-sm font-bold text-slate-900 dark:text-white",
					children: "Alvará Sanitário não localizado"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 41,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("p", {
					className: "text-xs text-slate-500",
					children: "Não foi possível carregar os registros deste documento de autorização sanitária."
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 44,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV(Link, {
					to: ROUTES.LICENCIAMENTO.LIST,
					className: "inline-flex items-center gap-1.5 px-4 py-2 text-xs font-bold text-teal-700 bg-teal-50 rounded-xl border border-teal-200 hover:bg-teal-100",
					children: [/* @__PURE__ */ _jsxDEV(ArrowLeft, { className: "w-3.5 h-3.5" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 51,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Voltar para Licenciamento" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 52,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 47,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 39,
			columnNumber: 7
		}, this);
	}
	const baseUrl = typeof window !== "undefined" ? window.location.origin : "";
	const urlValidacaoPublica = `${baseUrl}${ROUTES.PUBLIC.VALIDAR_ALVARA(alvara.codigo_autenticidade)}`;
	const handleCopiarLink = async () => {
		try {
			await navigator.clipboard.writeText(urlValidacaoPublica);
			setCopiado(true);
			setTimeout(() => setCopiado(false), 2500);
		} catch {}
	};
	const handleImprimir = () => {
		window.print();
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "space-y-6 pb-12",
		children: [/* @__PURE__ */ _jsxDEV("div", {
			className: "no-print bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4",
			children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "flex items-center gap-3",
				children: [/* @__PURE__ */ _jsxDEV(Link, {
					to: ROUTES.LICENCIAMENTO.LIST,
					className: "p-2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-300 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors",
					title: "Voltar para a Fila",
					children: /* @__PURE__ */ _jsxDEV(ArrowLeft, { className: "w-4 h-4" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 85,
						columnNumber: 13
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 80,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h1", {
					className: "text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2",
					children: [/* @__PURE__ */ _jsxDEV(ShieldCheck, { className: "w-4 h-4 text-teal-600" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 89,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("span", { children: ["Alvará Nº ", alvara.numero_formatado || `${alvara.numero_alvara}/${alvara.exercicio}`] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 90,
						columnNumber: 15
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 88,
					columnNumber: 13
				}, this), /* @__PURE__ */ _jsxDEV("p", {
					className: "text-[11px] text-slate-500 font-mono",
					children: ["Código de Autenticidade: ", alvara.codigo_autenticidade]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 92,
					columnNumber: 13
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 87,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 79,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("div", {
				className: "flex flex-wrap items-center gap-2",
				children: [
					/* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						onClick: handleCopiarLink,
						className: "px-3 py-1.5 text-xs font-semibold text-slate-700 dark:text-slate-200 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-700 shadow-2xs inline-flex items-center gap-1.5 transition-colors",
						children: copiado ? /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV(Check, { className: "w-3.5 h-3.5 text-emerald-600" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 106,
							columnNumber: 17
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							className: "text-emerald-700 dark:text-emerald-400",
							children: "Link Copiado!"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 107,
							columnNumber: 17
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 105,
							columnNumber: 15
						}, this) : /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV(Copy, { className: "w-3.5 h-3.5 text-slate-500" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 111,
							columnNumber: 17
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Copiar Link QR Code" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 112,
							columnNumber: 17
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 110,
							columnNumber: 15
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 99,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV(Link, {
						to: ROUTES.PUBLIC.VALIDAR_ALVARA(alvara.codigo_autenticidade),
						target: "_blank",
						className: "px-3 py-1.5 text-xs font-semibold text-teal-700 dark:text-teal-300 bg-teal-50 dark:bg-teal-950/40 border border-teal-200 dark:border-teal-800 rounded-lg hover:bg-teal-100/60 shadow-2xs inline-flex items-center gap-1.5 transition-colors",
						children: [
							/* @__PURE__ */ _jsxDEV(QrCode, { className: "w-3.5 h-3.5" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 122,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("span", { children: "Validação Pública" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 123,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV(ExternalLink, { className: "w-3 h-3 opacity-60" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 124,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 117,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						onClick: handleImprimir,
						className: "px-4 py-1.5 text-xs font-bold text-white bg-teal-600 hover:bg-teal-700 rounded-lg shadow-xs inline-flex items-center gap-1.5 transition-colors",
						children: [/* @__PURE__ */ _jsxDEV(Printer, { className: "w-4 h-4" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 132,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Imprimir Alvará (A4)" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 133,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 127,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 98,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 78,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV(AlvaraImpressaoView, { alvara }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 139,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 76,
		columnNumber: 5
	}, this);
};
_s(AlvaraViewPage, "krp85dqbiSLidKwgllapQ/mlAQo=", false, function() {
	return [useParams, useAlvaraDetalhe];
});
_c = AlvaraViewPage;
export default AlvaraViewPage;
var _c;
$RefreshReg$(_c, "AlvaraViewPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/licenciamento/AlvaraViewPage.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("E:/Projetos VSCODE/visa_braunas/src/pages/licenciamento/AlvaraViewPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("E:/Projetos VSCODE/visa_braunas/src/pages/licenciamento/AlvaraViewPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "E:/Projetos VSCODE/visa_braunas/src/pages/licenciamento/AlvaraViewPage.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7Ozs7QUFNQSxPQUFPLFNBQVMsZ0JBQWdCO0FBQ2hDLFNBQVMsTUFBTSxpQkFBaUI7QUFDaEMsU0FDRSxlQUNBLFdBQ0EsT0FDQSxNQUNBLGNBQ0EsU0FDQSxRQUNBLG1CQUNLO0FBQ1AsU0FBUyxjQUFjO0FBQ3ZCLFNBQVMsd0JBQXdCO0FBQ2pDLFNBQVMsMkJBQTJCOzs7O0FBRXBDLE9BQU8sTUFBTSx1QkFBaUM7O0NBQzVDLE1BQU0sRUFBRSxPQUFPLFVBQTBCO0NBQ3pDLE1BQU0sRUFBRSxNQUFNLFFBQVEsV0FBVyxZQUFZLGlCQUFpQixFQUFFO0NBQ2hFLE1BQU0sQ0FBQyxTQUFTLGNBQWMsU0FBUyxLQUFLO0NBRTVDLElBQUksV0FBVztFQUNiLE9BQ0Usd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZixDQUNFLHdCQUFDLE9BQUQsRUFBSyxXQUFVLHVGQUF3Rjs7OzthQUN2Ryx3QkFBQyxRQUFELFlBQU0sc0RBQXlEOzs7O1dBQzVEOzs7Ozs7Q0FFVDtDQUVBLElBQUksV0FBVyxDQUFDLFFBQVE7RUFDdEIsT0FDRSx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmO0lBQ0Usd0JBQUMsZUFBRCxFQUFlLFdBQVUsa0NBQW1DOzs7OztJQUM1RCx3QkFBQyxNQUFEO0tBQUksV0FBVTtlQUFtRDtJQUU3RDs7Ozs7SUFDSix3QkFBQyxLQUFEO0tBQUcsV0FBVTtlQUF5QjtJQUVuQzs7Ozs7SUFDSCx3QkFBQyxNQUFEO0tBQ0UsSUFBSSxPQUFPLGNBQWM7S0FDekIsV0FBVTtlQUZaLENBSUUsd0JBQUMsV0FBRCxFQUFXLFdBQVUsY0FBZTs7OztlQUNwQyx3QkFBQyxRQUFELFlBQU0sNEJBQStCOzs7O2FBQ2pDOzs7Ozs7R0FDSDs7Ozs7O0NBRVQ7Q0FFQSxNQUFNLFVBQVUsT0FBTyxXQUFXLGNBQWMsT0FBTyxTQUFTLFNBQVM7Q0FDekUsTUFBTSxzQkFBc0IsR0FBRyxVQUFVLE9BQU8sT0FBTyxlQUFlLE9BQU8sb0JBQW9CO0NBRWpHLE1BQU0sbUJBQW1CLFlBQVk7RUFDbkMsSUFBSTtHQUNGLE1BQU0sVUFBVSxVQUFVLFVBQVUsbUJBQW1CO0dBQ3ZELFdBQVcsSUFBSTtHQUNmLGlCQUFpQixXQUFXLEtBQUssR0FBRyxJQUFJO0VBQzFDLFFBQVEsQ0FFUjtDQUNGO0NBRUEsTUFBTSx1QkFBdUI7RUFDM0IsT0FBTyxNQUFNO0NBQ2Y7Q0FFQSxPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQWYsQ0FFRSx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmLENBQ0Usd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLE1BQUQ7S0FDRSxJQUFJLE9BQU8sY0FBYztLQUN6QixXQUFVO0tBQ1YsT0FBTTtlQUVOLHdCQUFDLFdBQUQsRUFBVyxXQUFVLFVBQVc7Ozs7O0lBQzVCOzs7O2NBQ04sd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE1BQUQ7S0FBSSxXQUFVO2VBQWQsQ0FDRSx3QkFBQyxhQUFELEVBQWEsV0FBVSx3QkFBeUI7Ozs7ZUFDaEQsd0JBQUMsUUFBRCxhQUFNLGNBQVcsT0FBTyxvQkFBb0IsR0FBRyxPQUFPLGNBQWMsR0FBRyxPQUFPLFdBQWtCOzs7O2FBQzlGOzs7OztjQUNKLHdCQUFDLEtBQUQ7S0FBRyxXQUFVO2VBQWIsQ0FBb0QsNkJBQ3hCLE9BQU8sb0JBQ2hDOzs7OztZQUNBOzs7O1lBQ0Y7Ozs7O2FBRUwsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZjtLQUNFLHdCQUFDLFVBQUQ7TUFDRSxNQUFLO01BQ0wsU0FBUztNQUNULFdBQVU7Z0JBRVQsVUFDQyxnREFDRSx3QkFBQyxPQUFELEVBQU8sV0FBVSwrQkFBZ0M7Ozs7Z0JBQ2pELHdCQUFDLFFBQUQ7T0FBTSxXQUFVO2lCQUF5QztNQUFtQjs7OztjQUM1RTs7OztpQkFFRixnREFDRSx3QkFBQyxNQUFELEVBQU0sV0FBVSw2QkFBOEI7Ozs7Z0JBQzlDLHdCQUFDLFFBQUQsWUFBTSxzQkFBeUI7Ozs7Y0FDL0I7Ozs7O0tBRUU7Ozs7O0tBRVIsd0JBQUMsTUFBRDtNQUNFLElBQUksT0FBTyxPQUFPLGVBQWUsT0FBTyxvQkFBb0I7TUFDNUQsUUFBTztNQUNQLFdBQVU7Z0JBSFo7T0FLRSx3QkFBQyxRQUFELEVBQVEsV0FBVSxjQUFlOzs7OztPQUNqQyx3QkFBQyxRQUFELFlBQU0sb0JBQXVCOzs7OztPQUM3Qix3QkFBQyxjQUFELEVBQWMsV0FBVSxxQkFBc0I7Ozs7O01BQzFDOzs7Ozs7S0FFTix3QkFBQyxVQUFEO01BQ0UsTUFBSztNQUNMLFNBQVM7TUFDVCxXQUFVO2dCQUhaLENBS0Usd0JBQUMsU0FBRCxFQUFTLFdBQVUsVUFBVzs7OztnQkFDOUIsd0JBQUMsUUFBRCxZQUFNLHVCQUEwQjs7OztjQUMxQjs7Ozs7O0lBQ0w7Ozs7O1dBQ0Y7Ozs7O1lBR0wsd0JBQUMscUJBQUQsRUFBNkIsT0FBUzs7OztVQUNuQzs7Ozs7O0FBRVQ7Ozs7O0FBRUEsZUFBZSIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJBbHZhcmFWaWV3UGFnZS50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiLyoqXHJcbiAqIFZpc3VhbGl6YcOnw6NvIGUgSW1wcmVzc8OjbyBkZSBBbHZhcsOhIFNhbml0w6FyaW8gRXhwZWRpZG9cclxuICogUm90YTogL2xpY2VuY2lhbWVudG8vYWx2YXJhcy86aWRcclxuICogSW5jb3Jwb3JhIEFsdmFyYUltcHJlc3Nhb1ZpZXcgZSBkaXNwb25pYmlsaXphIGF0YWxob3MgZGUgaW1wcmVzc8OjbyBkaXJldGEgZSBsaW5rIGRvIFFSIENvZGUuXHJcbiAqL1xyXG5cclxuaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7IExpbmssIHVzZVBhcmFtcyB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCI7XHJcbmltcG9ydCB7XHJcbiAgQWxlcnRUcmlhbmdsZSxcclxuICBBcnJvd0xlZnQsXHJcbiAgQ2hlY2ssXHJcbiAgQ29weSxcclxuICBFeHRlcm5hbExpbmssXHJcbiAgUHJpbnRlcixcclxuICBRckNvZGUsXHJcbiAgU2hpZWxkQ2hlY2ssXHJcbn0gZnJvbSBcImx1Y2lkZS1yZWFjdFwiO1xyXG5pbXBvcnQgeyBST1VURVMgfSBmcm9tIFwiLi4vLi4vY29uZmlnL3JvdXRlcy5jb25maWdcIjtcclxuaW1wb3J0IHsgdXNlQWx2YXJhRGV0YWxoZSB9IGZyb20gXCIuLi8uLi9ob29rcy91c2VMaWNlbmNpYW1lbnRvXCI7XHJcbmltcG9ydCB7IEFsdmFyYUltcHJlc3Nhb1ZpZXcgfSBmcm9tIFwiLi4vLi4vY29tcG9uZW50cy9saWNlbmNpYW1lbnRvL0FsdmFyYUltcHJlc3Nhb1ZpZXdcIjtcclxuXHJcbmV4cG9ydCBjb25zdCBBbHZhcmFWaWV3UGFnZTogUmVhY3QuRkMgPSAoKSA9PiB7XHJcbiAgY29uc3QgeyBpZCB9ID0gdXNlUGFyYW1zPHsgaWQ6IHN0cmluZyB9PigpO1xyXG4gIGNvbnN0IHsgZGF0YTogYWx2YXJhLCBpc0xvYWRpbmcsIGlzRXJyb3IgfSA9IHVzZUFsdmFyYURldGFsaGUoaWQpO1xyXG4gIGNvbnN0IFtjb3BpYWRvLCBzZXRDb3BpYWRvXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuXHJcbiAgaWYgKGlzTG9hZGluZykge1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTE2IHRleHQtY2VudGVyIHRleHQtc2xhdGUtNDAwIHRleHQteHMgZmxleCBmbGV4LWNvbCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXJcIj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctNiBoLTYgYm9yZGVyLTIgYm9yZGVyLXRlYWwtNTAwIGJvcmRlci10LXRyYW5zcGFyZW50IHJvdW5kZWQtZnVsbCBhbmltYXRlLXNwaW4gbWItM1wiIC8+XHJcbiAgICAgICAgPHNwYW4+Q2FycmVnYW5kbyBkb2N1bWVudG8gb2ZpY2lhbCBkbyBBbHZhcsOhIFNhbml0w6FyaW8uLi48L3NwYW4+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgKTtcclxuICB9XHJcblxyXG4gIGlmIChpc0Vycm9yIHx8ICFhbHZhcmEpIHtcclxuICAgIHJldHVybiAoXHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC04IGJnLXdoaXRlIGRhcms6Ymctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLTJ4bCB0ZXh0LWNlbnRlciBzcGFjZS15LTQgbWF4LXcteGwgbXgtYXV0byBtdC04XCI+XHJcbiAgICAgICAgPEFsZXJ0VHJpYW5nbGUgY2xhc3NOYW1lPVwidy0xMCBoLTEwIHRleHQtcm9zZS01MDAgbXgtYXV0b1wiIC8+XHJcbiAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1ib2xkIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZVwiPlxyXG4gICAgICAgICAgQWx2YXLDoSBTYW5pdMOhcmlvIG7Do28gbG9jYWxpemFkb1xyXG4gICAgICAgIDwvaDI+XHJcbiAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTUwMFwiPlxyXG4gICAgICAgICAgTsOjbyBmb2kgcG9zc8OtdmVsIGNhcnJlZ2FyIG9zIHJlZ2lzdHJvcyBkZXN0ZSBkb2N1bWVudG8gZGUgYXV0b3JpemHDp8OjbyBzYW5pdMOhcmlhLlxyXG4gICAgICAgIDwvcD5cclxuICAgICAgICA8TGlua1xyXG4gICAgICAgICAgdG89e1JPVVRFUy5MSUNFTkNJQU1FTlRPLkxJU1R9XHJcbiAgICAgICAgICBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBweC00IHB5LTIgdGV4dC14cyBmb250LWJvbGQgdGV4dC10ZWFsLTcwMCBiZy10ZWFsLTUwIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci10ZWFsLTIwMCBob3ZlcjpiZy10ZWFsLTEwMFwiXHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgPEFycm93TGVmdCBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNVwiIC8+XHJcbiAgICAgICAgICA8c3Bhbj5Wb2x0YXIgcGFyYSBMaWNlbmNpYW1lbnRvPC9zcGFuPlxyXG4gICAgICAgIDwvTGluaz5cclxuICAgICAgPC9kaXY+XHJcbiAgICApO1xyXG4gIH1cclxuXHJcbiAgY29uc3QgYmFzZVVybCA9IHR5cGVvZiB3aW5kb3cgIT09IFwidW5kZWZpbmVkXCIgPyB3aW5kb3cubG9jYXRpb24ub3JpZ2luIDogXCJcIjtcclxuICBjb25zdCB1cmxWYWxpZGFjYW9QdWJsaWNhID0gYCR7YmFzZVVybH0ke1JPVVRFUy5QVUJMSUMuVkFMSURBUl9BTFZBUkEoYWx2YXJhLmNvZGlnb19hdXRlbnRpY2lkYWRlKX1gO1xyXG5cclxuICBjb25zdCBoYW5kbGVDb3BpYXJMaW5rID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgYXdhaXQgbmF2aWdhdG9yLmNsaXBib2FyZC53cml0ZVRleHQodXJsVmFsaWRhY2FvUHVibGljYSk7XHJcbiAgICAgIHNldENvcGlhZG8odHJ1ZSk7XHJcbiAgICAgIHNldFRpbWVvdXQoKCkgPT4gc2V0Q29waWFkbyhmYWxzZSksIDI1MDApO1xyXG4gICAgfSBjYXRjaCB7XHJcbiAgICAgIC8vIEZhbGxiYWNrXHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlSW1wcmltaXIgPSAoKSA9PiB7XHJcbiAgICB3aW5kb3cucHJpbnQoKTtcclxuICB9O1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTYgcGItMTJcIj5cclxuICAgICAgey8qIEJhcnJhIGRlIEHDp8O1ZXMgU3VwZXJpb3IgKE9jdWx0YWRhIG5hIEltcHJlc3PDo28gdmlhIGNsYXNzZSBuby1wcmludCkgKi99XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwibm8tcHJpbnQgYmctd2hpdGUgZGFyazpiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtODAwIHJvdW5kZWQtMnhsIHAtNCBzaGFkb3cteHMgZmxleCBmbGV4LWNvbCBzbTpmbGV4LXJvdyBzbTppdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC00XCI+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxyXG4gICAgICAgICAgPExpbmtcclxuICAgICAgICAgICAgdG89e1JPVVRFUy5MSUNFTkNJQU1FTlRPLkxJU1R9XHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMiB0ZXh0LXNsYXRlLTQwMCBob3Zlcjp0ZXh0LXNsYXRlLTYwMCBkYXJrOmhvdmVyOnRleHQtc2xhdGUtMzAwIHJvdW5kZWQtbGcgaG92ZXI6Ymctc2xhdGUtMTAwIGRhcms6aG92ZXI6Ymctc2xhdGUtODAwIHRyYW5zaXRpb24tY29sb3JzXCJcclxuICAgICAgICAgICAgdGl0bGU9XCJWb2x0YXIgcGFyYSBhIEZpbGFcIlxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICA8QXJyb3dMZWZ0IGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPlxyXG4gICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1ib2xkIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgIDxTaGllbGRDaGVjayBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtdGVhbC02MDBcIiAvPlxyXG4gICAgICAgICAgICAgIDxzcGFuPkFsdmFyw6EgTsK6IHthbHZhcmEubnVtZXJvX2Zvcm1hdGFkbyB8fCBgJHthbHZhcmEubnVtZXJvX2FsdmFyYX0vJHthbHZhcmEuZXhlcmNpY2lvfWB9PC9zcGFuPlxyXG4gICAgICAgICAgICA8L2gxPlxyXG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LXNsYXRlLTUwMCBmb250LW1vbm9cIj5cclxuICAgICAgICAgICAgICBDw7NkaWdvIGRlIEF1dGVudGljaWRhZGU6IHthbHZhcmEuY29kaWdvX2F1dGVudGljaWRhZGV9XHJcbiAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgb25DbGljaz17aGFuZGxlQ29waWFyTGlua31cclxuICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtMyBweS0xLjUgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0yMDAgYmctc2xhdGUtNTAgZGFyazpiZy1zbGF0ZS04MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQtbGcgaG92ZXI6Ymctc2xhdGUtMTAwIGRhcms6aG92ZXI6Ymctc2xhdGUtNzAwIHNoYWRvdy0yeHMgaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgdHJhbnNpdGlvbi1jb2xvcnNcIlxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICB7Y29waWFkbyA/IChcclxuICAgICAgICAgICAgICA8PlxyXG4gICAgICAgICAgICAgICAgPENoZWNrIGNsYXNzTmFtZT1cInctMy41IGgtMy41IHRleHQtZW1lcmFsZC02MDBcIiAvPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1lbWVyYWxkLTcwMCBkYXJrOnRleHQtZW1lcmFsZC00MDBcIj5MaW5rIENvcGlhZG8hPC9zcGFuPlxyXG4gICAgICAgICAgICAgIDwvPlxyXG4gICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAgICA8Q29weSBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNSB0ZXh0LXNsYXRlLTUwMFwiIC8+XHJcbiAgICAgICAgICAgICAgICA8c3Bhbj5Db3BpYXIgTGluayBRUiBDb2RlPC9zcGFuPlxyXG4gICAgICAgICAgICAgIDwvPlxyXG4gICAgICAgICAgICApfVxyXG4gICAgICAgICAgPC9idXR0b24+XHJcblxyXG4gICAgICAgICAgPExpbmtcclxuICAgICAgICAgICAgdG89e1JPVVRFUy5QVUJMSUMuVkFMSURBUl9BTFZBUkEoYWx2YXJhLmNvZGlnb19hdXRlbnRpY2lkYWRlKX1cclxuICAgICAgICAgICAgdGFyZ2V0PVwiX2JsYW5rXCJcclxuICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtMyBweS0xLjUgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtdGVhbC03MDAgZGFyazp0ZXh0LXRlYWwtMzAwIGJnLXRlYWwtNTAgZGFyazpiZy10ZWFsLTk1MC80MCBib3JkZXIgYm9yZGVyLXRlYWwtMjAwIGRhcms6Ym9yZGVyLXRlYWwtODAwIHJvdW5kZWQtbGcgaG92ZXI6YmctdGVhbC0xMDAvNjAgc2hhZG93LTJ4cyBpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSB0cmFuc2l0aW9uLWNvbG9yc1wiXHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIDxRckNvZGUgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPlxyXG4gICAgICAgICAgICA8c3Bhbj5WYWxpZGHDp8OjbyBQw7pibGljYTwvc3Bhbj5cclxuICAgICAgICAgICAgPEV4dGVybmFsTGluayBjbGFzc05hbWU9XCJ3LTMgaC0zIG9wYWNpdHktNjBcIiAvPlxyXG4gICAgICAgICAgPC9MaW5rPlxyXG5cclxuICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZUltcHJpbWlyfVxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJweC00IHB5LTEuNSB0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXdoaXRlIGJnLXRlYWwtNjAwIGhvdmVyOmJnLXRlYWwtNzAwIHJvdW5kZWQtbGcgc2hhZG93LXhzIGlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHRyYW5zaXRpb24tY29sb3JzXCJcclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgPFByaW50ZXIgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+XHJcbiAgICAgICAgICAgIDxzcGFuPkltcHJpbWlyIEFsdmFyw6EgKEE0KTwvc3Bhbj5cclxuICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIHsvKiBWaXN1YWxpemHDp8OjbyBkZSBJbXByZXNzw6NvIE9maWNpYWwgKi99XHJcbiAgICAgIDxBbHZhcmFJbXByZXNzYW9WaWV3IGFsdmFyYT17YWx2YXJhfSAvPlxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IEFsdmFyYVZpZXdQYWdlO1xyXG4iXX0=