import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/common/ErrorBoundary.tsx");const React = __vite__cjsImport0_react; const Component = __vite__cjsImport0_react["Component"];const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport4_react_jsxDevRuntime["Fragment"];/**
* Componente Global de Error Boundary do Sistema VigiMinas
*
* Captura exceções não tratadas durante o ciclo de vida e renderização dos componentes React,
* impedindo que a aplicação trave em uma tela branca ("white screen of death") e exibindo
* uma interface amigável, institucional e acessível, com opções para:
*
* 1. Recarregar a página (hard refresh).
* 2. Tentar recuperar o estado do componente (resetErrorBoundary).
* 3. Retornar à página inicial segura (Dashboard).
* 4. Copiar diagnóstico técnico estruturado para acionamento do suporte da Vigilância Sanitária.
*/
import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=0fd2848a";
import { AlertTriangle, RotateCcw, Home, Copy, Check, ChevronDown, ChevronUp, RefreshCw, HelpCircle } from "/node_modules/.vite/deps/lucide-react.js?v=0fd2848a";
import { APP_CONFIG } from "/src/config/app.config.ts";
import { ROUTES } from "/src/config/routes.config.ts";
var _jsxFileName = "E:/Projetos VSCODE/visa_braunas/src/components/common/ErrorBoundary.tsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=0fd2848a";
export class ErrorBoundary extends Component {
	constructor(props) {
		super(props);
		this.copyTimeout = null;
		this.resetErrorBoundary = () => {
			this.props.onReset?.();
			this.setState({
				hasError: false,
				error: null,
				errorInfo: null,
				showDetails: false,
				copied: false
			});
		};
		this.reloadPage = () => {
			if (typeof window !== "undefined") {
				window.location.reload();
			}
		};
		this.goHome = () => {
			this.resetErrorBoundary();
			if (typeof window !== "undefined") {
				window.location.href = ROUTES.DASHBOARD;
			}
		};
		this.toggleDetails = () => {
			this.setState((prev) => ({ showDetails: !prev.showDetails }));
		};
		this.copyErrorDiagnostics = async () => {
			const { error, errorInfo } = this.state;
			const diagnosticReport = [
				`=== RELATÓRIO DE ERRO - ${APP_CONFIG.nome} v${APP_CONFIG.versao} ===`,
				`Município: ${APP_CONFIG.municipio}/${APP_CONFIG.uf}`,
				`Órgão: ${APP_CONFIG.orgao} - ${APP_CONFIG.secretaria}`,
				`Data/Hora: ${new Date().toISOString()}`,
				`URL Atual: ${typeof window !== "undefined" ? window.location.href : "N/A"}`,
				`User Agent: ${typeof navigator !== "undefined" ? navigator.userAgent : "N/A"}`,
				`Mensagem: ${error?.name}: ${error?.message}`,
				"",
				"--- STACK TRACE ---",
				error?.stack || "Stack trace indisponível",
				"",
				"--- COMPONENT STACK ---",
				errorInfo?.componentStack || "Component stack indisponível",
				"================================================"
			].join("\n");
			try {
				if (typeof navigator !== "undefined" && navigator.clipboard) {
					await navigator.clipboard.writeText(diagnosticReport);
					this.setState({ copied: true });
					if (this.copyTimeout) clearTimeout(this.copyTimeout);
					this.copyTimeout = setTimeout(() => {
						this.setState({ copied: false });
					}, 3e3);
				}
			} catch (err) {
				console.error("[VigiMinas ErrorBoundary] Falha ao copiar relatório:", err);
			}
		};
		this.state = {
			hasError: false,
			error: null,
			errorInfo: null,
			showDetails: false,
			copied: false
		};
	}
	static getDerivedStateFromError(error) {
		return {
			hasError: true,
			error
		};
	}
	componentDidCatch(error, errorInfo) {
		this.setState({ errorInfo });
		// Registra o erro no console para depuração em desenvolvimento
		console.error("[VigiMinas ErrorBoundary] Exceção não tratada capturada:", {
			error,
			componentStack: errorInfo.componentStack
		});
		if (this.props.onError) {
			try {
				this.props.onError(error, errorInfo);
			} catch (callbackError) {
				console.error("[VigiMinas ErrorBoundary] Erro no callback onError:", callbackError);
			}
		}
	}
	componentWillUnmount() {
		if (this.copyTimeout) {
			clearTimeout(this.copyTimeout);
		}
	}
	render() {
		const { hasError, error, errorInfo, showDetails, copied } = this.state;
		const { children, fallback } = this.props;
		if (!hasError) {
			return children;
		}
		// Se o usuário passou um fallback customizado
		if (fallback) {
			if (typeof fallback === "function") {
				return fallback({
					error: error || new Error("Erro desconhecido"),
					errorInfo,
					resetErrorBoundary: this.resetErrorBoundary,
					reloadPage: this.reloadPage,
					goHome: this.goHome
				});
			}
			return fallback;
		}
		// Interface Institucional Padrão do Error Boundary
		return /* @__PURE__ */ _jsxDEV("div", {
			role: "alert",
			"aria-live": "assertive",
			className: "min-h-screen w-full bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col justify-between p-4 sm:p-6 lg:p-8 antialiased",
			children: [
				/* @__PURE__ */ _jsxDEV("header", {
					className: "max-w-4xl w-full mx-auto flex items-center justify-between pb-6 border-b border-slate-200 dark:border-slate-800",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-2.5",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "w-8 h-8 rounded-lg bg-teal-600 text-white flex items-center justify-center font-bold shadow-xs",
							children: /* @__PURE__ */ _jsxDEV("span", {
								className: "text-sm font-black",
								children: "VM"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 208,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 207,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h1", {
							className: "text-sm font-bold tracking-tight",
							children: APP_CONFIG.nome
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 211,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("p", {
							className: "text-[11px] text-slate-500 dark:text-slate-400",
							children: [
								APP_CONFIG.municipio,
								" / ",
								APP_CONFIG.uf,
								" · ",
								APP_CONFIG.orgao
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 214,
							columnNumber: 15
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 210,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 206,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("span", {
						className: "text-xs font-mono text-slate-500 dark:text-slate-400",
						children: ["v", APP_CONFIG.versao]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 219,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 205,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("main", {
					className: "max-w-2xl w-full mx-auto my-auto py-8",
					children: /* @__PURE__ */ _jsxDEV("div", {
						className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 sm:p-8 shadow-xl",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-start gap-4",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "p-3 rounded-xl bg-rose-50 dark:bg-rose-950/40 text-rose-600 dark:text-rose-400 border border-rose-200 dark:border-rose-900/60 shrink-0",
									children: /* @__PURE__ */ _jsxDEV(AlertTriangle, { className: "w-7 h-7" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 229,
										columnNumber: 17
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 228,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "flex-1 min-w-0",
									children: [/* @__PURE__ */ _jsxDEV("h2", {
										className: "text-lg sm:text-xl font-bold text-slate-900 dark:text-white leading-snug",
										children: "Ocorreu uma falha inesperada na aplicação"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 232,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("p", {
										className: "mt-1.5 text-xs sm:text-sm text-slate-600 dark:text-slate-300 leading-relaxed",
										children: "A interface encontrou uma inconsistência durante a renderização. Para sua segurança, a execução foi interrompida antes de comprometer dados operacionais."
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 235,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 231,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 227,
								columnNumber: 13
							}, this),
							error && /* @__PURE__ */ _jsxDEV("div", {
								className: "mt-5 p-3.5 rounded-lg bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/60 text-xs text-rose-700 dark:text-rose-300 font-mono break-words",
								children: [
									/* @__PURE__ */ _jsxDEV("span", {
										className: "font-semibold",
										children: [error.name, ":"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 245,
										columnNumber: 17
									}, this),
									" ",
									error.message
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 244,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "mt-6 flex flex-wrap items-center gap-3",
								children: [
									/* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										onClick: this.reloadPage,
										className: "inline-flex items-center justify-center gap-2 px-4 py-2 text-xs font-medium text-white bg-teal-600 hover:bg-teal-700 active:bg-teal-800 rounded-lg shadow-xs transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-teal-600 focus-visible:ring-offset-2",
										children: [/* @__PURE__ */ _jsxDEV(RotateCcw, { className: "w-3.5 h-3.5" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 256,
											columnNumber: 17
										}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Recarregar Aplicação" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 257,
											columnNumber: 17
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 251,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										onClick: this.resetErrorBoundary,
										className: "inline-flex items-center justify-center gap-2 px-4 py-2 text-xs font-medium text-slate-700 dark:text-slate-200 hover:text-slate-900 dark:hover:text-white bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-lg transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-slate-400",
										children: [/* @__PURE__ */ _jsxDEV(RefreshCw, { className: "w-3.5 h-3.5" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 265,
											columnNumber: 17
										}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Tentar Novamente" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 266,
											columnNumber: 17
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 260,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										onClick: this.goHome,
										className: "inline-flex items-center justify-center gap-2 px-4 py-2 text-xs font-medium text-slate-700 dark:text-slate-200 hover:text-slate-900 dark:hover:text-white bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-lg transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-slate-400",
										children: [/* @__PURE__ */ _jsxDEV(Home, { className: "w-3.5 h-3.5" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 274,
											columnNumber: 17
										}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Ir para Página Inicial" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 275,
											columnNumber: 17
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 269,
										columnNumber: 15
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 250,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "mt-6 pt-5 border-t border-slate-200 dark:border-slate-800",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center justify-between",
									children: [/* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										onClick: this.toggleDetails,
										className: "inline-flex items-center gap-1.5 text-xs font-medium text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 transition-colors",
										children: [showDetails ? /* @__PURE__ */ _jsxDEV(ChevronUp, { className: "w-4 h-4" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 288,
											columnNumber: 21
										}, this) : /* @__PURE__ */ _jsxDEV(ChevronDown, { className: "w-4 h-4" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 290,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("span", { children: showDetails ? "Ocultar detalhes técnicos" : "Ver detalhes técnicos (Suporte de TI)" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 292,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 282,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										onClick: this.copyErrorDiagnostics,
										className: "inline-flex items-center gap-1 px-2.5 py-1 text-[11px] font-medium text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white bg-slate-100 dark:bg-slate-800 rounded-md transition-colors",
										title: "Copiar relatório para atendimento do suporte",
										children: copied ? /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV(Check, { className: "w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 307,
											columnNumber: 23
										}, this), /* @__PURE__ */ _jsxDEV("span", {
											className: "text-emerald-600 dark:text-emerald-400",
											children: "Copiado!"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 308,
											columnNumber: 23
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 306,
											columnNumber: 21
										}, this) : /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV(Copy, { className: "w-3.5 h-3.5" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 314,
											columnNumber: 23
										}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Copiar Diagnóstico" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 315,
											columnNumber: 23
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 313,
											columnNumber: 21
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 299,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 281,
									columnNumber: 15
								}, this), showDetails && /* @__PURE__ */ _jsxDEV("div", {
									className: "mt-3.5 space-y-3",
									children: [
										/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
											className: "text-[11px] font-semibold text-slate-500 uppercase tracking-wider",
											children: "Pilha de Chamadas (Stack Trace):"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 324,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("pre", {
											className: "mt-1 p-3 rounded-lg bg-slate-950 text-slate-200 text-[11px] font-mono leading-relaxed overflow-x-auto max-h-48 border border-slate-800",
											children: error?.stack || "Nenhum stack trace capturado."
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 327,
											columnNumber: 21
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 323,
											columnNumber: 19
										}, this),
										errorInfo?.componentStack && /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
											className: "text-[11px] font-semibold text-slate-500 uppercase tracking-wider",
											children: "Árvore de Componentes (Component Stack):"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 334,
											columnNumber: 23
										}, this), /* @__PURE__ */ _jsxDEV("pre", {
											className: "mt-1 p-3 rounded-lg bg-slate-950 text-slate-200 text-[11px] font-mono leading-relaxed overflow-x-auto max-h-36 border border-slate-800",
											children: errorInfo.componentStack
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 337,
											columnNumber: 23
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 333,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "p-3 rounded-lg bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-900/40 text-[11px] text-blue-800 dark:text-blue-300 flex items-start gap-2",
											children: [/* @__PURE__ */ _jsxDEV(HelpCircle, { className: "w-4 h-4 shrink-0 mt-0.5 text-blue-600 dark:text-blue-400" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 344,
												columnNumber: 21
											}, this), /* @__PURE__ */ _jsxDEV("span", { children: [
												"Caso a falha persista após recarregar, encaminhe o diagnóstico copiado para o suporte da Vigilância Sanitária pelo e-mail",
												" ",
												/* @__PURE__ */ _jsxDEV("strong", { children: APP_CONFIG.endereco.email }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 347,
													columnNumber: 23
												}, this),
												" ou telefone",
												" ",
												/* @__PURE__ */ _jsxDEV("strong", { children: APP_CONFIG.endereco.telefone }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 348,
													columnNumber: 23
												}, this),
												"."
											] }, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 345,
												columnNumber: 21
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 343,
											columnNumber: 19
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 322,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 280,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 226,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 225,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("footer", {
					className: "max-w-4xl w-full mx-auto text-center pt-6 border-t border-slate-200 dark:border-slate-800 text-[11px] text-slate-500 dark:text-slate-400",
					children: /* @__PURE__ */ _jsxDEV("p", { children: [
						APP_CONFIG.prefeitura,
						" · ",
						APP_CONFIG.secretaria,
						" · ",
						APP_CONFIG.departamento
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 359,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 358,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 199,
			columnNumber: 7
		}, this);
	}
}
export default ErrorBoundary;
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/common/ErrorBoundary.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("E:/Projetos VSCODE/visa_braunas/src/components/common/ErrorBoundary.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("E:/Projetos VSCODE/visa_braunas/src/components/common/ErrorBoundary.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7O0FBYUEsT0FBTyxTQUFTLGlCQUE0QjtBQUM1QyxTQUNFLGVBQ0EsV0FDQSxNQUNBLE1BQ0EsT0FDQSxhQUNBLFdBQ0EsV0FDQSxrQkFDSztBQUNQLFNBQVMsa0JBQWtCO0FBQzNCLFNBQVMsY0FBYzs7O0FBb0N2QixPQUFPLE1BQU0sc0JBQXNCLFVBR2pDO0NBR0EsWUFBWSxPQUEyQjtFQUNyQyxNQUFNLEtBQUs7cUJBSGdDO2tDQStDWjtHQUMvQixLQUFLLE1BQU0sVUFBVTtHQUNyQixLQUFLLFNBQVM7SUFDWixVQUFVO0lBQ1YsT0FBTztJQUNQLFdBQVc7SUFDWCxhQUFhO0lBQ2IsUUFBUTtHQUNWLENBQUM7RUFDSDswQkFFeUI7R0FDdkIsSUFBSSxPQUFPLFdBQVcsYUFBYTtJQUNqQyxPQUFPLFNBQVMsT0FBTztHQUN6QjtFQUNGO3NCQUVxQjtHQUNuQixLQUFLLG1CQUFtQjtHQUN4QixJQUFJLE9BQU8sV0FBVyxhQUFhO0lBQ2pDLE9BQU8sU0FBUyxPQUFPLE9BQU87R0FDaEM7RUFDRjs2QkFFNEI7R0FDMUIsS0FBSyxVQUFVLFVBQVUsRUFBRSxhQUFhLENBQUMsS0FBSyxZQUFZLEVBQUU7RUFDOUQ7OEJBRXVCLFlBQTJCO0dBQ2hELE1BQU0sRUFBRSxPQUFPLGNBQWMsS0FBSztHQUNsQyxNQUFNLG1CQUFtQjtJQUN2QiwyQkFBMkIsV0FBVyxLQUFLLElBQUksV0FBVyxPQUFPO0lBQ2pFLGNBQWMsV0FBVyxVQUFVLEdBQUcsV0FBVztJQUNqRCxVQUFVLFdBQVcsTUFBTSxLQUFLLFdBQVc7SUFDM0MsY0FBYyxJQUFJLEtBQUssQ0FBQyxDQUFDLFlBQVk7SUFDckMsY0FBYyxPQUFPLFdBQVcsY0FBYyxPQUFPLFNBQVMsT0FBTztJQUNyRSxlQUFlLE9BQU8sY0FBYyxjQUFjLFVBQVUsWUFBWTtJQUN4RSxhQUFhLE9BQU8sS0FBSyxJQUFJLE9BQU87SUFDcEM7SUFDQTtJQUNBLE9BQU8sU0FBUztJQUNoQjtJQUNBO0lBQ0EsV0FBVyxrQkFBa0I7SUFDN0I7R0FDRixDQUFDLENBQUMsS0FBSyxJQUFJO0dBRVgsSUFBSTtJQUNGLElBQUksT0FBTyxjQUFjLGVBQWUsVUFBVSxXQUFXO0tBQzNELE1BQU0sVUFBVSxVQUFVLFVBQVUsZ0JBQWdCO0tBQ3BELEtBQUssU0FBUyxFQUFFLFFBQVEsS0FBSyxDQUFDO0tBQzlCLElBQUksS0FBSyxhQUFhLGFBQWEsS0FBSyxXQUFXO0tBQ25ELEtBQUssY0FBYyxpQkFBaUI7TUFDbEMsS0FBSyxTQUFTLEVBQUUsUUFBUSxNQUFNLENBQUM7S0FDakMsR0FBRyxHQUFJO0lBQ1Q7R0FDRixTQUFTLEtBQUs7SUFDWixRQUFRLE1BQU0sd0RBQXdELEdBQUc7R0FDM0U7RUFDRjtFQXRHRSxLQUFLLFFBQVE7R0FDWCxVQUFVO0dBQ1YsT0FBTztHQUNQLFdBQVc7R0FDWCxhQUFhO0dBQ2IsUUFBUTtFQUNWO0NBQ0Y7Q0FFQSxPQUFPLHlCQUF5QixPQUEyQztFQUN6RSxPQUFPO0dBQ0wsVUFBVTtHQUNWO0VBQ0Y7Q0FDRjtDQUVBLGtCQUFrQixPQUFjLFdBQTRCO0VBQzFELEtBQUssU0FBUyxFQUFFLFVBQVUsQ0FBQzs7RUFHM0IsUUFBUSxNQUFNLDREQUE0RDtHQUN4RTtHQUNBLGdCQUFnQixVQUFVO0VBQzVCLENBQUM7RUFFRCxJQUFJLEtBQUssTUFBTSxTQUFTO0dBQ3RCLElBQUk7SUFDRixLQUFLLE1BQU0sUUFBUSxPQUFPLFNBQVM7R0FDckMsU0FBUyxlQUFlO0lBQ3RCLFFBQVEsTUFDTix1REFDQSxhQUNGO0dBQ0Y7RUFDRjtDQUNGO0NBRUEsdUJBQTZCO0VBQzNCLElBQUksS0FBSyxhQUFhO0dBQ3BCLGFBQWEsS0FBSyxXQUFXO0VBQy9CO0NBQ0Y7Q0ErREEsU0FBMEI7RUFDeEIsTUFBTSxFQUFFLFVBQVUsT0FBTyxXQUFXLGFBQWEsV0FBVyxLQUFLO0VBQ2pFLE1BQU0sRUFBRSxVQUFVLGFBQWEsS0FBSztFQUVwQyxJQUFJLENBQUMsVUFBVTtHQUNiLE9BQU87RUFDVDs7RUFHQSxJQUFJLFVBQVU7R0FDWixJQUFJLE9BQU8sYUFBYSxZQUFZO0lBQ2xDLE9BQU8sU0FBUztLQUNkLE9BQU8sU0FBUyxJQUFJLE1BQU0sbUJBQW1CO0tBQzdDO0tBQ0Esb0JBQW9CLEtBQUs7S0FDekIsWUFBWSxLQUFLO0tBQ2pCLFFBQVEsS0FBSztJQUNmLENBQUM7R0FDSDtHQUNBLE9BQU87RUFDVDs7RUFHQSxPQUNFLHdCQUFDLE9BQUQ7R0FDRSxNQUFLO0dBQ0wsYUFBVTtHQUNWLFdBQVU7YUFIWjtJQU1FLHdCQUFDLFVBQUQ7S0FBUSxXQUFVO2VBQWxCLENBQ0Usd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFDYix3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBcUI7T0FBUTs7Ozs7TUFDMUM7Ozs7Z0JBQ0wsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE1BQUQ7T0FBSSxXQUFVO2lCQUNYLFdBQVc7TUFDVjs7OztnQkFDSix3QkFBQyxLQUFEO09BQUcsV0FBVTtpQkFBYjtRQUNHLFdBQVc7UUFBVTtRQUFJLFdBQVc7UUFBRztRQUFJLFdBQVc7T0FDdEQ7Ozs7O2NBQ0E7Ozs7Y0FDRjs7Ozs7ZUFDTCx3QkFBQyxRQUFEO01BQU0sV0FBVTtnQkFBaEIsQ0FBdUUsS0FDbkUsV0FBVyxNQUNUOzs7OzthQUNBOzs7Ozs7SUFHUix3QkFBQyxRQUFEO0tBQU0sV0FBVTtlQUNkLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmO09BQ0Usd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFDYix3QkFBQyxlQUFELEVBQWUsV0FBVSxVQUFXOzs7OztRQUNqQzs7OztrQkFDTCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLE1BQUQ7VUFBSSxXQUFVO29CQUEyRTtTQUVyRjs7OzttQkFDSix3QkFBQyxLQUFEO1VBQUcsV0FBVTtvQkFBK0U7U0FHekY7Ozs7aUJBQ0E7Ozs7O2dCQUNGOzs7Ozs7T0FHSixTQUNDLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmO1NBQ0Usd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQWhCLENBQWlDLE1BQU0sTUFBSyxHQUFPOzs7Ozs7U0FBQztTQUFFLE1BQU07UUFDekQ7Ozs7OztPQUlQLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmO1NBQ0Usd0JBQUMsVUFBRDtVQUNFLE1BQUs7VUFDTCxTQUFTLEtBQUs7VUFDZCxXQUFVO29CQUhaLENBS0Usd0JBQUMsV0FBRCxFQUFXLFdBQVUsY0FBZTs7OztvQkFDcEMsd0JBQUMsUUFBRCxZQUFNLHVCQUEwQjs7OztrQkFDMUI7Ozs7OztTQUVSLHdCQUFDLFVBQUQ7VUFDRSxNQUFLO1VBQ0wsU0FBUyxLQUFLO1VBQ2QsV0FBVTtvQkFIWixDQUtFLHdCQUFDLFdBQUQsRUFBVyxXQUFVLGNBQWU7Ozs7b0JBQ3BDLHdCQUFDLFFBQUQsWUFBTSxtQkFBc0I7Ozs7a0JBQ3RCOzs7Ozs7U0FFUix3QkFBQyxVQUFEO1VBQ0UsTUFBSztVQUNMLFNBQVMsS0FBSztVQUNkLFdBQVU7b0JBSFosQ0FLRSx3QkFBQyxNQUFELEVBQU0sV0FBVSxjQUFlOzs7O29CQUMvQix3QkFBQyxRQUFELFlBQU0seUJBQTRCOzs7O2tCQUM1Qjs7Ozs7O1FBQ0w7Ozs7OztPQUdMLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDRSx3QkFBQyxVQUFEO1VBQ0UsTUFBSztVQUNMLFNBQVMsS0FBSztVQUNkLFdBQVU7b0JBSFosQ0FLRyxjQUNDLHdCQUFDLFdBQUQsRUFBVyxXQUFVLFVBQVc7Ozs7cUJBRWhDLHdCQUFDLGFBQUQsRUFBYSxXQUFVLFVBQVc7Ozs7b0JBRXBDLHdCQUFDLFFBQUQsWUFDRyxjQUNHLDhCQUNBLHdDQUNBOzs7O2tCQUNBOzs7OzttQkFFUix3QkFBQyxVQUFEO1VBQ0UsTUFBSztVQUNMLFNBQVMsS0FBSztVQUNkLFdBQVU7VUFDVixPQUFNO29CQUVMLFNBQ0MsZ0RBQ0Usd0JBQUMsT0FBRCxFQUFPLFdBQVUscURBQXNEOzs7O29CQUN2RSx3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFBeUM7VUFFbkQ7Ozs7a0JBQ047Ozs7cUJBRUYsZ0RBQ0Usd0JBQUMsTUFBRCxFQUFNLFdBQVUsY0FBZTs7OztvQkFDL0Isd0JBQUMsUUFBRCxZQUFNLHFCQUF3Qjs7OztrQkFDOUI7Ozs7O1NBRUU7Ozs7aUJBQ0w7Ozs7O2tCQUVKLGVBQ0Msd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWY7VUFDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQW9FO1VBRTlFOzs7O29CQUNOLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUNaLE9BQU8sU0FBUztVQUNkOzs7O2tCQUNGOzs7OztVQUVKLFdBQVcsa0JBQ1Ysd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFFBQUQ7V0FBTSxXQUFVO3FCQUFvRTtVQUU5RTs7OztvQkFDTix3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFDWixVQUFVO1VBQ1I7Ozs7a0JBQ0Y7Ozs7O1VBR1Asd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWYsQ0FDRSx3QkFBQyxZQUFELEVBQVksV0FBVSwyREFBNEQ7Ozs7cUJBQ2xGLHdCQUFDLFFBQUQ7WUFBTTtZQUNzSDtZQUMxSCx3QkFBQyxVQUFELFlBQVMsV0FBVyxTQUFTLE1BQWM7Ozs7O1lBQUM7WUFBYTtZQUN6RCx3QkFBQyxVQUFELFlBQVMsV0FBVyxTQUFTLFNBQWlCOzs7OztZQUFDO1dBQzNDOzs7O21CQUNIOzs7Ozs7U0FDRjs7Ozs7Z0JBRUo7Ozs7OztNQUNGOzs7Ozs7SUFDRDs7Ozs7SUFHTix3QkFBQyxVQUFEO0tBQVEsV0FBVTtlQUNoQix3QkFBQyxLQUFEO01BQ0csV0FBVztNQUFXO01BQUksV0FBVztNQUFXO01BQUksV0FBVztLQUMvRDs7Ozs7SUFDRzs7Ozs7R0FDTDs7Ozs7O0NBRVQ7QUFDRjtBQUVBLGVBQWUiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiRXJyb3JCb3VuZGFyeS50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiLyoqXHJcbiAqIENvbXBvbmVudGUgR2xvYmFsIGRlIEVycm9yIEJvdW5kYXJ5IGRvIFNpc3RlbWEgVmlnaU1pbmFzXHJcbiAqXHJcbiAqIENhcHR1cmEgZXhjZcOnw7VlcyBuw6NvIHRyYXRhZGFzIGR1cmFudGUgbyBjaWNsbyBkZSB2aWRhIGUgcmVuZGVyaXphw6fDo28gZG9zIGNvbXBvbmVudGVzIFJlYWN0LFxyXG4gKiBpbXBlZGluZG8gcXVlIGEgYXBsaWNhw6fDo28gdHJhdmUgZW0gdW1hIHRlbGEgYnJhbmNhIChcIndoaXRlIHNjcmVlbiBvZiBkZWF0aFwiKSBlIGV4aWJpbmRvXHJcbiAqIHVtYSBpbnRlcmZhY2UgYW1pZ8OhdmVsLCBpbnN0aXR1Y2lvbmFsIGUgYWNlc3PDrXZlbCwgY29tIG9ww6fDtWVzIHBhcmE6XHJcbiAqXHJcbiAqIDEuIFJlY2FycmVnYXIgYSBww6FnaW5hIChoYXJkIHJlZnJlc2gpLlxyXG4gKiAyLiBUZW50YXIgcmVjdXBlcmFyIG8gZXN0YWRvIGRvIGNvbXBvbmVudGUgKHJlc2V0RXJyb3JCb3VuZGFyeSkuXHJcbiAqIDMuIFJldG9ybmFyIMOgIHDDoWdpbmEgaW5pY2lhbCBzZWd1cmEgKERhc2hib2FyZCkuXHJcbiAqIDQuIENvcGlhciBkaWFnbsOzc3RpY28gdMOpY25pY28gZXN0cnV0dXJhZG8gcGFyYSBhY2lvbmFtZW50byBkbyBzdXBvcnRlIGRhIFZpZ2lsw6JuY2lhIFNhbml0w6FyaWEuXHJcbiAqL1xyXG5cclxuaW1wb3J0IFJlYWN0LCB7IENvbXBvbmVudCwgRXJyb3JJbmZvIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7XHJcbiAgQWxlcnRUcmlhbmdsZSxcclxuICBSb3RhdGVDY3csXHJcbiAgSG9tZSxcclxuICBDb3B5LFxyXG4gIENoZWNrLFxyXG4gIENoZXZyb25Eb3duLFxyXG4gIENoZXZyb25VcCxcclxuICBSZWZyZXNoQ3csXHJcbiAgSGVscENpcmNsZSxcclxufSBmcm9tIFwibHVjaWRlLXJlYWN0XCI7XHJcbmltcG9ydCB7IEFQUF9DT05GSUcgfSBmcm9tIFwiLi4vLi4vY29uZmlnL2FwcC5jb25maWdcIjtcclxuaW1wb3J0IHsgUk9VVEVTIH0gZnJvbSBcIi4uLy4uL2NvbmZpZy9yb3V0ZXMuY29uZmlnXCI7XHJcblxyXG5leHBvcnQgaW50ZXJmYWNlIEVycm9yQm91bmRhcnlGYWxsYmFja1Byb3BzIHtcclxuICBlcnJvcjogRXJyb3I7XHJcbiAgZXJyb3JJbmZvOiBFcnJvckluZm8gfCBudWxsO1xyXG4gIHJlc2V0RXJyb3JCb3VuZGFyeTogKCkgPT4gdm9pZDtcclxuICByZWxvYWRQYWdlOiAoKSA9PiB2b2lkO1xyXG4gIGdvSG9tZTogKCkgPT4gdm9pZDtcclxufVxyXG5cclxuZXhwb3J0IGludGVyZmFjZSBFcnJvckJvdW5kYXJ5UHJvcHMge1xyXG4gIGNoaWxkcmVuOiBSZWFjdC5SZWFjdE5vZGU7XHJcbiAgLyoqXHJcbiAgICogQ29tcG9uZW50ZSBvdSBmdW7Dp8OjbyBkZSByZW5kZXIgY3VzdG9taXphZGEgcGFyYSBhIHRlbGEgZGUgZXJyb1xyXG4gICAqL1xyXG4gIGZhbGxiYWNrPzpcclxuICAgIHwgUmVhY3QuUmVhY3ROb2RlXHJcbiAgICB8ICgocHJvcHM6IEVycm9yQm91bmRhcnlGYWxsYmFja1Byb3BzKSA9PiBSZWFjdC5SZWFjdE5vZGUpO1xyXG4gIC8qKlxyXG4gICAqIENhbGxiYWNrIGludm9jYWRvIHF1YW5kbyB1bSBlcnJvIGZvciBpbnRlcmNlcHRhZG9cclxuICAgKi9cclxuICBvbkVycm9yPzogKGVycm9yOiBFcnJvciwgZXJyb3JJbmZvOiBFcnJvckluZm8pID0+IHZvaWQ7XHJcbiAgLyoqXHJcbiAgICogQ2FsbGJhY2sgaW52b2NhZG8gcXVhbmRvIG8gdXN1w6FyaW8gc29saWNpdGFyIHJlc2V0IGRhIMOhcnZvcmUgZGUgY29tcG9uZW50ZXNcclxuICAgKi9cclxuICBvblJlc2V0PzogKCkgPT4gdm9pZDtcclxufVxyXG5cclxuaW50ZXJmYWNlIEVycm9yQm91bmRhcnlTdGF0ZSB7XHJcbiAgaGFzRXJyb3I6IGJvb2xlYW47XHJcbiAgZXJyb3I6IEVycm9yIHwgbnVsbDtcclxuICBlcnJvckluZm86IEVycm9ySW5mbyB8IG51bGw7XHJcbiAgc2hvd0RldGFpbHM6IGJvb2xlYW47XHJcbiAgY29waWVkOiBib29sZWFuO1xyXG59XHJcblxyXG5leHBvcnQgY2xhc3MgRXJyb3JCb3VuZGFyeSBleHRlbmRzIENvbXBvbmVudDxcclxuICBFcnJvckJvdW5kYXJ5UHJvcHMsXHJcbiAgRXJyb3JCb3VuZGFyeVN0YXRlXHJcbj4ge1xyXG4gIHByaXZhdGUgY29weVRpbWVvdXQ6IE5vZGVKUy5UaW1lb3V0IHwgbnVsbCA9IG51bGw7XHJcblxyXG4gIGNvbnN0cnVjdG9yKHByb3BzOiBFcnJvckJvdW5kYXJ5UHJvcHMpIHtcclxuICAgIHN1cGVyKHByb3BzKTtcclxuICAgIHRoaXMuc3RhdGUgPSB7XHJcbiAgICAgIGhhc0Vycm9yOiBmYWxzZSxcclxuICAgICAgZXJyb3I6IG51bGwsXHJcbiAgICAgIGVycm9ySW5mbzogbnVsbCxcclxuICAgICAgc2hvd0RldGFpbHM6IGZhbHNlLFxyXG4gICAgICBjb3BpZWQ6IGZhbHNlLFxyXG4gICAgfTtcclxuICB9XHJcblxyXG4gIHN0YXRpYyBnZXREZXJpdmVkU3RhdGVGcm9tRXJyb3IoZXJyb3I6IEVycm9yKTogUGFydGlhbDxFcnJvckJvdW5kYXJ5U3RhdGU+IHtcclxuICAgIHJldHVybiB7XHJcbiAgICAgIGhhc0Vycm9yOiB0cnVlLFxyXG4gICAgICBlcnJvcixcclxuICAgIH07XHJcbiAgfVxyXG5cclxuICBjb21wb25lbnREaWRDYXRjaChlcnJvcjogRXJyb3IsIGVycm9ySW5mbzogRXJyb3JJbmZvKTogdm9pZCB7XHJcbiAgICB0aGlzLnNldFN0YXRlKHsgZXJyb3JJbmZvIH0pO1xyXG5cclxuICAgIC8vIFJlZ2lzdHJhIG8gZXJybyBubyBjb25zb2xlIHBhcmEgZGVwdXJhw6fDo28gZW0gZGVzZW52b2x2aW1lbnRvXHJcbiAgICBjb25zb2xlLmVycm9yKFwiW1ZpZ2lNaW5hcyBFcnJvckJvdW5kYXJ5XSBFeGNlw6fDo28gbsOjbyB0cmF0YWRhIGNhcHR1cmFkYTpcIiwge1xyXG4gICAgICBlcnJvcixcclxuICAgICAgY29tcG9uZW50U3RhY2s6IGVycm9ySW5mby5jb21wb25lbnRTdGFjayxcclxuICAgIH0pO1xyXG5cclxuICAgIGlmICh0aGlzLnByb3BzLm9uRXJyb3IpIHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICB0aGlzLnByb3BzLm9uRXJyb3IoZXJyb3IsIGVycm9ySW5mbyk7XHJcbiAgICAgIH0gY2F0Y2ggKGNhbGxiYWNrRXJyb3IpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFxyXG4gICAgICAgICAgXCJbVmlnaU1pbmFzIEVycm9yQm91bmRhcnldIEVycm8gbm8gY2FsbGJhY2sgb25FcnJvcjpcIixcclxuICAgICAgICAgIGNhbGxiYWNrRXJyb3JcclxuICAgICAgICApO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBjb21wb25lbnRXaWxsVW5tb3VudCgpOiB2b2lkIHtcclxuICAgIGlmICh0aGlzLmNvcHlUaW1lb3V0KSB7XHJcbiAgICAgIGNsZWFyVGltZW91dCh0aGlzLmNvcHlUaW1lb3V0KTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIHJlc2V0RXJyb3JCb3VuZGFyeSA9ICgpOiB2b2lkID0+IHtcclxuICAgIHRoaXMucHJvcHMub25SZXNldD8uKCk7XHJcbiAgICB0aGlzLnNldFN0YXRlKHtcclxuICAgICAgaGFzRXJyb3I6IGZhbHNlLFxyXG4gICAgICBlcnJvcjogbnVsbCxcclxuICAgICAgZXJyb3JJbmZvOiBudWxsLFxyXG4gICAgICBzaG93RGV0YWlsczogZmFsc2UsXHJcbiAgICAgIGNvcGllZDogZmFsc2UsXHJcbiAgICB9KTtcclxuICB9O1xyXG5cclxuICByZWxvYWRQYWdlID0gKCk6IHZvaWQgPT4ge1xyXG4gICAgaWYgKHR5cGVvZiB3aW5kb3cgIT09IFwidW5kZWZpbmVkXCIpIHtcclxuICAgICAgd2luZG93LmxvY2F0aW9uLnJlbG9hZCgpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGdvSG9tZSA9ICgpOiB2b2lkID0+IHtcclxuICAgIHRoaXMucmVzZXRFcnJvckJvdW5kYXJ5KCk7XHJcbiAgICBpZiAodHlwZW9mIHdpbmRvdyAhPT0gXCJ1bmRlZmluZWRcIikge1xyXG4gICAgICB3aW5kb3cubG9jYXRpb24uaHJlZiA9IFJPVVRFUy5EQVNIQk9BUkQ7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgdG9nZ2xlRGV0YWlscyA9ICgpOiB2b2lkID0+IHtcclxuICAgIHRoaXMuc2V0U3RhdGUoKHByZXYpID0+ICh7IHNob3dEZXRhaWxzOiAhcHJldi5zaG93RGV0YWlscyB9KSk7XHJcbiAgfTtcclxuXHJcbiAgY29weUVycm9yRGlhZ25vc3RpY3MgPSBhc3luYyAoKTogUHJvbWlzZTx2b2lkPiA9PiB7XHJcbiAgICBjb25zdCB7IGVycm9yLCBlcnJvckluZm8gfSA9IHRoaXMuc3RhdGU7XHJcbiAgICBjb25zdCBkaWFnbm9zdGljUmVwb3J0ID0gW1xyXG4gICAgICBgPT09IFJFTEFUw5NSSU8gREUgRVJSTyAtICR7QVBQX0NPTkZJRy5ub21lfSB2JHtBUFBfQ09ORklHLnZlcnNhb30gPT09YCxcclxuICAgICAgYE11bmljw61waW86ICR7QVBQX0NPTkZJRy5tdW5pY2lwaW99LyR7QVBQX0NPTkZJRy51Zn1gLFxyXG4gICAgICBgw5NyZ8OjbzogJHtBUFBfQ09ORklHLm9yZ2FvfSAtICR7QVBQX0NPTkZJRy5zZWNyZXRhcmlhfWAsXHJcbiAgICAgIGBEYXRhL0hvcmE6ICR7bmV3IERhdGUoKS50b0lTT1N0cmluZygpfWAsXHJcbiAgICAgIGBVUkwgQXR1YWw6ICR7dHlwZW9mIHdpbmRvdyAhPT0gXCJ1bmRlZmluZWRcIiA/IHdpbmRvdy5sb2NhdGlvbi5ocmVmIDogXCJOL0FcIn1gLFxyXG4gICAgICBgVXNlciBBZ2VudDogJHt0eXBlb2YgbmF2aWdhdG9yICE9PSBcInVuZGVmaW5lZFwiID8gbmF2aWdhdG9yLnVzZXJBZ2VudCA6IFwiTi9BXCJ9YCxcclxuICAgICAgYE1lbnNhZ2VtOiAke2Vycm9yPy5uYW1lfTogJHtlcnJvcj8ubWVzc2FnZX1gLFxyXG4gICAgICBcIlwiLFxyXG4gICAgICBcIi0tLSBTVEFDSyBUUkFDRSAtLS1cIixcclxuICAgICAgZXJyb3I/LnN0YWNrIHx8IFwiU3RhY2sgdHJhY2UgaW5kaXNwb27DrXZlbFwiLFxyXG4gICAgICBcIlwiLFxyXG4gICAgICBcIi0tLSBDT01QT05FTlQgU1RBQ0sgLS0tXCIsXHJcbiAgICAgIGVycm9ySW5mbz8uY29tcG9uZW50U3RhY2sgfHwgXCJDb21wb25lbnQgc3RhY2sgaW5kaXNwb27DrXZlbFwiLFxyXG4gICAgICBcIj09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVwiLFxyXG4gICAgXS5qb2luKFwiXFxuXCIpO1xyXG5cclxuICAgIHRyeSB7XHJcbiAgICAgIGlmICh0eXBlb2YgbmF2aWdhdG9yICE9PSBcInVuZGVmaW5lZFwiICYmIG5hdmlnYXRvci5jbGlwYm9hcmQpIHtcclxuICAgICAgICBhd2FpdCBuYXZpZ2F0b3IuY2xpcGJvYXJkLndyaXRlVGV4dChkaWFnbm9zdGljUmVwb3J0KTtcclxuICAgICAgICB0aGlzLnNldFN0YXRlKHsgY29waWVkOiB0cnVlIH0pO1xyXG4gICAgICAgIGlmICh0aGlzLmNvcHlUaW1lb3V0KSBjbGVhclRpbWVvdXQodGhpcy5jb3B5VGltZW91dCk7XHJcbiAgICAgICAgdGhpcy5jb3B5VGltZW91dCA9IHNldFRpbWVvdXQoKCkgPT4ge1xyXG4gICAgICAgICAgdGhpcy5zZXRTdGF0ZSh7IGNvcGllZDogZmFsc2UgfSk7XHJcbiAgICAgICAgfSwgMzAwMCk7XHJcbiAgICAgIH1cclxuICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiW1ZpZ2lNaW5hcyBFcnJvckJvdW5kYXJ5XSBGYWxoYSBhbyBjb3BpYXIgcmVsYXTDs3JpbzpcIiwgZXJyKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICByZW5kZXIoKTogUmVhY3QuUmVhY3ROb2RlIHtcclxuICAgIGNvbnN0IHsgaGFzRXJyb3IsIGVycm9yLCBlcnJvckluZm8sIHNob3dEZXRhaWxzLCBjb3BpZWQgfSA9IHRoaXMuc3RhdGU7XHJcbiAgICBjb25zdCB7IGNoaWxkcmVuLCBmYWxsYmFjayB9ID0gdGhpcy5wcm9wcztcclxuXHJcbiAgICBpZiAoIWhhc0Vycm9yKSB7XHJcbiAgICAgIHJldHVybiBjaGlsZHJlbjtcclxuICAgIH1cclxuXHJcbiAgICAvLyBTZSBvIHVzdcOhcmlvIHBhc3NvdSB1bSBmYWxsYmFjayBjdXN0b21pemFkb1xyXG4gICAgaWYgKGZhbGxiYWNrKSB7XHJcbiAgICAgIGlmICh0eXBlb2YgZmFsbGJhY2sgPT09IFwiZnVuY3Rpb25cIikge1xyXG4gICAgICAgIHJldHVybiBmYWxsYmFjayh7XHJcbiAgICAgICAgICBlcnJvcjogZXJyb3IgfHwgbmV3IEVycm9yKFwiRXJybyBkZXNjb25oZWNpZG9cIiksXHJcbiAgICAgICAgICBlcnJvckluZm8sXHJcbiAgICAgICAgICByZXNldEVycm9yQm91bmRhcnk6IHRoaXMucmVzZXRFcnJvckJvdW5kYXJ5LFxyXG4gICAgICAgICAgcmVsb2FkUGFnZTogdGhpcy5yZWxvYWRQYWdlLFxyXG4gICAgICAgICAgZ29Ib21lOiB0aGlzLmdvSG9tZSxcclxuICAgICAgICB9KTtcclxuICAgICAgfVxyXG4gICAgICByZXR1cm4gZmFsbGJhY2s7XHJcbiAgICB9XHJcblxyXG4gICAgLy8gSW50ZXJmYWNlIEluc3RpdHVjaW9uYWwgUGFkcsOjbyBkbyBFcnJvciBCb3VuZGFyeVxyXG4gICAgcmV0dXJuIChcclxuICAgICAgPGRpdlxyXG4gICAgICAgIHJvbGU9XCJhbGVydFwiXHJcbiAgICAgICAgYXJpYS1saXZlPVwiYXNzZXJ0aXZlXCJcclxuICAgICAgICBjbGFzc05hbWU9XCJtaW4taC1zY3JlZW4gdy1mdWxsIGJnLXNsYXRlLTUwIGRhcms6Ymctc2xhdGUtOTUwIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC1zbGF0ZS0xMDAgZmxleCBmbGV4LWNvbCBqdXN0aWZ5LWJldHdlZW4gcC00IHNtOnAtNiBsZzpwLTggYW50aWFsaWFzZWRcIlxyXG4gICAgICA+XHJcbiAgICAgICAgey8qIENhYmXDp2FsaG8gSW5zdGl0dWNpb25hbCBTdXBlcmlvciAqL31cclxuICAgICAgICA8aGVhZGVyIGNsYXNzTmFtZT1cIm1heC13LTR4bCB3LWZ1bGwgbXgtYXV0byBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gcGItNiBib3JkZXItYiBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMFwiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMi41XCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy04IGgtOCByb3VuZGVkLWxnIGJnLXRlYWwtNjAwIHRleHQtd2hpdGUgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZm9udC1ib2xkIHNoYWRvdy14c1wiPlxyXG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1ibGFja1wiPlZNPC9zcGFuPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LWJvbGQgdHJhY2tpbmctdGlnaHRcIj5cclxuICAgICAgICAgICAgICAgIHtBUFBfQ09ORklHLm5vbWV9XHJcbiAgICAgICAgICAgICAgPC9oMT5cclxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LXNsYXRlLTUwMCBkYXJrOnRleHQtc2xhdGUtNDAwXCI+XHJcbiAgICAgICAgICAgICAgICB7QVBQX0NPTkZJRy5tdW5pY2lwaW99IC8ge0FQUF9DT05GSUcudWZ9IMK3IHtBUFBfQ09ORklHLm9yZ2FvfVxyXG4gICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1tb25vIHRleHQtc2xhdGUtNTAwIGRhcms6dGV4dC1zbGF0ZS00MDBcIj5cclxuICAgICAgICAgICAgdntBUFBfQ09ORklHLnZlcnNhb31cclxuICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICA8L2hlYWRlcj5cclxuXHJcbiAgICAgICAgey8qIENhcmQgQ2VudHJhbCBkZSBBbGVydGEgZGUgRXJybyAqL31cclxuICAgICAgICA8bWFpbiBjbGFzc05hbWU9XCJtYXgtdy0yeGwgdy1mdWxsIG14LWF1dG8gbXktYXV0byBweS04XCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIGRhcms6Ymctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLTJ4bCBwLTYgc206cC04IHNoYWRvdy14bFwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtc3RhcnQgZ2FwLTRcIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMyByb3VuZGVkLXhsIGJnLXJvc2UtNTAgZGFyazpiZy1yb3NlLTk1MC80MCB0ZXh0LXJvc2UtNjAwIGRhcms6dGV4dC1yb3NlLTQwMCBib3JkZXIgYm9yZGVyLXJvc2UtMjAwIGRhcms6Ym9yZGVyLXJvc2UtOTAwLzYwIHNocmluay0wXCI+XHJcbiAgICAgICAgICAgICAgICA8QWxlcnRUcmlhbmdsZSBjbGFzc05hbWU9XCJ3LTcgaC03XCIgLz5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMSBtaW4tdy0wXCI+XHJcbiAgICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1sZyBzbTp0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGUgbGVhZGluZy1zbnVnXCI+XHJcbiAgICAgICAgICAgICAgICAgIE9jb3JyZXUgdW1hIGZhbGhhIGluZXNwZXJhZGEgbmEgYXBsaWNhw6fDo29cclxuICAgICAgICAgICAgICAgIDwvaDI+XHJcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0xLjUgdGV4dC14cyBzbTp0ZXh0LXNtIHRleHQtc2xhdGUtNjAwIGRhcms6dGV4dC1zbGF0ZS0zMDAgbGVhZGluZy1yZWxheGVkXCI+XHJcbiAgICAgICAgICAgICAgICAgIEEgaW50ZXJmYWNlIGVuY29udHJvdSB1bWEgaW5jb25zaXN0w6puY2lhIGR1cmFudGUgYSByZW5kZXJpemHDp8Ojby5cclxuICAgICAgICAgICAgICAgICAgUGFyYSBzdWEgc2VndXJhbsOnYSwgYSBleGVjdcOnw6NvIGZvaSBpbnRlcnJvbXBpZGEgYW50ZXMgZGUgY29tcHJvbWV0ZXIgZGFkb3Mgb3BlcmFjaW9uYWlzLlxyXG4gICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIHsvKiBNZW5zYWdlbSByZXN1bWlkYSBkbyBlcnJvICovfVxyXG4gICAgICAgICAgICB7ZXJyb3IgJiYgKFxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNSBwLTMuNSByb3VuZGVkLWxnIGJnLXNsYXRlLTUwIGRhcms6Ymctc2xhdGUtODAwLzYwIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMC82MCB0ZXh0LXhzIHRleHQtcm9zZS03MDAgZGFyazp0ZXh0LXJvc2UtMzAwIGZvbnQtbW9ubyBicmVhay13b3Jkc1wiPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZFwiPntlcnJvci5uYW1lfTo8L3NwYW4+IHtlcnJvci5tZXNzYWdlfVxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgey8qIFBhaW5lbCBkZSBBw6fDtWVzIGRlIFJlY3VwZXJhw6fDo28gKi99XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNiBmbGV4IGZsZXgtd3JhcCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cclxuICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9e3RoaXMucmVsb2FkUGFnZX1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMiBweC00IHB5LTIgdGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LXdoaXRlIGJnLXRlYWwtNjAwIGhvdmVyOmJnLXRlYWwtNzAwIGFjdGl2ZTpiZy10ZWFsLTgwMCByb3VuZGVkLWxnIHNoYWRvdy14cyB0cmFuc2l0aW9uLWNvbG9ycyBmb2N1cy12aXNpYmxlOm91dGxpbmUtbm9uZSBmb2N1cy12aXNpYmxlOnJpbmctMiBmb2N1cy12aXNpYmxlOnJpbmctdGVhbC02MDAgZm9jdXMtdmlzaWJsZTpyaW5nLW9mZnNldC0yXCJcclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICA8Um90YXRlQ2N3IGNsYXNzTmFtZT1cInctMy41IGgtMy41XCIgLz5cclxuICAgICAgICAgICAgICAgIDxzcGFuPlJlY2FycmVnYXIgQXBsaWNhw6fDo288L3NwYW4+XHJcbiAgICAgICAgICAgICAgPC9idXR0b24+XHJcblxyXG4gICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgb25DbGljaz17dGhpcy5yZXNldEVycm9yQm91bmRhcnl9XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTIgcHgtNCBweS0yIHRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTIwMCBob3Zlcjp0ZXh0LXNsYXRlLTkwMCBkYXJrOmhvdmVyOnRleHQtd2hpdGUgYmctc2xhdGUtMTAwIGRhcms6Ymctc2xhdGUtODAwIGhvdmVyOmJnLXNsYXRlLTIwMCBkYXJrOmhvdmVyOmJnLXNsYXRlLTcwMCByb3VuZGVkLWxnIHRyYW5zaXRpb24tY29sb3JzIGZvY3VzLXZpc2libGU6b3V0bGluZS1ub25lIGZvY3VzLXZpc2libGU6cmluZy0yIGZvY3VzLXZpc2libGU6cmluZy1zbGF0ZS00MDBcIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIDxSZWZyZXNoQ3cgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4+VGVudGFyIE5vdmFtZW50ZTwvc3Bhbj5cclxuICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuXHJcbiAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXt0aGlzLmdvSG9tZX1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMiBweC00IHB5LTIgdGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMjAwIGhvdmVyOnRleHQtc2xhdGUtOTAwIGRhcms6aG92ZXI6dGV4dC13aGl0ZSBiZy1zbGF0ZS0xMDAgZGFyazpiZy1zbGF0ZS04MDAgaG92ZXI6Ymctc2xhdGUtMjAwIGRhcms6aG92ZXI6Ymctc2xhdGUtNzAwIHJvdW5kZWQtbGcgdHJhbnNpdGlvbi1jb2xvcnMgZm9jdXMtdmlzaWJsZTpvdXRsaW5lLW5vbmUgZm9jdXMtdmlzaWJsZTpyaW5nLTIgZm9jdXMtdmlzaWJsZTpyaW5nLXNsYXRlLTQwMFwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPEhvbWUgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4+SXIgcGFyYSBQw6FnaW5hIEluaWNpYWw8L3NwYW4+XHJcbiAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgey8qIFNlw6fDo28gQ29sYXBzw6F2ZWwgZGUgRGV0YWxoZXMgVMOpY25pY29zICovfVxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTYgcHQtNSBib3JkZXItdCBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMFwiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XHJcbiAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXt0aGlzLnRvZ2dsZURldGFpbHN9XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1zbGF0ZS02MDAgZGFyazp0ZXh0LXNsYXRlLTQwMCBob3Zlcjp0ZXh0LXNsYXRlLTkwMCBkYXJrOmhvdmVyOnRleHQtc2xhdGUtMjAwIHRyYW5zaXRpb24tY29sb3JzXCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAge3Nob3dEZXRhaWxzID8gKFxyXG4gICAgICAgICAgICAgICAgICAgIDxDaGV2cm9uVXAgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPENoZXZyb25Eb3duIGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICA8c3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICB7c2hvd0RldGFpbHNcclxuICAgICAgICAgICAgICAgICAgICAgID8gXCJPY3VsdGFyIGRldGFsaGVzIHTDqWNuaWNvc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICA6IFwiVmVyIGRldGFsaGVzIHTDqWNuaWNvcyAoU3Vwb3J0ZSBkZSBUSSlcIn1cclxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XHJcblxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgb25DbGljaz17dGhpcy5jb3B5RXJyb3JEaWFnbm9zdGljc31cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0xIHB4LTIuNSBweS0xIHRleHQtWzExcHhdIGZvbnQtbWVkaXVtIHRleHQtc2xhdGUtNjAwIGRhcms6dGV4dC1zbGF0ZS0zMDAgaG92ZXI6dGV4dC1zbGF0ZS05MDAgZGFyazpob3Zlcjp0ZXh0LXdoaXRlIGJnLXNsYXRlLTEwMCBkYXJrOmJnLXNsYXRlLTgwMCByb3VuZGVkLW1kIHRyYW5zaXRpb24tY29sb3JzXCJcclxuICAgICAgICAgICAgICAgICAgdGl0bGU9XCJDb3BpYXIgcmVsYXTDs3JpbyBwYXJhIGF0ZW5kaW1lbnRvIGRvIHN1cG9ydGVcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICB7Y29waWVkID8gKFxyXG4gICAgICAgICAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8Q2hlY2sgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjUgdGV4dC1lbWVyYWxkLTYwMCBkYXJrOnRleHQtZW1lcmFsZC00MDBcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1lbWVyYWxkLTYwMCBkYXJrOnRleHQtZW1lcmFsZC00MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgQ29waWFkbyFcclxuICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8Lz5cclxuICAgICAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgICAgICA8PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPENvcHkgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4+Q29waWFyIERpYWduw7NzdGljbzwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8Lz5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICB7c2hvd0RldGFpbHMgJiYgKFxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0zLjUgc3BhY2UteS0zXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTUwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIFBpbGhhIGRlIENoYW1hZGFzIChTdGFjayBUcmFjZSk6XHJcbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDxwcmUgY2xhc3NOYW1lPVwibXQtMSBwLTMgcm91bmRlZC1sZyBiZy1zbGF0ZS05NTAgdGV4dC1zbGF0ZS0yMDAgdGV4dC1bMTFweF0gZm9udC1tb25vIGxlYWRpbmctcmVsYXhlZCBvdmVyZmxvdy14LWF1dG8gbWF4LWgtNDggYm9yZGVyIGJvcmRlci1zbGF0ZS04MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcj8uc3RhY2sgfHwgXCJOZW5odW0gc3RhY2sgdHJhY2UgY2FwdHVyYWRvLlwifVxyXG4gICAgICAgICAgICAgICAgICAgIDwvcHJlPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgIHtlcnJvckluZm8/LmNvbXBvbmVudFN0YWNrICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTUwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgw4Fydm9yZSBkZSBDb21wb25lbnRlcyAoQ29tcG9uZW50IFN0YWNrKTpcclxuICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxwcmUgY2xhc3NOYW1lPVwibXQtMSBwLTMgcm91bmRlZC1sZyBiZy1zbGF0ZS05NTAgdGV4dC1zbGF0ZS0yMDAgdGV4dC1bMTFweF0gZm9udC1tb25vIGxlYWRpbmctcmVsYXhlZCBvdmVyZmxvdy14LWF1dG8gbWF4LWgtMzYgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ySW5mby5jb21wb25lbnRTdGFja31cclxuICAgICAgICAgICAgICAgICAgICAgIDwvcHJlPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTMgcm91bmRlZC1sZyBiZy1ibHVlLTUwIGRhcms6YmctYmx1ZS05NTAvNDAgYm9yZGVyIGJvcmRlci1ibHVlLTIwMCBkYXJrOmJvcmRlci1ibHVlLTkwMC80MCB0ZXh0LVsxMXB4XSB0ZXh0LWJsdWUtODAwIGRhcms6dGV4dC1ibHVlLTMwMCBmbGV4IGl0ZW1zLXN0YXJ0IGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPEhlbHBDaXJjbGUgY2xhc3NOYW1lPVwidy00IGgtNCBzaHJpbmstMCBtdC0wLjUgdGV4dC1ibHVlLTYwMCBkYXJrOnRleHQtYmx1ZS00MDBcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgQ2FzbyBhIGZhbGhhIHBlcnNpc3RhIGFww7NzIHJlY2FycmVnYXIsIGVuY2FtaW5oZSBvIGRpYWduw7NzdGljbyBjb3BpYWRvIHBhcmEgbyBzdXBvcnRlIGRhIFZpZ2lsw6JuY2lhIFNhbml0w6FyaWEgcGVsbyBlLW1haWx7XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3Ryb25nPntBUFBfQ09ORklHLmVuZGVyZWNvLmVtYWlsfTwvc3Ryb25nPiBvdSB0ZWxlZm9uZXtcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgICAgIDxzdHJvbmc+e0FQUF9DT05GSUcuZW5kZXJlY28udGVsZWZvbmV9PC9zdHJvbmc+LlxyXG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvbWFpbj5cclxuXHJcbiAgICAgICAgey8qIFJvZGFww6kgSW5zdGl0dWNpb25hbCBJbmZlcmlvciAqL31cclxuICAgICAgICA8Zm9vdGVyIGNsYXNzTmFtZT1cIm1heC13LTR4bCB3LWZ1bGwgbXgtYXV0byB0ZXh0LWNlbnRlciBwdC02IGJvcmRlci10IGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtODAwIHRleHQtWzExcHhdIHRleHQtc2xhdGUtNTAwIGRhcms6dGV4dC1zbGF0ZS00MDBcIj5cclxuICAgICAgICAgIDxwPlxyXG4gICAgICAgICAgICB7QVBQX0NPTkZJRy5wcmVmZWl0dXJhfSDCtyB7QVBQX0NPTkZJRy5zZWNyZXRhcmlhfSDCtyB7QVBQX0NPTkZJRy5kZXBhcnRhbWVudG99XHJcbiAgICAgICAgICA8L3A+XHJcbiAgICAgICAgPC9mb290ZXI+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgKTtcclxuICB9XHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IEVycm9yQm91bmRhcnk7XHJcbiJdfQ==