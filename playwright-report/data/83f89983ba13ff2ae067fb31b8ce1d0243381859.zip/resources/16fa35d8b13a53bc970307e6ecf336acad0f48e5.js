import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ouvidoria/ModalArquivamento.tsx");const React = __vite__cjsImport0_react;const _jsxDEV = __vite__cjsImport6_react_jsxDevRuntime["jsxDEV"];/**
* Modal de Conclusão e Arquivamento Fundamentado de Denúncias Sanitárias
* Exige justificativa formal técnica e permite redigir resposta pública ao cidadão.
*/
import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=0fd2848a";
import { useForm } from "/node_modules/.vite/deps/react-hook-form.js?v=0fd2848a";
import { zodResolver } from "/node_modules/.vite/deps/@hookform_resolvers_zod.js?v=0fd2848a";
import * as z from "/node_modules/.vite/deps/zod.js?v=0fd2848a";
import { AlertTriangle, Archive, X } from "/node_modules/.vite/deps/lucide-react.js?v=0fd2848a";
import { useConcluirDenunciaMutation } from "/src/hooks/useOuvidoria.ts";
var _jsxFileName = "E:/Projetos VSCODE/visa_braunas/src/components/ouvidoria/ModalArquivamento.tsx";
import __vite__cjsImport6_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=0fd2848a";
var _s = $RefreshSig$();
const arquivamentoSchema = z.object({
	status: z.enum([
		"arquivada",
		"improcedente",
		"procedente"
	]),
	conclusao_apuracao: z.string().min(10, "A conclusão/justificativa fundamentada deve conter no mínimo 10 caracteres"),
	resposta_ao_denunciante: z.string().optional()
});
export const ModalArquivamento = ({ isOpen, onClose, denunciaId, protocolo, onSucesso }) => {
	_s();
	const concluirMutation = useConcluirDenunciaMutation(denunciaId);
	const { register, handleSubmit, watch, formState: { errors, isSubmitting } } = useForm({
		resolver: zodResolver(arquivamentoSchema),
		defaultValues: {
			status: "arquivada",
			conclusao_apuracao: "",
			resposta_ao_denunciante: ""
		}
	});
	if (!isOpen) return null;
	const statusSelecionado = watch("status");
	const onSubmit = async (data) => {
		try {
			const payload = {
				status: data.status,
				conclusao_apuracao: data.conclusao_apuracao.trim(),
				resposta_ao_denunciante: data.resposta_ao_denunciante?.trim() || null
			};
			await concluirMutation.mutateAsync(payload);
			if (onSucesso) {
				onSucesso();
			}
			onClose();
		} catch {}
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-xs",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl w-full max-w-lg shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150 flex flex-col",
			children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "px-6 py-4 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between bg-slate-50/50 dark:bg-slate-800/40",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-2.5",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "w-9 h-9 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 flex items-center justify-center",
						children: /* @__PURE__ */ _jsxDEV(Archive, { className: "w-5 h-5" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 91,
							columnNumber: 15
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 90,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h2", {
						className: "text-sm font-bold text-slate-900 dark:text-white",
						children: "Encerramento / Arquivamento de Denúncia"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 94,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("p", {
						className: "text-[11px] text-slate-500 font-mono",
						children: ["Protocolo: ", protocolo]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 97,
						columnNumber: 15
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 93,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 89,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					onClick: onClose,
					className: "p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-300 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors",
					children: /* @__PURE__ */ _jsxDEV(X, { className: "w-5 h-5" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 107,
						columnNumber: 13
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 102,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 88,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("form", {
				onSubmit: handleSubmit(onSubmit),
				className: "p-6 space-y-4",
				children: [
					concluirMutation.isError && /* @__PURE__ */ _jsxDEV("div", {
						className: "p-3 bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 rounded-xl flex items-center gap-2 text-xs text-rose-700 dark:text-rose-300",
						children: [/* @__PURE__ */ _jsxDEV(AlertTriangle, { className: "w-4 h-4 shrink-0" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 115,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: concluirMutation.error instanceof Error ? concluirMutation.error.message : "Erro ao concluir/arquivar a denúncia." }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 116,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 114,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
						className: "block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1",
						children: ["Desfecho do Processo de Ouvidoria ", /* @__PURE__ */ _jsxDEV("span", {
							className: "text-rose-500",
							children: "*"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 127,
							columnNumber: 49
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 126,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("select", {
						...register("status"),
						className: "w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-teal-500",
						children: [
							/* @__PURE__ */ _jsxDEV("option", {
								value: "arquivada",
								children: "Arquivada (Motivos Administrativos / Prazo Decorrido)"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 133,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("option", {
								value: "improcedente",
								children: "Improcedente (Fatos Não Constatados em Vistoria)"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 134,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("option", {
								value: "procedente",
								children: "Procedente (Irregularidade Constatada e Notificada)"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 135,
								columnNumber: 15
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 129,
						columnNumber: 13
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 125,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", { children: [
						/* @__PURE__ */ _jsxDEV("label", {
							className: "block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1",
							children: ["Conclusão da Apuração / Justificativa Fundamentada ", /* @__PURE__ */ _jsxDEV("span", {
								className: "text-rose-500",
								children: "*"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 142,
								columnNumber: 66
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 141,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("textarea", {
							rows: 4,
							...register("conclusao_apuracao"),
							placeholder: "Descreva fundamentadamente os motivos fáticos e legais da conclusão da apuração...",
							className: "w-full p-2.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-teal-500"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 144,
							columnNumber: 13
						}, this),
						errors.conclusao_apuracao && /* @__PURE__ */ _jsxDEV("p", {
							className: "text-[11px] text-rose-600 mt-1",
							children: errors.conclusao_apuracao.message
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 151,
							columnNumber: 15
						}, this)
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 140,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", { children: [
						/* @__PURE__ */ _jsxDEV("label", {
							className: "block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1",
							children: "Resposta Oficial ao Cidadão (Visível na Consulta por Protocolo)"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 159,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("textarea", {
							rows: 3,
							...register("resposta_ao_denunciante"),
							placeholder: "Ex: A Vigilância Sanitária realizou inspeção no local e constatou que o estabelecimento sanou as irregularidades...",
							className: "w-full p-2.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-teal-500"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 162,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("p", {
							className: "text-[10px] text-slate-400 mt-1",
							children: "Este texto ficará disponível para leitura pelo cidadão ao consultar o protocolo da denúncia."
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 168,
							columnNumber: 13
						}, this)
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 158,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center justify-end gap-2.5 pt-3 border-t border-slate-100 dark:border-slate-800",
						children: [/* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							onClick: onClose,
							disabled: isSubmitting,
							className: "px-4 py-2 text-xs font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors",
							children: "Cancelar"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 175,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							type: "submit",
							disabled: isSubmitting,
							className: "px-5 py-2 text-xs font-bold text-white bg-slate-800 hover:bg-slate-900 dark:bg-slate-700 dark:hover:bg-slate-600 rounded-lg shadow-xs transition-colors flex items-center gap-2 disabled:opacity-60",
							children: [/* @__PURE__ */ _jsxDEV(Archive, { className: "w-4 h-4" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 188,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: isSubmitting ? "Salvando..." : "Confirmar Encerramento" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 189,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 183,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 174,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 112,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 86,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 85,
		columnNumber: 5
	}, this);
};
_s(ModalArquivamento, "MWXpHLZ/Cc/v9LCV8/xhF+bXH68=", false, function() {
	return [useConcluirDenunciaMutation, useForm];
});
_c = ModalArquivamento;
export default ModalArquivamento;
var _c;
$RefreshReg$(_c, "ModalArquivamento");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/ouvidoria/ModalArquivamento.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("E:/Projetos VSCODE/visa_braunas/src/components/ouvidoria/ModalArquivamento.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("E:/Projetos VSCODE/visa_braunas/src/components/ouvidoria/ModalArquivamento.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "E:/Projetos VSCODE/visa_braunas/src/components/ouvidoria/ModalArquivamento.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7OztBQUtBLE9BQU8sV0FBVztBQUNsQixTQUFTLGVBQWU7QUFDeEIsU0FBUyxtQkFBbUI7QUFDNUIsWUFBWSxPQUFPO0FBQ25CLFNBQ0UsZUFDQSxTQUdBLFNBRUs7QUFDUCxTQUFTLG1DQUFtQzs7OztBQUc1QyxNQUFNLHFCQUFxQixFQUFFLE9BQU87Q0FDbEMsUUFBUSxFQUFFLEtBQUs7RUFBQztFQUFhO0VBQWdCO0NBQVksQ0FBQztDQUMxRCxvQkFBb0IsRUFDakIsT0FBTyxDQUFDLENBQ1IsSUFBSSxJQUFJLDRFQUE0RTtDQUN2Rix5QkFBeUIsRUFBRSxPQUFPLENBQUMsQ0FBQyxTQUFTO0FBQy9DLENBQUM7QUFZRCxPQUFPLE1BQU0scUJBQXVELEVBQ2xFLFFBQ0EsU0FDQSxZQUNBLFdBQ0EsZ0JBQ0k7O0NBQ0osTUFBTSxtQkFBbUIsNEJBQTRCLFVBQVU7Q0FFL0QsTUFBTSxFQUNKLFVBQ0EsY0FDQSxPQUNBLFdBQVcsRUFBRSxRQUFRLG1CQUNuQixRQUE4QjtFQUNoQyxVQUFVLFlBQVksa0JBQWtCO0VBQ3hDLGVBQWU7R0FDYixRQUFRO0dBQ1Isb0JBQW9CO0dBQ3BCLHlCQUF5QjtFQUMzQjtDQUNGLENBQUM7Q0FFRCxJQUFJLENBQUMsUUFBUSxPQUFPO0NBRXBCLE1BQU0sb0JBQW9CLE1BQU0sUUFBUTtDQUV4QyxNQUFNLFdBQVcsT0FBTyxTQUErQjtFQUNyRCxJQUFJO0dBQ0YsTUFBTSxVQUErQjtJQUNuQyxRQUFRLEtBQUs7SUFDYixvQkFBb0IsS0FBSyxtQkFBbUIsS0FBSztJQUNqRCx5QkFBeUIsS0FBSyx5QkFBeUIsS0FBSyxLQUFLO0dBQ25FO0dBRUEsTUFBTSxpQkFBaUIsWUFBWSxPQUFPO0dBQzFDLElBQUksV0FBVztJQUNiLFVBQVU7R0FDWjtHQUNBLFFBQVE7RUFDVixRQUFRLENBRVI7Q0FDRjtDQUVBLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFDYix3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmLENBRUUsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFDYix3QkFBQyxTQUFELEVBQVMsV0FBVSxVQUFXOzs7OztLQUMzQjs7OztlQUNMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxNQUFEO01BQUksV0FBVTtnQkFBbUQ7S0FFN0Q7Ozs7ZUFDSix3QkFBQyxLQUFEO01BQUcsV0FBVTtnQkFBYixDQUFvRCxlQUN0QyxTQUNYOzs7OzthQUNBOzs7O2FBQ0Y7Ozs7O2NBQ0wsd0JBQUMsVUFBRDtLQUNFLE1BQUs7S0FDTCxTQUFTO0tBQ1QsV0FBVTtlQUVWLHdCQUFDLEdBQUQsRUFBRyxXQUFVLFVBQVc7Ozs7O0lBQ2xCOzs7O1lBQ0w7Ozs7O2FBR0wsd0JBQUMsUUFBRDtJQUFNLFVBQVUsYUFBYSxRQUFRO0lBQUcsV0FBVTtjQUFsRDtLQUNHLGlCQUFpQixXQUNoQix3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLGVBQUQsRUFBZSxXQUFVLG1CQUFvQjs7OztnQkFDN0Msd0JBQUMsUUFBRCxZQUNHLGlCQUFpQixpQkFBaUIsUUFDL0IsaUJBQWlCLE1BQU0sVUFDdkIsd0NBQ0E7Ozs7Y0FDSDs7Ozs7O0tBSVAsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7TUFBTyxXQUFVO2dCQUFqQixDQUF1RixzQ0FDbkQsd0JBQUMsUUFBRDtPQUFNLFdBQVU7aUJBQWdCO01BQU87Ozs7Y0FDcEU7Ozs7O2VBQ1Asd0JBQUMsVUFBRDtNQUNFLEdBQUksU0FBUyxRQUFRO01BQ3JCLFdBQVU7Z0JBRlo7T0FJRSx3QkFBQyxVQUFEO1FBQVEsT0FBTTtrQkFBWTtPQUE2RDs7Ozs7T0FDdkYsd0JBQUMsVUFBRDtRQUFRLE9BQU07a0JBQWU7T0FBd0Q7Ozs7O09BQ3JGLHdCQUFDLFVBQUQ7UUFBUSxPQUFNO2tCQUFhO09BQTJEOzs7OztNQUNoRjs7Ozs7YUFDTDs7Ozs7S0FHTCx3QkFBQyxPQUFEO01BQ0Usd0JBQUMsU0FBRDtPQUFPLFdBQVU7aUJBQWpCLENBQXVGLHVEQUNsQyx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBZ0I7T0FBTzs7OztlQUNyRjs7Ozs7O01BQ1Asd0JBQUMsWUFBRDtPQUNFLE1BQU07T0FDTixHQUFJLFNBQVMsb0JBQW9CO09BQ2pDLGFBQVk7T0FDWixXQUFVO01BQ1g7Ozs7O01BQ0EsT0FBTyxzQkFDTix3QkFBQyxLQUFEO09BQUcsV0FBVTtpQkFDVixPQUFPLG1CQUFtQjtNQUMxQjs7Ozs7S0FFRjs7Ozs7S0FHTCx3QkFBQyxPQUFEO01BQ0Usd0JBQUMsU0FBRDtPQUFPLFdBQVU7aUJBQXNFO01BRWhGOzs7OztNQUNQLHdCQUFDLFlBQUQ7T0FDRSxNQUFNO09BQ04sR0FBSSxTQUFTLHlCQUF5QjtPQUN0QyxhQUFZO09BQ1osV0FBVTtNQUNYOzs7OztNQUNELHdCQUFDLEtBQUQ7T0FBRyxXQUFVO2lCQUFrQztNQUU1Qzs7Ozs7S0FDQTs7Ozs7S0FHTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLFVBQUQ7T0FDRSxNQUFLO09BQ0wsU0FBUztPQUNULFVBQVU7T0FDVixXQUFVO2lCQUNYO01BRU87Ozs7Z0JBQ1Isd0JBQUMsVUFBRDtPQUNFLE1BQUs7T0FDTCxVQUFVO09BQ1YsV0FBVTtpQkFIWixDQUtFLHdCQUFDLFNBQUQsRUFBUyxXQUFVLFVBQVc7Ozs7aUJBQzlCLHdCQUFDLFFBQUQsWUFBTyxlQUFlLGdCQUFnQix5QkFBK0I7Ozs7ZUFDL0Q7Ozs7O2NBQ0w7Ozs7OztJQUNEOzs7OztXQUNIOzs7Ozs7Q0FDRjs7Ozs7QUFFVDs7Ozs7QUFFQSxlQUFlIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIk1vZGFsQXJxdWl2YW1lbnRvLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyIvKipcclxuICogTW9kYWwgZGUgQ29uY2x1c8OjbyBlIEFycXVpdmFtZW50byBGdW5kYW1lbnRhZG8gZGUgRGVuw7puY2lhcyBTYW5pdMOhcmlhc1xyXG4gKiBFeGlnZSBqdXN0aWZpY2F0aXZhIGZvcm1hbCB0w6ljbmljYSBlIHBlcm1pdGUgcmVkaWdpciByZXNwb3N0YSBww7pibGljYSBhbyBjaWRhZMOjby5cclxuICovXHJcblxyXG5pbXBvcnQgUmVhY3QgZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7IHVzZUZvcm0gfSBmcm9tIFwicmVhY3QtaG9vay1mb3JtXCI7XHJcbmltcG9ydCB7IHpvZFJlc29sdmVyIH0gZnJvbSBcIkBob29rZm9ybS9yZXNvbHZlcnMvem9kXCI7XHJcbmltcG9ydCAqIGFzIHogZnJvbSBcInpvZFwiO1xyXG5pbXBvcnQge1xyXG4gIEFsZXJ0VHJpYW5nbGUsXHJcbiAgQXJjaGl2ZSxcclxuICBDaGVja0NpcmNsZTIsXHJcbiAgRmlsZVRleHQsXHJcbiAgWCxcclxuICBYQ2lyY2xlLFxyXG59IGZyb20gXCJsdWNpZGUtcmVhY3RcIjtcclxuaW1wb3J0IHsgdXNlQ29uY2x1aXJEZW51bmNpYU11dGF0aW9uIH0gZnJvbSBcIi4uLy4uL2hvb2tzL3VzZU91dmlkb3JpYVwiO1xyXG5pbXBvcnQgeyBDb25jbHVpckRlbnVuY2lhRFRPLCBTdGF0dXNEZW51bmNpYSB9IGZyb20gXCIuLi8uLi90eXBlcy9vdXZpZG9yaWFcIjtcclxuXHJcbmNvbnN0IGFycXVpdmFtZW50b1NjaGVtYSA9IHoub2JqZWN0KHtcclxuICBzdGF0dXM6IHouZW51bShbXCJhcnF1aXZhZGFcIiwgXCJpbXByb2NlZGVudGVcIiwgXCJwcm9jZWRlbnRlXCJdKSxcclxuICBjb25jbHVzYW9fYXB1cmFjYW86IHpcclxuICAgIC5zdHJpbmcoKVxyXG4gICAgLm1pbigxMCwgXCJBIGNvbmNsdXPDo28vanVzdGlmaWNhdGl2YSBmdW5kYW1lbnRhZGEgZGV2ZSBjb250ZXIgbm8gbcOtbmltbyAxMCBjYXJhY3RlcmVzXCIpLFxyXG4gIHJlc3Bvc3RhX2FvX2RlbnVuY2lhbnRlOiB6LnN0cmluZygpLm9wdGlvbmFsKCksXHJcbn0pO1xyXG5cclxudHlwZSBBcnF1aXZhbWVudG9Gb3JtRGF0YSA9IHouaW5mZXI8dHlwZW9mIGFycXVpdmFtZW50b1NjaGVtYT47XHJcblxyXG5pbnRlcmZhY2UgTW9kYWxBcnF1aXZhbWVudG9Qcm9wcyB7XHJcbiAgaXNPcGVuOiBib29sZWFuO1xyXG4gIG9uQ2xvc2U6ICgpID0+IHZvaWQ7XHJcbiAgZGVudW5jaWFJZDogc3RyaW5nO1xyXG4gIHByb3RvY29sbzogc3RyaW5nO1xyXG4gIG9uU3VjZXNzbz86ICgpID0+IHZvaWQ7XHJcbn1cclxuXHJcbmV4cG9ydCBjb25zdCBNb2RhbEFycXVpdmFtZW50bzogUmVhY3QuRkM8TW9kYWxBcnF1aXZhbWVudG9Qcm9wcz4gPSAoe1xyXG4gIGlzT3BlbixcclxuICBvbkNsb3NlLFxyXG4gIGRlbnVuY2lhSWQsXHJcbiAgcHJvdG9jb2xvLFxyXG4gIG9uU3VjZXNzbyxcclxufSkgPT4ge1xyXG4gIGNvbnN0IGNvbmNsdWlyTXV0YXRpb24gPSB1c2VDb25jbHVpckRlbnVuY2lhTXV0YXRpb24oZGVudW5jaWFJZCk7XHJcblxyXG4gIGNvbnN0IHtcclxuICAgIHJlZ2lzdGVyLFxyXG4gICAgaGFuZGxlU3VibWl0LFxyXG4gICAgd2F0Y2gsXHJcbiAgICBmb3JtU3RhdGU6IHsgZXJyb3JzLCBpc1N1Ym1pdHRpbmcgfSxcclxuICB9ID0gdXNlRm9ybTxBcnF1aXZhbWVudG9Gb3JtRGF0YT4oe1xyXG4gICAgcmVzb2x2ZXI6IHpvZFJlc29sdmVyKGFycXVpdmFtZW50b1NjaGVtYSksXHJcbiAgICBkZWZhdWx0VmFsdWVzOiB7XHJcbiAgICAgIHN0YXR1czogXCJhcnF1aXZhZGFcIixcclxuICAgICAgY29uY2x1c2FvX2FwdXJhY2FvOiBcIlwiLFxyXG4gICAgICByZXNwb3N0YV9hb19kZW51bmNpYW50ZTogXCJcIixcclxuICAgIH0sXHJcbiAgfSk7XHJcblxyXG4gIGlmICghaXNPcGVuKSByZXR1cm4gbnVsbDtcclxuXHJcbiAgY29uc3Qgc3RhdHVzU2VsZWNpb25hZG8gPSB3YXRjaChcInN0YXR1c1wiKTtcclxuXHJcbiAgY29uc3Qgb25TdWJtaXQgPSBhc3luYyAoZGF0YTogQXJxdWl2YW1lbnRvRm9ybURhdGEpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHBheWxvYWQ6IENvbmNsdWlyRGVudW5jaWFEVE8gPSB7XHJcbiAgICAgICAgc3RhdHVzOiBkYXRhLnN0YXR1cyBhcyBTdGF0dXNEZW51bmNpYSxcclxuICAgICAgICBjb25jbHVzYW9fYXB1cmFjYW86IGRhdGEuY29uY2x1c2FvX2FwdXJhY2FvLnRyaW0oKSxcclxuICAgICAgICByZXNwb3N0YV9hb19kZW51bmNpYW50ZTogZGF0YS5yZXNwb3N0YV9hb19kZW51bmNpYW50ZT8udHJpbSgpIHx8IG51bGwsXHJcbiAgICAgIH07XHJcblxyXG4gICAgICBhd2FpdCBjb25jbHVpck11dGF0aW9uLm11dGF0ZUFzeW5jKHBheWxvYWQpO1xyXG4gICAgICBpZiAob25TdWNlc3NvKSB7XHJcbiAgICAgICAgb25TdWNlc3NvKCk7XHJcbiAgICAgIH1cclxuICAgICAgb25DbG9zZSgpO1xyXG4gICAgfSBjYXRjaCB7XHJcbiAgICAgIC8vIEVycm8gw6kgdHJhdGFkbyBwZWxvIFJlYWN0IFF1ZXJ5XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZml4ZWQgaW5zZXQtMCB6LTUwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHAtNCBiZy1ibGFjay81MCBiYWNrZHJvcC1ibHVyLXhzXCI+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGFyazpiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtODAwIHJvdW5kZWQtMnhsIHctZnVsbCBtYXgtdy1sZyBzaGFkb3ctMnhsIG92ZXJmbG93LWhpZGRlbiBhbmltYXRlLWluIGZhZGUtaW4gem9vbS1pbi05NSBkdXJhdGlvbi0xNTAgZmxleCBmbGV4LWNvbFwiPlxyXG4gICAgICAgIHsvKiBDYWJlw6dhbGhvICovfVxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHgtNiBweS00IGJvcmRlci1iIGJvcmRlci1zbGF0ZS0xMDAgZGFyazpib3JkZXItc2xhdGUtODAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBiZy1zbGF0ZS01MC81MCBkYXJrOmJnLXNsYXRlLTgwMC80MFwiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMi41XCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy05IGgtOSByb3VuZGVkLXhsIGJnLXNsYXRlLTEwMCBkYXJrOmJnLXNsYXRlLTgwMCB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMzAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgPEFyY2hpdmUgY2xhc3NOYW1lPVwidy01IGgtNVwiIC8+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGVcIj5cclxuICAgICAgICAgICAgICAgIEVuY2VycmFtZW50byAvIEFycXVpdmFtZW50byBkZSBEZW7Dum5jaWFcclxuICAgICAgICAgICAgICA8L2gyPlxyXG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtc2xhdGUtNTAwIGZvbnQtbW9ub1wiPlxyXG4gICAgICAgICAgICAgICAgUHJvdG9jb2xvOiB7cHJvdG9jb2xvfVxyXG4gICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgIG9uQ2xpY2s9e29uQ2xvc2V9XHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMS41IHRleHQtc2xhdGUtNDAwIGhvdmVyOnRleHQtc2xhdGUtNjAwIGRhcms6aG92ZXI6dGV4dC1zbGF0ZS0zMDAgcm91bmRlZC1sZyBob3ZlcjpiZy1zbGF0ZS0xMDAgZGFyazpob3ZlcjpiZy1zbGF0ZS04MDAgdHJhbnNpdGlvbi1jb2xvcnNcIlxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICA8WCBjbGFzc05hbWU9XCJ3LTUgaC01XCIgLz5cclxuICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICB7LyogRm9ybXVsw6FyaW8gKi99XHJcbiAgICAgICAgPGZvcm0gb25TdWJtaXQ9e2hhbmRsZVN1Ym1pdChvblN1Ym1pdCl9IGNsYXNzTmFtZT1cInAtNiBzcGFjZS15LTRcIj5cclxuICAgICAgICAgIHtjb25jbHVpck11dGF0aW9uLmlzRXJyb3IgJiYgKFxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMyBiZy1yb3NlLTUwIGRhcms6Ymctcm9zZS05NTAvNDAgYm9yZGVyIGJvcmRlci1yb3NlLTIwMCBkYXJrOmJvcmRlci1yb3NlLTgwMCByb3VuZGVkLXhsIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRleHQteHMgdGV4dC1yb3NlLTcwMCBkYXJrOnRleHQtcm9zZS0zMDBcIj5cclxuICAgICAgICAgICAgICA8QWxlcnRUcmlhbmdsZSBjbGFzc05hbWU9XCJ3LTQgaC00IHNocmluay0wXCIgLz5cclxuICAgICAgICAgICAgICA8c3Bhbj5cclxuICAgICAgICAgICAgICAgIHtjb25jbHVpck11dGF0aW9uLmVycm9yIGluc3RhbmNlb2YgRXJyb3JcclxuICAgICAgICAgICAgICAgICAgPyBjb25jbHVpck11dGF0aW9uLmVycm9yLm1lc3NhZ2VcclxuICAgICAgICAgICAgICAgICAgOiBcIkVycm8gYW8gY29uY2x1aXIvYXJxdWl2YXIgYSBkZW7Dum5jaWEuXCJ9XHJcbiAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgey8qIFNlbGXDp8OjbyBkbyBEZXNmZWNobyAqL31cclxuICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTMwMCBtYi0xXCI+XHJcbiAgICAgICAgICAgICAgRGVzZmVjaG8gZG8gUHJvY2Vzc28gZGUgT3V2aWRvcmlhIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcm9zZS01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICA8c2VsZWN0XHJcbiAgICAgICAgICAgICAgey4uLnJlZ2lzdGVyKFwic3RhdHVzXCIpfVxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC0zIHB5LTIgdGV4dC14cyBiZy1zbGF0ZS01MCBkYXJrOmJnLXNsYXRlLTgwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC1sZyB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGUgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLXRlYWwtNTAwXCJcclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJhcnF1aXZhZGFcIj5BcnF1aXZhZGEgKE1vdGl2b3MgQWRtaW5pc3RyYXRpdm9zIC8gUHJhem8gRGVjb3JyaWRvKTwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJpbXByb2NlZGVudGVcIj5JbXByb2NlZGVudGUgKEZhdG9zIE7Do28gQ29uc3RhdGFkb3MgZW0gVmlzdG9yaWEpPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cInByb2NlZGVudGVcIj5Qcm9jZWRlbnRlIChJcnJlZ3VsYXJpZGFkZSBDb25zdGF0YWRhIGUgTm90aWZpY2FkYSk8L29wdGlvbj5cclxuICAgICAgICAgICAgPC9zZWxlY3Q+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICB7LyogQ29uY2x1c8OjbyBUw6ljbmljYSBlIEp1c3RpZmljYXRpdmEgKi99XHJcbiAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0zMDAgbWItMVwiPlxyXG4gICAgICAgICAgICAgIENvbmNsdXPDo28gZGEgQXB1cmHDp8OjbyAvIEp1c3RpZmljYXRpdmEgRnVuZGFtZW50YWRhIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcm9zZS01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICA8dGV4dGFyZWFcclxuICAgICAgICAgICAgICByb3dzPXs0fVxyXG4gICAgICAgICAgICAgIHsuLi5yZWdpc3RlcihcImNvbmNsdXNhb19hcHVyYWNhb1wiKX1cclxuICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkRlc2NyZXZhIGZ1bmRhbWVudGFkYW1lbnRlIG9zIG1vdGl2b3MgZsOhdGljb3MgZSBsZWdhaXMgZGEgY29uY2x1c8OjbyBkYSBhcHVyYcOnw6NvLi4uXCJcclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcC0yLjUgdGV4dC14cyBiZy1zbGF0ZS01MCBkYXJrOmJnLXNsYXRlLTgwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC1sZyB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGUgcGxhY2Vob2xkZXItc2xhdGUtNDAwIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy10ZWFsLTUwMFwiXHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIHtlcnJvcnMuY29uY2x1c2FvX2FwdXJhY2FvICYmIChcclxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LXJvc2UtNjAwIG10LTFcIj5cclxuICAgICAgICAgICAgICAgIHtlcnJvcnMuY29uY2x1c2FvX2FwdXJhY2FvLm1lc3NhZ2V9XHJcbiAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICApfVxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgey8qIFJlc3Bvc3RhIFDDumJsaWNhIGFvIENpZGFkw6NvICovfVxyXG4gICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMzAwIG1iLTFcIj5cclxuICAgICAgICAgICAgICBSZXNwb3N0YSBPZmljaWFsIGFvIENpZGFkw6NvIChWaXPDrXZlbCBuYSBDb25zdWx0YSBwb3IgUHJvdG9jb2xvKVxyXG4gICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICA8dGV4dGFyZWFcclxuICAgICAgICAgICAgICByb3dzPXszfVxyXG4gICAgICAgICAgICAgIHsuLi5yZWdpc3RlcihcInJlc3Bvc3RhX2FvX2RlbnVuY2lhbnRlXCIpfVxyXG4gICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRXg6IEEgVmlnaWzDom5jaWEgU2FuaXTDoXJpYSByZWFsaXpvdSBpbnNwZcOnw6NvIG5vIGxvY2FsIGUgY29uc3RhdG91IHF1ZSBvIGVzdGFiZWxlY2ltZW50byBzYW5vdSBhcyBpcnJlZ3VsYXJpZGFkZXMuLi5cIlxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBwLTIuNSB0ZXh0LXhzIGJnLXNsYXRlLTUwIGRhcms6Ymctc2xhdGUtODAwIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCByb3VuZGVkLWxnIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZSBwbGFjZWhvbGRlci1zbGF0ZS00MDAgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLXRlYWwtNTAwXCJcclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1zbGF0ZS00MDAgbXQtMVwiPlxyXG4gICAgICAgICAgICAgIEVzdGUgdGV4dG8gZmljYXLDoSBkaXNwb27DrXZlbCBwYXJhIGxlaXR1cmEgcGVsbyBjaWRhZMOjbyBhbyBjb25zdWx0YXIgbyBwcm90b2NvbG8gZGEgZGVuw7puY2lhLlxyXG4gICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICB7LyogQm90w7VlcyBkZSBBw6fDo28gKi99XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktZW5kIGdhcC0yLjUgcHQtMyBib3JkZXItdCBib3JkZXItc2xhdGUtMTAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMFwiPlxyXG4gICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgb25DbGljaz17b25DbG9zZX1cclxuICAgICAgICAgICAgICBkaXNhYmxlZD17aXNTdWJtaXR0aW5nfVxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTQgcHktMiB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS02MDAgZGFyazp0ZXh0LXNsYXRlLTMwMCBob3ZlcjpiZy1zbGF0ZS0xMDAgZGFyazpob3ZlcjpiZy1zbGF0ZS04MDAgcm91bmRlZC1sZyB0cmFuc2l0aW9uLWNvbG9yc1wiXHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICBDYW5jZWxhclxyXG4gICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxyXG4gICAgICAgICAgICAgIGRpc2FibGVkPXtpc1N1Ym1pdHRpbmd9XHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNSBweS0yIHRleHQteHMgZm9udC1ib2xkIHRleHQtd2hpdGUgYmctc2xhdGUtODAwIGhvdmVyOmJnLXNsYXRlLTkwMCBkYXJrOmJnLXNsYXRlLTcwMCBkYXJrOmhvdmVyOmJnLXNsYXRlLTYwMCByb3VuZGVkLWxnIHNoYWRvdy14cyB0cmFuc2l0aW9uLWNvbG9ycyBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBkaXNhYmxlZDpvcGFjaXR5LTYwXCJcclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIDxBcmNoaXZlIGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPlxyXG4gICAgICAgICAgICAgIDxzcGFuPntpc1N1Ym1pdHRpbmcgPyBcIlNhbHZhbmRvLi4uXCIgOiBcIkNvbmZpcm1hciBFbmNlcnJhbWVudG9cIn08L3NwYW4+XHJcbiAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9mb3JtPlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBNb2RhbEFycXVpdmFtZW50bztcclxuIl19