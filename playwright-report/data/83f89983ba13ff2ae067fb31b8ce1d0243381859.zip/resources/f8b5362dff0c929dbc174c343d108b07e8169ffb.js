import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/layouts/AppLayout.tsx");const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport6_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport6_react_jsxDevRuntime["Fragment"];/**
* Shell Principal e Layout do Sistema VigiMinas (AppLayout)
* Estrutura com Sidebar retrátil, Header com informações do fiscal logado,
* navegação filtrada por RBAC e rodapé com metadados institucionais dinâmicos.
*/
import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=0fd2848a";
import { Link, NavLink, Outlet, useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=0fd2848a";
import { AlertCircle, BarChart3, Building2, ChevronRight, ClipboardCheck, Clock, FileCheck, LayoutDashboard, LogOut, Menu, Shield, Users, X } from "/node_modules/.vite/deps/lucide-react.js?v=0fd2848a";
import { APP_CONFIG } from "/src/config/app.config.ts";
import { ROUTES } from "/src/config/routes.config.ts";
import { useAuth } from "/src/contexts/AuthContext.tsx";
var _jsxFileName = "E:/Projetos VSCODE/visa_braunas/src/layouts/AppLayout.tsx";
import __vite__cjsImport6_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=0fd2848a";
var _s = $RefreshSig$();
const MENU_ITEMS = [
	{
		label: "Painel Geral",
		path: ROUTES.DASHBOARD,
		icon: LayoutDashboard
	},
	{
		label: "Estabelecimentos",
		path: ROUTES.ESTABELECIMENTOS.LIST,
		icon: Building2
	},
	{
		label: "Fiscalização & VAPT",
		path: ROUTES.INSPECOES.LIST,
		icon: ClipboardCheck,
		allowedRoles: [
			"admin_master",
			"coordenador",
			"fiscal_tecnico"
		]
	},
	{
		label: "Painel de Prazos",
		path: ROUTES.INSPECOES.PRAZOS,
		icon: Clock,
		allowedRoles: [
			"admin_master",
			"coordenador",
			"fiscal_tecnico"
		]
	},
	{
		label: "Alvarás & Licenciamento",
		path: ROUTES.LICENCIAMENTO.LIST,
		icon: FileCheck
	},
	{
		label: "Ouvidoria & Denúncias",
		path: ROUTES.OUVIDORIA.LIST,
		icon: AlertCircle
	},
	{
		label: "Metas & Indicadores",
		path: ROUTES.INDICADORES.DASHBOARD,
		icon: BarChart3,
		allowedRoles: [
			"admin_master",
			"coordenador",
			"fiscal_tecnico"
		]
	},
	{
		label: "Usuários & Servidores",
		path: ROUTES.USUARIOS.LIST,
		icon: Users,
		allowedRoles: ["admin_master", "coordenador"]
	}
];
const PERFIL_BADGES = {
	admin_master: {
		label: "Admin Master",
		bgClass: "bg-purple-50 dark:bg-purple-950/40",
		textClass: "text-purple-700 dark:text-purple-300",
		borderClass: "border-purple-200 dark:border-purple-800"
	},
	coordenador: {
		label: "Coordenador VISA",
		bgClass: "bg-blue-50 dark:bg-blue-950/40",
		textClass: "text-blue-700 dark:text-blue-300",
		borderClass: "border-blue-200 dark:border-blue-800"
	},
	fiscal_tecnico: {
		label: "Fiscal Sanitário",
		bgClass: "bg-teal-50 dark:bg-teal-950/40",
		textClass: "text-teal-700 dark:text-teal-300",
		borderClass: "border-teal-200 dark:border-teal-800"
	},
	digitador: {
		label: "Digitador",
		bgClass: "bg-slate-100 dark:bg-slate-800",
		textClass: "text-slate-700 dark:text-slate-300",
		borderClass: "border-slate-200 dark:border-slate-700"
	}
};
export const AppLayout = () => {
	_s();
	const { user, logout, hasPermission } = useAuth();
	const navigate = useNavigate();
	const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
	// Filtragem dinâmica dos itens de menu com base nas permissões RBAC do usuário
	const visibleMenuItems = MENU_ITEMS.filter((item) => hasPermission(item.allowedRoles));
	const handleLogout = () => {
		logout();
		navigate(ROUTES.AUTH.LOGIN);
	};
	const perfilMeta = user ? PERFIL_BADGES[user.perfil] || {
		label: user.perfil,
		bgClass: "bg-slate-100",
		textClass: "text-slate-700",
		borderClass: "border-slate-200"
	} : null;
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col antialiased",
		children: [
			/* @__PURE__ */ _jsxDEV("header", {
				className: "sticky top-0 z-40 bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800",
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							onClick: () => setMobileMenuOpen(!mobileMenuOpen),
							className: "md:hidden p-2 text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-teal-600",
							"aria-label": "Alternar navegação lateral",
							children: mobileMenuOpen ? /* @__PURE__ */ _jsxDEV(X, { className: "w-5 h-5" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 151,
								columnNumber: 17
							}, this) : /* @__PURE__ */ _jsxDEV(Menu, { className: "w-5 h-5" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 153,
								columnNumber: 17
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 144,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV(Link, {
							to: ROUTES.DASHBOARD,
							className: "flex items-center gap-2.5 text-slate-900 dark:text-white group focus-visible:outline-none",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "w-9 h-9 rounded-lg bg-teal-600 text-white flex items-center justify-center font-bold shadow-xs",
								children: /* @__PURE__ */ _jsxDEV(Shield, { className: "w-5 h-5 text-white" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 162,
									columnNumber: 17
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 161,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "flex flex-col",
								children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "font-bold text-base leading-tight tracking-tight",
									children: APP_CONFIG.nome
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 165,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("span", {
									className: "text-[11px] text-slate-500 dark:text-slate-400 leading-tight",
									children: [
										APP_CONFIG.municipio,
										" / ",
										APP_CONFIG.uf
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 168,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 164,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 157,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 143,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-4",
						children: [
							user && /* @__PURE__ */ _jsxDEV("div", {
								className: "hidden sm:flex flex-col text-right",
								children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "text-xs font-semibold text-slate-800 dark:text-slate-200 truncate max-w-[200px]",
									children: user.nome_completo
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 179,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("span", {
									className: "text-[11px] text-slate-500 dark:text-slate-400 truncate max-w-[200px]",
									children: user.cargo
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 182,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 178,
								columnNumber: 15
							}, this),
							perfilMeta && /* @__PURE__ */ _jsxDEV("span", {
								className: `text-[11px] font-medium px-2 py-0.5 rounded-md border ${perfilMeta.bgClass} ${perfilMeta.textClass} ${perfilMeta.borderClass} shrink-0`,
								children: perfilMeta.label
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 189,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								onClick: handleLogout,
								className: "inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 dark:text-slate-200 hover:text-rose-600 dark:hover:text-rose-400 bg-slate-100 dark:bg-slate-800 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded-lg transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-rose-500 shrink-0",
								title: "Encerrar Sessão",
								children: [/* @__PURE__ */ _jsxDEV(LogOut, { className: "w-3.5 h-3.5" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 202,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("span", {
									className: "hidden md:inline",
									children: "Sair"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 203,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 196,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 176,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 141,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 140,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 flex gap-6",
				children: [
					/* @__PURE__ */ _jsxDEV("aside", {
						className: "hidden md:block w-64 shrink-0",
						children: /* @__PURE__ */ _jsxDEV("nav", {
							className: "sticky top-24 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-3 shadow-xs space-y-1",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "px-3 py-2 text-[11px] font-bold uppercase tracking-wider text-slate-400 dark:text-slate-500",
								children: "Módulos Regulatórios"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 214,
								columnNumber: 13
							}, this), visibleMenuItems.map((item) => {
								const Icon = item.icon;
								return /* @__PURE__ */ _jsxDEV(NavLink, {
									to: item.path,
									end: item.path === "/",
									className: ({ isActive }) => `flex items-center justify-between px-3 py-2 text-xs font-medium rounded-lg transition-colors group ${isActive ? "bg-teal-50 dark:bg-teal-950/50 text-teal-800 dark:text-teal-300 font-semibold" : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800/60"}`,
									children: ({ isActive }) => /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center gap-2.5",
										children: [/* @__PURE__ */ _jsxDEV(Icon, { className: `w-4 h-4 transition-colors ${isActive ? "text-teal-600 dark:text-teal-400" : "text-slate-400 group-hover:text-slate-600 dark:group-hover:text-slate-300"}` }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 236,
											columnNumber: 25
										}, this), /* @__PURE__ */ _jsxDEV("span", { children: item.label }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 243,
											columnNumber: 25
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 235,
										columnNumber: 23
									}, this), /* @__PURE__ */ _jsxDEV(ChevronRight, { className: `w-3.5 h-3.5 opacity-0 group-hover:opacity-100 transition-opacity ${isActive ? "opacity-100 text-teal-600 dark:text-teal-400" : "text-slate-300 dark:text-slate-600"}` }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 245,
										columnNumber: 23
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 234,
										columnNumber: 21
									}, this)
								}, item.path, false, {
									fileName: _jsxFileName,
									lineNumber: 221,
									columnNumber: 17
								}, this);
							})]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 213,
							columnNumber: 11
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 212,
						columnNumber: 9
					}, this),
					mobileMenuOpen && /* @__PURE__ */ _jsxDEV("div", {
						className: "md:hidden fixed inset-0 z-50 bg-slate-950/50 backdrop-blur-xs flex",
						onClick: () => setMobileMenuOpen(false),
						children: /* @__PURE__ */ _jsxDEV("div", {
							className: "w-72 bg-white dark:bg-slate-900 h-full p-4 border-r border-slate-200 dark:border-slate-800 flex flex-col justify-between",
							onClick: (e) => e.stopPropagation(),
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "space-y-4",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center gap-2",
										children: [/* @__PURE__ */ _jsxDEV(Shield, { className: "w-5 h-5 text-teal-600" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 273,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("span", {
											className: "font-bold text-sm",
											children: APP_CONFIG.nome
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 274,
											columnNumber: 21
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 272,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										onClick: () => setMobileMenuOpen(false),
										className: "p-1 text-slate-500 hover:text-slate-800 dark:hover:text-white",
										children: /* @__PURE__ */ _jsxDEV(X, { className: "w-5 h-5" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 281,
											columnNumber: 21
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 276,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 271,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "space-y-1",
									children: visibleMenuItems.map((item) => {
										const Icon = item.icon;
										return /* @__PURE__ */ _jsxDEV(NavLink, {
											to: item.path,
											end: item.path === "/",
											onClick: () => setMobileMenuOpen(false),
											className: ({ isActive }) => `flex items-center gap-3 px-3 py-2 text-xs font-medium rounded-lg transition-colors ${isActive ? "bg-teal-50 dark:bg-teal-950/60 text-teal-700 dark:text-teal-300 font-semibold" : "text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800"}`,
											children: [/* @__PURE__ */ _jsxDEV(Icon, { className: "w-4 h-4 text-slate-500" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 302,
												columnNumber: 25
											}, this), /* @__PURE__ */ _jsxDEV("span", { children: item.label }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 303,
												columnNumber: 25
											}, this)]
										}, item.path, true, {
											fileName: _jsxFileName,
											lineNumber: 289,
											columnNumber: 23
										}, this);
									})
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 285,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 270,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "pt-4 border-t border-slate-200 dark:border-slate-800",
								children: /* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: handleLogout,
									className: "w-full flex items-center justify-center gap-2 px-3 py-2 text-xs font-medium text-rose-600 dark:text-rose-400 bg-rose-50 dark:bg-rose-950/40 rounded-lg hover:bg-rose-100 transition-colors",
									children: [/* @__PURE__ */ _jsxDEV(LogOut, { className: "w-4 h-4" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 316,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Encerrar Sessão" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 317,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 311,
									columnNumber: 17
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 310,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 266,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 262,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("main", {
						className: "flex-1 min-w-0",
						children: /* @__PURE__ */ _jsxDEV(Outlet, {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 326,
							columnNumber: 11
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 325,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 210,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("footer", {
				className: "mt-auto border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 py-4",
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center text-xs text-slate-500 dark:text-slate-400",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex flex-wrap items-center justify-center gap-x-2 gap-y-1",
						children: [
							/* @__PURE__ */ _jsxDEV("span", {
								className: "font-semibold text-slate-700 dark:text-slate-300",
								children: [
									APP_CONFIG.nome,
									" v",
									APP_CONFIG.versao
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 334,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("span", {
								"aria-hidden": "true",
								children: "·"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 337,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("span", { children: [
								APP_CONFIG.municipio,
								"/",
								APP_CONFIG.uf
							] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 338,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("span", {
								"aria-hidden": "true",
								children: "·"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 341,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("span", { children: APP_CONFIG.secretaria }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 342,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("span", {
								"aria-hidden": "true",
								children: "·"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 343,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("span", { children: APP_CONFIG.orgao }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 344,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 333,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("p", {
						className: "mt-1 text-[11px] text-slate-400 dark:text-slate-500",
						children: [
							"© ",
							new Date().getFullYear(),
							" ",
							APP_CONFIG.prefeitura,
							". Todos os direitos reservados."
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 346,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 332,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 331,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 138,
		columnNumber: 5
	}, this);
};
_s(AppLayout, "lUXVCNsly5yKhedtzbu1cHvQiBE=", false, function() {
	return [useAuth, useNavigate];
});
_c = AppLayout;
export default AppLayout;
var _c;
$RefreshReg$(_c, "AppLayout");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/layouts/AppLayout.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("E:/Projetos VSCODE/visa_braunas/src/layouts/AppLayout.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("E:/Projetos VSCODE/visa_braunas/src/layouts/AppLayout.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "E:/Projetos VSCODE/visa_braunas/src/layouts/AppLayout.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7Ozs7QUFNQSxPQUFPLFNBQVMsZ0JBQWdCO0FBQ2hDLFNBQVMsTUFBTSxTQUFTLFFBQVEsbUJBQW1CO0FBQ25ELFNBQ0UsYUFDQSxXQUNBLFdBQ0EsY0FDQSxnQkFDQSxPQUNBLFdBQ0EsaUJBQ0EsUUFDQSxNQUNBLFFBQ0EsT0FDQSxTQUNLO0FBQ1AsU0FBUyxrQkFBa0I7QUFDM0IsU0FBUyxjQUFjO0FBQ3ZCLFNBQVMsZUFBZTs7OztBQVV4QixNQUFNLGFBQTRCO0NBQ2hDO0VBQ0UsT0FBTztFQUNQLE1BQU0sT0FBTztFQUNiLE1BQU07Q0FDUjtDQUNBO0VBQ0UsT0FBTztFQUNQLE1BQU0sT0FBTyxpQkFBaUI7RUFDOUIsTUFBTTtDQUNSO0NBQ0E7RUFDRSxPQUFPO0VBQ1AsTUFBTSxPQUFPLFVBQVU7RUFDdkIsTUFBTTtFQUNOLGNBQWM7R0FBQztHQUFnQjtHQUFlO0VBQWdCO0NBQ2hFO0NBQ0E7RUFDRSxPQUFPO0VBQ1AsTUFBTSxPQUFPLFVBQVU7RUFDdkIsTUFBTTtFQUNOLGNBQWM7R0FBQztHQUFnQjtHQUFlO0VBQWdCO0NBQ2hFO0NBQ0E7RUFDRSxPQUFPO0VBQ1AsTUFBTSxPQUFPLGNBQWM7RUFDM0IsTUFBTTtDQUNSO0NBQ0E7RUFDRSxPQUFPO0VBQ1AsTUFBTSxPQUFPLFVBQVU7RUFDdkIsTUFBTTtDQUNSO0NBQ0E7RUFDRSxPQUFPO0VBQ1AsTUFBTSxPQUFPLFlBQVk7RUFDekIsTUFBTTtFQUNOLGNBQWM7R0FBQztHQUFnQjtHQUFlO0VBQWdCO0NBQ2hFO0NBQ0E7RUFDRSxPQUFPO0VBQ1AsTUFBTSxPQUFPLFNBQVM7RUFDdEIsTUFBTTtFQUNOLGNBQWMsQ0FBQyxnQkFBZ0IsYUFBYTtDQUM5QztBQUNGO0FBRUEsTUFBTSxnQkFHRjtDQUNGLGNBQWM7RUFDWixPQUFPO0VBQ1AsU0FBUztFQUNULFdBQVc7RUFDWCxhQUFhO0NBQ2Y7Q0FDQSxhQUFhO0VBQ1gsT0FBTztFQUNQLFNBQVM7RUFDVCxXQUFXO0VBQ1gsYUFBYTtDQUNmO0NBQ0EsZ0JBQWdCO0VBQ2QsT0FBTztFQUNQLFNBQVM7RUFDVCxXQUFXO0VBQ1gsYUFBYTtDQUNmO0NBQ0EsV0FBVztFQUNULE9BQU87RUFDUCxTQUFTO0VBQ1QsV0FBVztFQUNYLGFBQWE7Q0FDZjtBQUNGO0FBRUEsT0FBTyxNQUFNLGtCQUE0Qjs7Q0FDdkMsTUFBTSxFQUFFLE1BQU0sUUFBUSxrQkFBa0IsUUFBUTtDQUNoRCxNQUFNLFdBQVcsWUFBWTtDQUM3QixNQUFNLENBQUMsZ0JBQWdCLHFCQUFxQixTQUFTLEtBQUs7O0NBRzFELE1BQU0sbUJBQW1CLFdBQVcsUUFBUSxTQUMxQyxjQUFjLEtBQUssWUFBWSxDQUNqQztDQUVBLE1BQU0scUJBQXFCO0VBQ3pCLE9BQU87RUFDUCxTQUFTLE9BQU8sS0FBSyxLQUFLO0NBQzVCO0NBRUEsTUFBTSxhQUFhLE9BQ2YsY0FBYyxLQUFLLFdBQVc7RUFDNUIsT0FBTyxLQUFLO0VBQ1osU0FBUztFQUNULFdBQVc7RUFDWCxhQUFhO0NBQ2YsSUFDQTtDQUVKLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBZjtHQUVFLHdCQUFDLFVBQUQ7SUFBUSxXQUFVO2NBQ2hCLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FFRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLFVBQUQ7T0FDRSxNQUFLO09BQ0wsZUFBZSxrQkFBa0IsQ0FBQyxjQUFjO09BQ2hELFdBQVU7T0FDVixjQUFXO2lCQUVWLGlCQUNDLHdCQUFDLEdBQUQsRUFBRyxXQUFVLFVBQVc7Ozs7a0JBRXhCLHdCQUFDLE1BQUQsRUFBTSxXQUFVLFVBQVc7Ozs7O01BRXZCOzs7O2dCQUVSLHdCQUFDLE1BQUQ7T0FDRSxJQUFJLE9BQU87T0FDWCxXQUFVO2lCQUZaLENBSUUsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQ2Isd0JBQUMsUUFBRCxFQUFRLFdBQVUscUJBQXNCOzs7OztPQUNyQzs7OztpQkFDTCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUNiLFdBQVc7UUFDUjs7OztrQkFDTix3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFBaEI7VUFDRyxXQUFXO1VBQVU7VUFBSSxXQUFXO1NBQ2pDOzs7OztnQkFDSDs7Ozs7ZUFDRDs7Ozs7Y0FDSDs7Ozs7ZUFHTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZjtPQUNHLFFBQ0Msd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFDYixLQUFLO1FBQ0Y7Ozs7a0JBQ04sd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQ2IsS0FBSztRQUNGOzs7O2dCQUNIOzs7Ozs7T0FHTixjQUNDLHdCQUFDLFFBQUQ7UUFDRSxXQUFXLHlEQUF5RCxXQUFXLFFBQVEsR0FBRyxXQUFXLFVBQVUsR0FBRyxXQUFXLFlBQVk7a0JBRXhJLFdBQVc7T0FDUjs7Ozs7T0FHUix3QkFBQyxVQUFEO1FBQ0UsTUFBSztRQUNMLFNBQVM7UUFDVCxXQUFVO1FBQ1YsT0FBTTtrQkFKUixDQU1FLHdCQUFDLFFBQUQsRUFBUSxXQUFVLGNBQWU7Ozs7a0JBQ2pDLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUFtQjtRQUFVOzs7O2dCQUN2Qzs7Ozs7O01BQ0w7Ozs7O2FBQ0Y7Ozs7OztHQUNDOzs7OztHQUdSLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWY7S0FFRSx3QkFBQyxTQUFEO01BQU8sV0FBVTtnQkFDZix3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUE4RjtPQUV4Rzs7OztpQkFFSixpQkFBaUIsS0FBSyxTQUFTO1FBQzlCLE1BQU0sT0FBTyxLQUFLO1FBQ2xCLE9BQ0Usd0JBQUMsU0FBRDtTQUVFLElBQUksS0FBSztTQUNULEtBQUssS0FBSyxTQUFTO1NBQ25CLFlBQVksRUFBRSxlQUNaLHNHQUNFLFdBQ0ksa0ZBQ0E7b0JBSU4sRUFBRSxlQUNGLGdEQUNFLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmLENBQ0Usd0JBQUMsTUFBRCxFQUNFLFdBQVcsNkJBQ1QsV0FDSSxxQ0FDQSw4RUFFUDs7OztvQkFDRCx3QkFBQyxRQUFELFlBQU8sS0FBSyxNQUFZOzs7O2tCQUNyQjs7Ozs7bUJBQ0wsd0JBQUMsY0FBRCxFQUNFLFdBQVcsb0VBQ1QsV0FDSSxpREFDQSx1Q0FFUDs7OztpQkFDRDs7Ozs7UUFFRyxHQWhDRixLQUFLOzs7O2VBZ0NIO09BRWIsQ0FBQyxDQUNFOzs7Ozs7S0FDQTs7Ozs7S0FHTixrQkFDQyx3QkFBQyxPQUFEO01BQ0UsV0FBVTtNQUNWLGVBQWUsa0JBQWtCLEtBQUs7Z0JBRXRDLHdCQUFDLE9BQUQ7T0FDRSxXQUFVO09BQ1YsVUFBVSxNQUFNLEVBQUUsZ0JBQWdCO2lCQUZwQyxDQUlFLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDRSx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNFLHdCQUFDLFFBQUQsRUFBUSxXQUFVLHdCQUF5Qjs7OztvQkFDM0Msd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQXFCLFdBQVc7VUFBVzs7OztrQkFDeEQ7Ozs7O21CQUNMLHdCQUFDLFVBQUQ7VUFDRSxNQUFLO1VBQ0wsZUFBZSxrQkFBa0IsS0FBSztVQUN0QyxXQUFVO29CQUVWLHdCQUFDLEdBQUQsRUFBRyxXQUFVLFVBQVc7Ozs7O1NBQ2xCOzs7O2lCQUNMOzs7OztrQkFFTCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFDWixpQkFBaUIsS0FBSyxTQUFTO1VBQzlCLE1BQU0sT0FBTyxLQUFLO1VBQ2xCLE9BQ0Usd0JBQUMsU0FBRDtXQUVFLElBQUksS0FBSztXQUNULEtBQUssS0FBSyxTQUFTO1dBQ25CLGVBQWUsa0JBQWtCLEtBQUs7V0FDdEMsWUFBWSxFQUFFLGVBQ1osc0ZBQ0UsV0FDSSxrRkFDQTtxQkFUVixDQWFFLHdCQUFDLE1BQUQsRUFBTSxXQUFVLHlCQUEwQjs7OztxQkFDMUMsd0JBQUMsUUFBRCxZQUFPLEtBQUssTUFBWTs7OzttQkFDakI7YUFkRixLQUFLOzs7O2lCQWNIO1NBRWIsQ0FBQztRQUNFOzs7O2dCQUNGOzs7OztpQkFFTCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFDYix3QkFBQyxVQUFEO1NBQ0UsTUFBSztTQUNMLFNBQVM7U0FDVCxXQUFVO21CQUhaLENBS0Usd0JBQUMsUUFBRCxFQUFRLFdBQVUsVUFBVzs7OzttQkFDN0Isd0JBQUMsUUFBRCxZQUFNLGtCQUFxQjs7OztpQkFDckI7Ozs7OztPQUNMOzs7O2VBQ0Y7Ozs7OztLQUNGOzs7OztLQUlQLHdCQUFDLFFBQUQ7TUFBTSxXQUFVO2dCQUNkLHdCQUFDLFFBQUQsQ0FBUzs7Ozs7S0FDTDs7Ozs7SUFDSDs7Ozs7O0dBR0wsd0JBQUMsVUFBRDtJQUFRLFdBQVU7Y0FDaEIsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmO09BQ0Usd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQWhCO1NBQ0csV0FBVztTQUFLO1NBQUcsV0FBVztRQUMzQjs7Ozs7O09BQ04sd0JBQUMsUUFBRDtRQUFNLGVBQVk7a0JBQU87T0FBTzs7Ozs7T0FDaEMsd0JBQUMsUUFBRDtRQUNHLFdBQVc7UUFBVTtRQUFFLFdBQVc7T0FDL0I7Ozs7O09BQ04sd0JBQUMsUUFBRDtRQUFNLGVBQVk7a0JBQU87T0FBTzs7Ozs7T0FDaEMsd0JBQUMsUUFBRCxZQUFPLFdBQVcsV0FBaUI7Ozs7O09BQ25DLHdCQUFDLFFBQUQ7UUFBTSxlQUFZO2tCQUFPO09BQU87Ozs7O09BQ2hDLHdCQUFDLFFBQUQsWUFBTyxXQUFXLE1BQVk7Ozs7O01BQzNCOzs7OztlQUNMLHdCQUFDLEtBQUQ7TUFBRyxXQUFVO2dCQUFiO09BQW1FO09BQzlELElBQUksS0FBSyxDQUFDLENBQUMsWUFBWTtPQUFFO09BQUUsV0FBVztPQUFXO01BQ25EOzs7OzthQUNBOzs7Ozs7R0FDQzs7Ozs7RUFDTDs7Ozs7O0FBRVQ7Ozs7O0FBRUEsZUFBZSIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJBcHBMYXlvdXQudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbIi8qKlxyXG4gKiBTaGVsbCBQcmluY2lwYWwgZSBMYXlvdXQgZG8gU2lzdGVtYSBWaWdpTWluYXMgKEFwcExheW91dClcclxuICogRXN0cnV0dXJhIGNvbSBTaWRlYmFyIHJldHLDoXRpbCwgSGVhZGVyIGNvbSBpbmZvcm1hw6fDtWVzIGRvIGZpc2NhbCBsb2dhZG8sXHJcbiAqIG5hdmVnYcOnw6NvIGZpbHRyYWRhIHBvciBSQkFDIGUgcm9kYXDDqSBjb20gbWV0YWRhZG9zIGluc3RpdHVjaW9uYWlzIGRpbsOibWljb3MuXHJcbiAqL1xyXG5cclxuaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7IExpbmssIE5hdkxpbmssIE91dGxldCwgdXNlTmF2aWdhdGUgfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xyXG5pbXBvcnQge1xyXG4gIEFsZXJ0Q2lyY2xlLFxyXG4gIEJhckNoYXJ0MyxcclxuICBCdWlsZGluZzIsXHJcbiAgQ2hldnJvblJpZ2h0LFxyXG4gIENsaXBib2FyZENoZWNrLFxyXG4gIENsb2NrLFxyXG4gIEZpbGVDaGVjayxcclxuICBMYXlvdXREYXNoYm9hcmQsXHJcbiAgTG9nT3V0LFxyXG4gIE1lbnUsXHJcbiAgU2hpZWxkLFxyXG4gIFVzZXJzLFxyXG4gIFgsXHJcbn0gZnJvbSBcImx1Y2lkZS1yZWFjdFwiO1xyXG5pbXBvcnQgeyBBUFBfQ09ORklHIH0gZnJvbSBcIi4uL2NvbmZpZy9hcHAuY29uZmlnXCI7XHJcbmltcG9ydCB7IFJPVVRFUyB9IGZyb20gXCIuLi9jb25maWcvcm91dGVzLmNvbmZpZ1wiO1xyXG5pbXBvcnQgeyB1c2VBdXRoIH0gZnJvbSBcIi4uL2NvbnRleHRzL0F1dGhDb250ZXh0XCI7XHJcbmltcG9ydCB7IFBlcmZpbFVzdWFyaW8gfSBmcm9tIFwiLi4vdHlwZXMvYXV0aFwiO1xyXG5cclxuaW50ZXJmYWNlIE5hdk1lbnVJdGVtIHtcclxuICBsYWJlbDogc3RyaW5nO1xyXG4gIHBhdGg6IHN0cmluZztcclxuICBpY29uOiBSZWFjdC5Db21wb25lbnRUeXBlPHsgY2xhc3NOYW1lPzogc3RyaW5nIH0+O1xyXG4gIGFsbG93ZWRSb2xlcz86IFBlcmZpbFVzdWFyaW9bXTtcclxufVxyXG5cclxuY29uc3QgTUVOVV9JVEVNUzogTmF2TWVudUl0ZW1bXSA9IFtcclxuICB7XHJcbiAgICBsYWJlbDogXCJQYWluZWwgR2VyYWxcIixcclxuICAgIHBhdGg6IFJPVVRFUy5EQVNIQk9BUkQsXHJcbiAgICBpY29uOiBMYXlvdXREYXNoYm9hcmQsXHJcbiAgfSxcclxuICB7XHJcbiAgICBsYWJlbDogXCJFc3RhYmVsZWNpbWVudG9zXCIsXHJcbiAgICBwYXRoOiBST1VURVMuRVNUQUJFTEVDSU1FTlRPUy5MSVNULFxyXG4gICAgaWNvbjogQnVpbGRpbmcyLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgbGFiZWw6IFwiRmlzY2FsaXphw6fDo28gJiBWQVBUXCIsXHJcbiAgICBwYXRoOiBST1VURVMuSU5TUEVDT0VTLkxJU1QsXHJcbiAgICBpY29uOiBDbGlwYm9hcmRDaGVjayxcclxuICAgIGFsbG93ZWRSb2xlczogW1wiYWRtaW5fbWFzdGVyXCIsIFwiY29vcmRlbmFkb3JcIiwgXCJmaXNjYWxfdGVjbmljb1wiXSxcclxuICB9LFxyXG4gIHtcclxuICAgIGxhYmVsOiBcIlBhaW5lbCBkZSBQcmF6b3NcIixcclxuICAgIHBhdGg6IFJPVVRFUy5JTlNQRUNPRVMuUFJBWk9TLFxyXG4gICAgaWNvbjogQ2xvY2ssXHJcbiAgICBhbGxvd2VkUm9sZXM6IFtcImFkbWluX21hc3RlclwiLCBcImNvb3JkZW5hZG9yXCIsIFwiZmlzY2FsX3RlY25pY29cIl0sXHJcbiAgfSxcclxuICB7XHJcbiAgICBsYWJlbDogXCJBbHZhcsOhcyAmIExpY2VuY2lhbWVudG9cIixcclxuICAgIHBhdGg6IFJPVVRFUy5MSUNFTkNJQU1FTlRPLkxJU1QsXHJcbiAgICBpY29uOiBGaWxlQ2hlY2ssXHJcbiAgfSxcclxuICB7XHJcbiAgICBsYWJlbDogXCJPdXZpZG9yaWEgJiBEZW7Dum5jaWFzXCIsXHJcbiAgICBwYXRoOiBST1VURVMuT1VWSURPUklBLkxJU1QsXHJcbiAgICBpY29uOiBBbGVydENpcmNsZSxcclxuICB9LFxyXG4gIHtcclxuICAgIGxhYmVsOiBcIk1ldGFzICYgSW5kaWNhZG9yZXNcIixcclxuICAgIHBhdGg6IFJPVVRFUy5JTkRJQ0FET1JFUy5EQVNIQk9BUkQsXHJcbiAgICBpY29uOiBCYXJDaGFydDMsXHJcbiAgICBhbGxvd2VkUm9sZXM6IFtcImFkbWluX21hc3RlclwiLCBcImNvb3JkZW5hZG9yXCIsIFwiZmlzY2FsX3RlY25pY29cIl0sXHJcbiAgfSxcclxuICB7XHJcbiAgICBsYWJlbDogXCJVc3XDoXJpb3MgJiBTZXJ2aWRvcmVzXCIsXHJcbiAgICBwYXRoOiBST1VURVMuVVNVQVJJT1MuTElTVCxcclxuICAgIGljb246IFVzZXJzLFxyXG4gICAgYWxsb3dlZFJvbGVzOiBbXCJhZG1pbl9tYXN0ZXJcIiwgXCJjb29yZGVuYWRvclwiXSxcclxuICB9LFxyXG5dO1xyXG5cclxuY29uc3QgUEVSRklMX0JBREdFUzogUmVjb3JkPFxyXG4gIFBlcmZpbFVzdWFyaW8sXHJcbiAgeyBsYWJlbDogc3RyaW5nOyBiZ0NsYXNzOiBzdHJpbmc7IHRleHRDbGFzczogc3RyaW5nOyBib3JkZXJDbGFzczogc3RyaW5nIH1cclxuPiA9IHtcclxuICBhZG1pbl9tYXN0ZXI6IHtcclxuICAgIGxhYmVsOiBcIkFkbWluIE1hc3RlclwiLFxyXG4gICAgYmdDbGFzczogXCJiZy1wdXJwbGUtNTAgZGFyazpiZy1wdXJwbGUtOTUwLzQwXCIsXHJcbiAgICB0ZXh0Q2xhc3M6IFwidGV4dC1wdXJwbGUtNzAwIGRhcms6dGV4dC1wdXJwbGUtMzAwXCIsXHJcbiAgICBib3JkZXJDbGFzczogXCJib3JkZXItcHVycGxlLTIwMCBkYXJrOmJvcmRlci1wdXJwbGUtODAwXCIsXHJcbiAgfSxcclxuICBjb29yZGVuYWRvcjoge1xyXG4gICAgbGFiZWw6IFwiQ29vcmRlbmFkb3IgVklTQVwiLFxyXG4gICAgYmdDbGFzczogXCJiZy1ibHVlLTUwIGRhcms6YmctYmx1ZS05NTAvNDBcIixcclxuICAgIHRleHRDbGFzczogXCJ0ZXh0LWJsdWUtNzAwIGRhcms6dGV4dC1ibHVlLTMwMFwiLFxyXG4gICAgYm9yZGVyQ2xhc3M6IFwiYm9yZGVyLWJsdWUtMjAwIGRhcms6Ym9yZGVyLWJsdWUtODAwXCIsXHJcbiAgfSxcclxuICBmaXNjYWxfdGVjbmljbzoge1xyXG4gICAgbGFiZWw6IFwiRmlzY2FsIFNhbml0w6FyaW9cIixcclxuICAgIGJnQ2xhc3M6IFwiYmctdGVhbC01MCBkYXJrOmJnLXRlYWwtOTUwLzQwXCIsXHJcbiAgICB0ZXh0Q2xhc3M6IFwidGV4dC10ZWFsLTcwMCBkYXJrOnRleHQtdGVhbC0zMDBcIixcclxuICAgIGJvcmRlckNsYXNzOiBcImJvcmRlci10ZWFsLTIwMCBkYXJrOmJvcmRlci10ZWFsLTgwMFwiLFxyXG4gIH0sXHJcbiAgZGlnaXRhZG9yOiB7XHJcbiAgICBsYWJlbDogXCJEaWdpdGFkb3JcIixcclxuICAgIGJnQ2xhc3M6IFwiYmctc2xhdGUtMTAwIGRhcms6Ymctc2xhdGUtODAwXCIsXHJcbiAgICB0ZXh0Q2xhc3M6IFwidGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTMwMFwiLFxyXG4gICAgYm9yZGVyQ2xhc3M6IFwiYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDBcIixcclxuICB9LFxyXG59O1xyXG5cclxuZXhwb3J0IGNvbnN0IEFwcExheW91dDogUmVhY3QuRkMgPSAoKSA9PiB7XHJcbiAgY29uc3QgeyB1c2VyLCBsb2dvdXQsIGhhc1Blcm1pc3Npb24gfSA9IHVzZUF1dGgoKTtcclxuICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKCk7XHJcbiAgY29uc3QgW21vYmlsZU1lbnVPcGVuLCBzZXRNb2JpbGVNZW51T3Blbl0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcblxyXG4gIC8vIEZpbHRyYWdlbSBkaW7Dom1pY2EgZG9zIGl0ZW5zIGRlIG1lbnUgY29tIGJhc2UgbmFzIHBlcm1pc3PDtWVzIFJCQUMgZG8gdXN1w6FyaW9cclxuICBjb25zdCB2aXNpYmxlTWVudUl0ZW1zID0gTUVOVV9JVEVNUy5maWx0ZXIoKGl0ZW0pID0+XHJcbiAgICBoYXNQZXJtaXNzaW9uKGl0ZW0uYWxsb3dlZFJvbGVzKVxyXG4gICk7XHJcblxyXG4gIGNvbnN0IGhhbmRsZUxvZ291dCA9ICgpID0+IHtcclxuICAgIGxvZ291dCgpO1xyXG4gICAgbmF2aWdhdGUoUk9VVEVTLkFVVEguTE9HSU4pO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IHBlcmZpbE1ldGEgPSB1c2VyXHJcbiAgICA/IFBFUkZJTF9CQURHRVNbdXNlci5wZXJmaWxdIHx8IHtcclxuICAgICAgICBsYWJlbDogdXNlci5wZXJmaWwsXHJcbiAgICAgICAgYmdDbGFzczogXCJiZy1zbGF0ZS0xMDBcIixcclxuICAgICAgICB0ZXh0Q2xhc3M6IFwidGV4dC1zbGF0ZS03MDBcIixcclxuICAgICAgICBib3JkZXJDbGFzczogXCJib3JkZXItc2xhdGUtMjAwXCIsXHJcbiAgICAgIH1cclxuICAgIDogbnVsbDtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwibWluLWgtc2NyZWVuIGJnLXNsYXRlLTUwIGRhcms6Ymctc2xhdGUtOTUwIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC1zbGF0ZS0xMDAgZmxleCBmbGV4LWNvbCBhbnRpYWxpYXNlZFwiPlxyXG4gICAgICB7LyogVG9wIEhlYWRlciAqL31cclxuICAgICAgPGhlYWRlciBjbGFzc05hbWU9XCJzdGlja3kgdG9wLTAgei00MCBiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTkwMCBib3JkZXItYiBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMFwiPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWF4LXctN3hsIG14LWF1dG8gcHgtNCBzbTpweC02IGxnOnB4LTggaC0xNiBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTRcIj5cclxuICAgICAgICAgIHsvKiBMYWRvIEVzcXVlcmRvOiBNb2JpbGUgSGFtYnVyZ2VyICsgSWRlbnRpZmljYcOnw6NvIGRhIEFwbGljYcOnw6NvICovfVxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxyXG4gICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0TW9iaWxlTWVudU9wZW4oIW1vYmlsZU1lbnVPcGVuKX1cclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtZDpoaWRkZW4gcC0yIHRleHQtc2xhdGUtNjAwIGRhcms6dGV4dC1zbGF0ZS0zMDAgaG92ZXI6dGV4dC1zbGF0ZS05MDAgZGFyazpob3Zlcjp0ZXh0LXdoaXRlIHJvdW5kZWQtbGcgaG92ZXI6Ymctc2xhdGUtMTAwIGRhcms6aG92ZXI6Ymctc2xhdGUtODAwIGZvY3VzLXZpc2libGU6b3V0bGluZS1ub25lIGZvY3VzLXZpc2libGU6cmluZy0yIGZvY3VzLXZpc2libGU6cmluZy10ZWFsLTYwMFwiXHJcbiAgICAgICAgICAgICAgYXJpYS1sYWJlbD1cIkFsdGVybmFyIG5hdmVnYcOnw6NvIGxhdGVyYWxcIlxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAge21vYmlsZU1lbnVPcGVuID8gKFxyXG4gICAgICAgICAgICAgICAgPFggY2xhc3NOYW1lPVwidy01IGgtNVwiIC8+XHJcbiAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgIDxNZW51IGNsYXNzTmFtZT1cInctNSBoLTVcIiAvPlxyXG4gICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgIDwvYnV0dG9uPlxyXG5cclxuICAgICAgICAgICAgPExpbmtcclxuICAgICAgICAgICAgICB0bz17Uk9VVEVTLkRBU0hCT0FSRH1cclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMi41IHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZSBncm91cCBmb2N1cy12aXNpYmxlOm91dGxpbmUtbm9uZVwiXHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctOSBoLTkgcm91bmRlZC1sZyBiZy10ZWFsLTYwMCB0ZXh0LXdoaXRlIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGZvbnQtYm9sZCBzaGFkb3cteHNcIj5cclxuICAgICAgICAgICAgICAgIDxTaGllbGQgY2xhc3NOYW1lPVwidy01IGgtNSB0ZXh0LXdoaXRlXCIgLz5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2xcIj5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LWJhc2UgbGVhZGluZy10aWdodCB0cmFja2luZy10aWdodFwiPlxyXG4gICAgICAgICAgICAgICAgICB7QVBQX0NPTkZJRy5ub21lfVxyXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1zbGF0ZS01MDAgZGFyazp0ZXh0LXNsYXRlLTQwMCBsZWFkaW5nLXRpZ2h0XCI+XHJcbiAgICAgICAgICAgICAgICAgIHtBUFBfQ09ORklHLm11bmljaXBpb30gLyB7QVBQX0NPTkZJRy51Zn1cclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgey8qIExhZG8gRGlyZWl0bzogU2Vydmlkb3IgTG9nYWRvLCBQZXJmaWwgZSBMb2dvdXQgKi99XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC00XCI+XHJcbiAgICAgICAgICAgIHt1c2VyICYmIChcclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImhpZGRlbiBzbTpmbGV4IGZsZXgtY29sIHRleHQtcmlnaHRcIj5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTgwMCBkYXJrOnRleHQtc2xhdGUtMjAwIHRydW5jYXRlIG1heC13LVsyMDBweF1cIj5cclxuICAgICAgICAgICAgICAgICAge3VzZXIubm9tZV9jb21wbGV0b31cclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtc2xhdGUtNTAwIGRhcms6dGV4dC1zbGF0ZS00MDAgdHJ1bmNhdGUgbWF4LXctWzIwMHB4XVwiPlxyXG4gICAgICAgICAgICAgICAgICB7dXNlci5jYXJnb31cclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgIHtwZXJmaWxNZXRhICYmIChcclxuICAgICAgICAgICAgICA8c3BhblxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgdGV4dC1bMTFweF0gZm9udC1tZWRpdW0gcHgtMiBweS0wLjUgcm91bmRlZC1tZCBib3JkZXIgJHtwZXJmaWxNZXRhLmJnQ2xhc3N9ICR7cGVyZmlsTWV0YS50ZXh0Q2xhc3N9ICR7cGVyZmlsTWV0YS5ib3JkZXJDbGFzc30gc2hyaW5rLTBgfVxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIHtwZXJmaWxNZXRhLmxhYmVsfVxyXG4gICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVMb2dvdXR9XHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgcHgtMyBweS0xLjUgdGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMjAwIGhvdmVyOnRleHQtcm9zZS02MDAgZGFyazpob3Zlcjp0ZXh0LXJvc2UtNDAwIGJnLXNsYXRlLTEwMCBkYXJrOmJnLXNsYXRlLTgwMCBob3ZlcjpiZy1yb3NlLTUwIGRhcms6aG92ZXI6Ymctcm9zZS05NTAvNDAgcm91bmRlZC1sZyB0cmFuc2l0aW9uLWNvbG9ycyBmb2N1cy12aXNpYmxlOm91dGxpbmUtbm9uZSBmb2N1cy12aXNpYmxlOnJpbmctMiBmb2N1cy12aXNpYmxlOnJpbmctcm9zZS01MDAgc2hyaW5rLTBcIlxyXG4gICAgICAgICAgICAgIHRpdGxlPVwiRW5jZXJyYXIgU2Vzc8Ojb1wiXHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICA8TG9nT3V0IGNsYXNzTmFtZT1cInctMy41IGgtMy41XCIgLz5cclxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJoaWRkZW4gbWQ6aW5saW5lXCI+U2Fpcjwvc3Bhbj5cclxuICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9oZWFkZXI+XHJcblxyXG4gICAgICB7LyogQ29ycG8gY29tIFNpZGViYXIgZSBDb250ZcO6ZG8gKi99XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xIG1heC13LTd4bCB3LWZ1bGwgbXgtYXV0byBweC00IHNtOnB4LTYgbGc6cHgtOCBweS02IGZsZXggZ2FwLTZcIj5cclxuICAgICAgICB7LyogU2lkZWJhciBEZXNrdG9wIEZpeGEgKi99XHJcbiAgICAgICAgPGFzaWRlIGNsYXNzTmFtZT1cImhpZGRlbiBtZDpibG9jayB3LTY0IHNocmluay0wXCI+XHJcbiAgICAgICAgICA8bmF2IGNsYXNzTmFtZT1cInN0aWNreSB0b3AtMjQgYmctd2hpdGUgZGFyazpiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtODAwIHJvdW5kZWQteGwgcC0zIHNoYWRvdy14cyBzcGFjZS15LTFcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweC0zIHB5LTIgdGV4dC1bMTFweF0gZm9udC1ib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LXNsYXRlLTQwMCBkYXJrOnRleHQtc2xhdGUtNTAwXCI+XHJcbiAgICAgICAgICAgICAgTcOzZHVsb3MgUmVndWxhdMOzcmlvc1xyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIHt2aXNpYmxlTWVudUl0ZW1zLm1hcCgoaXRlbSkgPT4ge1xyXG4gICAgICAgICAgICAgIGNvbnN0IEljb24gPSBpdGVtLmljb247XHJcbiAgICAgICAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgICAgICAgIDxOYXZMaW5rXHJcbiAgICAgICAgICAgICAgICAgIGtleT17aXRlbS5wYXRofVxyXG4gICAgICAgICAgICAgICAgICB0bz17aXRlbS5wYXRofVxyXG4gICAgICAgICAgICAgICAgICBlbmQ9e2l0ZW0ucGF0aCA9PT0gXCIvXCJ9XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17KHsgaXNBY3RpdmUgfSkgPT5cclxuICAgICAgICAgICAgICAgICAgICBgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHB4LTMgcHktMiB0ZXh0LXhzIGZvbnQtbWVkaXVtIHJvdW5kZWQtbGcgdHJhbnNpdGlvbi1jb2xvcnMgZ3JvdXAgJHtcclxuICAgICAgICAgICAgICAgICAgICAgIGlzQWN0aXZlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgID8gXCJiZy10ZWFsLTUwIGRhcms6YmctdGVhbC05NTAvNTAgdGV4dC10ZWFsLTgwMCBkYXJrOnRleHQtdGVhbC0zMDAgZm9udC1zZW1pYm9sZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDogXCJ0ZXh0LXNsYXRlLTYwMCBkYXJrOnRleHQtc2xhdGUtNDAwIGhvdmVyOnRleHQtc2xhdGUtOTAwIGRhcms6aG92ZXI6dGV4dC13aGl0ZSBob3ZlcjpiZy1zbGF0ZS0xMDAgZGFyazpob3ZlcjpiZy1zbGF0ZS04MDAvNjBcIlxyXG4gICAgICAgICAgICAgICAgICAgIH1gXHJcbiAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgeyh7IGlzQWN0aXZlIH0pID0+IChcclxuICAgICAgICAgICAgICAgICAgICA8PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMi41XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxJY29uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgdy00IGgtNCB0cmFuc2l0aW9uLWNvbG9ycyAke1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaXNBY3RpdmVcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBcInRleHQtdGVhbC02MDAgZGFyazp0ZXh0LXRlYWwtNDAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBcInRleHQtc2xhdGUtNDAwIGdyb3VwLWhvdmVyOnRleHQtc2xhdGUtNjAwIGRhcms6Z3JvdXAtaG92ZXI6dGV4dC1zbGF0ZS0zMDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIH1gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj57aXRlbS5sYWJlbH08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxDaGV2cm9uUmlnaHRcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgdy0zLjUgaC0zLjUgb3BhY2l0eS0wIGdyb3VwLWhvdmVyOm9wYWNpdHktMTAwIHRyYW5zaXRpb24tb3BhY2l0eSAke1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGlzQWN0aXZlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IFwib3BhY2l0eS0xMDAgdGV4dC10ZWFsLTYwMCBkYXJrOnRleHQtdGVhbC00MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBcInRleHQtc2xhdGUtMzAwIGRhcms6dGV4dC1zbGF0ZS02MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9YH1cclxuICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPC8+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICA8L05hdkxpbms+XHJcbiAgICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgfSl9XHJcbiAgICAgICAgICA8L25hdj5cclxuICAgICAgICA8L2FzaWRlPlxyXG5cclxuICAgICAgICB7LyogRHJhd2VyIE1vYmlsZSAqL31cclxuICAgICAgICB7bW9iaWxlTWVudU9wZW4gJiYgKFxyXG4gICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJtZDpoaWRkZW4gZml4ZWQgaW5zZXQtMCB6LTUwIGJnLXNsYXRlLTk1MC81MCBiYWNrZHJvcC1ibHVyLXhzIGZsZXhcIlxyXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRNb2JpbGVNZW51T3BlbihmYWxzZSl9XHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTcyIGJnLXdoaXRlIGRhcms6Ymctc2xhdGUtOTAwIGgtZnVsbCBwLTQgYm9yZGVyLXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgZmxleCBmbGV4LWNvbCBqdXN0aWZ5LWJldHdlZW5cIlxyXG4gICAgICAgICAgICAgIG9uQ2xpY2s9eyhlKSA9PiBlLnN0b3BQcm9wYWdhdGlvbigpfVxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTRcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHBiLTMgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDBcIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxTaGllbGQgY2xhc3NOYW1lPVwidy01IGgtNSB0ZXh0LXRlYWwtNjAwXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1zbVwiPntBUFBfQ09ORklHLm5vbWV9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldE1vYmlsZU1lbnVPcGVuKGZhbHNlKX1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTEgdGV4dC1zbGF0ZS01MDAgaG92ZXI6dGV4dC1zbGF0ZS04MDAgZGFyazpob3Zlcjp0ZXh0LXdoaXRlXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIDxYIGNsYXNzTmFtZT1cInctNSBoLTVcIiAvPlxyXG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0xXCI+XHJcbiAgICAgICAgICAgICAgICAgIHt2aXNpYmxlTWVudUl0ZW1zLm1hcCgoaXRlbSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IEljb24gPSBpdGVtLmljb247XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgICAgICAgICAgICAgIDxOYXZMaW5rXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGtleT17aXRlbS5wYXRofVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0bz17aXRlbS5wYXRofVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBlbmQ9e2l0ZW0ucGF0aCA9PT0gXCIvXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldE1vYmlsZU1lbnVPcGVuKGZhbHNlKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXsoeyBpc0FjdGl2ZSB9KSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyBweC0zIHB5LTIgdGV4dC14cyBmb250LW1lZGl1bSByb3VuZGVkLWxnIHRyYW5zaXRpb24tY29sb3JzICR7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpc0FjdGl2ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IFwiYmctdGVhbC01MCBkYXJrOmJnLXRlYWwtOTUwLzYwIHRleHQtdGVhbC03MDAgZGFyazp0ZXh0LXRlYWwtMzAwIGZvbnQtc2VtaWJvbGRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IFwidGV4dC1zbGF0ZS02MDAgZGFyazp0ZXh0LXNsYXRlLTMwMCBob3ZlcjpiZy1zbGF0ZS0xMDAgZGFyazpob3ZlcjpiZy1zbGF0ZS04MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIH1gXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPEljb24gY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LXNsYXRlLTUwMFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPntpdGVtLmxhYmVsfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvTmF2TGluaz5cclxuICAgICAgICAgICAgICAgICAgICApO1xyXG4gICAgICAgICAgICAgICAgICB9KX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB0LTQgYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDBcIj5cclxuICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZUxvZ291dH1cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0yIHB4LTMgcHktMiB0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtcm9zZS02MDAgZGFyazp0ZXh0LXJvc2UtNDAwIGJnLXJvc2UtNTAgZGFyazpiZy1yb3NlLTk1MC80MCByb3VuZGVkLWxnIGhvdmVyOmJnLXJvc2UtMTAwIHRyYW5zaXRpb24tY29sb3JzXCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgPExvZ091dCBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4+RW5jZXJyYXIgU2Vzc8Ojbzwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICl9XHJcblxyXG4gICAgICAgIHsvKiBWaWV3cG9ydCBQcmluY2lwYWwgZGUgQ29udGXDumRvICovfVxyXG4gICAgICAgIDxtYWluIGNsYXNzTmFtZT1cImZsZXgtMSBtaW4tdy0wXCI+XHJcbiAgICAgICAgICA8T3V0bGV0IC8+XHJcbiAgICAgICAgPC9tYWluPlxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIHsvKiBSb2RhcMOpIERpbsOibWljbyBkbyBTaXN0ZW1hICovfVxyXG4gICAgICA8Zm9vdGVyIGNsYXNzTmFtZT1cIm10LWF1dG8gYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgYmctd2hpdGUgZGFyazpiZy1zbGF0ZS05MDAgcHktNFwiPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWF4LXctN3hsIG14LWF1dG8gcHgtNCBzbTpweC02IGxnOnB4LTggdGV4dC1jZW50ZXIgdGV4dC14cyB0ZXh0LXNsYXRlLTUwMCBkYXJrOnRleHQtc2xhdGUtNDAwXCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAteC0yIGdhcC15LTFcIj5cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMzAwXCI+XHJcbiAgICAgICAgICAgICAge0FQUF9DT05GSUcubm9tZX0gdntBUFBfQ09ORklHLnZlcnNhb31cclxuICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICA8c3BhbiBhcmlhLWhpZGRlbj1cInRydWVcIj7Ctzwvc3Bhbj5cclxuICAgICAgICAgICAgPHNwYW4+XHJcbiAgICAgICAgICAgICAge0FQUF9DT05GSUcubXVuaWNpcGlvfS97QVBQX0NPTkZJRy51Zn1cclxuICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICA8c3BhbiBhcmlhLWhpZGRlbj1cInRydWVcIj7Ctzwvc3Bhbj5cclxuICAgICAgICAgICAgPHNwYW4+e0FQUF9DT05GSUcuc2VjcmV0YXJpYX08L3NwYW4+XHJcbiAgICAgICAgICAgIDxzcGFuIGFyaWEtaGlkZGVuPVwidHJ1ZVwiPsK3PC9zcGFuPlxyXG4gICAgICAgICAgICA8c3Bhbj57QVBQX0NPTkZJRy5vcmdhb308L3NwYW4+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTEgdGV4dC1bMTFweF0gdGV4dC1zbGF0ZS00MDAgZGFyazp0ZXh0LXNsYXRlLTUwMFwiPlxyXG4gICAgICAgICAgICDCqSB7bmV3IERhdGUoKS5nZXRGdWxsWWVhcigpfSB7QVBQX0NPTkZJRy5wcmVmZWl0dXJhfS4gVG9kb3Mgb3MgZGlyZWl0b3MgcmVzZXJ2YWRvcy5cclxuICAgICAgICAgIDwvcD5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9mb290ZXI+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgQXBwTGF5b3V0O1xyXG4iXX0=