import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/indicadores/GraficoDistribuicaoRisco.tsx");const React = __vite__cjsImport0_react; const useMemo = __vite__cjsImport0_react["useMemo"];const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];/**
* Gráfico de Rosca: Distribuição de Estabelecimentos por Classe de Risco Sanitário
* Utiliza Recharts (PieChart, ResponsiveContainer, Cell, Tooltip, Legend).
*/
import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=0fd2848a";
import { Cell, Legend, Pie, PieChart, ResponsiveContainer, Tooltip } from "/node_modules/.vite/deps/recharts.js?v=0fd2848a";
import { ShieldAlert } from "/node_modules/.vite/deps/lucide-react.js?v=0fd2848a";
var _jsxFileName = "E:/Projetos VSCODE/visa_braunas/src/components/indicadores/GraficoDistribuicaoRisco.tsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=0fd2848a";
var _s = $RefreshSig$();
const PALETA_RISCO = {
	risco_3: {
		nome: "Risco III (Alto)",
		cor: "#8b5cf6",
		descricao: "Vistoria prévia mandatória e controle rigoroso"
	},
	"Risco III": {
		nome: "Risco III (Alto)",
		cor: "#8b5cf6",
		descricao: "Vistoria prévia mandatória e controle rigoroso"
	},
	risco_2: {
		nome: "Risco II (Médio)",
		cor: "#f59e0b",
		descricao: "Vistoria a posteriori ou por amostragem"
	},
	"Risco II": {
		nome: "Risco II (Médio)",
		cor: "#f59e0b",
		descricao: "Vistoria a posteriori ou por amostragem"
	},
	risco_1: {
		nome: "Risco I (Baixo)",
		cor: "#0ea5e9",
		descricao: "Dispensado de alvará prévio / autodeclaração"
	},
	"Risco I": {
		nome: "Risco I (Baixo)",
		cor: "#0ea5e9",
		descricao: "Dispensado de alvará prévio / autodeclaração"
	},
	dispensado: {
		nome: "Dispensado",
		cor: "#64748b",
		descricao: "Atividades sem impacto sanitário direto"
	},
	Dispensado: {
		nome: "Dispensado",
		cor: "#64748b",
		descricao: "Atividades sem impacto sanitário direto"
	}
};
export const GraficoDistribuicaoRisco = ({ distribuicao = {}, totalCadastrados }) => {
	_s();
	const dados = useMemo(() => {
		const itens = [];
		// Mapeamento normalizado
		const r3 = distribuicao["risco_3"] ?? distribuicao["Risco III"] ?? 0;
		const r2 = distribuicao["risco_2"] ?? distribuicao["Risco II"] ?? 0;
		const r1 = distribuicao["risco_1"] ?? distribuicao["Risco I"] ?? 0;
		const disp = distribuicao["dispensado"] ?? distribuicao["Dispensado"] ?? 0;
		if (r3 > 0) {
			itens.push({
				name: "Risco III (Alto)",
				valor: r3,
				cor: "#8b5cf6",
				descricao: "Alto Risco Sanitário"
			});
		}
		if (r2 > 0) {
			itens.push({
				name: "Risco II (Médio)",
				valor: r2,
				cor: "#f59e0b",
				descricao: "Médio Risco Sanitário"
			});
		}
		if (r1 > 0) {
			itens.push({
				name: "Risco I (Baixo)",
				valor: r1,
				cor: "#0ea5e9",
				descricao: "Baixo Risco Sanitário"
			});
		}
		if (disp > 0) {
			itens.push({
				name: "Dispensados",
				valor: disp,
				cor: "#64748b",
				descricao: "Atividades Dispensadas"
			});
		}
		// Se vazio, mock amigável representativo do município para visualização
		if (itens.length === 0) {
			return [
				{
					name: "Risco III (Alto)",
					valor: 28,
					cor: "#8b5cf6",
					descricao: "Alto Risco"
				},
				{
					name: "Risco II (Médio)",
					valor: 64,
					cor: "#f59e0b",
					descricao: "Médio Risco"
				},
				{
					name: "Risco I (Baixo)",
					valor: 112,
					cor: "#0ea5e9",
					descricao: "Baixo Risco"
				},
				{
					name: "Dispensados",
					valor: 35,
					cor: "#64748b",
					descricao: "Dispensados"
				}
			];
		}
		return itens;
	}, [distribuicao]);
	const totalCalculado = useMemo(() => {
		return totalCadastrados ?? dados.reduce((acc, curr) => acc + curr.valor, 0);
	}, [dados, totalCadastrados]);
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 shadow-xs flex flex-col justify-between",
		children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", {
			className: "flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800 mb-4",
			children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h2", {
				className: "text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2",
				children: [/* @__PURE__ */ _jsxDEV(ShieldAlert, { className: "w-4 h-4 text-purple-600" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 141,
					columnNumber: 15
				}, this), "Estratificação Sanitária por Grau de Risco"]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 140,
				columnNumber: 13
			}, this), /* @__PURE__ */ _jsxDEV("p", {
				className: "text-xs text-slate-500 dark:text-slate-400 mt-0.5",
				children: "Distribuição de empresas ativas de acordo com a RDC ANVISA nº 153/2017"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 144,
				columnNumber: 13
			}, this)] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 139,
				columnNumber: 11
			}, this), /* @__PURE__ */ _jsxDEV("span", {
				className: "text-xs font-semibold px-2.5 py-1 rounded bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300",
				children: ["Total: ", totalCalculado]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 148,
				columnNumber: 11
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 138,
			columnNumber: 9
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "h-64 w-full relative",
			children: [/* @__PURE__ */ _jsxDEV(ResponsiveContainer, {
				width: "100%",
				height: "100%",
				children: /* @__PURE__ */ _jsxDEV(PieChart, { children: [
					/* @__PURE__ */ _jsxDEV(Pie, {
						data: dados,
						dataKey: "valor",
						nameKey: "name",
						cx: "50%",
						cy: "50%",
						innerRadius: 62,
						outerRadius: 92,
						paddingAngle: 4,
						children: dados.map((entry, index) => /* @__PURE__ */ _jsxDEV(Cell, {
							fill: entry.cor,
							stroke: "transparent"
						}, `cell-${index}`, false, {
							fileName: _jsxFileName,
							lineNumber: 168,
							columnNumber: 19
						}, this))
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 157,
						columnNumber: 15
					}, this),
					/* @__PURE__ */ _jsxDEV(Tooltip, { content: ({ active, payload }) => {
						if (active && payload && payload.length) {
							const data = payload[0].payload;
							const pct = totalCalculado > 0 ? (data.valor / totalCalculado * 100).toFixed(1) : "0";
							return /* @__PURE__ */ _jsxDEV("div", {
								className: "bg-white dark:bg-slate-800 p-3 rounded-lg shadow-lg border border-slate-200 dark:border-slate-700 text-xs",
								children: [
									/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center gap-2 font-bold text-slate-900 dark:text-white mb-1",
										children: [/* @__PURE__ */ _jsxDEV("span", {
											className: "w-2.5 h-2.5 rounded-full inline-block",
											style: { backgroundColor: data.cor }
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 179,
											columnNumber: 27
										}, this), /* @__PURE__ */ _jsxDEV("span", { children: data.name }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 183,
											columnNumber: 27
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 178,
										columnNumber: 25
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "text-slate-600 dark:text-slate-300",
										children: ["Quantidade: ", /* @__PURE__ */ _jsxDEV("strong", {
											className: "text-slate-900 dark:text-white",
											children: [data.valor, " empresas"]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 186,
											columnNumber: 39
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 185,
										columnNumber: 25
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "text-slate-500 dark:text-slate-400",
										children: ["Participação: ", /* @__PURE__ */ _jsxDEV("strong", {
											className: "text-teal-600 dark:text-teal-400",
											children: [pct, "% do cadastro"]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 189,
											columnNumber: 41
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 188,
										columnNumber: 25
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 177,
								columnNumber: 23
							}, this);
						}
						return null;
					} }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 171,
						columnNumber: 15
					}, this),
					/* @__PURE__ */ _jsxDEV(Legend, {
						verticalAlign: "bottom",
						height: 36,
						formatter: (value, entry) => {
							const item = dados.find((d) => d.name === value);
							const pct = totalCalculado > 0 && item ? (item.valor / totalCalculado * 100).toFixed(0) : "0";
							return /* @__PURE__ */ _jsxDEV("span", {
								className: "text-xs text-slate-700 dark:text-slate-300 font-medium",
								children: [
									value,
									" (",
									pct,
									"%)"
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 204,
								columnNumber: 21
							}, this);
						}
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 197,
						columnNumber: 15
					}, this)
				] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 156,
					columnNumber: 13
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 155,
				columnNumber: 11
			}, this), /* @__PURE__ */ _jsxDEV("div", {
				className: "absolute inset-0 flex flex-col items-center justify-center pointer-events-none pb-9",
				children: [/* @__PURE__ */ _jsxDEV("span", {
					className: "text-2xl font-extrabold text-slate-900 dark:text-white tabular-nums",
					children: totalCalculado
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 215,
					columnNumber: 13
				}, this), /* @__PURE__ */ _jsxDEV("span", {
					className: "text-[10px] uppercase font-bold tracking-wider text-slate-400",
					children: "Empresas"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 218,
					columnNumber: 13
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 214,
				columnNumber: 11
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 154,
			columnNumber: 9
		}, this)] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 137,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "grid grid-cols-2 sm:grid-cols-4 gap-2 pt-3 border-t border-slate-100 dark:border-slate-800 mt-2",
			children: dados.map((item) => /* @__PURE__ */ _jsxDEV("div", {
				className: "p-2 rounded bg-slate-50 dark:bg-slate-800/40 text-center",
				children: [/* @__PURE__ */ _jsxDEV("span", {
					className: "text-[11px] font-semibold text-slate-600 dark:text-slate-400 block truncate",
					children: [
						item.name.split(" ")[0],
						" ",
						item.name.split(" ")[1] || ""
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 232,
					columnNumber: 13
				}, this), /* @__PURE__ */ _jsxDEV("span", {
					className: "text-sm font-bold tabular-nums block",
					style: { color: item.cor },
					children: item.valor
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 235,
					columnNumber: 13
				}, this)]
			}, item.name, true, {
				fileName: _jsxFileName,
				lineNumber: 228,
				columnNumber: 11
			}, this))
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 226,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 136,
		columnNumber: 5
	}, this);
};
_s(GraficoDistribuicaoRisco, "yCj8Mt5Z2+9IXpm69qSCy2bt1vA=");
_c = GraficoDistribuicaoRisco;
export default GraficoDistribuicaoRisco;
var _c;
$RefreshReg$(_c, "GraficoDistribuicaoRisco");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/indicadores/GraficoDistribuicaoRisco.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("E:/Projetos VSCODE/visa_braunas/src/components/indicadores/GraficoDistribuicaoRisco.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("E:/Projetos VSCODE/visa_braunas/src/components/indicadores/GraficoDistribuicaoRisco.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "E:/Projetos VSCODE/visa_braunas/src/components/indicadores/GraficoDistribuicaoRisco.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7OztBQUtBLE9BQU8sU0FBUyxlQUFlO0FBQy9CLFNBQ0UsTUFDQSxRQUNBLEtBQ0EsVUFDQSxxQkFDQSxlQUNLO0FBQ1AsU0FBUyxtQkFBbUI7Ozs7QUFjNUIsTUFBTSxlQUFpRjtDQUNyRixTQUFTO0VBQ1AsTUFBTTtFQUNOLEtBQUs7RUFDTCxXQUFXO0NBQ2I7Q0FDQSxhQUFhO0VBQ1gsTUFBTTtFQUNOLEtBQUs7RUFDTCxXQUFXO0NBQ2I7Q0FDQSxTQUFTO0VBQ1AsTUFBTTtFQUNOLEtBQUs7RUFDTCxXQUFXO0NBQ2I7Q0FDQSxZQUFZO0VBQ1YsTUFBTTtFQUNOLEtBQUs7RUFDTCxXQUFXO0NBQ2I7Q0FDQSxTQUFTO0VBQ1AsTUFBTTtFQUNOLEtBQUs7RUFDTCxXQUFXO0NBQ2I7Q0FDQSxXQUFXO0VBQ1QsTUFBTTtFQUNOLEtBQUs7RUFDTCxXQUFXO0NBQ2I7Q0FDQSxZQUFZO0VBQ1YsTUFBTTtFQUNOLEtBQUs7RUFDTCxXQUFXO0NBQ2I7Q0FDQSxZQUFZO0VBQ1YsTUFBTTtFQUNOLEtBQUs7RUFDTCxXQUFXO0NBQ2I7QUFDRjtBQUVBLE9BQU8sTUFBTSw0QkFBcUUsRUFDaEYsZUFBZSxDQUFDLEdBQ2hCLHVCQUNJOztDQUNKLE1BQU0sUUFBUSxjQUE2QjtFQUN6QyxNQUFNLFFBQXVCLENBQUM7O0VBRzlCLE1BQU0sS0FBSyxhQUFhLGNBQWMsYUFBYSxnQkFBZ0I7RUFDbkUsTUFBTSxLQUFLLGFBQWEsY0FBYyxhQUFhLGVBQWU7RUFDbEUsTUFBTSxLQUFLLGFBQWEsY0FBYyxhQUFhLGNBQWM7RUFDakUsTUFBTSxPQUFPLGFBQWEsaUJBQWlCLGFBQWEsaUJBQWlCO0VBRXpFLElBQUksS0FBSyxHQUFHO0dBQ1YsTUFBTSxLQUFLO0lBQ1QsTUFBTTtJQUNOLE9BQU87SUFDUCxLQUFLO0lBQ0wsV0FBVztHQUNiLENBQUM7RUFDSDtFQUNBLElBQUksS0FBSyxHQUFHO0dBQ1YsTUFBTSxLQUFLO0lBQ1QsTUFBTTtJQUNOLE9BQU87SUFDUCxLQUFLO0lBQ0wsV0FBVztHQUNiLENBQUM7RUFDSDtFQUNBLElBQUksS0FBSyxHQUFHO0dBQ1YsTUFBTSxLQUFLO0lBQ1QsTUFBTTtJQUNOLE9BQU87SUFDUCxLQUFLO0lBQ0wsV0FBVztHQUNiLENBQUM7RUFDSDtFQUNBLElBQUksT0FBTyxHQUFHO0dBQ1osTUFBTSxLQUFLO0lBQ1QsTUFBTTtJQUNOLE9BQU87SUFDUCxLQUFLO0lBQ0wsV0FBVztHQUNiLENBQUM7RUFDSDs7RUFHQSxJQUFJLE1BQU0sV0FBVyxHQUFHO0dBQ3RCLE9BQU87SUFDTDtLQUFFLE1BQU07S0FBb0IsT0FBTztLQUFJLEtBQUs7S0FBVyxXQUFXO0lBQWE7SUFDL0U7S0FBRSxNQUFNO0tBQW9CLE9BQU87S0FBSSxLQUFLO0tBQVcsV0FBVztJQUFjO0lBQ2hGO0tBQUUsTUFBTTtLQUFtQixPQUFPO0tBQUssS0FBSztLQUFXLFdBQVc7SUFBYztJQUNoRjtLQUFFLE1BQU07S0FBZSxPQUFPO0tBQUksS0FBSztLQUFXLFdBQVc7SUFBYztHQUM3RTtFQUNGO0VBRUEsT0FBTztDQUNULEdBQUcsQ0FBQyxZQUFZLENBQUM7Q0FFakIsTUFBTSxpQkFBaUIsY0FBYztFQUNuQyxPQUFPLG9CQUFvQixNQUFNLFFBQVEsS0FBSyxTQUFTLE1BQU0sS0FBSyxPQUFPLENBQUM7Q0FDNUUsR0FBRyxDQUFDLE9BQU8sZ0JBQWdCLENBQUM7Q0FFNUIsT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUFmLENBQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWYsQ0FDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsTUFBRDtJQUFJLFdBQVU7Y0FBZCxDQUNFLHdCQUFDLGFBQUQsRUFBYSxXQUFVLDBCQUEyQjs7OztjQUFDLDRDQUVqRDs7Ozs7YUFDSix3QkFBQyxLQUFEO0lBQUcsV0FBVTtjQUFvRDtHQUU5RDs7OztXQUNBOzs7O2FBQ0wsd0JBQUMsUUFBRDtJQUFNLFdBQVU7Y0FBaEIsQ0FBOEgsV0FDcEgsY0FDSjs7Ozs7V0FDSDs7Ozs7WUFHTCx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmLENBQ0Usd0JBQUMscUJBQUQ7SUFBcUIsT0FBTTtJQUFPLFFBQU87Y0FDdkMsd0JBQUMsVUFBRDtLQUNFLHdCQUFDLEtBQUQ7TUFDRSxNQUFNO01BQ04sU0FBUTtNQUNSLFNBQVE7TUFDUixJQUFHO01BQ0gsSUFBRztNQUNILGFBQWE7TUFDYixhQUFhO01BQ2IsY0FBYztnQkFFYixNQUFNLEtBQUssT0FBTyxVQUNqQix3QkFBQyxNQUFEO09BQTRCLE1BQU0sTUFBTTtPQUFLLFFBQU87TUFBZSxHQUF4RCxRQUFROzs7O2FBQWdELENBQ3BFO0tBQ0U7Ozs7O0tBQ0wsd0JBQUMsU0FBRCxFQUNFLFVBQVUsRUFBRSxRQUFRLGNBQWM7TUFDaEMsSUFBSSxVQUFVLFdBQVcsUUFBUSxRQUFRO09BQ3ZDLE1BQU0sT0FBTyxRQUFRLEVBQUUsQ0FBQztPQUN4QixNQUFNLE1BQU0saUJBQWlCLEtBQU0sS0FBSyxRQUFRLGlCQUFrQixJQUFHLENBQUUsUUFBUSxDQUFDLElBQUk7T0FDcEYsT0FDRSx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZjtTQUNFLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmLENBQ0Usd0JBQUMsUUFBRDtXQUNFLFdBQVU7V0FDVixPQUFPLEVBQUUsaUJBQWlCLEtBQUssSUFBSTtVQUNwQzs7OztvQkFDRCx3QkFBQyxRQUFELFlBQU8sS0FBSyxLQUFXOzs7O2tCQUNwQjs7Ozs7O1NBQ0wsd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FBb0QsZ0JBQ3RDLHdCQUFDLFVBQUQ7V0FBUSxXQUFVO3FCQUFsQixDQUFvRCxLQUFLLE9BQU0sV0FBaUI7Ozs7O2tCQUN6Rjs7Ozs7O1NBQ0wsd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FBb0Qsa0JBQ3BDLHdCQUFDLFVBQUQ7V0FBUSxXQUFVO3FCQUFsQixDQUFzRCxLQUFJLGVBQXFCOzs7OztrQkFDMUY7Ozs7OztRQUNGOzs7Ozs7TUFFVDtNQUNBLE9BQU87S0FDVCxFQUNEOzs7OztLQUNELHdCQUFDLFFBQUQ7TUFDRSxlQUFjO01BQ2QsUUFBUTtNQUNSLFlBQVksT0FBTyxVQUFVO09BQzNCLE1BQU0sT0FBTyxNQUFNLE1BQU0sTUFBTSxFQUFFLFNBQVMsS0FBSztPQUMvQyxNQUFNLE1BQU0saUJBQWlCLEtBQUssUUFBUyxLQUFLLFFBQVEsaUJBQWtCLElBQUcsQ0FBRSxRQUFRLENBQUMsSUFBSTtPQUM1RixPQUNFLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUFoQjtTQUNHO1NBQU07U0FBRztTQUFJO1FBQ1Y7Ozs7OztNQUVWO0tBQ0Q7Ozs7O0lBQ087Ozs7O0dBQ1M7Ozs7YUFHckIsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLFFBQUQ7S0FBTSxXQUFVO2VBQ2I7SUFDRzs7OztjQUNOLHdCQUFDLFFBQUQ7S0FBTSxXQUFVO2VBQWdFO0lBRTFFOzs7O1lBQ0g7Ozs7O1dBQ0Y7Ozs7O1VBQ0Y7Ozs7WUFHTCx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUNaLE1BQU0sS0FBSyxTQUNWLHdCQUFDLE9BQUQ7SUFFRSxXQUFVO2NBRlosQ0FJRSx3QkFBQyxRQUFEO0tBQU0sV0FBVTtlQUFoQjtNQUNHLEtBQUssS0FBSyxNQUFNLEdBQUcsQ0FBQyxDQUFDO01BQUc7TUFBRSxLQUFLLEtBQUssTUFBTSxHQUFHLENBQUMsQ0FBQyxNQUFNO0tBQ2xEOzs7OztjQUNOLHdCQUFDLFFBQUQ7S0FDRSxXQUFVO0tBQ1YsT0FBTyxFQUFFLE9BQU8sS0FBSyxJQUFJO2VBRXhCLEtBQUs7SUFDRjs7OztZQUNIO01BWkUsS0FBSzs7OztVQVlQLENBQ047RUFDRTs7OztVQUNGOzs7Ozs7QUFFVDs7O0FBRUEsZUFBZSIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJHcmFmaWNvRGlzdHJpYnVpY2FvUmlzY28udHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbIi8qKlxyXG4gKiBHcsOhZmljbyBkZSBSb3NjYTogRGlzdHJpYnVpw6fDo28gZGUgRXN0YWJlbGVjaW1lbnRvcyBwb3IgQ2xhc3NlIGRlIFJpc2NvIFNhbml0w6FyaW9cclxuICogVXRpbGl6YSBSZWNoYXJ0cyAoUGllQ2hhcnQsIFJlc3BvbnNpdmVDb250YWluZXIsIENlbGwsIFRvb2x0aXAsIExlZ2VuZCkuXHJcbiAqL1xyXG5cclxuaW1wb3J0IFJlYWN0LCB7IHVzZU1lbW8gfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHtcclxuICBDZWxsLFxyXG4gIExlZ2VuZCxcclxuICBQaWUsXHJcbiAgUGllQ2hhcnQsXHJcbiAgUmVzcG9uc2l2ZUNvbnRhaW5lcixcclxuICBUb29sdGlwLFxyXG59IGZyb20gXCJyZWNoYXJ0c1wiO1xyXG5pbXBvcnQgeyBTaGllbGRBbGVydCB9IGZyb20gXCJsdWNpZGUtcmVhY3RcIjtcclxuXHJcbmludGVyZmFjZSBHcmFmaWNvRGlzdHJpYnVpY2FvUmlzY29Qcm9wcyB7XHJcbiAgZGlzdHJpYnVpY2FvPzogUmVjb3JkPHN0cmluZywgbnVtYmVyPjtcclxuICB0b3RhbENhZGFzdHJhZG9zPzogbnVtYmVyO1xyXG59XHJcblxyXG5pbnRlcmZhY2UgSXRlbUdyYWZpY28ge1xyXG4gIG5hbWU6IHN0cmluZztcclxuICB2YWxvcjogbnVtYmVyO1xyXG4gIGNvcjogc3RyaW5nO1xyXG4gIGRlc2NyaWNhbzogc3RyaW5nO1xyXG59XHJcblxyXG5jb25zdCBQQUxFVEFfUklTQ086IFJlY29yZDxzdHJpbmcsIHsgbm9tZTogc3RyaW5nOyBjb3I6IHN0cmluZzsgZGVzY3JpY2FvOiBzdHJpbmcgfT4gPSB7XHJcbiAgcmlzY29fMzoge1xyXG4gICAgbm9tZTogXCJSaXNjbyBJSUkgKEFsdG8pXCIsXHJcbiAgICBjb3I6IFwiIzhiNWNmNlwiLCAvLyBQdXJwbGVcclxuICAgIGRlc2NyaWNhbzogXCJWaXN0b3JpYSBwcsOpdmlhIG1hbmRhdMOzcmlhIGUgY29udHJvbGUgcmlnb3Jvc29cIixcclxuICB9LFxyXG4gIFwiUmlzY28gSUlJXCI6IHtcclxuICAgIG5vbWU6IFwiUmlzY28gSUlJIChBbHRvKVwiLFxyXG4gICAgY29yOiBcIiM4YjVjZjZcIixcclxuICAgIGRlc2NyaWNhbzogXCJWaXN0b3JpYSBwcsOpdmlhIG1hbmRhdMOzcmlhIGUgY29udHJvbGUgcmlnb3Jvc29cIixcclxuICB9LFxyXG4gIHJpc2NvXzI6IHtcclxuICAgIG5vbWU6IFwiUmlzY28gSUkgKE3DqWRpbylcIixcclxuICAgIGNvcjogXCIjZjU5ZTBiXCIsIC8vIEFtYmVyXHJcbiAgICBkZXNjcmljYW86IFwiVmlzdG9yaWEgYSBwb3N0ZXJpb3JpIG91IHBvciBhbW9zdHJhZ2VtXCIsXHJcbiAgfSxcclxuICBcIlJpc2NvIElJXCI6IHtcclxuICAgIG5vbWU6IFwiUmlzY28gSUkgKE3DqWRpbylcIixcclxuICAgIGNvcjogXCIjZjU5ZTBiXCIsXHJcbiAgICBkZXNjcmljYW86IFwiVmlzdG9yaWEgYSBwb3N0ZXJpb3JpIG91IHBvciBhbW9zdHJhZ2VtXCIsXHJcbiAgfSxcclxuICByaXNjb18xOiB7XHJcbiAgICBub21lOiBcIlJpc2NvIEkgKEJhaXhvKVwiLFxyXG4gICAgY29yOiBcIiMwZWE1ZTlcIiwgLy8gU2t5IEJsdWVcclxuICAgIGRlc2NyaWNhbzogXCJEaXNwZW5zYWRvIGRlIGFsdmFyw6EgcHLDqXZpbyAvIGF1dG9kZWNsYXJhw6fDo29cIixcclxuICB9LFxyXG4gIFwiUmlzY28gSVwiOiB7XHJcbiAgICBub21lOiBcIlJpc2NvIEkgKEJhaXhvKVwiLFxyXG4gICAgY29yOiBcIiMwZWE1ZTlcIixcclxuICAgIGRlc2NyaWNhbzogXCJEaXNwZW5zYWRvIGRlIGFsdmFyw6EgcHLDqXZpbyAvIGF1dG9kZWNsYXJhw6fDo29cIixcclxuICB9LFxyXG4gIGRpc3BlbnNhZG86IHtcclxuICAgIG5vbWU6IFwiRGlzcGVuc2Fkb1wiLFxyXG4gICAgY29yOiBcIiM2NDc0OGJcIiwgLy8gU2xhdGVcclxuICAgIGRlc2NyaWNhbzogXCJBdGl2aWRhZGVzIHNlbSBpbXBhY3RvIHNhbml0w6FyaW8gZGlyZXRvXCIsXHJcbiAgfSxcclxuICBEaXNwZW5zYWRvOiB7XHJcbiAgICBub21lOiBcIkRpc3BlbnNhZG9cIixcclxuICAgIGNvcjogXCIjNjQ3NDhiXCIsXHJcbiAgICBkZXNjcmljYW86IFwiQXRpdmlkYWRlcyBzZW0gaW1wYWN0byBzYW5pdMOhcmlvIGRpcmV0b1wiLFxyXG4gIH0sXHJcbn07XHJcblxyXG5leHBvcnQgY29uc3QgR3JhZmljb0Rpc3RyaWJ1aWNhb1Jpc2NvOiBSZWFjdC5GQzxHcmFmaWNvRGlzdHJpYnVpY2FvUmlzY29Qcm9wcz4gPSAoe1xyXG4gIGRpc3RyaWJ1aWNhbyA9IHt9LFxyXG4gIHRvdGFsQ2FkYXN0cmFkb3MsXHJcbn0pID0+IHtcclxuICBjb25zdCBkYWRvcyA9IHVzZU1lbW88SXRlbUdyYWZpY29bXT4oKCkgPT4ge1xyXG4gICAgY29uc3QgaXRlbnM6IEl0ZW1HcmFmaWNvW10gPSBbXTtcclxuXHJcbiAgICAvLyBNYXBlYW1lbnRvIG5vcm1hbGl6YWRvXHJcbiAgICBjb25zdCByMyA9IGRpc3RyaWJ1aWNhb1tcInJpc2NvXzNcIl0gPz8gZGlzdHJpYnVpY2FvW1wiUmlzY28gSUlJXCJdID8/IDA7XHJcbiAgICBjb25zdCByMiA9IGRpc3RyaWJ1aWNhb1tcInJpc2NvXzJcIl0gPz8gZGlzdHJpYnVpY2FvW1wiUmlzY28gSUlcIl0gPz8gMDtcclxuICAgIGNvbnN0IHIxID0gZGlzdHJpYnVpY2FvW1wicmlzY29fMVwiXSA/PyBkaXN0cmlidWljYW9bXCJSaXNjbyBJXCJdID8/IDA7XHJcbiAgICBjb25zdCBkaXNwID0gZGlzdHJpYnVpY2FvW1wiZGlzcGVuc2Fkb1wiXSA/PyBkaXN0cmlidWljYW9bXCJEaXNwZW5zYWRvXCJdID8/IDA7XHJcblxyXG4gICAgaWYgKHIzID4gMCkge1xyXG4gICAgICBpdGVucy5wdXNoKHtcclxuICAgICAgICBuYW1lOiBcIlJpc2NvIElJSSAoQWx0bylcIixcclxuICAgICAgICB2YWxvcjogcjMsXHJcbiAgICAgICAgY29yOiBcIiM4YjVjZjZcIixcclxuICAgICAgICBkZXNjcmljYW86IFwiQWx0byBSaXNjbyBTYW5pdMOhcmlvXCIsXHJcbiAgICAgIH0pO1xyXG4gICAgfVxyXG4gICAgaWYgKHIyID4gMCkge1xyXG4gICAgICBpdGVucy5wdXNoKHtcclxuICAgICAgICBuYW1lOiBcIlJpc2NvIElJIChNw6lkaW8pXCIsXHJcbiAgICAgICAgdmFsb3I6IHIyLFxyXG4gICAgICAgIGNvcjogXCIjZjU5ZTBiXCIsXHJcbiAgICAgICAgZGVzY3JpY2FvOiBcIk3DqWRpbyBSaXNjbyBTYW5pdMOhcmlvXCIsXHJcbiAgICAgIH0pO1xyXG4gICAgfVxyXG4gICAgaWYgKHIxID4gMCkge1xyXG4gICAgICBpdGVucy5wdXNoKHtcclxuICAgICAgICBuYW1lOiBcIlJpc2NvIEkgKEJhaXhvKVwiLFxyXG4gICAgICAgIHZhbG9yOiByMSxcclxuICAgICAgICBjb3I6IFwiIzBlYTVlOVwiLFxyXG4gICAgICAgIGRlc2NyaWNhbzogXCJCYWl4byBSaXNjbyBTYW5pdMOhcmlvXCIsXHJcbiAgICAgIH0pO1xyXG4gICAgfVxyXG4gICAgaWYgKGRpc3AgPiAwKSB7XHJcbiAgICAgIGl0ZW5zLnB1c2goe1xyXG4gICAgICAgIG5hbWU6IFwiRGlzcGVuc2Fkb3NcIixcclxuICAgICAgICB2YWxvcjogZGlzcCxcclxuICAgICAgICBjb3I6IFwiIzY0NzQ4YlwiLFxyXG4gICAgICAgIGRlc2NyaWNhbzogXCJBdGl2aWRhZGVzIERpc3BlbnNhZGFzXCIsXHJcbiAgICAgIH0pO1xyXG4gICAgfVxyXG5cclxuICAgIC8vIFNlIHZhemlvLCBtb2NrIGFtaWfDoXZlbCByZXByZXNlbnRhdGl2byBkbyBtdW5pY8OtcGlvIHBhcmEgdmlzdWFsaXphw6fDo29cclxuICAgIGlmIChpdGVucy5sZW5ndGggPT09IDApIHtcclxuICAgICAgcmV0dXJuIFtcclxuICAgICAgICB7IG5hbWU6IFwiUmlzY28gSUlJIChBbHRvKVwiLCB2YWxvcjogMjgsIGNvcjogXCIjOGI1Y2Y2XCIsIGRlc2NyaWNhbzogXCJBbHRvIFJpc2NvXCIgfSxcclxuICAgICAgICB7IG5hbWU6IFwiUmlzY28gSUkgKE3DqWRpbylcIiwgdmFsb3I6IDY0LCBjb3I6IFwiI2Y1OWUwYlwiLCBkZXNjcmljYW86IFwiTcOpZGlvIFJpc2NvXCIgfSxcclxuICAgICAgICB7IG5hbWU6IFwiUmlzY28gSSAoQmFpeG8pXCIsIHZhbG9yOiAxMTIsIGNvcjogXCIjMGVhNWU5XCIsIGRlc2NyaWNhbzogXCJCYWl4byBSaXNjb1wiIH0sXHJcbiAgICAgICAgeyBuYW1lOiBcIkRpc3BlbnNhZG9zXCIsIHZhbG9yOiAzNSwgY29yOiBcIiM2NDc0OGJcIiwgZGVzY3JpY2FvOiBcIkRpc3BlbnNhZG9zXCIgfSxcclxuICAgICAgXTtcclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4gaXRlbnM7XHJcbiAgfSwgW2Rpc3RyaWJ1aWNhb10pO1xyXG5cclxuICBjb25zdCB0b3RhbENhbGN1bGFkbyA9IHVzZU1lbW8oKCkgPT4ge1xyXG4gICAgcmV0dXJuIHRvdGFsQ2FkYXN0cmFkb3MgPz8gZGFkb3MucmVkdWNlKChhY2MsIGN1cnIpID0+IGFjYyArIGN1cnIudmFsb3IsIDApO1xyXG4gIH0sIFtkYWRvcywgdG90YWxDYWRhc3RyYWRvc10pO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC14bCBwLTYgc2hhZG93LXhzIGZsZXggZmxleC1jb2wganVzdGlmeS1iZXR3ZWVuXCI+XHJcbiAgICAgIDxkaXY+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gcGItMyBib3JkZXItYiBib3JkZXItc2xhdGUtMTAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCBtYi00XCI+XHJcbiAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LWJvbGQgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgPFNoaWVsZEFsZXJ0IGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1wdXJwbGUtNjAwXCIgLz5cclxuICAgICAgICAgICAgICBFc3RyYXRpZmljYcOnw6NvIFNhbml0w6FyaWEgcG9yIEdyYXUgZGUgUmlzY29cclxuICAgICAgICAgICAgPC9oMj5cclxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTUwMCBkYXJrOnRleHQtc2xhdGUtNDAwIG10LTAuNVwiPlxyXG4gICAgICAgICAgICAgIERpc3RyaWJ1acOnw6NvIGRlIGVtcHJlc2FzIGF0aXZhcyBkZSBhY29yZG8gY29tIGEgUkRDIEFOVklTQSBuwrogMTUzLzIwMTdcclxuICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgcHgtMi41IHB5LTEgcm91bmRlZCBiZy1zbGF0ZS0xMDAgZGFyazpiZy1zbGF0ZS04MDAgdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTMwMFwiPlxyXG4gICAgICAgICAgICBUb3RhbDoge3RvdGFsQ2FsY3VsYWRvfVxyXG4gICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICB7LyogQ29udGFpbmVyIGRvIEdyw6FmaWNvIGRlIFJvc2NhICovfVxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaC02NCB3LWZ1bGwgcmVsYXRpdmVcIj5cclxuICAgICAgICAgIDxSZXNwb25zaXZlQ29udGFpbmVyIHdpZHRoPVwiMTAwJVwiIGhlaWdodD1cIjEwMCVcIj5cclxuICAgICAgICAgICAgPFBpZUNoYXJ0PlxyXG4gICAgICAgICAgICAgIDxQaWVcclxuICAgICAgICAgICAgICAgIGRhdGE9e2RhZG9zfVxyXG4gICAgICAgICAgICAgICAgZGF0YUtleT1cInZhbG9yXCJcclxuICAgICAgICAgICAgICAgIG5hbWVLZXk9XCJuYW1lXCJcclxuICAgICAgICAgICAgICAgIGN4PVwiNTAlXCJcclxuICAgICAgICAgICAgICAgIGN5PVwiNTAlXCJcclxuICAgICAgICAgICAgICAgIGlubmVyUmFkaXVzPXs2Mn1cclxuICAgICAgICAgICAgICAgIG91dGVyUmFkaXVzPXs5Mn1cclxuICAgICAgICAgICAgICAgIHBhZGRpbmdBbmdsZT17NH1cclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICB7ZGFkb3MubWFwKChlbnRyeSwgaW5kZXgpID0+IChcclxuICAgICAgICAgICAgICAgICAgPENlbGwga2V5PXtgY2VsbC0ke2luZGV4fWB9IGZpbGw9e2VudHJ5LmNvcn0gc3Ryb2tlPVwidHJhbnNwYXJlbnRcIiAvPlxyXG4gICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgPC9QaWU+XHJcbiAgICAgICAgICAgICAgPFRvb2x0aXBcclxuICAgICAgICAgICAgICAgIGNvbnRlbnQ9eyh7IGFjdGl2ZSwgcGF5bG9hZCB9KSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgIGlmIChhY3RpdmUgJiYgcGF5bG9hZCAmJiBwYXlsb2FkLmxlbmd0aCkge1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGRhdGEgPSBwYXlsb2FkWzBdLnBheWxvYWQgYXMgSXRlbUdyYWZpY287XHJcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgcGN0ID0gdG90YWxDYWxjdWxhZG8gPiAwID8gKChkYXRhLnZhbG9yIC8gdG90YWxDYWxjdWxhZG8pICogMTAwKS50b0ZpeGVkKDEpIDogXCIwXCI7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGFyazpiZy1zbGF0ZS04MDAgcC0zIHJvdW5kZWQtbGcgc2hhZG93LWxnIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCB0ZXh0LXhzXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgZm9udC1ib2xkIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZSBtYi0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctMi41IGgtMi41IHJvdW5kZWQtZnVsbCBpbmxpbmUtYmxvY2tcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgYmFja2dyb3VuZENvbG9yOiBkYXRhLmNvciB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+e2RhdGEubmFtZX08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNjAwIGRhcms6dGV4dC1zbGF0ZS0zMDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBRdWFudGlkYWRlOiA8c3Ryb25nIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZVwiPntkYXRhLnZhbG9yfSBlbXByZXNhczwvc3Ryb25nPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTUwMCBkYXJrOnRleHQtc2xhdGUtNDAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgUGFydGljaXBhw6fDo286IDxzdHJvbmcgY2xhc3NOYW1lPVwidGV4dC10ZWFsLTYwMCBkYXJrOnRleHQtdGVhbC00MDBcIj57cGN0fSUgZG8gY2FkYXN0cm88L3N0cm9uZz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICApO1xyXG4gICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgIHJldHVybiBudWxsO1xyXG4gICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIDxMZWdlbmRcclxuICAgICAgICAgICAgICAgIHZlcnRpY2FsQWxpZ249XCJib3R0b21cIlxyXG4gICAgICAgICAgICAgICAgaGVpZ2h0PXszNn1cclxuICAgICAgICAgICAgICAgIGZvcm1hdHRlcj17KHZhbHVlLCBlbnRyeSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICBjb25zdCBpdGVtID0gZGFkb3MuZmluZCgoZCkgPT4gZC5uYW1lID09PSB2YWx1ZSk7XHJcbiAgICAgICAgICAgICAgICAgIGNvbnN0IHBjdCA9IHRvdGFsQ2FsY3VsYWRvID4gMCAmJiBpdGVtID8gKChpdGVtLnZhbG9yIC8gdG90YWxDYWxjdWxhZG8pICogMTAwKS50b0ZpeGVkKDApIDogXCIwXCI7XHJcbiAgICAgICAgICAgICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMzAwIGZvbnQtbWVkaXVtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7dmFsdWV9ICh7cGN0fSUpXHJcbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICApO1xyXG4gICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8L1BpZUNoYXJ0PlxyXG4gICAgICAgICAgPC9SZXNwb25zaXZlQ29udGFpbmVyPlxyXG5cclxuICAgICAgICAgIHsvKiBSw7N0dWxvIENlbnRyYWwgbm8gTWlvbG8gZGEgUm9zY2EgKi99XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIGluc2V0LTAgZmxleCBmbGV4LWNvbCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcG9pbnRlci1ldmVudHMtbm9uZSBwYi05XCI+XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtZXh0cmFib2xkIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZSB0YWJ1bGFyLW51bXNcIj5cclxuICAgICAgICAgICAgICB7dG90YWxDYWxjdWxhZG99XHJcbiAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdXBwZXJjYXNlIGZvbnQtYm9sZCB0cmFja2luZy13aWRlciB0ZXh0LXNsYXRlLTQwMFwiPlxyXG4gICAgICAgICAgICAgIEVtcHJlc2FzXHJcbiAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIHsvKiBUYWJlbGEgUmVzdW1vIEFiYWl4byBkbyBHcsOhZmljbyAqL31cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0yIHNtOmdyaWQtY29scy00IGdhcC0yIHB0LTMgYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTEwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgbXQtMlwiPlxyXG4gICAgICAgIHtkYWRvcy5tYXAoKGl0ZW0pID0+IChcclxuICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAga2V5PXtpdGVtLm5hbWV9XHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMiByb3VuZGVkIGJnLXNsYXRlLTUwIGRhcms6Ymctc2xhdGUtODAwLzQwIHRleHQtY2VudGVyXCJcclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTYwMCBkYXJrOnRleHQtc2xhdGUtNDAwIGJsb2NrIHRydW5jYXRlXCI+XHJcbiAgICAgICAgICAgICAge2l0ZW0ubmFtZS5zcGxpdChcIiBcIilbMF19IHtpdGVtLm5hbWUuc3BsaXQoXCIgXCIpWzFdIHx8IFwiXCJ9XHJcbiAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgPHNwYW5cclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtYm9sZCB0YWJ1bGFyLW51bXMgYmxvY2tcIlxyXG4gICAgICAgICAgICAgIHN0eWxlPXt7IGNvbG9yOiBpdGVtLmNvciB9fVxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAge2l0ZW0udmFsb3J9XHJcbiAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICkpfVxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBHcmFmaWNvRGlzdHJpYnVpY2FvUmlzY287XHJcbiJdfQ==