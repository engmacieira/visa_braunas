import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/licenciamento/StatusRequerimentoBadge.tsx");const React = __vite__cjsImport0_react;const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];/**
* Badge Semântico para Status de Requerimento de Licenciamento Sanitário
*/
import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=0fd2848a";
import { AlertCircle, CheckCircle2, Clock, FileSearch, Hourglass, XCircle } from "/node_modules/.vite/deps/lucide-react.js?v=0fd2848a";
var _jsxFileName = "E:/Projetos VSCODE/visa_braunas/src/components/licenciamento/StatusRequerimentoBadge.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=0fd2848a";
const STATUS_CONFIGS = {
	pendente: {
		label: "Pendente",
		bgClass: "bg-amber-50 dark:bg-amber-950/40",
		textClass: "text-amber-700 dark:text-amber-300",
		borderClass: "border-amber-200 dark:border-amber-800",
		icon: Hourglass
	},
	solicitado: {
		label: "Solicitado",
		bgClass: "bg-amber-50 dark:bg-amber-950/40",
		textClass: "text-amber-700 dark:text-amber-300",
		borderClass: "border-amber-200 dark:border-amber-800",
		icon: Hourglass
	},
	em_analise: {
		label: "Em Análise",
		bgClass: "bg-sky-50 dark:bg-sky-950/40",
		textClass: "text-sky-700 dark:text-sky-300",
		borderClass: "border-sky-200 dark:border-sky-800",
		icon: FileSearch
	},
	em_analise_documental: {
		label: "Análise Documental",
		bgClass: "bg-sky-50 dark:bg-sky-950/40",
		textClass: "text-sky-700 dark:text-sky-300",
		borderClass: "border-sky-200 dark:border-sky-800",
		icon: FileSearch
	},
	aguardando_inspecao: {
		label: "Aguardando Vistoria",
		bgClass: "bg-indigo-50 dark:bg-indigo-950/40",
		textClass: "text-indigo-700 dark:text-indigo-300",
		borderClass: "border-indigo-200 dark:border-indigo-800",
		icon: Clock
	},
	vistoria_pendente: {
		label: "Vistoria Pendente",
		bgClass: "bg-indigo-50 dark:bg-indigo-950/40",
		textClass: "text-indigo-700 dark:text-indigo-300",
		borderClass: "border-indigo-200 dark:border-indigo-800",
		icon: Clock
	},
	aguardando_adequacao: {
		label: "Exigências / Adequação",
		bgClass: "bg-orange-50 dark:bg-orange-950/40",
		textClass: "text-orange-700 dark:text-orange-300",
		borderClass: "border-orange-200 dark:border-orange-800",
		icon: AlertCircle
	},
	deferido: {
		label: "Deferido / Aprovado",
		bgClass: "bg-emerald-50 dark:bg-emerald-950/40",
		textClass: "text-emerald-700 dark:text-emerald-300",
		borderClass: "border-emerald-200 dark:border-emerald-800",
		icon: CheckCircle2
	},
	aprovado: {
		label: "Aprovado",
		bgClass: "bg-emerald-50 dark:bg-emerald-950/40",
		textClass: "text-emerald-700 dark:text-emerald-300",
		borderClass: "border-emerald-200 dark:border-emerald-800",
		icon: CheckCircle2
	},
	indeferido: {
		label: "Indeferido",
		bgClass: "bg-rose-50 dark:bg-rose-950/40",
		textClass: "text-rose-700 dark:text-rose-300",
		borderClass: "border-rose-200 dark:border-rose-800",
		icon: XCircle
	},
	cancelado: {
		label: "Cancelado",
		bgClass: "bg-slate-100 dark:bg-slate-800",
		textClass: "text-slate-600 dark:text-slate-400",
		borderClass: "border-slate-200 dark:border-slate-700",
		icon: XCircle
	}
};
export const StatusRequerimentoBadge = ({ status, className = "" }) => {
	const normalizado = (status || "pendente").toLowerCase().trim();
	const config = STATUS_CONFIGS[normalizado] || {
		label: status,
		bgClass: "bg-slate-100 dark:bg-slate-800",
		textClass: "text-slate-700 dark:text-slate-300",
		borderClass: "border-slate-200 dark:border-slate-700",
		icon: Hourglass
	};
	const Icon = config.icon;
	return /* @__PURE__ */ _jsxDEV("span", {
		className: `inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-semibold border ${config.bgClass} ${config.textClass} ${config.borderClass} ${className}`,
		children: [/* @__PURE__ */ _jsxDEV(Icon, { className: "w-3 h-3 shrink-0" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 128,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("span", { children: config.label }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 129,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 125,
		columnNumber: 5
	}, this);
};
_c = StatusRequerimentoBadge;
export default StatusRequerimentoBadge;
var _c;
$RefreshReg$(_c, "StatusRequerimentoBadge");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/licenciamento/StatusRequerimentoBadge.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("E:/Projetos VSCODE/visa_braunas/src/components/licenciamento/StatusRequerimentoBadge.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("E:/Projetos VSCODE/visa_braunas/src/components/licenciamento/StatusRequerimentoBadge.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "E:/Projetos VSCODE/visa_braunas/src/components/licenciamento/StatusRequerimentoBadge.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7O0FBSUEsT0FBTyxXQUFXO0FBQ2xCLFNBQ0UsYUFDQSxjQUNBLE9BQ0EsWUFDQSxXQUNBLGVBQ0s7OztBQWdCUCxNQUFNLGlCQUE4QztDQUNsRCxVQUFVO0VBQ1IsT0FBTztFQUNQLFNBQVM7RUFDVCxXQUFXO0VBQ1gsYUFBYTtFQUNiLE1BQU07Q0FDUjtDQUNBLFlBQVk7RUFDVixPQUFPO0VBQ1AsU0FBUztFQUNULFdBQVc7RUFDWCxhQUFhO0VBQ2IsTUFBTTtDQUNSO0NBQ0EsWUFBWTtFQUNWLE9BQU87RUFDUCxTQUFTO0VBQ1QsV0FBVztFQUNYLGFBQWE7RUFDYixNQUFNO0NBQ1I7Q0FDQSx1QkFBdUI7RUFDckIsT0FBTztFQUNQLFNBQVM7RUFDVCxXQUFXO0VBQ1gsYUFBYTtFQUNiLE1BQU07Q0FDUjtDQUNBLHFCQUFxQjtFQUNuQixPQUFPO0VBQ1AsU0FBUztFQUNULFdBQVc7RUFDWCxhQUFhO0VBQ2IsTUFBTTtDQUNSO0NBQ0EsbUJBQW1CO0VBQ2pCLE9BQU87RUFDUCxTQUFTO0VBQ1QsV0FBVztFQUNYLGFBQWE7RUFDYixNQUFNO0NBQ1I7Q0FDQSxzQkFBc0I7RUFDcEIsT0FBTztFQUNQLFNBQVM7RUFDVCxXQUFXO0VBQ1gsYUFBYTtFQUNiLE1BQU07Q0FDUjtDQUNBLFVBQVU7RUFDUixPQUFPO0VBQ1AsU0FBUztFQUNULFdBQVc7RUFDWCxhQUFhO0VBQ2IsTUFBTTtDQUNSO0NBQ0EsVUFBVTtFQUNSLE9BQU87RUFDUCxTQUFTO0VBQ1QsV0FBVztFQUNYLGFBQWE7RUFDYixNQUFNO0NBQ1I7Q0FDQSxZQUFZO0VBQ1YsT0FBTztFQUNQLFNBQVM7RUFDVCxXQUFXO0VBQ1gsYUFBYTtFQUNiLE1BQU07Q0FDUjtDQUNBLFdBQVc7RUFDVCxPQUFPO0VBQ1AsU0FBUztFQUNULFdBQVc7RUFDWCxhQUFhO0VBQ2IsTUFBTTtDQUNSO0FBQ0Y7QUFFQSxPQUFPLE1BQU0sMkJBQW1FLEVBQzlFLFFBQ0EsWUFBWSxTQUNSO0NBQ0osTUFBTSxlQUFlLFVBQVUsV0FBVSxDQUFFLFlBQVksQ0FBQyxDQUFDLEtBQUs7Q0FDOUQsTUFBTSxTQUFTLGVBQWUsZ0JBQWdCO0VBQzVDLE9BQU87RUFDUCxTQUFTO0VBQ1QsV0FBVztFQUNYLGFBQWE7RUFDYixNQUFNO0NBQ1I7Q0FFQSxNQUFNLE9BQU8sT0FBTztDQUVwQixPQUNFLHdCQUFDLFFBQUQ7RUFDRSxXQUFXLGdHQUFnRyxPQUFPLFFBQVEsR0FBRyxPQUFPLFVBQVUsR0FBRyxPQUFPLFlBQVksR0FBRztZQUR6SyxDQUdFLHdCQUFDLE1BQUQsRUFBTSxXQUFVLG1CQUFvQjs7OztZQUNwQyx3QkFBQyxRQUFELFlBQU8sT0FBTyxNQUFZOzs7O1VBQ3RCOzs7Ozs7QUFFVjs7QUFFQSxlQUFlIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIlN0YXR1c1JlcXVlcmltZW50b0JhZGdlLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyIvKipcclxuICogQmFkZ2UgU2Vtw6JudGljbyBwYXJhIFN0YXR1cyBkZSBSZXF1ZXJpbWVudG8gZGUgTGljZW5jaWFtZW50byBTYW5pdMOhcmlvXHJcbiAqL1xyXG5cclxuaW1wb3J0IFJlYWN0IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQge1xyXG4gIEFsZXJ0Q2lyY2xlLFxyXG4gIENoZWNrQ2lyY2xlMixcclxuICBDbG9jayxcclxuICBGaWxlU2VhcmNoLFxyXG4gIEhvdXJnbGFzcyxcclxuICBYQ2lyY2xlLFxyXG59IGZyb20gXCJsdWNpZGUtcmVhY3RcIjtcclxuaW1wb3J0IHsgU3RhdHVzUmVxdWVyaW1lbnRvIH0gZnJvbSBcIi4uLy4uL3R5cGVzL2xpY2VuY2lhbWVudG9cIjtcclxuXHJcbmludGVyZmFjZSBTdGF0dXNSZXF1ZXJpbWVudG9CYWRnZVByb3BzIHtcclxuICBzdGF0dXM6IFN0YXR1c1JlcXVlcmltZW50byB8IHN0cmluZztcclxuICBjbGFzc05hbWU/OiBzdHJpbmc7XHJcbn1cclxuXHJcbmludGVyZmFjZSBCYWRnZUNvbmZpZyB7XHJcbiAgbGFiZWw6IHN0cmluZztcclxuICBiZ0NsYXNzOiBzdHJpbmc7XHJcbiAgdGV4dENsYXNzOiBzdHJpbmc7XHJcbiAgYm9yZGVyQ2xhc3M6IHN0cmluZztcclxuICBpY29uOiBSZWFjdC5Db21wb25lbnRUeXBlPHsgY2xhc3NOYW1lPzogc3RyaW5nIH0+O1xyXG59XHJcblxyXG5jb25zdCBTVEFUVVNfQ09ORklHUzogUmVjb3JkPHN0cmluZywgQmFkZ2VDb25maWc+ID0ge1xyXG4gIHBlbmRlbnRlOiB7XHJcbiAgICBsYWJlbDogXCJQZW5kZW50ZVwiLFxyXG4gICAgYmdDbGFzczogXCJiZy1hbWJlci01MCBkYXJrOmJnLWFtYmVyLTk1MC80MFwiLFxyXG4gICAgdGV4dENsYXNzOiBcInRleHQtYW1iZXItNzAwIGRhcms6dGV4dC1hbWJlci0zMDBcIixcclxuICAgIGJvcmRlckNsYXNzOiBcImJvcmRlci1hbWJlci0yMDAgZGFyazpib3JkZXItYW1iZXItODAwXCIsXHJcbiAgICBpY29uOiBIb3VyZ2xhc3MsXHJcbiAgfSxcclxuICBzb2xpY2l0YWRvOiB7XHJcbiAgICBsYWJlbDogXCJTb2xpY2l0YWRvXCIsXHJcbiAgICBiZ0NsYXNzOiBcImJnLWFtYmVyLTUwIGRhcms6YmctYW1iZXItOTUwLzQwXCIsXHJcbiAgICB0ZXh0Q2xhc3M6IFwidGV4dC1hbWJlci03MDAgZGFyazp0ZXh0LWFtYmVyLTMwMFwiLFxyXG4gICAgYm9yZGVyQ2xhc3M6IFwiYm9yZGVyLWFtYmVyLTIwMCBkYXJrOmJvcmRlci1hbWJlci04MDBcIixcclxuICAgIGljb246IEhvdXJnbGFzcyxcclxuICB9LFxyXG4gIGVtX2FuYWxpc2U6IHtcclxuICAgIGxhYmVsOiBcIkVtIEFuw6FsaXNlXCIsXHJcbiAgICBiZ0NsYXNzOiBcImJnLXNreS01MCBkYXJrOmJnLXNreS05NTAvNDBcIixcclxuICAgIHRleHRDbGFzczogXCJ0ZXh0LXNreS03MDAgZGFyazp0ZXh0LXNreS0zMDBcIixcclxuICAgIGJvcmRlckNsYXNzOiBcImJvcmRlci1za3ktMjAwIGRhcms6Ym9yZGVyLXNreS04MDBcIixcclxuICAgIGljb246IEZpbGVTZWFyY2gsXHJcbiAgfSxcclxuICBlbV9hbmFsaXNlX2RvY3VtZW50YWw6IHtcclxuICAgIGxhYmVsOiBcIkFuw6FsaXNlIERvY3VtZW50YWxcIixcclxuICAgIGJnQ2xhc3M6IFwiYmctc2t5LTUwIGRhcms6Ymctc2t5LTk1MC80MFwiLFxyXG4gICAgdGV4dENsYXNzOiBcInRleHQtc2t5LTcwMCBkYXJrOnRleHQtc2t5LTMwMFwiLFxyXG4gICAgYm9yZGVyQ2xhc3M6IFwiYm9yZGVyLXNreS0yMDAgZGFyazpib3JkZXItc2t5LTgwMFwiLFxyXG4gICAgaWNvbjogRmlsZVNlYXJjaCxcclxuICB9LFxyXG4gIGFndWFyZGFuZG9faW5zcGVjYW86IHtcclxuICAgIGxhYmVsOiBcIkFndWFyZGFuZG8gVmlzdG9yaWFcIixcclxuICAgIGJnQ2xhc3M6IFwiYmctaW5kaWdvLTUwIGRhcms6YmctaW5kaWdvLTk1MC80MFwiLFxyXG4gICAgdGV4dENsYXNzOiBcInRleHQtaW5kaWdvLTcwMCBkYXJrOnRleHQtaW5kaWdvLTMwMFwiLFxyXG4gICAgYm9yZGVyQ2xhc3M6IFwiYm9yZGVyLWluZGlnby0yMDAgZGFyazpib3JkZXItaW5kaWdvLTgwMFwiLFxyXG4gICAgaWNvbjogQ2xvY2ssXHJcbiAgfSxcclxuICB2aXN0b3JpYV9wZW5kZW50ZToge1xyXG4gICAgbGFiZWw6IFwiVmlzdG9yaWEgUGVuZGVudGVcIixcclxuICAgIGJnQ2xhc3M6IFwiYmctaW5kaWdvLTUwIGRhcms6YmctaW5kaWdvLTk1MC80MFwiLFxyXG4gICAgdGV4dENsYXNzOiBcInRleHQtaW5kaWdvLTcwMCBkYXJrOnRleHQtaW5kaWdvLTMwMFwiLFxyXG4gICAgYm9yZGVyQ2xhc3M6IFwiYm9yZGVyLWluZGlnby0yMDAgZGFyazpib3JkZXItaW5kaWdvLTgwMFwiLFxyXG4gICAgaWNvbjogQ2xvY2ssXHJcbiAgfSxcclxuICBhZ3VhcmRhbmRvX2FkZXF1YWNhbzoge1xyXG4gICAgbGFiZWw6IFwiRXhpZ8OqbmNpYXMgLyBBZGVxdWHDp8Ojb1wiLFxyXG4gICAgYmdDbGFzczogXCJiZy1vcmFuZ2UtNTAgZGFyazpiZy1vcmFuZ2UtOTUwLzQwXCIsXHJcbiAgICB0ZXh0Q2xhc3M6IFwidGV4dC1vcmFuZ2UtNzAwIGRhcms6dGV4dC1vcmFuZ2UtMzAwXCIsXHJcbiAgICBib3JkZXJDbGFzczogXCJib3JkZXItb3JhbmdlLTIwMCBkYXJrOmJvcmRlci1vcmFuZ2UtODAwXCIsXHJcbiAgICBpY29uOiBBbGVydENpcmNsZSxcclxuICB9LFxyXG4gIGRlZmVyaWRvOiB7XHJcbiAgICBsYWJlbDogXCJEZWZlcmlkbyAvIEFwcm92YWRvXCIsXHJcbiAgICBiZ0NsYXNzOiBcImJnLWVtZXJhbGQtNTAgZGFyazpiZy1lbWVyYWxkLTk1MC80MFwiLFxyXG4gICAgdGV4dENsYXNzOiBcInRleHQtZW1lcmFsZC03MDAgZGFyazp0ZXh0LWVtZXJhbGQtMzAwXCIsXHJcbiAgICBib3JkZXJDbGFzczogXCJib3JkZXItZW1lcmFsZC0yMDAgZGFyazpib3JkZXItZW1lcmFsZC04MDBcIixcclxuICAgIGljb246IENoZWNrQ2lyY2xlMixcclxuICB9LFxyXG4gIGFwcm92YWRvOiB7XHJcbiAgICBsYWJlbDogXCJBcHJvdmFkb1wiLFxyXG4gICAgYmdDbGFzczogXCJiZy1lbWVyYWxkLTUwIGRhcms6YmctZW1lcmFsZC05NTAvNDBcIixcclxuICAgIHRleHRDbGFzczogXCJ0ZXh0LWVtZXJhbGQtNzAwIGRhcms6dGV4dC1lbWVyYWxkLTMwMFwiLFxyXG4gICAgYm9yZGVyQ2xhc3M6IFwiYm9yZGVyLWVtZXJhbGQtMjAwIGRhcms6Ym9yZGVyLWVtZXJhbGQtODAwXCIsXHJcbiAgICBpY29uOiBDaGVja0NpcmNsZTIsXHJcbiAgfSxcclxuICBpbmRlZmVyaWRvOiB7XHJcbiAgICBsYWJlbDogXCJJbmRlZmVyaWRvXCIsXHJcbiAgICBiZ0NsYXNzOiBcImJnLXJvc2UtNTAgZGFyazpiZy1yb3NlLTk1MC80MFwiLFxyXG4gICAgdGV4dENsYXNzOiBcInRleHQtcm9zZS03MDAgZGFyazp0ZXh0LXJvc2UtMzAwXCIsXHJcbiAgICBib3JkZXJDbGFzczogXCJib3JkZXItcm9zZS0yMDAgZGFyazpib3JkZXItcm9zZS04MDBcIixcclxuICAgIGljb246IFhDaXJjbGUsXHJcbiAgfSxcclxuICBjYW5jZWxhZG86IHtcclxuICAgIGxhYmVsOiBcIkNhbmNlbGFkb1wiLFxyXG4gICAgYmdDbGFzczogXCJiZy1zbGF0ZS0xMDAgZGFyazpiZy1zbGF0ZS04MDBcIixcclxuICAgIHRleHRDbGFzczogXCJ0ZXh0LXNsYXRlLTYwMCBkYXJrOnRleHQtc2xhdGUtNDAwXCIsXHJcbiAgICBib3JkZXJDbGFzczogXCJib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMFwiLFxyXG4gICAgaWNvbjogWENpcmNsZSxcclxuICB9LFxyXG59O1xyXG5cclxuZXhwb3J0IGNvbnN0IFN0YXR1c1JlcXVlcmltZW50b0JhZGdlOiBSZWFjdC5GQzxTdGF0dXNSZXF1ZXJpbWVudG9CYWRnZVByb3BzPiA9ICh7XHJcbiAgc3RhdHVzLFxyXG4gIGNsYXNzTmFtZSA9IFwiXCIsXHJcbn0pID0+IHtcclxuICBjb25zdCBub3JtYWxpemFkbyA9IChzdGF0dXMgfHwgXCJwZW5kZW50ZVwiKS50b0xvd2VyQ2FzZSgpLnRyaW0oKTtcclxuICBjb25zdCBjb25maWcgPSBTVEFUVVNfQ09ORklHU1tub3JtYWxpemFkb10gfHwge1xyXG4gICAgbGFiZWw6IHN0YXR1cyxcclxuICAgIGJnQ2xhc3M6IFwiYmctc2xhdGUtMTAwIGRhcms6Ymctc2xhdGUtODAwXCIsXHJcbiAgICB0ZXh0Q2xhc3M6IFwidGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTMwMFwiLFxyXG4gICAgYm9yZGVyQ2xhc3M6IFwiYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDBcIixcclxuICAgIGljb246IEhvdXJnbGFzcyxcclxuICB9O1xyXG5cclxuICBjb25zdCBJY29uID0gY29uZmlnLmljb247XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8c3BhblxyXG4gICAgICBjbGFzc05hbWU9e2BpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBweC0yLjUgcHktMC41IHJvdW5kZWQtZnVsbCB0ZXh0LVsxMXB4XSBmb250LXNlbWlib2xkIGJvcmRlciAke2NvbmZpZy5iZ0NsYXNzfSAke2NvbmZpZy50ZXh0Q2xhc3N9ICR7Y29uZmlnLmJvcmRlckNsYXNzfSAke2NsYXNzTmFtZX1gfVxyXG4gICAgPlxyXG4gICAgICA8SWNvbiBjbGFzc05hbWU9XCJ3LTMgaC0zIHNocmluay0wXCIgLz5cclxuICAgICAgPHNwYW4+e2NvbmZpZy5sYWJlbH08L3NwYW4+XHJcbiAgICA8L3NwYW4+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IFN0YXR1c1JlcXVlcmltZW50b0JhZGdlO1xyXG4iXX0=