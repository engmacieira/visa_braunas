import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ouvidoria/ModalDespachoFiscal.tsx");const React = __vite__cjsImport0_react;const _jsxDEV = __vite__cjsImport7_react_jsxDevRuntime["jsxDEV"];/**
* Modal de Despacho Fiscal de Denúncias Sanitárias
* Permite ao Coordenador encaminhar a denúncia, designar fiscal e abrir inspeção.
*/
import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=0fd2848a";
import { useForm } from "/node_modules/.vite/deps/react-hook-form.js?v=0fd2848a";
import { zodResolver } from "/node_modules/.vite/deps/@hookform_resolvers_zod.js?v=0fd2848a";
import * as z from "/node_modules/.vite/deps/zod.js?v=0fd2848a";
import { AlertTriangle, ClipboardCheck, Send, UserCheck, X } from "/node_modules/.vite/deps/lucide-react.js?v=0fd2848a";
import { useDespachoFiscalMutation } from "/src/hooks/useOuvidoria.ts";
import { useAuth } from "/src/contexts/AuthContext.tsx";
var _jsxFileName = "E:/Projetos VSCODE/visa_braunas/src/components/ouvidoria/ModalDespachoFiscal.tsx";
import __vite__cjsImport7_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=0fd2848a";
var _s = $RefreshSig$();
const despachoSchema = z.object({
	despacho_coordenacao: z.string().min(10, "Despacho da coordenação deve conter no mínimo 10 caracteres"),
	fiscal_designado_id: z.string().optional(),
	nova_gravidade: z.enum([
		"baixa",
		"media",
		"alta",
		"urgente"
	]).optional(),
	iniciar_apuracao: z.boolean()
});
export const ModalDespachoFiscal = ({ isOpen, onClose, denunciaId, protocolo, gravidadeAtual, onSucesso }) => {
	_s();
	const { user } = useAuth();
	const despachoMutation = useDespachoFiscalMutation(denunciaId);
	const { register, handleSubmit, formState: { errors, isSubmitting } } = useForm({
		resolver: zodResolver(despachoSchema),
		defaultValues: {
			despacho_coordenacao: "",
			fiscal_designado_id: user?.id || "",
			nova_gravidade: gravidadeAtual,
			iniciar_apuracao: true
		}
	});
	if (!isOpen) return null;
	const onSubmit = async (data) => {
		try {
			const payload = {
				despacho_coordenacao: data.despacho_coordenacao.trim(),
				fiscal_designado_id: data.fiscal_designado_id || null,
				nova_gravidade: data.nova_gravidade || null,
				iniciar_apuracao: data.iniciar_apuracao
			};
			await despachoMutation.mutateAsync(payload);
			if (onSucesso) {
				onSucesso();
			}
			onClose();
		} catch {}
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-xs",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl w-full max-w-lg shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150 flex flex-col",
			children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "px-6 py-4 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between bg-slate-50/50 dark:bg-slate-800/40",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-2.5",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "w-9 h-9 rounded-xl bg-teal-100 dark:bg-teal-950/60 text-teal-700 dark:text-teal-300 flex items-center justify-center",
						children: /* @__PURE__ */ _jsxDEV(ClipboardCheck, { className: "w-5 h-5" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 95,
							columnNumber: 15
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 94,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h2", {
						className: "text-sm font-bold text-slate-900 dark:text-white",
						children: "Despacho e Encaminhamento Fiscal"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 98,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("p", {
						className: "text-[11px] text-slate-500 font-mono",
						children: ["Protocolo: ", protocolo]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 101,
						columnNumber: 15
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 97,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 93,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					onClick: onClose,
					className: "p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-300 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors",
					children: /* @__PURE__ */ _jsxDEV(X, { className: "w-5 h-5" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 111,
						columnNumber: 13
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 106,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 92,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("form", {
				onSubmit: handleSubmit(onSubmit),
				className: "p-6 space-y-4",
				children: [
					despachoMutation.isError && /* @__PURE__ */ _jsxDEV("div", {
						className: "p-3 bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 rounded-xl flex items-center gap-2 text-xs text-rose-700 dark:text-rose-300",
						children: [/* @__PURE__ */ _jsxDEV(AlertTriangle, { className: "w-4 h-4 shrink-0" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 119,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: despachoMutation.error instanceof Error ? despachoMutation.error.message : "Erro ao despachar a denúncia para fiscalização." }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 120,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 118,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV("div", { children: [
						/* @__PURE__ */ _jsxDEV("label", {
							className: "block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1",
							children: ["Despacho / Determinação da Coordenação ", /* @__PURE__ */ _jsxDEV("span", {
								className: "text-rose-500",
								children: "*"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 131,
								columnNumber: 54
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 130,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("textarea", {
							rows: 4,
							...register("despacho_coordenacao"),
							placeholder: "Ex: Determino realização de vistoria in loco para apurar condições higiênico-sanitárias de manipulação e procedência dos produtos...",
							className: "w-full p-2.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-teal-500"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 133,
							columnNumber: 13
						}, this),
						errors.despacho_coordenacao && /* @__PURE__ */ _jsxDEV("p", {
							className: "text-[11px] text-rose-600 mt-1",
							children: errors.despacho_coordenacao.message
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 140,
							columnNumber: 15
						}, this)
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 129,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "grid grid-cols-1 sm:grid-cols-2 gap-4",
						children: [/* @__PURE__ */ _jsxDEV("div", { children: [
							/* @__PURE__ */ _jsxDEV("label", {
								className: "block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1",
								children: "Fiscal Sanitário Designado"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 149,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-2 p-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg",
								children: [/* @__PURE__ */ _jsxDEV(UserCheck, { className: "w-4 h-4 text-teal-600 shrink-0" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 153,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("span", {
									className: "text-xs font-medium text-slate-800 dark:text-slate-200 truncate",
									children: user?.nome_completo || "Equipe de Fiscalização"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 154,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 152,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("input", {
								type: "hidden",
								...register("fiscal_designado_id")
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 158,
								columnNumber: 15
							}, this)
						] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 148,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
							className: "block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1",
							children: "Reclassificação de Gravidade"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 163,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("select", {
							...register("nova_gravidade"),
							className: "w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-teal-500",
							children: [
								/* @__PURE__ */ _jsxDEV("option", {
									value: "baixa",
									children: "Baixa (Rotina secundária)"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 170,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("option", {
									value: "media",
									children: "Média (Padrão de triagem)"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 171,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("option", {
									value: "alta",
									children: "Alta (Risco significativo)"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 172,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("option", {
									value: "urgente",
									children: "Urgente (Risco iminente à saúde)"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 173,
									columnNumber: 17
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 166,
							columnNumber: 15
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 162,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 146,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "p-3 bg-teal-50/70 dark:bg-teal-950/30 border border-teal-200 dark:border-teal-800/60 rounded-xl flex items-center justify-between gap-3",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-0.5",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-xs font-bold text-teal-900 dark:text-teal-200 block",
								children: "Iniciar Apuração Fiscal Imediata"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 181,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("p", {
								className: "text-[11px] text-teal-700 dark:text-teal-400",
								children: "Altera o status da denúncia para \"Em Apuração Fiscal\" na fila de fiscalização."
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 184,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 180,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("input", {
							type: "checkbox",
							...register("iniciar_apuracao"),
							className: "w-4 h-4 text-teal-600 rounded border-slate-300 focus:ring-teal-500"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 188,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 179,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center justify-end gap-2.5 pt-3 border-t border-slate-100 dark:border-slate-800",
						children: [/* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							onClick: onClose,
							disabled: isSubmitting,
							className: "px-4 py-2 text-xs font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors",
							children: "Cancelar"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 197,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							type: "submit",
							disabled: isSubmitting,
							className: "px-5 py-2 text-xs font-bold text-white bg-teal-600 hover:bg-teal-700 rounded-lg shadow-xs transition-colors flex items-center gap-2 disabled:opacity-60",
							children: [/* @__PURE__ */ _jsxDEV(Send, { className: "w-4 h-4" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 210,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: isSubmitting ? "Despachando..." : "Confirmar Despacho" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 211,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 205,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 196,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 116,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 90,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 89,
		columnNumber: 5
	}, this);
};
_s(ModalDespachoFiscal, "lImHHnWB3F1okz/MAohnM2t3d8A=", false, function() {
	return [
		useAuth,
		useDespachoFiscalMutation,
		useForm
	];
});
_c = ModalDespachoFiscal;
export default ModalDespachoFiscal;
var _c;
$RefreshReg$(_c, "ModalDespachoFiscal");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/ouvidoria/ModalDespachoFiscal.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("E:/Projetos VSCODE/visa_braunas/src/components/ouvidoria/ModalDespachoFiscal.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("E:/Projetos VSCODE/visa_braunas/src/components/ouvidoria/ModalDespachoFiscal.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "E:/Projetos VSCODE/visa_braunas/src/components/ouvidoria/ModalDespachoFiscal.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7OztBQUtBLE9BQU8sV0FBVztBQUNsQixTQUFTLGVBQWU7QUFDeEIsU0FBUyxtQkFBbUI7QUFDNUIsWUFBWSxPQUFPO0FBQ25CLFNBQ0UsZUFDQSxnQkFDQSxNQUVBLFdBQ0EsU0FDSztBQUNQLFNBQVMsaUNBQWlDO0FBQzFDLFNBQVMsZUFBZTs7OztBQUd4QixNQUFNLGlCQUFpQixFQUFFLE9BQU87Q0FDOUIsc0JBQXNCLEVBQ25CLE9BQU8sQ0FBQyxDQUNSLElBQUksSUFBSSw2REFBNkQ7Q0FDeEUscUJBQXFCLEVBQUUsT0FBTyxDQUFDLENBQUMsU0FBUztDQUN6QyxnQkFBZ0IsRUFBRSxLQUFLO0VBQUM7RUFBUztFQUFTO0VBQVE7Q0FBUyxDQUFDLENBQUMsQ0FBQyxTQUFTO0NBQ3ZFLGtCQUFrQixFQUFFLFFBQVE7QUFDOUIsQ0FBQztBQWFELE9BQU8sTUFBTSx1QkFBMkQsRUFDdEUsUUFDQSxTQUNBLFlBQ0EsV0FDQSxnQkFDQSxnQkFDSTs7Q0FDSixNQUFNLEVBQUUsU0FBUyxRQUFRO0NBQ3pCLE1BQU0sbUJBQW1CLDBCQUEwQixVQUFVO0NBRTdELE1BQU0sRUFDSixVQUNBLGNBQ0EsV0FBVyxFQUFFLFFBQVEsbUJBQ25CLFFBQTBCO0VBQzVCLFVBQVUsWUFBWSxjQUFjO0VBQ3BDLGVBQWU7R0FDYixzQkFBc0I7R0FDdEIscUJBQXFCLE1BQU0sTUFBTTtHQUNqQyxnQkFBZ0I7R0FDaEIsa0JBQWtCO0VBQ3BCO0NBQ0YsQ0FBQztDQUVELElBQUksQ0FBQyxRQUFRLE9BQU87Q0FFcEIsTUFBTSxXQUFXLE9BQU8sU0FBMkI7RUFDakQsSUFBSTtHQUNGLE1BQU0sVUFBZ0M7SUFDcEMsc0JBQXNCLEtBQUsscUJBQXFCLEtBQUs7SUFDckQscUJBQXFCLEtBQUssdUJBQXVCO0lBQ2pELGdCQUFnQixLQUFLLGtCQUFrQjtJQUN2QyxrQkFBa0IsS0FBSztHQUN6QjtHQUVBLE1BQU0saUJBQWlCLFlBQVksT0FBTztHQUMxQyxJQUFJLFdBQVc7SUFDYixVQUFVO0dBQ1o7R0FDQSxRQUFRO0VBQ1YsUUFBUSxDQUVSO0NBQ0Y7Q0FFQSxPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQ2Isd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZixDQUVFLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQ2Isd0JBQUMsZ0JBQUQsRUFBZ0IsV0FBVSxVQUFXOzs7OztLQUNsQzs7OztlQUNMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxNQUFEO01BQUksV0FBVTtnQkFBbUQ7S0FFN0Q7Ozs7ZUFDSix3QkFBQyxLQUFEO01BQUcsV0FBVTtnQkFBYixDQUFvRCxlQUN0QyxTQUNYOzs7OzthQUNBOzs7O2FBQ0Y7Ozs7O2NBQ0wsd0JBQUMsVUFBRDtLQUNFLE1BQUs7S0FDTCxTQUFTO0tBQ1QsV0FBVTtlQUVWLHdCQUFDLEdBQUQsRUFBRyxXQUFVLFVBQVc7Ozs7O0lBQ2xCOzs7O1lBQ0w7Ozs7O2FBR0wsd0JBQUMsUUFBRDtJQUFNLFVBQVUsYUFBYSxRQUFRO0lBQUcsV0FBVTtjQUFsRDtLQUNHLGlCQUFpQixXQUNoQix3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLGVBQUQsRUFBZSxXQUFVLG1CQUFvQjs7OztnQkFDN0Msd0JBQUMsUUFBRCxZQUNHLGlCQUFpQixpQkFBaUIsUUFDL0IsaUJBQWlCLE1BQU0sVUFDdkIsa0RBQ0E7Ozs7Y0FDSDs7Ozs7O0tBSVAsd0JBQUMsT0FBRDtNQUNFLHdCQUFDLFNBQUQ7T0FBTyxXQUFVO2lCQUFqQixDQUF1RiwyQ0FDOUMsd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQWdCO09BQU87Ozs7ZUFDekU7Ozs7OztNQUNQLHdCQUFDLFlBQUQ7T0FDRSxNQUFNO09BQ04sR0FBSSxTQUFTLHNCQUFzQjtPQUNuQyxhQUFZO09BQ1osV0FBVTtNQUNYOzs7OztNQUNBLE9BQU8sd0JBQ04sd0JBQUMsS0FBRDtPQUFHLFdBQVU7aUJBQ1YsT0FBTyxxQkFBcUI7TUFDNUI7Ozs7O0tBRUY7Ozs7O0tBRUwsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FFRSx3QkFBQyxPQUFEO09BQ0Usd0JBQUMsU0FBRDtRQUFPLFdBQVU7a0JBQXNFO09BRWhGOzs7OztPQUNQLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsV0FBRCxFQUFXLFdBQVUsaUNBQWtDOzs7O2tCQUN2RCx3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFDYixNQUFNLGlCQUFpQjtRQUNwQjs7OztnQkFDSDs7Ozs7O09BQ0wsd0JBQUMsU0FBRDtRQUFPLE1BQUs7UUFBUyxHQUFJLFNBQVMscUJBQXFCO09BQUk7Ozs7O01BQ3hEOzs7O2dCQUdMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO09BQU8sV0FBVTtpQkFBc0U7TUFFaEY7Ozs7Z0JBQ1Asd0JBQUMsVUFBRDtPQUNFLEdBQUksU0FBUyxnQkFBZ0I7T0FDN0IsV0FBVTtpQkFGWjtRQUlFLHdCQUFDLFVBQUQ7U0FBUSxPQUFNO21CQUFRO1FBQWlDOzs7OztRQUN2RCx3QkFBQyxVQUFEO1NBQVEsT0FBTTttQkFBUTtRQUFpQzs7Ozs7UUFDdkQsd0JBQUMsVUFBRDtTQUFRLE9BQU07bUJBQU87UUFBa0M7Ozs7O1FBQ3ZELHdCQUFDLFVBQUQ7U0FBUSxPQUFNO21CQUFVO1FBQXdDOzs7OztPQUMxRDs7Ozs7Y0FDTDs7OztjQUNGOzs7Ozs7S0FHTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQTJEO09BRXJFOzs7O2lCQUNOLHdCQUFDLEtBQUQ7UUFBRyxXQUFVO2tCQUErQztPQUV6RDs7OztlQUNBOzs7OztnQkFDTCx3QkFBQyxTQUFEO09BQ0UsTUFBSztPQUNMLEdBQUksU0FBUyxrQkFBa0I7T0FDL0IsV0FBVTtNQUNYOzs7O2NBQ0U7Ozs7OztLQUdMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsVUFBRDtPQUNFLE1BQUs7T0FDTCxTQUFTO09BQ1QsVUFBVTtPQUNWLFdBQVU7aUJBQ1g7TUFFTzs7OztnQkFDUix3QkFBQyxVQUFEO09BQ0UsTUFBSztPQUNMLFVBQVU7T0FDVixXQUFVO2lCQUhaLENBS0Usd0JBQUMsTUFBRCxFQUFNLFdBQVUsVUFBVzs7OztpQkFDM0Isd0JBQUMsUUFBRCxZQUFPLGVBQWUsbUJBQW1CLHFCQUEyQjs7OztlQUM5RDs7Ozs7Y0FDTDs7Ozs7O0lBQ0Q7Ozs7O1dBQ0g7Ozs7OztDQUNGOzs7OztBQUVUOzs7Ozs7Ozs7QUFFQSxlQUFlIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIk1vZGFsRGVzcGFjaG9GaXNjYWwudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbIi8qKlxyXG4gKiBNb2RhbCBkZSBEZXNwYWNobyBGaXNjYWwgZGUgRGVuw7puY2lhcyBTYW5pdMOhcmlhc1xyXG4gKiBQZXJtaXRlIGFvIENvb3JkZW5hZG9yIGVuY2FtaW5oYXIgYSBkZW7Dum5jaWEsIGRlc2lnbmFyIGZpc2NhbCBlIGFicmlyIGluc3Blw6fDo28uXHJcbiAqL1xyXG5cclxuaW1wb3J0IFJlYWN0IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgeyB1c2VGb3JtIH0gZnJvbSBcInJlYWN0LWhvb2stZm9ybVwiO1xyXG5pbXBvcnQgeyB6b2RSZXNvbHZlciB9IGZyb20gXCJAaG9va2Zvcm0vcmVzb2x2ZXJzL3pvZFwiO1xyXG5pbXBvcnQgKiBhcyB6IGZyb20gXCJ6b2RcIjtcclxuaW1wb3J0IHtcclxuICBBbGVydFRyaWFuZ2xlLFxyXG4gIENsaXBib2FyZENoZWNrLFxyXG4gIFNlbmQsXHJcbiAgU2hpZWxkQ2hlY2ssXHJcbiAgVXNlckNoZWNrLFxyXG4gIFgsXHJcbn0gZnJvbSBcImx1Y2lkZS1yZWFjdFwiO1xyXG5pbXBvcnQgeyB1c2VEZXNwYWNob0Zpc2NhbE11dGF0aW9uIH0gZnJvbSBcIi4uLy4uL2hvb2tzL3VzZU91dmlkb3JpYVwiO1xyXG5pbXBvcnQgeyB1c2VBdXRoIH0gZnJvbSBcIi4uLy4uL2NvbnRleHRzL0F1dGhDb250ZXh0XCI7XHJcbmltcG9ydCB7IERlc3BhY2hhckRlbnVuY2lhRFRPLCBHcmF2aWRhZGVEZW51bmNpYSB9IGZyb20gXCIuLi8uLi90eXBlcy9vdXZpZG9yaWFcIjtcclxuXHJcbmNvbnN0IGRlc3BhY2hvU2NoZW1hID0gei5vYmplY3Qoe1xyXG4gIGRlc3BhY2hvX2Nvb3JkZW5hY2FvOiB6XHJcbiAgICAuc3RyaW5nKClcclxuICAgIC5taW4oMTAsIFwiRGVzcGFjaG8gZGEgY29vcmRlbmHDp8OjbyBkZXZlIGNvbnRlciBubyBtw61uaW1vIDEwIGNhcmFjdGVyZXNcIiksXHJcbiAgZmlzY2FsX2Rlc2lnbmFkb19pZDogei5zdHJpbmcoKS5vcHRpb25hbCgpLFxyXG4gIG5vdmFfZ3JhdmlkYWRlOiB6LmVudW0oW1wiYmFpeGFcIiwgXCJtZWRpYVwiLCBcImFsdGFcIiwgXCJ1cmdlbnRlXCJdKS5vcHRpb25hbCgpLFxyXG4gIGluaWNpYXJfYXB1cmFjYW86IHouYm9vbGVhbigpLFxyXG59KTtcclxuXHJcbnR5cGUgRGVzcGFjaG9Gb3JtRGF0YSA9IHouaW5mZXI8dHlwZW9mIGRlc3BhY2hvU2NoZW1hPjtcclxuXHJcbmludGVyZmFjZSBNb2RhbERlc3BhY2hvRmlzY2FsUHJvcHMge1xyXG4gIGlzT3BlbjogYm9vbGVhbjtcclxuICBvbkNsb3NlOiAoKSA9PiB2b2lkO1xyXG4gIGRlbnVuY2lhSWQ6IHN0cmluZztcclxuICBwcm90b2NvbG86IHN0cmluZztcclxuICBncmF2aWRhZGVBdHVhbDogR3JhdmlkYWRlRGVudW5jaWE7XHJcbiAgb25TdWNlc3NvPzogKCkgPT4gdm9pZDtcclxufVxyXG5cclxuZXhwb3J0IGNvbnN0IE1vZGFsRGVzcGFjaG9GaXNjYWw6IFJlYWN0LkZDPE1vZGFsRGVzcGFjaG9GaXNjYWxQcm9wcz4gPSAoe1xyXG4gIGlzT3BlbixcclxuICBvbkNsb3NlLFxyXG4gIGRlbnVuY2lhSWQsXHJcbiAgcHJvdG9jb2xvLFxyXG4gIGdyYXZpZGFkZUF0dWFsLFxyXG4gIG9uU3VjZXNzbyxcclxufSkgPT4ge1xyXG4gIGNvbnN0IHsgdXNlciB9ID0gdXNlQXV0aCgpO1xyXG4gIGNvbnN0IGRlc3BhY2hvTXV0YXRpb24gPSB1c2VEZXNwYWNob0Zpc2NhbE11dGF0aW9uKGRlbnVuY2lhSWQpO1xyXG5cclxuICBjb25zdCB7XHJcbiAgICByZWdpc3RlcixcclxuICAgIGhhbmRsZVN1Ym1pdCxcclxuICAgIGZvcm1TdGF0ZTogeyBlcnJvcnMsIGlzU3VibWl0dGluZyB9LFxyXG4gIH0gPSB1c2VGb3JtPERlc3BhY2hvRm9ybURhdGE+KHtcclxuICAgIHJlc29sdmVyOiB6b2RSZXNvbHZlcihkZXNwYWNob1NjaGVtYSksXHJcbiAgICBkZWZhdWx0VmFsdWVzOiB7XHJcbiAgICAgIGRlc3BhY2hvX2Nvb3JkZW5hY2FvOiBcIlwiLFxyXG4gICAgICBmaXNjYWxfZGVzaWduYWRvX2lkOiB1c2VyPy5pZCB8fCBcIlwiLFxyXG4gICAgICBub3ZhX2dyYXZpZGFkZTogZ3JhdmlkYWRlQXR1YWwsXHJcbiAgICAgIGluaWNpYXJfYXB1cmFjYW86IHRydWUsXHJcbiAgICB9LFxyXG4gIH0pO1xyXG5cclxuICBpZiAoIWlzT3BlbikgcmV0dXJuIG51bGw7XHJcblxyXG4gIGNvbnN0IG9uU3VibWl0ID0gYXN5bmMgKGRhdGE6IERlc3BhY2hvRm9ybURhdGEpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHBheWxvYWQ6IERlc3BhY2hhckRlbnVuY2lhRFRPID0ge1xyXG4gICAgICAgIGRlc3BhY2hvX2Nvb3JkZW5hY2FvOiBkYXRhLmRlc3BhY2hvX2Nvb3JkZW5hY2FvLnRyaW0oKSxcclxuICAgICAgICBmaXNjYWxfZGVzaWduYWRvX2lkOiBkYXRhLmZpc2NhbF9kZXNpZ25hZG9faWQgfHwgbnVsbCxcclxuICAgICAgICBub3ZhX2dyYXZpZGFkZTogZGF0YS5ub3ZhX2dyYXZpZGFkZSB8fCBudWxsLFxyXG4gICAgICAgIGluaWNpYXJfYXB1cmFjYW86IGRhdGEuaW5pY2lhcl9hcHVyYWNhbyxcclxuICAgICAgfTtcclxuXHJcbiAgICAgIGF3YWl0IGRlc3BhY2hvTXV0YXRpb24ubXV0YXRlQXN5bmMocGF5bG9hZCk7XHJcbiAgICAgIGlmIChvblN1Y2Vzc28pIHtcclxuICAgICAgICBvblN1Y2Vzc28oKTtcclxuICAgICAgfVxyXG4gICAgICBvbkNsb3NlKCk7XHJcbiAgICB9IGNhdGNoIHtcclxuICAgICAgLy8gRXJybyDDqSBjYXB0dXJhZG8gcGVsbyBob29rXHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZml4ZWQgaW5zZXQtMCB6LTUwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHAtNCBiZy1ibGFjay81MCBiYWNrZHJvcC1ibHVyLXhzXCI+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGFyazpiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtODAwIHJvdW5kZWQtMnhsIHctZnVsbCBtYXgtdy1sZyBzaGFkb3ctMnhsIG92ZXJmbG93LWhpZGRlbiBhbmltYXRlLWluIGZhZGUtaW4gem9vbS1pbi05NSBkdXJhdGlvbi0xNTAgZmxleCBmbGV4LWNvbFwiPlxyXG4gICAgICAgIHsvKiBDYWJlw6dhbGhvICovfVxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHgtNiBweS00IGJvcmRlci1iIGJvcmRlci1zbGF0ZS0xMDAgZGFyazpib3JkZXItc2xhdGUtODAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBiZy1zbGF0ZS01MC81MCBkYXJrOmJnLXNsYXRlLTgwMC80MFwiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMi41XCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy05IGgtOSByb3VuZGVkLXhsIGJnLXRlYWwtMTAwIGRhcms6YmctdGVhbC05NTAvNjAgdGV4dC10ZWFsLTcwMCBkYXJrOnRleHQtdGVhbC0zMDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICA8Q2xpcGJvYXJkQ2hlY2sgY2xhc3NOYW1lPVwidy01IGgtNVwiIC8+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGVcIj5cclxuICAgICAgICAgICAgICAgIERlc3BhY2hvIGUgRW5jYW1pbmhhbWVudG8gRmlzY2FsXHJcbiAgICAgICAgICAgICAgPC9oMj5cclxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LXNsYXRlLTUwMCBmb250LW1vbm9cIj5cclxuICAgICAgICAgICAgICAgIFByb3RvY29sbzoge3Byb3RvY29sb31cclxuICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICBvbkNsaWNrPXtvbkNsb3NlfVxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJwLTEuNSB0ZXh0LXNsYXRlLTQwMCBob3Zlcjp0ZXh0LXNsYXRlLTYwMCBkYXJrOmhvdmVyOnRleHQtc2xhdGUtMzAwIHJvdW5kZWQtbGcgaG92ZXI6Ymctc2xhdGUtMTAwIGRhcms6aG92ZXI6Ymctc2xhdGUtODAwIHRyYW5zaXRpb24tY29sb3JzXCJcclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgPFggY2xhc3NOYW1lPVwidy01IGgtNVwiIC8+XHJcbiAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgey8qIEZvcm11bMOhcmlvICovfVxyXG4gICAgICAgIDxmb3JtIG9uU3VibWl0PXtoYW5kbGVTdWJtaXQob25TdWJtaXQpfSBjbGFzc05hbWU9XCJwLTYgc3BhY2UteS00XCI+XHJcbiAgICAgICAgICB7ZGVzcGFjaG9NdXRhdGlvbi5pc0Vycm9yICYmIChcclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTMgYmctcm9zZS01MCBkYXJrOmJnLXJvc2UtOTUwLzQwIGJvcmRlciBib3JkZXItcm9zZS0yMDAgZGFyazpib3JkZXItcm9zZS04MDAgcm91bmRlZC14bCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiB0ZXh0LXhzIHRleHQtcm9zZS03MDAgZGFyazp0ZXh0LXJvc2UtMzAwXCI+XHJcbiAgICAgICAgICAgICAgPEFsZXJ0VHJpYW5nbGUgY2xhc3NOYW1lPVwidy00IGgtNCBzaHJpbmstMFwiIC8+XHJcbiAgICAgICAgICAgICAgPHNwYW4+XHJcbiAgICAgICAgICAgICAgICB7ZGVzcGFjaG9NdXRhdGlvbi5lcnJvciBpbnN0YW5jZW9mIEVycm9yXHJcbiAgICAgICAgICAgICAgICAgID8gZGVzcGFjaG9NdXRhdGlvbi5lcnJvci5tZXNzYWdlXHJcbiAgICAgICAgICAgICAgICAgIDogXCJFcnJvIGFvIGRlc3BhY2hhciBhIGRlbsO6bmNpYSBwYXJhIGZpc2NhbGl6YcOnw6NvLlwifVxyXG4gICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgIHsvKiBEZXNwYWNobyBkYSBDb29yZGVuYcOnw6NvICovfVxyXG4gICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMzAwIG1iLTFcIj5cclxuICAgICAgICAgICAgICBEZXNwYWNobyAvIERldGVybWluYcOnw6NvIGRhIENvb3JkZW5hw6fDo28gPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yb3NlLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgIDx0ZXh0YXJlYVxyXG4gICAgICAgICAgICAgIHJvd3M9ezR9XHJcbiAgICAgICAgICAgICAgey4uLnJlZ2lzdGVyKFwiZGVzcGFjaG9fY29vcmRlbmFjYW9cIil9XHJcbiAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFeDogRGV0ZXJtaW5vIHJlYWxpemHDp8OjbyBkZSB2aXN0b3JpYSBpbiBsb2NvIHBhcmEgYXB1cmFyIGNvbmRpw6fDtWVzIGhpZ2nDqm5pY28tc2FuaXTDoXJpYXMgZGUgbWFuaXB1bGHDp8OjbyBlIHByb2NlZMOqbmNpYSBkb3MgcHJvZHV0b3MuLi5cIlxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBwLTIuNSB0ZXh0LXhzIGJnLXNsYXRlLTUwIGRhcms6Ymctc2xhdGUtODAwIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCByb3VuZGVkLWxnIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZSBwbGFjZWhvbGRlci1zbGF0ZS00MDAgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLXRlYWwtNTAwXCJcclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAge2Vycm9ycy5kZXNwYWNob19jb29yZGVuYWNhbyAmJiAoXHJcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1yb3NlLTYwMCBtdC0xXCI+XHJcbiAgICAgICAgICAgICAgICB7ZXJyb3JzLmRlc3BhY2hvX2Nvb3JkZW5hY2FvLm1lc3NhZ2V9XHJcbiAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICApfVxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIHNtOmdyaWQtY29scy0yIGdhcC00XCI+XHJcbiAgICAgICAgICAgIHsvKiBGaXNjYWwgRGVzaWduYWRvICovfVxyXG4gICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTMwMCBtYi0xXCI+XHJcbiAgICAgICAgICAgICAgICBGaXNjYWwgU2FuaXTDoXJpbyBEZXNpZ25hZG9cclxuICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgcC0yIGJnLXNsYXRlLTUwIGRhcms6Ymctc2xhdGUtODAwIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCByb3VuZGVkLWxnXCI+XHJcbiAgICAgICAgICAgICAgICA8VXNlckNoZWNrIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC10ZWFsLTYwMCBzaHJpbmstMFwiIC8+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtc2xhdGUtODAwIGRhcms6dGV4dC1zbGF0ZS0yMDAgdHJ1bmNhdGVcIj5cclxuICAgICAgICAgICAgICAgICAge3VzZXI/Lm5vbWVfY29tcGxldG8gfHwgXCJFcXVpcGUgZGUgRmlzY2FsaXphw6fDo29cIn1cclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8aW5wdXQgdHlwZT1cImhpZGRlblwiIHsuLi5yZWdpc3RlcihcImZpc2NhbF9kZXNpZ25hZG9faWRcIil9IC8+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgey8qIFJlY2xhc3NpZmljYcOnw6NvIGRlIEdyYXZpZGFkZSAqL31cclxuICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0zMDAgbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgUmVjbGFzc2lmaWNhw6fDo28gZGUgR3JhdmlkYWRlXHJcbiAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICA8c2VsZWN0XHJcbiAgICAgICAgICAgICAgICB7Li4ucmVnaXN0ZXIoXCJub3ZhX2dyYXZpZGFkZVwiKX1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC0zIHB5LTIgdGV4dC14cyBiZy1zbGF0ZS01MCBkYXJrOmJnLXNsYXRlLTgwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC1sZyB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGUgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLXRlYWwtNTAwXCJcclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiYmFpeGFcIj5CYWl4YSAoUm90aW5hIHNlY3VuZMOhcmlhKTwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIm1lZGlhXCI+TcOpZGlhIChQYWRyw6NvIGRlIHRyaWFnZW0pPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiYWx0YVwiPkFsdGEgKFJpc2NvIHNpZ25pZmljYXRpdm8pPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwidXJnZW50ZVwiPlVyZ2VudGUgKFJpc2NvIGltaW5lbnRlIMOgIHNhw7pkZSk8L29wdGlvbj5cclxuICAgICAgICAgICAgICA8L3NlbGVjdD5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICB7LyogVG9nZ2xlIGRlIEluw61jaW8gSW1lZGlhdG8gZGEgQXB1cmHDp8OjbyAqL31cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0zIGJnLXRlYWwtNTAvNzAgZGFyazpiZy10ZWFsLTk1MC8zMCBib3JkZXIgYm9yZGVyLXRlYWwtMjAwIGRhcms6Ym9yZGVyLXRlYWwtODAwLzYwIHJvdW5kZWQteGwgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC0zXCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0wLjVcIj5cclxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXRlYWwtOTAwIGRhcms6dGV4dC10ZWFsLTIwMCBibG9ja1wiPlxyXG4gICAgICAgICAgICAgICAgSW5pY2lhciBBcHVyYcOnw6NvIEZpc2NhbCBJbWVkaWF0YVxyXG4gICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LXRlYWwtNzAwIGRhcms6dGV4dC10ZWFsLTQwMFwiPlxyXG4gICAgICAgICAgICAgICAgQWx0ZXJhIG8gc3RhdHVzIGRhIGRlbsO6bmNpYSBwYXJhIFwiRW0gQXB1cmHDp8OjbyBGaXNjYWxcIiBuYSBmaWxhIGRlIGZpc2NhbGl6YcOnw6NvLlxyXG4gICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXHJcbiAgICAgICAgICAgICAgey4uLnJlZ2lzdGVyKFwiaW5pY2lhcl9hcHVyYWNhb1wiKX1cclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtdGVhbC02MDAgcm91bmRlZCBib3JkZXItc2xhdGUtMzAwIGZvY3VzOnJpbmctdGVhbC01MDBcIlxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgey8qIEJvdMO1ZXMgZGUgQcOnw6NvICovfVxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWVuZCBnYXAtMi41IHB0LTMgYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTEwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDBcIj5cclxuICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgIG9uQ2xpY2s9e29uQ2xvc2V9XHJcbiAgICAgICAgICAgICAgZGlzYWJsZWQ9e2lzU3VibWl0dGluZ31cclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC00IHB5LTIgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNjAwIGRhcms6dGV4dC1zbGF0ZS0zMDAgaG92ZXI6Ymctc2xhdGUtMTAwIGRhcms6aG92ZXI6Ymctc2xhdGUtODAwIHJvdW5kZWQtbGcgdHJhbnNpdGlvbi1jb2xvcnNcIlxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgQ2FuY2VsYXJcclxuICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcclxuICAgICAgICAgICAgICBkaXNhYmxlZD17aXNTdWJtaXR0aW5nfVxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTUgcHktMiB0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXdoaXRlIGJnLXRlYWwtNjAwIGhvdmVyOmJnLXRlYWwtNzAwIHJvdW5kZWQtbGcgc2hhZG93LXhzIHRyYW5zaXRpb24tY29sb3JzIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yIGRpc2FibGVkOm9wYWNpdHktNjBcIlxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgPFNlbmQgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+XHJcbiAgICAgICAgICAgICAgPHNwYW4+e2lzU3VibWl0dGluZyA/IFwiRGVzcGFjaGFuZG8uLi5cIiA6IFwiQ29uZmlybWFyIERlc3BhY2hvXCJ9PC9zcGFuPlxyXG4gICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZm9ybT5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgTW9kYWxEZXNwYWNob0Zpc2NhbDtcclxuIl19