import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/estabelecimentos/EstabelecimentoDetailPage.tsx");const React = __vite__cjsImport0_react;const _jsxDEV = __vite__cjsImport8_react_jsxDevRuntime["jsxDEV"];/**
* Ficha Cadastral e Detalhamento Integral do Estabelecimento (EstabelecimentoDetailPage)
* Apresenta dados cadastrais, atividades CNAE, representante legal, parâmetros de água e alvará.
*/
import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=0fd2848a";
import { Link, useNavigate, useParams } from "/node_modules/.vite/deps/react-router-dom.js?v=0fd2848a";
import { ArrowLeft, Building2, ClipboardCheck, Droplets, Edit, FileCheck, Mail, MapPin, Phone, Shield, User } from "/node_modules/.vite/deps/lucide-react.js?v=0fd2848a";
import RiscoBadge from "/src/components/estabelecimentos/RiscoBadge.tsx";
import SituacaoAlvaraBadge from "/src/components/estabelecimentos/SituacaoAlvaraBadge.tsx";
import { useEstabelecimentoDetalhe } from "/src/hooks/useEstabelecimentos.ts";
import { APP_CONFIG } from "/src/config/app.config.ts";
import { ROUTES } from "/src/config/routes.config.ts";
var _jsxFileName = "E:/Projetos VSCODE/visa_braunas/src/pages/estabelecimentos/EstabelecimentoDetailPage.tsx";
import __vite__cjsImport8_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=0fd2848a";
var _s = $RefreshSig$();
export const EstabelecimentoDetailPage = () => {
	_s();
	const { id } = useParams();
	const navigate = useNavigate();
	const { data: estab, isLoading, error } = useEstabelecimentoDetalhe(id);
	if (isLoading) {
		return /* @__PURE__ */ _jsxDEV("div", {
			className: "p-16 text-center text-xs text-slate-400 flex flex-col items-center justify-center",
			children: [/* @__PURE__ */ _jsxDEV("div", { className: "w-6 h-6 border-2 border-teal-500 border-t-transparent rounded-full animate-spin mb-3" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 40,
				columnNumber: 9
			}, this), "Carregando ficha cadastral do estabelecimento..."]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 39,
			columnNumber: 7
		}, this);
	}
	if (error || !estab) {
		return /* @__PURE__ */ _jsxDEV("div", {
			className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-8 text-center space-y-4",
			children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "w-12 h-12 rounded-full bg-rose-50 text-rose-600 flex items-center justify-center mx-auto",
					children: /* @__PURE__ */ _jsxDEV(Building2, { className: "w-6 h-6" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 50,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 49,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("h2", {
					className: "text-base font-semibold text-slate-900 dark:text-white",
					children: "Estabelecimento não encontrado"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 52,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("p", {
					className: "text-xs text-slate-500 max-w-sm mx-auto",
					children: [
						"Não foi possível localizar o estabelecimento solicitado no banco de dados da ",
						APP_CONFIG.orgao,
						"."
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 55,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					onClick: () => navigate(ROUTES.ESTABELECIMENTOS.LIST),
					className: "inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 bg-slate-100 rounded-lg hover:bg-slate-200",
					children: [/* @__PURE__ */ _jsxDEV(ArrowLeft, { className: "w-3.5 h-3.5" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 63,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Voltar para a listagem" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 64,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 58,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 48,
			columnNumber: 7
		}, this);
	}
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "space-y-6",
		children: [/* @__PURE__ */ _jsxDEV("div", {
			className: "flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 shadow-xs",
			children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "space-y-1.5",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						onClick: () => navigate(ROUTES.ESTABELECIMENTOS.LIST),
						className: "p-1 text-slate-400 hover:text-slate-600 dark:hover:text-white rounded",
						title: "Voltar",
						children: /* @__PURE__ */ _jsxDEV(ArrowLeft, { className: "w-4 h-4" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 82,
							columnNumber: 15
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 76,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("h1", {
						className: "text-xl font-bold text-slate-900 dark:text-white",
						children: estab.razao_social
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 84,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 75,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "flex flex-wrap items-center gap-2 text-xs text-slate-500 dark:text-slate-400 ml-6",
					children: [
						/* @__PURE__ */ _jsxDEV("span", {
							className: "font-mono font-semibold text-slate-700 dark:text-slate-300",
							children: estab.cnpj_cpf
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 89,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("span", {
							"aria-hidden": "true",
							children: "·"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 92,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("span", { children: estab.nome_fantasia || "Sem Nome Fantasia" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 93,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("span", {
							"aria-hidden": "true",
							children: "·"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 94,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV(RiscoBadge, { risco: estab.nivel_risco }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 95,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("span", {
							"aria-hidden": "true",
							children: "·"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 96,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV(SituacaoAlvaraBadge, { situacao: estab.situacao_alvara }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 97,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 88,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 74,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("div", {
				className: "flex items-center gap-2",
				children: [/* @__PURE__ */ _jsxDEV(Link, {
					to: ROUTES.ESTABELECIMENTOS.EDITAR(estab.id),
					className: "inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 rounded-lg transition-colors",
					children: [/* @__PURE__ */ _jsxDEV(Edit, { className: "w-3.5 h-3.5" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 106,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Editar" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 107,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 102,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV(Link, {
					to: `${ROUTES.INSPECOES.LIST}?estabelecimento_id=${estab.id}`,
					className: "inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-white bg-teal-600 hover:bg-teal-500 rounded-lg shadow-xs transition-colors",
					children: [/* @__PURE__ */ _jsxDEV(ClipboardCheck, { className: "w-3.5 h-3.5" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 114,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Ver Vistorias" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 115,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 110,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 101,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 73,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "grid grid-cols-1 lg:grid-cols-3 gap-6",
			children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "lg:col-span-2 space-y-6",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-xs space-y-4",
					children: [/* @__PURE__ */ _jsxDEV("h2", {
						className: "text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider flex items-center gap-2 pb-2 border-b border-slate-100 dark:border-slate-800",
						children: [/* @__PURE__ */ _jsxDEV(Building2, { className: "w-4 h-4 text-teal-600" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 127,
							columnNumber: 15
						}, this), "Identificação & Localização"]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 126,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs",
						children: [
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-slate-400 block text-[11px]",
								children: "Tipo de Cadastro"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 133,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "font-semibold text-slate-800 dark:text-slate-200",
								children: estab.tipo_cadastro === "PJ" ? "Pessoa Jurídica (PJ)" : "Pessoa Física (PF)"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 134,
								columnNumber: 17
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 132,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-slate-400 block text-[11px]",
								children: "Inscrição Municipal"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 140,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "font-semibold text-slate-800 dark:text-slate-200 font-mono",
								children: estab.inscricao_municipal || "Não informada"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 141,
								columnNumber: 17
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 139,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-slate-400 block text-[11px]",
								children: "Natureza Jurídica"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 147,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "font-semibold text-slate-800 dark:text-slate-200",
								children: estab.natureza_juridica || "Não informada"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 148,
								columnNumber: 17
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 146,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-slate-400 block text-[11px]",
								children: "Competência de Fiscalização"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 154,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "font-semibold text-slate-800 dark:text-slate-200",
								children: estab.competencia_fiscalizacao
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 155,
								columnNumber: 17
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 153,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "sm:col-span-2 pt-2 border-t border-slate-100 dark:border-slate-800",
								children: [
									/* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-400 block text-[11px]",
										children: "Endereço Sanitário Completo"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 161,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("span", {
										className: "font-semibold text-slate-800 dark:text-slate-200 block mt-0.5",
										children: [
											estab.logradouro,
											", ",
											estab.numero,
											estab.complemento ? ` - ${estab.complemento}` : ""
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 162,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-500 dark:text-slate-400 text-[11px]",
										children: [
											"Bairro ",
											estab.bairro,
											" · CEP ",
											estab.cep,
											" · ",
											estab.municipio,
											"/",
											estab.uf
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 166,
										columnNumber: 17
									}, this),
									estab.ponto_referencia && /* @__PURE__ */ _jsxDEV("p", {
										className: "text-[11px] text-slate-500 mt-1 italic",
										children: ["Referência: ", estab.ponto_referencia]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 170,
										columnNumber: 19
									}, this),
									estab.acesso_compartilhado_residencia && /* @__PURE__ */ _jsxDEV("div", {
										className: "mt-2 text-amber-700 bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 px-2.5 py-1 rounded text-[11px]",
										children: "Atenção: Estabelecimento com acesso compartilhado com residência unifamiliar."
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 175,
										columnNumber: 19
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 160,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-slate-400 block text-[11px]",
								children: "Telefone Principal"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 182,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "font-semibold text-slate-800 dark:text-slate-200 font-mono",
								children: estab.telefone_celular
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 183,
								columnNumber: 17
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 181,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-slate-400 block text-[11px]",
								children: "E-mail de Contato"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 189,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "font-semibold text-slate-800 dark:text-slate-200",
								children: estab.email
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 190,
								columnNumber: 17
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 188,
								columnNumber: 15
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 131,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 125,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-xs space-y-4",
					children: [/* @__PURE__ */ _jsxDEV("h2", {
						className: "text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider flex items-center gap-2 pb-2 border-b border-slate-100 dark:border-slate-800",
						children: [/* @__PURE__ */ _jsxDEV(Shield, { className: "w-4 h-4 text-teal-600" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 200,
							columnNumber: 15
						}, this), "Atividades Econômicas Reguladas (CNAEs)"]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 199,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "divide-y divide-slate-100 dark:divide-slate-800 text-xs",
						children: estab.cnaes.map((vinculo) => /* @__PURE__ */ _jsxDEV("div", {
							className: "py-3 first:pt-0 last:pb-0 space-y-1",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center justify-between gap-2",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center gap-2",
										children: [/* @__PURE__ */ _jsxDEV("span", {
											className: "font-mono font-bold text-slate-900 dark:text-white",
											children: vinculo.cnae_codigo
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 209,
											columnNumber: 23
										}, this), vinculo.eh_principal && /* @__PURE__ */ _jsxDEV("span", {
											className: "text-[10px] font-semibold bg-teal-100 dark:bg-teal-950 text-teal-800 dark:text-teal-300 px-1.5 py-0.5 rounded",
											children: "CNAE Principal"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 213,
											columnNumber: 25
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 208,
										columnNumber: 21
									}, this), vinculo.cnae && /* @__PURE__ */ _jsxDEV(RiscoBadge, {
										risco: vinculo.cnae.grau_risco_padrao,
										size: "sm"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 219,
										columnNumber: 23
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 207,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("p", {
									className: "text-slate-600 dark:text-slate-300 text-[11px]",
									children: vinculo.cnae?.descricao || "Descrição da atividade econômica"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 223,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center gap-3 text-[10px] text-slate-400 pt-0.5",
									children: [
										vinculo.cnae?.exige_rt && /* @__PURE__ */ _jsxDEV("span", {
											className: "text-amber-600 font-medium",
											children: "Exige RT"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 229,
											columnNumber: 23
										}, this),
										vinculo.cnae?.exige_projeto_arquitetonico && /* @__PURE__ */ _jsxDEV("span", {
											className: "text-blue-600 font-medium",
											children: "Exige Projeto Arq."
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 232,
											columnNumber: 23
										}, this),
										vinculo.data_inicio_atividade && /* @__PURE__ */ _jsxDEV("span", { children: ["Início: ", vinculo.data_inicio_atividade] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 235,
											columnNumber: 23
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 227,
									columnNumber: 19
								}, this)
							]
						}, vinculo.id || vinculo.cnae_codigo, true, {
							fileName: _jsxFileName,
							lineNumber: 206,
							columnNumber: 17
						}, this))
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 204,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 198,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 123,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("div", {
				className: "space-y-6",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-xs space-y-3",
						children: [/* @__PURE__ */ _jsxDEV("h2", {
							className: "text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider flex items-center gap-2 pb-2 border-b border-slate-100 dark:border-slate-800",
							children: [/* @__PURE__ */ _jsxDEV(FileCheck, { className: "w-4 h-4 text-teal-600" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 249,
								columnNumber: 15
							}, this), "Licenciamento Sanitário"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 248,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-2 text-xs",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center justify-between",
									children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-400",
										children: "Situação:"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 255,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV(SituacaoAlvaraBadge, { situacao: estab.situacao_alvara }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 256,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 254,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center justify-between",
									children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-400",
										children: "Número do Alvará:"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 260,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: "font-mono font-semibold text-slate-800 dark:text-slate-200",
										children: estab.numero_alvara || "Não emitido"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 261,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 259,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center justify-between",
									children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-400",
										children: "Validade:"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 267,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: "font-semibold text-slate-800 dark:text-slate-200",
										children: estab.data_validade_alvara || "—"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 268,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 266,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 253,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 247,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-xs space-y-3",
						children: [/* @__PURE__ */ _jsxDEV("h2", {
							className: "text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider flex items-center gap-2 pb-2 border-b border-slate-100 dark:border-slate-800",
							children: [/* @__PURE__ */ _jsxDEV(User, { className: "w-4 h-4 text-teal-600" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 278,
								columnNumber: 15
							}, this), "Representante Legal"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 277,
							columnNumber: 13
						}, this), estab.representante_legal ? /* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-2 text-xs",
							children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "font-semibold text-slate-900 dark:text-white block",
								children: estab.representante_legal.nome_completo
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 285,
								columnNumber: 19
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "text-[11px] font-mono text-slate-400",
								children: ["CPF: ", estab.representante_legal.cpf]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 288,
								columnNumber: 19
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 284,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "text-[11px] text-slate-600 dark:text-slate-300 space-y-0.5",
								children: [
									/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center gap-1.5",
										children: [/* @__PURE__ */ _jsxDEV(Phone, { className: "w-3 h-3 text-slate-400" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 295,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("span", { children: estab.representante_legal.telefone }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 296,
											columnNumber: 21
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 294,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center gap-1.5",
										children: [/* @__PURE__ */ _jsxDEV(Mail, { className: "w-3 h-3 text-slate-400" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 299,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("span", { children: estab.representante_legal.email }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 300,
											columnNumber: 21
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 298,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-start gap-1.5 pt-1",
										children: [/* @__PURE__ */ _jsxDEV(MapPin, { className: "w-3 h-3 text-slate-400 shrink-0 mt-0.5" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 303,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("span", {
											className: "text-[10px] leading-snug",
											children: estab.representante_legal.endereco_residencial
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 304,
											columnNumber: 21
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 302,
										columnNumber: 19
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 293,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 283,
							columnNumber: 15
						}, this) : /* @__PURE__ */ _jsxDEV("p", {
							className: "text-xs text-slate-400",
							children: "Nenhum representante legal associado."
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 311,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 276,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-xs space-y-3",
						children: [/* @__PURE__ */ _jsxDEV("h2", {
							className: "text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider flex items-center gap-2 pb-2 border-b border-slate-100 dark:border-slate-800",
							children: [/* @__PURE__ */ _jsxDEV(Droplets, { className: "w-4 h-4 text-teal-600" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 320,
								columnNumber: 15
							}, this), "Saneamento & Infraestrutura"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 319,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-2 text-xs",
							children: [
								/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "text-slate-400 block text-[11px]",
									children: "Fonte de Abastecimento"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 326,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("span", {
									className: "font-semibold text-slate-800 dark:text-slate-200",
									children: estab.fonte_abastecimento_agua || "Rede Pública"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 327,
									columnNumber: 17
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 325,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "text-slate-400 block text-[11px]",
									children: "Reservatório Próprio"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 333,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("span", {
									className: "font-semibold text-slate-800 dark:text-slate-200",
									children: estab.possui_reservatorio_proprio ? `Sim (${estab.capacidade_reservatorio_litros} L)` : "Não possui reservatório próprio"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 334,
									columnNumber: 17
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 332,
									columnNumber: 15
								}, this),
								estab.horario_funcionamento && /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "text-slate-400 block text-[11px]",
									children: "Horário de Funcionamento"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 343,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("span", {
									className: "font-semibold text-slate-800 dark:text-slate-200",
									children: estab.horario_funcionamento
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 344,
									columnNumber: 19
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 342,
									columnNumber: 17
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 324,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 318,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 245,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 121,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 71,
		columnNumber: 5
	}, this);
};
_s(EstabelecimentoDetailPage, "66ueE6xap1BrJx/3MZ6m3xhJh/c=", false, function() {
	return [
		useParams,
		useNavigate,
		useEstabelecimentoDetalhe
	];
});
_c = EstabelecimentoDetailPage;
export default EstabelecimentoDetailPage;
var _c;
$RefreshReg$(_c, "EstabelecimentoDetailPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/estabelecimentos/EstabelecimentoDetailPage.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("E:/Projetos VSCODE/visa_braunas/src/pages/estabelecimentos/EstabelecimentoDetailPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("E:/Projetos VSCODE/visa_braunas/src/pages/estabelecimentos/EstabelecimentoDetailPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "E:/Projetos VSCODE/visa_braunas/src/pages/estabelecimentos/EstabelecimentoDetailPage.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7OztBQUtBLE9BQU8sV0FBVztBQUNsQixTQUFTLE1BQU0sYUFBYSxpQkFBaUI7QUFDN0MsU0FDRSxXQUNBLFdBR0EsZ0JBQ0EsVUFDQSxNQUNBLFdBQ0EsTUFDQSxRQUNBLE9BQ0EsUUFFQSxZQUVLO0FBQ1AsT0FBTyxnQkFBZ0I7QUFDdkIsT0FBTyx5QkFBeUI7QUFDaEMsU0FBUyxpQ0FBaUM7QUFDMUMsU0FBUyxrQkFBa0I7QUFDM0IsU0FBUyxjQUFjOzs7O0FBRXZCLE9BQU8sTUFBTSxrQ0FBNEM7O0NBQ3ZELE1BQU0sRUFBRSxPQUFPLFVBQTBCO0NBQ3pDLE1BQU0sV0FBVyxZQUFZO0NBRTdCLE1BQU0sRUFBRSxNQUFNLE9BQU8sV0FBVyxVQUFVLDBCQUEwQixFQUFFO0NBRXRFLElBQUksV0FBVztFQUNiLE9BQ0Usd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZixDQUNFLHdCQUFDLE9BQUQsRUFBSyxXQUFVLHVGQUF3Rjs7OzthQUFDLGtEQUVyRzs7Ozs7O0NBRVQ7Q0FFQSxJQUFJLFNBQVMsQ0FBQyxPQUFPO0VBQ25CLE9BQ0Usd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZjtJQUNFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQ2Isd0JBQUMsV0FBRCxFQUFXLFdBQVUsVUFBVzs7Ozs7SUFDN0I7Ozs7O0lBQ0wsd0JBQUMsTUFBRDtLQUFJLFdBQVU7ZUFBeUQ7SUFFbkU7Ozs7O0lBQ0osd0JBQUMsS0FBRDtLQUFHLFdBQVU7ZUFBYjtNQUF1RDtNQUN5QixXQUFXO01BQU07S0FDOUY7Ozs7OztJQUNILHdCQUFDLFVBQUQ7S0FDRSxNQUFLO0tBQ0wsZUFBZSxTQUFTLE9BQU8saUJBQWlCLElBQUk7S0FDcEQsV0FBVTtlQUhaLENBS0Usd0JBQUMsV0FBRCxFQUFXLFdBQVUsY0FBZTs7OztlQUNwQyx3QkFBQyxRQUFELFlBQU0seUJBQTRCOzs7O2FBQzVCOzs7Ozs7R0FDTDs7Ozs7O0NBRVQ7Q0FFQSxPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQWYsQ0FFRSx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmLENBQ0Usd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxVQUFEO01BQ0UsTUFBSztNQUNMLGVBQWUsU0FBUyxPQUFPLGlCQUFpQixJQUFJO01BQ3BELFdBQVU7TUFDVixPQUFNO2dCQUVOLHdCQUFDLFdBQUQsRUFBVyxXQUFVLFVBQVc7Ozs7O0tBQzFCOzs7O2VBQ1Isd0JBQUMsTUFBRDtNQUFJLFdBQVU7Z0JBQ1gsTUFBTTtLQUNMOzs7O2FBQ0Q7Ozs7O2NBQ0wsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZjtNQUNFLHdCQUFDLFFBQUQ7T0FBTSxXQUFVO2lCQUNiLE1BQU07TUFDSDs7Ozs7TUFDTix3QkFBQyxRQUFEO09BQU0sZUFBWTtpQkFBTztNQUFPOzs7OztNQUNoQyx3QkFBQyxRQUFELFlBQU8sTUFBTSxpQkFBaUIsb0JBQTBCOzs7OztNQUN4RCx3QkFBQyxRQUFEO09BQU0sZUFBWTtpQkFBTztNQUFPOzs7OztNQUNoQyx3QkFBQyxZQUFELEVBQVksT0FBTyxNQUFNLFlBQWM7Ozs7O01BQ3ZDLHdCQUFDLFFBQUQ7T0FBTSxlQUFZO2lCQUFPO01BQU87Ozs7O01BQ2hDLHdCQUFDLHFCQUFELEVBQXFCLFVBQVUsTUFBTSxnQkFBa0I7Ozs7O0tBQ3BEOzs7OztZQUNGOzs7OzthQUVMLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxNQUFEO0tBQ0UsSUFBSSxPQUFPLGlCQUFpQixPQUFPLE1BQU0sRUFBRTtLQUMzQyxXQUFVO2VBRlosQ0FJRSx3QkFBQyxNQUFELEVBQU0sV0FBVSxjQUFlOzs7O2VBQy9CLHdCQUFDLFFBQUQsWUFBTSxTQUFZOzs7O2FBQ2Q7Ozs7O2NBRU4sd0JBQUMsTUFBRDtLQUNFLElBQUksR0FBRyxPQUFPLFVBQVUsS0FBSyxzQkFBc0IsTUFBTTtLQUN6RCxXQUFVO2VBRlosQ0FJRSx3QkFBQyxnQkFBRCxFQUFnQixXQUFVLGNBQWU7Ozs7ZUFDekMsd0JBQUMsUUFBRCxZQUFNLGdCQUFtQjs7OzthQUNyQjs7Ozs7WUFDSDs7Ozs7V0FDRjs7Ozs7WUFHTCx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmLENBRUUsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUVFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxNQUFEO01BQUksV0FBVTtnQkFBZCxDQUNFLHdCQUFDLFdBQUQsRUFBVyxXQUFVLHdCQUF5Qjs7OztnQkFBQyw2QkFFN0M7Ozs7O2VBRUosd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWY7T0FDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQW1DO09BQXNCOzs7O2lCQUN6RSx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFDYixNQUFNLGtCQUFrQixPQUFPLHlCQUF5QjtPQUNyRDs7OztlQUNIOzs7OztPQUVMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBbUM7T0FBeUI7Ozs7aUJBQzVFLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUNiLE1BQU0sdUJBQXVCO09BQzFCOzs7O2VBQ0g7Ozs7O09BRUwsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUFtQztPQUF1Qjs7OztpQkFDMUUsd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQ2IsTUFBTSxxQkFBcUI7T0FDeEI7Ozs7ZUFDSDs7Ozs7T0FFTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQW1DO09BQWlDOzs7O2lCQUNwRix3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFDYixNQUFNO09BQ0g7Ozs7ZUFDSDs7Ozs7T0FFTCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZjtTQUNFLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUFtQztTQUFpQzs7Ozs7U0FDcEYsd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQWhCO1dBQ0csTUFBTTtXQUFXO1dBQUcsTUFBTTtXQUMxQixNQUFNLGNBQWMsTUFBTSxNQUFNLGdCQUFnQjtVQUM3Qzs7Ozs7O1NBQ04sd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQWhCO1dBQWlFO1dBQ3ZELE1BQU07V0FBTztXQUFRLE1BQU07V0FBSTtXQUFJLE1BQU07V0FBVTtXQUFFLE1BQU07VUFDL0Q7Ozs7OztTQUNMLE1BQU0sb0JBQ0wsd0JBQUMsS0FBRDtVQUFHLFdBQVU7b0JBQWIsQ0FBc0QsZ0JBQ3ZDLE1BQU0sZ0JBQ2xCOzs7Ozs7U0FFSixNQUFNLG1DQUNMLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFxSTtTQUUvSTs7Ozs7UUFFSjs7Ozs7O09BRUwsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUFtQztPQUF3Qjs7OztpQkFDM0Usd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQ2IsTUFBTTtPQUNIOzs7O2VBQ0g7Ozs7O09BRUwsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUFtQztPQUF1Qjs7OztpQkFDMUUsd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQ2IsTUFBTTtPQUNIOzs7O2VBQ0g7Ozs7O01BQ0Y7Ozs7O2FBQ0Y7Ozs7O2NBR0wsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLE1BQUQ7TUFBSSxXQUFVO2dCQUFkLENBQ0Usd0JBQUMsUUFBRCxFQUFRLFdBQVUsd0JBQXlCOzs7O2dCQUFDLHlDQUUxQzs7Ozs7ZUFFSix3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFDWixNQUFNLE1BQU0sS0FBSyxZQUNoQix3QkFBQyxPQUFEO09BQTZDLFdBQVU7aUJBQXZEO1FBQ0Usd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDRSx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNFLHdCQUFDLFFBQUQ7V0FBTSxXQUFVO3FCQUNiLFFBQVE7VUFDTDs7OztvQkFDTCxRQUFRLGdCQUNQLHdCQUFDLFFBQUQ7V0FBTSxXQUFVO3FCQUFnSDtVQUUxSDs7OztrQkFFTDs7Ozs7bUJBQ0osUUFBUSxRQUNQLHdCQUFDLFlBQUQ7VUFBWSxPQUFPLFFBQVEsS0FBSztVQUFtQixNQUFLO1NBQU07Ozs7aUJBRTdEOzs7Ozs7UUFFTCx3QkFBQyxLQUFEO1NBQUcsV0FBVTttQkFDVixRQUFRLE1BQU0sYUFBYTtRQUMzQjs7Ozs7UUFFSCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZjtVQUNHLFFBQVEsTUFBTSxZQUNiLHdCQUFDLFFBQUQ7V0FBTSxXQUFVO3FCQUE2QjtVQUFjOzs7OztVQUU1RCxRQUFRLE1BQU0sK0JBQ2Isd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQTRCO1VBQXdCOzs7OztVQUVyRSxRQUFRLHlCQUNQLHdCQUFDLFFBQUQsYUFBTSxZQUFTLFFBQVEscUJBQTRCOzs7OztTQUVsRDs7Ozs7O09BQ0Y7U0FoQ0ssUUFBUSxNQUFNLFFBQVE7Ozs7YUFnQzNCLENBQ047S0FDRTs7OzthQUNGOzs7OztZQUNGOzs7OzthQUdMLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWY7S0FFRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLE1BQUQ7T0FBSSxXQUFVO2lCQUFkLENBQ0Usd0JBQUMsV0FBRCxFQUFXLFdBQVUsd0JBQXlCOzs7O2lCQUFDLHlCQUU3Qzs7Ozs7Z0JBRUosd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWY7UUFDRSx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUFpQjtTQUFlOzs7O21CQUNoRCx3QkFBQyxxQkFBRCxFQUFxQixVQUFVLE1BQU0sZ0JBQWtCOzs7O2lCQUNwRDs7Ozs7O1FBRUwsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDRSx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBaUI7U0FBdUI7Ozs7bUJBQ3hELHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUNiLE1BQU0saUJBQWlCO1NBQ3BCOzs7O2lCQUNIOzs7Ozs7UUFFTCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUFpQjtTQUFlOzs7O21CQUNoRCx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFDYixNQUFNLHdCQUF3QjtTQUMzQjs7OztpQkFDSDs7Ozs7O09BQ0Y7Ozs7O2NBQ0Y7Ozs7OztLQUdMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQWQsQ0FDRSx3QkFBQyxNQUFELEVBQU0sV0FBVSx3QkFBeUI7Ozs7aUJBQUMscUJBRXhDOzs7OztnQkFFSCxNQUFNLHNCQUNMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUNiLE1BQU0sb0JBQW9CO09BQ3ZCOzs7O2lCQUNOLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUFoQixDQUF1RCxTQUMvQyxNQUFNLG9CQUFvQixHQUM1Qjs7Ozs7ZUFDSDs7OztpQkFFTCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZjtTQUNFLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmLENBQ0Usd0JBQUMsT0FBRCxFQUFPLFdBQVUseUJBQTBCOzs7O29CQUMzQyx3QkFBQyxRQUFELFlBQU8sTUFBTSxvQkFBb0IsU0FBZTs7OztrQkFDN0M7Ozs7OztTQUNMLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmLENBQ0Usd0JBQUMsTUFBRCxFQUFNLFdBQVUseUJBQTBCOzs7O29CQUMxQyx3QkFBQyxRQUFELFlBQU8sTUFBTSxvQkFBb0IsTUFBWTs7OztrQkFDMUM7Ozs7OztTQUNMLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmLENBQ0Usd0JBQUMsUUFBRCxFQUFRLFdBQVUseUNBQTBDOzs7O29CQUM1RCx3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFDYixNQUFNLG9CQUFvQjtVQUN2Qjs7OztrQkFDSDs7Ozs7O1FBQ0Y7Ozs7O2VBQ0Y7Ozs7O2lCQUVMLHdCQUFDLEtBQUQ7T0FBRyxXQUFVO2lCQUF5QjtNQUVuQzs7OztjQUVGOzs7Ozs7S0FHTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLE1BQUQ7T0FBSSxXQUFVO2lCQUFkLENBQ0Usd0JBQUMsVUFBRCxFQUFVLFdBQVUsd0JBQXlCOzs7O2lCQUFDLDZCQUU1Qzs7Ozs7Z0JBRUosd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWY7UUFDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQW1DO1FBQTRCOzs7O2tCQUMvRSx3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFDYixNQUFNLDRCQUE0QjtRQUMvQjs7OztnQkFDSDs7Ozs7UUFFTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQW1DO1FBQTBCOzs7O2tCQUM3RSx3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFDYixNQUFNLDhCQUNILFFBQVEsTUFBTSwrQkFBK0IsT0FDN0M7UUFDQTs7OztnQkFDSDs7Ozs7UUFFSixNQUFNLHlCQUNMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFBbUM7UUFBOEI7Ozs7a0JBQ2pGLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUNiLE1BQU07UUFDSDs7OztnQkFDSDs7Ozs7T0FFSjs7Ozs7Y0FDRjs7Ozs7O0lBQ0Y7Ozs7O1dBQ0Y7Ozs7O1VBQ0Y7Ozs7OztBQUVUOzs7Ozs7Ozs7QUFFQSxlQUFlIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkVzdGFiZWxlY2ltZW50b0RldGFpbFBhZ2UudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbIi8qKlxyXG4gKiBGaWNoYSBDYWRhc3RyYWwgZSBEZXRhbGhhbWVudG8gSW50ZWdyYWwgZG8gRXN0YWJlbGVjaW1lbnRvIChFc3RhYmVsZWNpbWVudG9EZXRhaWxQYWdlKVxyXG4gKiBBcHJlc2VudGEgZGFkb3MgY2FkYXN0cmFpcywgYXRpdmlkYWRlcyBDTkFFLCByZXByZXNlbnRhbnRlIGxlZ2FsLCBwYXLDom1ldHJvcyBkZSDDoWd1YSBlIGFsdmFyw6EuXHJcbiAqL1xyXG5cclxuaW1wb3J0IFJlYWN0IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgeyBMaW5rLCB1c2VOYXZpZ2F0ZSwgdXNlUGFyYW1zIH0gZnJvbSBcInJlYWN0LXJvdXRlci1kb21cIjtcclxuaW1wb3J0IHtcclxuICBBcnJvd0xlZnQsXHJcbiAgQnVpbGRpbmcyLFxyXG4gIENhbGVuZGFyLFxyXG4gIENoZWNrQ2lyY2xlMixcclxuICBDbGlwYm9hcmRDaGVjayxcclxuICBEcm9wbGV0cyxcclxuICBFZGl0LFxyXG4gIEZpbGVDaGVjayxcclxuICBNYWlsLFxyXG4gIE1hcFBpbixcclxuICBQaG9uZSxcclxuICBTaGllbGQsXHJcbiAgU2hpZWxkQWxlcnQsXHJcbiAgVXNlcixcclxuICBVc2VycyxcclxufSBmcm9tIFwibHVjaWRlLXJlYWN0XCI7XHJcbmltcG9ydCBSaXNjb0JhZGdlIGZyb20gXCIuLi8uLi9jb21wb25lbnRzL2VzdGFiZWxlY2ltZW50b3MvUmlzY29CYWRnZVwiO1xyXG5pbXBvcnQgU2l0dWFjYW9BbHZhcmFCYWRnZSBmcm9tIFwiLi4vLi4vY29tcG9uZW50cy9lc3RhYmVsZWNpbWVudG9zL1NpdHVhY2FvQWx2YXJhQmFkZ2VcIjtcclxuaW1wb3J0IHsgdXNlRXN0YWJlbGVjaW1lbnRvRGV0YWxoZSB9IGZyb20gXCIuLi8uLi9ob29rcy91c2VFc3RhYmVsZWNpbWVudG9zXCI7XHJcbmltcG9ydCB7IEFQUF9DT05GSUcgfSBmcm9tIFwiLi4vLi4vY29uZmlnL2FwcC5jb25maWdcIjtcclxuaW1wb3J0IHsgUk9VVEVTIH0gZnJvbSBcIi4uLy4uL2NvbmZpZy9yb3V0ZXMuY29uZmlnXCI7XHJcblxyXG5leHBvcnQgY29uc3QgRXN0YWJlbGVjaW1lbnRvRGV0YWlsUGFnZTogUmVhY3QuRkMgPSAoKSA9PiB7XHJcbiAgY29uc3QgeyBpZCB9ID0gdXNlUGFyYW1zPHsgaWQ6IHN0cmluZyB9PigpO1xyXG4gIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKTtcclxuXHJcbiAgY29uc3QgeyBkYXRhOiBlc3RhYiwgaXNMb2FkaW5nLCBlcnJvciB9ID0gdXNlRXN0YWJlbGVjaW1lbnRvRGV0YWxoZShpZCk7XHJcblxyXG4gIGlmIChpc0xvYWRpbmcpIHtcclxuICAgIHJldHVybiAoXHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0xNiB0ZXh0LWNlbnRlciB0ZXh0LXhzIHRleHQtc2xhdGUtNDAwIGZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyXCI+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTYgaC02IGJvcmRlci0yIGJvcmRlci10ZWFsLTUwMCBib3JkZXItdC10cmFuc3BhcmVudCByb3VuZGVkLWZ1bGwgYW5pbWF0ZS1zcGluIG1iLTNcIiAvPlxyXG4gICAgICAgIENhcnJlZ2FuZG8gZmljaGEgY2FkYXN0cmFsIGRvIGVzdGFiZWxlY2ltZW50by4uLlxyXG4gICAgICA8L2Rpdj5cclxuICAgICk7XHJcbiAgfVxyXG5cclxuICBpZiAoZXJyb3IgfHwgIWVzdGFiKSB7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIGRhcms6Ymctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLXhsIHAtOCB0ZXh0LWNlbnRlciBzcGFjZS15LTRcIj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTIgaC0xMiByb3VuZGVkLWZ1bGwgYmctcm9zZS01MCB0ZXh0LXJvc2UtNjAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIG14LWF1dG9cIj5cclxuICAgICAgICAgIDxCdWlsZGluZzIgY2xhc3NOYW1lPVwidy02IGgtNlwiIC8+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtYmFzZSBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZVwiPlxyXG4gICAgICAgICAgRXN0YWJlbGVjaW1lbnRvIG7Do28gZW5jb250cmFkb1xyXG4gICAgICAgIDwvaDI+XHJcbiAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTUwMCBtYXgtdy1zbSBteC1hdXRvXCI+XHJcbiAgICAgICAgICBOw6NvIGZvaSBwb3Nzw612ZWwgbG9jYWxpemFyIG8gZXN0YWJlbGVjaW1lbnRvIHNvbGljaXRhZG8gbm8gYmFuY28gZGUgZGFkb3MgZGEge0FQUF9DT05GSUcub3JnYW99LlxyXG4gICAgICAgIDwvcD5cclxuICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG5hdmlnYXRlKFJPVVRFUy5FU1RBQkVMRUNJTUVOVE9TLkxJU1QpfVxyXG4gICAgICAgICAgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgcHgtMyBweS0xLjUgdGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LXNsYXRlLTcwMCBiZy1zbGF0ZS0xMDAgcm91bmRlZC1sZyBob3ZlcjpiZy1zbGF0ZS0yMDBcIlxyXG4gICAgICAgID5cclxuICAgICAgICAgIDxBcnJvd0xlZnQgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPlxyXG4gICAgICAgICAgPHNwYW4+Vm9sdGFyIHBhcmEgYSBsaXN0YWdlbTwvc3Bhbj5cclxuICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgPC9kaXY+XHJcbiAgICApO1xyXG4gIH1cclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS02XCI+XHJcbiAgICAgIHsvKiBCYXJyYSBTdXBlcmlvciBkZSBOYXZlZ2HDp8OjbyBlIEHDp8O1ZXMgKi99XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBzbTpmbGV4LXJvdyBzbTppdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC00IGJnLXdoaXRlIGRhcms6Ymctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLXhsIHAtNiBzaGFkb3cteHNcIj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMS41XCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBuYXZpZ2F0ZShST1VURVMuRVNUQUJFTEVDSU1FTlRPUy5MSVNUKX1cclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTEgdGV4dC1zbGF0ZS00MDAgaG92ZXI6dGV4dC1zbGF0ZS02MDAgZGFyazpob3Zlcjp0ZXh0LXdoaXRlIHJvdW5kZWRcIlxyXG4gICAgICAgICAgICAgIHRpdGxlPVwiVm9sdGFyXCJcclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIDxBcnJvd0xlZnQgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+XHJcbiAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC14bCBmb250LWJvbGQgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlXCI+XHJcbiAgICAgICAgICAgICAge2VzdGFiLnJhemFvX3NvY2lhbH1cclxuICAgICAgICAgICAgPC9oMT5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBpdGVtcy1jZW50ZXIgZ2FwLTIgdGV4dC14cyB0ZXh0LXNsYXRlLTUwMCBkYXJrOnRleHQtc2xhdGUtNDAwIG1sLTZcIj5cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tb25vIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTMwMFwiPlxyXG4gICAgICAgICAgICAgIHtlc3RhYi5jbnBqX2NwZn1cclxuICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICA8c3BhbiBhcmlhLWhpZGRlbj1cInRydWVcIj7Ctzwvc3Bhbj5cclxuICAgICAgICAgICAgPHNwYW4+e2VzdGFiLm5vbWVfZmFudGFzaWEgfHwgXCJTZW0gTm9tZSBGYW50YXNpYVwifTwvc3Bhbj5cclxuICAgICAgICAgICAgPHNwYW4gYXJpYS1oaWRkZW49XCJ0cnVlXCI+wrc8L3NwYW4+XHJcbiAgICAgICAgICAgIDxSaXNjb0JhZGdlIHJpc2NvPXtlc3RhYi5uaXZlbF9yaXNjb30gLz5cclxuICAgICAgICAgICAgPHNwYW4gYXJpYS1oaWRkZW49XCJ0cnVlXCI+wrc8L3NwYW4+XHJcbiAgICAgICAgICAgIDxTaXR1YWNhb0FsdmFyYUJhZGdlIHNpdHVhY2FvPXtlc3RhYi5zaXR1YWNhb19hbHZhcmF9IC8+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgPExpbmtcclxuICAgICAgICAgICAgdG89e1JPVVRFUy5FU1RBQkVMRUNJTUVOVE9TLkVESVRBUihlc3RhYi5pZCl9XHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHB4LTMgcHktMS41IHRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTIwMCBiZy1zbGF0ZS0xMDAgZGFyazpiZy1zbGF0ZS04MDAgaG92ZXI6Ymctc2xhdGUtMjAwIHJvdW5kZWQtbGcgdHJhbnNpdGlvbi1jb2xvcnNcIlxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICA8RWRpdCBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNVwiIC8+XHJcbiAgICAgICAgICAgIDxzcGFuPkVkaXRhcjwvc3Bhbj5cclxuICAgICAgICAgIDwvTGluaz5cclxuXHJcbiAgICAgICAgICA8TGlua1xyXG4gICAgICAgICAgICB0bz17YCR7Uk9VVEVTLklOU1BFQ09FUy5MSVNUfT9lc3RhYmVsZWNpbWVudG9faWQ9JHtlc3RhYi5pZH1gfVxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBweC0zLjUgcHktMS41IHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXdoaXRlIGJnLXRlYWwtNjAwIGhvdmVyOmJnLXRlYWwtNTAwIHJvdW5kZWQtbGcgc2hhZG93LXhzIHRyYW5zaXRpb24tY29sb3JzXCJcclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgPENsaXBib2FyZENoZWNrIGNsYXNzTmFtZT1cInctMy41IGgtMy41XCIgLz5cclxuICAgICAgICAgICAgPHNwYW4+VmVyIFZpc3Rvcmlhczwvc3Bhbj5cclxuICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICB7LyogR3JpZCBkZSBJbmZvcm1hw6fDtWVzIGVtIFNlw6fDtWVzICovfVxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbGc6Z3JpZC1jb2xzLTMgZ2FwLTZcIj5cclxuICAgICAgICB7LyogQ29sdW5hIDEgJiAyOiBJZGVudGlmaWNhw6fDo28gZSBBdGl2aWRhZGVzIENOQUUgKi99XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJsZzpjb2wtc3Bhbi0yIHNwYWNlLXktNlwiPlxyXG4gICAgICAgICAgey8qIENhcmQ6IERhZG9zIGRlIElkZW50aWZpY2HDp8OjbyAmIExvY2FsaXphw6fDo28gKi99XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIGRhcms6Ymctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLXhsIHAtNSBzaGFkb3cteHMgc3BhY2UteS00XCI+XHJcbiAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGUgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHBiLTIgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTEwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDBcIj5cclxuICAgICAgICAgICAgICA8QnVpbGRpbmcyIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC10ZWFsLTYwMFwiIC8+XHJcbiAgICAgICAgICAgICAgSWRlbnRpZmljYcOnw6NvICYgTG9jYWxpemHDp8Ojb1xyXG4gICAgICAgICAgICA8L2gyPlxyXG5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIHNtOmdyaWQtY29scy0yIGdhcC00IHRleHQteHNcIj5cclxuICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDAgYmxvY2sgdGV4dC1bMTFweF1cIj5UaXBvIGRlIENhZGFzdHJvPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTgwMCBkYXJrOnRleHQtc2xhdGUtMjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIHtlc3RhYi50aXBvX2NhZGFzdHJvID09PSBcIlBKXCIgPyBcIlBlc3NvYSBKdXLDrWRpY2EgKFBKKVwiIDogXCJQZXNzb2EgRsOtc2ljYSAoUEYpXCJ9XHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMCBibG9jayB0ZXh0LVsxMXB4XVwiPkluc2NyacOnw6NvIE11bmljaXBhbDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS04MDAgZGFyazp0ZXh0LXNsYXRlLTIwMCBmb250LW1vbm9cIj5cclxuICAgICAgICAgICAgICAgICAge2VzdGFiLmluc2NyaWNhb19tdW5pY2lwYWwgfHwgXCJOw6NvIGluZm9ybWFkYVwifVxyXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDAgYmxvY2sgdGV4dC1bMTFweF1cIj5OYXR1cmV6YSBKdXLDrWRpY2E8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtc2xhdGUtODAwIGRhcms6dGV4dC1zbGF0ZS0yMDBcIj5cclxuICAgICAgICAgICAgICAgICAge2VzdGFiLm5hdHVyZXphX2p1cmlkaWNhIHx8IFwiTsOjbyBpbmZvcm1hZGFcIn1cclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNDAwIGJsb2NrIHRleHQtWzExcHhdXCI+Q29tcGV0w6puY2lhIGRlIEZpc2NhbGl6YcOnw6NvPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTgwMCBkYXJrOnRleHQtc2xhdGUtMjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIHtlc3RhYi5jb21wZXRlbmNpYV9maXNjYWxpemFjYW99XHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic206Y29sLXNwYW4tMiBwdC0yIGJvcmRlci10IGJvcmRlci1zbGF0ZS0xMDAgZGFyazpib3JkZXItc2xhdGUtODAwXCI+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMCBibG9jayB0ZXh0LVsxMXB4XVwiPkVuZGVyZcOnbyBTYW5pdMOhcmlvIENvbXBsZXRvPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTgwMCBkYXJrOnRleHQtc2xhdGUtMjAwIGJsb2NrIG10LTAuNVwiPlxyXG4gICAgICAgICAgICAgICAgICB7ZXN0YWIubG9ncmFkb3Vyb30sIHtlc3RhYi5udW1lcm99XHJcbiAgICAgICAgICAgICAgICAgIHtlc3RhYi5jb21wbGVtZW50byA/IGAgLSAke2VzdGFiLmNvbXBsZW1lbnRvfWAgOiBcIlwifVxyXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS01MDAgZGFyazp0ZXh0LXNsYXRlLTQwMCB0ZXh0LVsxMXB4XVwiPlxyXG4gICAgICAgICAgICAgICAgICBCYWlycm8ge2VzdGFiLmJhaXJyb30gwrcgQ0VQIHtlc3RhYi5jZXB9IMK3IHtlc3RhYi5tdW5pY2lwaW99L3tlc3RhYi51Zn1cclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIHtlc3RhYi5wb250b19yZWZlcmVuY2lhICYmIChcclxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1zbGF0ZS01MDAgbXQtMSBpdGFsaWNcIj5cclxuICAgICAgICAgICAgICAgICAgICBSZWZlcsOqbmNpYToge2VzdGFiLnBvbnRvX3JlZmVyZW5jaWF9XHJcbiAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICB7ZXN0YWIuYWNlc3NvX2NvbXBhcnRpbGhhZG9fcmVzaWRlbmNpYSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LWFtYmVyLTcwMCBiZy1hbWJlci01MCBkYXJrOmJnLWFtYmVyLTk1MC80MCBib3JkZXIgYm9yZGVyLWFtYmVyLTIwMCBkYXJrOmJvcmRlci1hbWJlci04MDAgcHgtMi41IHB5LTEgcm91bmRlZCB0ZXh0LVsxMXB4XVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIEF0ZW7Dp8OjbzogRXN0YWJlbGVjaW1lbnRvIGNvbSBhY2Vzc28gY29tcGFydGlsaGFkbyBjb20gcmVzaWTDqm5jaWEgdW5pZmFtaWxpYXIuXHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNDAwIGJsb2NrIHRleHQtWzExcHhdXCI+VGVsZWZvbmUgUHJpbmNpcGFsPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTgwMCBkYXJrOnRleHQtc2xhdGUtMjAwIGZvbnQtbW9ub1wiPlxyXG4gICAgICAgICAgICAgICAgICB7ZXN0YWIudGVsZWZvbmVfY2VsdWxhcn1cclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNDAwIGJsb2NrIHRleHQtWzExcHhdXCI+RS1tYWlsIGRlIENvbnRhdG88L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtc2xhdGUtODAwIGRhcms6dGV4dC1zbGF0ZS0yMDBcIj5cclxuICAgICAgICAgICAgICAgICAge2VzdGFiLmVtYWlsfVxyXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIHsvKiBDYXJkOiBBdGl2aWRhZGVzIEVjb27DtG1pY2FzIChDTkFFcykgKi99XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIGRhcms6Ymctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLXhsIHAtNSBzaGFkb3cteHMgc3BhY2UteS00XCI+XHJcbiAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGUgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHBiLTIgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTEwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDBcIj5cclxuICAgICAgICAgICAgICA8U2hpZWxkIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC10ZWFsLTYwMFwiIC8+XHJcbiAgICAgICAgICAgICAgQXRpdmlkYWRlcyBFY29uw7RtaWNhcyBSZWd1bGFkYXMgKENOQUVzKVxyXG4gICAgICAgICAgICA8L2gyPlxyXG5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJkaXZpZGUteSBkaXZpZGUtc2xhdGUtMTAwIGRhcms6ZGl2aWRlLXNsYXRlLTgwMCB0ZXh0LXhzXCI+XHJcbiAgICAgICAgICAgICAge2VzdGFiLmNuYWVzLm1hcCgodmluY3VsbykgPT4gKFxyXG4gICAgICAgICAgICAgICAgPGRpdiBrZXk9e3ZpbmN1bG8uaWQgfHwgdmluY3Vsby5jbmFlX2NvZGlnb30gY2xhc3NOYW1lPVwicHktMyBmaXJzdDpwdC0wIGxhc3Q6cGItMCBzcGFjZS15LTFcIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1vbm8gZm9udC1ib2xkIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7dmluY3Vsby5jbmFlX2NvZGlnb31cclxuICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgIHt2aW5jdWxvLmVoX3ByaW5jaXBhbCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIGZvbnQtc2VtaWJvbGQgYmctdGVhbC0xMDAgZGFyazpiZy10ZWFsLTk1MCB0ZXh0LXRlYWwtODAwIGRhcms6dGV4dC10ZWFsLTMwMCBweC0xLjUgcHktMC41IHJvdW5kZWRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBDTkFFIFByaW5jaXBhbFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIHt2aW5jdWxvLmNuYWUgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPFJpc2NvQmFkZ2UgcmlzY289e3ZpbmN1bG8uY25hZS5ncmF1X3Jpc2NvX3BhZHJhb30gc2l6ZT1cInNtXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNjAwIGRhcms6dGV4dC1zbGF0ZS0zMDAgdGV4dC1bMTFweF1cIj5cclxuICAgICAgICAgICAgICAgICAgICB7dmluY3Vsby5jbmFlPy5kZXNjcmljYW8gfHwgXCJEZXNjcmnDp8OjbyBkYSBhdGl2aWRhZGUgZWNvbsO0bWljYVwifVxyXG4gICAgICAgICAgICAgICAgICA8L3A+XHJcblxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zIHRleHQtWzEwcHhdIHRleHQtc2xhdGUtNDAwIHB0LTAuNVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHt2aW5jdWxvLmNuYWU/LmV4aWdlX3J0ICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtYW1iZXItNjAwIGZvbnQtbWVkaXVtXCI+RXhpZ2UgUlQ8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICB7dmluY3Vsby5jbmFlPy5leGlnZV9wcm9qZXRvX2FycXVpdGV0b25pY28gJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1ibHVlLTYwMCBmb250LW1lZGl1bVwiPkV4aWdlIFByb2pldG8gQXJxLjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgIHt2aW5jdWxvLmRhdGFfaW5pY2lvX2F0aXZpZGFkZSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5JbsOtY2lvOiB7dmluY3Vsby5kYXRhX2luaWNpb19hdGl2aWRhZGV9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIHsvKiBDb2x1bmEgMzogSW5mcmFlc3RydXR1cmEsIFJlcHJlc2VudGFudGUgTGVnYWwgZSBBbHZhcsOhICovfVxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS02XCI+XHJcbiAgICAgICAgICB7LyogQ2FyZDogQWx2YXLDoSBTYW5pdMOhcmlvIEF0dWFsICovfVxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC14bCBwLTUgc2hhZG93LXhzIHNwYWNlLXktM1wiPlxyXG4gICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBwYi0yIGJvcmRlci1iIGJvcmRlci1zbGF0ZS0xMDAgZGFyazpib3JkZXItc2xhdGUtODAwXCI+XHJcbiAgICAgICAgICAgICAgPEZpbGVDaGVjayBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtdGVhbC02MDBcIiAvPlxyXG4gICAgICAgICAgICAgIExpY2VuY2lhbWVudG8gU2FuaXTDoXJpb1xyXG4gICAgICAgICAgICA8L2gyPlxyXG5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTIgdGV4dC14c1wiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMFwiPlNpdHVhw6fDo286PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPFNpdHVhY2FvQWx2YXJhQmFkZ2Ugc2l0dWFjYW89e2VzdGFiLnNpdHVhY2FvX2FsdmFyYX0gLz5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNDAwXCI+TsO6bWVybyBkbyBBbHZhcsOhOjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbW9ubyBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtODAwIGRhcms6dGV4dC1zbGF0ZS0yMDBcIj5cclxuICAgICAgICAgICAgICAgICAge2VzdGFiLm51bWVyb19hbHZhcmEgfHwgXCJOw6NvIGVtaXRpZG9cIn1cclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNDAwXCI+VmFsaWRhZGU6PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTgwMCBkYXJrOnRleHQtc2xhdGUtMjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIHtlc3RhYi5kYXRhX3ZhbGlkYWRlX2FsdmFyYSB8fCBcIuKAlFwifVxyXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIHsvKiBDYXJkOiBSZXByZXNlbnRhbnRlIExlZ2FsICovfVxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC14bCBwLTUgc2hhZG93LXhzIHNwYWNlLXktM1wiPlxyXG4gICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBwYi0yIGJvcmRlci1iIGJvcmRlci1zbGF0ZS0xMDAgZGFyazpib3JkZXItc2xhdGUtODAwXCI+XHJcbiAgICAgICAgICAgICAgPFVzZXIgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LXRlYWwtNjAwXCIgLz5cclxuICAgICAgICAgICAgICBSZXByZXNlbnRhbnRlIExlZ2FsXHJcbiAgICAgICAgICAgIDwvaDI+XHJcblxyXG4gICAgICAgICAgICB7ZXN0YWIucmVwcmVzZW50YW50ZV9sZWdhbCA/IChcclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMiB0ZXh0LXhzXCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZSBibG9ja1wiPlxyXG4gICAgICAgICAgICAgICAgICAgIHtlc3RhYi5yZXByZXNlbnRhbnRlX2xlZ2FsLm5vbWVfY29tcGxldG99XHJcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gZm9udC1tb25vIHRleHQtc2xhdGUtNDAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgQ1BGOiB7ZXN0YWIucmVwcmVzZW50YW50ZV9sZWdhbC5jcGZ9XHJcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1zbGF0ZS02MDAgZGFyazp0ZXh0LXNsYXRlLTMwMCBzcGFjZS15LTAuNVwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjVcIj5cclxuICAgICAgICAgICAgICAgICAgICA8UGhvbmUgY2xhc3NOYW1lPVwidy0zIGgtMyB0ZXh0LXNsYXRlLTQwMFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4+e2VzdGFiLnJlcHJlc2VudGFudGVfbGVnYWwudGVsZWZvbmV9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPE1haWwgY2xhc3NOYW1lPVwidy0zIGgtMyB0ZXh0LXNsYXRlLTQwMFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4+e2VzdGFiLnJlcHJlc2VudGFudGVfbGVnYWwuZW1haWx9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLXN0YXJ0IGdhcC0xLjUgcHQtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxNYXBQaW4gY2xhc3NOYW1lPVwidy0zIGgtMyB0ZXh0LXNsYXRlLTQwMCBzaHJpbmstMCBtdC0wLjVcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIGxlYWRpbmctc251Z1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2VzdGFiLnJlcHJlc2VudGFudGVfbGVnYWwuZW5kZXJlY29fcmVzaWRlbmNpYWx9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS00MDBcIj5cclxuICAgICAgICAgICAgICAgIE5lbmh1bSByZXByZXNlbnRhbnRlIGxlZ2FsIGFzc29jaWFkby5cclxuICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICl9XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICB7LyogQ2FyZDogUGFyw6JtZXRyb3MgZGUgU2FuZWFtZW50byAmIMOBZ3VhICovfVxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC14bCBwLTUgc2hhZG93LXhzIHNwYWNlLXktM1wiPlxyXG4gICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBwYi0yIGJvcmRlci1iIGJvcmRlci1zbGF0ZS0xMDAgZGFyazpib3JkZXItc2xhdGUtODAwXCI+XHJcbiAgICAgICAgICAgICAgPERyb3BsZXRzIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC10ZWFsLTYwMFwiIC8+XHJcbiAgICAgICAgICAgICAgU2FuZWFtZW50byAmIEluZnJhZXN0cnV0dXJhXHJcbiAgICAgICAgICAgIDwvaDI+XHJcblxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMiB0ZXh0LXhzXCI+XHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNDAwIGJsb2NrIHRleHQtWzExcHhdXCI+Rm9udGUgZGUgQWJhc3RlY2ltZW50bzwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS04MDAgZGFyazp0ZXh0LXNsYXRlLTIwMFwiPlxyXG4gICAgICAgICAgICAgICAgICB7ZXN0YWIuZm9udGVfYWJhc3RlY2ltZW50b19hZ3VhIHx8IFwiUmVkZSBQw7pibGljYVwifVxyXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDAgYmxvY2sgdGV4dC1bMTFweF1cIj5SZXNlcnZhdMOzcmlvIFByw7NwcmlvPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTgwMCBkYXJrOnRleHQtc2xhdGUtMjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIHtlc3RhYi5wb3NzdWlfcmVzZXJ2YXRvcmlvX3Byb3ByaW9cclxuICAgICAgICAgICAgICAgICAgICA/IGBTaW0gKCR7ZXN0YWIuY2FwYWNpZGFkZV9yZXNlcnZhdG9yaW9fbGl0cm9zfSBMKWBcclxuICAgICAgICAgICAgICAgICAgICA6IFwiTsOjbyBwb3NzdWkgcmVzZXJ2YXTDs3JpbyBwcsOzcHJpb1wifVxyXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICB7ZXN0YWIuaG9yYXJpb19mdW5jaW9uYW1lbnRvICYmIChcclxuICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNDAwIGJsb2NrIHRleHQtWzExcHhdXCI+SG9yw6FyaW8gZGUgRnVuY2lvbmFtZW50bzwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTgwMCBkYXJrOnRleHQtc2xhdGUtMjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge2VzdGFiLmhvcmFyaW9fZnVuY2lvbmFtZW50b31cclxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgRXN0YWJlbGVjaW1lbnRvRGV0YWlsUGFnZTtcclxuIl19