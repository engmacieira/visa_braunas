import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ouvidoria/DenuncianteCard.tsx");const React = __vite__cjsImport0_react;const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];/**
* Card de Exibição Protegida dos Dados do Denunciante
* Respeita a legislação de Ouvidoria Pública (Lei Federal 13.460/2017) e LGPD.
* Oculta e mascara a identidade quando a denúncia for anônima.
*/
import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=0fd2848a";
import { Lock, Mail, Phone, ShieldCheck, User } from "/node_modules/.vite/deps/lucide-react.js?v=0fd2848a";
var _jsxFileName = "E:/Projetos VSCODE/visa_braunas/src/components/ouvidoria/DenuncianteCard.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=0fd2848a";
export const DenuncianteCard = ({ denuncianteAnonimo, nome, telefone, email, className = "" }) => {
	if (denuncianteAnonimo) {
		return /* @__PURE__ */ _jsxDEV("div", {
			className: `p-4 bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 rounded-xl space-y-2 ${className}`,
			children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "flex items-center gap-2 text-slate-800 dark:text-slate-200",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "w-8 h-8 rounded-lg bg-slate-200 dark:bg-slate-700 flex items-center justify-center text-slate-600 dark:text-slate-300",
					children: /* @__PURE__ */ _jsxDEV(Lock, { className: "w-4 h-4" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 32,
						columnNumber: 13
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 31,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
					className: "text-[10px] uppercase font-bold text-slate-400 block tracking-wider",
					children: "Autoria da Denúncia"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 35,
					columnNumber: 13
				}, this), /* @__PURE__ */ _jsxDEV("p", {
					className: "text-xs font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1.5",
					children: /* @__PURE__ */ _jsxDEV("span", { children: "Identidade sob Sigilo Legal • Denúncia Anônima" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 39,
						columnNumber: 15
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 38,
					columnNumber: 13
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 34,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 30,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("p", {
				className: "text-[11px] text-slate-500 dark:text-slate-400 leading-relaxed pl-10",
				children: "O manifestante optou pelo anonimato no registro. Em conformidade com a Lei Federal 13.460/2017 e a Lei Geral de Proteção de Dados (LGPD), nenhum dado pessoal de contato é divulgado no processo de fiscalização."
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 44,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 27,
			columnNumber: 7
		}, this);
	}
	return /* @__PURE__ */ _jsxDEV("div", {
		className: `p-4 bg-teal-50/50 dark:bg-teal-950/20 border border-teal-200 dark:border-teal-800/60 rounded-xl space-y-3 ${className}`,
		children: [/* @__PURE__ */ _jsxDEV("div", {
			className: "flex items-center justify-between border-b border-teal-200/60 dark:border-teal-800/60 pb-2",
			children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "flex items-center gap-2",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "w-8 h-8 rounded-lg bg-teal-100 dark:bg-teal-950/60 flex items-center justify-center text-teal-700 dark:text-teal-300",
					children: /* @__PURE__ */ _jsxDEV(User, { className: "w-4 h-4" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 58,
						columnNumber: 13
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 57,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
					className: "text-[10px] uppercase font-bold text-teal-700 dark:text-teal-400 block tracking-wider",
					children: "Cidadão Denunciante (Identificado)"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 61,
					columnNumber: 13
				}, this), /* @__PURE__ */ _jsxDEV("p", {
					className: "text-xs font-bold text-slate-900 dark:text-white",
					children: nome || "Munícipe Identificado"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 64,
					columnNumber: 13
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 60,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 56,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("span", {
				className: "text-[10px] font-semibold text-teal-800 dark:text-teal-300 bg-teal-100/70 dark:bg-teal-900/40 px-2 py-0.5 rounded border border-teal-200 dark:border-teal-800 flex items-center gap-1",
				children: [/* @__PURE__ */ _jsxDEV(ShieldCheck, { className: "w-3 h-3" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 71,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Dados Protegidos" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 72,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 70,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 55,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs pl-1",
			children: [telefone ? /* @__PURE__ */ _jsxDEV("div", {
				className: "flex items-center gap-2 text-slate-700 dark:text-slate-300",
				children: [/* @__PURE__ */ _jsxDEV(Phone, { className: "w-3.5 h-3.5 text-teal-600 dark:text-teal-400 shrink-0" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 79,
					columnNumber: 13
				}, this), /* @__PURE__ */ _jsxDEV("span", { children: ["Telefone: ", telefone] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 80,
					columnNumber: 13
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 78,
				columnNumber: 11
			}, this) : /* @__PURE__ */ _jsxDEV("span", {
				className: "text-slate-400 text-[11px]",
				children: "Telefone não fornecido"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 83,
				columnNumber: 11
			}, this), email ? /* @__PURE__ */ _jsxDEV("div", {
				className: "flex items-center gap-2 text-slate-700 dark:text-slate-300 truncate",
				children: [/* @__PURE__ */ _jsxDEV(Mail, { className: "w-3.5 h-3.5 text-teal-600 dark:text-teal-400 shrink-0" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 88,
					columnNumber: 13
				}, this), /* @__PURE__ */ _jsxDEV("span", {
					className: "truncate",
					children: ["E-mail: ", email]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 89,
					columnNumber: 13
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 87,
				columnNumber: 11
			}, this) : /* @__PURE__ */ _jsxDEV("span", {
				className: "text-slate-400 text-[11px]",
				children: "E-mail não fornecido"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 92,
				columnNumber: 11
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 76,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 52,
		columnNumber: 5
	}, this);
};
_c = DenuncianteCard;
export default DenuncianteCard;
var _c;
$RefreshReg$(_c, "DenuncianteCard");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/ouvidoria/DenuncianteCard.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("E:/Projetos VSCODE/visa_braunas/src/components/ouvidoria/DenuncianteCard.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("E:/Projetos VSCODE/visa_braunas/src/components/ouvidoria/DenuncianteCard.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "E:/Projetos VSCODE/visa_braunas/src/components/ouvidoria/DenuncianteCard.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7Ozs7QUFNQSxPQUFPLFdBQVc7QUFDbEIsU0FBUyxNQUFNLE1BQU0sT0FBTyxhQUFhLFlBQW1COzs7QUFVNUQsT0FBTyxNQUFNLG1CQUFtRCxFQUM5RCxvQkFDQSxNQUNBLFVBQ0EsT0FDQSxZQUFZLFNBQ1I7Q0FDSixJQUFJLG9CQUFvQjtFQUN0QixPQUNFLHdCQUFDLE9BQUQ7R0FDRSxXQUFXLDJHQUEyRzthQUR4SCxDQUdFLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUNiLHdCQUFDLE1BQUQsRUFBTSxXQUFVLFVBQVc7Ozs7O0lBQ3hCOzs7O2NBQ0wsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFFBQUQ7S0FBTSxXQUFVO2VBQXNFO0lBRWhGOzs7O2NBQ04sd0JBQUMsS0FBRDtLQUFHLFdBQVU7ZUFDWCx3QkFBQyxRQUFELFlBQU0saURBQW9EOzs7OztJQUN6RDs7OztZQUNBOzs7O1lBQ0Y7Ozs7O2FBRUwsd0JBQUMsS0FBRDtJQUFHLFdBQVU7Y0FBdUU7R0FFakY7Ozs7V0FDQTs7Ozs7O0NBRVQ7Q0FFQSxPQUNFLHdCQUFDLE9BQUQ7RUFDRSxXQUFXLDZHQUE2RztZQUQxSCxDQUdFLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWYsQ0FDRSx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFDYix3QkFBQyxNQUFELEVBQU0sV0FBVSxVQUFXOzs7OztJQUN4Qjs7OztjQUNMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxRQUFEO0tBQU0sV0FBVTtlQUF3RjtJQUVsRzs7OztjQUNOLHdCQUFDLEtBQUQ7S0FBRyxXQUFVO2VBQ1YsUUFBUTtJQUNSOzs7O1lBQ0E7Ozs7WUFDRjs7Ozs7YUFFTCx3QkFBQyxRQUFEO0lBQU0sV0FBVTtjQUFoQixDQUNFLHdCQUFDLGFBQUQsRUFBYSxXQUFVLFVBQVc7Ozs7Y0FDbEMsd0JBQUMsUUFBRCxZQUFNLG1CQUFzQjs7OztZQUN4Qjs7Ozs7V0FDSDs7Ozs7WUFFTCx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmLENBQ0csV0FDQyx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsT0FBRCxFQUFPLFdBQVUsd0RBQXlEOzs7O2NBQzFFLHdCQUFDLFFBQUQsYUFBTSxjQUFXLFFBQWU7Ozs7WUFDN0I7Ozs7O2NBRUwsd0JBQUMsUUFBRDtJQUFNLFdBQVU7Y0FBNkI7R0FBNEI7Ozs7YUFHMUUsUUFDQyx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsTUFBRCxFQUFNLFdBQVUsd0RBQXlEOzs7O2NBQ3pFLHdCQUFDLFFBQUQ7S0FBTSxXQUFVO2VBQWhCLENBQTJCLFlBQVMsS0FBWTs7Ozs7WUFDN0M7Ozs7O2NBRUwsd0JBQUMsUUFBRDtJQUFNLFdBQVU7Y0FBNkI7R0FBMEI7Ozs7V0FFdEU7Ozs7O1VBQ0Y7Ozs7OztBQUVUOztBQUVBLGVBQWUiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiRGVudW5jaWFudGVDYXJkLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyIvKipcclxuICogQ2FyZCBkZSBFeGliacOnw6NvIFByb3RlZ2lkYSBkb3MgRGFkb3MgZG8gRGVudW5jaWFudGVcclxuICogUmVzcGVpdGEgYSBsZWdpc2xhw6fDo28gZGUgT3V2aWRvcmlhIFDDumJsaWNhIChMZWkgRmVkZXJhbCAxMy40NjAvMjAxNykgZSBMR1BELlxyXG4gKiBPY3VsdGEgZSBtYXNjYXJhIGEgaWRlbnRpZGFkZSBxdWFuZG8gYSBkZW7Dum5jaWEgZm9yIGFuw7RuaW1hLlxyXG4gKi9cclxuXHJcbmltcG9ydCBSZWFjdCBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHsgTG9jaywgTWFpbCwgUGhvbmUsIFNoaWVsZENoZWNrLCBVc2VyLCBVc2VyWCB9IGZyb20gXCJsdWNpZGUtcmVhY3RcIjtcclxuXHJcbmludGVyZmFjZSBEZW51bmNpYW50ZUNhcmRQcm9wcyB7XHJcbiAgZGVudW5jaWFudGVBbm9uaW1vOiBib29sZWFuO1xyXG4gIG5vbWU/OiBzdHJpbmcgfCBudWxsO1xyXG4gIHRlbGVmb25lPzogc3RyaW5nIHwgbnVsbDtcclxuICBlbWFpbD86IHN0cmluZyB8IG51bGw7XHJcbiAgY2xhc3NOYW1lPzogc3RyaW5nO1xyXG59XHJcblxyXG5leHBvcnQgY29uc3QgRGVudW5jaWFudGVDYXJkOiBSZWFjdC5GQzxEZW51bmNpYW50ZUNhcmRQcm9wcz4gPSAoe1xyXG4gIGRlbnVuY2lhbnRlQW5vbmltbyxcclxuICBub21lLFxyXG4gIHRlbGVmb25lLFxyXG4gIGVtYWlsLFxyXG4gIGNsYXNzTmFtZSA9IFwiXCIsXHJcbn0pID0+IHtcclxuICBpZiAoZGVudW5jaWFudGVBbm9uaW1vKSB7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICA8ZGl2XHJcbiAgICAgICAgY2xhc3NOYW1lPXtgcC00IGJnLXNsYXRlLTUwIGRhcms6Ymctc2xhdGUtODAwLzUwIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCByb3VuZGVkLXhsIHNwYWNlLXktMiAke2NsYXNzTmFtZX1gfVxyXG4gICAgICA+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiB0ZXh0LXNsYXRlLTgwMCBkYXJrOnRleHQtc2xhdGUtMjAwXCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctOCBoLTggcm91bmRlZC1sZyBiZy1zbGF0ZS0yMDAgZGFyazpiZy1zbGF0ZS03MDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgdGV4dC1zbGF0ZS02MDAgZGFyazp0ZXh0LXNsYXRlLTMwMFwiPlxyXG4gICAgICAgICAgICA8TG9jayBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdXBwZXJjYXNlIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTQwMCBibG9jayB0cmFja2luZy13aWRlclwiPlxyXG4gICAgICAgICAgICAgIEF1dG9yaWEgZGEgRGVuw7puY2lhXHJcbiAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdGV4dC1zbGF0ZS04MDAgZGFyazp0ZXh0LXNsYXRlLTIwMCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41XCI+XHJcbiAgICAgICAgICAgICAgPHNwYW4+SWRlbnRpZGFkZSBzb2IgU2lnaWxvIExlZ2FsIOKAoiBEZW7Dum5jaWEgQW7DtG5pbWE8L3NwYW4+XHJcbiAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LXNsYXRlLTUwMCBkYXJrOnRleHQtc2xhdGUtNDAwIGxlYWRpbmctcmVsYXhlZCBwbC0xMFwiPlxyXG4gICAgICAgICAgTyBtYW5pZmVzdGFudGUgb3B0b3UgcGVsbyBhbm9uaW1hdG8gbm8gcmVnaXN0cm8uIEVtIGNvbmZvcm1pZGFkZSBjb20gYSBMZWkgRmVkZXJhbCAxMy40NjAvMjAxNyBlIGEgTGVpIEdlcmFsIGRlIFByb3Rlw6fDo28gZGUgRGFkb3MgKExHUEQpLCBuZW5odW0gZGFkbyBwZXNzb2FsIGRlIGNvbnRhdG8gw6kgZGl2dWxnYWRvIG5vIHByb2Nlc3NvIGRlIGZpc2NhbGl6YcOnw6NvLlxyXG4gICAgICAgIDwvcD5cclxuICAgICAgPC9kaXY+XHJcbiAgICApO1xyXG4gIH1cclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXZcclxuICAgICAgY2xhc3NOYW1lPXtgcC00IGJnLXRlYWwtNTAvNTAgZGFyazpiZy10ZWFsLTk1MC8yMCBib3JkZXIgYm9yZGVyLXRlYWwtMjAwIGRhcms6Ym9yZGVyLXRlYWwtODAwLzYwIHJvdW5kZWQteGwgc3BhY2UteS0zICR7Y2xhc3NOYW1lfWB9XHJcbiAgICA+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGJvcmRlci1iIGJvcmRlci10ZWFsLTIwMC82MCBkYXJrOmJvcmRlci10ZWFsLTgwMC82MCBwYi0yXCI+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTggaC04IHJvdW5kZWQtbGcgYmctdGVhbC0xMDAgZGFyazpiZy10ZWFsLTk1MC82MCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB0ZXh0LXRlYWwtNzAwIGRhcms6dGV4dC10ZWFsLTMwMFwiPlxyXG4gICAgICAgICAgICA8VXNlciBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdXBwZXJjYXNlIGZvbnQtYm9sZCB0ZXh0LXRlYWwtNzAwIGRhcms6dGV4dC10ZWFsLTQwMCBibG9jayB0cmFja2luZy13aWRlclwiPlxyXG4gICAgICAgICAgICAgIENpZGFkw6NvIERlbnVuY2lhbnRlIChJZGVudGlmaWNhZG8pXHJcbiAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlXCI+XHJcbiAgICAgICAgICAgICAge25vbWUgfHwgXCJNdW7DrWNpcGUgSWRlbnRpZmljYWRvXCJ9XHJcbiAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSBmb250LXNlbWlib2xkIHRleHQtdGVhbC04MDAgZGFyazp0ZXh0LXRlYWwtMzAwIGJnLXRlYWwtMTAwLzcwIGRhcms6YmctdGVhbC05MDAvNDAgcHgtMiBweS0wLjUgcm91bmRlZCBib3JkZXIgYm9yZGVyLXRlYWwtMjAwIGRhcms6Ym9yZGVyLXRlYWwtODAwIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xXCI+XHJcbiAgICAgICAgICA8U2hpZWxkQ2hlY2sgY2xhc3NOYW1lPVwidy0zIGgtM1wiIC8+XHJcbiAgICAgICAgICA8c3Bhbj5EYWRvcyBQcm90ZWdpZG9zPC9zcGFuPlxyXG4gICAgICAgIDwvc3Bhbj5cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgc206Z3JpZC1jb2xzLTIgZ2FwLTMgdGV4dC14cyBwbC0xXCI+XHJcbiAgICAgICAge3RlbGVmb25lID8gKFxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMzAwXCI+XHJcbiAgICAgICAgICAgIDxQaG9uZSBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNSB0ZXh0LXRlYWwtNjAwIGRhcms6dGV4dC10ZWFsLTQwMCBzaHJpbmstMFwiIC8+XHJcbiAgICAgICAgICAgIDxzcGFuPlRlbGVmb25lOiB7dGVsZWZvbmV9PC9zcGFuPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgKSA6IChcclxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNDAwIHRleHQtWzExcHhdXCI+VGVsZWZvbmUgbsOjbyBmb3JuZWNpZG88L3NwYW4+XHJcbiAgICAgICAgKX1cclxuXHJcbiAgICAgICAge2VtYWlsID8gKFxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMzAwIHRydW5jYXRlXCI+XHJcbiAgICAgICAgICAgIDxNYWlsIGNsYXNzTmFtZT1cInctMy41IGgtMy41IHRleHQtdGVhbC02MDAgZGFyazp0ZXh0LXRlYWwtNDAwIHNocmluay0wXCIgLz5cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidHJ1bmNhdGVcIj5FLW1haWw6IHtlbWFpbH08L3NwYW4+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICApIDogKFxyXG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDAgdGV4dC1bMTFweF1cIj5FLW1haWwgbsOjbyBmb3JuZWNpZG88L3NwYW4+XHJcbiAgICAgICAgKX1cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgRGVudW5jaWFudGVDYXJkO1xyXG4iXX0=