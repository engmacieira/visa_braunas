import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/indicadores/GraficoEvolucaoInspecoes.tsx");const React = __vite__cjsImport0_react; const useMemo = __vite__cjsImport0_react["useMemo"];const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];/**
* Gráfico de Barras: Comparativo de Inspeções Realizadas no Exercício (Rotina vs VAPT)
* Utiliza Recharts (BarChart, Bar, XAxis, YAxis, Tooltip, Legend, ResponsiveContainer).
*/
import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=0fd2848a";
import { Bar, BarChart, CartesianGrid, Legend, ResponsiveContainer, Tooltip, XAxis, YAxis } from "/node_modules/.vite/deps/recharts.js?v=0fd2848a";
import { BarChart3 } from "/node_modules/.vite/deps/lucide-react.js?v=0fd2848a";
var _jsxFileName = "E:/Projetos VSCODE/visa_braunas/src/components/indicadores/GraficoEvolucaoInspecoes.tsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=0fd2848a";
var _s = $RefreshSig$();
const MESES_PADRAO = [
	{
		mesAbreviado: "Jan",
		mes: "Janeiro",
		rotina: 4,
		vapt: 1,
		total: 5
	},
	{
		mesAbreviado: "Fev",
		mes: "Fevereiro",
		rotina: 6,
		vapt: 2,
		total: 8
	},
	{
		mesAbreviado: "Mar",
		mes: "Março",
		rotina: 8,
		vapt: 2,
		total: 10
	},
	{
		mesAbreviado: "Abr",
		mes: "Abril",
		rotina: 7,
		vapt: 3,
		total: 10
	},
	{
		mesAbreviado: "Mai",
		mes: "Maio",
		rotina: 9,
		vapt: 2,
		total: 11
	},
	{
		mesAbreviado: "Jun",
		mes: "Junho",
		rotina: 5,
		vapt: 1,
		total: 6
	},
	{
		mesAbreviado: "Jul",
		mes: "Julho",
		rotina: 8,
		vapt: 3,
		total: 11
	},
	{
		mesAbreviado: "Ago",
		mes: "Agosto",
		rotina: 11,
		vapt: 4,
		total: 15
	},
	{
		mesAbreviado: "Set",
		mes: "Setembro",
		rotina: 9,
		vapt: 2,
		total: 11
	},
	{
		mesAbreviado: "Out",
		mes: "Outubro",
		rotina: 10,
		vapt: 3,
		total: 13
	},
	{
		mesAbreviado: "Nov",
		mes: "Novembro",
		rotina: 7,
		vapt: 2,
		total: 9
	},
	{
		mesAbreviado: "Dez",
		mes: "Dezembro",
		rotina: 5,
		vapt: 1,
		total: 6
	}
];
export const GraficoEvolucaoInspecoes = ({ ano = 2026, dadosMensais, totalVapt, totalGeral }) => {
	_s();
	const dados = useMemo(() => {
		if (dadosMensais && dadosMensais.length > 0) {
			return dadosMensais;
		}
		return MESES_PADRAO;
	}, [dadosMensais]);
	const totais = useMemo(() => {
		const calcVapt = totalVapt ?? dados.reduce((acc, curr) => acc + curr.vapt, 0);
		const calcRotina = dados.reduce((acc, curr) => acc + curr.rotina, 0);
		const calcGeral = totalGeral ?? calcVapt + calcRotina;
		return {
			vapt: calcVapt,
			rotina: calcRotina,
			geral: calcGeral
		};
	}, [
		dados,
		totalVapt,
		totalGeral
	]);
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 shadow-xs flex flex-col justify-between",
		children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", {
			className: "flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-100 dark:border-slate-800 mb-4",
			children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h2", {
				className: "text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2",
				children: [
					/* @__PURE__ */ _jsxDEV(BarChart3, { className: "w-4 h-4 text-teal-600" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 72,
						columnNumber: 15
					}, this),
					"Evolução Temporal de Vistorias Sanitárias (",
					ano,
					")"
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 71,
				columnNumber: 13
			}, this), /* @__PURE__ */ _jsxDEV("p", {
				className: "text-xs text-slate-500 dark:text-slate-400 mt-0.5",
				children: "Comparativo de ações de rotina/licenciamento versus fiscalizações VAPT (Saúde do Trabalhador)"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 75,
				columnNumber: 13
			}, this)] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 70,
				columnNumber: 11
			}, this), /* @__PURE__ */ _jsxDEV("div", {
				className: "flex items-center gap-2",
				children: [/* @__PURE__ */ _jsxDEV("span", {
					className: "text-xs font-semibold px-2.5 py-1 rounded bg-teal-50 dark:bg-teal-950/40 text-teal-700 dark:text-teal-300 border border-teal-200 dark:border-teal-800",
					children: ["VAPT: ", totais.vapt]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 81,
					columnNumber: 13
				}, this), /* @__PURE__ */ _jsxDEV("span", {
					className: "text-xs font-semibold px-2.5 py-1 rounded bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300",
					children: ["Total: ", totais.geral]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 84,
					columnNumber: 13
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 80,
				columnNumber: 11
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 69,
			columnNumber: 9
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "h-64 w-full",
			children: /* @__PURE__ */ _jsxDEV(ResponsiveContainer, {
				width: "100%",
				height: "100%",
				children: /* @__PURE__ */ _jsxDEV(BarChart, {
					data: dados,
					margin: {
						top: 10,
						right: 10,
						left: -20,
						bottom: 0
					},
					children: [
						/* @__PURE__ */ _jsxDEV(CartesianGrid, {
							strokeDasharray: "3 3",
							vertical: false,
							stroke: "#e2e8f0",
							className: "dark:stroke-slate-800"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 97,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV(XAxis, {
							dataKey: "mesAbreviado",
							tickLine: false,
							axisLine: false,
							tick: {
								fontSize: 11,
								fill: "#64748b"
							}
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 103,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV(YAxis, {
							tickLine: false,
							axisLine: false,
							tick: {
								fontSize: 11,
								fill: "#64748b"
							},
							allowDecimals: false
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 109,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV(Tooltip, { content: ({ active, payload, label }) => {
							if (active && payload && payload.length) {
								const rotinaVal = Number(payload.find((p) => p.dataKey === "rotina")?.value || 0);
								const vaptVal = Number(payload.find((p) => p.dataKey === "vapt")?.value || 0);
								const soma = rotinaVal + vaptVal;
								return /* @__PURE__ */ _jsxDEV("div", {
									className: "bg-white dark:bg-slate-800 p-3 rounded-lg shadow-lg border border-slate-200 dark:border-slate-700 text-xs",
									children: [
										/* @__PURE__ */ _jsxDEV("div", {
											className: "font-bold text-slate-900 dark:text-white mb-1.5 border-b border-slate-100 dark:border-slate-700 pb-1",
											children: ["Mês: ", label]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 123,
											columnNumber: 25
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "flex items-center justify-between gap-4 text-slate-600 dark:text-slate-300 mb-0.5",
											children: [/* @__PURE__ */ _jsxDEV("span", {
												className: "flex items-center gap-1.5",
												children: [/* @__PURE__ */ _jsxDEV("span", { className: "w-2.5 h-2.5 rounded-xs bg-slate-400 inline-block" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 128,
													columnNumber: 29
												}, this), "Rotina & Alvará:"]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 127,
												columnNumber: 27
											}, this), /* @__PURE__ */ _jsxDEV("strong", {
												className: "text-slate-900 dark:text-white tabular-nums",
												children: rotinaVal
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 131,
												columnNumber: 27
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 126,
											columnNumber: 25
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "flex items-center justify-between gap-4 text-teal-600 dark:text-teal-400 font-semibold mb-1",
											children: [/* @__PURE__ */ _jsxDEV("span", {
												className: "flex items-center gap-1.5",
												children: [/* @__PURE__ */ _jsxDEV("span", { className: "w-2.5 h-2.5 rounded-xs bg-teal-600 inline-block" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 135,
													columnNumber: 29
												}, this), "VAPT (Indicador 11):"]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 134,
												columnNumber: 27
											}, this), /* @__PURE__ */ _jsxDEV("strong", {
												className: "tabular-nums",
												children: vaptVal
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 138,
												columnNumber: 27
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 133,
											columnNumber: 25
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "pt-1 border-t border-slate-100 dark:border-slate-700 text-slate-500 text-[11px] flex justify-between",
											children: [/* @__PURE__ */ _jsxDEV("span", { children: "Total do Mês:" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 141,
												columnNumber: 27
											}, this), /* @__PURE__ */ _jsxDEV("span", {
												className: "font-bold text-slate-800 dark:text-slate-200",
												children: soma
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 142,
												columnNumber: 27
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 140,
											columnNumber: 25
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 122,
									columnNumber: 23
								}, this);
							}
							return null;
						} }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 115,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV(Legend, {
							verticalAlign: "bottom",
							height: 32,
							formatter: (value) => {
								return /* @__PURE__ */ _jsxDEV("span", {
									className: "text-xs text-slate-700 dark:text-slate-300 font-medium",
									children: value === "rotina" ? "Rotina & Licenciamento" : "VAPT (Saúde do Trabalhador)"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 155,
									columnNumber: 21
								}, this);
							}
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 150,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV(Bar, {
							dataKey: "rotina",
							name: "rotina",
							fill: "#94a3b8",
							radius: [
								4,
								4,
								0,
								0
							],
							maxBarSize: 28
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 161,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV(Bar, {
							dataKey: "vapt",
							name: "vapt",
							fill: "#0d9488",
							radius: [
								4,
								4,
								0,
								0
							],
							maxBarSize: 28
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 168,
							columnNumber: 15
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 93,
					columnNumber: 13
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 92,
				columnNumber: 11
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 91,
			columnNumber: 9
		}, this)] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 68,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "p-3 bg-teal-50/60 dark:bg-teal-950/30 border border-teal-100 dark:border-teal-900/40 rounded-lg flex items-center justify-between mt-3 text-xs",
			children: [/* @__PURE__ */ _jsxDEV("span", {
				className: "text-teal-900 dark:text-teal-200",
				children: [
					/* @__PURE__ */ _jsxDEV("strong", { children: "Ações VAPT acumuladas:" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 183,
						columnNumber: 11
					}, this),
					" ",
					totais.vapt,
					" inspeções focadas em ambientes e processos de trabalho."
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 182,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("span", {
				className: "font-mono font-bold text-teal-700 dark:text-teal-300",
				children: [(totais.vapt / (totais.geral || 1) * 100).toFixed(1), "% do total"]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 185,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 181,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 67,
		columnNumber: 5
	}, this);
};
_s(GraficoEvolucaoInspecoes, "SQQ8InTbHahOPZSRuQJTDbz0St0=");
_c = GraficoEvolucaoInspecoes;
export default GraficoEvolucaoInspecoes;
var _c;
$RefreshReg$(_c, "GraficoEvolucaoInspecoes");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/indicadores/GraficoEvolucaoInspecoes.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("E:/Projetos VSCODE/visa_braunas/src/components/indicadores/GraficoEvolucaoInspecoes.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("E:/Projetos VSCODE/visa_braunas/src/components/indicadores/GraficoEvolucaoInspecoes.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "E:/Projetos VSCODE/visa_braunas/src/components/indicadores/GraficoEvolucaoInspecoes.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7OztBQUtBLE9BQU8sU0FBUyxlQUFlO0FBQy9CLFNBQ0UsS0FDQSxVQUNBLGVBQ0EsUUFDQSxxQkFDQSxTQUNBLE9BQ0EsYUFDSztBQUNQLFNBQVMsaUJBQWlCOzs7O0FBVTFCLE1BQU0sZUFBZTtDQUNuQjtFQUFFLGNBQWM7RUFBTyxLQUFLO0VBQVcsUUFBUTtFQUFHLE1BQU07RUFBRyxPQUFPO0NBQUU7Q0FDcEU7RUFBRSxjQUFjO0VBQU8sS0FBSztFQUFhLFFBQVE7RUFBRyxNQUFNO0VBQUcsT0FBTztDQUFFO0NBQ3RFO0VBQUUsY0FBYztFQUFPLEtBQUs7RUFBUyxRQUFRO0VBQUcsTUFBTTtFQUFHLE9BQU87Q0FBRztDQUNuRTtFQUFFLGNBQWM7RUFBTyxLQUFLO0VBQVMsUUFBUTtFQUFHLE1BQU07RUFBRyxPQUFPO0NBQUc7Q0FDbkU7RUFBRSxjQUFjO0VBQU8sS0FBSztFQUFRLFFBQVE7RUFBRyxNQUFNO0VBQUcsT0FBTztDQUFHO0NBQ2xFO0VBQUUsY0FBYztFQUFPLEtBQUs7RUFBUyxRQUFRO0VBQUcsTUFBTTtFQUFHLE9BQU87Q0FBRTtDQUNsRTtFQUFFLGNBQWM7RUFBTyxLQUFLO0VBQVMsUUFBUTtFQUFHLE1BQU07RUFBRyxPQUFPO0NBQUc7Q0FDbkU7RUFBRSxjQUFjO0VBQU8sS0FBSztFQUFVLFFBQVE7RUFBSSxNQUFNO0VBQUcsT0FBTztDQUFHO0NBQ3JFO0VBQUUsY0FBYztFQUFPLEtBQUs7RUFBWSxRQUFRO0VBQUcsTUFBTTtFQUFHLE9BQU87Q0FBRztDQUN0RTtFQUFFLGNBQWM7RUFBTyxLQUFLO0VBQVcsUUFBUTtFQUFJLE1BQU07RUFBRyxPQUFPO0NBQUc7Q0FDdEU7RUFBRSxjQUFjO0VBQU8sS0FBSztFQUFZLFFBQVE7RUFBRyxNQUFNO0VBQUcsT0FBTztDQUFFO0NBQ3JFO0VBQUUsY0FBYztFQUFPLEtBQUs7RUFBWSxRQUFRO0VBQUcsTUFBTTtFQUFHLE9BQU87Q0FBRTtBQUN2RTtBQUVBLE9BQU8sTUFBTSw0QkFBcUUsRUFDaEYsTUFBTSxNQUNOLGNBQ0EsV0FDQSxpQkFDSTs7Q0FDSixNQUFNLFFBQVEsY0FBYztFQUMxQixJQUFJLGdCQUFnQixhQUFhLFNBQVMsR0FBRztHQUMzQyxPQUFPO0VBQ1Q7RUFDQSxPQUFPO0NBQ1QsR0FBRyxDQUFDLFlBQVksQ0FBQztDQUVqQixNQUFNLFNBQVMsY0FBYztFQUMzQixNQUFNLFdBQVcsYUFBYSxNQUFNLFFBQVEsS0FBSyxTQUFTLE1BQU0sS0FBSyxNQUFNLENBQUM7RUFDNUUsTUFBTSxhQUFhLE1BQU0sUUFBUSxLQUFLLFNBQVMsTUFBTSxLQUFLLFFBQVEsQ0FBQztFQUNuRSxNQUFNLFlBQVksY0FBYyxXQUFXO0VBQzNDLE9BQU87R0FDTCxNQUFNO0dBQ04sUUFBUTtHQUNSLE9BQU87RUFDVDtDQUNGLEdBQUc7RUFBQztFQUFPO0VBQVc7Q0FBVSxDQUFDO0NBRWpDLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBZixDQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmLENBQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE1BQUQ7SUFBSSxXQUFVO2NBQWQ7S0FDRSx3QkFBQyxXQUFELEVBQVcsV0FBVSx3QkFBeUI7Ozs7O0tBQUM7S0FDSDtLQUFJO0lBQzlDOzs7OzthQUNKLHdCQUFDLEtBQUQ7SUFBRyxXQUFVO2NBQW9EO0dBRTlEOzs7O1dBQ0E7Ozs7YUFFTCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsUUFBRDtLQUFNLFdBQVU7ZUFBaEIsQ0FBd0ssVUFDL0osT0FBTyxJQUNWOzs7OztjQUNOLHdCQUFDLFFBQUQ7S0FBTSxXQUFVO2VBQWhCLENBQThILFdBQ3BILE9BQU8sS0FDWDs7Ozs7WUFDSDs7Ozs7V0FDRjs7Ozs7WUFHTCx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUNiLHdCQUFDLHFCQUFEO0lBQXFCLE9BQU07SUFBTyxRQUFPO2NBQ3ZDLHdCQUFDLFVBQUQ7S0FDRSxNQUFNO0tBQ04sUUFBUTtNQUFFLEtBQUs7TUFBSSxPQUFPO01BQUksTUFBTSxDQUFDO01BQUksUUFBUTtLQUFFO2VBRnJEO01BSUUsd0JBQUMsZUFBRDtPQUNFLGlCQUFnQjtPQUNoQixVQUFVO09BQ1YsUUFBTztPQUNQLFdBQVU7TUFDWDs7Ozs7TUFDRCx3QkFBQyxPQUFEO09BQ0UsU0FBUTtPQUNSLFVBQVU7T0FDVixVQUFVO09BQ1YsTUFBTTtRQUFFLFVBQVU7UUFBSSxNQUFNO09BQVU7TUFDdkM7Ozs7O01BQ0Qsd0JBQUMsT0FBRDtPQUNFLFVBQVU7T0FDVixVQUFVO09BQ1YsTUFBTTtRQUFFLFVBQVU7UUFBSSxNQUFNO09BQVU7T0FDdEMsZUFBZTtNQUNoQjs7Ozs7TUFDRCx3QkFBQyxTQUFELEVBQ0UsVUFBVSxFQUFFLFFBQVEsU0FBUyxZQUFZO09BQ3ZDLElBQUksVUFBVSxXQUFXLFFBQVEsUUFBUTtRQUN2QyxNQUFNLFlBQVksT0FBTyxRQUFRLE1BQU0sTUFBTSxFQUFFLFlBQVksUUFBUSxDQUFDLEVBQUUsU0FBUyxDQUFDO1FBQ2hGLE1BQU0sVUFBVSxPQUFPLFFBQVEsTUFBTSxNQUFNLEVBQUUsWUFBWSxNQUFNLENBQUMsRUFBRSxTQUFTLENBQUM7UUFDNUUsTUFBTSxPQUFPLFlBQVk7UUFDekIsT0FDRSx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZjtVQUNFLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUFmLENBQXNILFNBQzlHLEtBQ0g7Ozs7OztVQUNMLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUFmLENBQ0Usd0JBQUMsUUFBRDtZQUFNLFdBQVU7c0JBQWhCLENBQ0Usd0JBQUMsUUFBRCxFQUFNLFdBQVUsbURBQW9EOzs7O3NCQUFDLGtCQUVqRTs7Ozs7cUJBQ04sd0JBQUMsVUFBRDtZQUFRLFdBQVU7c0JBQStDO1dBQWtCOzs7O21CQUNoRjs7Ozs7O1VBQ0wsd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWYsQ0FDRSx3QkFBQyxRQUFEO1lBQU0sV0FBVTtzQkFBaEIsQ0FDRSx3QkFBQyxRQUFELEVBQU0sV0FBVSxrREFBbUQ7Ozs7c0JBQUMsc0JBRWhFOzs7OztxQkFDTix3QkFBQyxVQUFEO1lBQVEsV0FBVTtzQkFBZ0I7V0FBZ0I7Ozs7bUJBQy9DOzs7Ozs7VUFDTCx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBZixDQUNFLHdCQUFDLFFBQUQsWUFBTSxnQkFBbUI7Ozs7cUJBQ3pCLHdCQUFDLFFBQUQ7WUFBTSxXQUFVO3NCQUFnRDtXQUFXOzs7O21CQUN4RTs7Ozs7O1NBQ0Y7Ozs7OztPQUVUO09BQ0EsT0FBTztNQUNULEVBQ0Q7Ozs7O01BQ0Qsd0JBQUMsUUFBRDtPQUNFLGVBQWM7T0FDZCxRQUFRO09BQ1IsWUFBWSxVQUFVO1FBQ3BCLE9BQ0Usd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQ2IsVUFBVSxXQUFXLDJCQUEyQjtRQUM3Qzs7Ozs7T0FFVjtNQUNEOzs7OztNQUNELHdCQUFDLEtBQUQ7T0FDRSxTQUFRO09BQ1IsTUFBSztPQUNMLE1BQUs7T0FDTCxRQUFRO1FBQUM7UUFBRztRQUFHO1FBQUc7T0FBQztPQUNuQixZQUFZO01BQ2I7Ozs7O01BQ0Qsd0JBQUMsS0FBRDtPQUNFLFNBQVE7T0FDUixNQUFLO09BQ0wsTUFBSztPQUNMLFFBQVE7UUFBQztRQUFHO1FBQUc7UUFBRztPQUFDO09BQ25CLFlBQVk7TUFDYjs7Ozs7S0FDTzs7Ozs7O0dBQ1M7Ozs7O0VBQ2xCOzs7O1VBQ0Y7Ozs7WUFHTCx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmLENBQ0Usd0JBQUMsUUFBRDtJQUFNLFdBQVU7Y0FBaEI7S0FDRSx3QkFBQyxVQUFELFlBQVEseUJBQThCOzs7OztLQUFDO0tBQUUsT0FBTztLQUFLO0lBQ2pEOzs7OzthQUNOLHdCQUFDLFFBQUQ7SUFBTSxXQUFVO2NBQWhCLEVBQ0ssT0FBTyxRQUFRLE9BQU8sU0FBUyxLQUFNLElBQUcsQ0FBRSxRQUFRLENBQUMsR0FBRSxZQUNwRDs7Ozs7V0FDSDs7Ozs7VUFDRjs7Ozs7O0FBRVQ7OztBQUVBLGVBQWUiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiR3JhZmljb0V2b2x1Y2FvSW5zcGVjb2VzLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyIvKipcclxuICogR3LDoWZpY28gZGUgQmFycmFzOiBDb21wYXJhdGl2byBkZSBJbnNwZcOnw7VlcyBSZWFsaXphZGFzIG5vIEV4ZXJjw61jaW8gKFJvdGluYSB2cyBWQVBUKVxyXG4gKiBVdGlsaXphIFJlY2hhcnRzIChCYXJDaGFydCwgQmFyLCBYQXhpcywgWUF4aXMsIFRvb2x0aXAsIExlZ2VuZCwgUmVzcG9uc2l2ZUNvbnRhaW5lcikuXHJcbiAqL1xyXG5cclxuaW1wb3J0IFJlYWN0LCB7IHVzZU1lbW8gfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHtcclxuICBCYXIsXHJcbiAgQmFyQ2hhcnQsXHJcbiAgQ2FydGVzaWFuR3JpZCxcclxuICBMZWdlbmQsXHJcbiAgUmVzcG9uc2l2ZUNvbnRhaW5lcixcclxuICBUb29sdGlwLFxyXG4gIFhBeGlzLFxyXG4gIFlBeGlzLFxyXG59IGZyb20gXCJyZWNoYXJ0c1wiO1xyXG5pbXBvcnQgeyBCYXJDaGFydDMgfSBmcm9tIFwibHVjaWRlLXJlYWN0XCI7XHJcbmltcG9ydCB7IEV2b2x1Y2FvTWVuc2FsSW5zcGVjYW8gfSBmcm9tIFwiLi4vLi4vdHlwZXMvaW5kaWNhZG9yZXNcIjtcclxuXHJcbmludGVyZmFjZSBHcmFmaWNvRXZvbHVjYW9JbnNwZWNvZXNQcm9wcyB7XHJcbiAgYW5vPzogbnVtYmVyO1xyXG4gIGRhZG9zTWVuc2Fpcz86IEV2b2x1Y2FvTWVuc2FsSW5zcGVjYW9bXTtcclxuICB0b3RhbFZhcHQ/OiBudW1iZXI7XHJcbiAgdG90YWxHZXJhbD86IG51bWJlcjtcclxufVxyXG5cclxuY29uc3QgTUVTRVNfUEFEUkFPID0gW1xyXG4gIHsgbWVzQWJyZXZpYWRvOiBcIkphblwiLCBtZXM6IFwiSmFuZWlyb1wiLCByb3RpbmE6IDQsIHZhcHQ6IDEsIHRvdGFsOiA1IH0sXHJcbiAgeyBtZXNBYnJldmlhZG86IFwiRmV2XCIsIG1lczogXCJGZXZlcmVpcm9cIiwgcm90aW5hOiA2LCB2YXB0OiAyLCB0b3RhbDogOCB9LFxyXG4gIHsgbWVzQWJyZXZpYWRvOiBcIk1hclwiLCBtZXM6IFwiTWFyw6dvXCIsIHJvdGluYTogOCwgdmFwdDogMiwgdG90YWw6IDEwIH0sXHJcbiAgeyBtZXNBYnJldmlhZG86IFwiQWJyXCIsIG1lczogXCJBYnJpbFwiLCByb3RpbmE6IDcsIHZhcHQ6IDMsIHRvdGFsOiAxMCB9LFxyXG4gIHsgbWVzQWJyZXZpYWRvOiBcIk1haVwiLCBtZXM6IFwiTWFpb1wiLCByb3RpbmE6IDksIHZhcHQ6IDIsIHRvdGFsOiAxMSB9LFxyXG4gIHsgbWVzQWJyZXZpYWRvOiBcIkp1blwiLCBtZXM6IFwiSnVuaG9cIiwgcm90aW5hOiA1LCB2YXB0OiAxLCB0b3RhbDogNiB9LFxyXG4gIHsgbWVzQWJyZXZpYWRvOiBcIkp1bFwiLCBtZXM6IFwiSnVsaG9cIiwgcm90aW5hOiA4LCB2YXB0OiAzLCB0b3RhbDogMTEgfSxcclxuICB7IG1lc0FicmV2aWFkbzogXCJBZ29cIiwgbWVzOiBcIkFnb3N0b1wiLCByb3RpbmE6IDExLCB2YXB0OiA0LCB0b3RhbDogMTUgfSxcclxuICB7IG1lc0FicmV2aWFkbzogXCJTZXRcIiwgbWVzOiBcIlNldGVtYnJvXCIsIHJvdGluYTogOSwgdmFwdDogMiwgdG90YWw6IDExIH0sXHJcbiAgeyBtZXNBYnJldmlhZG86IFwiT3V0XCIsIG1lczogXCJPdXR1YnJvXCIsIHJvdGluYTogMTAsIHZhcHQ6IDMsIHRvdGFsOiAxMyB9LFxyXG4gIHsgbWVzQWJyZXZpYWRvOiBcIk5vdlwiLCBtZXM6IFwiTm92ZW1icm9cIiwgcm90aW5hOiA3LCB2YXB0OiAyLCB0b3RhbDogOSB9LFxyXG4gIHsgbWVzQWJyZXZpYWRvOiBcIkRlelwiLCBtZXM6IFwiRGV6ZW1icm9cIiwgcm90aW5hOiA1LCB2YXB0OiAxLCB0b3RhbDogNiB9LFxyXG5dO1xyXG5cclxuZXhwb3J0IGNvbnN0IEdyYWZpY29Fdm9sdWNhb0luc3BlY29lczogUmVhY3QuRkM8R3JhZmljb0V2b2x1Y2FvSW5zcGVjb2VzUHJvcHM+ID0gKHtcclxuICBhbm8gPSAyMDI2LFxyXG4gIGRhZG9zTWVuc2FpcyxcclxuICB0b3RhbFZhcHQsXHJcbiAgdG90YWxHZXJhbCxcclxufSkgPT4ge1xyXG4gIGNvbnN0IGRhZG9zID0gdXNlTWVtbygoKSA9PiB7XHJcbiAgICBpZiAoZGFkb3NNZW5zYWlzICYmIGRhZG9zTWVuc2Fpcy5sZW5ndGggPiAwKSB7XHJcbiAgICAgIHJldHVybiBkYWRvc01lbnNhaXM7XHJcbiAgICB9XHJcbiAgICByZXR1cm4gTUVTRVNfUEFEUkFPO1xyXG4gIH0sIFtkYWRvc01lbnNhaXNdKTtcclxuXHJcbiAgY29uc3QgdG90YWlzID0gdXNlTWVtbygoKSA9PiB7XHJcbiAgICBjb25zdCBjYWxjVmFwdCA9IHRvdGFsVmFwdCA/PyBkYWRvcy5yZWR1Y2UoKGFjYywgY3VycikgPT4gYWNjICsgY3Vyci52YXB0LCAwKTtcclxuICAgIGNvbnN0IGNhbGNSb3RpbmEgPSBkYWRvcy5yZWR1Y2UoKGFjYywgY3VycikgPT4gYWNjICsgY3Vyci5yb3RpbmEsIDApO1xyXG4gICAgY29uc3QgY2FsY0dlcmFsID0gdG90YWxHZXJhbCA/PyBjYWxjVmFwdCArIGNhbGNSb3RpbmE7XHJcbiAgICByZXR1cm4ge1xyXG4gICAgICB2YXB0OiBjYWxjVmFwdCxcclxuICAgICAgcm90aW5hOiBjYWxjUm90aW5hLFxyXG4gICAgICBnZXJhbDogY2FsY0dlcmFsLFxyXG4gICAgfTtcclxuICB9LCBbZGFkb3MsIHRvdGFsVmFwdCwgdG90YWxHZXJhbF0pO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC14bCBwLTYgc2hhZG93LXhzIGZsZXggZmxleC1jb2wganVzdGlmeS1iZXR3ZWVuXCI+XHJcbiAgICAgIDxkaXY+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIHNtOmZsZXgtcm93IHNtOml0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTIgcGItMyBib3JkZXItYiBib3JkZXItc2xhdGUtMTAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCBtYi00XCI+XHJcbiAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LWJvbGQgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgPEJhckNoYXJ0MyBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtdGVhbC02MDBcIiAvPlxyXG4gICAgICAgICAgICAgIEV2b2x1w6fDo28gVGVtcG9yYWwgZGUgVmlzdG9yaWFzIFNhbml0w6FyaWFzICh7YW5vfSlcclxuICAgICAgICAgICAgPC9oMj5cclxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTUwMCBkYXJrOnRleHQtc2xhdGUtNDAwIG10LTAuNVwiPlxyXG4gICAgICAgICAgICAgIENvbXBhcmF0aXZvIGRlIGHDp8O1ZXMgZGUgcm90aW5hL2xpY2VuY2lhbWVudG8gdmVyc3VzIGZpc2NhbGl6YcOnw7VlcyBWQVBUIChTYcO6ZGUgZG8gVHJhYmFsaGFkb3IpXHJcbiAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHB4LTIuNSBweS0xIHJvdW5kZWQgYmctdGVhbC01MCBkYXJrOmJnLXRlYWwtOTUwLzQwIHRleHQtdGVhbC03MDAgZGFyazp0ZXh0LXRlYWwtMzAwIGJvcmRlciBib3JkZXItdGVhbC0yMDAgZGFyazpib3JkZXItdGVhbC04MDBcIj5cclxuICAgICAgICAgICAgICBWQVBUOiB7dG90YWlzLnZhcHR9XHJcbiAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHB4LTIuNSBweS0xIHJvdW5kZWQgYmctc2xhdGUtMTAwIGRhcms6Ymctc2xhdGUtODAwIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0zMDBcIj5cclxuICAgICAgICAgICAgICBUb3RhbDoge3RvdGFpcy5nZXJhbH1cclxuICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIHsvKiBDb250YWluZXIgZG8gR3LDoWZpY28gZGUgQmFycmFzICovfVxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaC02NCB3LWZ1bGxcIj5cclxuICAgICAgICAgIDxSZXNwb25zaXZlQ29udGFpbmVyIHdpZHRoPVwiMTAwJVwiIGhlaWdodD1cIjEwMCVcIj5cclxuICAgICAgICAgICAgPEJhckNoYXJ0XHJcbiAgICAgICAgICAgICAgZGF0YT17ZGFkb3N9XHJcbiAgICAgICAgICAgICAgbWFyZ2luPXt7IHRvcDogMTAsIHJpZ2h0OiAxMCwgbGVmdDogLTIwLCBib3R0b206IDAgfX1cclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIDxDYXJ0ZXNpYW5HcmlkXHJcbiAgICAgICAgICAgICAgICBzdHJva2VEYXNoYXJyYXk9XCIzIDNcIlxyXG4gICAgICAgICAgICAgICAgdmVydGljYWw9e2ZhbHNlfVxyXG4gICAgICAgICAgICAgICAgc3Ryb2tlPVwiI2UyZThmMFwiXHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJkYXJrOnN0cm9rZS1zbGF0ZS04MDBcIlxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPFhBeGlzXHJcbiAgICAgICAgICAgICAgICBkYXRhS2V5PVwibWVzQWJyZXZpYWRvXCJcclxuICAgICAgICAgICAgICAgIHRpY2tMaW5lPXtmYWxzZX1cclxuICAgICAgICAgICAgICAgIGF4aXNMaW5lPXtmYWxzZX1cclxuICAgICAgICAgICAgICAgIHRpY2s9e3sgZm9udFNpemU6IDExLCBmaWxsOiBcIiM2NDc0OGJcIiB9fVxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPFlBeGlzXHJcbiAgICAgICAgICAgICAgICB0aWNrTGluZT17ZmFsc2V9XHJcbiAgICAgICAgICAgICAgICBheGlzTGluZT17ZmFsc2V9XHJcbiAgICAgICAgICAgICAgICB0aWNrPXt7IGZvbnRTaXplOiAxMSwgZmlsbDogXCIjNjQ3NDhiXCIgfX1cclxuICAgICAgICAgICAgICAgIGFsbG93RGVjaW1hbHM9e2ZhbHNlfVxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPFRvb2x0aXBcclxuICAgICAgICAgICAgICAgIGNvbnRlbnQ9eyh7IGFjdGl2ZSwgcGF5bG9hZCwgbGFiZWwgfSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICBpZiAoYWN0aXZlICYmIHBheWxvYWQgJiYgcGF5bG9hZC5sZW5ndGgpIHtcclxuICAgICAgICAgICAgICAgICAgICBjb25zdCByb3RpbmFWYWwgPSBOdW1iZXIocGF5bG9hZC5maW5kKChwKSA9PiBwLmRhdGFLZXkgPT09IFwicm90aW5hXCIpPy52YWx1ZSB8fCAwKTtcclxuICAgICAgICAgICAgICAgICAgICBjb25zdCB2YXB0VmFsID0gTnVtYmVyKHBheWxvYWQuZmluZCgocCkgPT4gcC5kYXRhS2V5ID09PSBcInZhcHRcIik/LnZhbHVlIHx8IDApO1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IHNvbWEgPSByb3RpbmFWYWwgKyB2YXB0VmFsO1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIGRhcms6Ymctc2xhdGUtODAwIHAtMyByb3VuZGVkLWxnIHNoYWRvdy1sZyBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgdGV4dC14c1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGUgbWItMS41IGJvcmRlci1iIGJvcmRlci1zbGF0ZS0xMDAgZGFyazpib3JkZXItc2xhdGUtNzAwIHBiLTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBNw6pzOiB7bGFiZWx9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtNCB0ZXh0LXNsYXRlLTYwMCBkYXJrOnRleHQtc2xhdGUtMzAwIG1iLTAuNVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInctMi41IGgtMi41IHJvdW5kZWQteHMgYmctc2xhdGUtNDAwIGlubGluZS1ibG9ja1wiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBSb3RpbmEgJiBBbHZhcsOhOlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Ryb25nIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZSB0YWJ1bGFyLW51bXNcIj57cm90aW5hVmFsfTwvc3Ryb25nPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTQgdGV4dC10ZWFsLTYwMCBkYXJrOnRleHQtdGVhbC00MDAgZm9udC1zZW1pYm9sZCBtYi0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidy0yLjUgaC0yLjUgcm91bmRlZC14cyBiZy10ZWFsLTYwMCBpbmxpbmUtYmxvY2tcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgVkFQVCAoSW5kaWNhZG9yIDExKTpcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHN0cm9uZyBjbGFzc05hbWU9XCJ0YWJ1bGFyLW51bXNcIj57dmFwdFZhbH08L3N0cm9uZz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHQtMSBib3JkZXItdCBib3JkZXItc2xhdGUtMTAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCB0ZXh0LXNsYXRlLTUwMCB0ZXh0LVsxMXB4XSBmbGV4IGp1c3RpZnktYmV0d2VlblwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPlRvdGFsIGRvIE3DqnM6PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXNsYXRlLTgwMCBkYXJrOnRleHQtc2xhdGUtMjAwXCI+e3NvbWF9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgcmV0dXJuIG51bGw7XHJcbiAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPExlZ2VuZFxyXG4gICAgICAgICAgICAgICAgdmVydGljYWxBbGlnbj1cImJvdHRvbVwiXHJcbiAgICAgICAgICAgICAgICBoZWlnaHQ9ezMyfVxyXG4gICAgICAgICAgICAgICAgZm9ybWF0dGVyPXsodmFsdWUpID0+IHtcclxuICAgICAgICAgICAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0zMDAgZm9udC1tZWRpdW1cIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHt2YWx1ZSA9PT0gXCJyb3RpbmFcIiA/IFwiUm90aW5hICYgTGljZW5jaWFtZW50b1wiIDogXCJWQVBUIChTYcO6ZGUgZG8gVHJhYmFsaGFkb3IpXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICApO1xyXG4gICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIDxCYXJcclxuICAgICAgICAgICAgICAgIGRhdGFLZXk9XCJyb3RpbmFcIlxyXG4gICAgICAgICAgICAgICAgbmFtZT1cInJvdGluYVwiXHJcbiAgICAgICAgICAgICAgICBmaWxsPVwiIzk0YTNiOFwiXHJcbiAgICAgICAgICAgICAgICByYWRpdXM9e1s0LCA0LCAwLCAwXX1cclxuICAgICAgICAgICAgICAgIG1heEJhclNpemU9ezI4fVxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPEJhclxyXG4gICAgICAgICAgICAgICAgZGF0YUtleT1cInZhcHRcIlxyXG4gICAgICAgICAgICAgICAgbmFtZT1cInZhcHRcIlxyXG4gICAgICAgICAgICAgICAgZmlsbD1cIiMwZDk0ODhcIlxyXG4gICAgICAgICAgICAgICAgcmFkaXVzPXtbNCwgNCwgMCwgMF19XHJcbiAgICAgICAgICAgICAgICBtYXhCYXJTaXplPXsyOH1cclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8L0JhckNoYXJ0PlxyXG4gICAgICAgICAgPC9SZXNwb25zaXZlQ29udGFpbmVyPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIHsvKiBEZXN0YXF1ZSBkYXMgTWV0YXMgKi99XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0zIGJnLXRlYWwtNTAvNjAgZGFyazpiZy10ZWFsLTk1MC8zMCBib3JkZXIgYm9yZGVyLXRlYWwtMTAwIGRhcms6Ym9yZGVyLXRlYWwtOTAwLzQwIHJvdW5kZWQtbGcgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIG10LTMgdGV4dC14c1wiPlxyXG4gICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtdGVhbC05MDAgZGFyazp0ZXh0LXRlYWwtMjAwXCI+XHJcbiAgICAgICAgICA8c3Ryb25nPkHDp8O1ZXMgVkFQVCBhY3VtdWxhZGFzOjwvc3Ryb25nPiB7dG90YWlzLnZhcHR9IGluc3Blw6fDtWVzIGZvY2FkYXMgZW0gYW1iaWVudGVzIGUgcHJvY2Vzc29zIGRlIHRyYWJhbGhvLlxyXG4gICAgICAgIDwvc3Bhbj5cclxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1vbm8gZm9udC1ib2xkIHRleHQtdGVhbC03MDAgZGFyazp0ZXh0LXRlYWwtMzAwXCI+XHJcbiAgICAgICAgICB7KCh0b3RhaXMudmFwdCAvICh0b3RhaXMuZ2VyYWwgfHwgMSkpICogMTAwKS50b0ZpeGVkKDEpfSUgZG8gdG90YWxcclxuICAgICAgICA8L3NwYW4+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IEdyYWZpY29Fdm9sdWNhb0luc3BlY29lcztcclxuIl19