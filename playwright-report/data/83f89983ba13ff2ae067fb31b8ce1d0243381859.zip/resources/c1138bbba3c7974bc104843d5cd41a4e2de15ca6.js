import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/public/DenunciaPublicaPage.tsx");const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport8_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport8_react_jsxDevRuntime["Fragment"];/**
* Canal Cidadão: Ouvidoria e Registro Público de Denúncias Sanitárias
* Rota: /denuncia-cidada
* Acesso livre para munícipes registrarem queixas (anônimas ou identificadas)
* e consultarem o andamento por número de protocolo oficial.
*/
import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=0fd2848a";
import { useForm } from "/node_modules/.vite/deps/react-hook-form.js?v=0fd2848a";
import { zodResolver } from "/node_modules/.vite/deps/@hookform_resolvers_zod.js?v=0fd2848a";
import * as z from "/node_modules/.vite/deps/zod.js?v=0fd2848a";
import { AlertCircle, AlertTriangle, CheckCircle2, FileCheck2, Lock, Search, Send, Shield, ShieldAlert, ShieldCheck } from "/node_modules/.vite/deps/lucide-react.js?v=0fd2848a";
import { APP_CONFIG } from "/src/config/app.config.ts";
import { useConsultarProtocoloPublico, useRegistrarDenunciaMutation } from "/src/hooks/useOuvidoria.ts";
import { StatusDenunciaBadge } from "/src/components/ouvidoria/StatusDenunciaBadge.tsx";
var _jsxFileName = "E:/Projetos VSCODE/visa_braunas/src/pages/public/DenunciaPublicaPage.tsx";
import __vite__cjsImport8_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=0fd2848a";
var _s = $RefreshSig$();
const denunciaCidadaSchema = z.object({
	local_denunciado_identificacao: z.string().min(3, "Informe o nome do estabelecimento ou descrição do local"),
	logradouro: z.string().optional(),
	numero: z.string().optional(),
	bairro: z.string().min(2, "Informe o bairro ou comunidade rural"),
	ponto_referencia: z.string().optional(),
	relato_denuncia: z.string().min(15, "Por favor, relate o fato ocorrido com no mínimo 15 caracteres"),
	denunciante_anonimo: z.boolean(),
	denunciante_nome: z.string().optional(),
	denunciante_telefone: z.string().optional(),
	denunciante_email: z.string().email("E-mail inválido").optional().or(z.literal(""))
}).superRefine((data, ctx) => {
	if (!data.denunciante_anonimo) {
		if (!data.denunciante_nome || data.denunciante_nome.trim().length === 0) {
			ctx.addIssue({
				code: z.ZodIssueCode.custom,
				path: ["denunciante_nome"],
				message: "Informe seu nome completo para registro identificado."
			});
		}
	}
});
export const DenunciaPublicaPage = () => {
	_s();
	const [modoAba, setModoAba] = useState("registrar");
	const [protocoloGerado, setProtocoloGerado] = useState(null);
	const [protocoloBusca, setProtocoloBusca] = useState("");
	const [protocoloAtivoConsulta, setProtocoloAtivoConsulta] = useState("");
	const registrarMutation = useRegistrarDenunciaMutation();
	const { data: consultaData, isLoading: isConsultando, isError: isErroConsulta } = useConsultarProtocoloPublico(protocoloAtivoConsulta);
	const { register, handleSubmit, watch, reset, formState: { errors, isSubmitting } } = useForm({
		resolver: zodResolver(denunciaCidadaSchema),
		defaultValues: {
			local_denunciado_identificacao: "",
			logradouro: "",
			numero: "",
			bairro: "",
			ponto_referencia: "",
			relato_denuncia: "",
			denunciante_anonimo: true,
			denunciante_nome: "",
			denunciante_telefone: "",
			denunciante_email: ""
		}
	});
	const denuncianteAnonimo = watch("denunciante_anonimo");
	const onSubmit = async (data) => {
		try {
			const payload = {
				local_denunciado_identificacao: data.local_denunciado_identificacao.trim(),
				relato_denuncia: data.relato_denuncia.trim(),
				origem: "formulario_web",
				gravidade: "media",
				logradouro: data.logradouro?.trim() || null,
				numero: data.numero?.trim() || null,
				bairro: data.bairro.trim(),
				ponto_referencia: data.ponto_referencia?.trim() || null,
				denunciante_anonimo: data.denunciante_anonimo,
				denunciante_nome: data.denunciante_anonimo ? null : data.denunciante_nome?.trim() || null,
				denunciante_telefone: data.denunciante_anonimo ? null : data.denunciante_telefone?.trim() || null,
				denunciante_email: data.denunciante_anonimo ? null : data.denunciante_email?.trim() || null
			};
			const resultado = await registrarMutation.mutateAsync(payload);
			setProtocoloGerado(resultado.numero_protocolo);
			reset();
		} catch {}
	};
	const handleConsultar = (e) => {
		e.preventDefault();
		if (protocoloBusca.trim()) {
			setProtocoloAtivoConsulta(protocoloBusca.trim().toUpperCase());
		}
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col justify-between antialiased selection:bg-teal-500 selection:text-white",
		children: [
			/* @__PURE__ */ _jsxDEV("header", {
				className: "bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 shadow-2xs",
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: "max-w-4xl mx-auto px-4 py-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "w-10 h-10 rounded-xl bg-teal-600 text-white flex items-center justify-center font-bold shadow-xs",
							children: /* @__PURE__ */ _jsxDEV(Shield, { className: "w-5 h-5 text-white" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 145,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 144,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "text-[10px] font-bold text-slate-400 uppercase tracking-wider block",
							children: "Canal Oficial de Ouvidoria Sanitária"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 148,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("h1", {
							className: "text-sm font-bold text-slate-900 dark:text-white leading-tight",
							children: [
								APP_CONFIG.prefeitura,
								" / ",
								APP_CONFIG.uf
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 151,
							columnNumber: 15
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 147,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 143,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-2 bg-slate-100 dark:bg-slate-800 p-1 rounded-xl text-xs font-semibold",
						children: [/* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							onClick: () => {
								setModoAba("registrar");
								setProtocoloGerado(null);
							},
							className: `px-3 py-1.5 rounded-lg transition-colors ${modoAba === "registrar" ? "bg-white dark:bg-slate-900 text-teal-700 dark:text-teal-300 shadow-2xs" : "text-slate-600 dark:text-slate-400 hover:text-slate-900"}`,
							children: "Registrar Denúncia"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 159,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							onClick: () => setModoAba("consultar"),
							className: `px-3 py-1.5 rounded-lg transition-colors ${modoAba === "consultar" ? "bg-white dark:bg-slate-900 text-teal-700 dark:text-teal-300 shadow-2xs" : "text-slate-600 dark:text-slate-400 hover:text-slate-900"}`,
							children: "Consultar Protocolo"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 173,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 158,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 142,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 141,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("main", {
				className: "max-w-2xl w-full mx-auto px-4 py-8 space-y-6",
				children: modoAba === "registrar" ? /* @__PURE__ */ _jsxDEV(_Fragment, { children: protocoloGerado ? /* @__PURE__ */ _jsxDEV(
					"div",
					/* Tela de Sucesso ao Registrar */
					{
						className: "bg-white dark:bg-slate-900 border-2 border-emerald-300 dark:border-emerald-800 rounded-3xl p-6 sm:p-8 text-center space-y-6 shadow-sm animate-in fade-in zoom-in-95 duration-200",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "w-16 h-16 rounded-full bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 border border-emerald-200 dark:border-emerald-800 flex items-center justify-center mx-auto",
								children: /* @__PURE__ */ _jsxDEV(CheckCircle2, { className: "w-10 h-10" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 196,
									columnNumber: 19
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 195,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "space-y-2",
								children: [
									/* @__PURE__ */ _jsxDEV("span", {
										className: "text-[11px] font-bold uppercase tracking-widest text-emerald-700 dark:text-emerald-300 bg-emerald-50 dark:bg-emerald-950/40 px-3 py-0.5 rounded-full border border-emerald-200 dark:border-emerald-800",
										children: "Manifestação Registrada com Sucesso"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 200,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("h2", {
										className: "text-xl font-black text-slate-900 dark:text-white",
										children: "Protocolo Sanitário Emitido"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 203,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("p", {
										className: "text-xs text-slate-600 dark:text-slate-400 max-w-md mx-auto",
										children: [
											"Sua manifestação foi encaminhada para a equipe de triagem da Vigilância Sanitária de ",
											APP_CONFIG.municipio,
											"/MG."
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 206,
										columnNumber: 19
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 199,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "p-4 bg-slate-50 dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 max-w-sm mx-auto space-y-1",
								children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "text-[10px] text-slate-400 uppercase font-bold block",
									children: "Número Oficial de Protocolo"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 212,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("p", {
									className: "text-xl font-mono font-black text-teal-700 dark:text-teal-400",
									children: protocoloGerado
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 215,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 211,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "p-4 bg-teal-50/70 dark:bg-teal-950/30 border border-teal-200 dark:border-teal-800/80 rounded-2xl text-left text-xs text-teal-900 dark:text-teal-200 space-y-1",
								children: [/* @__PURE__ */ _jsxDEV("p", {
									className: "font-bold flex items-center gap-1.5",
									children: [/* @__PURE__ */ _jsxDEV(ShieldCheck, { className: "w-4 h-4 text-teal-600" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 222,
										columnNumber: 21
									}, this), "Guarde o seu número de protocolo:"]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 221,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("p", {
									className: "text-[11px] leading-relaxed text-teal-800 dark:text-teal-300",
									children: "Com este código você poderá acompanhar o andamento da fiscalização e ler a resposta oficial da autoridade de saúde a qualquer momento."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 225,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 220,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								onClick: () => {
									setProtocoloGerado(null);
									reset();
								},
								className: "px-5 py-2 text-xs font-bold text-slate-700 dark:text-slate-300 bg-slate-100 dark:bg-slate-800 rounded-xl hover:bg-slate-200",
								children: "Registrar Outra Denúncia"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 230,
								columnNumber: 17
							}, this)
						]
					},
					void 0,
					true,
					{
						fileName: _jsxFileName,
						lineNumber: 194,
						columnNumber: 15
					},
					this
				) : 
				/* Formulário de Registro de Denúncia */
				/* @__PURE__ */ _jsxDEV("div", {
					className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 sm:p-8 shadow-sm space-y-6",
					children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h2", {
						className: "text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2",
						children: [/* @__PURE__ */ _jsxDEV(ShieldAlert, { className: "w-5 h-5 text-teal-600" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 246,
							columnNumber: 21
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Relatar Irregularidade Sanitária" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 247,
							columnNumber: 21
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 245,
						columnNumber: 19
					}, this), /* @__PURE__ */ _jsxDEV("p", {
						className: "text-xs text-slate-500 dark:text-slate-400 mt-1",
						children: [
							"Ajude a proteger a saúde pública de ",
							APP_CONFIG.municipio,
							". Denúncias de alimentos impróprios, falta de higiene, comércio clandestino ou vetores."
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 249,
						columnNumber: 19
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 244,
						columnNumber: 17
					}, this), /* @__PURE__ */ _jsxDEV("form", {
						onSubmit: handleSubmit(onSubmit),
						className: "space-y-5",
						children: [
							registrarMutation.isError && /* @__PURE__ */ _jsxDEV("div", {
								className: "p-3 bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 rounded-xl flex items-center gap-2 text-xs text-rose-700 dark:text-rose-300",
								children: [/* @__PURE__ */ _jsxDEV(AlertTriangle, { className: "w-4 h-4 shrink-0" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 257,
									columnNumber: 23
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Não foi possível enviar a denúncia. Verifique os campos e tente novamente." }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 258,
									columnNumber: 23
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 256,
								columnNumber: 21
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "p-4 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-2xl flex items-center justify-between gap-3",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center gap-3",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "w-9 h-9 rounded-xl bg-slate-200 dark:bg-slate-700 flex items-center justify-center text-slate-700 dark:text-slate-300",
										children: /* @__PURE__ */ _jsxDEV(Lock, { className: "w-5 h-5" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 268,
											columnNumber: 25
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 267,
										columnNumber: 23
									}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-xs font-bold text-slate-900 dark:text-white block",
										children: "Denúncia Anônima (Sigilo Garantido)"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 271,
										columnNumber: 25
									}, this), /* @__PURE__ */ _jsxDEV("p", {
										className: "text-[11px] text-slate-500",
										children: "Sua identidade não será solicitada nem compartilhada."
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 274,
										columnNumber: 25
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 270,
										columnNumber: 23
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 266,
									columnNumber: 21
								}, this), /* @__PURE__ */ _jsxDEV("label", {
									className: "relative inline-flex items-center cursor-pointer",
									children: [/* @__PURE__ */ _jsxDEV("input", {
										type: "checkbox",
										...register("denunciante_anonimo"),
										className: "sr-only peer"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 281,
										columnNumber: 23
									}, this), /* @__PURE__ */ _jsxDEV("div", { className: "w-10 h-6 bg-slate-200 peer-focus:outline-none rounded-full peer dark:bg-slate-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-teal-600" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 286,
										columnNumber: 23
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 280,
									columnNumber: 21
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 265,
								columnNumber: 19
							}, this),
							!denuncianteAnonimo && /* @__PURE__ */ _jsxDEV("div", {
								className: "p-4 bg-teal-50/50 dark:bg-teal-950/20 border border-teal-200 dark:border-teal-800/60 rounded-2xl space-y-3 animate-in fade-in duration-150",
								children: [
									/* @__PURE__ */ _jsxDEV("span", {
										className: "text-xs font-bold text-teal-900 dark:text-teal-200 block",
										children: "Seus Dados de Contato (Confidenciais)"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 293,
										columnNumber: 23
									}, this),
									/* @__PURE__ */ _jsxDEV("div", { children: [
										/* @__PURE__ */ _jsxDEV("label", {
											className: "block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1",
											children: ["Seu Nome Completo ", /* @__PURE__ */ _jsxDEV("span", {
												className: "text-rose-500",
												children: "*"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 298,
												columnNumber: 45
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 297,
											columnNumber: 25
										}, this),
										/* @__PURE__ */ _jsxDEV("input", {
											type: "text",
											...register("denunciante_nome"),
											placeholder: "Digite seu nome...",
											className: "w-full px-3 py-2 text-xs bg-white dark:bg-slate-800 border border-teal-300 dark:border-teal-700 rounded-lg text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-teal-500"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 300,
											columnNumber: 25
										}, this),
										errors.denunciante_nome && /* @__PURE__ */ _jsxDEV("p", {
											className: "text-[11px] text-rose-600 mt-1",
											children: errors.denunciante_nome.message
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 307,
											columnNumber: 27
										}, this)
									] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 296,
										columnNumber: 23
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "grid grid-cols-1 sm:grid-cols-2 gap-3",
										children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
											className: "block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1",
											children: "Telefone / WhatsApp (Opcional)"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 315,
											columnNumber: 27
										}, this), /* @__PURE__ */ _jsxDEV("input", {
											type: "text",
											...register("denunciante_telefone"),
											placeholder: "(33) 99999-9999",
											className: "w-full px-3 py-2 text-xs bg-white dark:bg-slate-800 border border-teal-300 dark:border-teal-700 rounded-lg text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-teal-500"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 318,
											columnNumber: 27
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 314,
											columnNumber: 25
										}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
											className: "block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1",
											children: "E-mail para Notificações (Opcional)"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 327,
											columnNumber: 27
										}, this), /* @__PURE__ */ _jsxDEV("input", {
											type: "email",
											...register("denunciante_email"),
											placeholder: "seuemail@exemplo.com",
											className: "w-full px-3 py-2 text-xs bg-white dark:bg-slate-800 border border-teal-300 dark:border-teal-700 rounded-lg text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-teal-500"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 330,
											columnNumber: 27
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 326,
											columnNumber: 25
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 313,
										columnNumber: 23
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 292,
								columnNumber: 21
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "space-y-3",
								children: [
									/* @__PURE__ */ _jsxDEV("div", { children: [
										/* @__PURE__ */ _jsxDEV("label", {
											className: "block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1",
											children: ["Qual é o Estabelecimento ou Local Denunciado? ", /* @__PURE__ */ _jsxDEV("span", {
												className: "text-rose-500",
												children: "*"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 345,
												columnNumber: 71
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 344,
											columnNumber: 23
										}, this),
										/* @__PURE__ */ _jsxDEV("input", {
											type: "text",
											...register("local_denunciado_identificacao"),
											placeholder: "Ex: Mercado Central, Lanchonete do Bairro, Terreno baldio com acúmulo de lixo...",
											className: "w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-teal-500"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 347,
											columnNumber: 23
										}, this),
										errors.local_denunciado_identificacao && /* @__PURE__ */ _jsxDEV("p", {
											className: "text-[11px] text-rose-600 mt-1",
											children: errors.local_denunciado_identificacao.message
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 354,
											columnNumber: 25
										}, this)
									] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 343,
										columnNumber: 21
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "grid grid-cols-1 sm:grid-cols-2 gap-3",
										children: [/* @__PURE__ */ _jsxDEV("div", { children: [
											/* @__PURE__ */ _jsxDEV("label", {
												className: "block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1",
												children: ["Bairro / Comunidade ", /* @__PURE__ */ _jsxDEV("span", {
													className: "text-rose-500",
													children: "*"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 363,
													columnNumber: 47
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 362,
												columnNumber: 25
											}, this),
											/* @__PURE__ */ _jsxDEV("input", {
												type: "text",
												...register("bairro"),
												placeholder: "Ex: Centro, Bela Vista, Zona Rural...",
												className: "w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-teal-500"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 365,
												columnNumber: 25
											}, this),
											errors.bairro && /* @__PURE__ */ _jsxDEV("p", {
												className: "text-[11px] text-rose-600 mt-1",
												children: errors.bairro.message
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 372,
												columnNumber: 27
											}, this)
										] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 361,
											columnNumber: 23
										}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
											className: "block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1",
											children: "Ponto de Referência"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 379,
											columnNumber: 25
										}, this), /* @__PURE__ */ _jsxDEV("input", {
											type: "text",
											...register("ponto_referencia"),
											placeholder: "Ex: Próximo à praça da igreja, ao lado do posto de saúde...",
											className: "w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-teal-500"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 382,
											columnNumber: 25
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 378,
											columnNumber: 23
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 360,
										columnNumber: 21
									}, this),
									/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
										className: "block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1",
										children: "Endereço Completo (Rua e Número, se souber)"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 392,
										columnNumber: 23
									}, this), /* @__PURE__ */ _jsxDEV("input", {
										type: "text",
										...register("logradouro"),
										placeholder: "Rua / Avenida...",
										className: "w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-teal-500"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 395,
										columnNumber: 23
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 391,
										columnNumber: 21
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 342,
								columnNumber: 19
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { children: [
								/* @__PURE__ */ _jsxDEV("label", {
									className: "block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1",
									children: ["Descreva o Fato Ocorrido com o Máximo de Detalhes ", /* @__PURE__ */ _jsxDEV("span", {
										className: "text-rose-500",
										children: "*"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 407,
										columnNumber: 73
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 406,
									columnNumber: 21
								}, this),
								/* @__PURE__ */ _jsxDEV("textarea", {
									rows: 4,
									...register("relato_denuncia"),
									placeholder: "Descreva o problema observado: alimentos vencidos, falta de higiene, insetos, odores fortes, medicamentos sem procedência, horário em que ocorreu...",
									className: "w-full p-3 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-teal-500"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 409,
									columnNumber: 21
								}, this),
								errors.relato_denuncia && /* @__PURE__ */ _jsxDEV("p", {
									className: "text-[11px] text-rose-600 mt-1",
									children: errors.relato_denuncia.message
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 416,
									columnNumber: 23
								}, this)
							] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 405,
								columnNumber: 19
							}, this),
							/* @__PURE__ */ _jsxDEV("button", {
								type: "submit",
								disabled: isSubmitting,
								className: "w-full py-3 text-xs font-bold text-white bg-teal-600 hover:bg-teal-700 rounded-xl shadow-xs transition-colors flex items-center justify-center gap-2 disabled:opacity-60",
								children: [/* @__PURE__ */ _jsxDEV(Send, { className: "w-4 h-4" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 427,
									columnNumber: 21
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: isSubmitting ? "Enviando Denúncia..." : "Enviar Denúncia Sanitária" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 428,
									columnNumber: 21
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 422,
								columnNumber: 19
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 254,
						columnNumber: 17
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 243,
					columnNumber: 15
				}, this) }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 191,
					columnNumber: 11
				}, this) : 
				/* Consulta Pública por Protocolo */
				/* @__PURE__ */ _jsxDEV("div", {
					className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 sm:p-8 shadow-sm space-y-6",
					children: [
						/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h2", {
							className: "text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2",
							children: [/* @__PURE__ */ _jsxDEV(Search, { className: "w-5 h-5 text-teal-600" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 439,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Consultar Andamento da Denúncia" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 440,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 438,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("p", {
							className: "text-xs text-slate-500 dark:text-slate-400 mt-1",
							children: "Digite o número de protocolo recebido ao registrar a manifestação para verificar a resposta oficial."
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 442,
							columnNumber: 15
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 437,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("form", {
							onSubmit: handleConsultar,
							className: "flex gap-2",
							children: [/* @__PURE__ */ _jsxDEV("input", {
								type: "text",
								placeholder: "Ex: DEN-2026-0001",
								value: protocoloBusca,
								onChange: (e) => setProtocoloBusca(e.target.value.toUpperCase()),
								className: "flex-1 px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white font-mono focus:outline-none focus:ring-2 focus:ring-teal-500 uppercase"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 448,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								type: "submit",
								className: "px-5 py-2 text-xs font-bold text-white bg-teal-600 hover:bg-teal-700 rounded-xl shadow-xs transition-colors",
								children: "Buscar"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 455,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 447,
							columnNumber: 13
						}, this),
						isConsultando && /* @__PURE__ */ _jsxDEV("div", {
							className: "p-8 text-center text-xs text-slate-400 flex flex-col items-center justify-center",
							children: [/* @__PURE__ */ _jsxDEV("div", { className: "w-6 h-6 border-2 border-teal-500 border-t-transparent rounded-full animate-spin mb-2" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 465,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Consultando protocolo nos registros oficiais..." }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 466,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 464,
							columnNumber: 15
						}, this),
						!isConsultando && isErroConsulta && protocoloAtivoConsulta && /* @__PURE__ */ _jsxDEV("div", {
							className: "p-4 bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 rounded-2xl text-xs text-rose-800 dark:text-rose-200 flex items-center gap-2",
							children: [/* @__PURE__ */ _jsxDEV(AlertCircle, { className: "w-4 h-4 shrink-0" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 472,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: [
								"Protocolo ",
								/* @__PURE__ */ _jsxDEV("strong", { children: protocoloAtivoConsulta }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 474,
									columnNumber: 29
								}, this),
								" não localizado. Verifique se o código foi digitado corretamente."
							] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 473,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 471,
							columnNumber: 15
						}, this),
						!isConsultando && consultaData && /* @__PURE__ */ _jsxDEV("div", {
							className: "p-5 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-2xl space-y-4",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-700",
									children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-[10px] text-slate-400 uppercase font-bold block",
										children: "Protocolo Oficial"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 483,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: "text-base font-mono font-bold text-teal-700 dark:text-teal-400",
										children: consultaData.numero_protocolo
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 486,
										columnNumber: 21
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 482,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV(StatusDenunciaBadge, { status: consultaData.status }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 491,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 481,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "text-xs space-y-1",
									children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-[10px] text-slate-400 uppercase font-semibold block",
										children: "Local Apurado"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 495,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("p", {
										className: "font-bold text-slate-800 dark:text-slate-200",
										children: consultaData.local_denunciado_identificacao
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 498,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 494,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "text-xs space-y-1",
									children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-[10px] text-slate-400 uppercase font-semibold block",
										children: "Data de Recebimento"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 504,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("p", {
										className: "text-slate-700 dark:text-slate-300",
										children: new Date(consultaData.data_recebimento).toLocaleDateString("pt-BR")
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 507,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 503,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "p-3.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl space-y-1 text-xs",
									children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-[10px] text-teal-700 dark:text-teal-400 uppercase font-bold block flex items-center gap-1.5",
										children: [/* @__PURE__ */ _jsxDEV(FileCheck2, { className: "w-3.5 h-3.5" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 515,
											columnNumber: 21
										}, this), "Resposta da Autoridade Sanitária Municipal:"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 514,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("p", {
										className: "text-slate-800 dark:text-slate-200 leading-relaxed font-medium",
										children: consultaData.resposta_ao_denunciante || "A denúncia está em processo de apuração pela equipe fiscal de campo. Assim que concluída, a deliberação será disponibilizada neste espaço."
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 518,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 513,
									columnNumber: 17
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 480,
							columnNumber: 15
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 436,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 189,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("footer", {
				className: "bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800 py-6 text-center text-xs text-slate-500",
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: "max-w-2xl mx-auto px-4 space-y-1",
					children: [/* @__PURE__ */ _jsxDEV("p", {
						className: "font-semibold text-slate-700 dark:text-slate-300",
						children: [
							APP_CONFIG.prefeitura,
							" • ",
							APP_CONFIG.secretaria
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 532,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("p", {
						className: "text-[11px] text-slate-400",
						children: [APP_CONFIG.orgao, " • Canal de Atendimento ao Cidadão"]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 535,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 531,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 530,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 139,
		columnNumber: 5
	}, this);
};
_s(DenunciaPublicaPage, "xjIjsTDSEJ6+r0NyaYMVA4rmKso=", false, function() {
	return [
		useRegistrarDenunciaMutation,
		useConsultarProtocoloPublico,
		useForm
	];
});
_c = DenunciaPublicaPage;
export default DenunciaPublicaPage;
var _c;
$RefreshReg$(_c, "DenunciaPublicaPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/public/DenunciaPublicaPage.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("E:/Projetos VSCODE/visa_braunas/src/pages/public/DenunciaPublicaPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("E:/Projetos VSCODE/visa_braunas/src/pages/public/DenunciaPublicaPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "E:/Projetos VSCODE/visa_braunas/src/pages/public/DenunciaPublicaPage.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7Ozs7O0FBT0EsT0FBTyxTQUFTLGdCQUFnQjtBQUNoQyxTQUFTLGVBQWU7QUFDeEIsU0FBUyxtQkFBbUI7QUFDNUIsWUFBWSxPQUFPO0FBQ25CLFNBQ0UsYUFDQSxlQUdBLGNBRUEsWUFDQSxNQUVBLFFBQ0EsTUFDQSxRQUNBLGFBQ0EsbUJBRUs7QUFDUCxTQUFTLGtCQUFrQjtBQUMzQixTQUNFLDhCQUNBLG9DQUNLO0FBRVAsU0FBUywyQkFBMkI7Ozs7QUFFcEMsTUFBTSx1QkFBdUIsRUFDMUIsT0FBTztDQUNOLGdDQUFnQyxFQUM3QixPQUFPLENBQUMsQ0FDUixJQUFJLEdBQUcseURBQXlEO0NBQ25FLFlBQVksRUFBRSxPQUFPLENBQUMsQ0FBQyxTQUFTO0NBQ2hDLFFBQVEsRUFBRSxPQUFPLENBQUMsQ0FBQyxTQUFTO0NBQzVCLFFBQVEsRUFBRSxPQUFPLENBQUMsQ0FBQyxJQUFJLEdBQUcsc0NBQXNDO0NBQ2hFLGtCQUFrQixFQUFFLE9BQU8sQ0FBQyxDQUFDLFNBQVM7Q0FDdEMsaUJBQWlCLEVBQ2QsT0FBTyxDQUFDLENBQ1IsSUFBSSxJQUFJLCtEQUErRDtDQUUxRSxxQkFBcUIsRUFBRSxRQUFRO0NBQy9CLGtCQUFrQixFQUFFLE9BQU8sQ0FBQyxDQUFDLFNBQVM7Q0FDdEMsc0JBQXNCLEVBQUUsT0FBTyxDQUFDLENBQUMsU0FBUztDQUMxQyxtQkFBbUIsRUFBRSxPQUFPLENBQUMsQ0FBQyxNQUFNLGlCQUFpQixDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsR0FBRyxFQUFFLFFBQVEsRUFBRSxDQUFDO0FBQ3BGLENBQUMsQ0FBQyxDQUNELGFBQWEsTUFBTSxRQUFRO0NBQzFCLElBQUksQ0FBQyxLQUFLLHFCQUFxQjtFQUM3QixJQUFJLENBQUMsS0FBSyxvQkFBb0IsS0FBSyxpQkFBaUIsS0FBSyxDQUFDLENBQUMsV0FBVyxHQUFHO0dBQ3ZFLElBQUksU0FBUztJQUNYLE1BQU0sRUFBRSxhQUFhO0lBQ3JCLE1BQU0sQ0FBQyxrQkFBa0I7SUFDekIsU0FBUztHQUNYLENBQUM7RUFDSDtDQUNGO0FBQ0YsQ0FBQztBQUlILE9BQU8sTUFBTSw0QkFBc0M7O0NBQ2pELE1BQU0sQ0FBQyxTQUFTLGNBQWMsU0FBb0MsV0FBVztDQUM3RSxNQUFNLENBQUMsaUJBQWlCLHNCQUFzQixTQUF3QixJQUFJO0NBQzFFLE1BQU0sQ0FBQyxnQkFBZ0IscUJBQXFCLFNBQVMsRUFBRTtDQUN2RCxNQUFNLENBQUMsd0JBQXdCLDZCQUE2QixTQUFTLEVBQUU7Q0FFdkUsTUFBTSxvQkFBb0IsNkJBQTZCO0NBQ3ZELE1BQU0sRUFDSixNQUFNLGNBQ04sV0FBVyxlQUNYLFNBQVMsbUJBQ1AsNkJBQTZCLHNCQUFzQjtDQUV2RCxNQUFNLEVBQ0osVUFDQSxjQUNBLE9BQ0EsT0FDQSxXQUFXLEVBQUUsUUFBUSxtQkFDbkIsUUFBZ0M7RUFDbEMsVUFBVSxZQUFZLG9CQUFvQjtFQUMxQyxlQUFlO0dBQ2IsZ0NBQWdDO0dBQ2hDLFlBQVk7R0FDWixRQUFRO0dBQ1IsUUFBUTtHQUNSLGtCQUFrQjtHQUNsQixpQkFBaUI7R0FDakIscUJBQXFCO0dBQ3JCLGtCQUFrQjtHQUNsQixzQkFBc0I7R0FDdEIsbUJBQW1CO0VBQ3JCO0NBQ0YsQ0FBQztDQUVELE1BQU0scUJBQXFCLE1BQU0scUJBQXFCO0NBRXRELE1BQU0sV0FBVyxPQUFPLFNBQWlDO0VBQ3ZELElBQUk7R0FDRixNQUFNLFVBQWdDO0lBQ3BDLGdDQUFnQyxLQUFLLCtCQUErQixLQUFLO0lBQ3pFLGlCQUFpQixLQUFLLGdCQUFnQixLQUFLO0lBQzNDLFFBQVE7SUFDUixXQUFXO0lBQ1gsWUFBWSxLQUFLLFlBQVksS0FBSyxLQUFLO0lBQ3ZDLFFBQVEsS0FBSyxRQUFRLEtBQUssS0FBSztJQUMvQixRQUFRLEtBQUssT0FBTyxLQUFLO0lBQ3pCLGtCQUFrQixLQUFLLGtCQUFrQixLQUFLLEtBQUs7SUFDbkQscUJBQXFCLEtBQUs7SUFDMUIsa0JBQWtCLEtBQUssc0JBQXNCLE9BQU8sS0FBSyxrQkFBa0IsS0FBSyxLQUFLO0lBQ3JGLHNCQUFzQixLQUFLLHNCQUFzQixPQUFPLEtBQUssc0JBQXNCLEtBQUssS0FBSztJQUM3RixtQkFBbUIsS0FBSyxzQkFBc0IsT0FBTyxLQUFLLG1CQUFtQixLQUFLLEtBQUs7R0FDekY7R0FFQSxNQUFNLFlBQVksTUFBTSxrQkFBa0IsWUFBWSxPQUFPO0dBQzdELG1CQUFtQixVQUFVLGdCQUFnQjtHQUM3QyxNQUFNO0VBQ1IsUUFBUSxDQUVSO0NBQ0Y7Q0FFQSxNQUFNLG1CQUFtQixNQUF1QjtFQUM5QyxFQUFFLGVBQWU7RUFDakIsSUFBSSxlQUFlLEtBQUssR0FBRztHQUN6QiwwQkFBMEIsZUFBZSxLQUFLLENBQUMsQ0FBQyxZQUFZLENBQUM7RUFDL0Q7Q0FDRjtDQUVBLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBZjtHQUVFLHdCQUFDLFVBQUQ7SUFBUSxXQUFVO2NBQ2hCLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUNiLHdCQUFDLFFBQUQsRUFBUSxXQUFVLHFCQUFzQjs7Ozs7TUFDckM7Ozs7Z0JBQ0wsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFFBQUQ7T0FBTSxXQUFVO2lCQUFzRTtNQUVoRjs7OztnQkFDTix3QkFBQyxNQUFEO09BQUksV0FBVTtpQkFBZDtRQUNHLFdBQVc7UUFBVztRQUFJLFdBQVc7T0FDcEM7Ozs7O2NBQ0Q7Ozs7Y0FDRjs7Ozs7ZUFHTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLFVBQUQ7T0FDRSxNQUFLO09BQ0wsZUFBZTtRQUNiLFdBQVcsV0FBVztRQUN0QixtQkFBbUIsSUFBSTtPQUN6QjtPQUNBLFdBQVcsNENBQ1QsWUFBWSxjQUNSLDJFQUNBO2lCQUVQO01BRU87Ozs7Z0JBQ1Isd0JBQUMsVUFBRDtPQUNFLE1BQUs7T0FDTCxlQUFlLFdBQVcsV0FBVztPQUNyQyxXQUFXLDRDQUNULFlBQVksY0FDUiwyRUFDQTtpQkFFUDtNQUVPOzs7O2NBQ0w7Ozs7O2FBQ0Y7Ozs7OztHQUNDOzs7OztHQUdSLHdCQUFDLFFBQUQ7SUFBTSxXQUFVO2NBQ2IsWUFBWSxjQUNYLCtDQUNHLGtCQUVDO0tBQUM7O0tBQUQ7TUFBSyxXQUFVO2dCQUFmO09BQ0Usd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQ2Isd0JBQUMsY0FBRCxFQUFjLFdBQVUsWUFBYTs7Ozs7T0FDbEM7Ozs7O09BRUwsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWY7U0FDRSx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBeU07U0FFbk47Ozs7O1NBQ04sd0JBQUMsTUFBRDtVQUFJLFdBQVU7b0JBQW9EO1NBRTlEOzs7OztTQUNKLHdCQUFDLEtBQUQ7VUFBRyxXQUFVO29CQUFiO1dBQTJFO1dBQ2EsV0FBVztXQUFVO1VBQzFHOzs7Ozs7UUFDQTs7Ozs7O09BRUwsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFBdUQ7UUFFakU7Ozs7a0JBQ04sd0JBQUMsS0FBRDtTQUFHLFdBQVU7bUJBQ1Y7UUFDQTs7OztnQkFDQTs7Ozs7O09BRUwsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxLQUFEO1NBQUcsV0FBVTttQkFBYixDQUNFLHdCQUFDLGFBQUQsRUFBYSxXQUFVLHdCQUF5Qjs7OzttQkFBQyxtQ0FFaEQ7Ozs7O2tCQUNILHdCQUFDLEtBQUQ7U0FBRyxXQUFVO21CQUErRDtRQUV6RTs7OztnQkFDQTs7Ozs7O09BRUwsd0JBQUMsVUFBRDtRQUNFLE1BQUs7UUFDTCxlQUFlO1NBQ2IsbUJBQW1CLElBQUk7U0FDdkIsTUFBTTtRQUNSO1FBQ0EsV0FBVTtrQkFDWDtPQUVPOzs7OztNQUNMOzs7Ozs7Ozs7Ozs7SUFHTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE1BQUQ7TUFBSSxXQUFVO2dCQUFkLENBQ0Usd0JBQUMsYUFBRCxFQUFhLFdBQVUsd0JBQXlCOzs7O2dCQUNoRCx3QkFBQyxRQUFELFlBQU0sbUNBQXNDOzs7O2NBQzFDOzs7OztlQUNKLHdCQUFDLEtBQUQ7TUFBRyxXQUFVO2dCQUFiO09BQStEO09BQ3hCLFdBQVc7T0FBVTtNQUN6RDs7Ozs7YUFDQTs7OztlQUVMLHdCQUFDLFFBQUQ7TUFBTSxVQUFVLGFBQWEsUUFBUTtNQUFHLFdBQVU7Z0JBQWxEO09BQ0csa0JBQWtCLFdBQ2pCLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsZUFBRCxFQUFlLFdBQVUsbUJBQW9COzs7O2tCQUM3Qyx3QkFBQyxRQUFELFlBQU0sNkVBRUE7Ozs7Z0JBQ0g7Ozs7OztPQUlQLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDRSx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFDYix3QkFBQyxNQUFELEVBQU0sV0FBVSxVQUFXOzs7OztTQUN4Qjs7OzttQkFDTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQXlEO1NBRW5FOzs7O21CQUNOLHdCQUFDLEtBQUQ7VUFBRyxXQUFVO29CQUE2QjtTQUV2Qzs7OztpQkFDQTs7OztpQkFDRjs7Ozs7a0JBRUwsd0JBQUMsU0FBRDtTQUFPLFdBQVU7bUJBQWpCLENBQ0Usd0JBQUMsU0FBRDtVQUNFLE1BQUs7VUFDTCxHQUFJLFNBQVMscUJBQXFCO1VBQ2xDLFdBQVU7U0FDWDs7OzttQkFDRCx3QkFBQyxPQUFELEVBQUssV0FBVSxtV0FBb1c7Ozs7aUJBQzlXOzs7OztnQkFDSjs7Ozs7O09BR0osQ0FBQyxzQkFDQSx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZjtTQUNFLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUEyRDtTQUVyRTs7Ozs7U0FDTix3QkFBQyxPQUFEO1VBQ0Usd0JBQUMsU0FBRDtXQUFPLFdBQVU7cUJBQWpCLENBQXVGLHNCQUNuRSx3QkFBQyxRQUFEO1lBQU0sV0FBVTtzQkFBZ0I7V0FBTzs7OzttQkFDcEQ7Ozs7OztVQUNQLHdCQUFDLFNBQUQ7V0FDRSxNQUFLO1dBQ0wsR0FBSSxTQUFTLGtCQUFrQjtXQUMvQixhQUFZO1dBQ1osV0FBVTtVQUNYOzs7OztVQUNBLE9BQU8sb0JBQ04sd0JBQUMsS0FBRDtXQUFHLFdBQVU7cUJBQ1YsT0FBTyxpQkFBaUI7VUFDeEI7Ozs7O1NBRUY7Ozs7O1NBRUwsd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtXQUFPLFdBQVU7cUJBQXNFO1VBRWhGOzs7O29CQUNQLHdCQUFDLFNBQUQ7V0FDRSxNQUFLO1dBQ0wsR0FBSSxTQUFTLHNCQUFzQjtXQUNuQyxhQUFZO1dBQ1osV0FBVTtVQUNYOzs7O2tCQUNFOzs7O29CQUVMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO1dBQU8sV0FBVTtxQkFBc0U7VUFFaEY7Ozs7b0JBQ1Asd0JBQUMsU0FBRDtXQUNFLE1BQUs7V0FDTCxHQUFJLFNBQVMsbUJBQW1CO1dBQ2hDLGFBQVk7V0FDWixXQUFVO1VBQ1g7Ozs7a0JBQ0U7Ozs7a0JBQ0Y7Ozs7OztRQUNGOzs7Ozs7T0FJUCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZjtTQUNFLHdCQUFDLE9BQUQ7VUFDRSx3QkFBQyxTQUFEO1dBQU8sV0FBVTtxQkFBakIsQ0FBdUYsa0RBQ3ZDLHdCQUFDLFFBQUQ7WUFBTSxXQUFVO3NCQUFnQjtXQUFPOzs7O21CQUNoRjs7Ozs7O1VBQ1Asd0JBQUMsU0FBRDtXQUNFLE1BQUs7V0FDTCxHQUFJLFNBQVMsZ0NBQWdDO1dBQzdDLGFBQVk7V0FDWixXQUFVO1VBQ1g7Ozs7O1VBQ0EsT0FBTyxrQ0FDTix3QkFBQyxLQUFEO1dBQUcsV0FBVTtxQkFDVixPQUFPLCtCQUErQjtVQUN0Qzs7Ozs7U0FFRjs7Ozs7U0FFTCx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNFLHdCQUFDLE9BQUQ7V0FDRSx3QkFBQyxTQUFEO1lBQU8sV0FBVTtzQkFBakIsQ0FBdUYsd0JBQ2pFLHdCQUFDLFFBQUQ7YUFBTSxXQUFVO3VCQUFnQjtZQUFPOzs7O29CQUN0RDs7Ozs7O1dBQ1Asd0JBQUMsU0FBRDtZQUNFLE1BQUs7WUFDTCxHQUFJLFNBQVMsUUFBUTtZQUNyQixhQUFZO1lBQ1osV0FBVTtXQUNYOzs7OztXQUNBLE9BQU8sVUFDTix3QkFBQyxLQUFEO1lBQUcsV0FBVTtzQkFDVixPQUFPLE9BQU87V0FDZDs7Ozs7VUFFRjs7OztvQkFFTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtXQUFPLFdBQVU7cUJBQXNFO1VBRWhGOzs7O29CQUNQLHdCQUFDLFNBQUQ7V0FDRSxNQUFLO1dBQ0wsR0FBSSxTQUFTLGtCQUFrQjtXQUMvQixhQUFZO1dBQ1osV0FBVTtVQUNYOzs7O2tCQUNFOzs7O2tCQUNGOzs7Ozs7U0FFTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtVQUFPLFdBQVU7b0JBQXNFO1NBRWhGOzs7O21CQUNQLHdCQUFDLFNBQUQ7VUFDRSxNQUFLO1VBQ0wsR0FBSSxTQUFTLFlBQVk7VUFDekIsYUFBWTtVQUNaLFdBQVU7U0FDWDs7OztpQkFDRTs7Ozs7UUFDRjs7Ozs7O09BR0wsd0JBQUMsT0FBRDtRQUNFLHdCQUFDLFNBQUQ7U0FBTyxXQUFVO21CQUFqQixDQUF1RixzREFDbkMsd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQWdCO1NBQU87Ozs7aUJBQ3BGOzs7Ozs7UUFDUCx3QkFBQyxZQUFEO1NBQ0UsTUFBTTtTQUNOLEdBQUksU0FBUyxpQkFBaUI7U0FDOUIsYUFBWTtTQUNaLFdBQVU7UUFDWDs7Ozs7UUFDQSxPQUFPLG1CQUNOLHdCQUFDLEtBQUQ7U0FBRyxXQUFVO21CQUNWLE9BQU8sZ0JBQWdCO1FBQ3ZCOzs7OztPQUVGOzs7OztPQUVMLHdCQUFDLFVBQUQ7UUFDRSxNQUFLO1FBQ0wsVUFBVTtRQUNWLFdBQVU7a0JBSFosQ0FLRSx3QkFBQyxNQUFELEVBQU0sV0FBVSxVQUFXOzs7O2tCQUMzQix3QkFBQyxRQUFELFlBQU8sZUFBZSx5QkFBeUIsNEJBQWtDOzs7O2dCQUMzRTs7Ozs7O01BQ0o7Ozs7O2FBQ0g7Ozs7O2FBRVA7Ozs7OztJQUdGLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWY7TUFDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQWQsQ0FDRSx3QkFBQyxRQUFELEVBQVEsV0FBVSx3QkFBeUI7Ozs7aUJBQzNDLHdCQUFDLFFBQUQsWUFBTSxrQ0FBcUM7Ozs7ZUFDekM7Ozs7O2dCQUNKLHdCQUFDLEtBQUQ7T0FBRyxXQUFVO2lCQUFrRDtNQUU1RDs7OztjQUNBOzs7OztNQUVMLHdCQUFDLFFBQUQ7T0FBTSxVQUFVO09BQWlCLFdBQVU7aUJBQTNDLENBQ0Usd0JBQUMsU0FBRDtRQUNFLE1BQUs7UUFDTCxhQUFZO1FBQ1osT0FBTztRQUNQLFdBQVcsTUFBTSxrQkFBa0IsRUFBRSxPQUFPLE1BQU0sWUFBWSxDQUFDO1FBQy9ELFdBQVU7T0FDWDs7OztpQkFDRCx3QkFBQyxVQUFEO1FBQ0UsTUFBSztRQUNMLFdBQVU7a0JBQ1g7T0FFTzs7OztlQUNKOzs7Ozs7TUFFTCxpQkFDQyx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLE9BQUQsRUFBSyxXQUFVLHVGQUF3Rjs7OztpQkFDdkcsd0JBQUMsUUFBRCxZQUFNLGtEQUFxRDs7OztlQUN4RDs7Ozs7O01BR04sQ0FBQyxpQkFBaUIsa0JBQWtCLDBCQUNuQyx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLGFBQUQsRUFBYSxXQUFVLG1CQUFvQjs7OztpQkFDM0Msd0JBQUMsUUFBRDtRQUFNO1FBQ00sd0JBQUMsVUFBRCxZQUFTLHVCQUErQjs7Ozs7UUFBQztPQUMvQzs7OztlQUNIOzs7Ozs7TUFHTixDQUFDLGlCQUFpQixnQkFDakIsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWY7UUFDRSx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBdUQ7U0FFakU7Ozs7bUJBQ04sd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQ2IsYUFBYTtTQUNWOzs7O2lCQUNIOzs7O21CQUVMLHdCQUFDLHFCQUFELEVBQXFCLFFBQVEsYUFBYSxPQUFTOzs7O2lCQUNoRDs7Ozs7O1FBRUwsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDRSx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBMkQ7U0FFckU7Ozs7bUJBQ04sd0JBQUMsS0FBRDtVQUFHLFdBQVU7b0JBQ1YsYUFBYTtTQUNiOzs7O2lCQUNBOzs7Ozs7UUFFTCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUEyRDtTQUVyRTs7OzttQkFDTix3QkFBQyxLQUFEO1VBQUcsV0FBVTtvQkFDVixJQUFJLEtBQUssYUFBYSxnQkFBZ0IsQ0FBQyxDQUFDLG1CQUFtQixPQUFPO1NBQ2xFOzs7O2lCQUNBOzs7Ozs7UUFHTCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUFoQixDQUNFLHdCQUFDLFlBQUQsRUFBWSxXQUFVLGNBQWU7Ozs7b0JBQUMsNkNBRWxDOzs7OzttQkFDTix3QkFBQyxLQUFEO1VBQUcsV0FBVTtvQkFDVixhQUFhLDJCQUNaO1NBQ0Q7Ozs7aUJBQ0E7Ozs7OztPQUNGOzs7Ozs7S0FFSjs7Ozs7O0dBRUg7Ozs7O0dBR04sd0JBQUMsVUFBRDtJQUFRLFdBQVU7Y0FDaEIsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLEtBQUQ7TUFBRyxXQUFVO2dCQUFiO09BQ0csV0FBVztPQUFXO09BQUksV0FBVztNQUNyQzs7Ozs7ZUFDSCx3QkFBQyxLQUFEO01BQUcsV0FBVTtnQkFBYixDQUNHLFdBQVcsT0FBTSxvQ0FDakI7Ozs7O2FBQ0E7Ozs7OztHQUNDOzs7OztFQUNMOzs7Ozs7QUFFVDs7Ozs7Ozs7O0FBRUEsZUFBZSIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJEZW51bmNpYVB1YmxpY2FQYWdlLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyIvKipcclxuICogQ2FuYWwgQ2lkYWTDo286IE91dmlkb3JpYSBlIFJlZ2lzdHJvIFDDumJsaWNvIGRlIERlbsO6bmNpYXMgU2FuaXTDoXJpYXNcclxuICogUm90YTogL2RlbnVuY2lhLWNpZGFkYVxyXG4gKiBBY2Vzc28gbGl2cmUgcGFyYSBtdW7DrWNpcGVzIHJlZ2lzdHJhcmVtIHF1ZWl4YXMgKGFuw7RuaW1hcyBvdSBpZGVudGlmaWNhZGFzKVxyXG4gKiBlIGNvbnN1bHRhcmVtIG8gYW5kYW1lbnRvIHBvciBuw7ptZXJvIGRlIHByb3RvY29sbyBvZmljaWFsLlxyXG4gKi9cclxuXHJcbmltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgeyB1c2VGb3JtIH0gZnJvbSBcInJlYWN0LWhvb2stZm9ybVwiO1xyXG5pbXBvcnQgeyB6b2RSZXNvbHZlciB9IGZyb20gXCJAaG9va2Zvcm0vcmVzb2x2ZXJzL3pvZFwiO1xyXG5pbXBvcnQgKiBhcyB6IGZyb20gXCJ6b2RcIjtcclxuaW1wb3J0IHtcclxuICBBbGVydENpcmNsZSxcclxuICBBbGVydFRyaWFuZ2xlLFxyXG4gIEJ1aWxkaW5nMixcclxuICBDYWxlbmRhcixcclxuICBDaGVja0NpcmNsZTIsXHJcbiAgQ2xvY2ssXHJcbiAgRmlsZUNoZWNrMixcclxuICBMb2NrLFxyXG4gIE1hcFBpbixcclxuICBTZWFyY2gsXHJcbiAgU2VuZCxcclxuICBTaGllbGQsXHJcbiAgU2hpZWxkQWxlcnQsXHJcbiAgU2hpZWxkQ2hlY2ssXHJcbiAgVXNlcixcclxufSBmcm9tIFwibHVjaWRlLXJlYWN0XCI7XHJcbmltcG9ydCB7IEFQUF9DT05GSUcgfSBmcm9tIFwiLi4vLi4vY29uZmlnL2FwcC5jb25maWdcIjtcclxuaW1wb3J0IHtcclxuICB1c2VDb25zdWx0YXJQcm90b2NvbG9QdWJsaWNvLFxyXG4gIHVzZVJlZ2lzdHJhckRlbnVuY2lhTXV0YXRpb24sXHJcbn0gZnJvbSBcIi4uLy4uL2hvb2tzL3VzZU91dmlkb3JpYVwiO1xyXG5pbXBvcnQgeyBDYW5hbERlbnVuY2lhLCBHcmF2aWRhZGVEZW51bmNpYSwgUmVnaXN0cmFyRGVudW5jaWFEVE8gfSBmcm9tIFwiLi4vLi4vdHlwZXMvb3V2aWRvcmlhXCI7XHJcbmltcG9ydCB7IFN0YXR1c0RlbnVuY2lhQmFkZ2UgfSBmcm9tIFwiLi4vLi4vY29tcG9uZW50cy9vdXZpZG9yaWEvU3RhdHVzRGVudW5jaWFCYWRnZVwiO1xyXG5cclxuY29uc3QgZGVudW5jaWFDaWRhZGFTY2hlbWEgPSB6XHJcbiAgLm9iamVjdCh7XHJcbiAgICBsb2NhbF9kZW51bmNpYWRvX2lkZW50aWZpY2FjYW86IHpcclxuICAgICAgLnN0cmluZygpXHJcbiAgICAgIC5taW4oMywgXCJJbmZvcm1lIG8gbm9tZSBkbyBlc3RhYmVsZWNpbWVudG8gb3UgZGVzY3Jpw6fDo28gZG8gbG9jYWxcIiksXHJcbiAgICBsb2dyYWRvdXJvOiB6LnN0cmluZygpLm9wdGlvbmFsKCksXHJcbiAgICBudW1lcm86IHouc3RyaW5nKCkub3B0aW9uYWwoKSxcclxuICAgIGJhaXJybzogei5zdHJpbmcoKS5taW4oMiwgXCJJbmZvcm1lIG8gYmFpcnJvIG91IGNvbXVuaWRhZGUgcnVyYWxcIiksXHJcbiAgICBwb250b19yZWZlcmVuY2lhOiB6LnN0cmluZygpLm9wdGlvbmFsKCksXHJcbiAgICByZWxhdG9fZGVudW5jaWE6IHpcclxuICAgICAgLnN0cmluZygpXHJcbiAgICAgIC5taW4oMTUsIFwiUG9yIGZhdm9yLCByZWxhdGUgbyBmYXRvIG9jb3JyaWRvIGNvbSBubyBtw61uaW1vIDE1IGNhcmFjdGVyZXNcIiksXHJcblxyXG4gICAgZGVudW5jaWFudGVfYW5vbmltbzogei5ib29sZWFuKCksXHJcbiAgICBkZW51bmNpYW50ZV9ub21lOiB6LnN0cmluZygpLm9wdGlvbmFsKCksXHJcbiAgICBkZW51bmNpYW50ZV90ZWxlZm9uZTogei5zdHJpbmcoKS5vcHRpb25hbCgpLFxyXG4gICAgZGVudW5jaWFudGVfZW1haWw6IHouc3RyaW5nKCkuZW1haWwoXCJFLW1haWwgaW52w6FsaWRvXCIpLm9wdGlvbmFsKCkub3Ioei5saXRlcmFsKFwiXCIpKSxcclxuICB9KVxyXG4gIC5zdXBlclJlZmluZSgoZGF0YSwgY3R4KSA9PiB7XHJcbiAgICBpZiAoIWRhdGEuZGVudW5jaWFudGVfYW5vbmltbykge1xyXG4gICAgICBpZiAoIWRhdGEuZGVudW5jaWFudGVfbm9tZSB8fCBkYXRhLmRlbnVuY2lhbnRlX25vbWUudHJpbSgpLmxlbmd0aCA9PT0gMCkge1xyXG4gICAgICAgIGN0eC5hZGRJc3N1ZSh7XHJcbiAgICAgICAgICBjb2RlOiB6LlpvZElzc3VlQ29kZS5jdXN0b20sXHJcbiAgICAgICAgICBwYXRoOiBbXCJkZW51bmNpYW50ZV9ub21lXCJdLFxyXG4gICAgICAgICAgbWVzc2FnZTogXCJJbmZvcm1lIHNldSBub21lIGNvbXBsZXRvIHBhcmEgcmVnaXN0cm8gaWRlbnRpZmljYWRvLlwiLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfSk7XHJcblxyXG50eXBlIERlbnVuY2lhQ2lkYWRhRm9ybURhdGEgPSB6LmluZmVyPHR5cGVvZiBkZW51bmNpYUNpZGFkYVNjaGVtYT47XHJcblxyXG5leHBvcnQgY29uc3QgRGVudW5jaWFQdWJsaWNhUGFnZTogUmVhY3QuRkMgPSAoKSA9PiB7XHJcbiAgY29uc3QgW21vZG9BYmEsIHNldE1vZG9BYmFdID0gdXNlU3RhdGU8XCJyZWdpc3RyYXJcIiB8IFwiY29uc3VsdGFyXCI+KFwicmVnaXN0cmFyXCIpO1xyXG4gIGNvbnN0IFtwcm90b2NvbG9HZXJhZG8sIHNldFByb3RvY29sb0dlcmFkb10gPSB1c2VTdGF0ZTxzdHJpbmcgfCBudWxsPihudWxsKTtcclxuICBjb25zdCBbcHJvdG9jb2xvQnVzY2EsIHNldFByb3RvY29sb0J1c2NhXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtwcm90b2NvbG9BdGl2b0NvbnN1bHRhLCBzZXRQcm90b2NvbG9BdGl2b0NvbnN1bHRhXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG5cclxuICBjb25zdCByZWdpc3RyYXJNdXRhdGlvbiA9IHVzZVJlZ2lzdHJhckRlbnVuY2lhTXV0YXRpb24oKTtcclxuICBjb25zdCB7XHJcbiAgICBkYXRhOiBjb25zdWx0YURhdGEsXHJcbiAgICBpc0xvYWRpbmc6IGlzQ29uc3VsdGFuZG8sXHJcbiAgICBpc0Vycm9yOiBpc0Vycm9Db25zdWx0YSxcclxuICB9ID0gdXNlQ29uc3VsdGFyUHJvdG9jb2xvUHVibGljbyhwcm90b2NvbG9BdGl2b0NvbnN1bHRhKTtcclxuXHJcbiAgY29uc3Qge1xyXG4gICAgcmVnaXN0ZXIsXHJcbiAgICBoYW5kbGVTdWJtaXQsXHJcbiAgICB3YXRjaCxcclxuICAgIHJlc2V0LFxyXG4gICAgZm9ybVN0YXRlOiB7IGVycm9ycywgaXNTdWJtaXR0aW5nIH0sXHJcbiAgfSA9IHVzZUZvcm08RGVudW5jaWFDaWRhZGFGb3JtRGF0YT4oe1xyXG4gICAgcmVzb2x2ZXI6IHpvZFJlc29sdmVyKGRlbnVuY2lhQ2lkYWRhU2NoZW1hKSxcclxuICAgIGRlZmF1bHRWYWx1ZXM6IHtcclxuICAgICAgbG9jYWxfZGVudW5jaWFkb19pZGVudGlmaWNhY2FvOiBcIlwiLFxyXG4gICAgICBsb2dyYWRvdXJvOiBcIlwiLFxyXG4gICAgICBudW1lcm86IFwiXCIsXHJcbiAgICAgIGJhaXJybzogXCJcIixcclxuICAgICAgcG9udG9fcmVmZXJlbmNpYTogXCJcIixcclxuICAgICAgcmVsYXRvX2RlbnVuY2lhOiBcIlwiLFxyXG4gICAgICBkZW51bmNpYW50ZV9hbm9uaW1vOiB0cnVlLFxyXG4gICAgICBkZW51bmNpYW50ZV9ub21lOiBcIlwiLFxyXG4gICAgICBkZW51bmNpYW50ZV90ZWxlZm9uZTogXCJcIixcclxuICAgICAgZGVudW5jaWFudGVfZW1haWw6IFwiXCIsXHJcbiAgICB9LFxyXG4gIH0pO1xyXG5cclxuICBjb25zdCBkZW51bmNpYW50ZUFub25pbW8gPSB3YXRjaChcImRlbnVuY2lhbnRlX2Fub25pbW9cIik7XHJcblxyXG4gIGNvbnN0IG9uU3VibWl0ID0gYXN5bmMgKGRhdGE6IERlbnVuY2lhQ2lkYWRhRm9ybURhdGEpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHBheWxvYWQ6IFJlZ2lzdHJhckRlbnVuY2lhRFRPID0ge1xyXG4gICAgICAgIGxvY2FsX2RlbnVuY2lhZG9faWRlbnRpZmljYWNhbzogZGF0YS5sb2NhbF9kZW51bmNpYWRvX2lkZW50aWZpY2FjYW8udHJpbSgpLFxyXG4gICAgICAgIHJlbGF0b19kZW51bmNpYTogZGF0YS5yZWxhdG9fZGVudW5jaWEudHJpbSgpLFxyXG4gICAgICAgIG9yaWdlbTogXCJmb3JtdWxhcmlvX3dlYlwiLFxyXG4gICAgICAgIGdyYXZpZGFkZTogXCJtZWRpYVwiLFxyXG4gICAgICAgIGxvZ3JhZG91cm86IGRhdGEubG9ncmFkb3Vybz8udHJpbSgpIHx8IG51bGwsXHJcbiAgICAgICAgbnVtZXJvOiBkYXRhLm51bWVybz8udHJpbSgpIHx8IG51bGwsXHJcbiAgICAgICAgYmFpcnJvOiBkYXRhLmJhaXJyby50cmltKCksXHJcbiAgICAgICAgcG9udG9fcmVmZXJlbmNpYTogZGF0YS5wb250b19yZWZlcmVuY2lhPy50cmltKCkgfHwgbnVsbCxcclxuICAgICAgICBkZW51bmNpYW50ZV9hbm9uaW1vOiBkYXRhLmRlbnVuY2lhbnRlX2Fub25pbW8sXHJcbiAgICAgICAgZGVudW5jaWFudGVfbm9tZTogZGF0YS5kZW51bmNpYW50ZV9hbm9uaW1vID8gbnVsbCA6IGRhdGEuZGVudW5jaWFudGVfbm9tZT8udHJpbSgpIHx8IG51bGwsXHJcbiAgICAgICAgZGVudW5jaWFudGVfdGVsZWZvbmU6IGRhdGEuZGVudW5jaWFudGVfYW5vbmltbyA/IG51bGwgOiBkYXRhLmRlbnVuY2lhbnRlX3RlbGVmb25lPy50cmltKCkgfHwgbnVsbCxcclxuICAgICAgICBkZW51bmNpYW50ZV9lbWFpbDogZGF0YS5kZW51bmNpYW50ZV9hbm9uaW1vID8gbnVsbCA6IGRhdGEuZGVudW5jaWFudGVfZW1haWw/LnRyaW0oKSB8fCBudWxsLFxyXG4gICAgICB9O1xyXG5cclxuICAgICAgY29uc3QgcmVzdWx0YWRvID0gYXdhaXQgcmVnaXN0cmFyTXV0YXRpb24ubXV0YXRlQXN5bmMocGF5bG9hZCk7XHJcbiAgICAgIHNldFByb3RvY29sb0dlcmFkbyhyZXN1bHRhZG8ubnVtZXJvX3Byb3RvY29sbyk7XHJcbiAgICAgIHJlc2V0KCk7XHJcbiAgICB9IGNhdGNoIHtcclxuICAgICAgLy8gRXJybyBleGliaWRvIG5hIHRlbGFcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVDb25zdWx0YXIgPSAoZTogUmVhY3QuRm9ybUV2ZW50KSA9PiB7XHJcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XHJcbiAgICBpZiAocHJvdG9jb2xvQnVzY2EudHJpbSgpKSB7XHJcbiAgICAgIHNldFByb3RvY29sb0F0aXZvQ29uc3VsdGEocHJvdG9jb2xvQnVzY2EudHJpbSgpLnRvVXBwZXJDYXNlKCkpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cIm1pbi1oLXNjcmVlbiBiZy1zbGF0ZS01MCBkYXJrOmJnLXNsYXRlLTk1MCB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtc2xhdGUtMTAwIGZsZXggZmxleC1jb2wganVzdGlmeS1iZXR3ZWVuIGFudGlhbGlhc2VkIHNlbGVjdGlvbjpiZy10ZWFsLTUwMCBzZWxlY3Rpb246dGV4dC13aGl0ZVwiPlxyXG4gICAgICB7LyogVG9wbyBJbnN0aXR1Y2lvbmFsICovfVxyXG4gICAgICA8aGVhZGVyIGNsYXNzTmFtZT1cImJnLXdoaXRlIGRhcms6Ymctc2xhdGUtOTAwIGJvcmRlci1iIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtODAwIHNoYWRvdy0yeHNcIj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1heC13LTR4bCBteC1hdXRvIHB4LTQgcHktNCBmbGV4IGZsZXgtY29sIHNtOmZsZXgtcm93IHNtOml0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTRcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEwIGgtMTAgcm91bmRlZC14bCBiZy10ZWFsLTYwMCB0ZXh0LXdoaXRlIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGZvbnQtYm9sZCBzaGFkb3cteHNcIj5cclxuICAgICAgICAgICAgICA8U2hpZWxkIGNsYXNzTmFtZT1cInctNSBoLTUgdGV4dC13aGl0ZVwiIC8+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTQwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgYmxvY2tcIj5cclxuICAgICAgICAgICAgICAgIENhbmFsIE9maWNpYWwgZGUgT3V2aWRvcmlhIFNhbml0w6FyaWFcclxuICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1ib2xkIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZSBsZWFkaW5nLXRpZ2h0XCI+XHJcbiAgICAgICAgICAgICAgICB7QVBQX0NPTkZJRy5wcmVmZWl0dXJhfSAvIHtBUFBfQ09ORklHLnVmfVxyXG4gICAgICAgICAgICAgIDwvaDE+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgey8qIEFiYXMgU3VwZXJpb3JlcyAqL31cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgYmctc2xhdGUtMTAwIGRhcms6Ymctc2xhdGUtODAwIHAtMSByb3VuZGVkLXhsIHRleHQteHMgZm9udC1zZW1pYm9sZFwiPlxyXG4gICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgc2V0TW9kb0FiYShcInJlZ2lzdHJhclwiKTtcclxuICAgICAgICAgICAgICAgIHNldFByb3RvY29sb0dlcmFkbyhudWxsKTtcclxuICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT17YHB4LTMgcHktMS41IHJvdW5kZWQtbGcgdHJhbnNpdGlvbi1jb2xvcnMgJHtcclxuICAgICAgICAgICAgICAgIG1vZG9BYmEgPT09IFwicmVnaXN0cmFyXCJcclxuICAgICAgICAgICAgICAgICAgPyBcImJnLXdoaXRlIGRhcms6Ymctc2xhdGUtOTAwIHRleHQtdGVhbC03MDAgZGFyazp0ZXh0LXRlYWwtMzAwIHNoYWRvdy0yeHNcIlxyXG4gICAgICAgICAgICAgICAgICA6IFwidGV4dC1zbGF0ZS02MDAgZGFyazp0ZXh0LXNsYXRlLTQwMCBob3Zlcjp0ZXh0LXNsYXRlLTkwMFwiXHJcbiAgICAgICAgICAgICAgfWB9XHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICBSZWdpc3RyYXIgRGVuw7puY2lhXHJcbiAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0TW9kb0FiYShcImNvbnN1bHRhclwiKX1cclxuICAgICAgICAgICAgICBjbGFzc05hbWU9e2BweC0zIHB5LTEuNSByb3VuZGVkLWxnIHRyYW5zaXRpb24tY29sb3JzICR7XHJcbiAgICAgICAgICAgICAgICBtb2RvQWJhID09PSBcImNvbnN1bHRhclwiXHJcbiAgICAgICAgICAgICAgICAgID8gXCJiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTkwMCB0ZXh0LXRlYWwtNzAwIGRhcms6dGV4dC10ZWFsLTMwMCBzaGFkb3ctMnhzXCJcclxuICAgICAgICAgICAgICAgICAgOiBcInRleHQtc2xhdGUtNjAwIGRhcms6dGV4dC1zbGF0ZS00MDAgaG92ZXI6dGV4dC1zbGF0ZS05MDBcIlxyXG4gICAgICAgICAgICAgIH1gfVxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgQ29uc3VsdGFyIFByb3RvY29sb1xyXG4gICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2hlYWRlcj5cclxuXHJcbiAgICAgIHsvKiBDb250ZcO6ZG8gUHJpbmNpcGFsICovfVxyXG4gICAgICA8bWFpbiBjbGFzc05hbWU9XCJtYXgtdy0yeGwgdy1mdWxsIG14LWF1dG8gcHgtNCBweS04IHNwYWNlLXktNlwiPlxyXG4gICAgICAgIHttb2RvQWJhID09PSBcInJlZ2lzdHJhclwiID8gKFxyXG4gICAgICAgICAgPD5cclxuICAgICAgICAgICAge3Byb3RvY29sb0dlcmFkbyA/IChcclxuICAgICAgICAgICAgICAvKiBUZWxhIGRlIFN1Y2Vzc28gYW8gUmVnaXN0cmFyICovXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTkwMCBib3JkZXItMiBib3JkZXItZW1lcmFsZC0zMDAgZGFyazpib3JkZXItZW1lcmFsZC04MDAgcm91bmRlZC0zeGwgcC02IHNtOnAtOCB0ZXh0LWNlbnRlciBzcGFjZS15LTYgc2hhZG93LXNtIGFuaW1hdGUtaW4gZmFkZS1pbiB6b29tLWluLTk1IGR1cmF0aW9uLTIwMFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTE2IGgtMTYgcm91bmRlZC1mdWxsIGJnLWVtZXJhbGQtNTAgZGFyazpiZy1lbWVyYWxkLTk1MC82MCB0ZXh0LWVtZXJhbGQtNjAwIGJvcmRlciBib3JkZXItZW1lcmFsZC0yMDAgZGFyazpib3JkZXItZW1lcmFsZC04MDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgbXgtYXV0b1wiPlxyXG4gICAgICAgICAgICAgICAgICA8Q2hlY2tDaXJjbGUyIGNsYXNzTmFtZT1cInctMTAgaC0xMFwiIC8+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSBmb250LWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVzdCB0ZXh0LWVtZXJhbGQtNzAwIGRhcms6dGV4dC1lbWVyYWxkLTMwMCBiZy1lbWVyYWxkLTUwIGRhcms6YmctZW1lcmFsZC05NTAvNDAgcHgtMyBweS0wLjUgcm91bmRlZC1mdWxsIGJvcmRlciBib3JkZXItZW1lcmFsZC0yMDAgZGFyazpib3JkZXItZW1lcmFsZC04MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICBNYW5pZmVzdGHDp8OjbyBSZWdpc3RyYWRhIGNvbSBTdWNlc3NvXHJcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1ibGFjayB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGVcIj5cclxuICAgICAgICAgICAgICAgICAgICBQcm90b2NvbG8gU2FuaXTDoXJpbyBFbWl0aWRvXHJcbiAgICAgICAgICAgICAgICAgIDwvaDI+XHJcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS02MDAgZGFyazp0ZXh0LXNsYXRlLTQwMCBtYXgtdy1tZCBteC1hdXRvXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgU3VhIG1hbmlmZXN0YcOnw6NvIGZvaSBlbmNhbWluaGFkYSBwYXJhIGEgZXF1aXBlIGRlIHRyaWFnZW0gZGEgVmlnaWzDom5jaWEgU2FuaXTDoXJpYSBkZSB7QVBQX0NPTkZJRy5tdW5pY2lwaW99L01HLlxyXG4gICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNCBiZy1zbGF0ZS01MCBkYXJrOmJnLXNsYXRlLTgwMCByb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgbWF4LXctc20gbXgtYXV0byBzcGFjZS15LTFcIj5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1zbGF0ZS00MDAgdXBwZXJjYXNlIGZvbnQtYm9sZCBibG9ja1wiPlxyXG4gICAgICAgICAgICAgICAgICAgIE7Dum1lcm8gT2ZpY2lhbCBkZSBQcm90b2NvbG9cclxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtbW9ubyBmb250LWJsYWNrIHRleHQtdGVhbC03MDAgZGFyazp0ZXh0LXRlYWwtNDAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge3Byb3RvY29sb0dlcmFkb31cclxuICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTQgYmctdGVhbC01MC83MCBkYXJrOmJnLXRlYWwtOTUwLzMwIGJvcmRlciBib3JkZXItdGVhbC0yMDAgZGFyazpib3JkZXItdGVhbC04MDAvODAgcm91bmRlZC0yeGwgdGV4dC1sZWZ0IHRleHQteHMgdGV4dC10ZWFsLTkwMCBkYXJrOnRleHQtdGVhbC0yMDAgc3BhY2UteS0xXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImZvbnQtYm9sZCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPFNoaWVsZENoZWNrIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC10ZWFsLTYwMFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgR3VhcmRlIG8gc2V1IG7Dum1lcm8gZGUgcHJvdG9jb2xvOlxyXG4gICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIGxlYWRpbmctcmVsYXhlZCB0ZXh0LXRlYWwtODAwIGRhcms6dGV4dC10ZWFsLTMwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIENvbSBlc3RlIGPDs2RpZ28gdm9jw6ogcG9kZXLDoSBhY29tcGFuaGFyIG8gYW5kYW1lbnRvIGRhIGZpc2NhbGl6YcOnw6NvIGUgbGVyIGEgcmVzcG9zdGEgb2ZpY2lhbCBkYSBhdXRvcmlkYWRlIGRlIHNhw7pkZSBhIHF1YWxxdWVyIG1vbWVudG8uXHJcbiAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICBzZXRQcm90b2NvbG9HZXJhZG8obnVsbCk7XHJcbiAgICAgICAgICAgICAgICAgICAgcmVzZXQoKTtcclxuICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNSBweS0yIHRleHQteHMgZm9udC1ib2xkIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0zMDAgYmctc2xhdGUtMTAwIGRhcms6Ymctc2xhdGUtODAwIHJvdW5kZWQteGwgaG92ZXI6Ymctc2xhdGUtMjAwXCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgUmVnaXN0cmFyIE91dHJhIERlbsO6bmNpYVxyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgLyogRm9ybXVsw6FyaW8gZGUgUmVnaXN0cm8gZGUgRGVuw7puY2lhICovXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC0zeGwgcC02IHNtOnAtOCBzaGFkb3ctc20gc3BhY2UteS02XCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LWJvbGQgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPFNoaWVsZEFsZXJ0IGNsYXNzTmFtZT1cInctNSBoLTUgdGV4dC10ZWFsLTYwMFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4+UmVsYXRhciBJcnJlZ3VsYXJpZGFkZSBTYW5pdMOhcmlhPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2gyPlxyXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNTAwIGRhcms6dGV4dC1zbGF0ZS00MDAgbXQtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIEFqdWRlIGEgcHJvdGVnZXIgYSBzYcO6ZGUgcMO6YmxpY2EgZGUge0FQUF9DT05GSUcubXVuaWNpcGlvfS4gRGVuw7puY2lhcyBkZSBhbGltZW50b3MgaW1wcsOzcHJpb3MsIGZhbHRhIGRlIGhpZ2llbmUsIGNvbcOpcmNpbyBjbGFuZGVzdGlubyBvdSB2ZXRvcmVzLlxyXG4gICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICA8Zm9ybSBvblN1Ym1pdD17aGFuZGxlU3VibWl0KG9uU3VibWl0KX0gY2xhc3NOYW1lPVwic3BhY2UteS01XCI+XHJcbiAgICAgICAgICAgICAgICAgIHtyZWdpc3RyYXJNdXRhdGlvbi5pc0Vycm9yICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMyBiZy1yb3NlLTUwIGRhcms6Ymctcm9zZS05NTAvNDAgYm9yZGVyIGJvcmRlci1yb3NlLTIwMCBkYXJrOmJvcmRlci1yb3NlLTgwMCByb3VuZGVkLXhsIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRleHQteHMgdGV4dC1yb3NlLTcwMCBkYXJrOnRleHQtcm9zZS0zMDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxBbGVydFRyaWFuZ2xlIGNsYXNzTmFtZT1cInctNCBoLTQgc2hyaW5rLTBcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIE7Do28gZm9pIHBvc3PDrXZlbCBlbnZpYXIgYSBkZW7Dum5jaWEuIFZlcmlmaXF1ZSBvcyBjYW1wb3MgZSB0ZW50ZSBub3ZhbWVudGUuXHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICAgICAgICB7LyogT3DDp8OjbyBkZSBBbm9uaW1hdG8gKi99XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC00IGJnLXNsYXRlLTUwIGRhcms6Ymctc2xhdGUtODAwLzYwIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCByb3VuZGVkLTJ4bCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTNcIj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctOSBoLTkgcm91bmRlZC14bCBiZy1zbGF0ZS0yMDAgZGFyazpiZy1zbGF0ZS03MDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTMwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8TG9jayBjbGFzc05hbWU9XCJ3LTUgaC01XCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlIGJsb2NrXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgRGVuw7puY2lhIEFuw7RuaW1hIChTaWdpbG8gR2FyYW50aWRvKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtc2xhdGUtNTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgU3VhIGlkZW50aWRhZGUgbsOjbyBzZXLDoSBzb2xpY2l0YWRhIG5lbSBjb21wYXJ0aWxoYWRhLlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInJlbGF0aXZlIGlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBjdXJzb3ItcG9pbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHsuLi5yZWdpc3RlcihcImRlbnVuY2lhbnRlX2Fub25pbW9cIil9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInNyLW9ubHkgcGVlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEwIGgtNiBiZy1zbGF0ZS0yMDAgcGVlci1mb2N1czpvdXRsaW5lLW5vbmUgcm91bmRlZC1mdWxsIHBlZXIgZGFyazpiZy1zbGF0ZS03MDAgcGVlci1jaGVja2VkOmFmdGVyOnRyYW5zbGF0ZS14LWZ1bGwgcGVlci1jaGVja2VkOmFmdGVyOmJvcmRlci13aGl0ZSBhZnRlcjpjb250ZW50LVsnJ10gYWZ0ZXI6YWJzb2x1dGUgYWZ0ZXI6dG9wLVsycHhdIGFmdGVyOmxlZnQtWzJweF0gYWZ0ZXI6Ymctd2hpdGUgYWZ0ZXI6Ym9yZGVyLXNsYXRlLTMwMCBhZnRlcjpib3JkZXIgYWZ0ZXI6cm91bmRlZC1mdWxsIGFmdGVyOmgtNSBhZnRlcjp3LTUgYWZ0ZXI6dHJhbnNpdGlvbi1hbGwgcGVlci1jaGVja2VkOmJnLXRlYWwtNjAwXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgIHsvKiBTZSBOw4NPIGZvciBhbsO0bmltbywgZXhpYmUgY2FtcG9zIGRlIGNvbnRhdG8gKi99XHJcbiAgICAgICAgICAgICAgICAgIHshZGVudW5jaWFudGVBbm9uaW1vICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNCBiZy10ZWFsLTUwLzUwIGRhcms6YmctdGVhbC05NTAvMjAgYm9yZGVyIGJvcmRlci10ZWFsLTIwMCBkYXJrOmJvcmRlci10ZWFsLTgwMC82MCByb3VuZGVkLTJ4bCBzcGFjZS15LTMgYW5pbWF0ZS1pbiBmYWRlLWluIGR1cmF0aW9uLTE1MFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdGV4dC10ZWFsLTkwMCBkYXJrOnRleHQtdGVhbC0yMDAgYmxvY2tcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgU2V1cyBEYWRvcyBkZSBDb250YXRvIChDb25maWRlbmNpYWlzKVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMzAwIG1iLTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBTZXUgTm9tZSBDb21wbGV0byA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJvc2UtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHsuLi5yZWdpc3RlcihcImRlbnVuY2lhbnRlX25vbWVcIil9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJEaWdpdGUgc2V1IG5vbWUuLi5cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC0zIHB5LTIgdGV4dC14cyBiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTgwMCBib3JkZXIgYm9yZGVyLXRlYWwtMzAwIGRhcms6Ym9yZGVyLXRlYWwtNzAwIHJvdW5kZWQtbGcgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy10ZWFsLTUwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuZGVudW5jaWFudGVfbm9tZSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1yb3NlLTYwMCBtdC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmRlbnVuY2lhbnRlX25vbWUubWVzc2FnZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgc206Z3JpZC1jb2xzLTIgZ2FwLTNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0zMDAgbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgVGVsZWZvbmUgLyBXaGF0c0FwcCAoT3BjaW9uYWwpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsuLi5yZWdpc3RlcihcImRlbnVuY2lhbnRlX3RlbGVmb25lXCIpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCIoMzMpIDk5OTk5LTk5OTlcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMgcHktMiB0ZXh0LXhzIGJnLXdoaXRlIGRhcms6Ymctc2xhdGUtODAwIGJvcmRlciBib3JkZXItdGVhbC0zMDAgZGFyazpib3JkZXItdGVhbC03MDAgcm91bmRlZC1sZyB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGUgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLXRlYWwtNTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMzAwIG1iLTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIEUtbWFpbCBwYXJhIE5vdGlmaWNhw6fDtWVzIChPcGNpb25hbClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImVtYWlsXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsuLi5yZWdpc3RlcihcImRlbnVuY2lhbnRlX2VtYWlsXCIpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJzZXVlbWFpbEBleGVtcGxvLmNvbVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIHRleHQteHMgYmctd2hpdGUgZGFyazpiZy1zbGF0ZS04MDAgYm9yZGVyIGJvcmRlci10ZWFsLTMwMCBkYXJrOmJvcmRlci10ZWFsLTcwMCByb3VuZGVkLWxnIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZSBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctdGVhbC01MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICAgICAgICB7LyogTG9jYWwgRGVudW5jaWFkbyAqL31cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTNcIj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMzAwIG1iLTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgUXVhbCDDqSBvIEVzdGFiZWxlY2ltZW50byBvdSBMb2NhbCBEZW51bmNpYWRvPyA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJvc2UtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7Li4ucmVnaXN0ZXIoXCJsb2NhbF9kZW51bmNpYWRvX2lkZW50aWZpY2FjYW9cIil9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRXg6IE1lcmNhZG8gQ2VudHJhbCwgTGFuY2hvbmV0ZSBkbyBCYWlycm8sIFRlcnJlbm8gYmFsZGlvIGNvbSBhY8O6bXVsbyBkZSBsaXhvLi4uXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMgcHktMiB0ZXh0LXhzIGJnLXNsYXRlLTUwIGRhcms6Ymctc2xhdGUtODAwIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCByb3VuZGVkLWxnIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZSBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctdGVhbC01MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMubG9jYWxfZGVudW5jaWFkb19pZGVudGlmaWNhY2FvICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1yb3NlLTYwMCBtdC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5sb2NhbF9kZW51bmNpYWRvX2lkZW50aWZpY2FjYW8ubWVzc2FnZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIHNtOmdyaWQtY29scy0yIGdhcC0zXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0zMDAgbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIEJhaXJybyAvIENvbXVuaWRhZGUgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yb3NlLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7Li4ucmVnaXN0ZXIoXCJiYWlycm9cIil9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFeDogQ2VudHJvLCBCZWxhIFZpc3RhLCBab25hIFJ1cmFsLi4uXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIHRleHQteHMgYmctc2xhdGUtNTAgZGFyazpiZy1zbGF0ZS04MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQtbGcgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy10ZWFsLTUwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuYmFpcnJvICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LXJvc2UtNjAwIG10LTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuYmFpcnJvLm1lc3NhZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMzAwIG1iLTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBQb250byBkZSBSZWZlcsOqbmNpYVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgey4uLnJlZ2lzdGVyKFwicG9udG9fcmVmZXJlbmNpYVwiKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkV4OiBQcsOzeGltbyDDoCBwcmHDp2EgZGEgaWdyZWphLCBhbyBsYWRvIGRvIHBvc3RvIGRlIHNhw7pkZS4uLlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMgcHktMiB0ZXh0LXhzIGJnLXNsYXRlLTUwIGRhcms6Ymctc2xhdGUtODAwIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCByb3VuZGVkLWxnIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZSBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctdGVhbC01MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0zMDAgbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBFbmRlcmXDp28gQ29tcGxldG8gKFJ1YSBlIE7Dum1lcm8sIHNlIHNvdWJlcilcclxuICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7Li4ucmVnaXN0ZXIoXCJsb2dyYWRvdXJvXCIpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlJ1YSAvIEF2ZW5pZGEuLi5cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIHRleHQteHMgYmctc2xhdGUtNTAgZGFyazpiZy1zbGF0ZS04MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQtbGcgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy10ZWFsLTUwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgIHsvKiBSZWxhdG8gZG9zIEZhdG9zICovfVxyXG4gICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTMwMCBtYi0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICBEZXNjcmV2YSBvIEZhdG8gT2NvcnJpZG8gY29tIG8gTcOheGltbyBkZSBEZXRhbGhlcyA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJvc2UtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDx0ZXh0YXJlYVxyXG4gICAgICAgICAgICAgICAgICAgICAgcm93cz17NH1cclxuICAgICAgICAgICAgICAgICAgICAgIHsuLi5yZWdpc3RlcihcInJlbGF0b19kZW51bmNpYVwiKX1cclxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRGVzY3JldmEgbyBwcm9ibGVtYSBvYnNlcnZhZG86IGFsaW1lbnRvcyB2ZW5jaWRvcywgZmFsdGEgZGUgaGlnaWVuZSwgaW5zZXRvcywgb2RvcmVzIGZvcnRlcywgbWVkaWNhbWVudG9zIHNlbSBwcm9jZWTDqm5jaWEsIGhvcsOhcmlvIGVtIHF1ZSBvY29ycmV1Li4uXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBwLTMgdGV4dC14cyBiZy1zbGF0ZS01MCBkYXJrOmJnLXNsYXRlLTgwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC1sZyB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGUgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLXRlYWwtNTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgIHtlcnJvcnMucmVsYXRvX2RlbnVuY2lhICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtcm9zZS02MDAgbXQtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLnJlbGF0b19kZW51bmNpYS5tZXNzYWdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxyXG4gICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtpc1N1Ym1pdHRpbmd9XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB5LTMgdGV4dC14cyBmb250LWJvbGQgdGV4dC13aGl0ZSBiZy10ZWFsLTYwMCBob3ZlcjpiZy10ZWFsLTcwMCByb3VuZGVkLXhsIHNoYWRvdy14cyB0cmFuc2l0aW9uLWNvbG9ycyBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMiBkaXNhYmxlZDpvcGFjaXR5LTYwXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIDxTZW5kIGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuPntpc1N1Ym1pdHRpbmcgPyBcIkVudmlhbmRvIERlbsO6bmNpYS4uLlwiIDogXCJFbnZpYXIgRGVuw7puY2lhIFNhbml0w6FyaWFcIn08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgPC9mb3JtPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICApfVxyXG4gICAgICAgICAgPC8+XHJcbiAgICAgICAgKSA6IChcclxuICAgICAgICAgIC8qIENvbnN1bHRhIFDDumJsaWNhIHBvciBQcm90b2NvbG8gKi9cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGFyazpiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtODAwIHJvdW5kZWQtM3hsIHAtNiBzbTpwLTggc2hhZG93LXNtIHNwYWNlLXktNlwiPlxyXG4gICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGUgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgIDxTZWFyY2ggY2xhc3NOYW1lPVwidy01IGgtNSB0ZXh0LXRlYWwtNjAwXCIgLz5cclxuICAgICAgICAgICAgICAgIDxzcGFuPkNvbnN1bHRhciBBbmRhbWVudG8gZGEgRGVuw7puY2lhPC9zcGFuPlxyXG4gICAgICAgICAgICAgIDwvaDI+XHJcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTUwMCBkYXJrOnRleHQtc2xhdGUtNDAwIG10LTFcIj5cclxuICAgICAgICAgICAgICAgIERpZ2l0ZSBvIG7Dum1lcm8gZGUgcHJvdG9jb2xvIHJlY2ViaWRvIGFvIHJlZ2lzdHJhciBhIG1hbmlmZXN0YcOnw6NvIHBhcmEgdmVyaWZpY2FyIGEgcmVzcG9zdGEgb2ZpY2lhbC5cclxuICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgPGZvcm0gb25TdWJtaXQ9e2hhbmRsZUNvbnN1bHRhcn0gY2xhc3NOYW1lPVwiZmxleCBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFeDogREVOLTIwMjYtMDAwMVwiXHJcbiAgICAgICAgICAgICAgICB2YWx1ZT17cHJvdG9jb2xvQnVzY2F9XHJcbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFByb3RvY29sb0J1c2NhKGUudGFyZ2V0LnZhbHVlLnRvVXBwZXJDYXNlKCkpfVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleC0xIHB4LTMgcHktMiB0ZXh0LXhzIGJnLXNsYXRlLTUwIGRhcms6Ymctc2xhdGUtODAwIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCByb3VuZGVkLXhsIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZSBmb250LW1vbm8gZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLXRlYWwtNTAwIHVwcGVyY2FzZVwiXHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTUgcHktMiB0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXdoaXRlIGJnLXRlYWwtNjAwIGhvdmVyOmJnLXRlYWwtNzAwIHJvdW5kZWQteGwgc2hhZG93LXhzIHRyYW5zaXRpb24tY29sb3JzXCJcclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICBCdXNjYXJcclxuICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgPC9mb3JtPlxyXG5cclxuICAgICAgICAgICAge2lzQ29uc3VsdGFuZG8gJiYgKFxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC04IHRleHQtY2VudGVyIHRleHQteHMgdGV4dC1zbGF0ZS00MDAgZmxleCBmbGV4LWNvbCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy02IGgtNiBib3JkZXItMiBib3JkZXItdGVhbC01MDAgYm9yZGVyLXQtdHJhbnNwYXJlbnQgcm91bmRlZC1mdWxsIGFuaW1hdGUtc3BpbiBtYi0yXCIgLz5cclxuICAgICAgICAgICAgICAgIDxzcGFuPkNvbnN1bHRhbmRvIHByb3RvY29sbyBub3MgcmVnaXN0cm9zIG9maWNpYWlzLi4uPC9zcGFuPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgeyFpc0NvbnN1bHRhbmRvICYmIGlzRXJyb0NvbnN1bHRhICYmIHByb3RvY29sb0F0aXZvQ29uc3VsdGEgJiYgKFxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC00IGJnLXJvc2UtNTAgZGFyazpiZy1yb3NlLTk1MC80MCBib3JkZXIgYm9yZGVyLXJvc2UtMjAwIGRhcms6Ym9yZGVyLXJvc2UtODAwIHJvdW5kZWQtMnhsIHRleHQteHMgdGV4dC1yb3NlLTgwMCBkYXJrOnRleHQtcm9zZS0yMDAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgIDxBbGVydENpcmNsZSBjbGFzc05hbWU9XCJ3LTQgaC00IHNocmluay0wXCIgLz5cclxuICAgICAgICAgICAgICAgIDxzcGFuPlxyXG4gICAgICAgICAgICAgICAgICBQcm90b2NvbG8gPHN0cm9uZz57cHJvdG9jb2xvQXRpdm9Db25zdWx0YX08L3N0cm9uZz4gbsOjbyBsb2NhbGl6YWRvLiBWZXJpZmlxdWUgc2UgbyBjw7NkaWdvIGZvaSBkaWdpdGFkbyBjb3JyZXRhbWVudGUuXHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICB7IWlzQ29uc3VsdGFuZG8gJiYgY29uc3VsdGFEYXRhICYmIChcclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNSBiZy1zbGF0ZS01MCBkYXJrOmJnLXNsYXRlLTgwMC82MCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC0yeGwgc3BhY2UteS00XCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBwYi0zIGJvcmRlci1iIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1zbGF0ZS00MDAgdXBwZXJjYXNlIGZvbnQtYm9sZCBibG9ja1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgUHJvdG9jb2xvIE9maWNpYWxcclxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1iYXNlIGZvbnQtbW9ubyBmb250LWJvbGQgdGV4dC10ZWFsLTcwMCBkYXJrOnRleHQtdGVhbC00MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtjb25zdWx0YURhdGEubnVtZXJvX3Byb3RvY29sb31cclxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgPFN0YXR1c0RlbnVuY2lhQmFkZ2Ugc3RhdHVzPXtjb25zdWx0YURhdGEuc3RhdHVzfSAvPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHNwYWNlLXktMVwiPlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LXNsYXRlLTQwMCB1cHBlcmNhc2UgZm9udC1zZW1pYm9sZCBibG9ja1wiPlxyXG4gICAgICAgICAgICAgICAgICAgIExvY2FsIEFwdXJhZG9cclxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1zbGF0ZS04MDAgZGFyazp0ZXh0LXNsYXRlLTIwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHtjb25zdWx0YURhdGEubG9jYWxfZGVudW5jaWFkb19pZGVudGlmaWNhY2FvfVxyXG4gICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQteHMgc3BhY2UteS0xXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtc2xhdGUtNDAwIHVwcGVyY2FzZSBmb250LXNlbWlib2xkIGJsb2NrXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgRGF0YSBkZSBSZWNlYmltZW50b1xyXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0zMDBcIj5cclxuICAgICAgICAgICAgICAgICAgICB7bmV3IERhdGUoY29uc3VsdGFEYXRhLmRhdGFfcmVjZWJpbWVudG8pLnRvTG9jYWxlRGF0ZVN0cmluZyhcInB0LUJSXCIpfVxyXG4gICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICB7LyogUmVzcG9zdGEgT2ZpY2lhbCBhbyBEZW51bmNpYW50ZSAqL31cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0zLjUgYmctd2hpdGUgZGFyazpiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQteGwgc3BhY2UteS0xIHRleHQteHNcIj5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC10ZWFsLTcwMCBkYXJrOnRleHQtdGVhbC00MDAgdXBwZXJjYXNlIGZvbnQtYm9sZCBibG9jayBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPEZpbGVDaGVjazIgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgIFJlc3Bvc3RhIGRhIEF1dG9yaWRhZGUgU2FuaXTDoXJpYSBNdW5pY2lwYWw6XHJcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS04MDAgZGFyazp0ZXh0LXNsYXRlLTIwMCBsZWFkaW5nLXJlbGF4ZWQgZm9udC1tZWRpdW1cIj5cclxuICAgICAgICAgICAgICAgICAgICB7Y29uc3VsdGFEYXRhLnJlc3Bvc3RhX2FvX2RlbnVuY2lhbnRlIHx8XHJcbiAgICAgICAgICAgICAgICAgICAgICBcIkEgZGVuw7puY2lhIGVzdMOhIGVtIHByb2Nlc3NvIGRlIGFwdXJhw6fDo28gcGVsYSBlcXVpcGUgZmlzY2FsIGRlIGNhbXBvLiBBc3NpbSBxdWUgY29uY2x1w61kYSwgYSBkZWxpYmVyYcOnw6NvIHNlcsOhIGRpc3BvbmliaWxpemFkYSBuZXN0ZSBlc3Bhw6dvLlwifVxyXG4gICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgKX1cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICl9XHJcbiAgICAgIDwvbWFpbj5cclxuXHJcbiAgICAgIHsvKiBSb2RhcMOpIEluc3RpdHVjaW9uYWwgKi99XHJcbiAgICAgIDxmb290ZXIgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGFyazpiZy1zbGF0ZS05MDAgYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgcHktNiB0ZXh0LWNlbnRlciB0ZXh0LXhzIHRleHQtc2xhdGUtNTAwXCI+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYXgtdy0yeGwgbXgtYXV0byBweC00IHNwYWNlLXktMVwiPlxyXG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMzAwXCI+XHJcbiAgICAgICAgICAgIHtBUFBfQ09ORklHLnByZWZlaXR1cmF9IOKAoiB7QVBQX0NPTkZJRy5zZWNyZXRhcmlhfVxyXG4gICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1zbGF0ZS00MDBcIj5cclxuICAgICAgICAgICAge0FQUF9DT05GSUcub3JnYW99IOKAoiBDYW5hbCBkZSBBdGVuZGltZW50byBhbyBDaWRhZMOjb1xyXG4gICAgICAgICAgPC9wPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Zvb3Rlcj5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBEZW51bmNpYVB1YmxpY2FQYWdlO1xyXG4iXX0=