import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/licenciamento/RequerimentoDetailPage.tsx");const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport8_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport8_react_jsxDevRuntime["Fragment"];/**
* Detalhamento e Análise Técnica de Requerimento de Licenciamento
* Rota: /licenciamento/requerimentos/:id
* Permite avaliação documental, verificação de dados declarados e expedição do alvará.
*/
import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=0fd2848a";
import { Link, useNavigate, useParams } from "/node_modules/.vite/deps/react-router-dom.js?v=0fd2848a";
import { AlertCircle, AlertTriangle, ArrowLeft, Award, Building2, Clock, ExternalLink, FileSearch, FileText, XCircle } from "/node_modules/.vite/deps/lucide-react.js?v=0fd2848a";
import { ROUTES } from "/src/config/routes.config.ts";
import { useAnalisarRequerimentoMutation, useRequerimentoDetalhe } from "/src/hooks/useLicenciamento.ts";
import { StatusRequerimentoBadge } from "/src/components/licenciamento/StatusRequerimentoBadge.tsx";
import { ModalEmitirAlvara } from "/src/components/licenciamento/ModalEmitirAlvara.tsx";
import { RiscoBadge } from "/src/components/estabelecimentos/RiscoBadge.tsx";
var _jsxFileName = "E:/Projetos VSCODE/visa_braunas/src/pages/licenciamento/RequerimentoDetailPage.tsx";
import __vite__cjsImport8_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=0fd2848a";
var _s = $RefreshSig$();
export const RequerimentoDetailPage = () => {
	_s();
	const { id } = useParams();
	const navigate = useNavigate();
	const { data: req, isLoading, isError, refetch } = useRequerimentoDetalhe(id);
	const analisarMutation = useAnalisarRequerimentoMutation(id || "");
	// Estados locais para modais de ação
	const [modalEmitirAberta, setModalEmitirAberta] = useState(false);
	const [modalIndeferirAberta, setModalIndeferirAberta] = useState(false);
	const [modalAdequacaoAberta, setModalAdequacaoAberta] = useState(false);
	const [parecerTexto, setParecerTexto] = useState("");
	if (isLoading) {
		return /* @__PURE__ */ _jsxDEV("div", {
			className: "p-16 text-center text-slate-400 text-xs flex flex-col items-center justify-center",
			children: [/* @__PURE__ */ _jsxDEV("div", { className: "w-6 h-6 border-2 border-teal-500 border-t-transparent rounded-full animate-spin mb-3" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 58,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Carregando processo de licenciamento sanitário..." }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 59,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 57,
			columnNumber: 7
		}, this);
	}
	if (isError || !req) {
		return /* @__PURE__ */ _jsxDEV("div", {
			className: "p-8 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl text-center space-y-4",
			children: [
				/* @__PURE__ */ _jsxDEV(AlertTriangle, { className: "w-10 h-10 text-rose-500 mx-auto" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 67,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("h2", {
					className: "text-sm font-bold text-slate-900 dark:text-white",
					children: "Requerimento não encontrado ou indisponível"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 68,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("p", {
					className: "text-xs text-slate-500",
					children: "Não foi possível localizar os registros deste processo de licenciamento."
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 71,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV(Link, {
					to: ROUTES.LICENCIAMENTO.LIST,
					className: "inline-flex items-center gap-1.5 px-4 py-2 text-xs font-bold text-teal-700 bg-teal-50 rounded-xl border border-teal-200 hover:bg-teal-100",
					children: [/* @__PURE__ */ _jsxDEV(ArrowLeft, { className: "w-3.5 h-3.5" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 78,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Voltar para a Fila" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 79,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 74,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 66,
			columnNumber: 7
		}, this);
	}
	const dados = req.dados_declarados;
	const estab = req.estabelecimento;
	const handleTramitar = async (acao, motivo) => {
		try {
			await analisarMutation.mutateAsync({
				acao,
				parecer_ou_motivo: motivo || parecerTexto || undefined
			});
			setParecerTexto("");
			setModalIndeferirAberta(false);
			setModalAdequacaoAberta(false);
			refetch();
		} catch {}
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "space-y-6 max-w-5xl mx-auto pb-12",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex items-center justify-between",
				children: [/* @__PURE__ */ _jsxDEV(Link, {
					to: ROUTES.LICENCIAMENTO.LIST,
					className: "inline-flex items-center gap-2 text-xs font-semibold text-slate-600 dark:text-slate-300 hover:text-teal-600 dark:hover:text-teal-400 transition-colors",
					children: [/* @__PURE__ */ _jsxDEV(ArrowLeft, { className: "w-4 h-4" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 111,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Voltar para Fila de Licenciamento" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 112,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 107,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV(StatusRequerimentoBadge, { status: req.status }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 115,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 106,
				columnNumber: 7
			}, this),
			analisarMutation.isError && /* @__PURE__ */ _jsxDEV("div", {
				className: "p-4 bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 rounded-2xl flex items-center gap-2 text-xs text-rose-800 dark:text-rose-200",
				children: [/* @__PURE__ */ _jsxDEV(AlertCircle, { className: "w-4 h-4 text-rose-600 shrink-0" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 121,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("span", { children: analisarMutation.error instanceof Error ? analisarMutation.error.message : "Erro ao tramitar o requerimento sanitário." }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 122,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 120,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-xs space-y-4",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100 dark:border-slate-800",
						children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-2 text-[11px] font-bold text-teal-600 dark:text-teal-400 uppercase tracking-wider",
							children: [
								/* @__PURE__ */ _jsxDEV("span", { children: "Processo de Licenciamento Sanitário" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 135,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("span", { children: "•" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 136,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("span", {
									className: "capitalize",
									children: req.tipo_solicitacao === "concessao_inicial" ? "Concessão Inicial" : "Renovação Anual"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 137,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 134,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("h1", {
							className: "text-xl font-bold text-slate-900 dark:text-white mt-0.5",
							children: ["Protocolo: ", req.numero_protocolo]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 143,
							columnNumber: 13
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 133,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "text-right",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-[10px] text-slate-400 uppercase font-semibold block",
								children: "Data de Submissão"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 149,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "text-xs font-medium text-slate-700 dark:text-slate-300",
								children: new Date(req.data_submissao).toLocaleString("pt-BR")
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 152,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 148,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 132,
						columnNumber: 9
					}, this),
					req.parecer_fiscal && /* @__PURE__ */ _jsxDEV("div", {
						className: "p-3.5 bg-sky-50/70 dark:bg-sky-950/30 border border-sky-200 dark:border-sky-800 rounded-xl text-xs space-y-1",
						children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "text-[10px] uppercase font-bold text-sky-800 dark:text-sky-300 block",
							children: "Parecer Técnico do Fiscal:"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 161,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("p", {
							className: "text-slate-800 dark:text-slate-200 leading-relaxed",
							children: req.parecer_fiscal
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 164,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 160,
						columnNumber: 11
					}, this),
					req.motivo_indeferimento && /* @__PURE__ */ _jsxDEV("div", {
						className: "p-3.5 bg-rose-50/70 dark:bg-rose-950/30 border border-rose-200 dark:border-rose-800 rounded-xl text-xs space-y-1",
						children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "text-[10px] uppercase font-bold text-rose-800 dark:text-rose-300 block",
							children: "Motivo do Indeferimento:"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 172,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("p", {
							className: "text-rose-900 dark:text-rose-200 leading-relaxed",
							children: req.motivo_indeferimento
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 175,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 171,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "flex flex-wrap items-center gap-2 pt-2 border-t border-slate-100 dark:border-slate-800",
						children: [
							req.status === "pendente" && /* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								disabled: analisarMutation.isPending,
								onClick: () => handleTramitar("iniciar_analise", "Iniciada conferência documental formal."),
								className: "px-3.5 py-1.5 text-xs font-bold text-sky-700 dark:text-sky-300 bg-sky-50 dark:bg-sky-950/40 border border-sky-200 dark:border-sky-800 rounded-lg hover:bg-sky-100/60 shadow-2xs inline-flex items-center gap-1.5",
								children: [/* @__PURE__ */ _jsxDEV(FileSearch, { className: "w-3.5 h-3.5" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 190,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Iniciar Análise Documental" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 191,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 184,
								columnNumber: 13
							}, this),
							(req.status === "pendente" || req.status === "em_analise") && /* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								disabled: analisarMutation.isPending,
								onClick: () => handleTramitar("encaminhar_inspecao", "Documentação preliminar aprovada. Encaminhado para vistoria de campo."),
								className: "px-3.5 py-1.5 text-xs font-bold text-indigo-700 dark:text-indigo-300 bg-indigo-50 dark:bg-indigo-950/40 border border-indigo-200 dark:border-indigo-800 rounded-lg hover:bg-indigo-100/60 shadow-2xs inline-flex items-center gap-1.5",
								children: [/* @__PURE__ */ _jsxDEV(Clock, { className: "w-3.5 h-3.5" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 202,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Encaminhar para Vistoria" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 203,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 196,
								columnNumber: 13
							}, this),
							req.status !== "deferido" && req.status !== "cancelado" && /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
								/* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => setModalAdequacaoAberta(true),
									className: "px-3.5 py-1.5 text-xs font-bold text-amber-800 dark:text-amber-200 bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 rounded-lg hover:bg-amber-100/60 shadow-2xs inline-flex items-center gap-1.5",
									children: [/* @__PURE__ */ _jsxDEV(AlertCircle, { className: "w-3.5 h-3.5" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 214,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Solicitar Adequações" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 215,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 209,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => setModalEmitirAberta(true),
									className: "px-4 py-1.5 text-xs font-bold text-white bg-teal-600 hover:bg-teal-700 rounded-lg shadow-xs inline-flex items-center gap-1.5 transition-colors",
									children: [/* @__PURE__ */ _jsxDEV(Award, { className: "w-3.5 h-3.5" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 223,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Deferir & Emitir Alvará" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 224,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 218,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => setModalIndeferirAberta(true),
									className: "px-3.5 py-1.5 text-xs font-bold text-rose-700 dark:text-rose-300 bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 rounded-lg hover:bg-rose-100/60 shadow-2xs inline-flex items-center gap-1.5",
									children: [/* @__PURE__ */ _jsxDEV(XCircle, { className: "w-3.5 h-3.5" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 232,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Indeferir Pedido" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 233,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 227,
									columnNumber: 15
								}, this)
							] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 208,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 182,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 131,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-xs space-y-4",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center justify-between pb-2 border-b border-slate-100 dark:border-slate-800",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ _jsxDEV(Building2, { className: "w-4 h-4 text-teal-600" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 244,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("h2", {
								className: "text-xs font-bold uppercase tracking-wider text-slate-900 dark:text-white",
								children: "Estabelecimento Requerente"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 245,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 243,
							columnNumber: 11
						}, this), estab && /* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ _jsxDEV(RiscoBadge, { risco: estab.nivel_risco }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 251,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV(Link, {
								to: ROUTES.ESTABELECIMENTOS.DETALHE(estab.id),
								target: "_blank",
								className: "text-xs font-semibold text-teal-600 dark:text-teal-400 hover:underline flex items-center gap-1",
								children: [/* @__PURE__ */ _jsxDEV("span", { children: "Ver Prontuário" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 257,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV(ExternalLink, { className: "w-3 h-3" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 258,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 252,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 250,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 242,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs",
						children: [
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-slate-400 text-[10px] uppercase font-semibold block",
								children: "Razão Social"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 266,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "font-bold text-slate-900 dark:text-white",
								children: dados?.razao_social || estab?.razao_social || "Não informada"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 267,
								columnNumber: 13
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 265,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-slate-400 text-[10px] uppercase font-semibold block",
								children: "Nome Fantasia"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 273,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "font-medium text-slate-800 dark:text-slate-200",
								children: dados?.nome_fantasia || estab?.nome_fantasia || "Não informado"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 274,
								columnNumber: 13
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 272,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-slate-400 text-[10px] uppercase font-semibold block",
								children: "CNPJ / CPF"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 280,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "font-mono font-medium text-slate-800 dark:text-slate-200",
								children: dados?.cpf_cnpj || estab?.cnpj_cpf || "---"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 281,
								columnNumber: 13
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 279,
								columnNumber: 11
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 264,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "text-xs text-slate-600 dark:text-slate-300 pt-2 border-t border-slate-100 dark:border-slate-800",
						children: [
							/* @__PURE__ */ _jsxDEV("strong", { children: "Endereço Declarado:" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 288,
								columnNumber: 11
							}, this),
							" ",
							dados?.logradouro || estab?.logradouro || "Logradouro",
							",",
							" ",
							dados?.numero || estab?.numero || "S/N",
							" ",
							dados?.complemento && `(${dados.complemento})`,
							" -",
							" ",
							dados?.bairro || estab?.bairro || "Bairro",
							" • CEP: ",
							dados?.cep || estab?.cep || "---"
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 287,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 241,
				columnNumber: 7
			}, this),
			dados && /* @__PURE__ */ _jsxDEV("div", {
				className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-xs space-y-4",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-2 pb-2 border-b border-slate-100 dark:border-slate-800",
						children: [/* @__PURE__ */ _jsxDEV(FileText, { className: "w-4 h-4 text-teal-600" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 299,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("h2", {
							className: "text-xs font-bold uppercase tracking-wider text-slate-900 dark:text-white",
							children: "Informações Sanitárias Declaradas"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 300,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 298,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 text-xs",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "p-3 bg-slate-50 dark:bg-slate-800/50 rounded-xl space-y-1",
								children: [
									/* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-400 text-[10px] uppercase font-semibold block",
										children: "Atividade Principal (CNAE)"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 307,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("p", {
										className: "font-bold text-slate-900 dark:text-white",
										children: dados.cnae_principal_selecionado || dados.cnae_principal_codigo_manual || "Não especificado"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 310,
										columnNumber: 15
									}, this),
									dados.cnae_principal_descricao && /* @__PURE__ */ _jsxDEV("p", {
										className: "text-[11px] text-slate-600 dark:text-slate-300",
										children: dados.cnae_principal_descricao
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 314,
										columnNumber: 17
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 306,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "p-3 bg-slate-50 dark:bg-slate-800/50 rounded-xl space-y-1",
								children: [
									/* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-400 text-[10px] uppercase font-semibold block",
										children: "Abastecimento de Água"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 321,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("p", {
										className: "font-medium text-slate-800 dark:text-slate-200",
										children: dados.fonte_abastecimento_agua || "Rede Pública / Concessionária"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 324,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("p", {
										className: "text-[11px] text-slate-500",
										children: ["Reservatório: ", dados.possui_caixa_agua_propria === "sim" ? `Sim (${dados.capacidade_caixa_agua_litros || 0} L)` : "Não possui"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 327,
										columnNumber: 15
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 320,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "p-3 bg-slate-50 dark:bg-slate-800/50 rounded-xl space-y-1",
								children: [
									/* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-400 text-[10px] uppercase font-semibold block",
										children: "Responsável Técnico Declarado"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 333,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("p", {
										className: "font-bold text-slate-800 dark:text-slate-200",
										children: dados.rt_nome || "Não informado ou não exigido"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 336,
										columnNumber: 15
									}, this),
									dados.rt_conselho_classe && /* @__PURE__ */ _jsxDEV("p", {
										className: "text-[11px] text-slate-500",
										children: [
											dados.rt_conselho_classe,
											": ",
											dados.rt_numero_conselho,
											"/",
											dados.rt_conselho_uf
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 340,
										columnNumber: 17
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 332,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 305,
						columnNumber: 11
					}, this),
					dados.link_drive_documentos && /* @__PURE__ */ _jsxDEV("div", {
						className: "p-3.5 bg-teal-50/70 dark:bg-teal-950/30 border border-teal-200 dark:border-teal-800 rounded-xl flex items-center justify-between",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "text-xs",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "font-bold text-teal-900 dark:text-teal-200 block",
								children: "Pasta Digital de Documentos Comprobatórios"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 351,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "text-[11px] text-teal-700 dark:text-teal-300",
								children: "Acesse os laudos, alvará do corpo de bombeiros e documentos anexados pelo solicitante."
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 354,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 350,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("a", {
							href: dados.link_drive_documentos,
							target: "_blank",
							rel: "noreferrer",
							className: "px-3 py-1.5 text-xs font-bold text-white bg-teal-600 hover:bg-teal-700 rounded-lg inline-flex items-center gap-1.5 shadow-2xs",
							children: [/* @__PURE__ */ _jsxDEV("span", { children: "Abrir Pasta de Documentos" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 364,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV(ExternalLink, { className: "w-3.5 h-3.5" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 365,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 358,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 349,
						columnNumber: 13
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 297,
				columnNumber: 9
			}, this),
			modalAdequacaoAberta && /* @__PURE__ */ _jsxDEV("div", {
				className: "fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-xs",
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl w-full max-w-md p-6 shadow-2xl space-y-4",
					children: [
						/* @__PURE__ */ _jsxDEV("h3", {
							className: "text-sm font-bold text-slate-900 dark:text-white",
							children: "Solicitar Adequações / Notificar Exigências"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 376,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("p", {
							className: "text-xs text-slate-500",
							children: "Descreva as pendências documentais ou correções que o requerente deve sanar:"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 379,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("textarea", {
							rows: 4,
							value: parecerTexto,
							onChange: (e) => setParecerTexto(e.target.value),
							placeholder: "Ex: Anexar certificado atualizado de higienização do reservatório de água...",
							className: "w-full p-2.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-amber-500"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 382,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex justify-end gap-2 pt-2",
							children: [/* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								onClick: () => setModalAdequacaoAberta(false),
								className: "px-3 py-1.5 text-xs font-medium text-slate-600 hover:bg-slate-100 rounded-lg",
								children: "Cancelar"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 390,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								disabled: !parecerTexto.trim() || analisarMutation.isPending,
								onClick: () => handleTramitar("solicitar_adequacao"),
								className: "px-4 py-1.5 text-xs font-bold text-white bg-amber-600 hover:bg-amber-700 rounded-lg disabled:opacity-60",
								children: "Confirmar Notificação"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 397,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 389,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 375,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 374,
				columnNumber: 9
			}, this),
			modalIndeferirAberta && /* @__PURE__ */ _jsxDEV("div", {
				className: "fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-xs",
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl w-full max-w-md p-6 shadow-2xl space-y-4",
					children: [
						/* @__PURE__ */ _jsxDEV("h3", {
							className: "text-sm font-bold text-rose-700 dark:text-rose-400",
							children: "Indeferir Requerimento de Licenciamento"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 414,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("p", {
							className: "text-xs text-slate-500",
							children: "Justifique formalmente o motivo técnico ou legal do indeferimento do alvará:"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 417,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("textarea", {
							rows: 4,
							value: parecerTexto,
							onChange: (e) => setParecerTexto(e.target.value),
							placeholder: "Ex: Incompatibilidade de atividade no endereço ou reprovação em vistoria fiscal sem adequação no prazo legal...",
							className: "w-full p-2.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-rose-500"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 420,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex justify-end gap-2 pt-2",
							children: [/* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								onClick: () => setModalIndeferirAberta(false),
								className: "px-3 py-1.5 text-xs font-medium text-slate-600 hover:bg-slate-100 rounded-lg",
								children: "Cancelar"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 428,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								disabled: !parecerTexto.trim() || analisarMutation.isPending,
								onClick: () => handleTramitar("indeferir"),
								className: "px-4 py-1.5 text-xs font-bold text-white bg-rose-600 hover:bg-rose-700 rounded-lg disabled:opacity-60",
								children: "Confirmar Indeferimento"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 435,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 427,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 413,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 412,
				columnNumber: 9
			}, this),
			modalEmitirAberta && /* @__PURE__ */ _jsxDEV(ModalEmitirAlvara, {
				isOpen: modalEmitirAberta,
				onClose: () => setModalEmitirAberta(false),
				estabelecimentoId: req.estabelecimento_id,
				requerimentoId: req.id,
				razaoSocial: dados?.razao_social || estab?.razao_social,
				cnpjCpf: dados?.cpf_cnpj || estab?.cnpj_cpf,
				onSucesso: (alvara) => {
					navigate(ROUTES.LICENCIAMENTO.ALVARA_VIEW(alvara.id));
				}
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 450,
				columnNumber: 9
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 104,
		columnNumber: 5
	}, this);
};
_s(RequerimentoDetailPage, "n9bzlcXmMHUmc1FC59Oioacqdxc=", false, function() {
	return [
		useParams,
		useNavigate,
		useRequerimentoDetalhe,
		useAnalisarRequerimentoMutation
	];
});
_c = RequerimentoDetailPage;
export default RequerimentoDetailPage;
var _c;
$RefreshReg$(_c, "RequerimentoDetailPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/licenciamento/RequerimentoDetailPage.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("E:/Projetos VSCODE/visa_braunas/src/pages/licenciamento/RequerimentoDetailPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("E:/Projetos VSCODE/visa_braunas/src/pages/licenciamento/RequerimentoDetailPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "E:/Projetos VSCODE/visa_braunas/src/pages/licenciamento/RequerimentoDetailPage.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7Ozs7QUFNQSxPQUFPLFNBQVMsZ0JBQWdCO0FBQ2hDLFNBQVMsTUFBTSxhQUFhLGlCQUFpQjtBQUM3QyxTQUNFLGFBQ0EsZUFDQSxXQUNBLE9BQ0EsV0FHQSxPQUVBLGNBRUEsWUFDQSxVQVNBLGVBQ0s7QUFDUCxTQUFTLGNBQWM7QUFDdkIsU0FDRSxpQ0FDQSw4QkFDSztBQUNQLFNBQVMsK0JBQStCO0FBQ3hDLFNBQVMseUJBQXlCO0FBQ2xDLFNBQVMsa0JBQWtCOzs7O0FBRTNCLE9BQU8sTUFBTSwrQkFBeUM7O0NBQ3BELE1BQU0sRUFBRSxPQUFPLFVBQTBCO0NBQ3pDLE1BQU0sV0FBVyxZQUFZO0NBRTdCLE1BQU0sRUFBRSxNQUFNLEtBQUssV0FBVyxTQUFTLFlBQVksdUJBQXVCLEVBQUU7Q0FDNUUsTUFBTSxtQkFBbUIsZ0NBQWdDLE1BQU0sRUFBRTs7Q0FHakUsTUFBTSxDQUFDLG1CQUFtQix3QkFBd0IsU0FBUyxLQUFLO0NBQ2hFLE1BQU0sQ0FBQyxzQkFBc0IsMkJBQTJCLFNBQVMsS0FBSztDQUN0RSxNQUFNLENBQUMsc0JBQXNCLDJCQUEyQixTQUFTLEtBQUs7Q0FDdEUsTUFBTSxDQUFDLGNBQWMsbUJBQW1CLFNBQVMsRUFBRTtDQUVuRCxJQUFJLFdBQVc7RUFDYixPQUNFLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWYsQ0FDRSx3QkFBQyxPQUFELEVBQUssV0FBVSx1RkFBd0Y7Ozs7YUFDdkcsd0JBQUMsUUFBRCxZQUFNLG9EQUF1RDs7OztXQUMxRDs7Ozs7O0NBRVQ7Q0FFQSxJQUFJLFdBQVcsQ0FBQyxLQUFLO0VBQ25CLE9BQ0Usd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZjtJQUNFLHdCQUFDLGVBQUQsRUFBZSxXQUFVLGtDQUFtQzs7Ozs7SUFDNUQsd0JBQUMsTUFBRDtLQUFJLFdBQVU7ZUFBbUQ7SUFFN0Q7Ozs7O0lBQ0osd0JBQUMsS0FBRDtLQUFHLFdBQVU7ZUFBeUI7SUFFbkM7Ozs7O0lBQ0gsd0JBQUMsTUFBRDtLQUNFLElBQUksT0FBTyxjQUFjO0tBQ3pCLFdBQVU7ZUFGWixDQUlFLHdCQUFDLFdBQUQsRUFBVyxXQUFVLGNBQWU7Ozs7ZUFDcEMsd0JBQUMsUUFBRCxZQUFNLHFCQUF3Qjs7OzthQUMxQjs7Ozs7O0dBQ0g7Ozs7OztDQUVUO0NBRUEsTUFBTSxRQUFRLElBQUk7Q0FDbEIsTUFBTSxRQUFRLElBQUk7Q0FFbEIsTUFBTSxpQkFBaUIsT0FBTyxNQUFXLFdBQW9CO0VBQzNELElBQUk7R0FDRixNQUFNLGlCQUFpQixZQUFZO0lBQ2pDO0lBQ0EsbUJBQW1CLFVBQVUsZ0JBQWdCO0dBQy9DLENBQUM7R0FDRCxnQkFBZ0IsRUFBRTtHQUNsQix3QkFBd0IsS0FBSztHQUM3Qix3QkFBd0IsS0FBSztHQUM3QixRQUFRO0VBQ1YsUUFBUSxDQUVSO0NBQ0Y7Q0FFQSxPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQWY7R0FFRSx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsTUFBRDtLQUNFLElBQUksT0FBTyxjQUFjO0tBQ3pCLFdBQVU7ZUFGWixDQUlFLHdCQUFDLFdBQUQsRUFBVyxXQUFVLFVBQVc7Ozs7ZUFDaEMsd0JBQUMsUUFBRCxZQUFNLG9DQUF1Qzs7OzthQUN6Qzs7Ozs7Y0FFTix3QkFBQyx5QkFBRCxFQUF5QixRQUFRLElBQUksT0FBUzs7OztZQUMzQzs7Ozs7O0dBR0osaUJBQWlCLFdBQ2hCLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxhQUFELEVBQWEsV0FBVSxpQ0FBa0M7Ozs7Y0FDekQsd0JBQUMsUUFBRCxZQUNHLGlCQUFpQixpQkFBaUIsUUFDL0IsaUJBQWlCLE1BQU0sVUFDdkIsNkNBQ0E7Ozs7WUFDSDs7Ozs7O0dBSVAsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZjtLQUNFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmO1FBQ0Usd0JBQUMsUUFBRCxZQUFNLHNDQUF5Qzs7Ozs7UUFDL0Msd0JBQUMsUUFBRCxZQUFNLElBQU87Ozs7O1FBQ2Isd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQ2IsSUFBSSxxQkFBcUIsc0JBQ3RCLHNCQUNBO1FBQ0E7Ozs7O09BQ0g7Ozs7O2dCQUNMLHdCQUFDLE1BQUQ7T0FBSSxXQUFVO2lCQUFkLENBQXdFLGVBQzFELElBQUksZ0JBQ2Q7Ozs7O2NBQ0Q7Ozs7Z0JBRUwsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBMkQ7T0FFckU7Ozs7aUJBQ04sd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQ2IsSUFBSSxLQUFLLElBQUksY0FBYyxDQUFDLENBQUMsZUFBZSxPQUFPO09BQ2hEOzs7O2VBQ0g7Ozs7O2NBQ0Y7Ozs7OztLQUdKLElBQUksa0JBQ0gsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxRQUFEO09BQU0sV0FBVTtpQkFBdUU7TUFFakY7Ozs7Z0JBQ04sd0JBQUMsS0FBRDtPQUFHLFdBQVU7aUJBQ1YsSUFBSTtNQUNKOzs7O2NBQ0E7Ozs7OztLQUdOLElBQUksd0JBQ0gsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxRQUFEO09BQU0sV0FBVTtpQkFBeUU7TUFFbkY7Ozs7Z0JBQ04sd0JBQUMsS0FBRDtPQUFHLFdBQVU7aUJBQ1YsSUFBSTtNQUNKOzs7O2NBQ0E7Ozs7OztLQUlQLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmO09BQ0csSUFBSSxXQUFXLGNBQ2Qsd0JBQUMsVUFBRDtRQUNFLE1BQUs7UUFDTCxVQUFVLGlCQUFpQjtRQUMzQixlQUFlLGVBQWUsbUJBQW1CLHlDQUF5QztRQUMxRixXQUFVO2tCQUpaLENBTUUsd0JBQUMsWUFBRCxFQUFZLFdBQVUsY0FBZTs7OztrQkFDckMsd0JBQUMsUUFBRCxZQUFNLDZCQUFnQzs7OztnQkFDaEM7Ozs7OztRQUdSLElBQUksV0FBVyxjQUFjLElBQUksV0FBVyxpQkFDNUMsd0JBQUMsVUFBRDtRQUNFLE1BQUs7UUFDTCxVQUFVLGlCQUFpQjtRQUMzQixlQUFlLGVBQWUsdUJBQXVCLHVFQUF1RTtRQUM1SCxXQUFVO2tCQUpaLENBTUUsd0JBQUMsT0FBRCxFQUFPLFdBQVUsY0FBZTs7OztrQkFDaEMsd0JBQUMsUUFBRCxZQUFNLDJCQUE4Qjs7OztnQkFDOUI7Ozs7OztPQUdULElBQUksV0FBVyxjQUFjLElBQUksV0FBVyxlQUMzQztRQUNFLHdCQUFDLFVBQUQ7U0FDRSxNQUFLO1NBQ0wsZUFBZSx3QkFBd0IsSUFBSTtTQUMzQyxXQUFVO21CQUhaLENBS0Usd0JBQUMsYUFBRCxFQUFhLFdBQVUsY0FBZTs7OzttQkFDdEMsd0JBQUMsUUFBRCxZQUFNLHVCQUEwQjs7OztpQkFDMUI7Ozs7OztRQUVSLHdCQUFDLFVBQUQ7U0FDRSxNQUFLO1NBQ0wsZUFBZSxxQkFBcUIsSUFBSTtTQUN4QyxXQUFVO21CQUhaLENBS0Usd0JBQUMsT0FBRCxFQUFPLFdBQVUsY0FBZTs7OzttQkFDaEMsd0JBQUMsUUFBRCxZQUFNLDBCQUE2Qjs7OztpQkFDN0I7Ozs7OztRQUVSLHdCQUFDLFVBQUQ7U0FDRSxNQUFLO1NBQ0wsZUFBZSx3QkFBd0IsSUFBSTtTQUMzQyxXQUFVO21CQUhaLENBS0Usd0JBQUMsU0FBRCxFQUFTLFdBQVUsY0FBZTs7OzttQkFDbEMsd0JBQUMsUUFBRCxZQUFNLG1CQUFzQjs7OztpQkFDdEI7Ozs7OztPQUNSOzs7OztNQUVEOzs7Ozs7SUFDRjs7Ozs7O0dBR0wsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZjtLQUNFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxXQUFELEVBQVcsV0FBVSx3QkFBeUI7Ozs7aUJBQzlDLHdCQUFDLE1BQUQ7UUFBSSxXQUFVO2tCQUE0RTtPQUV0Rjs7OztlQUNEOzs7OztnQkFDSixTQUNDLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsWUFBRCxFQUFZLE9BQU8sTUFBTSxZQUFjOzs7O2lCQUN2Qyx3QkFBQyxNQUFEO1FBQ0UsSUFBSSxPQUFPLGlCQUFpQixRQUFRLE1BQU0sRUFBRTtRQUM1QyxRQUFPO1FBQ1AsV0FBVTtrQkFIWixDQUtFLHdCQUFDLFFBQUQsWUFBTSxpQkFBb0I7Ozs7a0JBQzFCLHdCQUFDLGNBQUQsRUFBYyxXQUFVLFVBQVc7Ozs7Z0JBQy9COzs7OztlQUNIOzs7OztjQUVKOzs7Ozs7S0FFTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZjtPQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBMkQ7T0FBa0I7Ozs7aUJBQzdGLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUNiLE9BQU8sZ0JBQWdCLE9BQU8sZ0JBQWdCO09BQzNDOzs7O2VBQ0g7Ozs7O09BRUwsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUEyRDtPQUFtQjs7OztpQkFDOUYsd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQ2IsT0FBTyxpQkFBaUIsT0FBTyxpQkFBaUI7T0FDN0M7Ozs7ZUFDSDs7Ozs7T0FFTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQTJEO09BQWdCOzs7O2lCQUMzRix3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFDYixPQUFPLFlBQVksT0FBTyxZQUFZO09BQ25DOzs7O2VBQ0g7Ozs7O01BQ0Y7Ozs7OztLQUVMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmO09BQ0Usd0JBQUMsVUFBRCxZQUFRLHNCQUEyQjs7Ozs7T0FBQztPQUFFLE9BQU8sY0FBYyxPQUFPLGNBQWM7T0FBYTtPQUFFO09BQzlGLE9BQU8sVUFBVSxPQUFPLFVBQVU7T0FBTztPQUN6QyxPQUFPLGVBQWUsSUFBSSxNQUFNLFlBQVk7T0FBRztPQUFHO09BQ2xELE9BQU8sVUFBVSxPQUFPLFVBQVU7T0FBUztPQUFTLE9BQU8sT0FBTyxPQUFPLE9BQU87TUFDOUU7Ozs7OztJQUNGOzs7Ozs7R0FHSixTQUNDLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWY7S0FDRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLFVBQUQsRUFBVSxXQUFVLHdCQUF5Qjs7OztnQkFDN0Msd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQTRFO01BRXRGOzs7O2NBQ0Q7Ozs7OztLQUVMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmO09BQ0Usd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWY7U0FDRSx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBMkQ7U0FFckU7Ozs7O1NBQ04sd0JBQUMsS0FBRDtVQUFHLFdBQVU7b0JBQ1YsTUFBTSw4QkFBOEIsTUFBTSxnQ0FBZ0M7U0FDMUU7Ozs7O1NBQ0YsTUFBTSw0QkFDTCx3QkFBQyxLQUFEO1VBQUcsV0FBVTtvQkFDVixNQUFNO1NBQ047Ozs7O1FBRUY7Ozs7OztPQUVMLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmO1NBQ0Usd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQTJEO1NBRXJFOzs7OztTQUNOLHdCQUFDLEtBQUQ7VUFBRyxXQUFVO29CQUNWLE1BQU0sNEJBQTRCO1NBQ2xDOzs7OztTQUNILHdCQUFDLEtBQUQ7VUFBRyxXQUFVO29CQUFiLENBQTBDLGtCQUN6QixNQUFNLDhCQUE4QixRQUFRLFFBQVEsTUFBTSxnQ0FBZ0MsRUFBRSxPQUFPLFlBQ2pIOzs7Ozs7UUFDQTs7Ozs7O09BRUwsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWY7U0FDRSx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBMkQ7U0FFckU7Ozs7O1NBQ04sd0JBQUMsS0FBRDtVQUFHLFdBQVU7b0JBQ1YsTUFBTSxXQUFXO1NBQ2pCOzs7OztTQUNGLE1BQU0sc0JBQ0wsd0JBQUMsS0FBRDtVQUFHLFdBQVU7b0JBQWI7V0FDRyxNQUFNO1dBQW1CO1dBQUcsTUFBTTtXQUFtQjtXQUFFLE1BQU07VUFDN0Q7Ozs7OztRQUVGOzs7Ozs7TUFDRjs7Ozs7O0tBR0osTUFBTSx5QkFDTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQW1EO09BRTdEOzs7O2lCQUNOLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUErQztPQUV6RDs7OztlQUNIOzs7OztnQkFDTCx3QkFBQyxLQUFEO09BQ0UsTUFBTSxNQUFNO09BQ1osUUFBTztPQUNQLEtBQUk7T0FDSixXQUFVO2lCQUpaLENBTUUsd0JBQUMsUUFBRCxZQUFNLDRCQUErQjs7OztpQkFDckMsd0JBQUMsY0FBRCxFQUFjLFdBQVUsY0FBZTs7OztlQUN0Qzs7Ozs7Y0FDQTs7Ozs7O0lBRUo7Ozs7OztHQUlOLHdCQUNDLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQ2Isd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZjtNQUNFLHdCQUFDLE1BQUQ7T0FBSSxXQUFVO2lCQUFtRDtNQUU3RDs7Ozs7TUFDSix3QkFBQyxLQUFEO09BQUcsV0FBVTtpQkFBeUI7TUFFbkM7Ozs7O01BQ0gsd0JBQUMsWUFBRDtPQUNFLE1BQU07T0FDTixPQUFPO09BQ1AsV0FBVyxNQUFNLGdCQUFnQixFQUFFLE9BQU8sS0FBSztPQUMvQyxhQUFZO09BQ1osV0FBVTtNQUNYOzs7OztNQUNELHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsVUFBRDtRQUNFLE1BQUs7UUFDTCxlQUFlLHdCQUF3QixLQUFLO1FBQzVDLFdBQVU7a0JBQ1g7T0FFTzs7OztpQkFDUix3QkFBQyxVQUFEO1FBQ0UsTUFBSztRQUNMLFVBQVUsQ0FBQyxhQUFhLEtBQUssS0FBSyxpQkFBaUI7UUFDbkQsZUFBZSxlQUFlLHFCQUFxQjtRQUNuRCxXQUFVO2tCQUNYO09BRU87Ozs7ZUFDTDs7Ozs7O0tBQ0Y7Ozs7OztHQUNGOzs7OztHQUlOLHdCQUNDLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQ2Isd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZjtNQUNFLHdCQUFDLE1BQUQ7T0FBSSxXQUFVO2lCQUFxRDtNQUUvRDs7Ozs7TUFDSix3QkFBQyxLQUFEO09BQUcsV0FBVTtpQkFBeUI7TUFFbkM7Ozs7O01BQ0gsd0JBQUMsWUFBRDtPQUNFLE1BQU07T0FDTixPQUFPO09BQ1AsV0FBVyxNQUFNLGdCQUFnQixFQUFFLE9BQU8sS0FBSztPQUMvQyxhQUFZO09BQ1osV0FBVTtNQUNYOzs7OztNQUNELHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsVUFBRDtRQUNFLE1BQUs7UUFDTCxlQUFlLHdCQUF3QixLQUFLO1FBQzVDLFdBQVU7a0JBQ1g7T0FFTzs7OztpQkFDUix3QkFBQyxVQUFEO1FBQ0UsTUFBSztRQUNMLFVBQVUsQ0FBQyxhQUFhLEtBQUssS0FBSyxpQkFBaUI7UUFDbkQsZUFBZSxlQUFlLFdBQVc7UUFDekMsV0FBVTtrQkFDWDtPQUVPOzs7O2VBQ0w7Ozs7OztLQUNGOzs7Ozs7R0FDRjs7Ozs7R0FJTixxQkFDQyx3QkFBQyxtQkFBRDtJQUNFLFFBQVE7SUFDUixlQUFlLHFCQUFxQixLQUFLO0lBQ3pDLG1CQUFtQixJQUFJO0lBQ3ZCLGdCQUFnQixJQUFJO0lBQ3BCLGFBQWEsT0FBTyxnQkFBZ0IsT0FBTztJQUMzQyxTQUFTLE9BQU8sWUFBWSxPQUFPO0lBQ25DLFlBQVksV0FBVztLQUNyQixTQUFTLE9BQU8sY0FBYyxZQUFZLE9BQU8sRUFBRSxDQUFDO0lBQ3REO0dBQ0Q7Ozs7O0VBRUE7Ozs7OztBQUVUOzs7Ozs7Ozs7O0FBRUEsZUFBZSIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJSZXF1ZXJpbWVudG9EZXRhaWxQYWdlLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyIvKipcclxuICogRGV0YWxoYW1lbnRvIGUgQW7DoWxpc2UgVMOpY25pY2EgZGUgUmVxdWVyaW1lbnRvIGRlIExpY2VuY2lhbWVudG9cclxuICogUm90YTogL2xpY2VuY2lhbWVudG8vcmVxdWVyaW1lbnRvcy86aWRcclxuICogUGVybWl0ZSBhdmFsaWHDp8OjbyBkb2N1bWVudGFsLCB2ZXJpZmljYcOnw6NvIGRlIGRhZG9zIGRlY2xhcmFkb3MgZSBleHBlZGnDp8OjbyBkbyBhbHZhcsOhLlxyXG4gKi9cclxuXHJcbmltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgeyBMaW5rLCB1c2VOYXZpZ2F0ZSwgdXNlUGFyYW1zIH0gZnJvbSBcInJlYWN0LXJvdXRlci1kb21cIjtcclxuaW1wb3J0IHtcclxuICBBbGVydENpcmNsZSxcclxuICBBbGVydFRyaWFuZ2xlLFxyXG4gIEFycm93TGVmdCxcclxuICBBd2FyZCxcclxuICBCdWlsZGluZzIsXHJcbiAgQ2FsZW5kYXIsXHJcbiAgQ2hlY2tDaXJjbGUyLFxyXG4gIENsb2NrLFxyXG4gIERyb3BsZXRzLFxyXG4gIEV4dGVybmFsTGluayxcclxuICBGaWxlQ2hlY2syLFxyXG4gIEZpbGVTZWFyY2gsXHJcbiAgRmlsZVRleHQsXHJcbiAgTWFpbCxcclxuICBNYXBQaW4sXHJcbiAgUGhvbmUsXHJcbiAgU2VuZCxcclxuICBTaGllbGQsXHJcbiAgVXNlcixcclxuICBVc2VyQ2hlY2ssXHJcbiAgWCxcclxuICBYQ2lyY2xlLFxyXG59IGZyb20gXCJsdWNpZGUtcmVhY3RcIjtcclxuaW1wb3J0IHsgUk9VVEVTIH0gZnJvbSBcIi4uLy4uL2NvbmZpZy9yb3V0ZXMuY29uZmlnXCI7XHJcbmltcG9ydCB7XHJcbiAgdXNlQW5hbGlzYXJSZXF1ZXJpbWVudG9NdXRhdGlvbixcclxuICB1c2VSZXF1ZXJpbWVudG9EZXRhbGhlLFxyXG59IGZyb20gXCIuLi8uLi9ob29rcy91c2VMaWNlbmNpYW1lbnRvXCI7XHJcbmltcG9ydCB7IFN0YXR1c1JlcXVlcmltZW50b0JhZGdlIH0gZnJvbSBcIi4uLy4uL2NvbXBvbmVudHMvbGljZW5jaWFtZW50by9TdGF0dXNSZXF1ZXJpbWVudG9CYWRnZVwiO1xyXG5pbXBvcnQgeyBNb2RhbEVtaXRpckFsdmFyYSB9IGZyb20gXCIuLi8uLi9jb21wb25lbnRzL2xpY2VuY2lhbWVudG8vTW9kYWxFbWl0aXJBbHZhcmFcIjtcclxuaW1wb3J0IHsgUmlzY29CYWRnZSB9IGZyb20gXCIuLi8uLi9jb21wb25lbnRzL2VzdGFiZWxlY2ltZW50b3MvUmlzY29CYWRnZVwiO1xyXG5cclxuZXhwb3J0IGNvbnN0IFJlcXVlcmltZW50b0RldGFpbFBhZ2U6IFJlYWN0LkZDID0gKCkgPT4ge1xyXG4gIGNvbnN0IHsgaWQgfSA9IHVzZVBhcmFtczx7IGlkOiBzdHJpbmcgfT4oKTtcclxuICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKCk7XHJcblxyXG4gIGNvbnN0IHsgZGF0YTogcmVxLCBpc0xvYWRpbmcsIGlzRXJyb3IsIHJlZmV0Y2ggfSA9IHVzZVJlcXVlcmltZW50b0RldGFsaGUoaWQpO1xyXG4gIGNvbnN0IGFuYWxpc2FyTXV0YXRpb24gPSB1c2VBbmFsaXNhclJlcXVlcmltZW50b011dGF0aW9uKGlkIHx8IFwiXCIpO1xyXG5cclxuICAvLyBFc3RhZG9zIGxvY2FpcyBwYXJhIG1vZGFpcyBkZSBhw6fDo29cclxuICBjb25zdCBbbW9kYWxFbWl0aXJBYmVydGEsIHNldE1vZGFsRW1pdGlyQWJlcnRhXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbbW9kYWxJbmRlZmVyaXJBYmVydGEsIHNldE1vZGFsSW5kZWZlcmlyQWJlcnRhXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbbW9kYWxBZGVxdWFjYW9BYmVydGEsIHNldE1vZGFsQWRlcXVhY2FvQWJlcnRhXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbcGFyZWNlclRleHRvLCBzZXRQYXJlY2VyVGV4dG9dID0gdXNlU3RhdGUoXCJcIik7XHJcblxyXG4gIGlmIChpc0xvYWRpbmcpIHtcclxuICAgIHJldHVybiAoXHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0xNiB0ZXh0LWNlbnRlciB0ZXh0LXNsYXRlLTQwMCB0ZXh0LXhzIGZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyXCI+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTYgaC02IGJvcmRlci0yIGJvcmRlci10ZWFsLTUwMCBib3JkZXItdC10cmFuc3BhcmVudCByb3VuZGVkLWZ1bGwgYW5pbWF0ZS1zcGluIG1iLTNcIiAvPlxyXG4gICAgICAgIDxzcGFuPkNhcnJlZ2FuZG8gcHJvY2Vzc28gZGUgbGljZW5jaWFtZW50byBzYW5pdMOhcmlvLi4uPC9zcGFuPlxyXG4gICAgICA8L2Rpdj5cclxuICAgICk7XHJcbiAgfVxyXG5cclxuICBpZiAoaXNFcnJvciB8fCAhcmVxKSB7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtOCBiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC0yeGwgdGV4dC1jZW50ZXIgc3BhY2UteS00XCI+XHJcbiAgICAgICAgPEFsZXJ0VHJpYW5nbGUgY2xhc3NOYW1lPVwidy0xMCBoLTEwIHRleHQtcm9zZS01MDAgbXgtYXV0b1wiIC8+XHJcbiAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1ib2xkIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZVwiPlxyXG4gICAgICAgICAgUmVxdWVyaW1lbnRvIG7Do28gZW5jb250cmFkbyBvdSBpbmRpc3BvbsOtdmVsXHJcbiAgICAgICAgPC9oMj5cclxuICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNTAwXCI+XHJcbiAgICAgICAgICBOw6NvIGZvaSBwb3Nzw612ZWwgbG9jYWxpemFyIG9zIHJlZ2lzdHJvcyBkZXN0ZSBwcm9jZXNzbyBkZSBsaWNlbmNpYW1lbnRvLlxyXG4gICAgICAgIDwvcD5cclxuICAgICAgICA8TGlua1xyXG4gICAgICAgICAgdG89e1JPVVRFUy5MSUNFTkNJQU1FTlRPLkxJU1R9XHJcbiAgICAgICAgICBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBweC00IHB5LTIgdGV4dC14cyBmb250LWJvbGQgdGV4dC10ZWFsLTcwMCBiZy10ZWFsLTUwIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci10ZWFsLTIwMCBob3ZlcjpiZy10ZWFsLTEwMFwiXHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgPEFycm93TGVmdCBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNVwiIC8+XHJcbiAgICAgICAgICA8c3Bhbj5Wb2x0YXIgcGFyYSBhIEZpbGE8L3NwYW4+XHJcbiAgICAgICAgPC9MaW5rPlxyXG4gICAgICA8L2Rpdj5cclxuICAgICk7XHJcbiAgfVxyXG5cclxuICBjb25zdCBkYWRvcyA9IHJlcS5kYWRvc19kZWNsYXJhZG9zO1xyXG4gIGNvbnN0IGVzdGFiID0gcmVxLmVzdGFiZWxlY2ltZW50bztcclxuXHJcbiAgY29uc3QgaGFuZGxlVHJhbWl0YXIgPSBhc3luYyAoYWNhbzogYW55LCBtb3Rpdm8/OiBzdHJpbmcpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGF3YWl0IGFuYWxpc2FyTXV0YXRpb24ubXV0YXRlQXN5bmMoe1xyXG4gICAgICAgIGFjYW8sXHJcbiAgICAgICAgcGFyZWNlcl9vdV9tb3Rpdm86IG1vdGl2byB8fCBwYXJlY2VyVGV4dG8gfHwgdW5kZWZpbmVkLFxyXG4gICAgICB9KTtcclxuICAgICAgc2V0UGFyZWNlclRleHRvKFwiXCIpO1xyXG4gICAgICBzZXRNb2RhbEluZGVmZXJpckFiZXJ0YShmYWxzZSk7XHJcbiAgICAgIHNldE1vZGFsQWRlcXVhY2FvQWJlcnRhKGZhbHNlKTtcclxuICAgICAgcmVmZXRjaCgpO1xyXG4gICAgfSBjYXRjaCB7XHJcbiAgICAgIC8vIEVycm8gw6kgdHJhdGFkbyBwZWxvIFJlYWN0IFF1ZXJ5XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS02IG1heC13LTV4bCBteC1hdXRvIHBiLTEyXCI+XHJcbiAgICAgIHsvKiBCYXJyYSBkZSBOYXZlZ2HDp8OjbyBTdXBlcmlvciAqL31cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cclxuICAgICAgICA8TGlua1xyXG4gICAgICAgICAgdG89e1JPVVRFUy5MSUNFTkNJQU1FTlRPLkxJU1R9XHJcbiAgICAgICAgICBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNjAwIGRhcms6dGV4dC1zbGF0ZS0zMDAgaG92ZXI6dGV4dC10ZWFsLTYwMCBkYXJrOmhvdmVyOnRleHQtdGVhbC00MDAgdHJhbnNpdGlvbi1jb2xvcnNcIlxyXG4gICAgICAgID5cclxuICAgICAgICAgIDxBcnJvd0xlZnQgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+XHJcbiAgICAgICAgICA8c3Bhbj5Wb2x0YXIgcGFyYSBGaWxhIGRlIExpY2VuY2lhbWVudG88L3NwYW4+XHJcbiAgICAgICAgPC9MaW5rPlxyXG5cclxuICAgICAgICA8U3RhdHVzUmVxdWVyaW1lbnRvQmFkZ2Ugc3RhdHVzPXtyZXEuc3RhdHVzfSAvPlxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIHsvKiBCYW5uZXIgZGUgRmVlZGJhY2sgZGUgRXJybyAqL31cclxuICAgICAge2FuYWxpc2FyTXV0YXRpb24uaXNFcnJvciAmJiAoXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTQgYmctcm9zZS01MCBkYXJrOmJnLXJvc2UtOTUwLzQwIGJvcmRlciBib3JkZXItcm9zZS0yMDAgZGFyazpib3JkZXItcm9zZS04MDAgcm91bmRlZC0yeGwgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdGV4dC14cyB0ZXh0LXJvc2UtODAwIGRhcms6dGV4dC1yb3NlLTIwMFwiPlxyXG4gICAgICAgICAgPEFsZXJ0Q2lyY2xlIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1yb3NlLTYwMCBzaHJpbmstMFwiIC8+XHJcbiAgICAgICAgICA8c3Bhbj5cclxuICAgICAgICAgICAge2FuYWxpc2FyTXV0YXRpb24uZXJyb3IgaW5zdGFuY2VvZiBFcnJvclxyXG4gICAgICAgICAgICAgID8gYW5hbGlzYXJNdXRhdGlvbi5lcnJvci5tZXNzYWdlXHJcbiAgICAgICAgICAgICAgOiBcIkVycm8gYW8gdHJhbWl0YXIgbyByZXF1ZXJpbWVudG8gc2FuaXTDoXJpby5cIn1cclxuICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgKX1cclxuXHJcbiAgICAgIHsvKiBDYWJlw6dhbGhvIGRvIFByb2Nlc3NvICovfVxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIGRhcms6Ymctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLTJ4bCBwLTYgc2hhZG93LXhzIHNwYWNlLXktNFwiPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBzbTpmbGV4LXJvdyBzbTppdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC00IHBiLTQgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTEwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDBcIj5cclxuICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdGV4dC1bMTFweF0gZm9udC1ib2xkIHRleHQtdGVhbC02MDAgZGFyazp0ZXh0LXRlYWwtNDAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPlxyXG4gICAgICAgICAgICAgIDxzcGFuPlByb2Nlc3NvIGRlIExpY2VuY2lhbWVudG8gU2FuaXTDoXJpbzwvc3Bhbj5cclxuICAgICAgICAgICAgICA8c3Bhbj7igKI8L3NwYW4+XHJcbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiY2FwaXRhbGl6ZVwiPlxyXG4gICAgICAgICAgICAgICAge3JlcS50aXBvX3NvbGljaXRhY2FvID09PSBcImNvbmNlc3Nhb19pbmljaWFsXCJcclxuICAgICAgICAgICAgICAgICAgPyBcIkNvbmNlc3PDo28gSW5pY2lhbFwiXHJcbiAgICAgICAgICAgICAgICAgIDogXCJSZW5vdmHDp8OjbyBBbnVhbFwifVxyXG4gICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGUgbXQtMC41XCI+XHJcbiAgICAgICAgICAgICAgUHJvdG9jb2xvOiB7cmVxLm51bWVyb19wcm90b2NvbG99XHJcbiAgICAgICAgICAgIDwvaDE+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtcmlnaHRcIj5cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1zbGF0ZS00MDAgdXBwZXJjYXNlIGZvbnQtc2VtaWJvbGQgYmxvY2tcIj5cclxuICAgICAgICAgICAgICBEYXRhIGRlIFN1Ym1pc3PDo29cclxuICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0zMDBcIj5cclxuICAgICAgICAgICAgICB7bmV3IERhdGUocmVxLmRhdGFfc3VibWlzc2FvKS50b0xvY2FsZVN0cmluZyhcInB0LUJSXCIpfVxyXG4gICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgey8qIFBhcmVjZXIgRmlzY2FsIEF0dWFsIC8gTW90aXZvICovfVxyXG4gICAgICAgIHtyZXEucGFyZWNlcl9maXNjYWwgJiYgKFxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTMuNSBiZy1za3ktNTAvNzAgZGFyazpiZy1za3ktOTUwLzMwIGJvcmRlciBib3JkZXItc2t5LTIwMCBkYXJrOmJvcmRlci1za3ktODAwIHJvdW5kZWQteGwgdGV4dC14cyBzcGFjZS15LTFcIj5cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdXBwZXJjYXNlIGZvbnQtYm9sZCB0ZXh0LXNreS04MDAgZGFyazp0ZXh0LXNreS0zMDAgYmxvY2tcIj5cclxuICAgICAgICAgICAgICBQYXJlY2VyIFTDqWNuaWNvIGRvIEZpc2NhbDpcclxuICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTgwMCBkYXJrOnRleHQtc2xhdGUtMjAwIGxlYWRpbmctcmVsYXhlZFwiPlxyXG4gICAgICAgICAgICAgIHtyZXEucGFyZWNlcl9maXNjYWx9XHJcbiAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICl9XHJcblxyXG4gICAgICAgIHtyZXEubW90aXZvX2luZGVmZXJpbWVudG8gJiYgKFxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTMuNSBiZy1yb3NlLTUwLzcwIGRhcms6Ymctcm9zZS05NTAvMzAgYm9yZGVyIGJvcmRlci1yb3NlLTIwMCBkYXJrOmJvcmRlci1yb3NlLTgwMCByb3VuZGVkLXhsIHRleHQteHMgc3BhY2UteS0xXCI+XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHVwcGVyY2FzZSBmb250LWJvbGQgdGV4dC1yb3NlLTgwMCBkYXJrOnRleHQtcm9zZS0zMDAgYmxvY2tcIj5cclxuICAgICAgICAgICAgICBNb3Rpdm8gZG8gSW5kZWZlcmltZW50bzpcclxuICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXJvc2UtOTAwIGRhcms6dGV4dC1yb3NlLTIwMCBsZWFkaW5nLXJlbGF4ZWRcIj5cclxuICAgICAgICAgICAgICB7cmVxLm1vdGl2b19pbmRlZmVyaW1lbnRvfVxyXG4gICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICApfVxyXG5cclxuICAgICAgICB7LyogQmFycmEgZGUgQcOnw7VlcyBSw6FwaWRhcyBkZSBUcmFtaXRhw6fDo28gKi99XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBpdGVtcy1jZW50ZXIgZ2FwLTIgcHQtMiBib3JkZXItdCBib3JkZXItc2xhdGUtMTAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMFwiPlxyXG4gICAgICAgICAge3JlcS5zdGF0dXMgPT09IFwicGVuZGVudGVcIiAmJiAoXHJcbiAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICBkaXNhYmxlZD17YW5hbGlzYXJNdXRhdGlvbi5pc1BlbmRpbmd9XHJcbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlVHJhbWl0YXIoXCJpbmljaWFyX2FuYWxpc2VcIiwgXCJJbmljaWFkYSBjb25mZXLDqm5jaWEgZG9jdW1lbnRhbCBmb3JtYWwuXCIpfVxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTMuNSBweS0xLjUgdGV4dC14cyBmb250LWJvbGQgdGV4dC1za3ktNzAwIGRhcms6dGV4dC1za3ktMzAwIGJnLXNreS01MCBkYXJrOmJnLXNreS05NTAvNDAgYm9yZGVyIGJvcmRlci1za3ktMjAwIGRhcms6Ym9yZGVyLXNreS04MDAgcm91bmRlZC1sZyBob3ZlcjpiZy1za3ktMTAwLzYwIHNoYWRvdy0yeHMgaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjVcIlxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgPEZpbGVTZWFyY2ggY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPlxyXG4gICAgICAgICAgICAgIDxzcGFuPkluaWNpYXIgQW7DoWxpc2UgRG9jdW1lbnRhbDwvc3Bhbj5cclxuICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgIHsocmVxLnN0YXR1cyA9PT0gXCJwZW5kZW50ZVwiIHx8IHJlcS5zdGF0dXMgPT09IFwiZW1fYW5hbGlzZVwiKSAmJiAoXHJcbiAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICBkaXNhYmxlZD17YW5hbGlzYXJNdXRhdGlvbi5pc1BlbmRpbmd9XHJcbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlVHJhbWl0YXIoXCJlbmNhbWluaGFyX2luc3BlY2FvXCIsIFwiRG9jdW1lbnRhw6fDo28gcHJlbGltaW5hciBhcHJvdmFkYS4gRW5jYW1pbmhhZG8gcGFyYSB2aXN0b3JpYSBkZSBjYW1wby5cIil9XHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtMy41IHB5LTEuNSB0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LWluZGlnby03MDAgZGFyazp0ZXh0LWluZGlnby0zMDAgYmctaW5kaWdvLTUwIGRhcms6YmctaW5kaWdvLTk1MC80MCBib3JkZXIgYm9yZGVyLWluZGlnby0yMDAgZGFyazpib3JkZXItaW5kaWdvLTgwMCByb3VuZGVkLWxnIGhvdmVyOmJnLWluZGlnby0xMDAvNjAgc2hhZG93LTJ4cyBpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNVwiXHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICA8Q2xvY2sgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPlxyXG4gICAgICAgICAgICAgIDxzcGFuPkVuY2FtaW5oYXIgcGFyYSBWaXN0b3JpYTwvc3Bhbj5cclxuICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgIHtyZXEuc3RhdHVzICE9PSBcImRlZmVyaWRvXCIgJiYgcmVxLnN0YXR1cyAhPT0gXCJjYW5jZWxhZG9cIiAmJiAoXHJcbiAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRNb2RhbEFkZXF1YWNhb0FiZXJ0YSh0cnVlKX1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTMuNSBweS0xLjUgdGV4dC14cyBmb250LWJvbGQgdGV4dC1hbWJlci04MDAgZGFyazp0ZXh0LWFtYmVyLTIwMCBiZy1hbWJlci01MCBkYXJrOmJnLWFtYmVyLTk1MC80MCBib3JkZXIgYm9yZGVyLWFtYmVyLTIwMCBkYXJrOmJvcmRlci1hbWJlci04MDAgcm91bmRlZC1sZyBob3ZlcjpiZy1hbWJlci0xMDAvNjAgc2hhZG93LTJ4cyBpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNVwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPEFsZXJ0Q2lyY2xlIGNsYXNzTmFtZT1cInctMy41IGgtMy41XCIgLz5cclxuICAgICAgICAgICAgICAgIDxzcGFuPlNvbGljaXRhciBBZGVxdWHDp8O1ZXM8L3NwYW4+XHJcbiAgICAgICAgICAgICAgPC9idXR0b24+XHJcblxyXG4gICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0TW9kYWxFbWl0aXJBYmVydGEodHJ1ZSl9XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC00IHB5LTEuNSB0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXdoaXRlIGJnLXRlYWwtNjAwIGhvdmVyOmJnLXRlYWwtNzAwIHJvdW5kZWQtbGcgc2hhZG93LXhzIGlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHRyYW5zaXRpb24tY29sb3JzXCJcclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICA8QXdhcmQgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4+RGVmZXJpciAmIEVtaXRpciBBbHZhcsOhPC9zcGFuPlxyXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG5cclxuICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldE1vZGFsSW5kZWZlcmlyQWJlcnRhKHRydWUpfVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtMy41IHB5LTEuNSB0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXJvc2UtNzAwIGRhcms6dGV4dC1yb3NlLTMwMCBiZy1yb3NlLTUwIGRhcms6Ymctcm9zZS05NTAvNDAgYm9yZGVyIGJvcmRlci1yb3NlLTIwMCBkYXJrOmJvcmRlci1yb3NlLTgwMCByb3VuZGVkLWxnIGhvdmVyOmJnLXJvc2UtMTAwLzYwIHNoYWRvdy0yeHMgaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjVcIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIDxYQ2lyY2xlIGNsYXNzTmFtZT1cInctMy41IGgtMy41XCIgLz5cclxuICAgICAgICAgICAgICAgIDxzcGFuPkluZGVmZXJpciBQZWRpZG88L3NwYW4+XHJcbiAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgIDwvPlxyXG4gICAgICAgICAgKX1cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICB7LyogSWRlbnRpZmljYcOnw6NvIGRvIEVzdGFiZWxlY2ltZW50byBWaW5jdWxhZG8gKi99XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGFyazpiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtODAwIHJvdW5kZWQtMnhsIHAtNiBzaGFkb3cteHMgc3BhY2UteS00XCI+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gcGItMiBib3JkZXItYiBib3JkZXItc2xhdGUtMTAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMFwiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICA8QnVpbGRpbmcyIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC10ZWFsLTYwMFwiIC8+XHJcbiAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlXCI+XHJcbiAgICAgICAgICAgICAgRXN0YWJlbGVjaW1lbnRvIFJlcXVlcmVudGVcclxuICAgICAgICAgICAgPC9oMj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAge2VzdGFiICYmIChcclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgIDxSaXNjb0JhZGdlIHJpc2NvPXtlc3RhYi5uaXZlbF9yaXNjb30gLz5cclxuICAgICAgICAgICAgICA8TGlua1xyXG4gICAgICAgICAgICAgICAgdG89e1JPVVRFUy5FU1RBQkVMRUNJTUVOVE9TLkRFVEFMSEUoZXN0YWIuaWQpfVxyXG4gICAgICAgICAgICAgICAgdGFyZ2V0PVwiX2JsYW5rXCJcclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXRlYWwtNjAwIGRhcms6dGV4dC10ZWFsLTQwMCBob3Zlcjp1bmRlcmxpbmUgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTFcIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIDxzcGFuPlZlciBQcm9udHXDoXJpbzwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDxFeHRlcm5hbExpbmsgY2xhc3NOYW1lPVwidy0zIGgtM1wiIC8+XHJcbiAgICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICl9XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBzbTpncmlkLWNvbHMtMyBnYXAtNCB0ZXh0LXhzXCI+XHJcbiAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMCB0ZXh0LVsxMHB4XSB1cHBlcmNhc2UgZm9udC1zZW1pYm9sZCBibG9ja1wiPlJhesOjbyBTb2NpYWw8L3NwYW4+XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGVcIj5cclxuICAgICAgICAgICAgICB7ZGFkb3M/LnJhemFvX3NvY2lhbCB8fCBlc3RhYj8ucmF6YW9fc29jaWFsIHx8IFwiTsOjbyBpbmZvcm1hZGFcIn1cclxuICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDAgdGV4dC1bMTBweF0gdXBwZXJjYXNlIGZvbnQtc2VtaWJvbGQgYmxvY2tcIj5Ob21lIEZhbnRhc2lhPC9zcGFuPlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1lZGl1bSB0ZXh0LXNsYXRlLTgwMCBkYXJrOnRleHQtc2xhdGUtMjAwXCI+XHJcbiAgICAgICAgICAgICAge2RhZG9zPy5ub21lX2ZhbnRhc2lhIHx8IGVzdGFiPy5ub21lX2ZhbnRhc2lhIHx8IFwiTsOjbyBpbmZvcm1hZG9cIn1cclxuICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDAgdGV4dC1bMTBweF0gdXBwZXJjYXNlIGZvbnQtc2VtaWJvbGQgYmxvY2tcIj5DTlBKIC8gQ1BGPC9zcGFuPlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1vbm8gZm9udC1tZWRpdW0gdGV4dC1zbGF0ZS04MDAgZGFyazp0ZXh0LXNsYXRlLTIwMFwiPlxyXG4gICAgICAgICAgICAgIHtkYWRvcz8uY3BmX2NucGogfHwgZXN0YWI/LmNucGpfY3BmIHx8IFwiLS0tXCJ9XHJcbiAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS02MDAgZGFyazp0ZXh0LXNsYXRlLTMwMCBwdC0yIGJvcmRlci10IGJvcmRlci1zbGF0ZS0xMDAgZGFyazpib3JkZXItc2xhdGUtODAwXCI+XHJcbiAgICAgICAgICA8c3Ryb25nPkVuZGVyZcOnbyBEZWNsYXJhZG86PC9zdHJvbmc+IHtkYWRvcz8ubG9ncmFkb3VybyB8fCBlc3RhYj8ubG9ncmFkb3VybyB8fCBcIkxvZ3JhZG91cm9cIn0se1wiIFwifVxyXG4gICAgICAgICAge2RhZG9zPy5udW1lcm8gfHwgZXN0YWI/Lm51bWVybyB8fCBcIlMvTlwifXtcIiBcIn1cclxuICAgICAgICAgIHtkYWRvcz8uY29tcGxlbWVudG8gJiYgYCgke2RhZG9zLmNvbXBsZW1lbnRvfSlgfSAte1wiIFwifVxyXG4gICAgICAgICAge2RhZG9zPy5iYWlycm8gfHwgZXN0YWI/LmJhaXJybyB8fCBcIkJhaXJyb1wifSDigKIgQ0VQOiB7ZGFkb3M/LmNlcCB8fCBlc3RhYj8uY2VwIHx8IFwiLS0tXCJ9XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgey8qIERhZG9zIERlY2xhcmFkb3MgbmEgUGV0acOnw6NvIEVsZXRyw7RuaWNhICovfVxyXG4gICAgICB7ZGFkb3MgJiYgKFxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGFyazpiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtODAwIHJvdW5kZWQtMnhsIHAtNiBzaGFkb3cteHMgc3BhY2UteS00XCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHBiLTIgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTEwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDBcIj5cclxuICAgICAgICAgICAgPEZpbGVUZXh0IGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC10ZWFsLTYwMFwiIC8+XHJcbiAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlXCI+XHJcbiAgICAgICAgICAgICAgSW5mb3JtYcOnw7VlcyBTYW5pdMOhcmlhcyBEZWNsYXJhZGFzXHJcbiAgICAgICAgICAgIDwvaDI+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgc206Z3JpZC1jb2xzLTIgbWQ6Z3JpZC1jb2xzLTMgZ2FwLTQgdGV4dC14c1wiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMyBiZy1zbGF0ZS01MCBkYXJrOmJnLXNsYXRlLTgwMC81MCByb3VuZGVkLXhsIHNwYWNlLXktMVwiPlxyXG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNDAwIHRleHQtWzEwcHhdIHVwcGVyY2FzZSBmb250LXNlbWlib2xkIGJsb2NrXCI+XHJcbiAgICAgICAgICAgICAgICBBdGl2aWRhZGUgUHJpbmNpcGFsIChDTkFFKVxyXG4gICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlXCI+XHJcbiAgICAgICAgICAgICAgICB7ZGFkb3MuY25hZV9wcmluY2lwYWxfc2VsZWNpb25hZG8gfHwgZGFkb3MuY25hZV9wcmluY2lwYWxfY29kaWdvX21hbnVhbCB8fCBcIk7Do28gZXNwZWNpZmljYWRvXCJ9XHJcbiAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgIHtkYWRvcy5jbmFlX3ByaW5jaXBhbF9kZXNjcmljYW8gJiYgKFxyXG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1zbGF0ZS02MDAgZGFyazp0ZXh0LXNsYXRlLTMwMFwiPlxyXG4gICAgICAgICAgICAgICAgICB7ZGFkb3MuY25hZV9wcmluY2lwYWxfZGVzY3JpY2FvfVxyXG4gICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTMgYmctc2xhdGUtNTAgZGFyazpiZy1zbGF0ZS04MDAvNTAgcm91bmRlZC14bCBzcGFjZS15LTFcIj5cclxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMCB0ZXh0LVsxMHB4XSB1cHBlcmNhc2UgZm9udC1zZW1pYm9sZCBibG9ja1wiPlxyXG4gICAgICAgICAgICAgICAgQWJhc3RlY2ltZW50byBkZSDDgWd1YVxyXG4gICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJmb250LW1lZGl1bSB0ZXh0LXNsYXRlLTgwMCBkYXJrOnRleHQtc2xhdGUtMjAwXCI+XHJcbiAgICAgICAgICAgICAgICB7ZGFkb3MuZm9udGVfYWJhc3RlY2ltZW50b19hZ3VhIHx8IFwiUmVkZSBQw7pibGljYSAvIENvbmNlc3Npb27DoXJpYVwifVxyXG4gICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LXNsYXRlLTUwMFwiPlxyXG4gICAgICAgICAgICAgICAgUmVzZXJ2YXTDs3Jpbzoge2RhZG9zLnBvc3N1aV9jYWl4YV9hZ3VhX3Byb3ByaWEgPT09IFwic2ltXCIgPyBgU2ltICgke2RhZG9zLmNhcGFjaWRhZGVfY2FpeGFfYWd1YV9saXRyb3MgfHwgMH0gTClgIDogXCJOw6NvIHBvc3N1aVwifVxyXG4gICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMyBiZy1zbGF0ZS01MCBkYXJrOmJnLXNsYXRlLTgwMC81MCByb3VuZGVkLXhsIHNwYWNlLXktMVwiPlxyXG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNDAwIHRleHQtWzEwcHhdIHVwcGVyY2FzZSBmb250LXNlbWlib2xkIGJsb2NrXCI+XHJcbiAgICAgICAgICAgICAgICBSZXNwb25zw6F2ZWwgVMOpY25pY28gRGVjbGFyYWRvXHJcbiAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXNsYXRlLTgwMCBkYXJrOnRleHQtc2xhdGUtMjAwXCI+XHJcbiAgICAgICAgICAgICAgICB7ZGFkb3MucnRfbm9tZSB8fCBcIk7Do28gaW5mb3JtYWRvIG91IG7Do28gZXhpZ2lkb1wifVxyXG4gICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICB7ZGFkb3MucnRfY29uc2VsaG9fY2xhc3NlICYmIChcclxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtc2xhdGUtNTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIHtkYWRvcy5ydF9jb25zZWxob19jbGFzc2V9OiB7ZGFkb3MucnRfbnVtZXJvX2NvbnNlbGhvfS97ZGFkb3MucnRfY29uc2VsaG9fdWZ9XHJcbiAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICB7LyogRG9jdW1lbnRvcyBBbmV4b3MgKi99XHJcbiAgICAgICAgICB7ZGFkb3MubGlua19kcml2ZV9kb2N1bWVudG9zICYmIChcclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTMuNSBiZy10ZWFsLTUwLzcwIGRhcms6YmctdGVhbC05NTAvMzAgYm9yZGVyIGJvcmRlci10ZWFsLTIwMCBkYXJrOmJvcmRlci10ZWFsLTgwMCByb3VuZGVkLXhsIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC14c1wiPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtdGVhbC05MDAgZGFyazp0ZXh0LXRlYWwtMjAwIGJsb2NrXCI+XHJcbiAgICAgICAgICAgICAgICAgIFBhc3RhIERpZ2l0YWwgZGUgRG9jdW1lbnRvcyBDb21wcm9iYXTDs3Jpb3NcclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtdGVhbC03MDAgZGFyazp0ZXh0LXRlYWwtMzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIEFjZXNzZSBvcyBsYXVkb3MsIGFsdmFyw6EgZG8gY29ycG8gZGUgYm9tYmVpcm9zIGUgZG9jdW1lbnRvcyBhbmV4YWRvcyBwZWxvIHNvbGljaXRhbnRlLlxyXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxhXHJcbiAgICAgICAgICAgICAgICBocmVmPXtkYWRvcy5saW5rX2RyaXZlX2RvY3VtZW50b3N9XHJcbiAgICAgICAgICAgICAgICB0YXJnZXQ9XCJfYmxhbmtcIlxyXG4gICAgICAgICAgICAgICAgcmVsPVwibm9yZWZlcnJlclwiXHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC0zIHB5LTEuNSB0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXdoaXRlIGJnLXRlYWwtNjAwIGhvdmVyOmJnLXRlYWwtNzAwIHJvdW5kZWQtbGcgaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgc2hhZG93LTJ4c1wiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4+QWJyaXIgUGFzdGEgZGUgRG9jdW1lbnRvczwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDxFeHRlcm5hbExpbmsgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPlxyXG4gICAgICAgICAgICAgIDwvYT5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICApfVxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICApfVxyXG5cclxuICAgICAgey8qIE1vZGFsIHBhcmEgU29saWNpdGFyIEFkZXF1YcOnw6NvICovfVxyXG4gICAgICB7bW9kYWxBZGVxdWFjYW9BYmVydGEgJiYgKFxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZml4ZWQgaW5zZXQtMCB6LTUwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHAtNCBiZy1ibGFjay81MCBiYWNrZHJvcC1ibHVyLXhzXCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIGRhcms6Ymctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLTJ4bCB3LWZ1bGwgbWF4LXctbWQgcC02IHNoYWRvdy0yeGwgc3BhY2UteS00XCI+XHJcbiAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGVcIj5cclxuICAgICAgICAgICAgICBTb2xpY2l0YXIgQWRlcXVhw6fDtWVzIC8gTm90aWZpY2FyIEV4aWfDqm5jaWFzXHJcbiAgICAgICAgICAgIDwvaDM+XHJcbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS01MDBcIj5cclxuICAgICAgICAgICAgICBEZXNjcmV2YSBhcyBwZW5kw6puY2lhcyBkb2N1bWVudGFpcyBvdSBjb3JyZcOnw7VlcyBxdWUgbyByZXF1ZXJlbnRlIGRldmUgc2FuYXI6XHJcbiAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgPHRleHRhcmVhXHJcbiAgICAgICAgICAgICAgcm93cz17NH1cclxuICAgICAgICAgICAgICB2YWx1ZT17cGFyZWNlclRleHRvfVxyXG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0UGFyZWNlclRleHRvKGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkV4OiBBbmV4YXIgY2VydGlmaWNhZG8gYXR1YWxpemFkbyBkZSBoaWdpZW5pemHDp8OjbyBkbyByZXNlcnZhdMOzcmlvIGRlIMOhZ3VhLi4uXCJcclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcC0yLjUgdGV4dC14cyBiZy1zbGF0ZS01MCBkYXJrOmJnLXNsYXRlLTgwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC1sZyB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGUgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLWFtYmVyLTUwMFwiXHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWVuZCBnYXAtMiBwdC0yXCI+XHJcbiAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRNb2RhbEFkZXF1YWNhb0FiZXJ0YShmYWxzZSl9XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC0zIHB5LTEuNSB0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtc2xhdGUtNjAwIGhvdmVyOmJnLXNsYXRlLTEwMCByb3VuZGVkLWxnXCJcclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICBDYW5jZWxhclxyXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgZGlzYWJsZWQ9eyFwYXJlY2VyVGV4dG8udHJpbSgpIHx8IGFuYWxpc2FyTXV0YXRpb24uaXNQZW5kaW5nfVxyXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlVHJhbWl0YXIoXCJzb2xpY2l0YXJfYWRlcXVhY2FvXCIpfVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNCBweS0xLjUgdGV4dC14cyBmb250LWJvbGQgdGV4dC13aGl0ZSBiZy1hbWJlci02MDAgaG92ZXI6YmctYW1iZXItNzAwIHJvdW5kZWQtbGcgZGlzYWJsZWQ6b3BhY2l0eS02MFwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgQ29uZmlybWFyIE5vdGlmaWNhw6fDo29cclxuICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgKX1cclxuXHJcbiAgICAgIHsvKiBNb2RhbCBwYXJhIEluZGVmZXJpciBQZWRpZG8gKi99XHJcbiAgICAgIHttb2RhbEluZGVmZXJpckFiZXJ0YSAmJiAoXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIHotNTAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcC00IGJnLWJsYWNrLzUwIGJhY2tkcm9wLWJsdXIteHNcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGFyazpiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtODAwIHJvdW5kZWQtMnhsIHctZnVsbCBtYXgtdy1tZCBwLTYgc2hhZG93LTJ4bCBzcGFjZS15LTRcIj5cclxuICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1ib2xkIHRleHQtcm9zZS03MDAgZGFyazp0ZXh0LXJvc2UtNDAwXCI+XHJcbiAgICAgICAgICAgICAgSW5kZWZlcmlyIFJlcXVlcmltZW50byBkZSBMaWNlbmNpYW1lbnRvXHJcbiAgICAgICAgICAgIDwvaDM+XHJcbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS01MDBcIj5cclxuICAgICAgICAgICAgICBKdXN0aWZpcXVlIGZvcm1hbG1lbnRlIG8gbW90aXZvIHTDqWNuaWNvIG91IGxlZ2FsIGRvIGluZGVmZXJpbWVudG8gZG8gYWx2YXLDoTpcclxuICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICA8dGV4dGFyZWFcclxuICAgICAgICAgICAgICByb3dzPXs0fVxyXG4gICAgICAgICAgICAgIHZhbHVlPXtwYXJlY2VyVGV4dG99XHJcbiAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRQYXJlY2VyVGV4dG8oZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRXg6IEluY29tcGF0aWJpbGlkYWRlIGRlIGF0aXZpZGFkZSBubyBlbmRlcmXDp28gb3UgcmVwcm92YcOnw6NvIGVtIHZpc3RvcmlhIGZpc2NhbCBzZW0gYWRlcXVhw6fDo28gbm8gcHJhem8gbGVnYWwuLi5cIlxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBwLTIuNSB0ZXh0LXhzIGJnLXNsYXRlLTUwIGRhcms6Ymctc2xhdGUtODAwIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCByb3VuZGVkLWxnIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZSBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctcm9zZS01MDBcIlxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1lbmQgZ2FwLTIgcHQtMlwiPlxyXG4gICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0TW9kYWxJbmRlZmVyaXJBYmVydGEoZmFsc2UpfVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtMyBweS0xLjUgdGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LXNsYXRlLTYwMCBob3ZlcjpiZy1zbGF0ZS0xMDAgcm91bmRlZC1sZ1wiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgQ2FuY2VsYXJcclxuICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgIGRpc2FibGVkPXshcGFyZWNlclRleHRvLnRyaW0oKSB8fCBhbmFsaXNhck11dGF0aW9uLmlzUGVuZGluZ31cclxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZVRyYW1pdGFyKFwiaW5kZWZlcmlyXCIpfVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNCBweS0xLjUgdGV4dC14cyBmb250LWJvbGQgdGV4dC13aGl0ZSBiZy1yb3NlLTYwMCBob3ZlcjpiZy1yb3NlLTcwMCByb3VuZGVkLWxnIGRpc2FibGVkOm9wYWNpdHktNjBcIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIENvbmZpcm1hciBJbmRlZmVyaW1lbnRvXHJcbiAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICl9XHJcblxyXG4gICAgICB7LyogTW9kYWwgZGUgRW1pc3PDo28gT2ZpY2lhbCBkZSBBbHZhcsOhICovfVxyXG4gICAgICB7bW9kYWxFbWl0aXJBYmVydGEgJiYgKFxyXG4gICAgICAgIDxNb2RhbEVtaXRpckFsdmFyYVxyXG4gICAgICAgICAgaXNPcGVuPXttb2RhbEVtaXRpckFiZXJ0YX1cclxuICAgICAgICAgIG9uQ2xvc2U9eygpID0+IHNldE1vZGFsRW1pdGlyQWJlcnRhKGZhbHNlKX1cclxuICAgICAgICAgIGVzdGFiZWxlY2ltZW50b0lkPXtyZXEuZXN0YWJlbGVjaW1lbnRvX2lkfVxyXG4gICAgICAgICAgcmVxdWVyaW1lbnRvSWQ9e3JlcS5pZH1cclxuICAgICAgICAgIHJhemFvU29jaWFsPXtkYWRvcz8ucmF6YW9fc29jaWFsIHx8IGVzdGFiPy5yYXphb19zb2NpYWx9XHJcbiAgICAgICAgICBjbnBqQ3BmPXtkYWRvcz8uY3BmX2NucGogfHwgZXN0YWI/LmNucGpfY3BmfVxyXG4gICAgICAgICAgb25TdWNlc3NvPXsoYWx2YXJhKSA9PiB7XHJcbiAgICAgICAgICAgIG5hdmlnYXRlKFJPVVRFUy5MSUNFTkNJQU1FTlRPLkFMVkFSQV9WSUVXKGFsdmFyYS5pZCkpO1xyXG4gICAgICAgICAgfX1cclxuICAgICAgICAvPlxyXG4gICAgICApfVxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IFJlcXVlcmltZW50b0RldGFpbFBhZ2U7XHJcbiJdfQ==