import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/common/GlobalLoadingIndicator.tsx");const React = __vite__cjsImport0_react; const useEffect = __vite__cjsImport0_react["useEffect"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];/**
* Componente Visual de Estado de Carregamento Global (Global Loading Indicator)
*
* Integra-se diretamente ao `useGlobalLoading` e aos interceptors do Axios,
* provendo feedback contínuo sem bloquear a interface de usuário (não intrusivo):
*
* 1. Barra superior ultrafina (Top Progress Bar) com gradiente institucional e animação contínua.
* 2. Indicador flutuante no canto inferior direito com contador de requisições paralelas e debounce
*    antiflicker para respostas instantâneas.
* 3. Totalmente acessível com suporte a leitores de tela (role="status", aria-live="polite").
*/
import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=0fd2848a";
import { Loader2 } from "/node_modules/.vite/deps/lucide-react.js?v=0fd2848a";
import { useGlobalLoading } from "/src/hooks/useGlobalLoading.ts";
var _jsxFileName = "E:/Projetos VSCODE/visa_braunas/src/components/common/GlobalLoadingIndicator.tsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=0fd2848a";
var _s = $RefreshSig$();
export const GlobalLoadingIndicator = ({ debounceBadgeMs = 120, showBadge = true }) => {
	_s();
	const { isLoading, activeRequestsCount } = useGlobalLoading();
	const [showDebouncedBadge, setShowDebouncedBadge] = useState(false);
	const [isFinishing, setIsFinishing] = useState(false);
	// Debounce do badge flutuante para evitar micro-flickering
	useEffect(() => {
		let timer = null;
		if (isLoading) {
			setIsFinishing(false);
			timer = setTimeout(() => {
				setShowDebouncedBadge(true);
			}, debounceBadgeMs);
		} else {
			// Quando finaliza, mantém uma breve transição suave de conclusão
			setShowDebouncedBadge(false);
			setIsFinishing(true);
			const finishTimer = setTimeout(() => {
				setIsFinishing(false);
			}, 350);
			return () => clearTimeout(finishTimer);
		}
		return () => {
			if (timer) clearTimeout(timer);
		};
	}, [isLoading, debounceBadgeMs]);
	// Se não estiver carregando e não estiver em animação de término, não renderiza nada
	if (!isLoading && !isFinishing) {
		return null;
	}
	return /* @__PURE__ */ _jsxDEV("div", {
		role: "status",
		"aria-live": "polite",
		"aria-busy": isLoading,
		className: "pointer-events-none fixed inset-x-0 top-0 z-[9999]",
		children: [
			/* @__PURE__ */ _jsxDEV("span", {
				className: "sr-only",
				children: isLoading ? `Carregando dados do servidor (${activeRequestsCount} requisição${activeRequestsCount > 1 ? "ões" : ""} em andamento)` : "Carregamento concluído"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 74,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "relative h-1 w-full overflow-hidden bg-transparent",
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: `h-full transition-all duration-300 ease-out ${isFinishing ? "w-full bg-emerald-500 opacity-0 transition-opacity duration-300" : "w-full bg-gradient-to-r from-teal-500 via-emerald-400 to-cyan-500 shadow-[0_0_8px_rgba(20,184,166,0.8)]"}`,
					style: { animation: isFinishing ? "none" : "vigiminas-loading-pulse 1.4s ease-in-out infinite" }
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 84,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 83,
				columnNumber: 7
			}, this),
			showBadge && (showDebouncedBadge || isLoading && activeRequestsCount > 1) && /* @__PURE__ */ _jsxDEV("aside", {
				"aria-hidden": !isLoading,
				className: "pointer-events-auto fixed bottom-5 right-5 z-[9999] flex items-center gap-2.5 rounded-full border border-slate-700/80 bg-slate-900/90 px-3.5 py-1.5 text-xs text-slate-100 shadow-xl backdrop-blur-md transition-all duration-200 animate-in fade-in slide-in-from-bottom-2 dark:border-slate-600 dark:bg-slate-800/95",
				children: [
					/* @__PURE__ */ _jsxDEV(Loader2, { className: "h-3.5 w-3.5 animate-spin text-teal-400" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 102,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("span", {
						className: "font-medium tracking-tight",
						children: "Sincronizando dados..."
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 103,
						columnNumber: 11
					}, this),
					activeRequestsCount > 1 && /* @__PURE__ */ _jsxDEV("span", {
						title: `${activeRequestsCount} requisições ativas simultâneas`,
						className: "inline-flex h-4 min-w-[1rem] items-center justify-center rounded-full bg-teal-500/20 px-1 text-[10px] font-semibold text-teal-300 border border-teal-500/30",
						children: activeRequestsCount
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 105,
						columnNumber: 13
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 98,
				columnNumber: 9
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 68,
		columnNumber: 5
	}, this);
};
_s(GlobalLoadingIndicator, "lt85C3CKRU7dn8e+1xSax9DDvz0=", false, function() {
	return [useGlobalLoading];
});
_c = GlobalLoadingIndicator;
export default GlobalLoadingIndicator;
var _c;
$RefreshReg$(_c, "GlobalLoadingIndicator");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/common/GlobalLoadingIndicator.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("E:/Projetos VSCODE/visa_braunas/src/components/common/GlobalLoadingIndicator.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("E:/Projetos VSCODE/visa_braunas/src/components/common/GlobalLoadingIndicator.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "E:/Projetos VSCODE/visa_braunas/src/components/common/GlobalLoadingIndicator.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7QUFZQSxPQUFPLFNBQVMsV0FBVyxnQkFBZ0I7QUFDM0MsU0FBUyxlQUFlO0FBQ3hCLFNBQVMsd0JBQXdCOzs7O0FBZWpDLE9BQU8sTUFBTSwwQkFBaUUsRUFDNUUsa0JBQWtCLEtBQ2xCLFlBQVksV0FDUjs7Q0FDSixNQUFNLEVBQUUsV0FBVyx3QkFBd0IsaUJBQWlCO0NBQzVELE1BQU0sQ0FBQyxvQkFBb0IseUJBQXlCLFNBQWtCLEtBQUs7Q0FDM0UsTUFBTSxDQUFDLGFBQWEsa0JBQWtCLFNBQWtCLEtBQUs7O0NBRzdELGdCQUFnQjtFQUNkLElBQUksUUFBK0I7RUFFbkMsSUFBSSxXQUFXO0dBQ2IsZUFBZSxLQUFLO0dBQ3BCLFFBQVEsaUJBQWlCO0lBQ3ZCLHNCQUFzQixJQUFJO0dBQzVCLEdBQUcsZUFBZTtFQUNwQixPQUFPOztHQUVMLHNCQUFzQixLQUFLO0dBQzNCLGVBQWUsSUFBSTtHQUNuQixNQUFNLGNBQWMsaUJBQWlCO0lBQ25DLGVBQWUsS0FBSztHQUN0QixHQUFHLEdBQUc7R0FDTixhQUFhLGFBQWEsV0FBVztFQUN2QztFQUVBLGFBQWE7R0FDWCxJQUFJLE9BQU8sYUFBYSxLQUFLO0VBQy9CO0NBQ0YsR0FBRyxDQUFDLFdBQVcsZUFBZSxDQUFDOztDQUcvQixJQUFJLENBQUMsYUFBYSxDQUFDLGFBQWE7RUFDOUIsT0FBTztDQUNUO0NBRUEsT0FDRSx3QkFBQyxPQUFEO0VBQ0UsTUFBSztFQUNMLGFBQVU7RUFDVixhQUFXO0VBQ1gsV0FBVTtZQUpaO0dBTUUsd0JBQUMsUUFBRDtJQUFNLFdBQVU7Y0FDYixZQUNHLGlDQUFpQyxvQkFBb0IsYUFDbkQsc0JBQXNCLElBQUksUUFBUSxHQUNuQyxrQkFDRDtHQUNBOzs7OztHQUdOLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQ2Isd0JBQUMsT0FBRDtLQUNFLFdBQVcsK0NBQ1QsY0FDSSxvRUFDQTtLQUVOLE9BQU8sRUFDTCxXQUFXLGNBQWMsU0FBUyxvREFDcEM7SUFDRDs7Ozs7R0FDRTs7Ozs7R0FHSixjQUFjLHNCQUF1QixhQUFhLHNCQUFzQixNQUN2RSx3QkFBQyxTQUFEO0lBQ0UsZUFBYSxDQUFDO0lBQ2QsV0FBVTtjQUZaO0tBSUUsd0JBQUMsU0FBRCxFQUFTLFdBQVUseUNBQTBDOzs7OztLQUM3RCx3QkFBQyxRQUFEO01BQU0sV0FBVTtnQkFBNkI7S0FBNEI7Ozs7O0tBQ3hFLHNCQUFzQixLQUNyQix3QkFBQyxRQUFEO01BQ0UsT0FBTyxHQUFHLG9CQUFvQjtNQUM5QixXQUFVO2dCQUVUO0tBQ0c7Ozs7O0lBRUg7Ozs7OztFQUVOOzs7Ozs7QUFFVDs7Ozs7QUFFQSxlQUFlIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkdsb2JhbExvYWRpbmdJbmRpY2F0b3IudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbIi8qKlxyXG4gKiBDb21wb25lbnRlIFZpc3VhbCBkZSBFc3RhZG8gZGUgQ2FycmVnYW1lbnRvIEdsb2JhbCAoR2xvYmFsIExvYWRpbmcgSW5kaWNhdG9yKVxyXG4gKlxyXG4gKiBJbnRlZ3JhLXNlIGRpcmV0YW1lbnRlIGFvIGB1c2VHbG9iYWxMb2FkaW5nYCBlIGFvcyBpbnRlcmNlcHRvcnMgZG8gQXhpb3MsXHJcbiAqIHByb3ZlbmRvIGZlZWRiYWNrIGNvbnTDrW51byBzZW0gYmxvcXVlYXIgYSBpbnRlcmZhY2UgZGUgdXN1w6FyaW8gKG7Do28gaW50cnVzaXZvKTpcclxuICpcclxuICogMS4gQmFycmEgc3VwZXJpb3IgdWx0cmFmaW5hIChUb3AgUHJvZ3Jlc3MgQmFyKSBjb20gZ3JhZGllbnRlIGluc3RpdHVjaW9uYWwgZSBhbmltYcOnw6NvIGNvbnTDrW51YS5cclxuICogMi4gSW5kaWNhZG9yIGZsdXR1YW50ZSBubyBjYW50byBpbmZlcmlvciBkaXJlaXRvIGNvbSBjb250YWRvciBkZSByZXF1aXNpw6fDtWVzIHBhcmFsZWxhcyBlIGRlYm91bmNlXHJcbiAqICAgIGFudGlmbGlja2VyIHBhcmEgcmVzcG9zdGFzIGluc3RhbnTDom5lYXMuXHJcbiAqIDMuIFRvdGFsbWVudGUgYWNlc3PDrXZlbCBjb20gc3Vwb3J0ZSBhIGxlaXRvcmVzIGRlIHRlbGEgKHJvbGU9XCJzdGF0dXNcIiwgYXJpYS1saXZlPVwicG9saXRlXCIpLlxyXG4gKi9cclxuXHJcbmltcG9ydCBSZWFjdCwgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7IExvYWRlcjIgfSBmcm9tIFwibHVjaWRlLXJlYWN0XCI7XHJcbmltcG9ydCB7IHVzZUdsb2JhbExvYWRpbmcgfSBmcm9tIFwiLi4vLi4vaG9va3MvdXNlR2xvYmFsTG9hZGluZ1wiO1xyXG5cclxuaW50ZXJmYWNlIEdsb2JhbExvYWRpbmdJbmRpY2F0b3JQcm9wcyB7XHJcbiAgLyoqXHJcbiAgICogVGVtcG8gZW0gbWlsaXNzZWd1bmRvcyBhbnRlcyBkZSBleGliaXIgbyBiYWRnZSBmbHV0dWFudGUsXHJcbiAgICogcHJldmVuaW5kbyBwaXNjYWRhcyB2aXN1YWlzIGVtIHJlcXVpc2nDp8O1ZXMgZGUgY2FjaGUgb3UgdWx0cmEtcsOhcGlkYXMuXHJcbiAgICogUGFkcsOjbzogMTIwbXNcclxuICAgKi9cclxuICBkZWJvdW5jZUJhZGdlTXM/OiBudW1iZXI7XHJcbiAgLyoqXHJcbiAgICogUGVybWl0ZSBkZXNhdGl2YXIgbyBiYWRnZSBmbHV0dWFudGUgbWFudGVuZG8gYXBlbmFzIGEgYmFycmEgZGUgcHJvZ3Jlc3NvIGRvIHRvcG9cclxuICAgKi9cclxuICBzaG93QmFkZ2U/OiBib29sZWFuO1xyXG59XHJcblxyXG5leHBvcnQgY29uc3QgR2xvYmFsTG9hZGluZ0luZGljYXRvcjogUmVhY3QuRkM8R2xvYmFsTG9hZGluZ0luZGljYXRvclByb3BzPiA9ICh7XHJcbiAgZGVib3VuY2VCYWRnZU1zID0gMTIwLFxyXG4gIHNob3dCYWRnZSA9IHRydWUsXHJcbn0pID0+IHtcclxuICBjb25zdCB7IGlzTG9hZGluZywgYWN0aXZlUmVxdWVzdHNDb3VudCB9ID0gdXNlR2xvYmFsTG9hZGluZygpO1xyXG4gIGNvbnN0IFtzaG93RGVib3VuY2VkQmFkZ2UsIHNldFNob3dEZWJvdW5jZWRCYWRnZV0gPSB1c2VTdGF0ZTxib29sZWFuPihmYWxzZSk7XHJcbiAgY29uc3QgW2lzRmluaXNoaW5nLCBzZXRJc0ZpbmlzaGluZ10gPSB1c2VTdGF0ZTxib29sZWFuPihmYWxzZSk7XHJcblxyXG4gIC8vIERlYm91bmNlIGRvIGJhZGdlIGZsdXR1YW50ZSBwYXJhIGV2aXRhciBtaWNyby1mbGlja2VyaW5nXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGxldCB0aW1lcjogTm9kZUpTLlRpbWVvdXQgfCBudWxsID0gbnVsbDtcclxuXHJcbiAgICBpZiAoaXNMb2FkaW5nKSB7XHJcbiAgICAgIHNldElzRmluaXNoaW5nKGZhbHNlKTtcclxuICAgICAgdGltZXIgPSBzZXRUaW1lb3V0KCgpID0+IHtcclxuICAgICAgICBzZXRTaG93RGVib3VuY2VkQmFkZ2UodHJ1ZSk7XHJcbiAgICAgIH0sIGRlYm91bmNlQmFkZ2VNcyk7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICAvLyBRdWFuZG8gZmluYWxpemEsIG1hbnTDqW0gdW1hIGJyZXZlIHRyYW5zacOnw6NvIHN1YXZlIGRlIGNvbmNsdXPDo29cclxuICAgICAgc2V0U2hvd0RlYm91bmNlZEJhZGdlKGZhbHNlKTtcclxuICAgICAgc2V0SXNGaW5pc2hpbmcodHJ1ZSk7XHJcbiAgICAgIGNvbnN0IGZpbmlzaFRpbWVyID0gc2V0VGltZW91dCgoKSA9PiB7XHJcbiAgICAgICAgc2V0SXNGaW5pc2hpbmcoZmFsc2UpO1xyXG4gICAgICB9LCAzNTApO1xyXG4gICAgICByZXR1cm4gKCkgPT4gY2xlYXJUaW1lb3V0KGZpbmlzaFRpbWVyKTtcclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4gKCkgPT4ge1xyXG4gICAgICBpZiAodGltZXIpIGNsZWFyVGltZW91dCh0aW1lcik7XHJcbiAgICB9O1xyXG4gIH0sIFtpc0xvYWRpbmcsIGRlYm91bmNlQmFkZ2VNc10pO1xyXG5cclxuICAvLyBTZSBuw6NvIGVzdGl2ZXIgY2FycmVnYW5kbyBlIG7Do28gZXN0aXZlciBlbSBhbmltYcOnw6NvIGRlIHTDqXJtaW5vLCBuw6NvIHJlbmRlcml6YSBuYWRhXHJcbiAgaWYgKCFpc0xvYWRpbmcgJiYgIWlzRmluaXNoaW5nKSB7XHJcbiAgICByZXR1cm4gbnVsbDtcclxuICB9XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2XHJcbiAgICAgIHJvbGU9XCJzdGF0dXNcIlxyXG4gICAgICBhcmlhLWxpdmU9XCJwb2xpdGVcIlxyXG4gICAgICBhcmlhLWJ1c3k9e2lzTG9hZGluZ31cclxuICAgICAgY2xhc3NOYW1lPVwicG9pbnRlci1ldmVudHMtbm9uZSBmaXhlZCBpbnNldC14LTAgdG9wLTAgei1bOTk5OV1cIlxyXG4gICAgPlxyXG4gICAgICA8c3BhbiBjbGFzc05hbWU9XCJzci1vbmx5XCI+XHJcbiAgICAgICAge2lzTG9hZGluZ1xyXG4gICAgICAgICAgPyBgQ2FycmVnYW5kbyBkYWRvcyBkbyBzZXJ2aWRvciAoJHthY3RpdmVSZXF1ZXN0c0NvdW50fSByZXF1aXNpw6fDo28ke1xyXG4gICAgICAgICAgICAgIGFjdGl2ZVJlcXVlc3RzQ291bnQgPiAxID8gXCLDtWVzXCIgOiBcIlwiXHJcbiAgICAgICAgICAgIH0gZW0gYW5kYW1lbnRvKWBcclxuICAgICAgICAgIDogXCJDYXJyZWdhbWVudG8gY29uY2x1w61kb1wifVxyXG4gICAgICA8L3NwYW4+XHJcblxyXG4gICAgICB7LyogMS4gQmFycmEgZGUgUHJvZ3Jlc3NvIFN1cGVyaW9yIChTbGltIFRvcCBQcm9ncmVzcyBCYXIpICovfVxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIGgtMSB3LWZ1bGwgb3ZlcmZsb3ctaGlkZGVuIGJnLXRyYW5zcGFyZW50XCI+XHJcbiAgICAgICAgPGRpdlxyXG4gICAgICAgICAgY2xhc3NOYW1lPXtgaC1mdWxsIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMCBlYXNlLW91dCAke1xyXG4gICAgICAgICAgICBpc0ZpbmlzaGluZ1xyXG4gICAgICAgICAgICAgID8gXCJ3LWZ1bGwgYmctZW1lcmFsZC01MDAgb3BhY2l0eS0wIHRyYW5zaXRpb24tb3BhY2l0eSBkdXJhdGlvbi0zMDBcIlxyXG4gICAgICAgICAgICAgIDogXCJ3LWZ1bGwgYmctZ3JhZGllbnQtdG8tciBmcm9tLXRlYWwtNTAwIHZpYS1lbWVyYWxkLTQwMCB0by1jeWFuLTUwMCBzaGFkb3ctWzBfMF84cHhfcmdiYSgyMCwxODQsMTY2LDAuOCldXCJcclxuICAgICAgICAgIH1gfVxyXG4gICAgICAgICAgc3R5bGU9e3tcclxuICAgICAgICAgICAgYW5pbWF0aW9uOiBpc0ZpbmlzaGluZyA/IFwibm9uZVwiIDogXCJ2aWdpbWluYXMtbG9hZGluZy1wdWxzZSAxLjRzIGVhc2UtaW4tb3V0IGluZmluaXRlXCIsXHJcbiAgICAgICAgICB9fVxyXG4gICAgICAgIC8+XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgey8qIDIuIEJhZGdlIEZsdXR1YW50ZSBEaXNjcmV0byBubyBDYW50byBJbmZlcmlvciBEaXJlaXRvIChjb20gRGVib3VuY2UpICovfVxyXG4gICAgICB7c2hvd0JhZGdlICYmIChzaG93RGVib3VuY2VkQmFkZ2UgfHwgKGlzTG9hZGluZyAmJiBhY3RpdmVSZXF1ZXN0c0NvdW50ID4gMSkpICYmIChcclxuICAgICAgICA8YXNpZGVcclxuICAgICAgICAgIGFyaWEtaGlkZGVuPXshaXNMb2FkaW5nfVxyXG4gICAgICAgICAgY2xhc3NOYW1lPVwicG9pbnRlci1ldmVudHMtYXV0byBmaXhlZCBib3R0b20tNSByaWdodC01IHotWzk5OTldIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yLjUgcm91bmRlZC1mdWxsIGJvcmRlciBib3JkZXItc2xhdGUtNzAwLzgwIGJnLXNsYXRlLTkwMC85MCBweC0zLjUgcHktMS41IHRleHQteHMgdGV4dC1zbGF0ZS0xMDAgc2hhZG93LXhsIGJhY2tkcm9wLWJsdXItbWQgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMjAwIGFuaW1hdGUtaW4gZmFkZS1pbiBzbGlkZS1pbi1mcm9tLWJvdHRvbS0yIGRhcms6Ym9yZGVyLXNsYXRlLTYwMCBkYXJrOmJnLXNsYXRlLTgwMC85NVwiXHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgPExvYWRlcjIgY2xhc3NOYW1lPVwiaC0zLjUgdy0zLjUgYW5pbWF0ZS1zcGluIHRleHQtdGVhbC00MDBcIiAvPlxyXG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tZWRpdW0gdHJhY2tpbmctdGlnaHRcIj5TaW5jcm9uaXphbmRvIGRhZG9zLi4uPC9zcGFuPlxyXG4gICAgICAgICAge2FjdGl2ZVJlcXVlc3RzQ291bnQgPiAxICYmIChcclxuICAgICAgICAgICAgPHNwYW5cclxuICAgICAgICAgICAgICB0aXRsZT17YCR7YWN0aXZlUmVxdWVzdHNDb3VudH0gcmVxdWlzacOnw7VlcyBhdGl2YXMgc2ltdWx0w6JuZWFzYH1cclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBoLTQgbWluLXctWzFyZW1dIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciByb3VuZGVkLWZ1bGwgYmctdGVhbC01MDAvMjAgcHgtMSB0ZXh0LVsxMHB4XSBmb250LXNlbWlib2xkIHRleHQtdGVhbC0zMDAgYm9yZGVyIGJvcmRlci10ZWFsLTUwMC8zMFwiXHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICB7YWN0aXZlUmVxdWVzdHNDb3VudH1cclxuICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgKX1cclxuICAgICAgICA8L2FzaWRlPlxyXG4gICAgICApfVxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IEdsb2JhbExvYWRpbmdJbmRpY2F0b3I7XHJcbiJdfQ==