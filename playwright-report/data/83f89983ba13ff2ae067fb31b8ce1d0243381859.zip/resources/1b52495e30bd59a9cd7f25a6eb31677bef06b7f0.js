import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/indicadores/RelatorioSusImpressaoView.tsx");const React = __vite__cjsImport0_react;const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];/**
* Layout Oficial do Relatório de Prestação de Contas Sanitárias SUS (A4 para Impressão)
* Compatível com DIGISUS / Sargsus e diretrizes do Pacto da Saúde.
* Estilizado para folha A4 com regras @media print e cabeçalho oficial dinâmico de APP_CONFIG.
*/
import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=0fd2848a";
import { Shield } from "/node_modules/.vite/deps/lucide-react.js?v=0fd2848a";
import { APP_CONFIG } from "/src/config/app.config.ts";
var _jsxFileName = "E:/Projetos VSCODE/visa_braunas/src/components/indicadores/RelatorioSusImpressaoView.tsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=0fd2848a";
export const RelatorioSusImpressaoView = ({ relatorio, nomeCoordenador = "Coordenação de Vigilância Sanitária", matriculaCoordenador = "VISA-0042/MG" }) => {
	const { ano_exercicio, data_emissao_relatorio, indicadores_sintese = [], resumo_geral = {} } = relatorio;
	const totalEmpresas = resumo_geral.total_estabelecimentos_cadastrados ?? 239;
	const totalInspecoes = resumo_geral.total_inspecoes_exercicio ?? 84;
	const totalAlvaras = resumo_geral.total_alvaras_ativos ?? 162;
	const totalVapt = resumo_geral.acoes_vapt_concluidas ?? 18;
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "bg-white text-slate-900 font-sans p-8 sm:p-12 max-w-[210mm] mx-auto min-h-[297mm] shadow-lg print:shadow-none print:p-0 print:m-0 print:max-w-none print:w-full print:min-h-0",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "border-b-2 border-slate-900 pb-5 mb-6 text-center flex flex-col items-center",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "w-14 h-14 rounded-full border-2 border-slate-900 flex items-center justify-center mb-3",
						children: /* @__PURE__ */ _jsxDEV(Shield, { className: "w-8 h-8 text-slate-900 stroke-[2.2]" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 41,
							columnNumber: 11
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 40,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "text-xs uppercase font-bold tracking-widest text-slate-700",
						children: [
							APP_CONFIG.pais,
							" • ",
							APP_CONFIG.estadoExtenso
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 44,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("h1", {
						className: "text-base font-extrabold uppercase tracking-tight text-slate-900 mt-0.5",
						children: APP_CONFIG.prefeitura
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 47,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("h2", {
						className: "text-xs font-semibold text-slate-800 uppercase mt-0.5",
						children: APP_CONFIG.secretaria
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 50,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("h3", {
						className: "text-xs font-bold text-slate-900 uppercase tracking-wide mt-0.5",
						children: APP_CONFIG.orgao
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 53,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 38,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "mb-6 bg-slate-50 border border-slate-300 p-4 rounded-sm print:bg-transparent print:border-slate-400",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-300 pb-2 mb-2 text-xs",
						children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "font-bold text-slate-700",
							children: "DOCUMENTO OFICIAL: "
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 62,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							className: "font-mono font-bold text-slate-900",
							children: [
								"REL-SUS/",
								ano_exercicio,
								"/",
								APP_CONFIG.municipio.toUpperCase()
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 63,
							columnNumber: 13
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 61,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "font-bold text-slate-700",
							children: "EMISSÃO: "
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 68,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							className: "font-mono text-slate-900",
							children: data_emissao_relatorio
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 69,
							columnNumber: 13
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 67,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 60,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("h2", {
						className: "text-sm font-extrabold uppercase text-slate-900 text-center tracking-wide",
						children: "RELATÓRIO ANUAL DE PRESTAÇÃO DE CONTAS SANITÁRIAS & CUMPRIMENTO DE METAS DO SUS"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 73,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("p", {
						className: "text-[11px] text-slate-600 text-center mt-1",
						children: [
							"Exercício de Referência: ",
							/* @__PURE__ */ _jsxDEV("strong", { children: ano_exercicio }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 77,
								columnNumber: 36
							}, this),
							" • Município:",
							" ",
							/* @__PURE__ */ _jsxDEV("strong", { children: [
								APP_CONFIG.municipio,
								" - ",
								APP_CONFIG.uf
							] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 78,
								columnNumber: 11
							}, this),
							" • Diretrizes: DIGISUS / Rargsus / Pacto da Saúde"
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 76,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 59,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "mb-6",
				children: [/* @__PURE__ */ _jsxDEV("h3", {
					className: "text-xs font-bold uppercase tracking-wider text-slate-800 border-b border-slate-400 pb-1 mb-2",
					children: "1. Síntese do Parque Cadastral e Ações Regulatórias"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 84,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "grid grid-cols-4 gap-2 text-center text-xs",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "border border-slate-300 p-2 rounded-xs",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-[10px] uppercase text-slate-500 font-semibold block",
								children: "Empresas Ativas"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 89,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "text-sm font-extrabold text-slate-900 tabular-nums",
								children: totalEmpresas
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 92,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 88,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "border border-slate-300 p-2 rounded-xs",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-[10px] uppercase text-slate-500 font-semibold block",
								children: "Alvarás Vigentes"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 97,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "text-sm font-extrabold text-slate-900 tabular-nums",
								children: totalAlvaras
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 100,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 96,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "border border-slate-300 p-2 rounded-xs",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-[10px] uppercase text-slate-500 font-semibold block",
								children: "Vistorias Realizadas"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 105,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "text-sm font-extrabold text-slate-900 tabular-nums",
								children: totalInspecoes
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 108,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 104,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "border border-slate-300 p-2 rounded-xs",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-[10px] uppercase text-slate-500 font-semibold block",
								children: "Ações VAPT (Trabalhador)"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 113,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "text-sm font-extrabold text-slate-900 tabular-nums",
								children: totalVapt
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 116,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 112,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 87,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 83,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "mb-6",
				children: [/* @__PURE__ */ _jsxDEV("h3", {
					className: "text-xs font-bold uppercase tracking-wider text-slate-800 border-b border-slate-400 pb-1 mb-2",
					children: "2. Detalhamento dos Indicadores Sanitários Pactuados (11 a 15)"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 125,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("table", {
					className: "w-full text-left text-xs border border-slate-300",
					children: [/* @__PURE__ */ _jsxDEV("thead", {
						className: "bg-slate-100 text-slate-800 font-bold uppercase text-[10px] border-b border-slate-300",
						children: /* @__PURE__ */ _jsxDEV("tr", { children: [
							/* @__PURE__ */ _jsxDEV("th", {
								className: "py-2 px-2.5 border-r border-slate-300 w-16 text-center",
								children: "Código"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 132,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("th", {
								className: "py-2 px-2.5 border-r border-slate-300",
								children: "Descrição Técnica do Indicador"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 133,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("th", {
								className: "py-2 px-2 border-r border-slate-300 text-center w-20",
								children: "Meta Fixada"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 134,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("th", {
								className: "py-2 px-2 border-r border-slate-300 text-center w-20",
								children: "Realizado"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 135,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("th", {
								className: "py-2 px-2 border-r border-slate-300 text-center w-20",
								children: "Atingimento"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 136,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("th", {
								className: "py-2 px-2.5 text-center w-24",
								children: "Situação"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 137,
								columnNumber: 15
							}, this)
						] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 131,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 130,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("tbody", {
						className: "divide-y divide-slate-300 text-[11px]",
						children: indicadores_sintese.map((ind) => {
							const { codigo, titulo, descricao, unidade, progresso } = ind;
							const { meta_pactuada, realizado, percentual_atingido, status } = progresso;
							const isAtingida = percentual_atingido >= 100 || status?.toLowerCase() === "atingida";
							return /* @__PURE__ */ _jsxDEV("tr", {
								className: "leading-tight",
								children: [
									/* @__PURE__ */ _jsxDEV("td", {
										className: "py-2.5 px-2.5 border-r border-slate-300 font-mono font-bold text-center",
										children: codigo
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 148,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										className: "py-2.5 px-2.5 border-r border-slate-300",
										children: [/* @__PURE__ */ _jsxDEV("div", {
											className: "font-bold text-slate-900",
											children: titulo
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 152,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("div", {
											className: "text-[10px] text-slate-600 mt-0.5",
											children: descricao
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 153,
											columnNumber: 21
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 151,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										className: "py-2.5 px-2 border-r border-slate-300 text-center font-mono",
										children: [
											meta_pactuada,
											" ",
											unidade
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 155,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										className: "py-2.5 px-2 border-r border-slate-300 text-center font-mono font-bold",
										children: [
											realizado,
											" ",
											unidade
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 158,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										className: "py-2.5 px-2 border-r border-slate-300 text-center font-mono font-bold",
										children: [percentual_atingido.toFixed(1), "%"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 161,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										className: "py-2.5 px-2 text-center",
										children: /* @__PURE__ */ _jsxDEV("span", {
											className: `inline-block px-1.5 py-0.5 rounded text-[9px] font-bold uppercase ${isAtingida ? "bg-slate-200 text-slate-900 border border-slate-400" : "bg-slate-100 text-slate-800 border border-slate-300"}`,
											children: status || (isAtingida ? "Atingida" : "Em Andamento")
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 165,
											columnNumber: 21
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 164,
										columnNumber: 19
									}, this)
								]
							}, codigo, true, {
								fileName: _jsxFileName,
								lineNumber: 147,
								columnNumber: 17
							}, this);
						})
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 140,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 129,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 124,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "mb-8 p-3 border border-slate-300 rounded-xs text-[10px] text-slate-600 leading-relaxed",
				children: [/* @__PURE__ */ _jsxDEV("strong", { children: "Nota Técnica Legal:" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 184,
					columnNumber: 9
				}, this), " Indicadores calculados em conformidade com as diretrizes da Resolução SES/MG nº 7.730/2021, Instrução Normativa ANVISA nº 66/2020 e Lei Federal nº 8.080/1990. O Indicador 11 afere a vigilância ativa em ambientes de trabalho (VAPT) visando a prevenção de acidentes e agravos ocupacionais. Os Indicadores 12 a 15 consolidam a cobertura proporcional por grau de risco sanitário atribuído pelo CNAE."]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 183,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "mt-12 pt-6 border-t border-slate-400 break-inside-avoid",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "text-right text-xs text-slate-700 mb-12",
					children: [
						APP_CONFIG.municipio,
						" - ",
						APP_CONFIG.uf,
						", ",
						new Date().toLocaleDateString("pt-BR", {
							day: "2-digit",
							month: "long",
							year: "numeric"
						}),
						"."
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 192,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "grid grid-cols-2 gap-12 text-center text-xs",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex flex-col items-center",
						children: [
							/* @__PURE__ */ _jsxDEV("div", { className: "w-56 border-b border-slate-900 mb-1.5" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 202,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "font-bold text-slate-900 uppercase",
								children: nomeCoordenador
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 203,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "text-[11px] text-slate-600",
								children: APP_CONFIG.orgao
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 206,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "text-[10px] font-mono text-slate-500",
								children: ["Matrícula: ", matriculaCoordenador]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 209,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 201,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "flex flex-col items-center",
						children: [
							/* @__PURE__ */ _jsxDEV("div", { className: "w-56 border-b border-slate-900 mb-1.5" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 215,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "font-bold text-slate-900 uppercase",
								children: APP_CONFIG.secretaria
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 216,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "text-[11px] text-slate-600",
								children: "Gestor Municipal do SUS"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 219,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "text-[10px] font-mono text-slate-500",
								children: APP_CONFIG.prefeitura
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 222,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 214,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 200,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 191,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 36,
		columnNumber: 5
	}, this);
};
_c = RelatorioSusImpressaoView;
export default RelatorioSusImpressaoView;
var _c;
$RefreshReg$(_c, "RelatorioSusImpressaoView");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/indicadores/RelatorioSusImpressaoView.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("E:/Projetos VSCODE/visa_braunas/src/components/indicadores/RelatorioSusImpressaoView.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("E:/Projetos VSCODE/visa_braunas/src/components/indicadores/RelatorioSusImpressaoView.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "E:/Projetos VSCODE/visa_braunas/src/components/indicadores/RelatorioSusImpressaoView.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7Ozs7QUFNQSxPQUFPLFdBQVc7QUFDbEIsU0FBUyxjQUFjO0FBQ3ZCLFNBQVMsa0JBQWtCOzs7QUFTM0IsT0FBTyxNQUFNLDZCQUF1RSxFQUNsRixXQUNBLGtCQUFrQix1Q0FDbEIsdUJBQXVCLHFCQUNuQjtDQUNKLE1BQU0sRUFDSixlQUNBLHdCQUNBLHNCQUFzQixDQUFDLEdBQ3ZCLGVBQWUsQ0FBQyxNQUNkO0NBRUosTUFBTSxnQkFBZ0IsYUFBYSxzQ0FBc0M7Q0FDekUsTUFBTSxpQkFBaUIsYUFBYSw2QkFBNkI7Q0FDakUsTUFBTSxlQUFlLGFBQWEsd0JBQXdCO0NBQzFELE1BQU0sWUFBWSxhQUFhLHlCQUF5QjtDQUV4RCxPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQWY7R0FFRSx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmO0tBRUUsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQ2Isd0JBQUMsUUFBRCxFQUFRLFdBQVUsc0NBQXVDOzs7OztLQUN0RDs7Ozs7S0FFTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZjtPQUNHLFdBQVc7T0FBSztPQUFJLFdBQVc7TUFDN0I7Ozs7OztLQUNMLHdCQUFDLE1BQUQ7TUFBSSxXQUFVO2dCQUNYLFdBQVc7S0FDVjs7Ozs7S0FDSix3QkFBQyxNQUFEO01BQUksV0FBVTtnQkFDWCxXQUFXO0tBQ1Y7Ozs7O0tBQ0osd0JBQUMsTUFBRDtNQUFJLFdBQVU7Z0JBQ1gsV0FBVztLQUNWOzs7OztJQUNEOzs7Ozs7R0FHTCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmO0tBQ0Usd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsUUFBRDtPQUFNLFdBQVU7aUJBQTJCO01BQXlCOzs7O2dCQUNwRSx3QkFBQyxRQUFEO09BQU0sV0FBVTtpQkFBaEI7UUFBcUQ7UUFDMUM7UUFBYztRQUFFLFdBQVcsVUFBVSxZQUFZO09BQ3REOzs7OztjQUNIOzs7O2dCQUNMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxRQUFEO09BQU0sV0FBVTtpQkFBMkI7TUFBZTs7OztnQkFDMUQsd0JBQUMsUUFBRDtPQUFNLFdBQVU7aUJBQTRCO01BQTZCOzs7O2NBQ3RFOzs7O2NBQ0Y7Ozs7OztLQUVMLHdCQUFDLE1BQUQ7TUFBSSxXQUFVO2dCQUE0RTtLQUV0Rjs7Ozs7S0FDSix3QkFBQyxLQUFEO01BQUcsV0FBVTtnQkFBYjtPQUEyRDtPQUNoQyx3QkFBQyxVQUFELFlBQVMsY0FBc0I7Ozs7O09BQUM7T0FBYztPQUN2RSx3QkFBQyxVQUFEO1FBQVMsV0FBVztRQUFVO1FBQUksV0FBVztPQUFXOzs7OztPQUFDO01BQ3hEOzs7Ozs7SUFDQTs7Ozs7O0dBR0wsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLE1BQUQ7S0FBSSxXQUFVO2VBQWdHO0lBRTFHOzs7O2NBQ0osd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZjtNQUNFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQTJEO09BRXJFOzs7O2lCQUNOLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUNiO09BQ0c7Ozs7ZUFDSDs7Ozs7O01BQ0wsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBMkQ7T0FFckU7Ozs7aUJBQ04sd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQ2I7T0FDRzs7OztlQUNIOzs7Ozs7TUFDTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUEyRDtPQUVyRTs7OztpQkFDTix3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFDYjtPQUNHOzs7O2VBQ0g7Ozs7OztNQUNMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQTJEO09BRXJFOzs7O2lCQUNOLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUNiO09BQ0c7Ozs7ZUFDSDs7Ozs7O0tBQ0Y7Ozs7O1lBQ0Y7Ozs7OztHQUdMLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxNQUFEO0tBQUksV0FBVTtlQUFnRztJQUUxRzs7OztjQUVKLHdCQUFDLFNBQUQ7S0FBTyxXQUFVO2VBQWpCLENBQ0Usd0JBQUMsU0FBRDtNQUFPLFdBQVU7Z0JBQ2Ysd0JBQUMsTUFBRDtPQUNFLHdCQUFDLE1BQUQ7UUFBSSxXQUFVO2tCQUF5RDtPQUFVOzs7OztPQUNqRix3QkFBQyxNQUFEO1FBQUksV0FBVTtrQkFBd0M7T0FBa0M7Ozs7O09BQ3hGLHdCQUFDLE1BQUQ7UUFBSSxXQUFVO2tCQUF1RDtPQUFlOzs7OztPQUNwRix3QkFBQyxNQUFEO1FBQUksV0FBVTtrQkFBdUQ7T0FBYTs7Ozs7T0FDbEYsd0JBQUMsTUFBRDtRQUFJLFdBQVU7a0JBQXVEO09BQWU7Ozs7O09BQ3BGLHdCQUFDLE1BQUQ7UUFBSSxXQUFVO2tCQUErQjtPQUFZOzs7OztNQUN2RDs7Ozs7S0FDQzs7OztlQUNQLHdCQUFDLFNBQUQ7TUFBTyxXQUFVO2dCQUNkLG9CQUFvQixLQUFLLFFBQVE7T0FDaEMsTUFBTSxFQUFFLFFBQVEsUUFBUSxXQUFXLFNBQVMsY0FBYztPQUMxRCxNQUFNLEVBQUUsZUFBZSxXQUFXLHFCQUFxQixXQUFXO09BQ2xFLE1BQU0sYUFBYSx1QkFBdUIsT0FBTyxRQUFRLFlBQVksTUFBTTtPQUUzRSxPQUNFLHdCQUFDLE1BQUQ7UUFBaUIsV0FBVTtrQkFBM0I7U0FDRSx3QkFBQyxNQUFEO1VBQUksV0FBVTtvQkFDWDtTQUNDOzs7OztTQUNKLHdCQUFDLE1BQUQ7VUFBSSxXQUFVO29CQUFkLENBQ0Usd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQTRCO1VBQVk7Ozs7b0JBQ3ZELHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUFxQztVQUFlOzs7O2tCQUNqRTs7Ozs7O1NBQ0osd0JBQUMsTUFBRDtVQUFJLFdBQVU7b0JBQWQ7V0FDRztXQUFjO1dBQUU7VUFDZjs7Ozs7O1NBQ0osd0JBQUMsTUFBRDtVQUFJLFdBQVU7b0JBQWQ7V0FDRztXQUFVO1dBQUU7VUFDWDs7Ozs7O1NBQ0osd0JBQUMsTUFBRDtVQUFJLFdBQVU7b0JBQWQsQ0FDRyxvQkFBb0IsUUFBUSxDQUFDLEdBQUUsR0FDOUI7Ozs7OztTQUNKLHdCQUFDLE1BQUQ7VUFBSSxXQUFVO29CQUNaLHdCQUFDLFFBQUQ7V0FDRSxXQUFXLHFFQUNULGFBQ0ksd0RBQ0E7cUJBR0wsV0FBVyxhQUFhLGFBQWE7VUFDbEM7Ozs7O1NBQ0o7Ozs7O1FBQ0Y7VUE1Qks7Ozs7Y0E0Qkw7TUFFUixDQUFDO0tBQ0k7Ozs7YUFDRjs7Ozs7WUFDSjs7Ozs7O0dBR0wsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLFVBQUQsWUFBUSxzQkFBMkI7Ozs7Y0FBQyw4WUFJakM7Ozs7OztHQUdMLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmO01BQ0csV0FBVztNQUFVO01BQUksV0FBVztNQUFHO01BQUcsSUFBSSxLQUFLLENBQUMsQ0FBQyxtQkFBbUIsU0FBUztPQUNoRixLQUFLO09BQ0wsT0FBTztPQUNQLE1BQU07TUFDUixDQUFDO01BQUU7S0FDQTs7Ozs7Y0FFTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWY7T0FDRSx3QkFBQyxPQUFELEVBQUssV0FBVSx3Q0FBeUM7Ozs7O09BQ3hELHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUNaO09BQ0U7Ozs7O09BQ0wsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQ1osV0FBVztPQUNUOzs7OztPQUNMLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQXNELGVBQ3hDLG9CQUNUOzs7Ozs7TUFDRjs7Ozs7ZUFFTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZjtPQUNFLHdCQUFDLE9BQUQsRUFBSyxXQUFVLHdDQUF5Qzs7Ozs7T0FDeEQsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQ1osV0FBVztPQUNUOzs7OztPQUNMLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUE2QjtPQUV2Qzs7Ozs7T0FDTCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFDWixXQUFXO09BQ1Q7Ozs7O01BQ0Y7Ozs7O2FBQ0Y7Ozs7O1lBQ0Y7Ozs7OztFQUNGOzs7Ozs7QUFFVDs7QUFFQSxlQUFlIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIlJlbGF0b3Jpb1N1c0ltcHJlc3Nhb1ZpZXcudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbIi8qKlxyXG4gKiBMYXlvdXQgT2ZpY2lhbCBkbyBSZWxhdMOzcmlvIGRlIFByZXN0YcOnw6NvIGRlIENvbnRhcyBTYW5pdMOhcmlhcyBTVVMgKEE0IHBhcmEgSW1wcmVzc8OjbylcclxuICogQ29tcGF0w612ZWwgY29tIERJR0lTVVMgLyBTYXJnc3VzIGUgZGlyZXRyaXplcyBkbyBQYWN0byBkYSBTYcO6ZGUuXHJcbiAqIEVzdGlsaXphZG8gcGFyYSBmb2xoYSBBNCBjb20gcmVncmFzIEBtZWRpYSBwcmludCBlIGNhYmXDp2FsaG8gb2ZpY2lhbCBkaW7Dom1pY28gZGUgQVBQX0NPTkZJRy5cclxuICovXHJcblxyXG5pbXBvcnQgUmVhY3QgZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7IFNoaWVsZCB9IGZyb20gXCJsdWNpZGUtcmVhY3RcIjtcclxuaW1wb3J0IHsgQVBQX0NPTkZJRyB9IGZyb20gXCIuLi8uLi9jb25maWcvYXBwLmNvbmZpZ1wiO1xyXG5pbXBvcnQgeyBSZWxhdG9yaW9TdXNEVE8gfSBmcm9tIFwiLi4vLi4vdHlwZXMvaW5kaWNhZG9yZXNcIjtcclxuXHJcbmludGVyZmFjZSBSZWxhdG9yaW9TdXNJbXByZXNzYW9WaWV3UHJvcHMge1xyXG4gIHJlbGF0b3JpbzogUmVsYXRvcmlvU3VzRFRPO1xyXG4gIG5vbWVDb29yZGVuYWRvcj86IHN0cmluZztcclxuICBtYXRyaWN1bGFDb29yZGVuYWRvcj86IHN0cmluZztcclxufVxyXG5cclxuZXhwb3J0IGNvbnN0IFJlbGF0b3Jpb1N1c0ltcHJlc3Nhb1ZpZXc6IFJlYWN0LkZDPFJlbGF0b3Jpb1N1c0ltcHJlc3Nhb1ZpZXdQcm9wcz4gPSAoe1xyXG4gIHJlbGF0b3JpbyxcclxuICBub21lQ29vcmRlbmFkb3IgPSBcIkNvb3JkZW5hw6fDo28gZGUgVmlnaWzDom5jaWEgU2FuaXTDoXJpYVwiLFxyXG4gIG1hdHJpY3VsYUNvb3JkZW5hZG9yID0gXCJWSVNBLTAwNDIvTUdcIixcclxufSkgPT4ge1xyXG4gIGNvbnN0IHtcclxuICAgIGFub19leGVyY2ljaW8sXHJcbiAgICBkYXRhX2VtaXNzYW9fcmVsYXRvcmlvLFxyXG4gICAgaW5kaWNhZG9yZXNfc2ludGVzZSA9IFtdLFxyXG4gICAgcmVzdW1vX2dlcmFsID0ge30sXHJcbiAgfSA9IHJlbGF0b3JpbztcclxuXHJcbiAgY29uc3QgdG90YWxFbXByZXNhcyA9IHJlc3Vtb19nZXJhbC50b3RhbF9lc3RhYmVsZWNpbWVudG9zX2NhZGFzdHJhZG9zID8/IDIzOTtcclxuICBjb25zdCB0b3RhbEluc3BlY29lcyA9IHJlc3Vtb19nZXJhbC50b3RhbF9pbnNwZWNvZXNfZXhlcmNpY2lvID8/IDg0O1xyXG4gIGNvbnN0IHRvdGFsQWx2YXJhcyA9IHJlc3Vtb19nZXJhbC50b3RhbF9hbHZhcmFzX2F0aXZvcyA/PyAxNjI7XHJcbiAgY29uc3QgdG90YWxWYXB0ID0gcmVzdW1vX2dlcmFsLmFjb2VzX3ZhcHRfY29uY2x1aWRhcyA/PyAxODtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgdGV4dC1zbGF0ZS05MDAgZm9udC1zYW5zIHAtOCBzbTpwLTEyIG1heC13LVsyMTBtbV0gbXgtYXV0byBtaW4taC1bMjk3bW1dIHNoYWRvdy1sZyBwcmludDpzaGFkb3ctbm9uZSBwcmludDpwLTAgcHJpbnQ6bS0wIHByaW50Om1heC13LW5vbmUgcHJpbnQ6dy1mdWxsIHByaW50Om1pbi1oLTBcIj5cclxuICAgICAgey8qIENhYmXDp2FsaG8gT2ZpY2lhbCBkbyBNdW5pY8OtcGlvICovfVxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImJvcmRlci1iLTIgYm9yZGVyLXNsYXRlLTkwMCBwYi01IG1iLTYgdGV4dC1jZW50ZXIgZmxleCBmbGV4LWNvbCBpdGVtcy1jZW50ZXJcIj5cclxuICAgICAgICB7LyogQnJhc8OjbyAvIFPDrW1ib2xvIEluc3RpdHVjaW9uYWwgKi99XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTE0IGgtMTQgcm91bmRlZC1mdWxsIGJvcmRlci0yIGJvcmRlci1zbGF0ZS05MDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgbWItM1wiPlxyXG4gICAgICAgICAgPFNoaWVsZCBjbGFzc05hbWU9XCJ3LTggaC04IHRleHQtc2xhdGUtOTAwIHN0cm9rZS1bMi4yXVwiIC8+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC14cyB1cHBlcmNhc2UgZm9udC1ib2xkIHRyYWNraW5nLXdpZGVzdCB0ZXh0LXNsYXRlLTcwMFwiPlxyXG4gICAgICAgICAge0FQUF9DT05GSUcucGFpc30g4oCiIHtBUFBfQ09ORklHLmVzdGFkb0V4dGVuc299XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQtYmFzZSBmb250LWV4dHJhYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctdGlnaHQgdGV4dC1zbGF0ZS05MDAgbXQtMC41XCI+XHJcbiAgICAgICAgICB7QVBQX0NPTkZJRy5wcmVmZWl0dXJhfVxyXG4gICAgICAgIDwvaDE+XHJcbiAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTgwMCB1cHBlcmNhc2UgbXQtMC41XCI+XHJcbiAgICAgICAgICB7QVBQX0NPTkZJRy5zZWNyZXRhcmlhfVxyXG4gICAgICAgIDwvaDI+XHJcbiAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHRleHQtc2xhdGUtOTAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlIG10LTAuNVwiPlxyXG4gICAgICAgICAge0FQUF9DT05GSUcub3JnYW99XHJcbiAgICAgICAgPC9oMz5cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICB7LyogSWRlbnRpZmljYcOnw6NvIGRvIFJlbGF0w7NyaW8gT2ZpY2lhbCAqL31cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi02IGJnLXNsYXRlLTUwIGJvcmRlciBib3JkZXItc2xhdGUtMzAwIHAtNCByb3VuZGVkLXNtIHByaW50OmJnLXRyYW5zcGFyZW50IHByaW50OmJvcmRlci1zbGF0ZS00MDBcIj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgc206ZmxleC1yb3cgc206aXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtMiBib3JkZXItYiBib3JkZXItc2xhdGUtMzAwIHBiLTIgbWItMiB0ZXh0LXhzXCI+XHJcbiAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1zbGF0ZS03MDBcIj5ET0NVTUVOVE8gT0ZJQ0lBTDogPC9zcGFuPlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1vbm8gZm9udC1ib2xkIHRleHQtc2xhdGUtOTAwXCI+XHJcbiAgICAgICAgICAgICAgUkVMLVNVUy97YW5vX2V4ZXJjaWNpb30ve0FQUF9DT05GSUcubXVuaWNpcGlvLnRvVXBwZXJDYXNlKCl9XHJcbiAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtc2xhdGUtNzAwXCI+RU1JU1PDg086IDwvc3Bhbj5cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tb25vIHRleHQtc2xhdGUtOTAwXCI+e2RhdGFfZW1pc3Nhb19yZWxhdG9yaW99PC9zcGFuPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtZXh0cmFib2xkIHVwcGVyY2FzZSB0ZXh0LXNsYXRlLTkwMCB0ZXh0LWNlbnRlciB0cmFja2luZy13aWRlXCI+XHJcbiAgICAgICAgICBSRUxBVMOTUklPIEFOVUFMIERFIFBSRVNUQcOHw4NPIERFIENPTlRBUyBTQU5JVMOBUklBUyAmIENVTVBSSU1FTlRPIERFIE1FVEFTIERPIFNVU1xyXG4gICAgICAgIDwvaDI+XHJcbiAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1zbGF0ZS02MDAgdGV4dC1jZW50ZXIgbXQtMVwiPlxyXG4gICAgICAgICAgRXhlcmPDrWNpbyBkZSBSZWZlcsOqbmNpYTogPHN0cm9uZz57YW5vX2V4ZXJjaWNpb308L3N0cm9uZz4g4oCiIE11bmljw61waW86e1wiIFwifVxyXG4gICAgICAgICAgPHN0cm9uZz57QVBQX0NPTkZJRy5tdW5pY2lwaW99IC0ge0FQUF9DT05GSUcudWZ9PC9zdHJvbmc+IOKAoiBEaXJldHJpemVzOiBESUdJU1VTIC8gUmFyZ3N1cyAvIFBhY3RvIGRhIFNhw7pkZVxyXG4gICAgICAgIDwvcD5cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICB7LyogUmVzdW1vIENhZGFzdHJhbCBlIE9wZXJhY2lvbmFsIENvbnNvbGlkYWRvICovfVxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTZcIj5cclxuICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtc2xhdGUtODAwIGJvcmRlci1iIGJvcmRlci1zbGF0ZS00MDAgcGItMSBtYi0yXCI+XHJcbiAgICAgICAgICAxLiBTw61udGVzZSBkbyBQYXJxdWUgQ2FkYXN0cmFsIGUgQcOnw7VlcyBSZWd1bGF0w7NyaWFzXHJcbiAgICAgICAgPC9oMz5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTQgZ2FwLTIgdGV4dC1jZW50ZXIgdGV4dC14c1wiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJib3JkZXIgYm9yZGVyLXNsYXRlLTMwMCBwLTIgcm91bmRlZC14c1wiPlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB1cHBlcmNhc2UgdGV4dC1zbGF0ZS01MDAgZm9udC1zZW1pYm9sZCBibG9ja1wiPlxyXG4gICAgICAgICAgICAgIEVtcHJlc2FzIEF0aXZhc1xyXG4gICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1leHRyYWJvbGQgdGV4dC1zbGF0ZS05MDAgdGFidWxhci1udW1zXCI+XHJcbiAgICAgICAgICAgICAge3RvdGFsRW1wcmVzYXN9XHJcbiAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJib3JkZXIgYm9yZGVyLXNsYXRlLTMwMCBwLTIgcm91bmRlZC14c1wiPlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB1cHBlcmNhc2UgdGV4dC1zbGF0ZS01MDAgZm9udC1zZW1pYm9sZCBibG9ja1wiPlxyXG4gICAgICAgICAgICAgIEFsdmFyw6FzIFZpZ2VudGVzXHJcbiAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LWV4dHJhYm9sZCB0ZXh0LXNsYXRlLTkwMCB0YWJ1bGFyLW51bXNcIj5cclxuICAgICAgICAgICAgICB7dG90YWxBbHZhcmFzfVxyXG4gICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYm9yZGVyIGJvcmRlci1zbGF0ZS0zMDAgcC0yIHJvdW5kZWQteHNcIj5cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdXBwZXJjYXNlIHRleHQtc2xhdGUtNTAwIGZvbnQtc2VtaWJvbGQgYmxvY2tcIj5cclxuICAgICAgICAgICAgICBWaXN0b3JpYXMgUmVhbGl6YWRhc1xyXG4gICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1leHRyYWJvbGQgdGV4dC1zbGF0ZS05MDAgdGFidWxhci1udW1zXCI+XHJcbiAgICAgICAgICAgICAge3RvdGFsSW5zcGVjb2VzfVxyXG4gICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYm9yZGVyIGJvcmRlci1zbGF0ZS0zMDAgcC0yIHJvdW5kZWQteHNcIj5cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdXBwZXJjYXNlIHRleHQtc2xhdGUtNTAwIGZvbnQtc2VtaWJvbGQgYmxvY2tcIj5cclxuICAgICAgICAgICAgICBBw6fDtWVzIFZBUFQgKFRyYWJhbGhhZG9yKVxyXG4gICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1leHRyYWJvbGQgdGV4dC1zbGF0ZS05MDAgdGFidWxhci1udW1zXCI+XHJcbiAgICAgICAgICAgICAge3RvdGFsVmFwdH1cclxuICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgey8qIFRhYmVsYSBPZmljaWFsIGRlIEluZGljYWRvcmVzIFBhY3R1YWRvcyAqL31cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi02XCI+XHJcbiAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LXNsYXRlLTgwMCBib3JkZXItYiBib3JkZXItc2xhdGUtNDAwIHBiLTEgbWItMlwiPlxyXG4gICAgICAgICAgMi4gRGV0YWxoYW1lbnRvIGRvcyBJbmRpY2Fkb3JlcyBTYW5pdMOhcmlvcyBQYWN0dWFkb3MgKDExIGEgMTUpXHJcbiAgICAgICAgPC9oMz5cclxuXHJcbiAgICAgICAgPHRhYmxlIGNsYXNzTmFtZT1cInctZnVsbCB0ZXh0LWxlZnQgdGV4dC14cyBib3JkZXIgYm9yZGVyLXNsYXRlLTMwMFwiPlxyXG4gICAgICAgICAgPHRoZWFkIGNsYXNzTmFtZT1cImJnLXNsYXRlLTEwMCB0ZXh0LXNsYXRlLTgwMCBmb250LWJvbGQgdXBwZXJjYXNlIHRleHQtWzEwcHhdIGJvcmRlci1iIGJvcmRlci1zbGF0ZS0zMDBcIj5cclxuICAgICAgICAgICAgPHRyPlxyXG4gICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0yIHB4LTIuNSBib3JkZXItciBib3JkZXItc2xhdGUtMzAwIHctMTYgdGV4dC1jZW50ZXJcIj5Dw7NkaWdvPC90aD5cclxuICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMiBweC0yLjUgYm9yZGVyLXIgYm9yZGVyLXNsYXRlLTMwMFwiPkRlc2NyacOnw6NvIFTDqWNuaWNhIGRvIEluZGljYWRvcjwvdGg+XHJcbiAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB5LTIgcHgtMiBib3JkZXItciBib3JkZXItc2xhdGUtMzAwIHRleHQtY2VudGVyIHctMjBcIj5NZXRhIEZpeGFkYTwvdGg+XHJcbiAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB5LTIgcHgtMiBib3JkZXItciBib3JkZXItc2xhdGUtMzAwIHRleHQtY2VudGVyIHctMjBcIj5SZWFsaXphZG88L3RoPlxyXG4gICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0yIHB4LTIgYm9yZGVyLXIgYm9yZGVyLXNsYXRlLTMwMCB0ZXh0LWNlbnRlciB3LTIwXCI+QXRpbmdpbWVudG88L3RoPlxyXG4gICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0yIHB4LTIuNSB0ZXh0LWNlbnRlciB3LTI0XCI+U2l0dWHDp8OjbzwvdGg+XHJcbiAgICAgICAgICAgIDwvdHI+XHJcbiAgICAgICAgICA8L3RoZWFkPlxyXG4gICAgICAgICAgPHRib2R5IGNsYXNzTmFtZT1cImRpdmlkZS15IGRpdmlkZS1zbGF0ZS0zMDAgdGV4dC1bMTFweF1cIj5cclxuICAgICAgICAgICAge2luZGljYWRvcmVzX3NpbnRlc2UubWFwKChpbmQpID0+IHtcclxuICAgICAgICAgICAgICBjb25zdCB7IGNvZGlnbywgdGl0dWxvLCBkZXNjcmljYW8sIHVuaWRhZGUsIHByb2dyZXNzbyB9ID0gaW5kO1xyXG4gICAgICAgICAgICAgIGNvbnN0IHsgbWV0YV9wYWN0dWFkYSwgcmVhbGl6YWRvLCBwZXJjZW50dWFsX2F0aW5naWRvLCBzdGF0dXMgfSA9IHByb2dyZXNzbztcclxuICAgICAgICAgICAgICBjb25zdCBpc0F0aW5naWRhID0gcGVyY2VudHVhbF9hdGluZ2lkbyA+PSAxMDAgfHwgc3RhdHVzPy50b0xvd2VyQ2FzZSgpID09PSBcImF0aW5naWRhXCI7XHJcblxyXG4gICAgICAgICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICAgICAgICA8dHIga2V5PXtjb2RpZ299IGNsYXNzTmFtZT1cImxlYWRpbmctdGlnaHRcIj5cclxuICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTIuNSBweC0yLjUgYm9yZGVyLXIgYm9yZGVyLXNsYXRlLTMwMCBmb250LW1vbm8gZm9udC1ib2xkIHRleHQtY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge2NvZGlnb31cclxuICAgICAgICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTIuNSBweC0yLjUgYm9yZGVyLXIgYm9yZGVyLXNsYXRlLTMwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtc2xhdGUtOTAwXCI+e3RpdHVsb308L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtc2xhdGUtNjAwIG10LTAuNVwiPntkZXNjcmljYW99PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS0yLjUgcHgtMiBib3JkZXItciBib3JkZXItc2xhdGUtMzAwIHRleHQtY2VudGVyIGZvbnQtbW9ub1wiPlxyXG4gICAgICAgICAgICAgICAgICAgIHttZXRhX3BhY3R1YWRhfSB7dW5pZGFkZX1cclxuICAgICAgICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTIuNSBweC0yIGJvcmRlci1yIGJvcmRlci1zbGF0ZS0zMDAgdGV4dC1jZW50ZXIgZm9udC1tb25vIGZvbnQtYm9sZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHtyZWFsaXphZG99IHt1bmlkYWRlfVxyXG4gICAgICAgICAgICAgICAgICA8L3RkPlxyXG4gICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMi41IHB4LTIgYm9yZGVyLXIgYm9yZGVyLXNsYXRlLTMwMCB0ZXh0LWNlbnRlciBmb250LW1vbm8gZm9udC1ib2xkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge3BlcmNlbnR1YWxfYXRpbmdpZG8udG9GaXhlZCgxKX0lXHJcbiAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS0yLjUgcHgtMiB0ZXh0LWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BpbmxpbmUtYmxvY2sgcHgtMS41IHB5LTAuNSByb3VuZGVkIHRleHQtWzlweF0gZm9udC1ib2xkIHVwcGVyY2FzZSAke1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBpc0F0aW5naWRhXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPyBcImJnLXNsYXRlLTIwMCB0ZXh0LXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTQwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgOiBcImJnLXNsYXRlLTEwMCB0ZXh0LXNsYXRlLTgwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTMwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICB9YH1cclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7c3RhdHVzIHx8IChpc0F0aW5naWRhID8gXCJBdGluZ2lkYVwiIDogXCJFbSBBbmRhbWVudG9cIil9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L3RkPlxyXG4gICAgICAgICAgICAgICAgPC90cj5cclxuICAgICAgICAgICAgICApO1xyXG4gICAgICAgICAgICB9KX1cclxuICAgICAgICAgIDwvdGJvZHk+XHJcbiAgICAgICAgPC90YWJsZT5cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICB7LyogTm90YSBNZXRvZG9sw7NnaWNhIGUgQmFzZSBMZWdhbCAqL31cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi04IHAtMyBib3JkZXIgYm9yZGVyLXNsYXRlLTMwMCByb3VuZGVkLXhzIHRleHQtWzEwcHhdIHRleHQtc2xhdGUtNjAwIGxlYWRpbmctcmVsYXhlZFwiPlxyXG4gICAgICAgIDxzdHJvbmc+Tm90YSBUw6ljbmljYSBMZWdhbDo8L3N0cm9uZz4gSW5kaWNhZG9yZXMgY2FsY3VsYWRvcyBlbSBjb25mb3JtaWRhZGUgY29tIGFzIGRpcmV0cml6ZXMgZGFcclxuICAgICAgICBSZXNvbHXDp8OjbyBTRVMvTUcgbsK6IDcuNzMwLzIwMjEsIEluc3RydcOnw6NvIE5vcm1hdGl2YSBBTlZJU0EgbsK6IDY2LzIwMjAgZSBMZWkgRmVkZXJhbCBuwrogOC4wODAvMTk5MC5cclxuICAgICAgICBPIEluZGljYWRvciAxMSBhZmVyZSBhIHZpZ2lsw6JuY2lhIGF0aXZhIGVtIGFtYmllbnRlcyBkZSB0cmFiYWxobyAoVkFQVCkgdmlzYW5kbyBhIHByZXZlbsOnw6NvIGRlIGFjaWRlbnRlcyBlIGFncmF2b3NcclxuICAgICAgICBvY3VwYWNpb25haXMuIE9zIEluZGljYWRvcmVzIDEyIGEgMTUgY29uc29saWRhbSBhIGNvYmVydHVyYSBwcm9wb3JjaW9uYWwgcG9yIGdyYXUgZGUgcmlzY28gc2FuaXTDoXJpbyBhdHJpYnXDrWRvIHBlbG8gQ05BRS5cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICB7LyogQ2FtcG8gRm9ybWFsIGRlIEVuY2VycmFtZW50bywgQXNzaW5hdHVyYSBlIENhcmltYm8gKi99XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMTIgcHQtNiBib3JkZXItdCBib3JkZXItc2xhdGUtNDAwIGJyZWFrLWluc2lkZS1hdm9pZFwiPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1yaWdodCB0ZXh0LXhzIHRleHQtc2xhdGUtNzAwIG1iLTEyXCI+XHJcbiAgICAgICAgICB7QVBQX0NPTkZJRy5tdW5pY2lwaW99IC0ge0FQUF9DT05GSUcudWZ9LCB7bmV3IERhdGUoKS50b0xvY2FsZURhdGVTdHJpbmcoXCJwdC1CUlwiLCB7XHJcbiAgICAgICAgICAgIGRheTogXCIyLWRpZ2l0XCIsXHJcbiAgICAgICAgICAgIG1vbnRoOiBcImxvbmdcIixcclxuICAgICAgICAgICAgeWVhcjogXCJudW1lcmljXCIsXHJcbiAgICAgICAgICB9KX0uXHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMiBnYXAtMTIgdGV4dC1jZW50ZXIgdGV4dC14c1wiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGl0ZW1zLWNlbnRlclwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctNTYgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTkwMCBtYi0xLjVcIiAvPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXNsYXRlLTkwMCB1cHBlcmNhc2VcIj5cclxuICAgICAgICAgICAgICB7bm9tZUNvb3JkZW5hZG9yfVxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LXNsYXRlLTYwMFwiPlxyXG4gICAgICAgICAgICAgIHtBUFBfQ09ORklHLm9yZ2FvfVxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSBmb250LW1vbm8gdGV4dC1zbGF0ZS01MDBcIj5cclxuICAgICAgICAgICAgICBNYXRyw61jdWxhOiB7bWF0cmljdWxhQ29vcmRlbmFkb3J9XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGl0ZW1zLWNlbnRlclwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctNTYgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTkwMCBtYi0xLjVcIiAvPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXNsYXRlLTkwMCB1cHBlcmNhc2VcIj5cclxuICAgICAgICAgICAgICB7QVBQX0NPTkZJRy5zZWNyZXRhcmlhfVxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LXNsYXRlLTYwMFwiPlxyXG4gICAgICAgICAgICAgIEdlc3RvciBNdW5pY2lwYWwgZG8gU1VTXHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIGZvbnQtbW9ubyB0ZXh0LXNsYXRlLTUwMFwiPlxyXG4gICAgICAgICAgICAgIHtBUFBfQ09ORklHLnByZWZlaXR1cmF9XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IFJlbGF0b3Jpb1N1c0ltcHJlc3Nhb1ZpZXc7XHJcbiJdfQ==