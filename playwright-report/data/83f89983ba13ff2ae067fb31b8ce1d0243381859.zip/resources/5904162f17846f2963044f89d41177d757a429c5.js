import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/fiscalizacao/UploadEvidencias.tsx");const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"]; const useRef = __vite__cjsImport0_react["useRef"];const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];/**
* Componente de Gestão e Upload de Evidências Fotográficas da Fiscalização
* Permite capturar ou anexar fotos da vistoria em campo, adicionar legendas
* e montar o relatório fotográfico para o laudo pericial.
*/
import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=0fd2848a";
import { Camera, Image as ImageIcon, Plus, Trash2, X } from "/node_modules/.vite/deps/lucide-react.js?v=0fd2848a";
var _jsxFileName = "E:/Projetos VSCODE/visa_braunas/src/components/fiscalizacao/UploadEvidencias.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=0fd2848a";
var _s = $RefreshSig$();
export const UploadEvidencias = ({ value = [], onChange, readOnly = false }) => {
	_s();
	const [modalAberta, setModalAberta] = useState(false);
	const [novaUrl, setNovaUrl] = useState("");
	const [novaLegenda, setNovaLegenda] = useState("");
	const [visualizandoFoto, setVisualizandoFoto] = useState(null);
	const fileInputRef = useRef(null);
	const handleRemoverFoto = (id) => {
		if (readOnly) return;
		onChange(value.filter((foto) => foto.id !== id));
	};
	const handleAtualizarLegenda = (id, legenda) => {
		if (readOnly) return;
		onChange(value.map((foto) => foto.id === id ? {
			...foto,
			legenda
		} : foto));
	};
	const handleAdicionarPorUrl = (e) => {
		e.preventDefault();
		if (!novaUrl.trim()) return;
		const novaFoto = {
			id: `foto_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
			url: novaUrl.trim(),
			legenda: novaLegenda.trim() || "Registro fotográfico da vistoria",
			data_registro: new Date().toISOString()
		};
		onChange([...value, novaFoto]);
		setNovaUrl("");
		setNovaLegenda("");
		setModalAberta(false);
	};
	const handleArquivoSelecionado = (e) => {
		const file = e.target.files?.[0];
		if (!file) return;
		// Converte arquivo para Data URL (Base64) para visualização imediata offline
		const reader = new FileReader();
		reader.onload = (event) => {
			const dataUrl = event.target?.result;
			if (dataUrl) {
				const novaFoto = {
					id: `foto_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
					url: dataUrl,
					legenda: file.name.replace(/\.[^/.]+$/, ""),
					data_registro: new Date().toISOString()
				};
				onChange([...value, novaFoto]);
			}
		};
		reader.readAsDataURL(file);
		// Reseta o input para permitir selecionar o mesmo arquivo novamente
		if (fileInputRef.current) {
			fileInputRef.current.value = "";
		}
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex items-center justify-between",
				children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
					className: "text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider block",
					children: "Relatório Fotográfico de Evidências"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 87,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("p", {
					className: "text-[11px] text-slate-500 dark:text-slate-400",
					children: "Anexe registros visuais de irregularidades, equipamentos, instalações ou adequações sanitárias."
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 90,
					columnNumber: 11
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 86,
					columnNumber: 9
				}, this), !readOnly && /* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-2",
					children: [
						/* @__PURE__ */ _jsxDEV("input", {
							type: "file",
							ref: fileInputRef,
							accept: "image/*",
							className: "hidden",
							onChange: handleArquivoSelecionado
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 97,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							onClick: () => fileInputRef.current?.click(),
							className: "px-3 py-1.5 text-xs font-semibold text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-700/60 shadow-2xs flex items-center gap-1.5 transition-colors",
							children: [/* @__PURE__ */ _jsxDEV(Camera, { className: "w-3.5 h-3.5 text-teal-600 dark:text-teal-400" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 109,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Anexar Imagem" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 110,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 104,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							onClick: () => setModalAberta(true),
							className: "px-3 py-1.5 text-xs font-semibold text-teal-700 dark:text-teal-300 bg-teal-50 dark:bg-teal-950/40 border border-teal-200 dark:border-teal-800/80 rounded-lg hover:bg-teal-100/60 shadow-2xs flex items-center gap-1.5 transition-colors",
							children: [/* @__PURE__ */ _jsxDEV(Plus, { className: "w-3.5 h-3.5" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 118,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Adicionar por URL" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 119,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 113,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 96,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 85,
				columnNumber: 7
			}, this),
			value.length === 0 ? /* @__PURE__ */ _jsxDEV("div", {
				className: "border border-dashed border-slate-300 dark:border-slate-800 rounded-xl p-8 text-center bg-slate-50/50 dark:bg-slate-900/30",
				children: [
					/* @__PURE__ */ _jsxDEV(ImageIcon, { className: "w-8 h-8 text-slate-400 mx-auto mb-2" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 128,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("p", {
						className: "text-xs font-medium text-slate-600 dark:text-slate-400",
						children: "Nenhuma evidência fotográfica anexada a este laudo sanitário."
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 129,
						columnNumber: 11
					}, this),
					!readOnly && /* @__PURE__ */ _jsxDEV("p", {
						className: "text-[11px] text-slate-400 mt-1",
						children: "Clique em \"Anexar Imagem\" ou \"Adicionar por URL\" para registrar comprovações visuais."
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 133,
						columnNumber: 13
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 127,
				columnNumber: 9
			}, this) : /* @__PURE__ */ _jsxDEV("div", {
				className: "grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4",
				children: value.map((foto, index) => /* @__PURE__ */ _jsxDEV("div", {
					className: "group border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden bg-white dark:bg-slate-900 shadow-2xs hover:shadow-xs transition-shadow flex flex-col",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "relative aspect-video bg-slate-100 dark:bg-slate-800 cursor-pointer overflow-hidden",
						onClick: () => setVisualizandoFoto(foto),
						children: [
							/* @__PURE__ */ _jsxDEV("img", {
								src: foto.url,
								alt: foto.legenda,
								className: "w-full h-full object-cover group-hover:scale-105 transition-transform duration-200",
								onError: (e) => {
									// Fallback para URL quebrada
									e.target.src = "https://images.unsplash.com/photo-1584727638096-042c45049ebe?w=600&auto=format&fit=crop&q=60";
								}
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 149,
								columnNumber: 17
							}, this),
							!readOnly && /* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								onClick: (e) => {
									e.stopPropagation();
									handleRemoverFoto(foto.id);
								},
								className: "absolute top-2 right-2 p-1.5 bg-rose-600/90 text-white rounded-md hover:bg-rose-700 transition-colors shadow-xs",
								title: "Remover foto",
								children: /* @__PURE__ */ _jsxDEV(Trash2, { className: "w-3.5 h-3.5" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 169,
									columnNumber: 21
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 160,
								columnNumber: 19
							}, this),
							/* @__PURE__ */ _jsxDEV("span", {
								className: "absolute bottom-1 left-2 text-[10px] font-medium text-white/90 bg-black/50 px-1.5 py-0.5 rounded backdrop-blur-xs",
								children: ["Foto ", index + 1]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 172,
								columnNumber: 17
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 145,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "p-2.5 flex-1 flex flex-col justify-between gap-1.5 bg-slate-50/50 dark:bg-slate-800/30",
						children: [readOnly ? /* @__PURE__ */ _jsxDEV("p", {
							className: "text-xs text-slate-700 dark:text-slate-300 font-medium line-clamp-2",
							children: foto.legenda || "Sem legenda"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 179,
							columnNumber: 19
						}, this) : /* @__PURE__ */ _jsxDEV("input", {
							type: "text",
							value: foto.legenda,
							onChange: (e) => handleAtualizarLegenda(foto.id, e.target.value),
							placeholder: "Legenda da irregularidade / item...",
							className: "w-full px-2 py-1 text-xs bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-1 focus:ring-teal-500"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 183,
							columnNumber: 19
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							className: "text-[10px] text-slate-400",
							children: new Date(foto.data_registro).toLocaleDateString("pt-BR", {
								day: "2-digit",
								month: "2-digit",
								year: "numeric",
								hour: "2-digit",
								minute: "2-digit"
							})
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 191,
							columnNumber: 17
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 177,
						columnNumber: 15
					}, this)]
				}, foto.id || index, true, {
					fileName: _jsxFileName,
					lineNumber: 141,
					columnNumber: 13
				}, this))
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 139,
				columnNumber: 9
			}, this),
			modalAberta && /* @__PURE__ */ _jsxDEV("div", {
				className: "fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-xs",
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 w-full max-w-md shadow-xl space-y-4",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3",
						children: [/* @__PURE__ */ _jsxDEV("h3", {
							className: "text-sm font-bold text-slate-900 dark:text-white",
							children: "Adicionar Evidência Fotográfica por URL"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 211,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							onClick: () => setModalAberta(false),
							className: "text-slate-400 hover:text-slate-600 dark:hover:text-slate-300",
							children: /* @__PURE__ */ _jsxDEV(X, { className: "w-4 h-4" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 219,
								columnNumber: 17
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 214,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 210,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("form", {
						onSubmit: handleAdicionarPorUrl,
						className: "space-y-3",
						children: [
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1",
								children: ["URL da Imagem ", /* @__PURE__ */ _jsxDEV("span", {
									className: "text-rose-500",
									children: "*"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 226,
									columnNumber: 33
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 225,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								type: "url",
								required: true,
								placeholder: "https://exemplo.com/fotos/evidencia-01.jpg",
								value: novaUrl,
								onChange: (e) => setNovaUrl(e.target.value),
								className: "w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-teal-500"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 228,
								columnNumber: 17
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 224,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1",
								children: "Legenda / Descrição da Irregularidade"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 239,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								type: "text",
								placeholder: "Ex: Ausência de telas milimétricas na manipulação de alimentos",
								value: novaLegenda,
								onChange: (e) => setNovaLegenda(e.target.value),
								className: "w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-teal-500"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 242,
								columnNumber: 17
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 238,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center justify-end gap-2 pt-2 border-t border-slate-100 dark:border-slate-800",
								children: [/* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => setModalAberta(false),
									className: "px-3 py-1.5 text-xs font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg",
									children: "Cancelar"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 252,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("button", {
									type: "submit",
									className: "px-4 py-1.5 text-xs font-bold text-white bg-teal-600 hover:bg-teal-700 rounded-lg shadow-xs",
									children: "Confirmar Adição"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 259,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 251,
								columnNumber: 15
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 223,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 209,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 208,
				columnNumber: 9
			}, this),
			visualizandoFoto && /* @__PURE__ */ _jsxDEV("div", {
				className: "fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs cursor-pointer",
				onClick: () => setVisualizandoFoto(null),
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: "relative max-w-3xl max-h-[90vh] bg-slate-900 rounded-xl overflow-hidden shadow-2xl p-2",
					onClick: (e) => e.stopPropagation(),
					children: [
						/* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							onClick: () => setVisualizandoFoto(null),
							className: "absolute top-4 right-4 z-10 p-2 bg-black/60 hover:bg-black text-white rounded-full transition-colors",
							children: /* @__PURE__ */ _jsxDEV(X, { className: "w-5 h-5" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 286,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 281,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("img", {
							src: visualizandoFoto.url,
							alt: visualizandoFoto.legenda,
							className: "max-h-[80vh] w-auto mx-auto object-contain rounded-lg"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 288,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "p-3 text-center",
							children: [/* @__PURE__ */ _jsxDEV("p", {
								className: "text-xs font-semibold text-white",
								children: visualizandoFoto.legenda || "Evidência Fotográfica"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 294,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "text-[10px] text-slate-400",
								children: new Date(visualizandoFoto.data_registro).toLocaleString("pt-BR")
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 297,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 293,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 277,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 273,
				columnNumber: 9
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 84,
		columnNumber: 5
	}, this);
};
_s(UploadEvidencias, "7oe9MRAeCJw639SlJufatuMWTlw=");
_c = UploadEvidencias;
export default UploadEvidencias;
var _c;
$RefreshReg$(_c, "UploadEvidencias");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/fiscalizacao/UploadEvidencias.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("E:/Projetos VSCODE/visa_braunas/src/components/fiscalizacao/UploadEvidencias.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("E:/Projetos VSCODE/visa_braunas/src/components/fiscalizacao/UploadEvidencias.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "E:/Projetos VSCODE/visa_braunas/src/components/fiscalizacao/UploadEvidencias.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7Ozs7QUFNQSxPQUFPLFNBQVMsVUFBVSxjQUFjO0FBQ3hDLFNBQVMsUUFBUSxTQUFTLFdBQVcsTUFBTSxRQUFRLFNBQVM7Ozs7QUFTNUQsT0FBTyxNQUFNLG9CQUFxRCxFQUNoRSxRQUFRLENBQUMsR0FDVCxVQUNBLFdBQVcsWUFDUDs7Q0FDSixNQUFNLENBQUMsYUFBYSxrQkFBa0IsU0FBUyxLQUFLO0NBQ3BELE1BQU0sQ0FBQyxTQUFTLGNBQWMsU0FBUyxFQUFFO0NBQ3pDLE1BQU0sQ0FBQyxhQUFhLGtCQUFrQixTQUFTLEVBQUU7Q0FDakQsTUFBTSxDQUFDLGtCQUFrQix1QkFBdUIsU0FBK0IsSUFBSTtDQUNuRixNQUFNLGVBQWUsT0FBeUIsSUFBSTtDQUVsRCxNQUFNLHFCQUFxQixPQUFlO0VBQ3hDLElBQUksVUFBVTtFQUNkLFNBQVMsTUFBTSxRQUFRLFNBQVMsS0FBSyxPQUFPLEVBQUUsQ0FBQztDQUNqRDtDQUVBLE1BQU0sMEJBQTBCLElBQVksWUFBb0I7RUFDOUQsSUFBSSxVQUFVO0VBQ2QsU0FDRSxNQUFNLEtBQUssU0FBVSxLQUFLLE9BQU8sS0FBSztHQUFFLEdBQUc7R0FBTTtFQUFRLElBQUksSUFBSyxDQUNwRTtDQUNGO0NBRUEsTUFBTSx5QkFBeUIsTUFBdUI7RUFDcEQsRUFBRSxlQUFlO0VBQ2pCLElBQUksQ0FBQyxRQUFRLEtBQUssR0FBRztFQUVyQixNQUFNLFdBQTBCO0dBQzlCLElBQUksUUFBUSxLQUFLLElBQUksRUFBRSxHQUFHLEtBQUssT0FBTyxDQUFDLENBQUMsU0FBUyxFQUFFLENBQUMsQ0FBQyxVQUFVLEdBQUcsQ0FBQztHQUNuRSxLQUFLLFFBQVEsS0FBSztHQUNsQixTQUFTLFlBQVksS0FBSyxLQUFLO0dBQy9CLGVBQWUsSUFBSSxLQUFLLENBQUMsQ0FBQyxZQUFZO0VBQ3hDO0VBRUEsU0FBUyxDQUFDLEdBQUcsT0FBTyxRQUFRLENBQUM7RUFDN0IsV0FBVyxFQUFFO0VBQ2IsZUFBZSxFQUFFO0VBQ2pCLGVBQWUsS0FBSztDQUN0QjtDQUVBLE1BQU0sNEJBQTRCLE1BQTJDO0VBQzNFLE1BQU0sT0FBTyxFQUFFLE9BQU8sUUFBUTtFQUM5QixJQUFJLENBQUMsTUFBTTs7RUFHWCxNQUFNLFNBQVMsSUFBSSxXQUFXO0VBQzlCLE9BQU8sVUFBVSxVQUFVO0dBQ3pCLE1BQU0sVUFBVSxNQUFNLFFBQVE7R0FDOUIsSUFBSSxTQUFTO0lBQ1gsTUFBTSxXQUEwQjtLQUM5QixJQUFJLFFBQVEsS0FBSyxJQUFJLEVBQUUsR0FBRyxLQUFLLE9BQU8sQ0FBQyxDQUFDLFNBQVMsRUFBRSxDQUFDLENBQUMsVUFBVSxHQUFHLENBQUM7S0FDbkUsS0FBSztLQUNMLFNBQVMsS0FBSyxLQUFLLFFBQVEsYUFBYSxFQUFFO0tBQzFDLGVBQWUsSUFBSSxLQUFLLENBQUMsQ0FBQyxZQUFZO0lBQ3hDO0lBQ0EsU0FBUyxDQUFDLEdBQUcsT0FBTyxRQUFRLENBQUM7R0FDL0I7RUFDRjtFQUNBLE9BQU8sY0FBYyxJQUFJOztFQUd6QixJQUFJLGFBQWEsU0FBUztHQUN4QixhQUFhLFFBQVEsUUFBUTtFQUMvQjtDQUNGO0NBRUEsT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUFmO0dBQ0Usd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxRQUFEO0tBQU0sV0FBVTtlQUFrRjtJQUU1Rjs7OztjQUNOLHdCQUFDLEtBQUQ7S0FBRyxXQUFVO2VBQWlEO0lBRTNEOzs7O1lBQ0E7Ozs7Y0FFSixDQUFDLFlBQ0Esd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZjtNQUNFLHdCQUFDLFNBQUQ7T0FDRSxNQUFLO09BQ0wsS0FBSztPQUNMLFFBQU87T0FDUCxXQUFVO09BQ1YsVUFBVTtNQUNYOzs7OztNQUNELHdCQUFDLFVBQUQ7T0FDRSxNQUFLO09BQ0wsZUFBZSxhQUFhLFNBQVMsTUFBTTtPQUMzQyxXQUFVO2lCQUhaLENBS0Usd0JBQUMsUUFBRCxFQUFRLFdBQVUsK0NBQWdEOzs7O2lCQUNsRSx3QkFBQyxRQUFELFlBQU0sZ0JBQW1COzs7O2VBQ25COzs7Ozs7TUFFUix3QkFBQyxVQUFEO09BQ0UsTUFBSztPQUNMLGVBQWUsZUFBZSxJQUFJO09BQ2xDLFdBQVU7aUJBSFosQ0FLRSx3QkFBQyxNQUFELEVBQU0sV0FBVSxjQUFlOzs7O2lCQUMvQix3QkFBQyxRQUFELFlBQU0sb0JBQXVCOzs7O2VBQ3ZCOzs7Ozs7S0FDTDs7Ozs7WUFFSjs7Ozs7O0dBR0osTUFBTSxXQUFXLElBQ2hCLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWY7S0FDRSx3QkFBQyxXQUFELEVBQVcsV0FBVSxzQ0FBdUM7Ozs7O0tBQzVELHdCQUFDLEtBQUQ7TUFBRyxXQUFVO2dCQUF5RDtLQUVuRTs7Ozs7S0FDRixDQUFDLFlBQ0Esd0JBQUMsS0FBRDtNQUFHLFdBQVU7Z0JBQWtDO0tBRTVDOzs7OztJQUVGOzs7OztjQUVMLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQ1osTUFBTSxLQUFLLE1BQU0sVUFDaEIsd0JBQUMsT0FBRDtLQUVFLFdBQVU7ZUFGWixDQUlFLHdCQUFDLE9BQUQ7TUFDRSxXQUFVO01BQ1YsZUFBZSxvQkFBb0IsSUFBSTtnQkFGekM7T0FJRSx3QkFBQyxPQUFEO1FBQ0UsS0FBSyxLQUFLO1FBQ1YsS0FBSyxLQUFLO1FBQ1YsV0FBVTtRQUNWLFVBQVUsTUFBTTs7U0FFZCxBQUFDLEVBQUUsT0FBNEIsTUFDN0I7UUFDSjtPQUNEOzs7OztPQUNBLENBQUMsWUFDQSx3QkFBQyxVQUFEO1FBQ0UsTUFBSztRQUNMLFVBQVUsTUFBTTtTQUNkLEVBQUUsZ0JBQWdCO1NBQ2xCLGtCQUFrQixLQUFLLEVBQUU7UUFDM0I7UUFDQSxXQUFVO1FBQ1YsT0FBTTtrQkFFTix3QkFBQyxRQUFELEVBQVEsV0FBVSxjQUFlOzs7OztPQUMzQjs7Ozs7T0FFVix3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBaEIsQ0FBb0ksU0FDNUgsUUFBUSxDQUNWOzs7Ozs7TUFDSDs7Ozs7ZUFFTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNHLFdBQ0Msd0JBQUMsS0FBRDtPQUFHLFdBQVU7aUJBQ1YsS0FBSyxXQUFXO01BQ2hCOzs7O2lCQUVILHdCQUFDLFNBQUQ7T0FDRSxNQUFLO09BQ0wsT0FBTyxLQUFLO09BQ1osV0FBVyxNQUFNLHVCQUF1QixLQUFLLElBQUksRUFBRSxPQUFPLEtBQUs7T0FDL0QsYUFBWTtPQUNaLFdBQVU7TUFDWDs7OztnQkFFSCx3QkFBQyxRQUFEO09BQU0sV0FBVTtpQkFDYixJQUFJLEtBQUssS0FBSyxhQUFhLENBQUMsQ0FBQyxtQkFBbUIsU0FBUztRQUN4RCxLQUFLO1FBQ0wsT0FBTztRQUNQLE1BQU07UUFDTixNQUFNO1FBQ04sUUFBUTtPQUNWLENBQUM7TUFDRzs7OztjQUNIOzs7OzthQUNGO09BM0RFLEtBQUssTUFBTTs7OztXQTJEYixDQUNOO0dBQ0U7Ozs7O0dBSU4sZUFDQyx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUNiLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLE1BQUQ7T0FBSSxXQUFVO2lCQUFtRDtNQUU3RDs7OztnQkFDSix3QkFBQyxVQUFEO09BQ0UsTUFBSztPQUNMLGVBQWUsZUFBZSxLQUFLO09BQ25DLFdBQVU7aUJBRVYsd0JBQUMsR0FBRCxFQUFHLFdBQVUsVUFBVzs7Ozs7TUFDbEI7Ozs7Y0FDTDs7Ozs7ZUFFTCx3QkFBQyxRQUFEO01BQU0sVUFBVTtNQUF1QixXQUFVO2dCQUFqRDtPQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO1FBQU8sV0FBVTtrQkFBakIsQ0FBdUYsa0JBQ3ZFLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUFnQjtRQUFPOzs7O2dCQUNoRDs7Ozs7aUJBQ1Asd0JBQUMsU0FBRDtRQUNFLE1BQUs7UUFDTDtRQUNBLGFBQVk7UUFDWixPQUFPO1FBQ1AsV0FBVyxNQUFNLFdBQVcsRUFBRSxPQUFPLEtBQUs7UUFDMUMsV0FBVTtPQUNYOzs7O2VBQ0U7Ozs7O09BRUwsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7UUFBTyxXQUFVO2tCQUFzRTtPQUVoRjs7OztpQkFDUCx3QkFBQyxTQUFEO1FBQ0UsTUFBSztRQUNMLGFBQVk7UUFDWixPQUFPO1FBQ1AsV0FBVyxNQUFNLGVBQWUsRUFBRSxPQUFPLEtBQUs7UUFDOUMsV0FBVTtPQUNYOzs7O2VBQ0U7Ozs7O09BRUwsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxVQUFEO1NBQ0UsTUFBSztTQUNMLGVBQWUsZUFBZSxLQUFLO1NBQ25DLFdBQVU7bUJBQ1g7UUFFTzs7OztrQkFDUix3QkFBQyxVQUFEO1NBQ0UsTUFBSztTQUNMLFdBQVU7bUJBQ1g7UUFFTzs7OztnQkFDTDs7Ozs7O01BQ0Q7Ozs7O2FBQ0g7Ozs7OztHQUNGOzs7OztHQUlOLG9CQUNDLHdCQUFDLE9BQUQ7SUFDRSxXQUFVO0lBQ1YsZUFBZSxvQkFBb0IsSUFBSTtjQUV2Qyx3QkFBQyxPQUFEO0tBQ0UsV0FBVTtLQUNWLFVBQVUsTUFBTSxFQUFFLGdCQUFnQjtlQUZwQztNQUlFLHdCQUFDLFVBQUQ7T0FDRSxNQUFLO09BQ0wsZUFBZSxvQkFBb0IsSUFBSTtPQUN2QyxXQUFVO2lCQUVWLHdCQUFDLEdBQUQsRUFBRyxXQUFVLFVBQVc7Ozs7O01BQ2xCOzs7OztNQUNSLHdCQUFDLE9BQUQ7T0FDRSxLQUFLLGlCQUFpQjtPQUN0QixLQUFLLGlCQUFpQjtPQUN0QixXQUFVO01BQ1g7Ozs7O01BQ0Qsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxLQUFEO1FBQUcsV0FBVTtrQkFDVixpQkFBaUIsV0FBVztPQUM1Qjs7OztpQkFDSCx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFDYixJQUFJLEtBQUssaUJBQWlCLGFBQWEsQ0FBQyxDQUFDLGVBQWUsT0FBTztPQUM1RDs7OztlQUNIOzs7Ozs7S0FDRjs7Ozs7O0dBQ0Y7Ozs7O0VBRUo7Ozs7OztBQUVUOzs7QUFFQSxlQUFlIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIlVwbG9hZEV2aWRlbmNpYXMudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbIi8qKlxyXG4gKiBDb21wb25lbnRlIGRlIEdlc3TDo28gZSBVcGxvYWQgZGUgRXZpZMOqbmNpYXMgRm90b2dyw6FmaWNhcyBkYSBGaXNjYWxpemHDp8Ojb1xyXG4gKiBQZXJtaXRlIGNhcHR1cmFyIG91IGFuZXhhciBmb3RvcyBkYSB2aXN0b3JpYSBlbSBjYW1wbywgYWRpY2lvbmFyIGxlZ2VuZGFzXHJcbiAqIGUgbW9udGFyIG8gcmVsYXTDs3JpbyBmb3RvZ3LDoWZpY28gcGFyYSBvIGxhdWRvIHBlcmljaWFsLlxyXG4gKi9cclxuXHJcbmltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSwgdXNlUmVmIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7IENhbWVyYSwgSW1hZ2UgYXMgSW1hZ2VJY29uLCBQbHVzLCBUcmFzaDIsIFggfSBmcm9tIFwibHVjaWRlLXJlYWN0XCI7XHJcbmltcG9ydCB7IEZvdG9FdmlkZW5jaWEgfSBmcm9tIFwiLi4vLi4vdHlwZXMvZmlzY2FsaXphY2FvXCI7XHJcblxyXG5pbnRlcmZhY2UgVXBsb2FkRXZpZGVuY2lhc1Byb3BzIHtcclxuICB2YWx1ZTogRm90b0V2aWRlbmNpYVtdO1xyXG4gIG9uQ2hhbmdlOiAoZm90b3M6IEZvdG9FdmlkZW5jaWFbXSkgPT4gdm9pZDtcclxuICByZWFkT25seT86IGJvb2xlYW47XHJcbn1cclxuXHJcbmV4cG9ydCBjb25zdCBVcGxvYWRFdmlkZW5jaWFzOiBSZWFjdC5GQzxVcGxvYWRFdmlkZW5jaWFzUHJvcHM+ID0gKHtcclxuICB2YWx1ZSA9IFtdLFxyXG4gIG9uQ2hhbmdlLFxyXG4gIHJlYWRPbmx5ID0gZmFsc2UsXHJcbn0pID0+IHtcclxuICBjb25zdCBbbW9kYWxBYmVydGEsIHNldE1vZGFsQWJlcnRhXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbbm92YVVybCwgc2V0Tm92YVVybF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbbm92YUxlZ2VuZGEsIHNldE5vdmFMZWdlbmRhXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFt2aXN1YWxpemFuZG9Gb3RvLCBzZXRWaXN1YWxpemFuZG9Gb3RvXSA9IHVzZVN0YXRlPEZvdG9FdmlkZW5jaWEgfCBudWxsPihudWxsKTtcclxuICBjb25zdCBmaWxlSW5wdXRSZWYgPSB1c2VSZWY8SFRNTElucHV0RWxlbWVudD4obnVsbCk7XHJcblxyXG4gIGNvbnN0IGhhbmRsZVJlbW92ZXJGb3RvID0gKGlkOiBzdHJpbmcpID0+IHtcclxuICAgIGlmIChyZWFkT25seSkgcmV0dXJuO1xyXG4gICAgb25DaGFuZ2UodmFsdWUuZmlsdGVyKChmb3RvKSA9PiBmb3RvLmlkICE9PSBpZCkpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZUF0dWFsaXphckxlZ2VuZGEgPSAoaWQ6IHN0cmluZywgbGVnZW5kYTogc3RyaW5nKSA9PiB7XHJcbiAgICBpZiAocmVhZE9ubHkpIHJldHVybjtcclxuICAgIG9uQ2hhbmdlKFxyXG4gICAgICB2YWx1ZS5tYXAoKGZvdG8pID0+IChmb3RvLmlkID09PSBpZCA/IHsgLi4uZm90bywgbGVnZW5kYSB9IDogZm90bykpXHJcbiAgICApO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZUFkaWNpb25hclBvclVybCA9IChlOiBSZWFjdC5Gb3JtRXZlbnQpID0+IHtcclxuICAgIGUucHJldmVudERlZmF1bHQoKTtcclxuICAgIGlmICghbm92YVVybC50cmltKCkpIHJldHVybjtcclxuXHJcbiAgICBjb25zdCBub3ZhRm90bzogRm90b0V2aWRlbmNpYSA9IHtcclxuICAgICAgaWQ6IGBmb3RvXyR7RGF0ZS5ub3coKX1fJHtNYXRoLnJhbmRvbSgpLnRvU3RyaW5nKDM2KS5zdWJzdHJpbmcoMiwgNyl9YCxcclxuICAgICAgdXJsOiBub3ZhVXJsLnRyaW0oKSxcclxuICAgICAgbGVnZW5kYTogbm92YUxlZ2VuZGEudHJpbSgpIHx8IFwiUmVnaXN0cm8gZm90b2dyw6FmaWNvIGRhIHZpc3RvcmlhXCIsXHJcbiAgICAgIGRhdGFfcmVnaXN0cm86IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcclxuICAgIH07XHJcblxyXG4gICAgb25DaGFuZ2UoWy4uLnZhbHVlLCBub3ZhRm90b10pO1xyXG4gICAgc2V0Tm92YVVybChcIlwiKTtcclxuICAgIHNldE5vdmFMZWdlbmRhKFwiXCIpO1xyXG4gICAgc2V0TW9kYWxBYmVydGEoZmFsc2UpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZUFycXVpdm9TZWxlY2lvbmFkbyA9IChlOiBSZWFjdC5DaGFuZ2VFdmVudDxIVE1MSW5wdXRFbGVtZW50PikgPT4ge1xyXG4gICAgY29uc3QgZmlsZSA9IGUudGFyZ2V0LmZpbGVzPy5bMF07XHJcbiAgICBpZiAoIWZpbGUpIHJldHVybjtcclxuXHJcbiAgICAvLyBDb252ZXJ0ZSBhcnF1aXZvIHBhcmEgRGF0YSBVUkwgKEJhc2U2NCkgcGFyYSB2aXN1YWxpemHDp8OjbyBpbWVkaWF0YSBvZmZsaW5lXHJcbiAgICBjb25zdCByZWFkZXIgPSBuZXcgRmlsZVJlYWRlcigpO1xyXG4gICAgcmVhZGVyLm9ubG9hZCA9IChldmVudCkgPT4ge1xyXG4gICAgICBjb25zdCBkYXRhVXJsID0gZXZlbnQudGFyZ2V0Py5yZXN1bHQgYXMgc3RyaW5nO1xyXG4gICAgICBpZiAoZGF0YVVybCkge1xyXG4gICAgICAgIGNvbnN0IG5vdmFGb3RvOiBGb3RvRXZpZGVuY2lhID0ge1xyXG4gICAgICAgICAgaWQ6IGBmb3RvXyR7RGF0ZS5ub3coKX1fJHtNYXRoLnJhbmRvbSgpLnRvU3RyaW5nKDM2KS5zdWJzdHJpbmcoMiwgNyl9YCxcclxuICAgICAgICAgIHVybDogZGF0YVVybCxcclxuICAgICAgICAgIGxlZ2VuZGE6IGZpbGUubmFtZS5yZXBsYWNlKC9cXC5bXi8uXSskLywgXCJcIiksXHJcbiAgICAgICAgICBkYXRhX3JlZ2lzdHJvOiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXHJcbiAgICAgICAgfTtcclxuICAgICAgICBvbkNoYW5nZShbLi4udmFsdWUsIG5vdmFGb3RvXSk7XHJcbiAgICAgIH1cclxuICAgIH07XHJcbiAgICByZWFkZXIucmVhZEFzRGF0YVVSTChmaWxlKTtcclxuXHJcbiAgICAvLyBSZXNldGEgbyBpbnB1dCBwYXJhIHBlcm1pdGlyIHNlbGVjaW9uYXIgbyBtZXNtbyBhcnF1aXZvIG5vdmFtZW50ZVxyXG4gICAgaWYgKGZpbGVJbnB1dFJlZi5jdXJyZW50KSB7XHJcbiAgICAgIGZpbGVJbnB1dFJlZi5jdXJyZW50LnZhbHVlID0gXCJcIjtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTRcIj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cclxuICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciBibG9ja1wiPlxyXG4gICAgICAgICAgICBSZWxhdMOzcmlvIEZvdG9ncsOhZmljbyBkZSBFdmlkw6puY2lhc1xyXG4gICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1zbGF0ZS01MDAgZGFyazp0ZXh0LXNsYXRlLTQwMFwiPlxyXG4gICAgICAgICAgICBBbmV4ZSByZWdpc3Ryb3MgdmlzdWFpcyBkZSBpcnJlZ3VsYXJpZGFkZXMsIGVxdWlwYW1lbnRvcywgaW5zdGFsYcOnw7VlcyBvdSBhZGVxdWHDp8O1ZXMgc2FuaXTDoXJpYXMuXHJcbiAgICAgICAgICA8L3A+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIHshcmVhZE9ubHkgJiYgKFxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICB0eXBlPVwiZmlsZVwiXHJcbiAgICAgICAgICAgICAgcmVmPXtmaWxlSW5wdXRSZWZ9XHJcbiAgICAgICAgICAgICAgYWNjZXB0PVwiaW1hZ2UvKlwiXHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaGlkZGVuXCJcclxuICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQXJxdWl2b1NlbGVjaW9uYWRvfVxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gZmlsZUlucHV0UmVmLmN1cnJlbnQ/LmNsaWNrKCl9XHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtMyBweS0xLjUgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0yMDAgYmctd2hpdGUgZGFyazpiZy1zbGF0ZS04MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS0zMDAgZGFyazpib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQtbGcgaG92ZXI6Ymctc2xhdGUtNTAgZGFyazpob3ZlcjpiZy1zbGF0ZS03MDAvNjAgc2hhZG93LTJ4cyBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHRyYW5zaXRpb24tY29sb3JzXCJcclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIDxDYW1lcmEgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjUgdGV4dC10ZWFsLTYwMCBkYXJrOnRleHQtdGVhbC00MDBcIiAvPlxyXG4gICAgICAgICAgICAgIDxzcGFuPkFuZXhhciBJbWFnZW08L3NwYW4+XHJcbiAgICAgICAgICAgIDwvYnV0dG9uPlxyXG5cclxuICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldE1vZGFsQWJlcnRhKHRydWUpfVxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTMgcHktMS41IHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXRlYWwtNzAwIGRhcms6dGV4dC10ZWFsLTMwMCBiZy10ZWFsLTUwIGRhcms6YmctdGVhbC05NTAvNDAgYm9yZGVyIGJvcmRlci10ZWFsLTIwMCBkYXJrOmJvcmRlci10ZWFsLTgwMC84MCByb3VuZGVkLWxnIGhvdmVyOmJnLXRlYWwtMTAwLzYwIHNoYWRvdy0yeHMgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSB0cmFuc2l0aW9uLWNvbG9yc1wiXHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICA8UGx1cyBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNVwiIC8+XHJcbiAgICAgICAgICAgICAgPHNwYW4+QWRpY2lvbmFyIHBvciBVUkw8L3NwYW4+XHJcbiAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgKX1cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICB7LyogR3JpZCBkZSBGb3RvcyAqL31cclxuICAgICAge3ZhbHVlLmxlbmd0aCA9PT0gMCA/IChcclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJvcmRlciBib3JkZXItZGFzaGVkIGJvcmRlci1zbGF0ZS0zMDAgZGFyazpib3JkZXItc2xhdGUtODAwIHJvdW5kZWQteGwgcC04IHRleHQtY2VudGVyIGJnLXNsYXRlLTUwLzUwIGRhcms6Ymctc2xhdGUtOTAwLzMwXCI+XHJcbiAgICAgICAgICA8SW1hZ2VJY29uIGNsYXNzTmFtZT1cInctOCBoLTggdGV4dC1zbGF0ZS00MDAgbXgtYXV0byBtYi0yXCIgLz5cclxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1zbGF0ZS02MDAgZGFyazp0ZXh0LXNsYXRlLTQwMFwiPlxyXG4gICAgICAgICAgICBOZW5odW1hIGV2aWTDqm5jaWEgZm90b2dyw6FmaWNhIGFuZXhhZGEgYSBlc3RlIGxhdWRvIHNhbml0w6FyaW8uXHJcbiAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICB7IXJlYWRPbmx5ICYmIChcclxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1zbGF0ZS00MDAgbXQtMVwiPlxyXG4gICAgICAgICAgICAgIENsaXF1ZSBlbSBcIkFuZXhhciBJbWFnZW1cIiBvdSBcIkFkaWNpb25hciBwb3IgVVJMXCIgcGFyYSByZWdpc3RyYXIgY29tcHJvdmHDp8O1ZXMgdmlzdWFpcy5cclxuICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgKX1cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgKSA6IChcclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgc206Z3JpZC1jb2xzLTIgbWQ6Z3JpZC1jb2xzLTMgbGc6Z3JpZC1jb2xzLTQgZ2FwLTRcIj5cclxuICAgICAgICAgIHt2YWx1ZS5tYXAoKGZvdG8sIGluZGV4KSA9PiAoXHJcbiAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICBrZXk9e2ZvdG8uaWQgfHwgaW5kZXh9XHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZ3JvdXAgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtODAwIHJvdW5kZWQteGwgb3ZlcmZsb3ctaGlkZGVuIGJnLXdoaXRlIGRhcms6Ymctc2xhdGUtOTAwIHNoYWRvdy0yeHMgaG92ZXI6c2hhZG93LXhzIHRyYW5zaXRpb24tc2hhZG93IGZsZXggZmxleC1jb2xcIlxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicmVsYXRpdmUgYXNwZWN0LXZpZGVvIGJnLXNsYXRlLTEwMCBkYXJrOmJnLXNsYXRlLTgwMCBjdXJzb3ItcG9pbnRlciBvdmVyZmxvdy1oaWRkZW5cIlxyXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0VmlzdWFsaXphbmRvRm90byhmb3RvKX1cclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICA8aW1nXHJcbiAgICAgICAgICAgICAgICAgIHNyYz17Zm90by51cmx9XHJcbiAgICAgICAgICAgICAgICAgIGFsdD17Zm90by5sZWdlbmRhfVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgaC1mdWxsIG9iamVjdC1jb3ZlciBncm91cC1ob3ZlcjpzY2FsZS0xMDUgdHJhbnNpdGlvbi10cmFuc2Zvcm0gZHVyYXRpb24tMjAwXCJcclxuICAgICAgICAgICAgICAgICAgb25FcnJvcj17KGUpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAvLyBGYWxsYmFjayBwYXJhIFVSTCBxdWVicmFkYVxyXG4gICAgICAgICAgICAgICAgICAgIChlLnRhcmdldCBhcyBIVE1MSW1hZ2VFbGVtZW50KS5zcmMgPVxyXG4gICAgICAgICAgICAgICAgICAgICAgXCJodHRwczovL2ltYWdlcy51bnNwbGFzaC5jb20vcGhvdG8tMTU4NDcyNzYzODA5Ni0wNDJjNDUwNDllYmU/dz02MDAmYXV0bz1mb3JtYXQmZml0PWNyb3AmcT02MFwiO1xyXG4gICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIHshcmVhZE9ubHkgJiYgKFxyXG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KGUpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgIGUuc3RvcFByb3BhZ2F0aW9uKCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVSZW1vdmVyRm90byhmb3RvLmlkKTtcclxuICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImFic29sdXRlIHRvcC0yIHJpZ2h0LTIgcC0xLjUgYmctcm9zZS02MDAvOTAgdGV4dC13aGl0ZSByb3VuZGVkLW1kIGhvdmVyOmJnLXJvc2UtNzAwIHRyYW5zaXRpb24tY29sb3JzIHNoYWRvdy14c1wiXHJcbiAgICAgICAgICAgICAgICAgICAgdGl0bGU9XCJSZW1vdmVyIGZvdG9cIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgPFRyYXNoMiBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNVwiIC8+XHJcbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImFic29sdXRlIGJvdHRvbS0xIGxlZnQtMiB0ZXh0LVsxMHB4XSBmb250LW1lZGl1bSB0ZXh0LXdoaXRlLzkwIGJnLWJsYWNrLzUwIHB4LTEuNSBweS0wLjUgcm91bmRlZCBiYWNrZHJvcC1ibHVyLXhzXCI+XHJcbiAgICAgICAgICAgICAgICAgIEZvdG8ge2luZGV4ICsgMX1cclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTIuNSBmbGV4LTEgZmxleCBmbGV4LWNvbCBqdXN0aWZ5LWJldHdlZW4gZ2FwLTEuNSBiZy1zbGF0ZS01MC81MCBkYXJrOmJnLXNsYXRlLTgwMC8zMFwiPlxyXG4gICAgICAgICAgICAgICAge3JlYWRPbmx5ID8gKFxyXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0zMDAgZm9udC1tZWRpdW0gbGluZS1jbGFtcC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge2ZvdG8ubGVnZW5kYSB8fCBcIlNlbSBsZWdlbmRhXCJ9XHJcbiAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm90by5sZWdlbmRhfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlQXR1YWxpemFyTGVnZW5kYShmb3RvLmlkLCBlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJMZWdlbmRhIGRhIGlycmVndWxhcmlkYWRlIC8gaXRlbS4uLlwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTIgcHktMSB0ZXh0LXhzIGJnLXdoaXRlIGRhcms6Ymctc2xhdGUtODAwIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCByb3VuZGVkIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZSBwbGFjZWhvbGRlci1zbGF0ZS00MDAgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMSBmb2N1czpyaW5nLXRlYWwtNTAwXCJcclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LXNsYXRlLTQwMFwiPlxyXG4gICAgICAgICAgICAgICAgICB7bmV3IERhdGUoZm90by5kYXRhX3JlZ2lzdHJvKS50b0xvY2FsZURhdGVTdHJpbmcoXCJwdC1CUlwiLCB7XHJcbiAgICAgICAgICAgICAgICAgICAgZGF5OiBcIjItZGlnaXRcIixcclxuICAgICAgICAgICAgICAgICAgICBtb250aDogXCIyLWRpZ2l0XCIsXHJcbiAgICAgICAgICAgICAgICAgICAgeWVhcjogXCJudW1lcmljXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgaG91cjogXCIyLWRpZ2l0XCIsXHJcbiAgICAgICAgICAgICAgICAgICAgbWludXRlOiBcIjItZGlnaXRcIixcclxuICAgICAgICAgICAgICAgICAgfSl9XHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgKSl9XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICl9XHJcblxyXG4gICAgICB7LyogTW9kYWwgcGFyYSBBZGljaW9uYXIgcG9yIFVSTCAqL31cclxuICAgICAge21vZGFsQWJlcnRhICYmIChcclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LTAgei01MCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBwLTQgYmctYmxhY2svNTAgYmFja2Ryb3AtYmx1ci14c1wiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC14bCBwLTUgdy1mdWxsIG1heC13LW1kIHNoYWRvdy14bCBzcGFjZS15LTRcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTEwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgcGItM1wiPlxyXG4gICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGVcIj5cclxuICAgICAgICAgICAgICAgIEFkaWNpb25hciBFdmlkw6puY2lhIEZvdG9ncsOhZmljYSBwb3IgVVJMXHJcbiAgICAgICAgICAgICAgPC9oMz5cclxuICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldE1vZGFsQWJlcnRhKGZhbHNlKX1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNDAwIGhvdmVyOnRleHQtc2xhdGUtNjAwIGRhcms6aG92ZXI6dGV4dC1zbGF0ZS0zMDBcIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIDxYIGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPlxyXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDxmb3JtIG9uU3VibWl0PXtoYW5kbGVBZGljaW9uYXJQb3JVcmx9IGNsYXNzTmFtZT1cInNwYWNlLXktM1wiPlxyXG4gICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0zMDAgbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgICBVUkwgZGEgSW1hZ2VtIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcm9zZS01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwidXJsXCJcclxuICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJodHRwczovL2V4ZW1wbG8uY29tL2ZvdG9zL2V2aWRlbmNpYS0wMS5qcGdcIlxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17bm92YVVybH1cclxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXROb3ZhVXJsKGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMgcHktMiB0ZXh0LXhzIGJnLXNsYXRlLTUwIGRhcms6Ymctc2xhdGUtODAwIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCByb3VuZGVkLWxnIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZSBwbGFjZWhvbGRlci1zbGF0ZS00MDAgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLXRlYWwtNTAwXCJcclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0zMDAgbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgICBMZWdlbmRhIC8gRGVzY3Jpw6fDo28gZGEgSXJyZWd1bGFyaWRhZGVcclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkV4OiBBdXPDqm5jaWEgZGUgdGVsYXMgbWlsaW3DqXRyaWNhcyBuYSBtYW5pcHVsYcOnw6NvIGRlIGFsaW1lbnRvc1wiXHJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtub3ZhTGVnZW5kYX1cclxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXROb3ZhTGVnZW5kYShlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC0zIHB5LTIgdGV4dC14cyBiZy1zbGF0ZS01MCBkYXJrOmJnLXNsYXRlLTgwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC1sZyB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGUgcGxhY2Vob2xkZXItc2xhdGUtNDAwIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy10ZWFsLTUwMFwiXHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktZW5kIGdhcC0yIHB0LTIgYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTEwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDBcIj5cclxuICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldE1vZGFsQWJlcnRhKGZhbHNlKX1cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtMyBweS0xLjUgdGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LXNsYXRlLTYwMCBkYXJrOnRleHQtc2xhdGUtMzAwIGhvdmVyOmJnLXNsYXRlLTEwMCBkYXJrOmhvdmVyOmJnLXNsYXRlLTgwMCByb3VuZGVkLWxnXCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgQ2FuY2VsYXJcclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNCBweS0xLjUgdGV4dC14cyBmb250LWJvbGQgdGV4dC13aGl0ZSBiZy10ZWFsLTYwMCBob3ZlcjpiZy10ZWFsLTcwMCByb3VuZGVkLWxnIHNoYWRvdy14c1wiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIENvbmZpcm1hciBBZGnDp8Ojb1xyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZm9ybT5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICApfVxyXG5cclxuICAgICAgey8qIE1vZGFsIGRlIFpvb20gZGUgSW1hZ2VtICovfVxyXG4gICAgICB7dmlzdWFsaXphbmRvRm90byAmJiAoXHJcbiAgICAgICAgPGRpdlxyXG4gICAgICAgICAgY2xhc3NOYW1lPVwiZml4ZWQgaW5zZXQtMCB6LTUwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHAtNCBiZy1ibGFjay84MCBiYWNrZHJvcC1ibHVyLXhzIGN1cnNvci1wb2ludGVyXCJcclxuICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFZpc3VhbGl6YW5kb0ZvdG8obnVsbCl9XHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJyZWxhdGl2ZSBtYXgtdy0zeGwgbWF4LWgtWzkwdmhdIGJnLXNsYXRlLTkwMCByb3VuZGVkLXhsIG92ZXJmbG93LWhpZGRlbiBzaGFkb3ctMnhsIHAtMlwiXHJcbiAgICAgICAgICAgIG9uQ2xpY2s9eyhlKSA9PiBlLnN0b3BQcm9wYWdhdGlvbigpfVxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0VmlzdWFsaXphbmRvRm90byhudWxsKX1cclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJhYnNvbHV0ZSB0b3AtNCByaWdodC00IHotMTAgcC0yIGJnLWJsYWNrLzYwIGhvdmVyOmJnLWJsYWNrIHRleHQtd2hpdGUgcm91bmRlZC1mdWxsIHRyYW5zaXRpb24tY29sb3JzXCJcclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIDxYIGNsYXNzTmFtZT1cInctNSBoLTVcIiAvPlxyXG4gICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgPGltZ1xyXG4gICAgICAgICAgICAgIHNyYz17dmlzdWFsaXphbmRvRm90by51cmx9XHJcbiAgICAgICAgICAgICAgYWx0PXt2aXN1YWxpemFuZG9Gb3RvLmxlZ2VuZGF9XHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibWF4LWgtWzgwdmhdIHctYXV0byBteC1hdXRvIG9iamVjdC1jb250YWluIHJvdW5kZWQtbGdcIlxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMyB0ZXh0LWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXdoaXRlXCI+XHJcbiAgICAgICAgICAgICAgICB7dmlzdWFsaXphbmRvRm90by5sZWdlbmRhIHx8IFwiRXZpZMOqbmNpYSBGb3RvZ3LDoWZpY2FcIn1cclxuICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1zbGF0ZS00MDBcIj5cclxuICAgICAgICAgICAgICAgIHtuZXcgRGF0ZSh2aXN1YWxpemFuZG9Gb3RvLmRhdGFfcmVnaXN0cm8pLnRvTG9jYWxlU3RyaW5nKFwicHQtQlJcIil9XHJcbiAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICApfVxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IFVwbG9hZEV2aWRlbmNpYXM7XHJcbiJdfQ==