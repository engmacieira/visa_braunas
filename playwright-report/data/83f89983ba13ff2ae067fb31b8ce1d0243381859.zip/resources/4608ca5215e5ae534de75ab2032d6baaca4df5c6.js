import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/estabelecimentos/SituacaoAlvaraBadge.tsx");const React = __vite__cjsImport0_react;const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];/**
* Componente Badge para Situação do Alvará Sanitário
* Válido | Vencido | Em Análise | Não Possui (Irregular) | Cassado
*/
import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=0fd2848a";
import { CheckCircle2, AlertTriangle, Clock, XCircle, Ban } from "/node_modules/.vite/deps/lucide-react.js?v=0fd2848a";
var _jsxFileName = "E:/Projetos VSCODE/visa_braunas/src/components/estabelecimentos/SituacaoAlvaraBadge.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=0fd2848a";
const SITUACAO_CONFIG = {
	Válido: {
		label: "Alvará Válido",
		bg: "bg-emerald-50 dark:bg-emerald-950/40",
		text: "text-emerald-700 dark:text-emerald-300",
		border: "border-emerald-200 dark:border-emerald-800",
		icon: CheckCircle2
	},
	"Em Análise": {
		label: "Em Análise",
		bg: "bg-blue-50 dark:bg-blue-950/40",
		text: "text-blue-700 dark:text-blue-300",
		border: "border-blue-200 dark:border-blue-800",
		icon: Clock
	},
	Vencido: {
		label: "Alvará Vencido",
		bg: "bg-amber-50 dark:bg-amber-950/40",
		text: "text-amber-700 dark:text-amber-300",
		border: "border-amber-200 dark:border-amber-800",
		icon: AlertTriangle
	},
	"Não Possui (Irregular)": {
		label: "Sem Alvará (Irregular)",
		bg: "bg-rose-50 dark:bg-rose-950/40",
		text: "text-rose-700 dark:text-rose-300",
		border: "border-rose-200 dark:border-rose-800",
		icon: XCircle
	},
	Cassado: {
		label: "Alvará Cassado",
		bg: "bg-slate-100 dark:bg-slate-800",
		text: "text-slate-800 dark:text-slate-200",
		border: "border-slate-300 dark:border-slate-700",
		icon: Ban
	}
};
export const SituacaoAlvaraBadge = ({ situacao, size = "sm" }) => {
	const config = SITUACAO_CONFIG[situacao] || {
		label: situacao,
		bg: "bg-slate-100",
		text: "text-slate-700",
		border: "border-slate-200",
		icon: Clock
	};
	const Icon = config.icon;
	const sizeClasses = size === "sm" ? "text-[11px] px-2 py-0.5 gap-1 font-medium" : "text-xs px-2.5 py-1 gap-1.5 font-semibold";
	return /* @__PURE__ */ _jsxDEV("span", {
		className: `inline-flex items-center rounded-md border ${config.bg} ${config.text} ${config.border} ${sizeClasses} whitespace-nowrap`,
		children: [/* @__PURE__ */ _jsxDEV(Icon, { className: "w-3 h-3 shrink-0" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 78,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("span", { children: config.label }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 79,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 75,
		columnNumber: 5
	}, this);
};
_c = SituacaoAlvaraBadge;
export default SituacaoAlvaraBadge;
var _c;
$RefreshReg$(_c, "SituacaoAlvaraBadge");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/estabelecimentos/SituacaoAlvaraBadge.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("E:/Projetos VSCODE/visa_braunas/src/components/estabelecimentos/SituacaoAlvaraBadge.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("E:/Projetos VSCODE/visa_braunas/src/components/estabelecimentos/SituacaoAlvaraBadge.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "E:/Projetos VSCODE/visa_braunas/src/components/estabelecimentos/SituacaoAlvaraBadge.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7OztBQUtBLE9BQU8sV0FBVztBQUNsQixTQUFTLGNBQWMsZUFBZSxPQUFPLFNBQVMsV0FBVzs7O0FBUWpFLE1BQU0sa0JBR0Y7Q0FDRixRQUFRO0VBQ04sT0FBTztFQUNQLElBQUk7RUFDSixNQUFNO0VBQ04sUUFBUTtFQUNSLE1BQU07Q0FDUjtDQUNBLGNBQWM7RUFDWixPQUFPO0VBQ1AsSUFBSTtFQUNKLE1BQU07RUFDTixRQUFRO0VBQ1IsTUFBTTtDQUNSO0NBQ0EsU0FBUztFQUNQLE9BQU87RUFDUCxJQUFJO0VBQ0osTUFBTTtFQUNOLFFBQVE7RUFDUixNQUFNO0NBQ1I7Q0FDQSwwQkFBMEI7RUFDeEIsT0FBTztFQUNQLElBQUk7RUFDSixNQUFNO0VBQ04sUUFBUTtFQUNSLE1BQU07Q0FDUjtDQUNBLFNBQVM7RUFDUCxPQUFPO0VBQ1AsSUFBSTtFQUNKLE1BQU07RUFDTixRQUFRO0VBQ1IsTUFBTTtDQUNSO0FBQ0Y7QUFFQSxPQUFPLE1BQU0sdUJBQTJELEVBQ3RFLFVBQ0EsT0FBTyxXQUNIO0NBQ0osTUFBTSxTQUFTLGdCQUFnQixhQUFhO0VBQzFDLE9BQU87RUFDUCxJQUFJO0VBQ0osTUFBTTtFQUNOLFFBQVE7RUFDUixNQUFNO0NBQ1I7Q0FFQSxNQUFNLE9BQU8sT0FBTztDQUNwQixNQUFNLGNBQ0osU0FBUyxPQUNMLDhDQUNBO0NBRU4sT0FDRSx3QkFBQyxRQUFEO0VBQ0UsV0FBVyw4Q0FBOEMsT0FBTyxHQUFHLEdBQUcsT0FBTyxLQUFLLEdBQUcsT0FBTyxPQUFPLEdBQUcsWUFBWTtZQURwSCxDQUdFLHdCQUFDLE1BQUQsRUFBTSxXQUFVLG1CQUFvQjs7OztZQUNwQyx3QkFBQyxRQUFELFlBQU8sT0FBTyxNQUFZOzs7O1VBQ3RCOzs7Ozs7QUFFVjs7QUFFQSxlQUFlIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIlNpdHVhY2FvQWx2YXJhQmFkZ2UudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbIi8qKlxyXG4gKiBDb21wb25lbnRlIEJhZGdlIHBhcmEgU2l0dWHDp8OjbyBkbyBBbHZhcsOhIFNhbml0w6FyaW9cclxuICogVsOhbGlkbyB8IFZlbmNpZG8gfCBFbSBBbsOhbGlzZSB8IE7Do28gUG9zc3VpIChJcnJlZ3VsYXIpIHwgQ2Fzc2Fkb1xyXG4gKi9cclxuXHJcbmltcG9ydCBSZWFjdCBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHsgQ2hlY2tDaXJjbGUyLCBBbGVydFRyaWFuZ2xlLCBDbG9jaywgWENpcmNsZSwgQmFuIH0gZnJvbSBcImx1Y2lkZS1yZWFjdFwiO1xyXG5pbXBvcnQgeyBTaXR1YWNhb0FsdmFyYSB9IGZyb20gXCIuLi8uLi90eXBlcy9lc3RhYmVsZWNpbWVudG9cIjtcclxuXHJcbmludGVyZmFjZSBTaXR1YWNhb0FsdmFyYUJhZGdlUHJvcHMge1xyXG4gIHNpdHVhY2FvOiBTaXR1YWNhb0FsdmFyYSB8IHN0cmluZztcclxuICBzaXplPzogXCJzbVwiIHwgXCJtZFwiO1xyXG59XHJcblxyXG5jb25zdCBTSVRVQUNBT19DT05GSUc6IFJlY29yZDxcclxuICBzdHJpbmcsXHJcbiAgeyBsYWJlbDogc3RyaW5nOyBiZzogc3RyaW5nOyB0ZXh0OiBzdHJpbmc7IGJvcmRlcjogc3RyaW5nOyBpY29uOiBSZWFjdC5Db21wb25lbnRUeXBlPHsgY2xhc3NOYW1lPzogc3RyaW5nIH0+IH1cclxuPiA9IHtcclxuICBWw6FsaWRvOiB7XHJcbiAgICBsYWJlbDogXCJBbHZhcsOhIFbDoWxpZG9cIixcclxuICAgIGJnOiBcImJnLWVtZXJhbGQtNTAgZGFyazpiZy1lbWVyYWxkLTk1MC80MFwiLFxyXG4gICAgdGV4dDogXCJ0ZXh0LWVtZXJhbGQtNzAwIGRhcms6dGV4dC1lbWVyYWxkLTMwMFwiLFxyXG4gICAgYm9yZGVyOiBcImJvcmRlci1lbWVyYWxkLTIwMCBkYXJrOmJvcmRlci1lbWVyYWxkLTgwMFwiLFxyXG4gICAgaWNvbjogQ2hlY2tDaXJjbGUyLFxyXG4gIH0sXHJcbiAgXCJFbSBBbsOhbGlzZVwiOiB7XHJcbiAgICBsYWJlbDogXCJFbSBBbsOhbGlzZVwiLFxyXG4gICAgYmc6IFwiYmctYmx1ZS01MCBkYXJrOmJnLWJsdWUtOTUwLzQwXCIsXHJcbiAgICB0ZXh0OiBcInRleHQtYmx1ZS03MDAgZGFyazp0ZXh0LWJsdWUtMzAwXCIsXHJcbiAgICBib3JkZXI6IFwiYm9yZGVyLWJsdWUtMjAwIGRhcms6Ym9yZGVyLWJsdWUtODAwXCIsXHJcbiAgICBpY29uOiBDbG9jayxcclxuICB9LFxyXG4gIFZlbmNpZG86IHtcclxuICAgIGxhYmVsOiBcIkFsdmFyw6EgVmVuY2lkb1wiLFxyXG4gICAgYmc6IFwiYmctYW1iZXItNTAgZGFyazpiZy1hbWJlci05NTAvNDBcIixcclxuICAgIHRleHQ6IFwidGV4dC1hbWJlci03MDAgZGFyazp0ZXh0LWFtYmVyLTMwMFwiLFxyXG4gICAgYm9yZGVyOiBcImJvcmRlci1hbWJlci0yMDAgZGFyazpib3JkZXItYW1iZXItODAwXCIsXHJcbiAgICBpY29uOiBBbGVydFRyaWFuZ2xlLFxyXG4gIH0sXHJcbiAgXCJOw6NvIFBvc3N1aSAoSXJyZWd1bGFyKVwiOiB7XHJcbiAgICBsYWJlbDogXCJTZW0gQWx2YXLDoSAoSXJyZWd1bGFyKVwiLFxyXG4gICAgYmc6IFwiYmctcm9zZS01MCBkYXJrOmJnLXJvc2UtOTUwLzQwXCIsXHJcbiAgICB0ZXh0OiBcInRleHQtcm9zZS03MDAgZGFyazp0ZXh0LXJvc2UtMzAwXCIsXHJcbiAgICBib3JkZXI6IFwiYm9yZGVyLXJvc2UtMjAwIGRhcms6Ym9yZGVyLXJvc2UtODAwXCIsXHJcbiAgICBpY29uOiBYQ2lyY2xlLFxyXG4gIH0sXHJcbiAgQ2Fzc2Fkbzoge1xyXG4gICAgbGFiZWw6IFwiQWx2YXLDoSBDYXNzYWRvXCIsXHJcbiAgICBiZzogXCJiZy1zbGF0ZS0xMDAgZGFyazpiZy1zbGF0ZS04MDBcIixcclxuICAgIHRleHQ6IFwidGV4dC1zbGF0ZS04MDAgZGFyazp0ZXh0LXNsYXRlLTIwMFwiLFxyXG4gICAgYm9yZGVyOiBcImJvcmRlci1zbGF0ZS0zMDAgZGFyazpib3JkZXItc2xhdGUtNzAwXCIsXHJcbiAgICBpY29uOiBCYW4sXHJcbiAgfSxcclxufTtcclxuXHJcbmV4cG9ydCBjb25zdCBTaXR1YWNhb0FsdmFyYUJhZGdlOiBSZWFjdC5GQzxTaXR1YWNhb0FsdmFyYUJhZGdlUHJvcHM+ID0gKHtcclxuICBzaXR1YWNhbyxcclxuICBzaXplID0gXCJzbVwiLFxyXG59KSA9PiB7XHJcbiAgY29uc3QgY29uZmlnID0gU0lUVUFDQU9fQ09ORklHW3NpdHVhY2FvXSB8fCB7XHJcbiAgICBsYWJlbDogc2l0dWFjYW8sXHJcbiAgICBiZzogXCJiZy1zbGF0ZS0xMDBcIixcclxuICAgIHRleHQ6IFwidGV4dC1zbGF0ZS03MDBcIixcclxuICAgIGJvcmRlcjogXCJib3JkZXItc2xhdGUtMjAwXCIsXHJcbiAgICBpY29uOiBDbG9jayxcclxuICB9O1xyXG5cclxuICBjb25zdCBJY29uID0gY29uZmlnLmljb247XHJcbiAgY29uc3Qgc2l6ZUNsYXNzZXMgPVxyXG4gICAgc2l6ZSA9PT0gXCJzbVwiXHJcbiAgICAgID8gXCJ0ZXh0LVsxMXB4XSBweC0yIHB5LTAuNSBnYXAtMSBmb250LW1lZGl1bVwiXHJcbiAgICAgIDogXCJ0ZXh0LXhzIHB4LTIuNSBweS0xIGdhcC0xLjUgZm9udC1zZW1pYm9sZFwiO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPHNwYW5cclxuICAgICAgY2xhc3NOYW1lPXtgaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIHJvdW5kZWQtbWQgYm9yZGVyICR7Y29uZmlnLmJnfSAke2NvbmZpZy50ZXh0fSAke2NvbmZpZy5ib3JkZXJ9ICR7c2l6ZUNsYXNzZXN9IHdoaXRlc3BhY2Utbm93cmFwYH1cclxuICAgID5cclxuICAgICAgPEljb24gY2xhc3NOYW1lPVwidy0zIGgtMyBzaHJpbmstMFwiIC8+XHJcbiAgICAgIDxzcGFuPntjb25maWcubGFiZWx9PC9zcGFuPlxyXG4gICAgPC9zcGFuPlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBTaXR1YWNhb0FsdmFyYUJhZGdlO1xyXG4iXX0=