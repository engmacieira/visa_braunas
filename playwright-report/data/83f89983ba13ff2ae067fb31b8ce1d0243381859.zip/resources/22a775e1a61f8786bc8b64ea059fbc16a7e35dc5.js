import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/estabelecimentos/EstabelecimentosListPage.tsx");const React = __vite__cjsImport0_react; const useEffect = __vite__cjsImport0_react["useEffect"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport7_react_jsxDevRuntime["jsxDEV"];/**
* Listagem Principal de Estabelecimentos Sanitários (EstabelecimentosListPage)
* Tabela densa e responsiva com debounce de busca, filtros combinados de Risco e Situação,
* paginação e atalhos operacionais para visualização detalhada e edição.
*/
import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=0fd2848a";
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=0fd2848a";
import { Building2, ChevronLeft, ChevronRight, ClipboardCheck, Edit, Eye, Plus, RefreshCw, Search, X } from "/node_modules/.vite/deps/lucide-react.js?v=0fd2848a";
import { ROUTES } from "/src/config/routes.config.ts";
import RiscoBadge from "/src/components/estabelecimentos/RiscoBadge.tsx";
import SituacaoAlvaraBadge from "/src/components/estabelecimentos/SituacaoAlvaraBadge.tsx";
import { useEstabelecimentosList } from "/src/hooks/useEstabelecimentos.ts";
var _jsxFileName = "E:/Projetos VSCODE/visa_braunas/src/pages/estabelecimentos/EstabelecimentosListPage.tsx";
import __vite__cjsImport7_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=0fd2848a";
var _s = $RefreshSig$();
const ITENS_POR_PAGINA = 15;
export const EstabelecimentosListPage = () => {
	_s();
	const [termoBusca, setTermoBusca] = useState("");
	const [debouncedBusca, setDebouncedBusca] = useState("");
	const [filtroRisco, setFiltroRisco] = useState("");
	const [filtroSituacao, setFiltroSituacao] = useState("");
	const [paginaAtual, setPaginaAtual] = useState(1);
	// Debounce de 350ms na busca textual
	useEffect(() => {
		const timer = setTimeout(() => {
			setDebouncedBusca(termoBusca);
			setPaginaAtual(1);
		}, 350);
		return () => clearTimeout(timer);
	}, [termoBusca]);
	const filtros = {
		busca: debouncedBusca,
		risco: filtroRisco,
		situacao: filtroSituacao,
		skip: (paginaAtual - 1) * ITENS_POR_PAGINA,
		limit: ITENS_POR_PAGINA
	};
	const { data, isLoading, isFetching, refetch } = useEstabelecimentosList(filtros);
	const estabelecimentos = data?.itens || data?.items || [];
	const totalRegistros = data?.total || 0;
	const totalPaginas = Math.ceil(totalRegistros / ITENS_POR_PAGINA) || 1;
	const handleLimparFiltros = () => {
		setTermoBusca("");
		setDebouncedBusca("");
		setFiltroRisco("");
		setFiltroSituacao("");
		setPaginaAtual(1);
	};
	const temFiltrosAtivos = Boolean(termoBusca) || Boolean(filtroRisco) || Boolean(filtroSituacao);
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "space-y-5",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 shadow-xs",
				children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "p-2 bg-teal-50 dark:bg-teal-950/40 rounded-lg text-teal-600 dark:text-teal-400",
						children: /* @__PURE__ */ _jsxDEV(Building2, { className: "w-5 h-5" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 82,
							columnNumber: 15
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 81,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("h1", {
						className: "text-xl font-bold text-slate-900 dark:text-white",
						children: "Estabelecimentos Regulados"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 84,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 80,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("p", {
					className: "text-xs text-slate-500 dark:text-slate-400 mt-1",
					children: "Cadastro de estabelecimentos municipais sujeitos à fiscalização e licenciamento da VISA."
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 88,
					columnNumber: 11
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 79,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						onClick: () => refetch(),
						className: "p-2 text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white bg-slate-100 dark:bg-slate-800 rounded-lg hover:bg-slate-200 transition-colors",
						title: "Recarregar dados",
						children: /* @__PURE__ */ _jsxDEV(RefreshCw, { className: `w-4 h-4 ${isFetching ? "animate-spin" : ""}` }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 100,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 94,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV(Link, {
						to: ROUTES.ESTABELECIMENTOS.NOVO,
						className: "inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-teal-600 hover:bg-teal-500 rounded-lg shadow-xs transition-colors",
						children: [/* @__PURE__ */ _jsxDEV(Plus, { className: "w-4 h-4" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 107,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Novo Estabelecimento" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 108,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 103,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 93,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 78,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 shadow-xs space-y-3",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "grid grid-cols-1 sm:grid-cols-12 gap-3",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "sm:col-span-6 relative",
							children: [
								/* @__PURE__ */ _jsxDEV(Search, { className: "w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 118,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("input", {
									type: "text",
									value: termoBusca,
									onChange: (e) => setTermoBusca(e.target.value),
									placeholder: "Buscar por CNPJ/CPF, Razão Social ou Nome Fantasia...",
									className: "w-full pl-9 pr-8 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg text-xs text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-teal-500"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 119,
									columnNumber: 13
								}, this),
								termoBusca && /* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => setTermoBusca(""),
									className: "absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600",
									children: /* @__PURE__ */ _jsxDEV(X, { className: "w-3.5 h-3.5" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 132,
										columnNumber: 17
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 127,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 117,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "sm:col-span-3",
							children: /* @__PURE__ */ _jsxDEV("select", {
								value: filtroRisco,
								onChange: (e) => {
									setFiltroRisco(e.target.value);
									setPaginaAtual(1);
								},
								className: "w-full py-2 px-3 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg text-xs text-slate-700 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-teal-500",
								children: [
									/* @__PURE__ */ _jsxDEV("option", {
										value: "",
										children: "Todos os Níveis de Risco"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 147,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("option", {
										value: "Risco III",
										children: "Risco III (Alto)"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 148,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("option", {
										value: "Risco II",
										children: "Risco II (Médio)"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 149,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("option", {
										value: "Risco I",
										children: "Risco I (Baixo)"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 150,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("option", {
										value: "Dispensado",
										children: "Dispensado"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 151,
										columnNumber: 15
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 139,
								columnNumber: 13
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 138,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "sm:col-span-3",
							children: /* @__PURE__ */ _jsxDEV("select", {
								value: filtroSituacao,
								onChange: (e) => {
									setFiltroSituacao(e.target.value);
									setPaginaAtual(1);
								},
								className: "w-full py-2 px-3 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg text-xs text-slate-700 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-teal-500",
								children: [
									/* @__PURE__ */ _jsxDEV("option", {
										value: "",
										children: "Todas as Situações"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 165,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("option", {
										value: "Ativo",
										children: "Ativo"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 166,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("option", {
										value: "Inativo",
										children: "Inativo"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 167,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("option", {
										value: "Suspenso",
										children: "Suspenso"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 168,
										columnNumber: 15
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 157,
								columnNumber: 13
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 156,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 115,
					columnNumber: 9
				}, this), temFiltrosAtivos && /* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center justify-between pt-2 border-t border-slate-100 dark:border-slate-800 text-[11px] text-slate-500",
					children: [/* @__PURE__ */ _jsxDEV("span", { children: [
						"Filtrando resultados (",
						totalRegistros,
						" estabelecimento",
						totalRegistros === 1 ? "" : "s",
						" encontrado",
						totalRegistros === 1 ? "" : "s",
						")"
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 176,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						onClick: handleLimparFiltros,
						className: "text-teal-600 hover:text-teal-700 dark:text-teal-400 font-semibold",
						children: "Limpar Filtros"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 180,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 175,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 114,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden shadow-xs",
				children: [isLoading ? /* @__PURE__ */ _jsxDEV("div", {
					className: "p-16 text-center text-xs text-slate-400 flex flex-col items-center justify-center",
					children: [/* @__PURE__ */ _jsxDEV("div", { className: "w-6 h-6 border-2 border-teal-500 border-t-transparent rounded-full animate-spin mb-3" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 195,
						columnNumber: 13
					}, this), "Carregando cadastro de estabelecimentos..."]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 194,
					columnNumber: 11
				}, this) : estabelecimentos.length === 0 ? /* @__PURE__ */ _jsxDEV("div", {
					className: "p-16 text-center text-xs text-slate-500 dark:text-slate-400 space-y-2",
					children: [
						/* @__PURE__ */ _jsxDEV(Building2, { className: "w-8 h-8 text-slate-300 mx-auto mb-2" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 200,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("p", {
							className: "font-semibold text-slate-700 dark:text-slate-200",
							children: "Nenhum estabelecimento encontrado."
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 201,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("p", {
							className: "text-[11px] text-slate-400 max-w-sm mx-auto",
							children: "Verifique os filtros informados ou realize um novo cadastro clicando no botão acima."
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 204,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 199,
					columnNumber: 11
				}, this) : /* @__PURE__ */ _jsxDEV("div", {
					className: "overflow-x-auto",
					children: /* @__PURE__ */ _jsxDEV("table", {
						className: "w-full text-left text-xs",
						children: [/* @__PURE__ */ _jsxDEV("thead", {
							className: "bg-slate-50 dark:bg-slate-800/60 border-b border-slate-200 dark:border-slate-800 text-slate-500 font-semibold uppercase tracking-wider text-[11px]",
							children: /* @__PURE__ */ _jsxDEV("tr", { children: [
								/* @__PURE__ */ _jsxDEV("th", {
									className: "py-3 px-4",
									children: "CNPJ / CPF"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 213,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("th", {
									className: "py-3 px-4",
									children: "Razão Social / Nome Fantasia"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 214,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("th", {
									className: "py-3 px-4",
									children: "Grau de Risco"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 215,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("th", {
									className: "py-3 px-4",
									children: "Situação do Alvará"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 216,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("th", {
									className: "py-3 px-4",
									children: "Situação Cadastral"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 217,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("th", {
									className: "py-3 px-4 text-right",
									children: "Ações"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 218,
									columnNumber: 19
								}, this)
							] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 212,
								columnNumber: 17
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 211,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("tbody", {
							className: "divide-y divide-slate-100 dark:divide-slate-800",
							children: estabelecimentos.map((estab) => /* @__PURE__ */ _jsxDEV("tr", {
								className: "hover:bg-slate-50/60 dark:hover:bg-slate-800/40 transition-colors",
								children: [
									/* @__PURE__ */ _jsxDEV("td", {
										className: "py-3 px-4 font-mono font-medium text-slate-700 dark:text-slate-300 whitespace-nowrap",
										children: estab.cnpj_cpf
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 227,
										columnNumber: 21
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										className: "py-3 px-4 max-w-xs",
										children: [/* @__PURE__ */ _jsxDEV(Link, {
											to: ROUTES.ESTABELECIMENTOS.DETALHE(estab.id),
											className: "font-semibold text-slate-900 dark:text-white hover:text-teal-600 dark:hover:text-teal-400 block truncate",
											title: estab.razao_social,
											children: estab.razao_social
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 232,
											columnNumber: 23
										}, this), /* @__PURE__ */ _jsxDEV("span", {
											className: "text-[11px] text-slate-400 block truncate",
											children: estab.nome_fantasia || "Sem nome fantasia registrado"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 239,
											columnNumber: 23
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 231,
										columnNumber: 21
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										className: "py-3 px-4 whitespace-nowrap",
										children: /* @__PURE__ */ _jsxDEV(RiscoBadge, { risco: estab.nivel_risco }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 245,
											columnNumber: 23
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 244,
										columnNumber: 21
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										className: "py-3 px-4 whitespace-nowrap",
										children: [/* @__PURE__ */ _jsxDEV(SituacaoAlvaraBadge, { situacao: estab.situacao_alvara }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 249,
											columnNumber: 23
										}, this), estab.numero_alvara && /* @__PURE__ */ _jsxDEV("span", {
											className: "block text-[10px] font-mono text-slate-400 mt-0.5",
											children: ["Nº ", estab.numero_alvara]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 251,
											columnNumber: 25
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 248,
										columnNumber: 21
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										className: "py-3 px-4 whitespace-nowrap",
										children: /* @__PURE__ */ _jsxDEV("span", {
											className: `inline-block px-2 py-0.5 rounded text-[10px] font-semibold border ${estab.situacao_estabelecimento === "Ativo" ? "bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-950/40 dark:text-emerald-300" : "bg-slate-100 text-slate-600 border-slate-200"}`,
											children: estab.situacao_estabelecimento
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 258,
											columnNumber: 23
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 257,
										columnNumber: 21
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										className: "py-3 px-4 text-right whitespace-nowrap",
										children: /* @__PURE__ */ _jsxDEV("div", {
											className: "inline-flex items-center gap-1.5",
											children: [
												/* @__PURE__ */ _jsxDEV(Link, {
													to: ROUTES.ESTABELECIMENTOS.DETALHE(estab.id),
													className: "p-1.5 text-slate-600 hover:text-teal-600 hover:bg-slate-100 dark:hover:bg-slate-800 rounded transition-colors",
													title: "Visualizar Ficha Completa",
													children: /* @__PURE__ */ _jsxDEV(Eye, { className: "w-4 h-4" }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 276,
														columnNumber: 27
													}, this)
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 271,
													columnNumber: 25
												}, this),
												/* @__PURE__ */ _jsxDEV(Link, {
													to: ROUTES.ESTABELECIMENTOS.EDITAR(estab.id),
													className: "p-1.5 text-slate-600 hover:text-blue-600 hover:bg-slate-100 dark:hover:bg-slate-800 rounded transition-colors",
													title: "Editar Cadastro",
													children: /* @__PURE__ */ _jsxDEV(Edit, { className: "w-4 h-4" }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 284,
														columnNumber: 27
													}, this)
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 279,
													columnNumber: 25
												}, this),
												/* @__PURE__ */ _jsxDEV(Link, {
													to: `${ROUTES.INSPECOES.LIST}?estabelecimento_id=${estab.id}`,
													className: "p-1.5 text-slate-600 hover:text-purple-600 hover:bg-slate-100 dark:hover:bg-slate-800 rounded transition-colors",
													title: "Fiscalizações deste estabelecimento",
													children: /* @__PURE__ */ _jsxDEV(ClipboardCheck, { className: "w-4 h-4" }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 292,
														columnNumber: 27
													}, this)
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 287,
													columnNumber: 25
												}, this)
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 270,
											columnNumber: 23
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 269,
										columnNumber: 21
									}, this)
								]
							}, estab.id, true, {
								fileName: _jsxFileName,
								lineNumber: 223,
								columnNumber: 19
							}, this))
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 221,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 210,
						columnNumber: 13
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 209,
					columnNumber: 11
				}, this), totalPaginas > 1 && /* @__PURE__ */ _jsxDEV("div", {
					className: "p-3 bg-slate-50 dark:bg-slate-800/40 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between text-xs text-slate-500",
					children: [/* @__PURE__ */ _jsxDEV("div", { children: [
						"Mostrando",
						" ",
						/* @__PURE__ */ _jsxDEV("strong", {
							className: "text-slate-700 dark:text-slate-300",
							children: (paginaAtual - 1) * ITENS_POR_PAGINA + 1
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 308,
							columnNumber: 15
						}, this),
						" ",
						"a",
						" ",
						/* @__PURE__ */ _jsxDEV("strong", {
							className: "text-slate-700 dark:text-slate-300",
							children: Math.min(paginaAtual * ITENS_POR_PAGINA, totalRegistros)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 312,
							columnNumber: 15
						}, this),
						" ",
						"de ",
						/* @__PURE__ */ _jsxDEV("strong", {
							className: "tabular-nums",
							children: totalRegistros
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 315,
							columnNumber: 18
						}, this),
						" registros"
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 306,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-1",
						children: [
							/* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								onClick: () => setPaginaAtual((p) => Math.max(1, p - 1)),
								disabled: paginaAtual === 1,
								className: "p-1.5 rounded border border-slate-300 dark:border-slate-700 hover:bg-white dark:hover:bg-slate-700 disabled:opacity-40 transition-colors",
								children: /* @__PURE__ */ _jsxDEV(ChevronLeft, { className: "w-4 h-4" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 325,
									columnNumber: 17
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 319,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("span", {
								className: "px-2 font-medium",
								children: [
									"Página ",
									paginaAtual,
									" de ",
									totalPaginas
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 328,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								onClick: () => setPaginaAtual((p) => Math.min(totalPaginas, p + 1)),
								disabled: paginaAtual === totalPaginas,
								className: "p-1.5 rounded border border-slate-300 dark:border-slate-700 hover:bg-white dark:hover:bg-slate-700 disabled:opacity-40 transition-colors",
								children: /* @__PURE__ */ _jsxDEV(ChevronRight, { className: "w-4 h-4" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 338,
									columnNumber: 17
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 332,
								columnNumber: 15
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 318,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 305,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 192,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 76,
		columnNumber: 5
	}, this);
};
_s(EstabelecimentosListPage, "SjxKci6/MDoYF31CA7tjmTKpLIs=", false, function() {
	return [useEstabelecimentosList];
});
_c = EstabelecimentosListPage;
export default EstabelecimentosListPage;
var _c;
$RefreshReg$(_c, "EstabelecimentosListPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/estabelecimentos/EstabelecimentosListPage.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("E:/Projetos VSCODE/visa_braunas/src/pages/estabelecimentos/EstabelecimentosListPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("E:/Projetos VSCODE/visa_braunas/src/pages/estabelecimentos/EstabelecimentosListPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "E:/Projetos VSCODE/visa_braunas/src/pages/estabelecimentos/EstabelecimentosListPage.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7Ozs7QUFNQSxPQUFPLFNBQVMsV0FBVyxnQkFBZ0I7QUFDM0MsU0FBUyxZQUFZO0FBQ3JCLFNBQ0UsV0FDQSxhQUNBLGNBQ0EsZ0JBQ0EsTUFDQSxLQUVBLE1BQ0EsV0FDQSxRQUNBLFNBQ0s7QUFDUCxTQUFTLGNBQWM7QUFDdkIsT0FBTyxnQkFBZ0I7QUFDdkIsT0FBTyx5QkFBeUI7QUFDaEMsU0FBUywrQkFBK0I7Ozs7QUFPeEMsTUFBTSxtQkFBbUI7QUFFekIsT0FBTyxNQUFNLGlDQUEyQzs7Q0FDdEQsTUFBTSxDQUFDLFlBQVksaUJBQWlCLFNBQVMsRUFBRTtDQUMvQyxNQUFNLENBQUMsZ0JBQWdCLHFCQUFxQixTQUFTLEVBQUU7Q0FDdkQsTUFBTSxDQUFDLGFBQWEsa0JBQWtCLFNBQTBCLEVBQUU7Q0FDbEUsTUFBTSxDQUFDLGdCQUFnQixxQkFBcUIsU0FBaUMsRUFBRTtDQUMvRSxNQUFNLENBQUMsYUFBYSxrQkFBa0IsU0FBUyxDQUFDOztDQUdoRCxnQkFBZ0I7RUFDZCxNQUFNLFFBQVEsaUJBQWlCO0dBQzdCLGtCQUFrQixVQUFVO0dBQzVCLGVBQWUsQ0FBQztFQUNsQixHQUFHLEdBQUc7RUFDTixhQUFhLGFBQWEsS0FBSztDQUNqQyxHQUFHLENBQUMsVUFBVSxDQUFDO0NBRWYsTUFBTSxVQUFrQztFQUN0QyxPQUFPO0VBQ1AsT0FBTztFQUNQLFVBQVU7RUFDVixPQUFPLGNBQWMsS0FBSztFQUMxQixPQUFPO0NBQ1Q7Q0FFQSxNQUFNLEVBQUUsTUFBTSxXQUFXLFlBQVksWUFBWSx3QkFBd0IsT0FBTztDQUVoRixNQUFNLG1CQUFtQixNQUFNLFNBQVUsTUFBcUYsU0FBUyxDQUFDO0NBQ3hJLE1BQU0saUJBQWlCLE1BQU0sU0FBUztDQUN0QyxNQUFNLGVBQWUsS0FBSyxLQUFLLGlCQUFpQixnQkFBZ0IsS0FBSztDQUVyRSxNQUFNLDRCQUE0QjtFQUNoQyxjQUFjLEVBQUU7RUFDaEIsa0JBQWtCLEVBQUU7RUFDcEIsZUFBZSxFQUFFO0VBQ2pCLGtCQUFrQixFQUFFO0VBQ3BCLGVBQWUsQ0FBQztDQUNsQjtDQUVBLE1BQU0sbUJBQ0osUUFBUSxVQUFVLEtBQUssUUFBUSxXQUFXLEtBQUssUUFBUSxjQUFjO0NBRXZFLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBZjtHQUVFLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUNiLHdCQUFDLFdBQUQsRUFBVyxXQUFVLFVBQVc7Ozs7O0tBQzdCOzs7O2VBQ0wsd0JBQUMsTUFBRDtNQUFJLFdBQVU7Z0JBQW1EO0tBRTdEOzs7O2FBQ0Q7Ozs7O2NBQ0wsd0JBQUMsS0FBRDtLQUFHLFdBQVU7ZUFBa0Q7SUFFNUQ7Ozs7WUFDQTs7OztjQUVMLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxVQUFEO01BQ0UsTUFBSztNQUNMLGVBQWUsUUFBUTtNQUN2QixXQUFVO01BQ1YsT0FBTTtnQkFFTix3QkFBQyxXQUFELEVBQVcsV0FBVyxXQUFXLGFBQWEsaUJBQWlCLEtBQU87Ozs7O0tBQ2hFOzs7O2VBRVIsd0JBQUMsTUFBRDtNQUNFLElBQUksT0FBTyxpQkFBaUI7TUFDNUIsV0FBVTtnQkFGWixDQUlFLHdCQUFDLE1BQUQsRUFBTSxXQUFVLFVBQVc7Ozs7Z0JBQzNCLHdCQUFDLFFBQUQsWUFBTSx1QkFBMEI7Ozs7Y0FDNUI7Ozs7O2FBQ0g7Ozs7O1lBQ0Y7Ozs7OztHQUdMLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmO01BRUUsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWY7UUFDRSx3QkFBQyxRQUFELEVBQVEsV0FBVSxrRUFBbUU7Ozs7O1FBQ3JGLHdCQUFDLFNBQUQ7U0FDRSxNQUFLO1NBQ0wsT0FBTztTQUNQLFdBQVcsTUFBTSxjQUFjLEVBQUUsT0FBTyxLQUFLO1NBQzdDLGFBQVk7U0FDWixXQUFVO1FBQ1g7Ozs7O1FBQ0EsY0FDQyx3QkFBQyxVQUFEO1NBQ0UsTUFBSztTQUNMLGVBQWUsY0FBYyxFQUFFO1NBQy9CLFdBQVU7bUJBRVYsd0JBQUMsR0FBRCxFQUFHLFdBQVUsY0FBZTs7Ozs7UUFDdEI7Ozs7O09BRVA7Ozs7OztNQUdMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUNiLHdCQUFDLFVBQUQ7UUFDRSxPQUFPO1FBQ1AsV0FBVyxNQUFNO1NBQ2YsZUFBZSxFQUFFLE9BQU8sS0FBd0I7U0FDaEQsZUFBZSxDQUFDO1FBQ2xCO1FBQ0EsV0FBVTtrQkFOWjtTQVFFLHdCQUFDLFVBQUQ7VUFBUSxPQUFNO29CQUFHO1NBQWdDOzs7OztTQUNqRCx3QkFBQyxVQUFEO1VBQVEsT0FBTTtvQkFBWTtTQUF3Qjs7Ozs7U0FDbEQsd0JBQUMsVUFBRDtVQUFRLE9BQU07b0JBQVc7U0FBd0I7Ozs7O1NBQ2pELHdCQUFDLFVBQUQ7VUFBUSxPQUFNO29CQUFVO1NBQXVCOzs7OztTQUMvQyx3QkFBQyxVQUFEO1VBQVEsT0FBTTtvQkFBYTtTQUFrQjs7Ozs7UUFDdkM7Ozs7OztNQUNMOzs7OztNQUdMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUNiLHdCQUFDLFVBQUQ7UUFDRSxPQUFPO1FBQ1AsV0FBVyxNQUFNO1NBQ2Ysa0JBQWtCLEVBQUUsT0FBTyxLQUErQjtTQUMxRCxlQUFlLENBQUM7UUFDbEI7UUFDQSxXQUFVO2tCQU5aO1NBUUUsd0JBQUMsVUFBRDtVQUFRLE9BQU07b0JBQUc7U0FBMEI7Ozs7O1NBQzNDLHdCQUFDLFVBQUQ7VUFBUSxPQUFNO29CQUFRO1NBQWE7Ozs7O1NBQ25DLHdCQUFDLFVBQUQ7VUFBUSxPQUFNO29CQUFVO1NBQWU7Ozs7O1NBQ3ZDLHdCQUFDLFVBQUQ7VUFBUSxPQUFNO29CQUFXO1NBQWdCOzs7OztRQUNuQzs7Ozs7O01BQ0w7Ozs7O0tBQ0Y7Ozs7O2NBR0osb0JBQ0Msd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLFFBQUQ7TUFBTTtNQUNtQjtNQUFlO01BQ3JDLG1CQUFtQixJQUFJLEtBQUs7TUFBSTtNQUFZLG1CQUFtQixJQUFJLEtBQUs7TUFBSTtLQUN6RTs7OztlQUNOLHdCQUFDLFVBQUQ7TUFDRSxNQUFLO01BQ0wsU0FBUztNQUNULFdBQVU7Z0JBQ1g7S0FFTzs7OzthQUNMOzs7OztZQUVKOzs7Ozs7R0FHTCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0csWUFDQyx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsT0FBRCxFQUFLLFdBQVUsdUZBQXdGOzs7O2VBQUMsNENBRXJHOzs7OztlQUNILGlCQUFpQixXQUFXLElBQzlCLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWY7TUFDRSx3QkFBQyxXQUFELEVBQVcsV0FBVSxzQ0FBdUM7Ozs7O01BQzVELHdCQUFDLEtBQUQ7T0FBRyxXQUFVO2lCQUFtRDtNQUU3RDs7Ozs7TUFDSCx3QkFBQyxLQUFEO09BQUcsV0FBVTtpQkFBOEM7TUFFeEQ7Ozs7O0tBQ0E7Ozs7O2VBRUwsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFDYix3QkFBQyxTQUFEO01BQU8sV0FBVTtnQkFBakIsQ0FDRSx3QkFBQyxTQUFEO09BQU8sV0FBVTtpQkFDZix3QkFBQyxNQUFEO1FBQ0Usd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQVk7UUFBYzs7Ozs7UUFDeEMsd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQVk7UUFBZ0M7Ozs7O1FBQzFELHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUFZO1FBQWlCOzs7OztRQUMzQyx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFBWTtRQUFzQjs7Ozs7UUFDaEQsd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQVk7UUFBc0I7Ozs7O1FBQ2hELHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUF1QjtRQUFTOzs7OztPQUM1Qzs7Ozs7TUFDQzs7OztnQkFDUCx3QkFBQyxTQUFEO09BQU8sV0FBVTtpQkFDZCxpQkFBaUIsS0FBSyxVQUNyQix3QkFBQyxNQUFEO1FBRUUsV0FBVTtrQkFGWjtTQUlFLHdCQUFDLE1BQUQ7VUFBSSxXQUFVO29CQUNYLE1BQU07U0FDTDs7Ozs7U0FFSix3QkFBQyxNQUFEO1VBQUksV0FBVTtvQkFBZCxDQUNFLHdCQUFDLE1BQUQ7V0FDRSxJQUFJLE9BQU8saUJBQWlCLFFBQVEsTUFBTSxFQUFFO1dBQzVDLFdBQVU7V0FDVixPQUFPLE1BQU07cUJBRVosTUFBTTtVQUNIOzs7O29CQUNOLHdCQUFDLFFBQUQ7V0FBTSxXQUFVO3FCQUNiLE1BQU0saUJBQWlCO1VBQ3BCOzs7O2tCQUNKOzs7Ozs7U0FFSix3QkFBQyxNQUFEO1VBQUksV0FBVTtvQkFDWix3QkFBQyxZQUFELEVBQVksT0FBTyxNQUFNLFlBQWM7Ozs7O1NBQ3JDOzs7OztTQUVKLHdCQUFDLE1BQUQ7VUFBSSxXQUFVO29CQUFkLENBQ0Usd0JBQUMscUJBQUQsRUFBcUIsVUFBVSxNQUFNLGdCQUFrQjs7OztvQkFDdEQsTUFBTSxpQkFDTCx3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFBaEIsQ0FBb0UsT0FDOUQsTUFBTSxhQUNOOzs7OztrQkFFTjs7Ozs7O1NBRUosd0JBQUMsTUFBRDtVQUFJLFdBQVU7b0JBQ1osd0JBQUMsUUFBRDtXQUNFLFdBQVcscUVBQ1QsTUFBTSw2QkFBNkIsVUFDL0IsbUdBQ0E7cUJBR0wsTUFBTTtVQUNIOzs7OztTQUNKOzs7OztTQUVKLHdCQUFDLE1BQUQ7VUFBSSxXQUFVO29CQUNaLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUFmO1lBQ0Usd0JBQUMsTUFBRDthQUNFLElBQUksT0FBTyxpQkFBaUIsUUFBUSxNQUFNLEVBQUU7YUFDNUMsV0FBVTthQUNWLE9BQU07dUJBRU4sd0JBQUMsS0FBRCxFQUFLLFdBQVUsVUFBVzs7Ozs7WUFDdEI7Ozs7O1lBRU4sd0JBQUMsTUFBRDthQUNFLElBQUksT0FBTyxpQkFBaUIsT0FBTyxNQUFNLEVBQUU7YUFDM0MsV0FBVTthQUNWLE9BQU07dUJBRU4sd0JBQUMsTUFBRCxFQUFNLFdBQVUsVUFBVzs7Ozs7WUFDdkI7Ozs7O1lBRU4sd0JBQUMsTUFBRDthQUNFLElBQUksR0FBRyxPQUFPLFVBQVUsS0FBSyxzQkFBc0IsTUFBTTthQUN6RCxXQUFVO2FBQ1YsT0FBTTt1QkFFTix3QkFBQyxnQkFBRCxFQUFnQixXQUFVLFVBQVc7Ozs7O1lBQ2pDOzs7OztXQUNIOzs7Ozs7U0FDSDs7Ozs7UUFDRjtVQXhFRyxNQUFNOzs7O2NBd0VULENBQ0w7TUFDSTs7OztjQUNGOzs7Ozs7SUFDSjs7OztjQUlOLGVBQWUsS0FDZCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsT0FBRDtNQUFLO01BQ087TUFDVix3QkFBQyxVQUFEO09BQVEsV0FBVTtrQkFDZCxjQUFjLEtBQUssbUJBQW1CO01BQ2xDOzs7OztNQUFFO01BQUk7TUFDWjtNQUNGLHdCQUFDLFVBQUQ7T0FBUSxXQUFVO2lCQUNmLEtBQUssSUFBSSxjQUFjLGtCQUFrQixjQUFjO01BQ2xEOzs7OztNQUFFO01BQUk7TUFDWCx3QkFBQyxVQUFEO09BQVEsV0FBVTtpQkFBZ0I7TUFBdUI7Ozs7O01BQUM7S0FDMUQ7Ozs7ZUFFTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZjtPQUNFLHdCQUFDLFVBQUQ7UUFDRSxNQUFLO1FBQ0wsZUFBZSxnQkFBZ0IsTUFBTSxLQUFLLElBQUksR0FBRyxJQUFJLENBQUMsQ0FBQztRQUN2RCxVQUFVLGdCQUFnQjtRQUMxQixXQUFVO2tCQUVWLHdCQUFDLGFBQUQsRUFBYSxXQUFVLFVBQVc7Ozs7O09BQzVCOzs7OztPQUVSLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUFoQjtTQUFtQztTQUN6QjtTQUFZO1NBQUs7UUFDckI7Ozs7OztPQUVOLHdCQUFDLFVBQUQ7UUFDRSxNQUFLO1FBQ0wsZUFBZSxnQkFBZ0IsTUFBTSxLQUFLLElBQUksY0FBYyxJQUFJLENBQUMsQ0FBQztRQUNsRSxVQUFVLGdCQUFnQjtRQUMxQixXQUFVO2tCQUVWLHdCQUFDLGNBQUQsRUFBYyxXQUFVLFVBQVc7Ozs7O09BQzdCOzs7OztNQUNMOzs7OzthQUNGOzs7OztZQUVKOzs7Ozs7RUFDRjs7Ozs7O0FBRVQ7Ozs7O0FBRUEsZUFBZSIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJFc3RhYmVsZWNpbWVudG9zTGlzdFBhZ2UudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbIi8qKlxyXG4gKiBMaXN0YWdlbSBQcmluY2lwYWwgZGUgRXN0YWJlbGVjaW1lbnRvcyBTYW5pdMOhcmlvcyAoRXN0YWJlbGVjaW1lbnRvc0xpc3RQYWdlKVxyXG4gKiBUYWJlbGEgZGVuc2EgZSByZXNwb25zaXZhIGNvbSBkZWJvdW5jZSBkZSBidXNjYSwgZmlsdHJvcyBjb21iaW5hZG9zIGRlIFJpc2NvIGUgU2l0dWHDp8OjbyxcclxuICogcGFnaW5hw6fDo28gZSBhdGFsaG9zIG9wZXJhY2lvbmFpcyBwYXJhIHZpc3VhbGl6YcOnw6NvIGRldGFsaGFkYSBlIGVkacOnw6NvLlxyXG4gKi9cclxuXHJcbmltcG9ydCBSZWFjdCwgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7IExpbmsgfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xyXG5pbXBvcnQge1xyXG4gIEJ1aWxkaW5nMixcclxuICBDaGV2cm9uTGVmdCxcclxuICBDaGV2cm9uUmlnaHQsXHJcbiAgQ2xpcGJvYXJkQ2hlY2ssXHJcbiAgRWRpdCxcclxuICBFeWUsXHJcbiAgRmlsdGVyLFxyXG4gIFBsdXMsXHJcbiAgUmVmcmVzaEN3LFxyXG4gIFNlYXJjaCxcclxuICBYLFxyXG59IGZyb20gXCJsdWNpZGUtcmVhY3RcIjtcclxuaW1wb3J0IHsgUk9VVEVTIH0gZnJvbSBcIi4uLy4uL2NvbmZpZy9yb3V0ZXMuY29uZmlnXCI7XHJcbmltcG9ydCBSaXNjb0JhZGdlIGZyb20gXCIuLi8uLi9jb21wb25lbnRzL2VzdGFiZWxlY2ltZW50b3MvUmlzY29CYWRnZVwiO1xyXG5pbXBvcnQgU2l0dWFjYW9BbHZhcmFCYWRnZSBmcm9tIFwiLi4vLi4vY29tcG9uZW50cy9lc3RhYmVsZWNpbWVudG9zL1NpdHVhY2FvQWx2YXJhQmFkZ2VcIjtcclxuaW1wb3J0IHsgdXNlRXN0YWJlbGVjaW1lbnRvc0xpc3QgfSBmcm9tIFwiLi4vLi4vaG9va3MvdXNlRXN0YWJlbGVjaW1lbnRvc1wiO1xyXG5pbXBvcnQge1xyXG4gIEVzdGFiZWxlY2ltZW50b0ZpbHRlcnMsXHJcbiAgTml2ZWxSaXNjbyxcclxuICBTaXR1YWNhb0NhZGFzdHJhbCxcclxufSBmcm9tIFwiLi4vLi4vdHlwZXMvZXN0YWJlbGVjaW1lbnRvXCI7XHJcblxyXG5jb25zdCBJVEVOU19QT1JfUEFHSU5BID0gMTU7XHJcblxyXG5leHBvcnQgY29uc3QgRXN0YWJlbGVjaW1lbnRvc0xpc3RQYWdlOiBSZWFjdC5GQyA9ICgpID0+IHtcclxuICBjb25zdCBbdGVybW9CdXNjYSwgc2V0VGVybW9CdXNjYV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbZGVib3VuY2VkQnVzY2EsIHNldERlYm91bmNlZEJ1c2NhXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtmaWx0cm9SaXNjbywgc2V0RmlsdHJvUmlzY29dID0gdXNlU3RhdGU8Tml2ZWxSaXNjbyB8IFwiXCI+KFwiXCIpO1xyXG4gIGNvbnN0IFtmaWx0cm9TaXR1YWNhbywgc2V0RmlsdHJvU2l0dWFjYW9dID0gdXNlU3RhdGU8U2l0dWFjYW9DYWRhc3RyYWwgfCBcIlwiPihcIlwiKTtcclxuICBjb25zdCBbcGFnaW5hQXR1YWwsIHNldFBhZ2luYUF0dWFsXSA9IHVzZVN0YXRlKDEpO1xyXG5cclxuICAvLyBEZWJvdW5jZSBkZSAzNTBtcyBuYSBidXNjYSB0ZXh0dWFsXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IHRpbWVyID0gc2V0VGltZW91dCgoKSA9PiB7XHJcbiAgICAgIHNldERlYm91bmNlZEJ1c2NhKHRlcm1vQnVzY2EpO1xyXG4gICAgICBzZXRQYWdpbmFBdHVhbCgxKTsgLy8gUmVzZXRhIHBhcmEgYSBwcmltZWlyYSBww6FnaW5hIGFvIGFsdGVyYXIgbyB0ZXJtb1xyXG4gICAgfSwgMzUwKTtcclxuICAgIHJldHVybiAoKSA9PiBjbGVhclRpbWVvdXQodGltZXIpO1xyXG4gIH0sIFt0ZXJtb0J1c2NhXSk7XHJcblxyXG4gIGNvbnN0IGZpbHRyb3M6IEVzdGFiZWxlY2ltZW50b0ZpbHRlcnMgPSB7XHJcbiAgICBidXNjYTogZGVib3VuY2VkQnVzY2EsXHJcbiAgICByaXNjbzogZmlsdHJvUmlzY28sXHJcbiAgICBzaXR1YWNhbzogZmlsdHJvU2l0dWFjYW8sXHJcbiAgICBza2lwOiAocGFnaW5hQXR1YWwgLSAxKSAqIElURU5TX1BPUl9QQUdJTkEsXHJcbiAgICBsaW1pdDogSVRFTlNfUE9SX1BBR0lOQSxcclxuICB9O1xyXG5cclxuICBjb25zdCB7IGRhdGEsIGlzTG9hZGluZywgaXNGZXRjaGluZywgcmVmZXRjaCB9ID0gdXNlRXN0YWJlbGVjaW1lbnRvc0xpc3QoZmlsdHJvcyk7XHJcblxyXG4gIGNvbnN0IGVzdGFiZWxlY2ltZW50b3MgPSBkYXRhPy5pdGVucyB8fCAoZGF0YSBhcyB7IGl0ZW1zPzogdHlwZW9mIGRhdGEgZXh0ZW5kcyB7IGl0ZW5zOiBpbmZlciBUIH0gPyBUIDogbmV2ZXIgfSB8IHVuZGVmaW5lZCk/Lml0ZW1zIHx8IFtdO1xyXG4gIGNvbnN0IHRvdGFsUmVnaXN0cm9zID0gZGF0YT8udG90YWwgfHwgMDtcclxuICBjb25zdCB0b3RhbFBhZ2luYXMgPSBNYXRoLmNlaWwodG90YWxSZWdpc3Ryb3MgLyBJVEVOU19QT1JfUEFHSU5BKSB8fCAxO1xyXG5cclxuICBjb25zdCBoYW5kbGVMaW1wYXJGaWx0cm9zID0gKCkgPT4ge1xyXG4gICAgc2V0VGVybW9CdXNjYShcIlwiKTtcclxuICAgIHNldERlYm91bmNlZEJ1c2NhKFwiXCIpO1xyXG4gICAgc2V0RmlsdHJvUmlzY28oXCJcIik7XHJcbiAgICBzZXRGaWx0cm9TaXR1YWNhbyhcIlwiKTtcclxuICAgIHNldFBhZ2luYUF0dWFsKDEpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IHRlbUZpbHRyb3NBdGl2b3MgPVxyXG4gICAgQm9vbGVhbih0ZXJtb0J1c2NhKSB8fCBCb29sZWFuKGZpbHRyb1Jpc2NvKSB8fCBCb29sZWFuKGZpbHRyb1NpdHVhY2FvKTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS01XCI+XHJcbiAgICAgIHsvKiBDYWJlw6dhbGhvIGRhIFDDoWdpbmEgKi99XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBzbTpmbGV4LXJvdyBzbTppdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC00IGJnLXdoaXRlIGRhcms6Ymctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLXhsIHAtNiBzaGFkb3cteHNcIj5cclxuICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMiBiZy10ZWFsLTUwIGRhcms6YmctdGVhbC05NTAvNDAgcm91bmRlZC1sZyB0ZXh0LXRlYWwtNjAwIGRhcms6dGV4dC10ZWFsLTQwMFwiPlxyXG4gICAgICAgICAgICAgIDxCdWlsZGluZzIgY2xhc3NOYW1lPVwidy01IGgtNVwiIC8+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC14bCBmb250LWJvbGQgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlXCI+XHJcbiAgICAgICAgICAgICAgRXN0YWJlbGVjaW1lbnRvcyBSZWd1bGFkb3NcclxuICAgICAgICAgICAgPC9oMT5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTUwMCBkYXJrOnRleHQtc2xhdGUtNDAwIG10LTFcIj5cclxuICAgICAgICAgICAgQ2FkYXN0cm8gZGUgZXN0YWJlbGVjaW1lbnRvcyBtdW5pY2lwYWlzIHN1amVpdG9zIMOgIGZpc2NhbGl6YcOnw6NvIGUgbGljZW5jaWFtZW50byBkYSBWSVNBLlxyXG4gICAgICAgICAgPC9wPlxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiByZWZldGNoKCl9XHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMiB0ZXh0LXNsYXRlLTYwMCBob3Zlcjp0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtc2xhdGUtNDAwIGRhcms6aG92ZXI6dGV4dC13aGl0ZSBiZy1zbGF0ZS0xMDAgZGFyazpiZy1zbGF0ZS04MDAgcm91bmRlZC1sZyBob3ZlcjpiZy1zbGF0ZS0yMDAgdHJhbnNpdGlvbi1jb2xvcnNcIlxyXG4gICAgICAgICAgICB0aXRsZT1cIlJlY2FycmVnYXIgZGFkb3NcIlxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICA8UmVmcmVzaEN3IGNsYXNzTmFtZT17YHctNCBoLTQgJHtpc0ZldGNoaW5nID8gXCJhbmltYXRlLXNwaW5cIiA6IFwiXCJ9YH0gLz5cclxuICAgICAgICAgIDwvYnV0dG9uPlxyXG5cclxuICAgICAgICAgIDxMaW5rXHJcbiAgICAgICAgICAgIHRvPXtST1VURVMuRVNUQUJFTEVDSU1FTlRPUy5OT1ZPfVxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBweC0zLjUgcHktMiB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC13aGl0ZSBiZy10ZWFsLTYwMCBob3ZlcjpiZy10ZWFsLTUwMCByb3VuZGVkLWxnIHNoYWRvdy14cyB0cmFuc2l0aW9uLWNvbG9yc1wiXHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIDxQbHVzIGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPlxyXG4gICAgICAgICAgICA8c3Bhbj5Ob3ZvIEVzdGFiZWxlY2ltZW50bzwvc3Bhbj5cclxuICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICB7LyogQmFycmEgZGUgRmlsdHJvcyBlIEJ1c2NhIFLDoXBpZGEgY29tIERlYm91bmNlICovfVxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIGRhcms6Ymctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLXhsIHAtNCBzaGFkb3cteHMgc3BhY2UteS0zXCI+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIHNtOmdyaWQtY29scy0xMiBnYXAtM1wiPlxyXG4gICAgICAgICAgey8qIEJ1c2NhIFRleHR1YWwgKi99XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNtOmNvbC1zcGFuLTYgcmVsYXRpdmVcIj5cclxuICAgICAgICAgICAgPFNlYXJjaCBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtc2xhdGUtNDAwIGFic29sdXRlIGxlZnQtMyB0b3AtMS8yIC10cmFuc2xhdGUteS0xLzJcIiAvPlxyXG4gICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgdmFsdWU9e3Rlcm1vQnVzY2F9XHJcbiAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRUZXJtb0J1c2NhKGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkJ1c2NhciBwb3IgQ05QSi9DUEYsIFJhesOjbyBTb2NpYWwgb3UgTm9tZSBGYW50YXNpYS4uLlwiXHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHBsLTkgcHItOCBweS0yIGJnLXNsYXRlLTUwIGRhcms6Ymctc2xhdGUtODAwIGJvcmRlciBib3JkZXItc2xhdGUtMzAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCByb3VuZGVkLWxnIHRleHQteHMgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlIHBsYWNlaG9sZGVyLXNsYXRlLTQwMCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctdGVhbC01MDBcIlxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICB7dGVybW9CdXNjYSAmJiAoXHJcbiAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRUZXJtb0J1c2NhKFwiXCIpfVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYWJzb2x1dGUgcmlnaHQtMi41IHRvcC0xLzIgLXRyYW5zbGF0ZS15LTEvMiB0ZXh0LXNsYXRlLTQwMCBob3Zlcjp0ZXh0LXNsYXRlLTYwMFwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPFggY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPlxyXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICApfVxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgey8qIEZpbHRybyBwb3IgUmlzY28gU2FuaXTDoXJpbyAqL31cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic206Y29sLXNwYW4tM1wiPlxyXG4gICAgICAgICAgICA8c2VsZWN0XHJcbiAgICAgICAgICAgICAgdmFsdWU9e2ZpbHRyb1Jpc2NvfVxyXG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgc2V0RmlsdHJvUmlzY28oZS50YXJnZXQudmFsdWUgYXMgTml2ZWxSaXNjbyB8IFwiXCIpO1xyXG4gICAgICAgICAgICAgICAgc2V0UGFnaW5hQXR1YWwoMSk7XHJcbiAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHktMiBweC0zIGJnLXNsYXRlLTUwIGRhcms6Ymctc2xhdGUtODAwIGJvcmRlciBib3JkZXItc2xhdGUtMzAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCByb3VuZGVkLWxnIHRleHQteHMgdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTIwMCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctdGVhbC01MDBcIlxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlwiPlRvZG9zIG9zIE7DrXZlaXMgZGUgUmlzY288L29wdGlvbj5cclxuICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiUmlzY28gSUlJXCI+UmlzY28gSUlJIChBbHRvKTwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJSaXNjbyBJSVwiPlJpc2NvIElJIChNw6lkaW8pPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlJpc2NvIElcIj5SaXNjbyBJIChCYWl4byk8L29wdGlvbj5cclxuICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiRGlzcGVuc2Fkb1wiPkRpc3BlbnNhZG88L29wdGlvbj5cclxuICAgICAgICAgICAgPC9zZWxlY3Q+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICB7LyogRmlsdHJvIHBvciBTaXR1YcOnw6NvIENhZGFzdHJhbCAqL31cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic206Y29sLXNwYW4tM1wiPlxyXG4gICAgICAgICAgICA8c2VsZWN0XHJcbiAgICAgICAgICAgICAgdmFsdWU9e2ZpbHRyb1NpdHVhY2FvfVxyXG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgc2V0RmlsdHJvU2l0dWFjYW8oZS50YXJnZXQudmFsdWUgYXMgU2l0dWFjYW9DYWRhc3RyYWwgfCBcIlwiKTtcclxuICAgICAgICAgICAgICAgIHNldFBhZ2luYUF0dWFsKDEpO1xyXG4gICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB5LTIgcHgtMyBiZy1zbGF0ZS01MCBkYXJrOmJnLXNsYXRlLTgwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTMwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC1sZyB0ZXh0LXhzIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0yMDAgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLXRlYWwtNTAwXCJcclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJcIj5Ub2RhcyBhcyBTaXR1YcOnw7Vlczwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJBdGl2b1wiPkF0aXZvPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIkluYXRpdm9cIj5JbmF0aXZvPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlN1c3BlbnNvXCI+U3VzcGVuc288L29wdGlvbj5cclxuICAgICAgICAgICAgPC9zZWxlY3Q+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgey8qIEluZGljYWRvciBkZSBGaWx0cm9zIEF0aXZvcyAqL31cclxuICAgICAgICB7dGVtRmlsdHJvc0F0aXZvcyAmJiAoXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBwdC0yIGJvcmRlci10IGJvcmRlci1zbGF0ZS0xMDAgZGFyazpib3JkZXItc2xhdGUtODAwIHRleHQtWzExcHhdIHRleHQtc2xhdGUtNTAwXCI+XHJcbiAgICAgICAgICAgIDxzcGFuPlxyXG4gICAgICAgICAgICAgIEZpbHRyYW5kbyByZXN1bHRhZG9zICh7dG90YWxSZWdpc3Ryb3N9IGVzdGFiZWxlY2ltZW50b1xyXG4gICAgICAgICAgICAgIHt0b3RhbFJlZ2lzdHJvcyA9PT0gMSA/IFwiXCIgOiBcInNcIn0gZW5jb250cmFkb3t0b3RhbFJlZ2lzdHJvcyA9PT0gMSA/IFwiXCIgOiBcInNcIn0pXHJcbiAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZUxpbXBhckZpbHRyb3N9XHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC10ZWFsLTYwMCBob3Zlcjp0ZXh0LXRlYWwtNzAwIGRhcms6dGV4dC10ZWFsLTQwMCBmb250LXNlbWlib2xkXCJcclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIExpbXBhciBGaWx0cm9zXHJcbiAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgKX1cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICB7LyogVGFiZWxhIGRlIEVzdGFiZWxlY2ltZW50b3MgKi99XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGFyazpiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtODAwIHJvdW5kZWQteGwgb3ZlcmZsb3ctaGlkZGVuIHNoYWRvdy14c1wiPlxyXG4gICAgICAgIHtpc0xvYWRpbmcgPyAoXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMTYgdGV4dC1jZW50ZXIgdGV4dC14cyB0ZXh0LXNsYXRlLTQwMCBmbGV4IGZsZXgtY29sIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlclwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctNiBoLTYgYm9yZGVyLTIgYm9yZGVyLXRlYWwtNTAwIGJvcmRlci10LXRyYW5zcGFyZW50IHJvdW5kZWQtZnVsbCBhbmltYXRlLXNwaW4gbWItM1wiIC8+XHJcbiAgICAgICAgICAgIENhcnJlZ2FuZG8gY2FkYXN0cm8gZGUgZXN0YWJlbGVjaW1lbnRvcy4uLlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgKSA6IGVzdGFiZWxlY2ltZW50b3MubGVuZ3RoID09PSAwID8gKFxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTE2IHRleHQtY2VudGVyIHRleHQteHMgdGV4dC1zbGF0ZS01MDAgZGFyazp0ZXh0LXNsYXRlLTQwMCBzcGFjZS15LTJcIj5cclxuICAgICAgICAgICAgPEJ1aWxkaW5nMiBjbGFzc05hbWU9XCJ3LTggaC04IHRleHQtc2xhdGUtMzAwIG14LWF1dG8gbWItMlwiIC8+XHJcbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTIwMFwiPlxyXG4gICAgICAgICAgICAgIE5lbmh1bSBlc3RhYmVsZWNpbWVudG8gZW5jb250cmFkby5cclxuICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LXNsYXRlLTQwMCBtYXgtdy1zbSBteC1hdXRvXCI+XHJcbiAgICAgICAgICAgICAgVmVyaWZpcXVlIG9zIGZpbHRyb3MgaW5mb3JtYWRvcyBvdSByZWFsaXplIHVtIG5vdm8gY2FkYXN0cm8gY2xpY2FuZG8gbm8gYm90w6NvIGFjaW1hLlxyXG4gICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICApIDogKFxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJvdmVyZmxvdy14LWF1dG9cIj5cclxuICAgICAgICAgICAgPHRhYmxlIGNsYXNzTmFtZT1cInctZnVsbCB0ZXh0LWxlZnQgdGV4dC14c1wiPlxyXG4gICAgICAgICAgICAgIDx0aGVhZCBjbGFzc05hbWU9XCJiZy1zbGF0ZS01MCBkYXJrOmJnLXNsYXRlLTgwMC82MCBib3JkZXItYiBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCB0ZXh0LXNsYXRlLTUwMCBmb250LXNlbWlib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LVsxMXB4XVwiPlxyXG4gICAgICAgICAgICAgICAgPHRyPlxyXG4gICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMyBweC00XCI+Q05QSiAvIENQRjwvdGg+XHJcbiAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0zIHB4LTRcIj5SYXrDo28gU29jaWFsIC8gTm9tZSBGYW50YXNpYTwvdGg+XHJcbiAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0zIHB4LTRcIj5HcmF1IGRlIFJpc2NvPC90aD5cclxuICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB5LTMgcHgtNFwiPlNpdHVhw6fDo28gZG8gQWx2YXLDoTwvdGg+XHJcbiAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0zIHB4LTRcIj5TaXR1YcOnw6NvIENhZGFzdHJhbDwvdGg+XHJcbiAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0zIHB4LTQgdGV4dC1yaWdodFwiPkHDp8O1ZXM8L3RoPlxyXG4gICAgICAgICAgICAgICAgPC90cj5cclxuICAgICAgICAgICAgICA8L3RoZWFkPlxyXG4gICAgICAgICAgICAgIDx0Ym9keSBjbGFzc05hbWU9XCJkaXZpZGUteSBkaXZpZGUtc2xhdGUtMTAwIGRhcms6ZGl2aWRlLXNsYXRlLTgwMFwiPlxyXG4gICAgICAgICAgICAgICAge2VzdGFiZWxlY2ltZW50b3MubWFwKChlc3RhYikgPT4gKFxyXG4gICAgICAgICAgICAgICAgICA8dHJcclxuICAgICAgICAgICAgICAgICAgICBrZXk9e2VzdGFiLmlkfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImhvdmVyOmJnLXNsYXRlLTUwLzYwIGRhcms6aG92ZXI6Ymctc2xhdGUtODAwLzQwIHRyYW5zaXRpb24tY29sb3JzXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS0zIHB4LTQgZm9udC1tb25vIGZvbnQtbWVkaXVtIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0zMDAgd2hpdGVzcGFjZS1ub3dyYXBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtlc3RhYi5jbnBqX2NwZn1cclxuICAgICAgICAgICAgICAgICAgICA8L3RkPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMyBweC00IG1heC13LXhzXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8TGlua1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0bz17Uk9VVEVTLkVTVEFCRUxFQ0lNRU5UT1MuREVUQUxIRShlc3RhYi5pZCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlIGhvdmVyOnRleHQtdGVhbC02MDAgZGFyazpob3Zlcjp0ZXh0LXRlYWwtNDAwIGJsb2NrIHRydW5jYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU9e2VzdGFiLnJhemFvX3NvY2lhbH1cclxuICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2VzdGFiLnJhemFvX3NvY2lhbH1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtc2xhdGUtNDAwIGJsb2NrIHRydW5jYXRlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtlc3RhYi5ub21lX2ZhbnRhc2lhIHx8IFwiU2VtIG5vbWUgZmFudGFzaWEgcmVnaXN0cmFkb1wifVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS0zIHB4LTQgd2hpdGVzcGFjZS1ub3dyYXBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxSaXNjb0JhZGdlIHJpc2NvPXtlc3RhYi5uaXZlbF9yaXNjb30gLz5cclxuICAgICAgICAgICAgICAgICAgICA8L3RkPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMyBweC00IHdoaXRlc3BhY2Utbm93cmFwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8U2l0dWFjYW9BbHZhcmFCYWRnZSBzaXR1YWNhbz17ZXN0YWIuc2l0dWFjYW9fYWx2YXJhfSAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2VzdGFiLm51bWVyb19hbHZhcmEgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJibG9jayB0ZXh0LVsxMHB4XSBmb250LW1vbm8gdGV4dC1zbGF0ZS00MDAgbXQtMC41XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgTsK6IHtlc3RhYi5udW1lcm9fYWx2YXJhfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS0zIHB4LTQgd2hpdGVzcGFjZS1ub3dyYXBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGlubGluZS1ibG9jayBweC0yIHB5LTAuNSByb3VuZGVkIHRleHQtWzEwcHhdIGZvbnQtc2VtaWJvbGQgYm9yZGVyICR7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZXN0YWIuc2l0dWFjYW9fZXN0YWJlbGVjaW1lbnRvID09PSBcIkF0aXZvXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gXCJiZy1lbWVyYWxkLTUwIHRleHQtZW1lcmFsZC03MDAgYm9yZGVyLWVtZXJhbGQtMjAwIGRhcms6YmctZW1lcmFsZC05NTAvNDAgZGFyazp0ZXh0LWVtZXJhbGQtMzAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogXCJiZy1zbGF0ZS0xMDAgdGV4dC1zbGF0ZS02MDAgYm9yZGVyLXNsYXRlLTIwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7ZXN0YWIuc2l0dWFjYW9fZXN0YWJlbGVjaW1lbnRvfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS0zIHB4LTQgdGV4dC1yaWdodCB3aGl0ZXNwYWNlLW5vd3JhcFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8TGlua1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHRvPXtST1VURVMuRVNUQUJFTEVDSU1FTlRPUy5ERVRBTEhFKGVzdGFiLmlkKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTEuNSB0ZXh0LXNsYXRlLTYwMCBob3Zlcjp0ZXh0LXRlYWwtNjAwIGhvdmVyOmJnLXNsYXRlLTEwMCBkYXJrOmhvdmVyOmJnLXNsYXRlLTgwMCByb3VuZGVkIHRyYW5zaXRpb24tY29sb3JzXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB0aXRsZT1cIlZpc3VhbGl6YXIgRmljaGEgQ29tcGxldGFcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPEV5ZSBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9MaW5rPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPExpbmtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB0bz17Uk9VVEVTLkVTVEFCRUxFQ0lNRU5UT1MuRURJVEFSKGVzdGFiLmlkKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTEuNSB0ZXh0LXNsYXRlLTYwMCBob3Zlcjp0ZXh0LWJsdWUtNjAwIGhvdmVyOmJnLXNsYXRlLTEwMCBkYXJrOmhvdmVyOmJnLXNsYXRlLTgwMCByb3VuZGVkIHRyYW5zaXRpb24tY29sb3JzXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB0aXRsZT1cIkVkaXRhciBDYWRhc3Ryb1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8RWRpdCBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9MaW5rPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPExpbmtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB0bz17YCR7Uk9VVEVTLklOU1BFQ09FUy5MSVNUfT9lc3RhYmVsZWNpbWVudG9faWQ9JHtlc3RhYi5pZH1gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMS41IHRleHQtc2xhdGUtNjAwIGhvdmVyOnRleHQtcHVycGxlLTYwMCBob3ZlcjpiZy1zbGF0ZS0xMDAgZGFyazpob3ZlcjpiZy1zbGF0ZS04MDAgcm91bmRlZCB0cmFuc2l0aW9uLWNvbG9yc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU9XCJGaXNjYWxpemHDp8O1ZXMgZGVzdGUgZXN0YWJlbGVjaW1lbnRvXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxDbGlwYm9hcmRDaGVjayBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICAgICAgICAgICAgPC90cj5cclxuICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgIDwvdGJvZHk+XHJcbiAgICAgICAgICAgIDwvdGFibGU+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICApfVxyXG5cclxuICAgICAgICB7LyogUGFnaW5hw6fDo28gKi99XHJcbiAgICAgICAge3RvdGFsUGFnaW5hcyA+IDEgJiYgKFxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTMgYmctc2xhdGUtNTAgZGFyazpiZy1zbGF0ZS04MDAvNDAgYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHRleHQteHMgdGV4dC1zbGF0ZS01MDBcIj5cclxuICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICBNb3N0cmFuZG97XCIgXCJ9XHJcbiAgICAgICAgICAgICAgPHN0cm9uZyBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMzAwXCI+XHJcbiAgICAgICAgICAgICAgICB7KHBhZ2luYUF0dWFsIC0gMSkgKiBJVEVOU19QT1JfUEFHSU5BICsgMX1cclxuICAgICAgICAgICAgICA8L3N0cm9uZz57XCIgXCJ9XHJcbiAgICAgICAgICAgICAgYXtcIiBcIn1cclxuICAgICAgICAgICAgICA8c3Ryb25nIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0zMDBcIj5cclxuICAgICAgICAgICAgICAgIHtNYXRoLm1pbihwYWdpbmFBdHVhbCAqIElURU5TX1BPUl9QQUdJTkEsIHRvdGFsUmVnaXN0cm9zKX1cclxuICAgICAgICAgICAgICA8L3N0cm9uZz57XCIgXCJ9XHJcbiAgICAgICAgICAgICAgZGUgPHN0cm9uZyBjbGFzc05hbWU9XCJ0YWJ1bGFyLW51bXNcIj57dG90YWxSZWdpc3Ryb3N9PC9zdHJvbmc+IHJlZ2lzdHJvc1xyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTFcIj5cclxuICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFBhZ2luYUF0dWFsKChwKSA9PiBNYXRoLm1heCgxLCBwIC0gMSkpfVxyXG4gICAgICAgICAgICAgICAgZGlzYWJsZWQ9e3BhZ2luYUF0dWFsID09PSAxfVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0xLjUgcm91bmRlZCBib3JkZXIgYm9yZGVyLXNsYXRlLTMwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgaG92ZXI6Ymctd2hpdGUgZGFyazpob3ZlcjpiZy1zbGF0ZS03MDAgZGlzYWJsZWQ6b3BhY2l0eS00MCB0cmFuc2l0aW9uLWNvbG9yc1wiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPENoZXZyb25MZWZ0IGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPlxyXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG5cclxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJweC0yIGZvbnQtbWVkaXVtXCI+XHJcbiAgICAgICAgICAgICAgICBQw6FnaW5hIHtwYWdpbmFBdHVhbH0gZGUge3RvdGFsUGFnaW5hc31cclxuICAgICAgICAgICAgICA8L3NwYW4+XHJcblxyXG4gICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0UGFnaW5hQXR1YWwoKHApID0+IE1hdGgubWluKHRvdGFsUGFnaW5hcywgcCArIDEpKX1cclxuICAgICAgICAgICAgICAgIGRpc2FibGVkPXtwYWdpbmFBdHVhbCA9PT0gdG90YWxQYWdpbmFzfVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0xLjUgcm91bmRlZCBib3JkZXIgYm9yZGVyLXNsYXRlLTMwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgaG92ZXI6Ymctd2hpdGUgZGFyazpob3ZlcjpiZy1zbGF0ZS03MDAgZGlzYWJsZWQ6b3BhY2l0eS00MCB0cmFuc2l0aW9uLWNvbG9yc1wiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPENoZXZyb25SaWdodCBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz5cclxuICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICApfVxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBFc3RhYmVsZWNpbWVudG9zTGlzdFBhZ2U7XHJcbiJdfQ==