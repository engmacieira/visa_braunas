import { r as __toESM } from "/node_modules/.vite/deps/rolldown-runtime-SbdDWaPq.js?v=0fd2848a";
import { t as require_react } from "/node_modules/.vite/deps/react-4hkZzRew.js?v=0fd2848a";
// node_modules/qrcode.react/lib/esm/index.js
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var __defProp = Object.defineProperty;
var __getOwnPropSymbols = Object.getOwnPropertySymbols;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __propIsEnum = Object.prototype.propertyIsEnumerable;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, {
	enumerable: true,
	configurable: true,
	writable: true,
	value
}) : obj[key] = value;
var __spreadValues = (a, b) => {
	for (var prop in b || (b = {})) if (__hasOwnProp.call(b, prop)) __defNormalProp(a, prop, b[prop]);
	if (__getOwnPropSymbols) {
		for (var prop of __getOwnPropSymbols(b)) if (__propIsEnum.call(b, prop)) __defNormalProp(a, prop, b[prop]);
	}
	return a;
};
var __objRest = (source, exclude) => {
	var target = {};
	for (var prop in source) if (__hasOwnProp.call(source, prop) && exclude.indexOf(prop) < 0) target[prop] = source[prop];
	if (source != null && __getOwnPropSymbols) {
		for (var prop of __getOwnPropSymbols(source)) if (exclude.indexOf(prop) < 0 && __propIsEnum.call(source, prop)) target[prop] = source[prop];
	}
	return target;
};
/**
* @license QR Code generator library (TypeScript)
* Copyright (c) Project Nayuki.
* SPDX-License-Identifier: MIT
*/
var qrcodegen;
((qrcodegen2) => {
	const _QrCode = class _QrCode {
		constructor(version, errorCorrectionLevel, dataCodewords, msk) {
			this.version = version;
			this.errorCorrectionLevel = errorCorrectionLevel;
			this.modules = [];
			this.isFunction = [];
			if (version < _QrCode.MIN_VERSION || version > _QrCode.MAX_VERSION) throw new RangeError("Version value out of range");
			if (msk < -1 || msk > 7) throw new RangeError("Mask value out of range");
			this.size = version * 4 + 17;
			let row = [];
			for (let i = 0; i < this.size; i++) row.push(false);
			for (let i = 0; i < this.size; i++) {
				this.modules.push(row.slice());
				this.isFunction.push(row.slice());
			}
			this.drawFunctionPatterns();
			const allCodewords = this.addEccAndInterleave(dataCodewords);
			this.drawCodewords(allCodewords);
			if (msk == -1) {
				let minPenalty = 1e9;
				for (let i = 0; i < 8; i++) {
					this.applyMask(i);
					this.drawFormatBits(i);
					const penalty = this.getPenaltyScore();
					if (penalty < minPenalty) {
						msk = i;
						minPenalty = penalty;
					}
					this.applyMask(i);
				}
			}
			assert(0 <= msk && msk <= 7);
			this.mask = msk;
			this.applyMask(msk);
			this.drawFormatBits(msk);
			this.isFunction = [];
		}
		static encodeText(text, ecl) {
			const segs = qrcodegen2.QrSegment.makeSegments(text);
			return _QrCode.encodeSegments(segs, ecl);
		}
		static encodeBinary(data, ecl) {
			const seg = qrcodegen2.QrSegment.makeBytes(data);
			return _QrCode.encodeSegments([seg], ecl);
		}
		static encodeSegments(segs, ecl, minVersion = 1, maxVersion = 40, mask = -1, boostEcl = true) {
			if (!(_QrCode.MIN_VERSION <= minVersion && minVersion <= maxVersion && maxVersion <= _QrCode.MAX_VERSION) || mask < -1 || mask > 7) throw new RangeError("Invalid value");
			let version;
			let dataUsedBits;
			for (version = minVersion;; version++) {
				const dataCapacityBits2 = _QrCode.getNumDataCodewords(version, ecl) * 8;
				const usedBits = QrSegment.getTotalBits(segs, version);
				if (usedBits <= dataCapacityBits2) {
					dataUsedBits = usedBits;
					break;
				}
				if (version >= maxVersion) throw new RangeError("Data too long");
			}
			for (const newEcl of [
				_QrCode.Ecc.MEDIUM,
				_QrCode.Ecc.QUARTILE,
				_QrCode.Ecc.HIGH
			]) if (boostEcl && dataUsedBits <= _QrCode.getNumDataCodewords(version, newEcl) * 8) ecl = newEcl;
			let bb = [];
			for (const seg of segs) {
				appendBits(seg.mode.modeBits, 4, bb);
				appendBits(seg.numChars, seg.mode.numCharCountBits(version), bb);
				for (const b of seg.getData()) bb.push(b);
			}
			assert(bb.length == dataUsedBits);
			const dataCapacityBits = _QrCode.getNumDataCodewords(version, ecl) * 8;
			assert(bb.length <= dataCapacityBits);
			appendBits(0, Math.min(4, dataCapacityBits - bb.length), bb);
			appendBits(0, (8 - bb.length % 8) % 8, bb);
			assert(bb.length % 8 == 0);
			for (let padByte = 236; bb.length < dataCapacityBits; padByte ^= 253) appendBits(padByte, 8, bb);
			let dataCodewords = [];
			while (dataCodewords.length * 8 < bb.length) dataCodewords.push(0);
			bb.forEach((b, i) => dataCodewords[i >>> 3] |= b << 7 - (i & 7));
			return new _QrCode(version, ecl, dataCodewords, mask);
		}
		getModule(x, y) {
			return 0 <= x && x < this.size && 0 <= y && y < this.size && this.modules[y][x];
		}
		getModules() {
			return this.modules;
		}
		drawFunctionPatterns() {
			for (let i = 0; i < this.size; i++) {
				this.setFunctionModule(6, i, i % 2 == 0);
				this.setFunctionModule(i, 6, i % 2 == 0);
			}
			this.drawFinderPattern(3, 3);
			this.drawFinderPattern(this.size - 4, 3);
			this.drawFinderPattern(3, this.size - 4);
			const alignPatPos = this.getAlignmentPatternPositions();
			const numAlign = alignPatPos.length;
			for (let i = 0; i < numAlign; i++) for (let j = 0; j < numAlign; j++) if (!(i == 0 && j == 0 || i == 0 && j == numAlign - 1 || i == numAlign - 1 && j == 0)) this.drawAlignmentPattern(alignPatPos[i], alignPatPos[j]);
			this.drawFormatBits(0);
			this.drawVersion();
		}
		drawFormatBits(mask) {
			const data = this.errorCorrectionLevel.formatBits << 3 | mask;
			let rem = data;
			for (let i = 0; i < 10; i++) rem = rem << 1 ^ (rem >>> 9) * 1335;
			const bits = (data << 10 | rem) ^ 21522;
			assert(bits >>> 15 == 0);
			for (let i = 0; i <= 5; i++) this.setFunctionModule(8, i, getBit(bits, i));
			this.setFunctionModule(8, 7, getBit(bits, 6));
			this.setFunctionModule(8, 8, getBit(bits, 7));
			this.setFunctionModule(7, 8, getBit(bits, 8));
			for (let i = 9; i < 15; i++) this.setFunctionModule(14 - i, 8, getBit(bits, i));
			for (let i = 0; i < 8; i++) this.setFunctionModule(this.size - 1 - i, 8, getBit(bits, i));
			for (let i = 8; i < 15; i++) this.setFunctionModule(8, this.size - 15 + i, getBit(bits, i));
			this.setFunctionModule(8, this.size - 8, true);
		}
		drawVersion() {
			if (this.version < 7) return;
			let rem = this.version;
			for (let i = 0; i < 12; i++) rem = rem << 1 ^ (rem >>> 11) * 7973;
			const bits = this.version << 12 | rem;
			assert(bits >>> 18 == 0);
			for (let i = 0; i < 18; i++) {
				const color = getBit(bits, i);
				const a = this.size - 11 + i % 3;
				const b = Math.floor(i / 3);
				this.setFunctionModule(a, b, color);
				this.setFunctionModule(b, a, color);
			}
		}
		drawFinderPattern(x, y) {
			for (let dy = -4; dy <= 4; dy++) for (let dx = -4; dx <= 4; dx++) {
				const dist = Math.max(Math.abs(dx), Math.abs(dy));
				const xx = x + dx;
				const yy = y + dy;
				if (0 <= xx && xx < this.size && 0 <= yy && yy < this.size) this.setFunctionModule(xx, yy, dist != 2 && dist != 4);
			}
		}
		drawAlignmentPattern(x, y) {
			for (let dy = -2; dy <= 2; dy++) for (let dx = -2; dx <= 2; dx++) this.setFunctionModule(x + dx, y + dy, Math.max(Math.abs(dx), Math.abs(dy)) != 1);
		}
		setFunctionModule(x, y, isDark) {
			this.modules[y][x] = isDark;
			this.isFunction[y][x] = true;
		}
		addEccAndInterleave(data) {
			const ver = this.version;
			const ecl = this.errorCorrectionLevel;
			if (data.length != _QrCode.getNumDataCodewords(ver, ecl)) throw new RangeError("Invalid argument");
			const numBlocks = _QrCode.NUM_ERROR_CORRECTION_BLOCKS[ecl.ordinal][ver];
			const blockEccLen = _QrCode.ECC_CODEWORDS_PER_BLOCK[ecl.ordinal][ver];
			const rawCodewords = Math.floor(_QrCode.getNumRawDataModules(ver) / 8);
			const numShortBlocks = numBlocks - rawCodewords % numBlocks;
			const shortBlockLen = Math.floor(rawCodewords / numBlocks);
			let blocks = [];
			const rsDiv = _QrCode.reedSolomonComputeDivisor(blockEccLen);
			for (let i = 0, k = 0; i < numBlocks; i++) {
				let dat = data.slice(k, k + shortBlockLen - blockEccLen + (i < numShortBlocks ? 0 : 1));
				k += dat.length;
				const ecc = _QrCode.reedSolomonComputeRemainder(dat, rsDiv);
				if (i < numShortBlocks) dat.push(0);
				blocks.push(dat.concat(ecc));
			}
			let result = [];
			for (let i = 0; i < blocks[0].length; i++) blocks.forEach((block, j) => {
				if (i != shortBlockLen - blockEccLen || j >= numShortBlocks) result.push(block[i]);
			});
			assert(result.length == rawCodewords);
			return result;
		}
		drawCodewords(data) {
			if (data.length != Math.floor(_QrCode.getNumRawDataModules(this.version) / 8)) throw new RangeError("Invalid argument");
			let i = 0;
			for (let right = this.size - 1; right >= 1; right -= 2) {
				if (right == 6) right = 5;
				for (let vert = 0; vert < this.size; vert++) for (let j = 0; j < 2; j++) {
					const x = right - j;
					const y = (right + 1 & 2) == 0 ? this.size - 1 - vert : vert;
					if (!this.isFunction[y][x] && i < data.length * 8) {
						this.modules[y][x] = getBit(data[i >>> 3], 7 - (i & 7));
						i++;
					}
				}
			}
			assert(i == data.length * 8);
		}
		applyMask(mask) {
			if (mask < 0 || mask > 7) throw new RangeError("Mask value out of range");
			for (let y = 0; y < this.size; y++) for (let x = 0; x < this.size; x++) {
				let invert;
				switch (mask) {
					case 0:
						invert = (x + y) % 2 == 0;
						break;
					case 1:
						invert = y % 2 == 0;
						break;
					case 2:
						invert = x % 3 == 0;
						break;
					case 3:
						invert = (x + y) % 3 == 0;
						break;
					case 4:
						invert = (Math.floor(x / 3) + Math.floor(y / 2)) % 2 == 0;
						break;
					case 5:
						invert = x * y % 2 + x * y % 3 == 0;
						break;
					case 6:
						invert = (x * y % 2 + x * y % 3) % 2 == 0;
						break;
					case 7:
						invert = ((x + y) % 2 + x * y % 3) % 2 == 0;
						break;
					default: throw new Error("Unreachable");
				}
				if (!this.isFunction[y][x] && invert) this.modules[y][x] = !this.modules[y][x];
			}
		}
		getPenaltyScore() {
			let result = 0;
			for (let y = 0; y < this.size; y++) {
				let runColor = false;
				let runX = 0;
				let runHistory = [
					0,
					0,
					0,
					0,
					0,
					0,
					0
				];
				for (let x = 0; x < this.size; x++) if (this.modules[y][x] == runColor) {
					runX++;
					if (runX == 5) result += _QrCode.PENALTY_N1;
					else if (runX > 5) result++;
				} else {
					this.finderPenaltyAddHistory(runX, runHistory);
					if (!runColor) result += this.finderPenaltyCountPatterns(runHistory) * _QrCode.PENALTY_N3;
					runColor = this.modules[y][x];
					runX = 1;
				}
				result += this.finderPenaltyTerminateAndCount(runColor, runX, runHistory) * _QrCode.PENALTY_N3;
			}
			for (let x = 0; x < this.size; x++) {
				let runColor = false;
				let runY = 0;
				let runHistory = [
					0,
					0,
					0,
					0,
					0,
					0,
					0
				];
				for (let y = 0; y < this.size; y++) if (this.modules[y][x] == runColor) {
					runY++;
					if (runY == 5) result += _QrCode.PENALTY_N1;
					else if (runY > 5) result++;
				} else {
					this.finderPenaltyAddHistory(runY, runHistory);
					if (!runColor) result += this.finderPenaltyCountPatterns(runHistory) * _QrCode.PENALTY_N3;
					runColor = this.modules[y][x];
					runY = 1;
				}
				result += this.finderPenaltyTerminateAndCount(runColor, runY, runHistory) * _QrCode.PENALTY_N3;
			}
			for (let y = 0; y < this.size - 1; y++) for (let x = 0; x < this.size - 1; x++) {
				const color = this.modules[y][x];
				if (color == this.modules[y][x + 1] && color == this.modules[y + 1][x] && color == this.modules[y + 1][x + 1]) result += _QrCode.PENALTY_N2;
			}
			let dark = 0;
			for (const row of this.modules) dark = row.reduce((sum, color) => sum + (color ? 1 : 0), dark);
			const total = this.size * this.size;
			const k = Math.ceil(Math.abs(dark * 20 - total * 10) / total) - 1;
			assert(0 <= k && k <= 9);
			result += k * _QrCode.PENALTY_N4;
			assert(0 <= result && result <= 2568888);
			return result;
		}
		getAlignmentPatternPositions() {
			if (this.version == 1) return [];
			else {
				const numAlign = Math.floor(this.version / 7) + 2;
				const step = this.version == 32 ? 26 : Math.ceil((this.version * 4 + 4) / (numAlign * 2 - 2)) * 2;
				let result = [6];
				for (let pos = this.size - 7; result.length < numAlign; pos -= step) result.splice(1, 0, pos);
				return result;
			}
		}
		static getNumRawDataModules(ver) {
			if (ver < _QrCode.MIN_VERSION || ver > _QrCode.MAX_VERSION) throw new RangeError("Version number out of range");
			let result = (16 * ver + 128) * ver + 64;
			if (ver >= 2) {
				const numAlign = Math.floor(ver / 7) + 2;
				result -= (25 * numAlign - 10) * numAlign - 55;
				if (ver >= 7) result -= 36;
			}
			assert(208 <= result && result <= 29648);
			return result;
		}
		static getNumDataCodewords(ver, ecl) {
			return Math.floor(_QrCode.getNumRawDataModules(ver) / 8) - _QrCode.ECC_CODEWORDS_PER_BLOCK[ecl.ordinal][ver] * _QrCode.NUM_ERROR_CORRECTION_BLOCKS[ecl.ordinal][ver];
		}
		static reedSolomonComputeDivisor(degree) {
			if (degree < 1 || degree > 255) throw new RangeError("Degree out of range");
			let result = [];
			for (let i = 0; i < degree - 1; i++) result.push(0);
			result.push(1);
			let root = 1;
			for (let i = 0; i < degree; i++) {
				for (let j = 0; j < result.length; j++) {
					result[j] = _QrCode.reedSolomonMultiply(result[j], root);
					if (j + 1 < result.length) result[j] ^= result[j + 1];
				}
				root = _QrCode.reedSolomonMultiply(root, 2);
			}
			return result;
		}
		static reedSolomonComputeRemainder(data, divisor) {
			let result = divisor.map((_) => 0);
			for (const b of data) {
				const factor = b ^ result.shift();
				result.push(0);
				divisor.forEach((coef, i) => result[i] ^= _QrCode.reedSolomonMultiply(coef, factor));
			}
			return result;
		}
		static reedSolomonMultiply(x, y) {
			if (x >>> 8 != 0 || y >>> 8 != 0) throw new RangeError("Byte out of range");
			let z = 0;
			for (let i = 7; i >= 0; i--) {
				z = z << 1 ^ (z >>> 7) * 285;
				z ^= (y >>> i & 1) * x;
			}
			assert(z >>> 8 == 0);
			return z;
		}
		finderPenaltyCountPatterns(runHistory) {
			const n = runHistory[1];
			assert(n <= this.size * 3);
			const core = n > 0 && runHistory[2] == n && runHistory[3] == n * 3 && runHistory[4] == n && runHistory[5] == n;
			return (core && runHistory[0] >= n * 4 && runHistory[6] >= n ? 1 : 0) + (core && runHistory[6] >= n * 4 && runHistory[0] >= n ? 1 : 0);
		}
		finderPenaltyTerminateAndCount(currentRunColor, currentRunLength, runHistory) {
			if (currentRunColor) {
				this.finderPenaltyAddHistory(currentRunLength, runHistory);
				currentRunLength = 0;
			}
			currentRunLength += this.size;
			this.finderPenaltyAddHistory(currentRunLength, runHistory);
			return this.finderPenaltyCountPatterns(runHistory);
		}
		finderPenaltyAddHistory(currentRunLength, runHistory) {
			if (runHistory[0] == 0) currentRunLength += this.size;
			runHistory.pop();
			runHistory.unshift(currentRunLength);
		}
	};
	_QrCode.MIN_VERSION = 1;
	_QrCode.MAX_VERSION = 40;
	_QrCode.PENALTY_N1 = 3;
	_QrCode.PENALTY_N2 = 3;
	_QrCode.PENALTY_N3 = 40;
	_QrCode.PENALTY_N4 = 10;
	_QrCode.ECC_CODEWORDS_PER_BLOCK = [
		[
			-1,
			7,
			10,
			15,
			20,
			26,
			18,
			20,
			24,
			30,
			18,
			20,
			24,
			26,
			30,
			22,
			24,
			28,
			30,
			28,
			28,
			28,
			28,
			30,
			30,
			26,
			28,
			30,
			30,
			30,
			30,
			30,
			30,
			30,
			30,
			30,
			30,
			30,
			30,
			30,
			30
		],
		[
			-1,
			10,
			16,
			26,
			18,
			24,
			16,
			18,
			22,
			22,
			26,
			30,
			22,
			22,
			24,
			24,
			28,
			28,
			26,
			26,
			26,
			26,
			28,
			28,
			28,
			28,
			28,
			28,
			28,
			28,
			28,
			28,
			28,
			28,
			28,
			28,
			28,
			28,
			28,
			28,
			28
		],
		[
			-1,
			13,
			22,
			18,
			26,
			18,
			24,
			18,
			22,
			20,
			24,
			28,
			26,
			24,
			20,
			30,
			24,
			28,
			28,
			26,
			30,
			28,
			30,
			30,
			30,
			30,
			28,
			30,
			30,
			30,
			30,
			30,
			30,
			30,
			30,
			30,
			30,
			30,
			30,
			30,
			30
		],
		[
			-1,
			17,
			28,
			22,
			16,
			22,
			28,
			26,
			26,
			24,
			28,
			24,
			28,
			22,
			24,
			24,
			30,
			28,
			28,
			26,
			28,
			30,
			24,
			30,
			30,
			30,
			30,
			30,
			30,
			30,
			30,
			30,
			30,
			30,
			30,
			30,
			30,
			30,
			30,
			30,
			30
		]
	];
	_QrCode.NUM_ERROR_CORRECTION_BLOCKS = [
		[
			-1,
			1,
			1,
			1,
			1,
			1,
			2,
			2,
			2,
			2,
			4,
			4,
			4,
			4,
			4,
			6,
			6,
			6,
			6,
			7,
			8,
			8,
			9,
			9,
			10,
			12,
			12,
			12,
			13,
			14,
			15,
			16,
			17,
			18,
			19,
			19,
			20,
			21,
			22,
			24,
			25
		],
		[
			-1,
			1,
			1,
			1,
			2,
			2,
			4,
			4,
			4,
			5,
			5,
			5,
			8,
			9,
			9,
			10,
			10,
			11,
			13,
			14,
			16,
			17,
			17,
			18,
			20,
			21,
			23,
			25,
			26,
			28,
			29,
			31,
			33,
			35,
			37,
			38,
			40,
			43,
			45,
			47,
			49
		],
		[
			-1,
			1,
			1,
			2,
			2,
			4,
			4,
			6,
			6,
			8,
			8,
			8,
			10,
			12,
			16,
			12,
			17,
			16,
			18,
			21,
			20,
			23,
			23,
			25,
			27,
			29,
			34,
			34,
			35,
			38,
			40,
			43,
			45,
			48,
			51,
			53,
			56,
			59,
			62,
			65,
			68
		],
		[
			-1,
			1,
			1,
			2,
			4,
			4,
			4,
			5,
			6,
			8,
			8,
			11,
			11,
			16,
			16,
			18,
			16,
			19,
			21,
			25,
			25,
			25,
			34,
			30,
			32,
			35,
			37,
			40,
			42,
			45,
			48,
			51,
			54,
			57,
			60,
			63,
			66,
			70,
			74,
			77,
			81
		]
	];
	qrcodegen2.QrCode = _QrCode;
	function appendBits(val, len, bb) {
		if (len < 0 || len > 31 || val >>> len != 0) throw new RangeError("Value out of range");
		for (let i = len - 1; i >= 0; i--) bb.push(val >>> i & 1);
	}
	function getBit(x, i) {
		return (x >>> i & 1) != 0;
	}
	function assert(cond) {
		if (!cond) throw new Error("Assertion error");
	}
	const _QrSegment = class _QrSegment {
		constructor(mode, numChars, bitData) {
			this.mode = mode;
			this.numChars = numChars;
			this.bitData = bitData;
			if (numChars < 0) throw new RangeError("Invalid argument");
			this.bitData = bitData.slice();
		}
		static makeBytes(data) {
			let bb = [];
			for (const b of data) appendBits(b, 8, bb);
			return new _QrSegment(_QrSegment.Mode.BYTE, data.length, bb);
		}
		static makeNumeric(digits) {
			if (!_QrSegment.isNumeric(digits)) throw new RangeError("String contains non-numeric characters");
			let bb = [];
			for (let i = 0; i < digits.length;) {
				const n = Math.min(digits.length - i, 3);
				appendBits(parseInt(digits.substring(i, i + n), 10), n * 3 + 1, bb);
				i += n;
			}
			return new _QrSegment(_QrSegment.Mode.NUMERIC, digits.length, bb);
		}
		static makeAlphanumeric(text) {
			if (!_QrSegment.isAlphanumeric(text)) throw new RangeError("String contains unencodable characters in alphanumeric mode");
			let bb = [];
			let i = 0;
			for (; i + 2 <= text.length; i += 2) {
				let temp = _QrSegment.ALPHANUMERIC_CHARSET.indexOf(text.charAt(i)) * 45;
				temp += _QrSegment.ALPHANUMERIC_CHARSET.indexOf(text.charAt(i + 1));
				appendBits(temp, 11, bb);
			}
			if (i < text.length) appendBits(_QrSegment.ALPHANUMERIC_CHARSET.indexOf(text.charAt(i)), 6, bb);
			return new _QrSegment(_QrSegment.Mode.ALPHANUMERIC, text.length, bb);
		}
		static makeSegments(text) {
			if (text == "") return [];
			else if (_QrSegment.isNumeric(text)) return [_QrSegment.makeNumeric(text)];
			else if (_QrSegment.isAlphanumeric(text)) return [_QrSegment.makeAlphanumeric(text)];
			else return [_QrSegment.makeBytes(_QrSegment.toUtf8ByteArray(text))];
		}
		static makeEci(assignVal) {
			let bb = [];
			if (assignVal < 0) throw new RangeError("ECI assignment value out of range");
			else if (assignVal < 128) appendBits(assignVal, 8, bb);
			else if (assignVal < 16384) {
				appendBits(2, 2, bb);
				appendBits(assignVal, 14, bb);
			} else if (assignVal < 1e6) {
				appendBits(6, 3, bb);
				appendBits(assignVal, 21, bb);
			} else throw new RangeError("ECI assignment value out of range");
			return new _QrSegment(_QrSegment.Mode.ECI, 0, bb);
		}
		static isNumeric(text) {
			return _QrSegment.NUMERIC_REGEX.test(text);
		}
		static isAlphanumeric(text) {
			return _QrSegment.ALPHANUMERIC_REGEX.test(text);
		}
		getData() {
			return this.bitData.slice();
		}
		static getTotalBits(segs, version) {
			let result = 0;
			for (const seg of segs) {
				const ccbits = seg.mode.numCharCountBits(version);
				if (seg.numChars >= 1 << ccbits) return Infinity;
				result += 4 + ccbits + seg.bitData.length;
			}
			return result;
		}
		static toUtf8ByteArray(str) {
			str = encodeURI(str);
			let result = [];
			for (let i = 0; i < str.length; i++) if (str.charAt(i) != "%") result.push(str.charCodeAt(i));
			else {
				result.push(parseInt(str.substring(i + 1, i + 3), 16));
				i += 2;
			}
			return result;
		}
	};
	_QrSegment.NUMERIC_REGEX = /^[0-9]*$/;
	_QrSegment.ALPHANUMERIC_REGEX = /^[A-Z0-9 $%*+.\/:-]*$/;
	_QrSegment.ALPHANUMERIC_CHARSET = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ $%*+-./:";
	let QrSegment = _QrSegment;
	qrcodegen2.QrSegment = _QrSegment;
})(qrcodegen || (qrcodegen = {}));
((qrcodegen2) => {
	((QrCode2) => {
		const _Ecc = class _Ecc {
			constructor(ordinal, formatBits) {
				this.ordinal = ordinal;
				this.formatBits = formatBits;
			}
		};
		_Ecc.LOW = new _Ecc(0, 1);
		_Ecc.MEDIUM = new _Ecc(1, 0);
		_Ecc.QUARTILE = new _Ecc(2, 3);
		_Ecc.HIGH = new _Ecc(3, 2);
		QrCode2.Ecc = _Ecc;
	})(qrcodegen2.QrCode || (qrcodegen2.QrCode = {}));
})(qrcodegen || (qrcodegen = {}));
((qrcodegen2) => {
	((QrSegment2) => {
		const _Mode = class _Mode {
			constructor(modeBits, numBitsCharCount) {
				this.modeBits = modeBits;
				this.numBitsCharCount = numBitsCharCount;
			}
			numCharCountBits(ver) {
				return this.numBitsCharCount[Math.floor((ver + 7) / 17)];
			}
		};
		_Mode.NUMERIC = new _Mode(1, [
			10,
			12,
			14
		]);
		_Mode.ALPHANUMERIC = new _Mode(2, [
			9,
			11,
			13
		]);
		_Mode.BYTE = new _Mode(4, [
			8,
			16,
			16
		]);
		_Mode.KANJI = new _Mode(8, [
			8,
			10,
			12
		]);
		_Mode.ECI = new _Mode(7, [
			0,
			0,
			0
		]);
		QrSegment2.Mode = _Mode;
	})(qrcodegen2.QrSegment || (qrcodegen2.QrSegment = {}));
})(qrcodegen || (qrcodegen = {}));
var qrcodegen_default = qrcodegen;
/**
* @license qrcode.react
* Copyright (c) Paul O'Shannessy
* SPDX-License-Identifier: ISC
*/
var ERROR_LEVEL_MAP = {
	L: qrcodegen_default.QrCode.Ecc.LOW,
	M: qrcodegen_default.QrCode.Ecc.MEDIUM,
	Q: qrcodegen_default.QrCode.Ecc.QUARTILE,
	H: qrcodegen_default.QrCode.Ecc.HIGH
};
var DEFAULT_SIZE = 128;
var DEFAULT_LEVEL = "L";
var DEFAULT_BGCOLOR = "#FFFFFF";
var DEFAULT_FGCOLOR = "#000000";
var DEFAULT_INCLUDEMARGIN = false;
var DEFAULT_MINVERSION = 1;
var SPEC_MARGIN_SIZE = 4;
var DEFAULT_MARGIN_SIZE = 0;
var DEFAULT_IMG_SCALE = .1;
function generatePath(modules, margin = 0) {
	const ops = [];
	modules.forEach(function(row, y) {
		let start = null;
		row.forEach(function(cell, x) {
			if (!cell && start !== null) {
				ops.push(`M${start + margin} ${y + margin}h${x - start}v1H${start + margin}z`);
				start = null;
				return;
			}
			if (x === row.length - 1) {
				if (!cell) return;
				if (start === null) ops.push(`M${x + margin},${y + margin} h1v1H${x + margin}z`);
				else ops.push(`M${start + margin},${y + margin} h${x + 1 - start}v1H${start + margin}z`);
				return;
			}
			if (cell && start === null) start = x;
		});
	});
	return ops.join("");
}
function excavateModules(modules, excavation) {
	return modules.slice().map((row, y) => {
		if (y < excavation.y || y >= excavation.y + excavation.h) return row;
		return row.map((cell, x) => {
			if (x < excavation.x || x >= excavation.x + excavation.w) return cell;
			return false;
		});
	});
}
function getImageSettings(cells, size, margin, imageSettings) {
	if (imageSettings == null) return null;
	const numCells = cells.length + margin * 2;
	const defaultSize = Math.floor(size * DEFAULT_IMG_SCALE);
	const scale = numCells / size;
	const w = (imageSettings.width || defaultSize) * scale;
	const h = (imageSettings.height || defaultSize) * scale;
	const x = imageSettings.x == null ? cells.length / 2 - w / 2 : imageSettings.x * scale;
	const y = imageSettings.y == null ? cells.length / 2 - h / 2 : imageSettings.y * scale;
	const opacity = imageSettings.opacity == null ? 1 : imageSettings.opacity;
	let excavation = null;
	if (imageSettings.excavate) {
		let floorX = Math.floor(x);
		let floorY = Math.floor(y);
		excavation = {
			x: floorX,
			y: floorY,
			w: Math.ceil(w + x - floorX),
			h: Math.ceil(h + y - floorY)
		};
	}
	const crossOrigin = imageSettings.crossOrigin;
	return {
		x,
		y,
		h,
		w,
		excavation,
		opacity,
		crossOrigin
	};
}
function getMarginSize(includeMargin, marginSize) {
	if (marginSize != null) return Math.max(Math.floor(marginSize), 0);
	return includeMargin ? SPEC_MARGIN_SIZE : DEFAULT_MARGIN_SIZE;
}
function useQRCode({ value, level, minVersion, includeMargin, marginSize, imageSettings, size, boostLevel }) {
	let qrcode = import_react.useMemo(() => {
		const segments = (Array.isArray(value) ? value : [value]).reduce((accum, v) => {
			accum.push(...qrcodegen_default.QrSegment.makeSegments(v));
			return accum;
		}, []);
		return qrcodegen_default.QrCode.encodeSegments(segments, ERROR_LEVEL_MAP[level], minVersion, void 0, void 0, boostLevel);
	}, [
		value,
		level,
		minVersion,
		boostLevel
	]);
	const { cells, margin, numCells, calculatedImageSettings } = import_react.useMemo(() => {
		let cells2 = qrcode.getModules();
		const margin2 = getMarginSize(includeMargin, marginSize);
		return {
			cells: cells2,
			margin: margin2,
			numCells: cells2.length + margin2 * 2,
			calculatedImageSettings: getImageSettings(cells2, size, margin2, imageSettings)
		};
	}, [
		qrcode,
		size,
		imageSettings,
		includeMargin,
		marginSize
	]);
	return {
		qrcode,
		margin,
		cells,
		numCells,
		calculatedImageSettings
	};
}
var SUPPORTS_PATH2D = function() {
	try {
		new Path2D().addPath(new Path2D());
	} catch (e) {
		return false;
	}
	return true;
}();
var QRCodeCanvas = import_react.forwardRef(function QRCodeCanvas2(props, forwardedRef) {
	const _a = props, { value, size = DEFAULT_SIZE, level = DEFAULT_LEVEL, bgColor = DEFAULT_BGCOLOR, fgColor = DEFAULT_FGCOLOR, includeMargin = DEFAULT_INCLUDEMARGIN, minVersion = DEFAULT_MINVERSION, boostLevel, marginSize, imageSettings } = _a;
	const _b = __objRest(_a, [
		"value",
		"size",
		"level",
		"bgColor",
		"fgColor",
		"includeMargin",
		"minVersion",
		"boostLevel",
		"marginSize",
		"imageSettings"
	]), { style } = _b, otherProps = __objRest(_b, ["style"]);
	const imgSrc = imageSettings == null ? void 0 : imageSettings.src;
	const _canvas = import_react.useRef(null);
	const _image = import_react.useRef(null);
	const setCanvasRef = import_react.useCallback((node) => {
		_canvas.current = node;
		if (typeof forwardedRef === "function") forwardedRef(node);
		else if (forwardedRef) forwardedRef.current = node;
	}, [forwardedRef]);
	const [isImgLoaded, setIsImageLoaded] = import_react.useState(false);
	const { margin, cells, numCells, calculatedImageSettings } = useQRCode({
		value,
		level,
		minVersion,
		boostLevel,
		includeMargin,
		marginSize,
		imageSettings,
		size
	});
	import_react.useEffect(() => {
		if (_canvas.current != null) {
			const canvas = _canvas.current;
			const ctx = canvas.getContext("2d");
			if (!ctx) return;
			let cellsToDraw = cells;
			const image = _image.current;
			const haveImageToRender = calculatedImageSettings != null && image !== null && image.complete && image.naturalHeight !== 0 && image.naturalWidth !== 0;
			if (haveImageToRender) {
				if (calculatedImageSettings.excavation != null) cellsToDraw = excavateModules(cells, calculatedImageSettings.excavation);
			}
			const pixelRatio = window.devicePixelRatio || 1;
			canvas.height = canvas.width = size * pixelRatio;
			const scale = size / numCells * pixelRatio;
			ctx.scale(scale, scale);
			ctx.fillStyle = bgColor;
			ctx.fillRect(0, 0, numCells, numCells);
			ctx.fillStyle = fgColor;
			if (SUPPORTS_PATH2D) ctx.fill(new Path2D(generatePath(cellsToDraw, margin)));
			else cells.forEach(function(row, rdx) {
				row.forEach(function(cell, cdx) {
					if (cell) ctx.fillRect(cdx + margin, rdx + margin, 1, 1);
				});
			});
			if (calculatedImageSettings) ctx.globalAlpha = calculatedImageSettings.opacity;
			if (haveImageToRender) ctx.drawImage(image, calculatedImageSettings.x + margin, calculatedImageSettings.y + margin, calculatedImageSettings.w, calculatedImageSettings.h);
		}
	});
	import_react.useEffect(() => {
		setIsImageLoaded(false);
	}, [imgSrc]);
	const canvasStyle = __spreadValues({
		height: size,
		width: size
	}, style);
	let img = null;
	if (imgSrc != null) img = /* @__PURE__ */ import_react.createElement("img", {
		src: imgSrc,
		key: imgSrc,
		style: { display: "none" },
		onLoad: () => {
			setIsImageLoaded(true);
		},
		ref: _image,
		crossOrigin: calculatedImageSettings == null ? void 0 : calculatedImageSettings.crossOrigin
	});
	return /* @__PURE__ */ import_react.createElement(import_react.Fragment, null, /* @__PURE__ */ import_react.createElement("canvas", __spreadValues({
		style: canvasStyle,
		height: size,
		width: size,
		ref: setCanvasRef,
		role: "img"
	}, otherProps)), img);
});
QRCodeCanvas.displayName = "QRCodeCanvas";
var QRCodeSVG = import_react.forwardRef(function QRCodeSVG2(props, forwardedRef) {
	const _a = props, { value, size = DEFAULT_SIZE, level = DEFAULT_LEVEL, bgColor = DEFAULT_BGCOLOR, fgColor = DEFAULT_FGCOLOR, includeMargin = DEFAULT_INCLUDEMARGIN, minVersion = DEFAULT_MINVERSION, boostLevel, title, marginSize, imageSettings } = _a, otherProps = __objRest(_a, [
		"value",
		"size",
		"level",
		"bgColor",
		"fgColor",
		"includeMargin",
		"minVersion",
		"boostLevel",
		"title",
		"marginSize",
		"imageSettings"
	]);
	const { margin, cells, numCells, calculatedImageSettings } = useQRCode({
		value,
		level,
		minVersion,
		boostLevel,
		includeMargin,
		marginSize,
		imageSettings,
		size
	});
	let cellsToDraw = cells;
	let image = null;
	if (imageSettings != null && calculatedImageSettings != null) {
		if (calculatedImageSettings.excavation != null) cellsToDraw = excavateModules(cells, calculatedImageSettings.excavation);
		image = /* @__PURE__ */ import_react.createElement("image", {
			href: imageSettings.src,
			height: calculatedImageSettings.h,
			width: calculatedImageSettings.w,
			x: calculatedImageSettings.x + margin,
			y: calculatedImageSettings.y + margin,
			preserveAspectRatio: "none",
			opacity: calculatedImageSettings.opacity,
			crossOrigin: calculatedImageSettings.crossOrigin
		});
	}
	const fgPath = generatePath(cellsToDraw, margin);
	return /* @__PURE__ */ import_react.createElement("svg", __spreadValues({
		height: size,
		width: size,
		viewBox: `0 0 ${numCells} ${numCells}`,
		ref: forwardedRef,
		role: "img"
	}, otherProps), !!title && /* @__PURE__ */ import_react.createElement("title", null, title), /* @__PURE__ */ import_react.createElement("path", {
		fill: bgColor,
		d: `M0,0 h${numCells}v${numCells}H0z`,
		shapeRendering: "crispEdges"
	}), /* @__PURE__ */ import_react.createElement("path", {
		fill: fgColor,
		d: fgPath,
		shapeRendering: "crispEdges"
	}), image);
});
QRCodeSVG.displayName = "QRCodeSVG";
export { QRCodeCanvas, QRCodeSVG };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicXJjb2RlX19yZWFjdC5qcyIsIm5hbWVzIjpbXSwic291cmNlcyI6WyIuLi8uLi9xcmNvZGUucmVhY3QvbGliL2VzbS9pbmRleC5qcyJdLCJzb3VyY2VzQ29udGVudCI6WyJ2YXIgX19kZWZQcm9wID0gT2JqZWN0LmRlZmluZVByb3BlcnR5O1xudmFyIF9fZ2V0T3duUHJvcFN5bWJvbHMgPSBPYmplY3QuZ2V0T3duUHJvcGVydHlTeW1ib2xzO1xudmFyIF9faGFzT3duUHJvcCA9IE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHk7XG52YXIgX19wcm9wSXNFbnVtID0gT2JqZWN0LnByb3RvdHlwZS5wcm9wZXJ0eUlzRW51bWVyYWJsZTtcbnZhciBfX2RlZk5vcm1hbFByb3AgPSAob2JqLCBrZXksIHZhbHVlKSA9PiBrZXkgaW4gb2JqID8gX19kZWZQcm9wKG9iaiwga2V5LCB7IGVudW1lcmFibGU6IHRydWUsIGNvbmZpZ3VyYWJsZTogdHJ1ZSwgd3JpdGFibGU6IHRydWUsIHZhbHVlIH0pIDogb2JqW2tleV0gPSB2YWx1ZTtcbnZhciBfX3NwcmVhZFZhbHVlcyA9IChhLCBiKSA9PiB7XG4gIGZvciAodmFyIHByb3AgaW4gYiB8fCAoYiA9IHt9KSlcbiAgICBpZiAoX19oYXNPd25Qcm9wLmNhbGwoYiwgcHJvcCkpXG4gICAgICBfX2RlZk5vcm1hbFByb3AoYSwgcHJvcCwgYltwcm9wXSk7XG4gIGlmIChfX2dldE93blByb3BTeW1ib2xzKVxuICAgIGZvciAodmFyIHByb3Agb2YgX19nZXRPd25Qcm9wU3ltYm9scyhiKSkge1xuICAgICAgaWYgKF9fcHJvcElzRW51bS5jYWxsKGIsIHByb3ApKVxuICAgICAgICBfX2RlZk5vcm1hbFByb3AoYSwgcHJvcCwgYltwcm9wXSk7XG4gICAgfVxuICByZXR1cm4gYTtcbn07XG52YXIgX19vYmpSZXN0ID0gKHNvdXJjZSwgZXhjbHVkZSkgPT4ge1xuICB2YXIgdGFyZ2V0ID0ge307XG4gIGZvciAodmFyIHByb3AgaW4gc291cmNlKVxuICAgIGlmIChfX2hhc093blByb3AuY2FsbChzb3VyY2UsIHByb3ApICYmIGV4Y2x1ZGUuaW5kZXhPZihwcm9wKSA8IDApXG4gICAgICB0YXJnZXRbcHJvcF0gPSBzb3VyY2VbcHJvcF07XG4gIGlmIChzb3VyY2UgIT0gbnVsbCAmJiBfX2dldE93blByb3BTeW1ib2xzKVxuICAgIGZvciAodmFyIHByb3Agb2YgX19nZXRPd25Qcm9wU3ltYm9scyhzb3VyY2UpKSB7XG4gICAgICBpZiAoZXhjbHVkZS5pbmRleE9mKHByb3ApIDwgMCAmJiBfX3Byb3BJc0VudW0uY2FsbChzb3VyY2UsIHByb3ApKVxuICAgICAgICB0YXJnZXRbcHJvcF0gPSBzb3VyY2VbcHJvcF07XG4gICAgfVxuICByZXR1cm4gdGFyZ2V0O1xufTtcblxuLy8gc3JjL2luZGV4LnRzeFxuaW1wb3J0IFJlYWN0IGZyb20gXCJyZWFjdFwiO1xuXG4vLyBzcmMvdGhpcmQtcGFydHkvcXJjb2RlZ2VuL2luZGV4LnRzXG4vKipcbiAqIEBsaWNlbnNlIFFSIENvZGUgZ2VuZXJhdG9yIGxpYnJhcnkgKFR5cGVTY3JpcHQpXG4gKiBDb3B5cmlnaHQgKGMpIFByb2plY3QgTmF5dWtpLlxuICogU1BEWC1MaWNlbnNlLUlkZW50aWZpZXI6IE1JVFxuICovXG52YXIgcXJjb2RlZ2VuO1xuKChxcmNvZGVnZW4yKSA9PiB7XG4gIGNvbnN0IF9RckNvZGUgPSBjbGFzcyBfUXJDb2RlIHtcbiAgICAvKi0tIENvbnN0cnVjdG9yIChsb3cgbGV2ZWwpIGFuZCBmaWVsZHMgLS0qL1xuICAgIC8vIENyZWF0ZXMgYSBuZXcgUVIgQ29kZSB3aXRoIHRoZSBnaXZlbiB2ZXJzaW9uIG51bWJlcixcbiAgICAvLyBlcnJvciBjb3JyZWN0aW9uIGxldmVsLCBkYXRhIGNvZGV3b3JkIGJ5dGVzLCBhbmQgbWFzayBudW1iZXIuXG4gICAgLy8gVGhpcyBpcyBhIGxvdy1sZXZlbCBBUEkgdGhhdCBtb3N0IHVzZXJzIHNob3VsZCBub3QgdXNlIGRpcmVjdGx5LlxuICAgIC8vIEEgbWlkLWxldmVsIEFQSSBpcyB0aGUgZW5jb2RlU2VnbWVudHMoKSBmdW5jdGlvbi5cbiAgICBjb25zdHJ1Y3Rvcih2ZXJzaW9uLCBlcnJvckNvcnJlY3Rpb25MZXZlbCwgZGF0YUNvZGV3b3JkcywgbXNrKSB7XG4gICAgICB0aGlzLnZlcnNpb24gPSB2ZXJzaW9uO1xuICAgICAgdGhpcy5lcnJvckNvcnJlY3Rpb25MZXZlbCA9IGVycm9yQ29ycmVjdGlvbkxldmVsO1xuICAgICAgLy8gVGhlIG1vZHVsZXMgb2YgdGhpcyBRUiBDb2RlIChmYWxzZSA9IGxpZ2h0LCB0cnVlID0gZGFyaykuXG4gICAgICAvLyBJbW11dGFibGUgYWZ0ZXIgY29uc3RydWN0b3IgZmluaXNoZXMuIEFjY2Vzc2VkIHRocm91Z2ggZ2V0TW9kdWxlKCkuXG4gICAgICB0aGlzLm1vZHVsZXMgPSBbXTtcbiAgICAgIC8vIEluZGljYXRlcyBmdW5jdGlvbiBtb2R1bGVzIHRoYXQgYXJlIG5vdCBzdWJqZWN0ZWQgdG8gbWFza2luZy4gRGlzY2FyZGVkIHdoZW4gY29uc3RydWN0b3IgZmluaXNoZXMuXG4gICAgICB0aGlzLmlzRnVuY3Rpb24gPSBbXTtcbiAgICAgIGlmICh2ZXJzaW9uIDwgX1FyQ29kZS5NSU5fVkVSU0lPTiB8fCB2ZXJzaW9uID4gX1FyQ29kZS5NQVhfVkVSU0lPTilcbiAgICAgICAgdGhyb3cgbmV3IFJhbmdlRXJyb3IoXCJWZXJzaW9uIHZhbHVlIG91dCBvZiByYW5nZVwiKTtcbiAgICAgIGlmIChtc2sgPCAtMSB8fCBtc2sgPiA3KVxuICAgICAgICB0aHJvdyBuZXcgUmFuZ2VFcnJvcihcIk1hc2sgdmFsdWUgb3V0IG9mIHJhbmdlXCIpO1xuICAgICAgdGhpcy5zaXplID0gdmVyc2lvbiAqIDQgKyAxNztcbiAgICAgIGxldCByb3cgPSBbXTtcbiAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgdGhpcy5zaXplOyBpKyspXG4gICAgICAgIHJvdy5wdXNoKGZhbHNlKTtcbiAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgdGhpcy5zaXplOyBpKyspIHtcbiAgICAgICAgdGhpcy5tb2R1bGVzLnB1c2gocm93LnNsaWNlKCkpO1xuICAgICAgICB0aGlzLmlzRnVuY3Rpb24ucHVzaChyb3cuc2xpY2UoKSk7XG4gICAgICB9XG4gICAgICB0aGlzLmRyYXdGdW5jdGlvblBhdHRlcm5zKCk7XG4gICAgICBjb25zdCBhbGxDb2Rld29yZHMgPSB0aGlzLmFkZEVjY0FuZEludGVybGVhdmUoZGF0YUNvZGV3b3Jkcyk7XG4gICAgICB0aGlzLmRyYXdDb2Rld29yZHMoYWxsQ29kZXdvcmRzKTtcbiAgICAgIGlmIChtc2sgPT0gLTEpIHtcbiAgICAgICAgbGV0IG1pblBlbmFsdHkgPSAxZTk7XG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgODsgaSsrKSB7XG4gICAgICAgICAgdGhpcy5hcHBseU1hc2soaSk7XG4gICAgICAgICAgdGhpcy5kcmF3Rm9ybWF0Qml0cyhpKTtcbiAgICAgICAgICBjb25zdCBwZW5hbHR5ID0gdGhpcy5nZXRQZW5hbHR5U2NvcmUoKTtcbiAgICAgICAgICBpZiAocGVuYWx0eSA8IG1pblBlbmFsdHkpIHtcbiAgICAgICAgICAgIG1zayA9IGk7XG4gICAgICAgICAgICBtaW5QZW5hbHR5ID0gcGVuYWx0eTtcbiAgICAgICAgICB9XG4gICAgICAgICAgdGhpcy5hcHBseU1hc2soaSk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIGFzc2VydCgwIDw9IG1zayAmJiBtc2sgPD0gNyk7XG4gICAgICB0aGlzLm1hc2sgPSBtc2s7XG4gICAgICB0aGlzLmFwcGx5TWFzayhtc2spO1xuICAgICAgdGhpcy5kcmF3Rm9ybWF0Qml0cyhtc2spO1xuICAgICAgdGhpcy5pc0Z1bmN0aW9uID0gW107XG4gICAgfVxuICAgIC8qLS0gU3RhdGljIGZhY3RvcnkgZnVuY3Rpb25zIChoaWdoIGxldmVsKSAtLSovXG4gICAgLy8gUmV0dXJucyBhIFFSIENvZGUgcmVwcmVzZW50aW5nIHRoZSBnaXZlbiBVbmljb2RlIHRleHQgc3RyaW5nIGF0IHRoZSBnaXZlbiBlcnJvciBjb3JyZWN0aW9uIGxldmVsLlxuICAgIC8vIEFzIGEgY29uc2VydmF0aXZlIHVwcGVyIGJvdW5kLCB0aGlzIGZ1bmN0aW9uIGlzIGd1YXJhbnRlZWQgdG8gc3VjY2VlZCBmb3Igc3RyaW5ncyB0aGF0IGhhdmUgNzM4IG9yIGZld2VyXG4gICAgLy8gVW5pY29kZSBjb2RlIHBvaW50cyAobm90IFVURi0xNiBjb2RlIHVuaXRzKSBpZiB0aGUgbG93IGVycm9yIGNvcnJlY3Rpb24gbGV2ZWwgaXMgdXNlZC4gVGhlIHNtYWxsZXN0IHBvc3NpYmxlXG4gICAgLy8gUVIgQ29kZSB2ZXJzaW9uIGlzIGF1dG9tYXRpY2FsbHkgY2hvc2VuIGZvciB0aGUgb3V0cHV0LiBUaGUgRUNDIGxldmVsIG9mIHRoZSByZXN1bHQgbWF5IGJlIGhpZ2hlciB0aGFuIHRoZVxuICAgIC8vIGVjbCBhcmd1bWVudCBpZiBpdCBjYW4gYmUgZG9uZSB3aXRob3V0IGluY3JlYXNpbmcgdGhlIHZlcnNpb24uXG4gICAgc3RhdGljIGVuY29kZVRleHQodGV4dCwgZWNsKSB7XG4gICAgICBjb25zdCBzZWdzID0gcXJjb2RlZ2VuMi5RclNlZ21lbnQubWFrZVNlZ21lbnRzKHRleHQpO1xuICAgICAgcmV0dXJuIF9RckNvZGUuZW5jb2RlU2VnbWVudHMoc2VncywgZWNsKTtcbiAgICB9XG4gICAgLy8gUmV0dXJucyBhIFFSIENvZGUgcmVwcmVzZW50aW5nIHRoZSBnaXZlbiBiaW5hcnkgZGF0YSBhdCB0aGUgZ2l2ZW4gZXJyb3IgY29ycmVjdGlvbiBsZXZlbC5cbiAgICAvLyBUaGlzIGZ1bmN0aW9uIGFsd2F5cyBlbmNvZGVzIHVzaW5nIHRoZSBiaW5hcnkgc2VnbWVudCBtb2RlLCBub3QgYW55IHRleHQgbW9kZS4gVGhlIG1heGltdW0gbnVtYmVyIG9mXG4gICAgLy8gYnl0ZXMgYWxsb3dlZCBpcyAyOTUzLiBUaGUgc21hbGxlc3QgcG9zc2libGUgUVIgQ29kZSB2ZXJzaW9uIGlzIGF1dG9tYXRpY2FsbHkgY2hvc2VuIGZvciB0aGUgb3V0cHV0LlxuICAgIC8vIFRoZSBFQ0MgbGV2ZWwgb2YgdGhlIHJlc3VsdCBtYXkgYmUgaGlnaGVyIHRoYW4gdGhlIGVjbCBhcmd1bWVudCBpZiBpdCBjYW4gYmUgZG9uZSB3aXRob3V0IGluY3JlYXNpbmcgdGhlIHZlcnNpb24uXG4gICAgc3RhdGljIGVuY29kZUJpbmFyeShkYXRhLCBlY2wpIHtcbiAgICAgIGNvbnN0IHNlZyA9IHFyY29kZWdlbjIuUXJTZWdtZW50Lm1ha2VCeXRlcyhkYXRhKTtcbiAgICAgIHJldHVybiBfUXJDb2RlLmVuY29kZVNlZ21lbnRzKFtzZWddLCBlY2wpO1xuICAgIH1cbiAgICAvKi0tIFN0YXRpYyBmYWN0b3J5IGZ1bmN0aW9ucyAobWlkIGxldmVsKSAtLSovXG4gICAgLy8gUmV0dXJucyBhIFFSIENvZGUgcmVwcmVzZW50aW5nIHRoZSBnaXZlbiBzZWdtZW50cyB3aXRoIHRoZSBnaXZlbiBlbmNvZGluZyBwYXJhbWV0ZXJzLlxuICAgIC8vIFRoZSBzbWFsbGVzdCBwb3NzaWJsZSBRUiBDb2RlIHZlcnNpb24gd2l0aGluIHRoZSBnaXZlbiByYW5nZSBpcyBhdXRvbWF0aWNhbGx5XG4gICAgLy8gY2hvc2VuIGZvciB0aGUgb3V0cHV0LiBJZmYgYm9vc3RFY2wgaXMgdHJ1ZSwgdGhlbiB0aGUgRUNDIGxldmVsIG9mIHRoZSByZXN1bHRcbiAgICAvLyBtYXkgYmUgaGlnaGVyIHRoYW4gdGhlIGVjbCBhcmd1bWVudCBpZiBpdCBjYW4gYmUgZG9uZSB3aXRob3V0IGluY3JlYXNpbmcgdGhlXG4gICAgLy8gdmVyc2lvbi4gVGhlIG1hc2sgbnVtYmVyIGlzIGVpdGhlciBiZXR3ZWVuIDAgdG8gNyAoaW5jbHVzaXZlKSB0byBmb3JjZSB0aGF0XG4gICAgLy8gbWFzaywgb3IgLTEgdG8gYXV0b21hdGljYWxseSBjaG9vc2UgYW4gYXBwcm9wcmlhdGUgbWFzayAod2hpY2ggbWF5IGJlIHNsb3cpLlxuICAgIC8vIFRoaXMgZnVuY3Rpb24gYWxsb3dzIHRoZSB1c2VyIHRvIGNyZWF0ZSBhIGN1c3RvbSBzZXF1ZW5jZSBvZiBzZWdtZW50cyB0aGF0IHN3aXRjaGVzXG4gICAgLy8gYmV0d2VlbiBtb2RlcyAoc3VjaCBhcyBhbHBoYW51bWVyaWMgYW5kIGJ5dGUpIHRvIGVuY29kZSB0ZXh0IGluIGxlc3Mgc3BhY2UuXG4gICAgLy8gVGhpcyBpcyBhIG1pZC1sZXZlbCBBUEk7IHRoZSBoaWdoLWxldmVsIEFQSSBpcyBlbmNvZGVUZXh0KCkgYW5kIGVuY29kZUJpbmFyeSgpLlxuICAgIHN0YXRpYyBlbmNvZGVTZWdtZW50cyhzZWdzLCBlY2wsIG1pblZlcnNpb24gPSAxLCBtYXhWZXJzaW9uID0gNDAsIG1hc2sgPSAtMSwgYm9vc3RFY2wgPSB0cnVlKSB7XG4gICAgICBpZiAoIShfUXJDb2RlLk1JTl9WRVJTSU9OIDw9IG1pblZlcnNpb24gJiYgbWluVmVyc2lvbiA8PSBtYXhWZXJzaW9uICYmIG1heFZlcnNpb24gPD0gX1FyQ29kZS5NQVhfVkVSU0lPTikgfHwgbWFzayA8IC0xIHx8IG1hc2sgPiA3KVxuICAgICAgICB0aHJvdyBuZXcgUmFuZ2VFcnJvcihcIkludmFsaWQgdmFsdWVcIik7XG4gICAgICBsZXQgdmVyc2lvbjtcbiAgICAgIGxldCBkYXRhVXNlZEJpdHM7XG4gICAgICBmb3IgKHZlcnNpb24gPSBtaW5WZXJzaW9uOyA7IHZlcnNpb24rKykge1xuICAgICAgICBjb25zdCBkYXRhQ2FwYWNpdHlCaXRzMiA9IF9RckNvZGUuZ2V0TnVtRGF0YUNvZGV3b3Jkcyh2ZXJzaW9uLCBlY2wpICogODtcbiAgICAgICAgY29uc3QgdXNlZEJpdHMgPSBRclNlZ21lbnQuZ2V0VG90YWxCaXRzKHNlZ3MsIHZlcnNpb24pO1xuICAgICAgICBpZiAodXNlZEJpdHMgPD0gZGF0YUNhcGFjaXR5Qml0czIpIHtcbiAgICAgICAgICBkYXRhVXNlZEJpdHMgPSB1c2VkQml0cztcbiAgICAgICAgICBicmVhaztcbiAgICAgICAgfVxuICAgICAgICBpZiAodmVyc2lvbiA+PSBtYXhWZXJzaW9uKVxuICAgICAgICAgIHRocm93IG5ldyBSYW5nZUVycm9yKFwiRGF0YSB0b28gbG9uZ1wiKTtcbiAgICAgIH1cbiAgICAgIGZvciAoY29uc3QgbmV3RWNsIG9mIFtfUXJDb2RlLkVjYy5NRURJVU0sIF9RckNvZGUuRWNjLlFVQVJUSUxFLCBfUXJDb2RlLkVjYy5ISUdIXSkge1xuICAgICAgICBpZiAoYm9vc3RFY2wgJiYgZGF0YVVzZWRCaXRzIDw9IF9RckNvZGUuZ2V0TnVtRGF0YUNvZGV3b3Jkcyh2ZXJzaW9uLCBuZXdFY2wpICogOClcbiAgICAgICAgICBlY2wgPSBuZXdFY2w7XG4gICAgICB9XG4gICAgICBsZXQgYmIgPSBbXTtcbiAgICAgIGZvciAoY29uc3Qgc2VnIG9mIHNlZ3MpIHtcbiAgICAgICAgYXBwZW5kQml0cyhzZWcubW9kZS5tb2RlQml0cywgNCwgYmIpO1xuICAgICAgICBhcHBlbmRCaXRzKHNlZy5udW1DaGFycywgc2VnLm1vZGUubnVtQ2hhckNvdW50Qml0cyh2ZXJzaW9uKSwgYmIpO1xuICAgICAgICBmb3IgKGNvbnN0IGIgb2Ygc2VnLmdldERhdGEoKSlcbiAgICAgICAgICBiYi5wdXNoKGIpO1xuICAgICAgfVxuICAgICAgYXNzZXJ0KGJiLmxlbmd0aCA9PSBkYXRhVXNlZEJpdHMpO1xuICAgICAgY29uc3QgZGF0YUNhcGFjaXR5Qml0cyA9IF9RckNvZGUuZ2V0TnVtRGF0YUNvZGV3b3Jkcyh2ZXJzaW9uLCBlY2wpICogODtcbiAgICAgIGFzc2VydChiYi5sZW5ndGggPD0gZGF0YUNhcGFjaXR5Qml0cyk7XG4gICAgICBhcHBlbmRCaXRzKDAsIE1hdGgubWluKDQsIGRhdGFDYXBhY2l0eUJpdHMgLSBiYi5sZW5ndGgpLCBiYik7XG4gICAgICBhcHBlbmRCaXRzKDAsICg4IC0gYmIubGVuZ3RoICUgOCkgJSA4LCBiYik7XG4gICAgICBhc3NlcnQoYmIubGVuZ3RoICUgOCA9PSAwKTtcbiAgICAgIGZvciAobGV0IHBhZEJ5dGUgPSAyMzY7IGJiLmxlbmd0aCA8IGRhdGFDYXBhY2l0eUJpdHM7IHBhZEJ5dGUgXj0gMjM2IF4gMTcpXG4gICAgICAgIGFwcGVuZEJpdHMocGFkQnl0ZSwgOCwgYmIpO1xuICAgICAgbGV0IGRhdGFDb2Rld29yZHMgPSBbXTtcbiAgICAgIHdoaWxlIChkYXRhQ29kZXdvcmRzLmxlbmd0aCAqIDggPCBiYi5sZW5ndGgpXG4gICAgICAgIGRhdGFDb2Rld29yZHMucHVzaCgwKTtcbiAgICAgIGJiLmZvckVhY2goKGIsIGkpID0+IGRhdGFDb2Rld29yZHNbaSA+Pj4gM10gfD0gYiA8PCA3IC0gKGkgJiA3KSk7XG4gICAgICByZXR1cm4gbmV3IF9RckNvZGUodmVyc2lvbiwgZWNsLCBkYXRhQ29kZXdvcmRzLCBtYXNrKTtcbiAgICB9XG4gICAgLyotLSBBY2Nlc3NvciBtZXRob2RzIC0tKi9cbiAgICAvLyBSZXR1cm5zIHRoZSBjb2xvciBvZiB0aGUgbW9kdWxlIChwaXhlbCkgYXQgdGhlIGdpdmVuIGNvb3JkaW5hdGVzLCB3aGljaCBpcyBmYWxzZVxuICAgIC8vIGZvciBsaWdodCBvciB0cnVlIGZvciBkYXJrLiBUaGUgdG9wIGxlZnQgY29ybmVyIGhhcyB0aGUgY29vcmRpbmF0ZXMgKHg9MCwgeT0wKS5cbiAgICAvLyBJZiB0aGUgZ2l2ZW4gY29vcmRpbmF0ZXMgYXJlIG91dCBvZiBib3VuZHMsIHRoZW4gZmFsc2UgKGxpZ2h0KSBpcyByZXR1cm5lZC5cbiAgICBnZXRNb2R1bGUoeCwgeSkge1xuICAgICAgcmV0dXJuIDAgPD0geCAmJiB4IDwgdGhpcy5zaXplICYmIDAgPD0geSAmJiB5IDwgdGhpcy5zaXplICYmIHRoaXMubW9kdWxlc1t5XVt4XTtcbiAgICB9XG4gICAgLy8gTW9kaWZpZWQgdG8gZXhwb3NlIG1vZHVsZXMgZm9yIGVhc3kgYWNjZXNzXG4gICAgZ2V0TW9kdWxlcygpIHtcbiAgICAgIHJldHVybiB0aGlzLm1vZHVsZXM7XG4gICAgfVxuICAgIC8qLS0gUHJpdmF0ZSBoZWxwZXIgbWV0aG9kcyBmb3IgY29uc3RydWN0b3I6IERyYXdpbmcgZnVuY3Rpb24gbW9kdWxlcyAtLSovXG4gICAgLy8gUmVhZHMgdGhpcyBvYmplY3QncyB2ZXJzaW9uIGZpZWxkLCBhbmQgZHJhd3MgYW5kIG1hcmtzIGFsbCBmdW5jdGlvbiBtb2R1bGVzLlxuICAgIGRyYXdGdW5jdGlvblBhdHRlcm5zKCkge1xuICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCB0aGlzLnNpemU7IGkrKykge1xuICAgICAgICB0aGlzLnNldEZ1bmN0aW9uTW9kdWxlKDYsIGksIGkgJSAyID09IDApO1xuICAgICAgICB0aGlzLnNldEZ1bmN0aW9uTW9kdWxlKGksIDYsIGkgJSAyID09IDApO1xuICAgICAgfVxuICAgICAgdGhpcy5kcmF3RmluZGVyUGF0dGVybigzLCAzKTtcbiAgICAgIHRoaXMuZHJhd0ZpbmRlclBhdHRlcm4odGhpcy5zaXplIC0gNCwgMyk7XG4gICAgICB0aGlzLmRyYXdGaW5kZXJQYXR0ZXJuKDMsIHRoaXMuc2l6ZSAtIDQpO1xuICAgICAgY29uc3QgYWxpZ25QYXRQb3MgPSB0aGlzLmdldEFsaWdubWVudFBhdHRlcm5Qb3NpdGlvbnMoKTtcbiAgICAgIGNvbnN0IG51bUFsaWduID0gYWxpZ25QYXRQb3MubGVuZ3RoO1xuICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBudW1BbGlnbjsgaSsrKSB7XG4gICAgICAgIGZvciAobGV0IGogPSAwOyBqIDwgbnVtQWxpZ247IGorKykge1xuICAgICAgICAgIGlmICghKGkgPT0gMCAmJiBqID09IDAgfHwgaSA9PSAwICYmIGogPT0gbnVtQWxpZ24gLSAxIHx8IGkgPT0gbnVtQWxpZ24gLSAxICYmIGogPT0gMCkpXG4gICAgICAgICAgICB0aGlzLmRyYXdBbGlnbm1lbnRQYXR0ZXJuKGFsaWduUGF0UG9zW2ldLCBhbGlnblBhdFBvc1tqXSk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIHRoaXMuZHJhd0Zvcm1hdEJpdHMoMCk7XG4gICAgICB0aGlzLmRyYXdWZXJzaW9uKCk7XG4gICAgfVxuICAgIC8vIERyYXdzIHR3byBjb3BpZXMgb2YgdGhlIGZvcm1hdCBiaXRzICh3aXRoIGl0cyBvd24gZXJyb3IgY29ycmVjdGlvbiBjb2RlKVxuICAgIC8vIGJhc2VkIG9uIHRoZSBnaXZlbiBtYXNrIGFuZCB0aGlzIG9iamVjdCdzIGVycm9yIGNvcnJlY3Rpb24gbGV2ZWwgZmllbGQuXG4gICAgZHJhd0Zvcm1hdEJpdHMobWFzaykge1xuICAgICAgY29uc3QgZGF0YSA9IHRoaXMuZXJyb3JDb3JyZWN0aW9uTGV2ZWwuZm9ybWF0Qml0cyA8PCAzIHwgbWFzaztcbiAgICAgIGxldCByZW0gPSBkYXRhO1xuICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCAxMDsgaSsrKVxuICAgICAgICByZW0gPSByZW0gPDwgMSBeIChyZW0gPj4+IDkpICogMTMzNTtcbiAgICAgIGNvbnN0IGJpdHMgPSAoZGF0YSA8PCAxMCB8IHJlbSkgXiAyMTUyMjtcbiAgICAgIGFzc2VydChiaXRzID4+PiAxNSA9PSAwKTtcbiAgICAgIGZvciAobGV0IGkgPSAwOyBpIDw9IDU7IGkrKylcbiAgICAgICAgdGhpcy5zZXRGdW5jdGlvbk1vZHVsZSg4LCBpLCBnZXRCaXQoYml0cywgaSkpO1xuICAgICAgdGhpcy5zZXRGdW5jdGlvbk1vZHVsZSg4LCA3LCBnZXRCaXQoYml0cywgNikpO1xuICAgICAgdGhpcy5zZXRGdW5jdGlvbk1vZHVsZSg4LCA4LCBnZXRCaXQoYml0cywgNykpO1xuICAgICAgdGhpcy5zZXRGdW5jdGlvbk1vZHVsZSg3LCA4LCBnZXRCaXQoYml0cywgOCkpO1xuICAgICAgZm9yIChsZXQgaSA9IDk7IGkgPCAxNTsgaSsrKVxuICAgICAgICB0aGlzLnNldEZ1bmN0aW9uTW9kdWxlKDE0IC0gaSwgOCwgZ2V0Qml0KGJpdHMsIGkpKTtcbiAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgODsgaSsrKVxuICAgICAgICB0aGlzLnNldEZ1bmN0aW9uTW9kdWxlKHRoaXMuc2l6ZSAtIDEgLSBpLCA4LCBnZXRCaXQoYml0cywgaSkpO1xuICAgICAgZm9yIChsZXQgaSA9IDg7IGkgPCAxNTsgaSsrKVxuICAgICAgICB0aGlzLnNldEZ1bmN0aW9uTW9kdWxlKDgsIHRoaXMuc2l6ZSAtIDE1ICsgaSwgZ2V0Qml0KGJpdHMsIGkpKTtcbiAgICAgIHRoaXMuc2V0RnVuY3Rpb25Nb2R1bGUoOCwgdGhpcy5zaXplIC0gOCwgdHJ1ZSk7XG4gICAgfVxuICAgIC8vIERyYXdzIHR3byBjb3BpZXMgb2YgdGhlIHZlcnNpb24gYml0cyAod2l0aCBpdHMgb3duIGVycm9yIGNvcnJlY3Rpb24gY29kZSksXG4gICAgLy8gYmFzZWQgb24gdGhpcyBvYmplY3QncyB2ZXJzaW9uIGZpZWxkLCBpZmYgNyA8PSB2ZXJzaW9uIDw9IDQwLlxuICAgIGRyYXdWZXJzaW9uKCkge1xuICAgICAgaWYgKHRoaXMudmVyc2lvbiA8IDcpXG4gICAgICAgIHJldHVybjtcbiAgICAgIGxldCByZW0gPSB0aGlzLnZlcnNpb247XG4gICAgICBmb3IgKGxldCBpID0gMDsgaSA8IDEyOyBpKyspXG4gICAgICAgIHJlbSA9IHJlbSA8PCAxIF4gKHJlbSA+Pj4gMTEpICogNzk3MztcbiAgICAgIGNvbnN0IGJpdHMgPSB0aGlzLnZlcnNpb24gPDwgMTIgfCByZW07XG4gICAgICBhc3NlcnQoYml0cyA+Pj4gMTggPT0gMCk7XG4gICAgICBmb3IgKGxldCBpID0gMDsgaSA8IDE4OyBpKyspIHtcbiAgICAgICAgY29uc3QgY29sb3IgPSBnZXRCaXQoYml0cywgaSk7XG4gICAgICAgIGNvbnN0IGEgPSB0aGlzLnNpemUgLSAxMSArIGkgJSAzO1xuICAgICAgICBjb25zdCBiID0gTWF0aC5mbG9vcihpIC8gMyk7XG4gICAgICAgIHRoaXMuc2V0RnVuY3Rpb25Nb2R1bGUoYSwgYiwgY29sb3IpO1xuICAgICAgICB0aGlzLnNldEZ1bmN0aW9uTW9kdWxlKGIsIGEsIGNvbG9yKTtcbiAgICAgIH1cbiAgICB9XG4gICAgLy8gRHJhd3MgYSA5KjkgZmluZGVyIHBhdHRlcm4gaW5jbHVkaW5nIHRoZSBib3JkZXIgc2VwYXJhdG9yLFxuICAgIC8vIHdpdGggdGhlIGNlbnRlciBtb2R1bGUgYXQgKHgsIHkpLiBNb2R1bGVzIGNhbiBiZSBvdXQgb2YgYm91bmRzLlxuICAgIGRyYXdGaW5kZXJQYXR0ZXJuKHgsIHkpIHtcbiAgICAgIGZvciAobGV0IGR5ID0gLTQ7IGR5IDw9IDQ7IGR5KyspIHtcbiAgICAgICAgZm9yIChsZXQgZHggPSAtNDsgZHggPD0gNDsgZHgrKykge1xuICAgICAgICAgIGNvbnN0IGRpc3QgPSBNYXRoLm1heChNYXRoLmFicyhkeCksIE1hdGguYWJzKGR5KSk7XG4gICAgICAgICAgY29uc3QgeHggPSB4ICsgZHg7XG4gICAgICAgICAgY29uc3QgeXkgPSB5ICsgZHk7XG4gICAgICAgICAgaWYgKDAgPD0geHggJiYgeHggPCB0aGlzLnNpemUgJiYgMCA8PSB5eSAmJiB5eSA8IHRoaXMuc2l6ZSlcbiAgICAgICAgICAgIHRoaXMuc2V0RnVuY3Rpb25Nb2R1bGUoeHgsIHl5LCBkaXN0ICE9IDIgJiYgZGlzdCAhPSA0KTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cbiAgICAvLyBEcmF3cyBhIDUqNSBhbGlnbm1lbnQgcGF0dGVybiwgd2l0aCB0aGUgY2VudGVyIG1vZHVsZVxuICAgIC8vIGF0ICh4LCB5KS4gQWxsIG1vZHVsZXMgbXVzdCBiZSBpbiBib3VuZHMuXG4gICAgZHJhd0FsaWdubWVudFBhdHRlcm4oeCwgeSkge1xuICAgICAgZm9yIChsZXQgZHkgPSAtMjsgZHkgPD0gMjsgZHkrKykge1xuICAgICAgICBmb3IgKGxldCBkeCA9IC0yOyBkeCA8PSAyOyBkeCsrKVxuICAgICAgICAgIHRoaXMuc2V0RnVuY3Rpb25Nb2R1bGUoeCArIGR4LCB5ICsgZHksIE1hdGgubWF4KE1hdGguYWJzKGR4KSwgTWF0aC5hYnMoZHkpKSAhPSAxKTtcbiAgICAgIH1cbiAgICB9XG4gICAgLy8gU2V0cyB0aGUgY29sb3Igb2YgYSBtb2R1bGUgYW5kIG1hcmtzIGl0IGFzIGEgZnVuY3Rpb24gbW9kdWxlLlxuICAgIC8vIE9ubHkgdXNlZCBieSB0aGUgY29uc3RydWN0b3IuIENvb3JkaW5hdGVzIG11c3QgYmUgaW4gYm91bmRzLlxuICAgIHNldEZ1bmN0aW9uTW9kdWxlKHgsIHksIGlzRGFyaykge1xuICAgICAgdGhpcy5tb2R1bGVzW3ldW3hdID0gaXNEYXJrO1xuICAgICAgdGhpcy5pc0Z1bmN0aW9uW3ldW3hdID0gdHJ1ZTtcbiAgICB9XG4gICAgLyotLSBQcml2YXRlIGhlbHBlciBtZXRob2RzIGZvciBjb25zdHJ1Y3RvcjogQ29kZXdvcmRzIGFuZCBtYXNraW5nIC0tKi9cbiAgICAvLyBSZXR1cm5zIGEgbmV3IGJ5dGUgc3RyaW5nIHJlcHJlc2VudGluZyB0aGUgZ2l2ZW4gZGF0YSB3aXRoIHRoZSBhcHByb3ByaWF0ZSBlcnJvciBjb3JyZWN0aW9uXG4gICAgLy8gY29kZXdvcmRzIGFwcGVuZGVkIHRvIGl0LCBiYXNlZCBvbiB0aGlzIG9iamVjdCdzIHZlcnNpb24gYW5kIGVycm9yIGNvcnJlY3Rpb24gbGV2ZWwuXG4gICAgYWRkRWNjQW5kSW50ZXJsZWF2ZShkYXRhKSB7XG4gICAgICBjb25zdCB2ZXIgPSB0aGlzLnZlcnNpb247XG4gICAgICBjb25zdCBlY2wgPSB0aGlzLmVycm9yQ29ycmVjdGlvbkxldmVsO1xuICAgICAgaWYgKGRhdGEubGVuZ3RoICE9IF9RckNvZGUuZ2V0TnVtRGF0YUNvZGV3b3Jkcyh2ZXIsIGVjbCkpXG4gICAgICAgIHRocm93IG5ldyBSYW5nZUVycm9yKFwiSW52YWxpZCBhcmd1bWVudFwiKTtcbiAgICAgIGNvbnN0IG51bUJsb2NrcyA9IF9RckNvZGUuTlVNX0VSUk9SX0NPUlJFQ1RJT05fQkxPQ0tTW2VjbC5vcmRpbmFsXVt2ZXJdO1xuICAgICAgY29uc3QgYmxvY2tFY2NMZW4gPSBfUXJDb2RlLkVDQ19DT0RFV09SRFNfUEVSX0JMT0NLW2VjbC5vcmRpbmFsXVt2ZXJdO1xuICAgICAgY29uc3QgcmF3Q29kZXdvcmRzID0gTWF0aC5mbG9vcihfUXJDb2RlLmdldE51bVJhd0RhdGFNb2R1bGVzKHZlcikgLyA4KTtcbiAgICAgIGNvbnN0IG51bVNob3J0QmxvY2tzID0gbnVtQmxvY2tzIC0gcmF3Q29kZXdvcmRzICUgbnVtQmxvY2tzO1xuICAgICAgY29uc3Qgc2hvcnRCbG9ja0xlbiA9IE1hdGguZmxvb3IocmF3Q29kZXdvcmRzIC8gbnVtQmxvY2tzKTtcbiAgICAgIGxldCBibG9ja3MgPSBbXTtcbiAgICAgIGNvbnN0IHJzRGl2ID0gX1FyQ29kZS5yZWVkU29sb21vbkNvbXB1dGVEaXZpc29yKGJsb2NrRWNjTGVuKTtcbiAgICAgIGZvciAobGV0IGkgPSAwLCBrID0gMDsgaSA8IG51bUJsb2NrczsgaSsrKSB7XG4gICAgICAgIGxldCBkYXQgPSBkYXRhLnNsaWNlKGssIGsgKyBzaG9ydEJsb2NrTGVuIC0gYmxvY2tFY2NMZW4gKyAoaSA8IG51bVNob3J0QmxvY2tzID8gMCA6IDEpKTtcbiAgICAgICAgayArPSBkYXQubGVuZ3RoO1xuICAgICAgICBjb25zdCBlY2MgPSBfUXJDb2RlLnJlZWRTb2xvbW9uQ29tcHV0ZVJlbWFpbmRlcihkYXQsIHJzRGl2KTtcbiAgICAgICAgaWYgKGkgPCBudW1TaG9ydEJsb2NrcylcbiAgICAgICAgICBkYXQucHVzaCgwKTtcbiAgICAgICAgYmxvY2tzLnB1c2goZGF0LmNvbmNhdChlY2MpKTtcbiAgICAgIH1cbiAgICAgIGxldCByZXN1bHQgPSBbXTtcbiAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgYmxvY2tzWzBdLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgIGJsb2Nrcy5mb3JFYWNoKChibG9jaywgaikgPT4ge1xuICAgICAgICAgIGlmIChpICE9IHNob3J0QmxvY2tMZW4gLSBibG9ja0VjY0xlbiB8fCBqID49IG51bVNob3J0QmxvY2tzKVxuICAgICAgICAgICAgcmVzdWx0LnB1c2goYmxvY2tbaV0pO1xuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICAgIGFzc2VydChyZXN1bHQubGVuZ3RoID09IHJhd0NvZGV3b3Jkcyk7XG4gICAgICByZXR1cm4gcmVzdWx0O1xuICAgIH1cbiAgICAvLyBEcmF3cyB0aGUgZ2l2ZW4gc2VxdWVuY2Ugb2YgOC1iaXQgY29kZXdvcmRzIChkYXRhIGFuZCBlcnJvciBjb3JyZWN0aW9uKSBvbnRvIHRoZSBlbnRpcmVcbiAgICAvLyBkYXRhIGFyZWEgb2YgdGhpcyBRUiBDb2RlLiBGdW5jdGlvbiBtb2R1bGVzIG5lZWQgdG8gYmUgbWFya2VkIG9mZiBiZWZvcmUgdGhpcyBpcyBjYWxsZWQuXG4gICAgZHJhd0NvZGV3b3JkcyhkYXRhKSB7XG4gICAgICBpZiAoZGF0YS5sZW5ndGggIT0gTWF0aC5mbG9vcihfUXJDb2RlLmdldE51bVJhd0RhdGFNb2R1bGVzKHRoaXMudmVyc2lvbikgLyA4KSlcbiAgICAgICAgdGhyb3cgbmV3IFJhbmdlRXJyb3IoXCJJbnZhbGlkIGFyZ3VtZW50XCIpO1xuICAgICAgbGV0IGkgPSAwO1xuICAgICAgZm9yIChsZXQgcmlnaHQgPSB0aGlzLnNpemUgLSAxOyByaWdodCA+PSAxOyByaWdodCAtPSAyKSB7XG4gICAgICAgIGlmIChyaWdodCA9PSA2KVxuICAgICAgICAgIHJpZ2h0ID0gNTtcbiAgICAgICAgZm9yIChsZXQgdmVydCA9IDA7IHZlcnQgPCB0aGlzLnNpemU7IHZlcnQrKykge1xuICAgICAgICAgIGZvciAobGV0IGogPSAwOyBqIDwgMjsgaisrKSB7XG4gICAgICAgICAgICBjb25zdCB4ID0gcmlnaHQgLSBqO1xuICAgICAgICAgICAgY29uc3QgdXB3YXJkID0gKHJpZ2h0ICsgMSAmIDIpID09IDA7XG4gICAgICAgICAgICBjb25zdCB5ID0gdXB3YXJkID8gdGhpcy5zaXplIC0gMSAtIHZlcnQgOiB2ZXJ0O1xuICAgICAgICAgICAgaWYgKCF0aGlzLmlzRnVuY3Rpb25beV1beF0gJiYgaSA8IGRhdGEubGVuZ3RoICogOCkge1xuICAgICAgICAgICAgICB0aGlzLm1vZHVsZXNbeV1beF0gPSBnZXRCaXQoZGF0YVtpID4+PiAzXSwgNyAtIChpICYgNykpO1xuICAgICAgICAgICAgICBpKys7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9XG4gICAgICBhc3NlcnQoaSA9PSBkYXRhLmxlbmd0aCAqIDgpO1xuICAgIH1cbiAgICAvLyBYT1JzIHRoZSBjb2Rld29yZCBtb2R1bGVzIGluIHRoaXMgUVIgQ29kZSB3aXRoIHRoZSBnaXZlbiBtYXNrIHBhdHRlcm4uXG4gICAgLy8gVGhlIGZ1bmN0aW9uIG1vZHVsZXMgbXVzdCBiZSBtYXJrZWQgYW5kIHRoZSBjb2Rld29yZCBiaXRzIG11c3QgYmUgZHJhd25cbiAgICAvLyBiZWZvcmUgbWFza2luZy4gRHVlIHRvIHRoZSBhcml0aG1ldGljIG9mIFhPUiwgY2FsbGluZyBhcHBseU1hc2soKSB3aXRoXG4gICAgLy8gdGhlIHNhbWUgbWFzayB2YWx1ZSBhIHNlY29uZCB0aW1lIHdpbGwgdW5kbyB0aGUgbWFzay4gQSBmaW5hbCB3ZWxsLWZvcm1lZFxuICAgIC8vIFFSIENvZGUgbmVlZHMgZXhhY3RseSBvbmUgKG5vdCB6ZXJvLCB0d28sIGV0Yy4pIG1hc2sgYXBwbGllZC5cbiAgICBhcHBseU1hc2sobWFzaykge1xuICAgICAgaWYgKG1hc2sgPCAwIHx8IG1hc2sgPiA3KVxuICAgICAgICB0aHJvdyBuZXcgUmFuZ2VFcnJvcihcIk1hc2sgdmFsdWUgb3V0IG9mIHJhbmdlXCIpO1xuICAgICAgZm9yIChsZXQgeSA9IDA7IHkgPCB0aGlzLnNpemU7IHkrKykge1xuICAgICAgICBmb3IgKGxldCB4ID0gMDsgeCA8IHRoaXMuc2l6ZTsgeCsrKSB7XG4gICAgICAgICAgbGV0IGludmVydDtcbiAgICAgICAgICBzd2l0Y2ggKG1hc2spIHtcbiAgICAgICAgICAgIGNhc2UgMDpcbiAgICAgICAgICAgICAgaW52ZXJ0ID0gKHggKyB5KSAlIDIgPT0gMDtcbiAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlIDE6XG4gICAgICAgICAgICAgIGludmVydCA9IHkgJSAyID09IDA7XG4gICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgY2FzZSAyOlxuICAgICAgICAgICAgICBpbnZlcnQgPSB4ICUgMyA9PSAwO1xuICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGNhc2UgMzpcbiAgICAgICAgICAgICAgaW52ZXJ0ID0gKHggKyB5KSAlIDMgPT0gMDtcbiAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlIDQ6XG4gICAgICAgICAgICAgIGludmVydCA9IChNYXRoLmZsb29yKHggLyAzKSArIE1hdGguZmxvb3IoeSAvIDIpKSAlIDIgPT0gMDtcbiAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlIDU6XG4gICAgICAgICAgICAgIGludmVydCA9IHggKiB5ICUgMiArIHggKiB5ICUgMyA9PSAwO1xuICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGNhc2UgNjpcbiAgICAgICAgICAgICAgaW52ZXJ0ID0gKHggKiB5ICUgMiArIHggKiB5ICUgMykgJSAyID09IDA7XG4gICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgY2FzZSA3OlxuICAgICAgICAgICAgICBpbnZlcnQgPSAoKHggKyB5KSAlIDIgKyB4ICogeSAlIDMpICUgMiA9PSAwO1xuICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihcIlVucmVhY2hhYmxlXCIpO1xuICAgICAgICAgIH1cbiAgICAgICAgICBpZiAoIXRoaXMuaXNGdW5jdGlvblt5XVt4XSAmJiBpbnZlcnQpXG4gICAgICAgICAgICB0aGlzLm1vZHVsZXNbeV1beF0gPSAhdGhpcy5tb2R1bGVzW3ldW3hdO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuICAgIC8vIENhbGN1bGF0ZXMgYW5kIHJldHVybnMgdGhlIHBlbmFsdHkgc2NvcmUgYmFzZWQgb24gc3RhdGUgb2YgdGhpcyBRUiBDb2RlJ3MgY3VycmVudCBtb2R1bGVzLlxuICAgIC8vIFRoaXMgaXMgdXNlZCBieSB0aGUgYXV0b21hdGljIG1hc2sgY2hvaWNlIGFsZ29yaXRobSB0byBmaW5kIHRoZSBtYXNrIHBhdHRlcm4gdGhhdCB5aWVsZHMgdGhlIGxvd2VzdCBzY29yZS5cbiAgICBnZXRQZW5hbHR5U2NvcmUoKSB7XG4gICAgICBsZXQgcmVzdWx0ID0gMDtcbiAgICAgIGZvciAobGV0IHkgPSAwOyB5IDwgdGhpcy5zaXplOyB5KyspIHtcbiAgICAgICAgbGV0IHJ1bkNvbG9yID0gZmFsc2U7XG4gICAgICAgIGxldCBydW5YID0gMDtcbiAgICAgICAgbGV0IHJ1bkhpc3RvcnkgPSBbMCwgMCwgMCwgMCwgMCwgMCwgMF07XG4gICAgICAgIGZvciAobGV0IHggPSAwOyB4IDwgdGhpcy5zaXplOyB4KyspIHtcbiAgICAgICAgICBpZiAodGhpcy5tb2R1bGVzW3ldW3hdID09IHJ1bkNvbG9yKSB7XG4gICAgICAgICAgICBydW5YKys7XG4gICAgICAgICAgICBpZiAocnVuWCA9PSA1KVxuICAgICAgICAgICAgICByZXN1bHQgKz0gX1FyQ29kZS5QRU5BTFRZX04xO1xuICAgICAgICAgICAgZWxzZSBpZiAocnVuWCA+IDUpXG4gICAgICAgICAgICAgIHJlc3VsdCsrO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICB0aGlzLmZpbmRlclBlbmFsdHlBZGRIaXN0b3J5KHJ1blgsIHJ1bkhpc3RvcnkpO1xuICAgICAgICAgICAgaWYgKCFydW5Db2xvcilcbiAgICAgICAgICAgICAgcmVzdWx0ICs9IHRoaXMuZmluZGVyUGVuYWx0eUNvdW50UGF0dGVybnMocnVuSGlzdG9yeSkgKiBfUXJDb2RlLlBFTkFMVFlfTjM7XG4gICAgICAgICAgICBydW5Db2xvciA9IHRoaXMubW9kdWxlc1t5XVt4XTtcbiAgICAgICAgICAgIHJ1blggPSAxO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICByZXN1bHQgKz0gdGhpcy5maW5kZXJQZW5hbHR5VGVybWluYXRlQW5kQ291bnQocnVuQ29sb3IsIHJ1blgsIHJ1bkhpc3RvcnkpICogX1FyQ29kZS5QRU5BTFRZX04zO1xuICAgICAgfVxuICAgICAgZm9yIChsZXQgeCA9IDA7IHggPCB0aGlzLnNpemU7IHgrKykge1xuICAgICAgICBsZXQgcnVuQ29sb3IgPSBmYWxzZTtcbiAgICAgICAgbGV0IHJ1blkgPSAwO1xuICAgICAgICBsZXQgcnVuSGlzdG9yeSA9IFswLCAwLCAwLCAwLCAwLCAwLCAwXTtcbiAgICAgICAgZm9yIChsZXQgeSA9IDA7IHkgPCB0aGlzLnNpemU7IHkrKykge1xuICAgICAgICAgIGlmICh0aGlzLm1vZHVsZXNbeV1beF0gPT0gcnVuQ29sb3IpIHtcbiAgICAgICAgICAgIHJ1blkrKztcbiAgICAgICAgICAgIGlmIChydW5ZID09IDUpXG4gICAgICAgICAgICAgIHJlc3VsdCArPSBfUXJDb2RlLlBFTkFMVFlfTjE7XG4gICAgICAgICAgICBlbHNlIGlmIChydW5ZID4gNSlcbiAgICAgICAgICAgICAgcmVzdWx0Kys7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHRoaXMuZmluZGVyUGVuYWx0eUFkZEhpc3RvcnkocnVuWSwgcnVuSGlzdG9yeSk7XG4gICAgICAgICAgICBpZiAoIXJ1bkNvbG9yKVxuICAgICAgICAgICAgICByZXN1bHQgKz0gdGhpcy5maW5kZXJQZW5hbHR5Q291bnRQYXR0ZXJucyhydW5IaXN0b3J5KSAqIF9RckNvZGUuUEVOQUxUWV9OMztcbiAgICAgICAgICAgIHJ1bkNvbG9yID0gdGhpcy5tb2R1bGVzW3ldW3hdO1xuICAgICAgICAgICAgcnVuWSA9IDE7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHJlc3VsdCArPSB0aGlzLmZpbmRlclBlbmFsdHlUZXJtaW5hdGVBbmRDb3VudChydW5Db2xvciwgcnVuWSwgcnVuSGlzdG9yeSkgKiBfUXJDb2RlLlBFTkFMVFlfTjM7XG4gICAgICB9XG4gICAgICBmb3IgKGxldCB5ID0gMDsgeSA8IHRoaXMuc2l6ZSAtIDE7IHkrKykge1xuICAgICAgICBmb3IgKGxldCB4ID0gMDsgeCA8IHRoaXMuc2l6ZSAtIDE7IHgrKykge1xuICAgICAgICAgIGNvbnN0IGNvbG9yID0gdGhpcy5tb2R1bGVzW3ldW3hdO1xuICAgICAgICAgIGlmIChjb2xvciA9PSB0aGlzLm1vZHVsZXNbeV1beCArIDFdICYmIGNvbG9yID09IHRoaXMubW9kdWxlc1t5ICsgMV1beF0gJiYgY29sb3IgPT0gdGhpcy5tb2R1bGVzW3kgKyAxXVt4ICsgMV0pXG4gICAgICAgICAgICByZXN1bHQgKz0gX1FyQ29kZS5QRU5BTFRZX04yO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICBsZXQgZGFyayA9IDA7XG4gICAgICBmb3IgKGNvbnN0IHJvdyBvZiB0aGlzLm1vZHVsZXMpXG4gICAgICAgIGRhcmsgPSByb3cucmVkdWNlKChzdW0sIGNvbG9yKSA9PiBzdW0gKyAoY29sb3IgPyAxIDogMCksIGRhcmspO1xuICAgICAgY29uc3QgdG90YWwgPSB0aGlzLnNpemUgKiB0aGlzLnNpemU7XG4gICAgICBjb25zdCBrID0gTWF0aC5jZWlsKE1hdGguYWJzKGRhcmsgKiAyMCAtIHRvdGFsICogMTApIC8gdG90YWwpIC0gMTtcbiAgICAgIGFzc2VydCgwIDw9IGsgJiYgayA8PSA5KTtcbiAgICAgIHJlc3VsdCArPSBrICogX1FyQ29kZS5QRU5BTFRZX040O1xuICAgICAgYXNzZXJ0KDAgPD0gcmVzdWx0ICYmIHJlc3VsdCA8PSAyNTY4ODg4KTtcbiAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgfVxuICAgIC8qLS0gUHJpdmF0ZSBoZWxwZXIgZnVuY3Rpb25zIC0tKi9cbiAgICAvLyBSZXR1cm5zIGFuIGFzY2VuZGluZyBsaXN0IG9mIHBvc2l0aW9ucyBvZiBhbGlnbm1lbnQgcGF0dGVybnMgZm9yIHRoaXMgdmVyc2lvbiBudW1iZXIuXG4gICAgLy8gRWFjaCBwb3NpdGlvbiBpcyBpbiB0aGUgcmFuZ2UgWzAsMTc3KSwgYW5kIGFyZSB1c2VkIG9uIGJvdGggdGhlIHggYW5kIHkgYXhlcy5cbiAgICAvLyBUaGlzIGNvdWxkIGJlIGltcGxlbWVudGVkIGFzIGxvb2t1cCB0YWJsZSBvZiA0MCB2YXJpYWJsZS1sZW5ndGggbGlzdHMgb2YgaW50ZWdlcnMuXG4gICAgZ2V0QWxpZ25tZW50UGF0dGVyblBvc2l0aW9ucygpIHtcbiAgICAgIGlmICh0aGlzLnZlcnNpb24gPT0gMSlcbiAgICAgICAgcmV0dXJuIFtdO1xuICAgICAgZWxzZSB7XG4gICAgICAgIGNvbnN0IG51bUFsaWduID0gTWF0aC5mbG9vcih0aGlzLnZlcnNpb24gLyA3KSArIDI7XG4gICAgICAgIGNvbnN0IHN0ZXAgPSB0aGlzLnZlcnNpb24gPT0gMzIgPyAyNiA6IE1hdGguY2VpbCgodGhpcy52ZXJzaW9uICogNCArIDQpIC8gKG51bUFsaWduICogMiAtIDIpKSAqIDI7XG4gICAgICAgIGxldCByZXN1bHQgPSBbNl07XG4gICAgICAgIGZvciAobGV0IHBvcyA9IHRoaXMuc2l6ZSAtIDc7IHJlc3VsdC5sZW5ndGggPCBudW1BbGlnbjsgcG9zIC09IHN0ZXApXG4gICAgICAgICAgcmVzdWx0LnNwbGljZSgxLCAwLCBwb3MpO1xuICAgICAgICByZXR1cm4gcmVzdWx0O1xuICAgICAgfVxuICAgIH1cbiAgICAvLyBSZXR1cm5zIHRoZSBudW1iZXIgb2YgZGF0YSBiaXRzIHRoYXQgY2FuIGJlIHN0b3JlZCBpbiBhIFFSIENvZGUgb2YgdGhlIGdpdmVuIHZlcnNpb24gbnVtYmVyLCBhZnRlclxuICAgIC8vIGFsbCBmdW5jdGlvbiBtb2R1bGVzIGFyZSBleGNsdWRlZC4gVGhpcyBpbmNsdWRlcyByZW1haW5kZXIgYml0cywgc28gaXQgbWlnaHQgbm90IGJlIGEgbXVsdGlwbGUgb2YgOC5cbiAgICAvLyBUaGUgcmVzdWx0IGlzIGluIHRoZSByYW5nZSBbMjA4LCAyOTY0OF0uIFRoaXMgY291bGQgYmUgaW1wbGVtZW50ZWQgYXMgYSA0MC1lbnRyeSBsb29rdXAgdGFibGUuXG4gICAgc3RhdGljIGdldE51bVJhd0RhdGFNb2R1bGVzKHZlcikge1xuICAgICAgaWYgKHZlciA8IF9RckNvZGUuTUlOX1ZFUlNJT04gfHwgdmVyID4gX1FyQ29kZS5NQVhfVkVSU0lPTilcbiAgICAgICAgdGhyb3cgbmV3IFJhbmdlRXJyb3IoXCJWZXJzaW9uIG51bWJlciBvdXQgb2YgcmFuZ2VcIik7XG4gICAgICBsZXQgcmVzdWx0ID0gKDE2ICogdmVyICsgMTI4KSAqIHZlciArIDY0O1xuICAgICAgaWYgKHZlciA+PSAyKSB7XG4gICAgICAgIGNvbnN0IG51bUFsaWduID0gTWF0aC5mbG9vcih2ZXIgLyA3KSArIDI7XG4gICAgICAgIHJlc3VsdCAtPSAoMjUgKiBudW1BbGlnbiAtIDEwKSAqIG51bUFsaWduIC0gNTU7XG4gICAgICAgIGlmICh2ZXIgPj0gNylcbiAgICAgICAgICByZXN1bHQgLT0gMzY7XG4gICAgICB9XG4gICAgICBhc3NlcnQoMjA4IDw9IHJlc3VsdCAmJiByZXN1bHQgPD0gMjk2NDgpO1xuICAgICAgcmV0dXJuIHJlc3VsdDtcbiAgICB9XG4gICAgLy8gUmV0dXJucyB0aGUgbnVtYmVyIG9mIDgtYml0IGRhdGEgKGkuZS4gbm90IGVycm9yIGNvcnJlY3Rpb24pIGNvZGV3b3JkcyBjb250YWluZWQgaW4gYW55XG4gICAgLy8gUVIgQ29kZSBvZiB0aGUgZ2l2ZW4gdmVyc2lvbiBudW1iZXIgYW5kIGVycm9yIGNvcnJlY3Rpb24gbGV2ZWwsIHdpdGggcmVtYWluZGVyIGJpdHMgZGlzY2FyZGVkLlxuICAgIC8vIFRoaXMgc3RhdGVsZXNzIHB1cmUgZnVuY3Rpb24gY291bGQgYmUgaW1wbGVtZW50ZWQgYXMgYSAoNDAqNCktY2VsbCBsb29rdXAgdGFibGUuXG4gICAgc3RhdGljIGdldE51bURhdGFDb2Rld29yZHModmVyLCBlY2wpIHtcbiAgICAgIHJldHVybiBNYXRoLmZsb29yKF9RckNvZGUuZ2V0TnVtUmF3RGF0YU1vZHVsZXModmVyKSAvIDgpIC0gX1FyQ29kZS5FQ0NfQ09ERVdPUkRTX1BFUl9CTE9DS1tlY2wub3JkaW5hbF1bdmVyXSAqIF9RckNvZGUuTlVNX0VSUk9SX0NPUlJFQ1RJT05fQkxPQ0tTW2VjbC5vcmRpbmFsXVt2ZXJdO1xuICAgIH1cbiAgICAvLyBSZXR1cm5zIGEgUmVlZC1Tb2xvbW9uIEVDQyBnZW5lcmF0b3IgcG9seW5vbWlhbCBmb3IgdGhlIGdpdmVuIGRlZ3JlZS4gVGhpcyBjb3VsZCBiZVxuICAgIC8vIGltcGxlbWVudGVkIGFzIGEgbG9va3VwIHRhYmxlIG92ZXIgYWxsIHBvc3NpYmxlIHBhcmFtZXRlciB2YWx1ZXMsIGluc3RlYWQgb2YgYXMgYW4gYWxnb3JpdGhtLlxuICAgIHN0YXRpYyByZWVkU29sb21vbkNvbXB1dGVEaXZpc29yKGRlZ3JlZSkge1xuICAgICAgaWYgKGRlZ3JlZSA8IDEgfHwgZGVncmVlID4gMjU1KVxuICAgICAgICB0aHJvdyBuZXcgUmFuZ2VFcnJvcihcIkRlZ3JlZSBvdXQgb2YgcmFuZ2VcIik7XG4gICAgICBsZXQgcmVzdWx0ID0gW107XG4gICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGRlZ3JlZSAtIDE7IGkrKylcbiAgICAgICAgcmVzdWx0LnB1c2goMCk7XG4gICAgICByZXN1bHQucHVzaCgxKTtcbiAgICAgIGxldCByb290ID0gMTtcbiAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgZGVncmVlOyBpKyspIHtcbiAgICAgICAgZm9yIChsZXQgaiA9IDA7IGogPCByZXN1bHQubGVuZ3RoOyBqKyspIHtcbiAgICAgICAgICByZXN1bHRbal0gPSBfUXJDb2RlLnJlZWRTb2xvbW9uTXVsdGlwbHkocmVzdWx0W2pdLCByb290KTtcbiAgICAgICAgICBpZiAoaiArIDEgPCByZXN1bHQubGVuZ3RoKVxuICAgICAgICAgICAgcmVzdWx0W2pdIF49IHJlc3VsdFtqICsgMV07XG4gICAgICAgIH1cbiAgICAgICAgcm9vdCA9IF9RckNvZGUucmVlZFNvbG9tb25NdWx0aXBseShyb290LCAyKTtcbiAgICAgIH1cbiAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgfVxuICAgIC8vIFJldHVybnMgdGhlIFJlZWQtU29sb21vbiBlcnJvciBjb3JyZWN0aW9uIGNvZGV3b3JkIGZvciB0aGUgZ2l2ZW4gZGF0YSBhbmQgZGl2aXNvciBwb2x5bm9taWFscy5cbiAgICBzdGF0aWMgcmVlZFNvbG9tb25Db21wdXRlUmVtYWluZGVyKGRhdGEsIGRpdmlzb3IpIHtcbiAgICAgIGxldCByZXN1bHQgPSBkaXZpc29yLm1hcCgoXykgPT4gMCk7XG4gICAgICBmb3IgKGNvbnN0IGIgb2YgZGF0YSkge1xuICAgICAgICBjb25zdCBmYWN0b3IgPSBiIF4gcmVzdWx0LnNoaWZ0KCk7XG4gICAgICAgIHJlc3VsdC5wdXNoKDApO1xuICAgICAgICBkaXZpc29yLmZvckVhY2goKGNvZWYsIGkpID0+IHJlc3VsdFtpXSBePSBfUXJDb2RlLnJlZWRTb2xvbW9uTXVsdGlwbHkoY29lZiwgZmFjdG9yKSk7XG4gICAgICB9XG4gICAgICByZXR1cm4gcmVzdWx0O1xuICAgIH1cbiAgICAvLyBSZXR1cm5zIHRoZSBwcm9kdWN0IG9mIHRoZSB0d28gZ2l2ZW4gZmllbGQgZWxlbWVudHMgbW9kdWxvIEdGKDJeOC8weDExRCkuIFRoZSBhcmd1bWVudHMgYW5kIHJlc3VsdFxuICAgIC8vIGFyZSB1bnNpZ25lZCA4LWJpdCBpbnRlZ2Vycy4gVGhpcyBjb3VsZCBiZSBpbXBsZW1lbnRlZCBhcyBhIGxvb2t1cCB0YWJsZSBvZiAyNTYqMjU2IGVudHJpZXMgb2YgdWludDguXG4gICAgc3RhdGljIHJlZWRTb2xvbW9uTXVsdGlwbHkoeCwgeSkge1xuICAgICAgaWYgKHggPj4+IDggIT0gMCB8fCB5ID4+PiA4ICE9IDApXG4gICAgICAgIHRocm93IG5ldyBSYW5nZUVycm9yKFwiQnl0ZSBvdXQgb2YgcmFuZ2VcIik7XG4gICAgICBsZXQgeiA9IDA7XG4gICAgICBmb3IgKGxldCBpID0gNzsgaSA+PSAwOyBpLS0pIHtcbiAgICAgICAgeiA9IHogPDwgMSBeICh6ID4+PiA3KSAqIDI4NTtcbiAgICAgICAgeiBePSAoeSA+Pj4gaSAmIDEpICogeDtcbiAgICAgIH1cbiAgICAgIGFzc2VydCh6ID4+PiA4ID09IDApO1xuICAgICAgcmV0dXJuIHo7XG4gICAgfVxuICAgIC8vIENhbiBvbmx5IGJlIGNhbGxlZCBpbW1lZGlhdGVseSBhZnRlciBhIGxpZ2h0IHJ1biBpcyBhZGRlZCwgYW5kXG4gICAgLy8gcmV0dXJucyBlaXRoZXIgMCwgMSwgb3IgMi4gQSBoZWxwZXIgZnVuY3Rpb24gZm9yIGdldFBlbmFsdHlTY29yZSgpLlxuICAgIGZpbmRlclBlbmFsdHlDb3VudFBhdHRlcm5zKHJ1bkhpc3RvcnkpIHtcbiAgICAgIGNvbnN0IG4gPSBydW5IaXN0b3J5WzFdO1xuICAgICAgYXNzZXJ0KG4gPD0gdGhpcy5zaXplICogMyk7XG4gICAgICBjb25zdCBjb3JlID0gbiA+IDAgJiYgcnVuSGlzdG9yeVsyXSA9PSBuICYmIHJ1bkhpc3RvcnlbM10gPT0gbiAqIDMgJiYgcnVuSGlzdG9yeVs0XSA9PSBuICYmIHJ1bkhpc3RvcnlbNV0gPT0gbjtcbiAgICAgIHJldHVybiAoY29yZSAmJiBydW5IaXN0b3J5WzBdID49IG4gKiA0ICYmIHJ1bkhpc3RvcnlbNl0gPj0gbiA/IDEgOiAwKSArIChjb3JlICYmIHJ1bkhpc3RvcnlbNl0gPj0gbiAqIDQgJiYgcnVuSGlzdG9yeVswXSA+PSBuID8gMSA6IDApO1xuICAgIH1cbiAgICAvLyBNdXN0IGJlIGNhbGxlZCBhdCB0aGUgZW5kIG9mIGEgbGluZSAocm93IG9yIGNvbHVtbikgb2YgbW9kdWxlcy4gQSBoZWxwZXIgZnVuY3Rpb24gZm9yIGdldFBlbmFsdHlTY29yZSgpLlxuICAgIGZpbmRlclBlbmFsdHlUZXJtaW5hdGVBbmRDb3VudChjdXJyZW50UnVuQ29sb3IsIGN1cnJlbnRSdW5MZW5ndGgsIHJ1bkhpc3RvcnkpIHtcbiAgICAgIGlmIChjdXJyZW50UnVuQ29sb3IpIHtcbiAgICAgICAgdGhpcy5maW5kZXJQZW5hbHR5QWRkSGlzdG9yeShjdXJyZW50UnVuTGVuZ3RoLCBydW5IaXN0b3J5KTtcbiAgICAgICAgY3VycmVudFJ1bkxlbmd0aCA9IDA7XG4gICAgICB9XG4gICAgICBjdXJyZW50UnVuTGVuZ3RoICs9IHRoaXMuc2l6ZTtcbiAgICAgIHRoaXMuZmluZGVyUGVuYWx0eUFkZEhpc3RvcnkoY3VycmVudFJ1bkxlbmd0aCwgcnVuSGlzdG9yeSk7XG4gICAgICByZXR1cm4gdGhpcy5maW5kZXJQZW5hbHR5Q291bnRQYXR0ZXJucyhydW5IaXN0b3J5KTtcbiAgICB9XG4gICAgLy8gUHVzaGVzIHRoZSBnaXZlbiB2YWx1ZSB0byB0aGUgZnJvbnQgYW5kIGRyb3BzIHRoZSBsYXN0IHZhbHVlLiBBIGhlbHBlciBmdW5jdGlvbiBmb3IgZ2V0UGVuYWx0eVNjb3JlKCkuXG4gICAgZmluZGVyUGVuYWx0eUFkZEhpc3RvcnkoY3VycmVudFJ1bkxlbmd0aCwgcnVuSGlzdG9yeSkge1xuICAgICAgaWYgKHJ1bkhpc3RvcnlbMF0gPT0gMClcbiAgICAgICAgY3VycmVudFJ1bkxlbmd0aCArPSB0aGlzLnNpemU7XG4gICAgICBydW5IaXN0b3J5LnBvcCgpO1xuICAgICAgcnVuSGlzdG9yeS51bnNoaWZ0KGN1cnJlbnRSdW5MZW5ndGgpO1xuICAgIH1cbiAgfTtcbiAgLyotLSBDb25zdGFudHMgYW5kIHRhYmxlcyAtLSovXG4gIC8vIFRoZSBtaW5pbXVtIHZlcnNpb24gbnVtYmVyIHN1cHBvcnRlZCBpbiB0aGUgUVIgQ29kZSBNb2RlbCAyIHN0YW5kYXJkLlxuICBfUXJDb2RlLk1JTl9WRVJTSU9OID0gMTtcbiAgLy8gVGhlIG1heGltdW0gdmVyc2lvbiBudW1iZXIgc3VwcG9ydGVkIGluIHRoZSBRUiBDb2RlIE1vZGVsIDIgc3RhbmRhcmQuXG4gIF9RckNvZGUuTUFYX1ZFUlNJT04gPSA0MDtcbiAgLy8gRm9yIHVzZSBpbiBnZXRQZW5hbHR5U2NvcmUoKSwgd2hlbiBldmFsdWF0aW5nIHdoaWNoIG1hc2sgaXMgYmVzdC5cbiAgX1FyQ29kZS5QRU5BTFRZX04xID0gMztcbiAgX1FyQ29kZS5QRU5BTFRZX04yID0gMztcbiAgX1FyQ29kZS5QRU5BTFRZX04zID0gNDA7XG4gIF9RckNvZGUuUEVOQUxUWV9ONCA9IDEwO1xuICBfUXJDb2RlLkVDQ19DT0RFV09SRFNfUEVSX0JMT0NLID0gW1xuICAgIC8vIFZlcnNpb246IChub3RlIHRoYXQgaW5kZXggMCBpcyBmb3IgcGFkZGluZywgYW5kIGlzIHNldCB0byBhbiBpbGxlZ2FsIHZhbHVlKVxuICAgIC8vMCwgIDEsICAyLCAgMywgIDQsICA1LCAgNiwgIDcsICA4LCAgOSwgMTAsIDExLCAxMiwgMTMsIDE0LCAxNSwgMTYsIDE3LCAxOCwgMTksIDIwLCAyMSwgMjIsIDIzLCAyNCwgMjUsIDI2LCAyNywgMjgsIDI5LCAzMCwgMzEsIDMyLCAzMywgMzQsIDM1LCAzNiwgMzcsIDM4LCAzOSwgNDAgICAgRXJyb3IgY29ycmVjdGlvbiBsZXZlbFxuICAgIFstMSwgNywgMTAsIDE1LCAyMCwgMjYsIDE4LCAyMCwgMjQsIDMwLCAxOCwgMjAsIDI0LCAyNiwgMzAsIDIyLCAyNCwgMjgsIDMwLCAyOCwgMjgsIDI4LCAyOCwgMzAsIDMwLCAyNiwgMjgsIDMwLCAzMCwgMzAsIDMwLCAzMCwgMzAsIDMwLCAzMCwgMzAsIDMwLCAzMCwgMzAsIDMwLCAzMF0sXG4gICAgLy8gTG93XG4gICAgWy0xLCAxMCwgMTYsIDI2LCAxOCwgMjQsIDE2LCAxOCwgMjIsIDIyLCAyNiwgMzAsIDIyLCAyMiwgMjQsIDI0LCAyOCwgMjgsIDI2LCAyNiwgMjYsIDI2LCAyOCwgMjgsIDI4LCAyOCwgMjgsIDI4LCAyOCwgMjgsIDI4LCAyOCwgMjgsIDI4LCAyOCwgMjgsIDI4LCAyOCwgMjgsIDI4LCAyOF0sXG4gICAgLy8gTWVkaXVtXG4gICAgWy0xLCAxMywgMjIsIDE4LCAyNiwgMTgsIDI0LCAxOCwgMjIsIDIwLCAyNCwgMjgsIDI2LCAyNCwgMjAsIDMwLCAyNCwgMjgsIDI4LCAyNiwgMzAsIDI4LCAzMCwgMzAsIDMwLCAzMCwgMjgsIDMwLCAzMCwgMzAsIDMwLCAzMCwgMzAsIDMwLCAzMCwgMzAsIDMwLCAzMCwgMzAsIDMwLCAzMF0sXG4gICAgLy8gUXVhcnRpbGVcbiAgICBbLTEsIDE3LCAyOCwgMjIsIDE2LCAyMiwgMjgsIDI2LCAyNiwgMjQsIDI4LCAyNCwgMjgsIDIyLCAyNCwgMjQsIDMwLCAyOCwgMjgsIDI2LCAyOCwgMzAsIDI0LCAzMCwgMzAsIDMwLCAzMCwgMzAsIDMwLCAzMCwgMzAsIDMwLCAzMCwgMzAsIDMwLCAzMCwgMzAsIDMwLCAzMCwgMzAsIDMwXVxuICAgIC8vIEhpZ2hcbiAgXTtcbiAgX1FyQ29kZS5OVU1fRVJST1JfQ09SUkVDVElPTl9CTE9DS1MgPSBbXG4gICAgLy8gVmVyc2lvbjogKG5vdGUgdGhhdCBpbmRleCAwIGlzIGZvciBwYWRkaW5nLCBhbmQgaXMgc2V0IHRvIGFuIGlsbGVnYWwgdmFsdWUpXG4gICAgLy8wLCAxLCAyLCAzLCA0LCA1LCA2LCA3LCA4LCA5LDEwLCAxMSwgMTIsIDEzLCAxNCwgMTUsIDE2LCAxNywgMTgsIDE5LCAyMCwgMjEsIDIyLCAyMywgMjQsIDI1LCAyNiwgMjcsIDI4LCAyOSwgMzAsIDMxLCAzMiwgMzMsIDM0LCAzNSwgMzYsIDM3LCAzOCwgMzksIDQwICAgIEVycm9yIGNvcnJlY3Rpb24gbGV2ZWxcbiAgICBbLTEsIDEsIDEsIDEsIDEsIDEsIDIsIDIsIDIsIDIsIDQsIDQsIDQsIDQsIDQsIDYsIDYsIDYsIDYsIDcsIDgsIDgsIDksIDksIDEwLCAxMiwgMTIsIDEyLCAxMywgMTQsIDE1LCAxNiwgMTcsIDE4LCAxOSwgMTksIDIwLCAyMSwgMjIsIDI0LCAyNV0sXG4gICAgLy8gTG93XG4gICAgWy0xLCAxLCAxLCAxLCAyLCAyLCA0LCA0LCA0LCA1LCA1LCA1LCA4LCA5LCA5LCAxMCwgMTAsIDExLCAxMywgMTQsIDE2LCAxNywgMTcsIDE4LCAyMCwgMjEsIDIzLCAyNSwgMjYsIDI4LCAyOSwgMzEsIDMzLCAzNSwgMzcsIDM4LCA0MCwgNDMsIDQ1LCA0NywgNDldLFxuICAgIC8vIE1lZGl1bVxuICAgIFstMSwgMSwgMSwgMiwgMiwgNCwgNCwgNiwgNiwgOCwgOCwgOCwgMTAsIDEyLCAxNiwgMTIsIDE3LCAxNiwgMTgsIDIxLCAyMCwgMjMsIDIzLCAyNSwgMjcsIDI5LCAzNCwgMzQsIDM1LCAzOCwgNDAsIDQzLCA0NSwgNDgsIDUxLCA1MywgNTYsIDU5LCA2MiwgNjUsIDY4XSxcbiAgICAvLyBRdWFydGlsZVxuICAgIFstMSwgMSwgMSwgMiwgNCwgNCwgNCwgNSwgNiwgOCwgOCwgMTEsIDExLCAxNiwgMTYsIDE4LCAxNiwgMTksIDIxLCAyNSwgMjUsIDI1LCAzNCwgMzAsIDMyLCAzNSwgMzcsIDQwLCA0MiwgNDUsIDQ4LCA1MSwgNTQsIDU3LCA2MCwgNjMsIDY2LCA3MCwgNzQsIDc3LCA4MV1cbiAgICAvLyBIaWdoXG4gIF07XG4gIGxldCBRckNvZGUgPSBfUXJDb2RlO1xuICBxcmNvZGVnZW4yLlFyQ29kZSA9IF9RckNvZGU7XG4gIGZ1bmN0aW9uIGFwcGVuZEJpdHModmFsLCBsZW4sIGJiKSB7XG4gICAgaWYgKGxlbiA8IDAgfHwgbGVuID4gMzEgfHwgdmFsID4+PiBsZW4gIT0gMClcbiAgICAgIHRocm93IG5ldyBSYW5nZUVycm9yKFwiVmFsdWUgb3V0IG9mIHJhbmdlXCIpO1xuICAgIGZvciAobGV0IGkgPSBsZW4gLSAxOyBpID49IDA7IGktLSlcbiAgICAgIGJiLnB1c2godmFsID4+PiBpICYgMSk7XG4gIH1cbiAgZnVuY3Rpb24gZ2V0Qml0KHgsIGkpIHtcbiAgICByZXR1cm4gKHggPj4+IGkgJiAxKSAhPSAwO1xuICB9XG4gIGZ1bmN0aW9uIGFzc2VydChjb25kKSB7XG4gICAgaWYgKCFjb25kKVxuICAgICAgdGhyb3cgbmV3IEVycm9yKFwiQXNzZXJ0aW9uIGVycm9yXCIpO1xuICB9XG4gIGNvbnN0IF9RclNlZ21lbnQgPSBjbGFzcyBfUXJTZWdtZW50IHtcbiAgICAvKi0tIENvbnN0cnVjdG9yIChsb3cgbGV2ZWwpIGFuZCBmaWVsZHMgLS0qL1xuICAgIC8vIENyZWF0ZXMgYSBuZXcgUVIgQ29kZSBzZWdtZW50IHdpdGggdGhlIGdpdmVuIGF0dHJpYnV0ZXMgYW5kIGRhdGEuXG4gICAgLy8gVGhlIGNoYXJhY3RlciBjb3VudCAobnVtQ2hhcnMpIG11c3QgYWdyZWUgd2l0aCB0aGUgbW9kZSBhbmQgdGhlIGJpdCBidWZmZXIgbGVuZ3RoLFxuICAgIC8vIGJ1dCB0aGUgY29uc3RyYWludCBpc24ndCBjaGVja2VkLiBUaGUgZ2l2ZW4gYml0IGJ1ZmZlciBpcyBjbG9uZWQgYW5kIHN0b3JlZC5cbiAgICBjb25zdHJ1Y3Rvcihtb2RlLCBudW1DaGFycywgYml0RGF0YSkge1xuICAgICAgdGhpcy5tb2RlID0gbW9kZTtcbiAgICAgIHRoaXMubnVtQ2hhcnMgPSBudW1DaGFycztcbiAgICAgIHRoaXMuYml0RGF0YSA9IGJpdERhdGE7XG4gICAgICBpZiAobnVtQ2hhcnMgPCAwKVxuICAgICAgICB0aHJvdyBuZXcgUmFuZ2VFcnJvcihcIkludmFsaWQgYXJndW1lbnRcIik7XG4gICAgICB0aGlzLmJpdERhdGEgPSBiaXREYXRhLnNsaWNlKCk7XG4gICAgfVxuICAgIC8qLS0gU3RhdGljIGZhY3RvcnkgZnVuY3Rpb25zIChtaWQgbGV2ZWwpIC0tKi9cbiAgICAvLyBSZXR1cm5zIGEgc2VnbWVudCByZXByZXNlbnRpbmcgdGhlIGdpdmVuIGJpbmFyeSBkYXRhIGVuY29kZWQgaW5cbiAgICAvLyBieXRlIG1vZGUuIEFsbCBpbnB1dCBieXRlIGFycmF5cyBhcmUgYWNjZXB0YWJsZS4gQW55IHRleHQgc3RyaW5nXG4gICAgLy8gY2FuIGJlIGNvbnZlcnRlZCB0byBVVEYtOCBieXRlcyBhbmQgZW5jb2RlZCBhcyBhIGJ5dGUgbW9kZSBzZWdtZW50LlxuICAgIHN0YXRpYyBtYWtlQnl0ZXMoZGF0YSkge1xuICAgICAgbGV0IGJiID0gW107XG4gICAgICBmb3IgKGNvbnN0IGIgb2YgZGF0YSlcbiAgICAgICAgYXBwZW5kQml0cyhiLCA4LCBiYik7XG4gICAgICByZXR1cm4gbmV3IF9RclNlZ21lbnQoX1FyU2VnbWVudC5Nb2RlLkJZVEUsIGRhdGEubGVuZ3RoLCBiYik7XG4gICAgfVxuICAgIC8vIFJldHVybnMgYSBzZWdtZW50IHJlcHJlc2VudGluZyB0aGUgZ2l2ZW4gc3RyaW5nIG9mIGRlY2ltYWwgZGlnaXRzIGVuY29kZWQgaW4gbnVtZXJpYyBtb2RlLlxuICAgIHN0YXRpYyBtYWtlTnVtZXJpYyhkaWdpdHMpIHtcbiAgICAgIGlmICghX1FyU2VnbWVudC5pc051bWVyaWMoZGlnaXRzKSlcbiAgICAgICAgdGhyb3cgbmV3IFJhbmdlRXJyb3IoXCJTdHJpbmcgY29udGFpbnMgbm9uLW51bWVyaWMgY2hhcmFjdGVyc1wiKTtcbiAgICAgIGxldCBiYiA9IFtdO1xuICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBkaWdpdHMubGVuZ3RoOyApIHtcbiAgICAgICAgY29uc3QgbiA9IE1hdGgubWluKGRpZ2l0cy5sZW5ndGggLSBpLCAzKTtcbiAgICAgICAgYXBwZW5kQml0cyhwYXJzZUludChkaWdpdHMuc3Vic3RyaW5nKGksIGkgKyBuKSwgMTApLCBuICogMyArIDEsIGJiKTtcbiAgICAgICAgaSArPSBuO1xuICAgICAgfVxuICAgICAgcmV0dXJuIG5ldyBfUXJTZWdtZW50KF9RclNlZ21lbnQuTW9kZS5OVU1FUklDLCBkaWdpdHMubGVuZ3RoLCBiYik7XG4gICAgfVxuICAgIC8vIFJldHVybnMgYSBzZWdtZW50IHJlcHJlc2VudGluZyB0aGUgZ2l2ZW4gdGV4dCBzdHJpbmcgZW5jb2RlZCBpbiBhbHBoYW51bWVyaWMgbW9kZS5cbiAgICAvLyBUaGUgY2hhcmFjdGVycyBhbGxvd2VkIGFyZTogMCB0byA5LCBBIHRvIFogKHVwcGVyY2FzZSBvbmx5KSwgc3BhY2UsXG4gICAgLy8gZG9sbGFyLCBwZXJjZW50LCBhc3RlcmlzaywgcGx1cywgaHlwaGVuLCBwZXJpb2QsIHNsYXNoLCBjb2xvbi5cbiAgICBzdGF0aWMgbWFrZUFscGhhbnVtZXJpYyh0ZXh0KSB7XG4gICAgICBpZiAoIV9RclNlZ21lbnQuaXNBbHBoYW51bWVyaWModGV4dCkpXG4gICAgICAgIHRocm93IG5ldyBSYW5nZUVycm9yKFwiU3RyaW5nIGNvbnRhaW5zIHVuZW5jb2RhYmxlIGNoYXJhY3RlcnMgaW4gYWxwaGFudW1lcmljIG1vZGVcIik7XG4gICAgICBsZXQgYmIgPSBbXTtcbiAgICAgIGxldCBpO1xuICAgICAgZm9yIChpID0gMDsgaSArIDIgPD0gdGV4dC5sZW5ndGg7IGkgKz0gMikge1xuICAgICAgICBsZXQgdGVtcCA9IF9RclNlZ21lbnQuQUxQSEFOVU1FUklDX0NIQVJTRVQuaW5kZXhPZih0ZXh0LmNoYXJBdChpKSkgKiA0NTtcbiAgICAgICAgdGVtcCArPSBfUXJTZWdtZW50LkFMUEhBTlVNRVJJQ19DSEFSU0VULmluZGV4T2YodGV4dC5jaGFyQXQoaSArIDEpKTtcbiAgICAgICAgYXBwZW5kQml0cyh0ZW1wLCAxMSwgYmIpO1xuICAgICAgfVxuICAgICAgaWYgKGkgPCB0ZXh0Lmxlbmd0aClcbiAgICAgICAgYXBwZW5kQml0cyhfUXJTZWdtZW50LkFMUEhBTlVNRVJJQ19DSEFSU0VULmluZGV4T2YodGV4dC5jaGFyQXQoaSkpLCA2LCBiYik7XG4gICAgICByZXR1cm4gbmV3IF9RclNlZ21lbnQoX1FyU2VnbWVudC5Nb2RlLkFMUEhBTlVNRVJJQywgdGV4dC5sZW5ndGgsIGJiKTtcbiAgICB9XG4gICAgLy8gUmV0dXJucyBhIG5ldyBtdXRhYmxlIGxpc3Qgb2YgemVybyBvciBtb3JlIHNlZ21lbnRzIHRvIHJlcHJlc2VudCB0aGUgZ2l2ZW4gVW5pY29kZSB0ZXh0IHN0cmluZy5cbiAgICAvLyBUaGUgcmVzdWx0IG1heSB1c2UgdmFyaW91cyBzZWdtZW50IG1vZGVzIGFuZCBzd2l0Y2ggbW9kZXMgdG8gb3B0aW1pemUgdGhlIGxlbmd0aCBvZiB0aGUgYml0IHN0cmVhbS5cbiAgICBzdGF0aWMgbWFrZVNlZ21lbnRzKHRleHQpIHtcbiAgICAgIGlmICh0ZXh0ID09IFwiXCIpXG4gICAgICAgIHJldHVybiBbXTtcbiAgICAgIGVsc2UgaWYgKF9RclNlZ21lbnQuaXNOdW1lcmljKHRleHQpKVxuICAgICAgICByZXR1cm4gW19RclNlZ21lbnQubWFrZU51bWVyaWModGV4dCldO1xuICAgICAgZWxzZSBpZiAoX1FyU2VnbWVudC5pc0FscGhhbnVtZXJpYyh0ZXh0KSlcbiAgICAgICAgcmV0dXJuIFtfUXJTZWdtZW50Lm1ha2VBbHBoYW51bWVyaWModGV4dCldO1xuICAgICAgZWxzZVxuICAgICAgICByZXR1cm4gW19RclNlZ21lbnQubWFrZUJ5dGVzKF9RclNlZ21lbnQudG9VdGY4Qnl0ZUFycmF5KHRleHQpKV07XG4gICAgfVxuICAgIC8vIFJldHVybnMgYSBzZWdtZW50IHJlcHJlc2VudGluZyBhbiBFeHRlbmRlZCBDaGFubmVsIEludGVycHJldGF0aW9uXG4gICAgLy8gKEVDSSkgZGVzaWduYXRvciB3aXRoIHRoZSBnaXZlbiBhc3NpZ25tZW50IHZhbHVlLlxuICAgIHN0YXRpYyBtYWtlRWNpKGFzc2lnblZhbCkge1xuICAgICAgbGV0IGJiID0gW107XG4gICAgICBpZiAoYXNzaWduVmFsIDwgMClcbiAgICAgICAgdGhyb3cgbmV3IFJhbmdlRXJyb3IoXCJFQ0kgYXNzaWdubWVudCB2YWx1ZSBvdXQgb2YgcmFuZ2VcIik7XG4gICAgICBlbHNlIGlmIChhc3NpZ25WYWwgPCAxIDw8IDcpXG4gICAgICAgIGFwcGVuZEJpdHMoYXNzaWduVmFsLCA4LCBiYik7XG4gICAgICBlbHNlIGlmIChhc3NpZ25WYWwgPCAxIDw8IDE0KSB7XG4gICAgICAgIGFwcGVuZEJpdHMoMiwgMiwgYmIpO1xuICAgICAgICBhcHBlbmRCaXRzKGFzc2lnblZhbCwgMTQsIGJiKTtcbiAgICAgIH0gZWxzZSBpZiAoYXNzaWduVmFsIDwgMWU2KSB7XG4gICAgICAgIGFwcGVuZEJpdHMoNiwgMywgYmIpO1xuICAgICAgICBhcHBlbmRCaXRzKGFzc2lnblZhbCwgMjEsIGJiKTtcbiAgICAgIH0gZWxzZVxuICAgICAgICB0aHJvdyBuZXcgUmFuZ2VFcnJvcihcIkVDSSBhc3NpZ25tZW50IHZhbHVlIG91dCBvZiByYW5nZVwiKTtcbiAgICAgIHJldHVybiBuZXcgX1FyU2VnbWVudChfUXJTZWdtZW50Lk1vZGUuRUNJLCAwLCBiYik7XG4gICAgfVxuICAgIC8vIFRlc3RzIHdoZXRoZXIgdGhlIGdpdmVuIHN0cmluZyBjYW4gYmUgZW5jb2RlZCBhcyBhIHNlZ21lbnQgaW4gbnVtZXJpYyBtb2RlLlxuICAgIC8vIEEgc3RyaW5nIGlzIGVuY29kYWJsZSBpZmYgZWFjaCBjaGFyYWN0ZXIgaXMgaW4gdGhlIHJhbmdlIDAgdG8gOS5cbiAgICBzdGF0aWMgaXNOdW1lcmljKHRleHQpIHtcbiAgICAgIHJldHVybiBfUXJTZWdtZW50Lk5VTUVSSUNfUkVHRVgudGVzdCh0ZXh0KTtcbiAgICB9XG4gICAgLy8gVGVzdHMgd2hldGhlciB0aGUgZ2l2ZW4gc3RyaW5nIGNhbiBiZSBlbmNvZGVkIGFzIGEgc2VnbWVudCBpbiBhbHBoYW51bWVyaWMgbW9kZS5cbiAgICAvLyBBIHN0cmluZyBpcyBlbmNvZGFibGUgaWZmIGVhY2ggY2hhcmFjdGVyIGlzIGluIHRoZSBmb2xsb3dpbmcgc2V0OiAwIHRvIDksIEEgdG8gWlxuICAgIC8vICh1cHBlcmNhc2Ugb25seSksIHNwYWNlLCBkb2xsYXIsIHBlcmNlbnQsIGFzdGVyaXNrLCBwbHVzLCBoeXBoZW4sIHBlcmlvZCwgc2xhc2gsIGNvbG9uLlxuICAgIHN0YXRpYyBpc0FscGhhbnVtZXJpYyh0ZXh0KSB7XG4gICAgICByZXR1cm4gX1FyU2VnbWVudC5BTFBIQU5VTUVSSUNfUkVHRVgudGVzdCh0ZXh0KTtcbiAgICB9XG4gICAgLyotLSBNZXRob2RzIC0tKi9cbiAgICAvLyBSZXR1cm5zIGEgbmV3IGNvcHkgb2YgdGhlIGRhdGEgYml0cyBvZiB0aGlzIHNlZ21lbnQuXG4gICAgZ2V0RGF0YSgpIHtcbiAgICAgIHJldHVybiB0aGlzLmJpdERhdGEuc2xpY2UoKTtcbiAgICB9XG4gICAgLy8gKFBhY2thZ2UtcHJpdmF0ZSkgQ2FsY3VsYXRlcyBhbmQgcmV0dXJucyB0aGUgbnVtYmVyIG9mIGJpdHMgbmVlZGVkIHRvIGVuY29kZSB0aGUgZ2l2ZW4gc2VnbWVudHMgYXRcbiAgICAvLyB0aGUgZ2l2ZW4gdmVyc2lvbi4gVGhlIHJlc3VsdCBpcyBpbmZpbml0eSBpZiBhIHNlZ21lbnQgaGFzIHRvbyBtYW55IGNoYXJhY3RlcnMgdG8gZml0IGl0cyBsZW5ndGggZmllbGQuXG4gICAgc3RhdGljIGdldFRvdGFsQml0cyhzZWdzLCB2ZXJzaW9uKSB7XG4gICAgICBsZXQgcmVzdWx0ID0gMDtcbiAgICAgIGZvciAoY29uc3Qgc2VnIG9mIHNlZ3MpIHtcbiAgICAgICAgY29uc3QgY2NiaXRzID0gc2VnLm1vZGUubnVtQ2hhckNvdW50Qml0cyh2ZXJzaW9uKTtcbiAgICAgICAgaWYgKHNlZy5udW1DaGFycyA+PSAxIDw8IGNjYml0cylcbiAgICAgICAgICByZXR1cm4gSW5maW5pdHk7XG4gICAgICAgIHJlc3VsdCArPSA0ICsgY2NiaXRzICsgc2VnLmJpdERhdGEubGVuZ3RoO1xuICAgICAgfVxuICAgICAgcmV0dXJuIHJlc3VsdDtcbiAgICB9XG4gICAgLy8gUmV0dXJucyBhIG5ldyBhcnJheSBvZiBieXRlcyByZXByZXNlbnRpbmcgdGhlIGdpdmVuIHN0cmluZyBlbmNvZGVkIGluIFVURi04LlxuICAgIHN0YXRpYyB0b1V0ZjhCeXRlQXJyYXkoc3RyKSB7XG4gICAgICBzdHIgPSBlbmNvZGVVUkkoc3RyKTtcbiAgICAgIGxldCByZXN1bHQgPSBbXTtcbiAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgc3RyLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgIGlmIChzdHIuY2hhckF0KGkpICE9IFwiJVwiKVxuICAgICAgICAgIHJlc3VsdC5wdXNoKHN0ci5jaGFyQ29kZUF0KGkpKTtcbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgcmVzdWx0LnB1c2gocGFyc2VJbnQoc3RyLnN1YnN0cmluZyhpICsgMSwgaSArIDMpLCAxNikpO1xuICAgICAgICAgIGkgKz0gMjtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgcmV0dXJuIHJlc3VsdDtcbiAgICB9XG4gIH07XG4gIC8qLS0gQ29uc3RhbnRzIC0tKi9cbiAgLy8gRGVzY3JpYmVzIHByZWNpc2VseSBhbGwgc3RyaW5ncyB0aGF0IGFyZSBlbmNvZGFibGUgaW4gbnVtZXJpYyBtb2RlLlxuICBfUXJTZWdtZW50Lk5VTUVSSUNfUkVHRVggPSAvXlswLTldKiQvO1xuICAvLyBEZXNjcmliZXMgcHJlY2lzZWx5IGFsbCBzdHJpbmdzIHRoYXQgYXJlIGVuY29kYWJsZSBpbiBhbHBoYW51bWVyaWMgbW9kZS5cbiAgX1FyU2VnbWVudC5BTFBIQU5VTUVSSUNfUkVHRVggPSAvXltBLVowLTkgJCUqKy5cXC86LV0qJC87XG4gIC8vIFRoZSBzZXQgb2YgYWxsIGxlZ2FsIGNoYXJhY3RlcnMgaW4gYWxwaGFudW1lcmljIG1vZGUsXG4gIC8vIHdoZXJlIGVhY2ggY2hhcmFjdGVyIHZhbHVlIG1hcHMgdG8gdGhlIGluZGV4IGluIHRoZSBzdHJpbmcuXG4gIF9RclNlZ21lbnQuQUxQSEFOVU1FUklDX0NIQVJTRVQgPSBcIjAxMjM0NTY3ODlBQkNERUZHSElKS0xNTk9QUVJTVFVWV1hZWiAkJSorLS4vOlwiO1xuICBsZXQgUXJTZWdtZW50ID0gX1FyU2VnbWVudDtcbiAgcXJjb2RlZ2VuMi5RclNlZ21lbnQgPSBfUXJTZWdtZW50O1xufSkocXJjb2RlZ2VuIHx8IChxcmNvZGVnZW4gPSB7fSkpO1xuKChxcmNvZGVnZW4yKSA9PiB7XG4gIGxldCBRckNvZGU7XG4gICgoUXJDb2RlMikgPT4ge1xuICAgIGNvbnN0IF9FY2MgPSBjbGFzcyBfRWNjIHtcbiAgICAgIC8vIFRoZSBRUiBDb2RlIGNhbiB0b2xlcmF0ZSBhYm91dCAzMCUgZXJyb25lb3VzIGNvZGV3b3Jkc1xuICAgICAgLyotLSBDb25zdHJ1Y3RvciBhbmQgZmllbGRzIC0tKi9cbiAgICAgIGNvbnN0cnVjdG9yKG9yZGluYWwsIGZvcm1hdEJpdHMpIHtcbiAgICAgICAgdGhpcy5vcmRpbmFsID0gb3JkaW5hbDtcbiAgICAgICAgdGhpcy5mb3JtYXRCaXRzID0gZm9ybWF0Qml0cztcbiAgICAgIH1cbiAgICB9O1xuICAgIC8qLS0gQ29uc3RhbnRzIC0tKi9cbiAgICBfRWNjLkxPVyA9IG5ldyBfRWNjKDAsIDEpO1xuICAgIC8vIFRoZSBRUiBDb2RlIGNhbiB0b2xlcmF0ZSBhYm91dCAgNyUgZXJyb25lb3VzIGNvZGV3b3Jkc1xuICAgIF9FY2MuTUVESVVNID0gbmV3IF9FY2MoMSwgMCk7XG4gICAgLy8gVGhlIFFSIENvZGUgY2FuIHRvbGVyYXRlIGFib3V0IDE1JSBlcnJvbmVvdXMgY29kZXdvcmRzXG4gICAgX0VjYy5RVUFSVElMRSA9IG5ldyBfRWNjKDIsIDMpO1xuICAgIC8vIFRoZSBRUiBDb2RlIGNhbiB0b2xlcmF0ZSBhYm91dCAyNSUgZXJyb25lb3VzIGNvZGV3b3Jkc1xuICAgIF9FY2MuSElHSCA9IG5ldyBfRWNjKDMsIDIpO1xuICAgIGxldCBFY2MgPSBfRWNjO1xuICAgIFFyQ29kZTIuRWNjID0gX0VjYztcbiAgfSkoUXJDb2RlID0gcXJjb2RlZ2VuMi5RckNvZGUgfHwgKHFyY29kZWdlbjIuUXJDb2RlID0ge30pKTtcbn0pKHFyY29kZWdlbiB8fCAocXJjb2RlZ2VuID0ge30pKTtcbigocXJjb2RlZ2VuMikgPT4ge1xuICBsZXQgUXJTZWdtZW50O1xuICAoKFFyU2VnbWVudDIpID0+IHtcbiAgICBjb25zdCBfTW9kZSA9IGNsYXNzIF9Nb2RlIHtcbiAgICAgIC8qLS0gQ29uc3RydWN0b3IgYW5kIGZpZWxkcyAtLSovXG4gICAgICBjb25zdHJ1Y3Rvcihtb2RlQml0cywgbnVtQml0c0NoYXJDb3VudCkge1xuICAgICAgICB0aGlzLm1vZGVCaXRzID0gbW9kZUJpdHM7XG4gICAgICAgIHRoaXMubnVtQml0c0NoYXJDb3VudCA9IG51bUJpdHNDaGFyQ291bnQ7XG4gICAgICB9XG4gICAgICAvKi0tIE1ldGhvZCAtLSovXG4gICAgICAvLyAoUGFja2FnZS1wcml2YXRlKSBSZXR1cm5zIHRoZSBiaXQgd2lkdGggb2YgdGhlIGNoYXJhY3RlciBjb3VudCBmaWVsZCBmb3IgYSBzZWdtZW50IGluXG4gICAgICAvLyB0aGlzIG1vZGUgaW4gYSBRUiBDb2RlIGF0IHRoZSBnaXZlbiB2ZXJzaW9uIG51bWJlci4gVGhlIHJlc3VsdCBpcyBpbiB0aGUgcmFuZ2UgWzAsIDE2XS5cbiAgICAgIG51bUNoYXJDb3VudEJpdHModmVyKSB7XG4gICAgICAgIHJldHVybiB0aGlzLm51bUJpdHNDaGFyQ291bnRbTWF0aC5mbG9vcigodmVyICsgNykgLyAxNyldO1xuICAgICAgfVxuICAgIH07XG4gICAgLyotLSBDb25zdGFudHMgLS0qL1xuICAgIF9Nb2RlLk5VTUVSSUMgPSBuZXcgX01vZGUoMSwgWzEwLCAxMiwgMTRdKTtcbiAgICBfTW9kZS5BTFBIQU5VTUVSSUMgPSBuZXcgX01vZGUoMiwgWzksIDExLCAxM10pO1xuICAgIF9Nb2RlLkJZVEUgPSBuZXcgX01vZGUoNCwgWzgsIDE2LCAxNl0pO1xuICAgIF9Nb2RlLktBTkpJID0gbmV3IF9Nb2RlKDgsIFs4LCAxMCwgMTJdKTtcbiAgICBfTW9kZS5FQ0kgPSBuZXcgX01vZGUoNywgWzAsIDAsIDBdKTtcbiAgICBsZXQgTW9kZSA9IF9Nb2RlO1xuICAgIFFyU2VnbWVudDIuTW9kZSA9IF9Nb2RlO1xuICB9KShRclNlZ21lbnQgPSBxcmNvZGVnZW4yLlFyU2VnbWVudCB8fCAocXJjb2RlZ2VuMi5RclNlZ21lbnQgPSB7fSkpO1xufSkocXJjb2RlZ2VuIHx8IChxcmNvZGVnZW4gPSB7fSkpO1xudmFyIHFyY29kZWdlbl9kZWZhdWx0ID0gcXJjb2RlZ2VuO1xuXG4vLyBzcmMvaW5kZXgudHN4XG4vKipcbiAqIEBsaWNlbnNlIHFyY29kZS5yZWFjdFxuICogQ29weXJpZ2h0IChjKSBQYXVsIE8nU2hhbm5lc3N5XG4gKiBTUERYLUxpY2Vuc2UtSWRlbnRpZmllcjogSVNDXG4gKi9cbnZhciBFUlJPUl9MRVZFTF9NQVAgPSB7XG4gIEw6IHFyY29kZWdlbl9kZWZhdWx0LlFyQ29kZS5FY2MuTE9XLFxuICBNOiBxcmNvZGVnZW5fZGVmYXVsdC5RckNvZGUuRWNjLk1FRElVTSxcbiAgUTogcXJjb2RlZ2VuX2RlZmF1bHQuUXJDb2RlLkVjYy5RVUFSVElMRSxcbiAgSDogcXJjb2RlZ2VuX2RlZmF1bHQuUXJDb2RlLkVjYy5ISUdIXG59O1xudmFyIERFRkFVTFRfU0laRSA9IDEyODtcbnZhciBERUZBVUxUX0xFVkVMID0gXCJMXCI7XG52YXIgREVGQVVMVF9CR0NPTE9SID0gXCIjRkZGRkZGXCI7XG52YXIgREVGQVVMVF9GR0NPTE9SID0gXCIjMDAwMDAwXCI7XG52YXIgREVGQVVMVF9JTkNMVURFTUFSR0lOID0gZmFsc2U7XG52YXIgREVGQVVMVF9NSU5WRVJTSU9OID0gMTtcbnZhciBTUEVDX01BUkdJTl9TSVpFID0gNDtcbnZhciBERUZBVUxUX01BUkdJTl9TSVpFID0gMDtcbnZhciBERUZBVUxUX0lNR19TQ0FMRSA9IDAuMTtcbmZ1bmN0aW9uIGdlbmVyYXRlUGF0aChtb2R1bGVzLCBtYXJnaW4gPSAwKSB7XG4gIGNvbnN0IG9wcyA9IFtdO1xuICBtb2R1bGVzLmZvckVhY2goZnVuY3Rpb24ocm93LCB5KSB7XG4gICAgbGV0IHN0YXJ0ID0gbnVsbDtcbiAgICByb3cuZm9yRWFjaChmdW5jdGlvbihjZWxsLCB4KSB7XG4gICAgICBpZiAoIWNlbGwgJiYgc3RhcnQgIT09IG51bGwpIHtcbiAgICAgICAgb3BzLnB1c2goXG4gICAgICAgICAgYE0ke3N0YXJ0ICsgbWFyZ2lufSAke3kgKyBtYXJnaW59aCR7eCAtIHN0YXJ0fXYxSCR7c3RhcnQgKyBtYXJnaW59emBcbiAgICAgICAgKTtcbiAgICAgICAgc3RhcnQgPSBudWxsO1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBpZiAoeCA9PT0gcm93Lmxlbmd0aCAtIDEpIHtcbiAgICAgICAgaWYgKCFjZWxsKSB7XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGlmIChzdGFydCA9PT0gbnVsbCkge1xuICAgICAgICAgIG9wcy5wdXNoKGBNJHt4ICsgbWFyZ2lufSwke3kgKyBtYXJnaW59IGgxdjFIJHt4ICsgbWFyZ2lufXpgKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBvcHMucHVzaChcbiAgICAgICAgICAgIGBNJHtzdGFydCArIG1hcmdpbn0sJHt5ICsgbWFyZ2lufSBoJHt4ICsgMSAtIHN0YXJ0fXYxSCR7c3RhcnQgKyBtYXJnaW59emBcbiAgICAgICAgICApO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIGlmIChjZWxsICYmIHN0YXJ0ID09PSBudWxsKSB7XG4gICAgICAgIHN0YXJ0ID0geDtcbiAgICAgIH1cbiAgICB9KTtcbiAgfSk7XG4gIHJldHVybiBvcHMuam9pbihcIlwiKTtcbn1cbmZ1bmN0aW9uIGV4Y2F2YXRlTW9kdWxlcyhtb2R1bGVzLCBleGNhdmF0aW9uKSB7XG4gIHJldHVybiBtb2R1bGVzLnNsaWNlKCkubWFwKChyb3csIHkpID0+IHtcbiAgICBpZiAoeSA8IGV4Y2F2YXRpb24ueSB8fCB5ID49IGV4Y2F2YXRpb24ueSArIGV4Y2F2YXRpb24uaCkge1xuICAgICAgcmV0dXJuIHJvdztcbiAgICB9XG4gICAgcmV0dXJuIHJvdy5tYXAoKGNlbGwsIHgpID0+IHtcbiAgICAgIGlmICh4IDwgZXhjYXZhdGlvbi54IHx8IHggPj0gZXhjYXZhdGlvbi54ICsgZXhjYXZhdGlvbi53KSB7XG4gICAgICAgIHJldHVybiBjZWxsO1xuICAgICAgfVxuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH0pO1xuICB9KTtcbn1cbmZ1bmN0aW9uIGdldEltYWdlU2V0dGluZ3MoY2VsbHMsIHNpemUsIG1hcmdpbiwgaW1hZ2VTZXR0aW5ncykge1xuICBpZiAoaW1hZ2VTZXR0aW5ncyA9PSBudWxsKSB7XG4gICAgcmV0dXJuIG51bGw7XG4gIH1cbiAgY29uc3QgbnVtQ2VsbHMgPSBjZWxscy5sZW5ndGggKyBtYXJnaW4gKiAyO1xuICBjb25zdCBkZWZhdWx0U2l6ZSA9IE1hdGguZmxvb3Ioc2l6ZSAqIERFRkFVTFRfSU1HX1NDQUxFKTtcbiAgY29uc3Qgc2NhbGUgPSBudW1DZWxscyAvIHNpemU7XG4gIGNvbnN0IHcgPSAoaW1hZ2VTZXR0aW5ncy53aWR0aCB8fCBkZWZhdWx0U2l6ZSkgKiBzY2FsZTtcbiAgY29uc3QgaCA9IChpbWFnZVNldHRpbmdzLmhlaWdodCB8fCBkZWZhdWx0U2l6ZSkgKiBzY2FsZTtcbiAgY29uc3QgeCA9IGltYWdlU2V0dGluZ3MueCA9PSBudWxsID8gY2VsbHMubGVuZ3RoIC8gMiAtIHcgLyAyIDogaW1hZ2VTZXR0aW5ncy54ICogc2NhbGU7XG4gIGNvbnN0IHkgPSBpbWFnZVNldHRpbmdzLnkgPT0gbnVsbCA/IGNlbGxzLmxlbmd0aCAvIDIgLSBoIC8gMiA6IGltYWdlU2V0dGluZ3MueSAqIHNjYWxlO1xuICBjb25zdCBvcGFjaXR5ID0gaW1hZ2VTZXR0aW5ncy5vcGFjaXR5ID09IG51bGwgPyAxIDogaW1hZ2VTZXR0aW5ncy5vcGFjaXR5O1xuICBsZXQgZXhjYXZhdGlvbiA9IG51bGw7XG4gIGlmIChpbWFnZVNldHRpbmdzLmV4Y2F2YXRlKSB7XG4gICAgbGV0IGZsb29yWCA9IE1hdGguZmxvb3IoeCk7XG4gICAgbGV0IGZsb29yWSA9IE1hdGguZmxvb3IoeSk7XG4gICAgbGV0IGNlaWxXID0gTWF0aC5jZWlsKHcgKyB4IC0gZmxvb3JYKTtcbiAgICBsZXQgY2VpbEggPSBNYXRoLmNlaWwoaCArIHkgLSBmbG9vclkpO1xuICAgIGV4Y2F2YXRpb24gPSB7IHg6IGZsb29yWCwgeTogZmxvb3JZLCB3OiBjZWlsVywgaDogY2VpbEggfTtcbiAgfVxuICBjb25zdCBjcm9zc09yaWdpbiA9IGltYWdlU2V0dGluZ3MuY3Jvc3NPcmlnaW47XG4gIHJldHVybiB7IHgsIHksIGgsIHcsIGV4Y2F2YXRpb24sIG9wYWNpdHksIGNyb3NzT3JpZ2luIH07XG59XG5mdW5jdGlvbiBnZXRNYXJnaW5TaXplKGluY2x1ZGVNYXJnaW4sIG1hcmdpblNpemUpIHtcbiAgaWYgKG1hcmdpblNpemUgIT0gbnVsbCkge1xuICAgIHJldHVybiBNYXRoLm1heChNYXRoLmZsb29yKG1hcmdpblNpemUpLCAwKTtcbiAgfVxuICByZXR1cm4gaW5jbHVkZU1hcmdpbiA/IFNQRUNfTUFSR0lOX1NJWkUgOiBERUZBVUxUX01BUkdJTl9TSVpFO1xufVxuZnVuY3Rpb24gdXNlUVJDb2RlKHtcbiAgdmFsdWUsXG4gIGxldmVsLFxuICBtaW5WZXJzaW9uLFxuICBpbmNsdWRlTWFyZ2luLFxuICBtYXJnaW5TaXplLFxuICBpbWFnZVNldHRpbmdzLFxuICBzaXplLFxuICBib29zdExldmVsXG59KSB7XG4gIGxldCBxcmNvZGUgPSBSZWFjdC51c2VNZW1vKCgpID0+IHtcbiAgICBjb25zdCB2YWx1ZXMgPSBBcnJheS5pc0FycmF5KHZhbHVlKSA/IHZhbHVlIDogW3ZhbHVlXTtcbiAgICBjb25zdCBzZWdtZW50cyA9IHZhbHVlcy5yZWR1Y2UoKGFjY3VtLCB2KSA9PiB7XG4gICAgICBhY2N1bS5wdXNoKC4uLnFyY29kZWdlbl9kZWZhdWx0LlFyU2VnbWVudC5tYWtlU2VnbWVudHModikpO1xuICAgICAgcmV0dXJuIGFjY3VtO1xuICAgIH0sIFtdKTtcbiAgICByZXR1cm4gcXJjb2RlZ2VuX2RlZmF1bHQuUXJDb2RlLmVuY29kZVNlZ21lbnRzKFxuICAgICAgc2VnbWVudHMsXG4gICAgICBFUlJPUl9MRVZFTF9NQVBbbGV2ZWxdLFxuICAgICAgbWluVmVyc2lvbixcbiAgICAgIHZvaWQgMCxcbiAgICAgIHZvaWQgMCxcbiAgICAgIGJvb3N0TGV2ZWxcbiAgICApO1xuICB9LCBbdmFsdWUsIGxldmVsLCBtaW5WZXJzaW9uLCBib29zdExldmVsXSk7XG4gIGNvbnN0IHsgY2VsbHMsIG1hcmdpbiwgbnVtQ2VsbHMsIGNhbGN1bGF0ZWRJbWFnZVNldHRpbmdzIH0gPSBSZWFjdC51c2VNZW1vKCgpID0+IHtcbiAgICBsZXQgY2VsbHMyID0gcXJjb2RlLmdldE1vZHVsZXMoKTtcbiAgICBjb25zdCBtYXJnaW4yID0gZ2V0TWFyZ2luU2l6ZShpbmNsdWRlTWFyZ2luLCBtYXJnaW5TaXplKTtcbiAgICBjb25zdCBudW1DZWxsczIgPSBjZWxsczIubGVuZ3RoICsgbWFyZ2luMiAqIDI7XG4gICAgY29uc3QgY2FsY3VsYXRlZEltYWdlU2V0dGluZ3MyID0gZ2V0SW1hZ2VTZXR0aW5ncyhcbiAgICAgIGNlbGxzMixcbiAgICAgIHNpemUsXG4gICAgICBtYXJnaW4yLFxuICAgICAgaW1hZ2VTZXR0aW5nc1xuICAgICk7XG4gICAgcmV0dXJuIHtcbiAgICAgIGNlbGxzOiBjZWxsczIsXG4gICAgICBtYXJnaW46IG1hcmdpbjIsXG4gICAgICBudW1DZWxsczogbnVtQ2VsbHMyLFxuICAgICAgY2FsY3VsYXRlZEltYWdlU2V0dGluZ3M6IGNhbGN1bGF0ZWRJbWFnZVNldHRpbmdzMlxuICAgIH07XG4gIH0sIFtxcmNvZGUsIHNpemUsIGltYWdlU2V0dGluZ3MsIGluY2x1ZGVNYXJnaW4sIG1hcmdpblNpemVdKTtcbiAgcmV0dXJuIHtcbiAgICBxcmNvZGUsXG4gICAgbWFyZ2luLFxuICAgIGNlbGxzLFxuICAgIG51bUNlbGxzLFxuICAgIGNhbGN1bGF0ZWRJbWFnZVNldHRpbmdzXG4gIH07XG59XG52YXIgU1VQUE9SVFNfUEFUSDJEID0gZnVuY3Rpb24oKSB7XG4gIHRyeSB7XG4gICAgbmV3IFBhdGgyRCgpLmFkZFBhdGgobmV3IFBhdGgyRCgpKTtcbiAgfSBjYXRjaCAoZSkge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICByZXR1cm4gdHJ1ZTtcbn0oKTtcbnZhciBRUkNvZGVDYW52YXMgPSBSZWFjdC5mb3J3YXJkUmVmKFxuICBmdW5jdGlvbiBRUkNvZGVDYW52YXMyKHByb3BzLCBmb3J3YXJkZWRSZWYpIHtcbiAgICBjb25zdCBfYSA9IHByb3BzLCB7XG4gICAgICB2YWx1ZSxcbiAgICAgIHNpemUgPSBERUZBVUxUX1NJWkUsXG4gICAgICBsZXZlbCA9IERFRkFVTFRfTEVWRUwsXG4gICAgICBiZ0NvbG9yID0gREVGQVVMVF9CR0NPTE9SLFxuICAgICAgZmdDb2xvciA9IERFRkFVTFRfRkdDT0xPUixcbiAgICAgIGluY2x1ZGVNYXJnaW4gPSBERUZBVUxUX0lOQ0xVREVNQVJHSU4sXG4gICAgICBtaW5WZXJzaW9uID0gREVGQVVMVF9NSU5WRVJTSU9OLFxuICAgICAgYm9vc3RMZXZlbCxcbiAgICAgIG1hcmdpblNpemUsXG4gICAgICBpbWFnZVNldHRpbmdzXG4gICAgfSA9IF9hLCBleHRyYVByb3BzID0gX19vYmpSZXN0KF9hLCBbXG4gICAgICBcInZhbHVlXCIsXG4gICAgICBcInNpemVcIixcbiAgICAgIFwibGV2ZWxcIixcbiAgICAgIFwiYmdDb2xvclwiLFxuICAgICAgXCJmZ0NvbG9yXCIsXG4gICAgICBcImluY2x1ZGVNYXJnaW5cIixcbiAgICAgIFwibWluVmVyc2lvblwiLFxuICAgICAgXCJib29zdExldmVsXCIsXG4gICAgICBcIm1hcmdpblNpemVcIixcbiAgICAgIFwiaW1hZ2VTZXR0aW5nc1wiXG4gICAgXSk7XG4gICAgY29uc3QgX2IgPSBleHRyYVByb3BzLCB7IHN0eWxlIH0gPSBfYiwgb3RoZXJQcm9wcyA9IF9fb2JqUmVzdChfYiwgW1wic3R5bGVcIl0pO1xuICAgIGNvbnN0IGltZ1NyYyA9IGltYWdlU2V0dGluZ3MgPT0gbnVsbCA/IHZvaWQgMCA6IGltYWdlU2V0dGluZ3Muc3JjO1xuICAgIGNvbnN0IF9jYW52YXMgPSBSZWFjdC51c2VSZWYobnVsbCk7XG4gICAgY29uc3QgX2ltYWdlID0gUmVhY3QudXNlUmVmKG51bGwpO1xuICAgIGNvbnN0IHNldENhbnZhc1JlZiA9IFJlYWN0LnVzZUNhbGxiYWNrKFxuICAgICAgKG5vZGUpID0+IHtcbiAgICAgICAgX2NhbnZhcy5jdXJyZW50ID0gbm9kZTtcbiAgICAgICAgaWYgKHR5cGVvZiBmb3J3YXJkZWRSZWYgPT09IFwiZnVuY3Rpb25cIikge1xuICAgICAgICAgIGZvcndhcmRlZFJlZihub2RlKTtcbiAgICAgICAgfSBlbHNlIGlmIChmb3J3YXJkZWRSZWYpIHtcbiAgICAgICAgICBmb3J3YXJkZWRSZWYuY3VycmVudCA9IG5vZGU7XG4gICAgICAgIH1cbiAgICAgIH0sXG4gICAgICBbZm9yd2FyZGVkUmVmXVxuICAgICk7XG4gICAgY29uc3QgW2lzSW1nTG9hZGVkLCBzZXRJc0ltYWdlTG9hZGVkXSA9IFJlYWN0LnVzZVN0YXRlKGZhbHNlKTtcbiAgICBjb25zdCB7IG1hcmdpbiwgY2VsbHMsIG51bUNlbGxzLCBjYWxjdWxhdGVkSW1hZ2VTZXR0aW5ncyB9ID0gdXNlUVJDb2RlKHtcbiAgICAgIHZhbHVlLFxuICAgICAgbGV2ZWwsXG4gICAgICBtaW5WZXJzaW9uLFxuICAgICAgYm9vc3RMZXZlbCxcbiAgICAgIGluY2x1ZGVNYXJnaW4sXG4gICAgICBtYXJnaW5TaXplLFxuICAgICAgaW1hZ2VTZXR0aW5ncyxcbiAgICAgIHNpemVcbiAgICB9KTtcbiAgICBSZWFjdC51c2VFZmZlY3QoKCkgPT4ge1xuICAgICAgaWYgKF9jYW52YXMuY3VycmVudCAhPSBudWxsKSB7XG4gICAgICAgIGNvbnN0IGNhbnZhcyA9IF9jYW52YXMuY3VycmVudDtcbiAgICAgICAgY29uc3QgY3R4ID0gY2FudmFzLmdldENvbnRleHQoXCIyZFwiKTtcbiAgICAgICAgaWYgKCFjdHgpIHtcbiAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgbGV0IGNlbGxzVG9EcmF3ID0gY2VsbHM7XG4gICAgICAgIGNvbnN0IGltYWdlID0gX2ltYWdlLmN1cnJlbnQ7XG4gICAgICAgIGNvbnN0IGhhdmVJbWFnZVRvUmVuZGVyID0gY2FsY3VsYXRlZEltYWdlU2V0dGluZ3MgIT0gbnVsbCAmJiBpbWFnZSAhPT0gbnVsbCAmJiBpbWFnZS5jb21wbGV0ZSAmJiBpbWFnZS5uYXR1cmFsSGVpZ2h0ICE9PSAwICYmIGltYWdlLm5hdHVyYWxXaWR0aCAhPT0gMDtcbiAgICAgICAgaWYgKGhhdmVJbWFnZVRvUmVuZGVyKSB7XG4gICAgICAgICAgaWYgKGNhbGN1bGF0ZWRJbWFnZVNldHRpbmdzLmV4Y2F2YXRpb24gIT0gbnVsbCkge1xuICAgICAgICAgICAgY2VsbHNUb0RyYXcgPSBleGNhdmF0ZU1vZHVsZXMoXG4gICAgICAgICAgICAgIGNlbGxzLFxuICAgICAgICAgICAgICBjYWxjdWxhdGVkSW1hZ2VTZXR0aW5ncy5leGNhdmF0aW9uXG4gICAgICAgICAgICApO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBjb25zdCBwaXhlbFJhdGlvID0gd2luZG93LmRldmljZVBpeGVsUmF0aW8gfHwgMTtcbiAgICAgICAgY2FudmFzLmhlaWdodCA9IGNhbnZhcy53aWR0aCA9IHNpemUgKiBwaXhlbFJhdGlvO1xuICAgICAgICBjb25zdCBzY2FsZSA9IHNpemUgLyBudW1DZWxscyAqIHBpeGVsUmF0aW87XG4gICAgICAgIGN0eC5zY2FsZShzY2FsZSwgc2NhbGUpO1xuICAgICAgICBjdHguZmlsbFN0eWxlID0gYmdDb2xvcjtcbiAgICAgICAgY3R4LmZpbGxSZWN0KDAsIDAsIG51bUNlbGxzLCBudW1DZWxscyk7XG4gICAgICAgIGN0eC5maWxsU3R5bGUgPSBmZ0NvbG9yO1xuICAgICAgICBpZiAoU1VQUE9SVFNfUEFUSDJEKSB7XG4gICAgICAgICAgY3R4LmZpbGwobmV3IFBhdGgyRChnZW5lcmF0ZVBhdGgoY2VsbHNUb0RyYXcsIG1hcmdpbikpKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBjZWxscy5mb3JFYWNoKGZ1bmN0aW9uKHJvdywgcmR4KSB7XG4gICAgICAgICAgICByb3cuZm9yRWFjaChmdW5jdGlvbihjZWxsLCBjZHgpIHtcbiAgICAgICAgICAgICAgaWYgKGNlbGwpIHtcbiAgICAgICAgICAgICAgICBjdHguZmlsbFJlY3QoY2R4ICsgbWFyZ2luLCByZHggKyBtYXJnaW4sIDEsIDEpO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoY2FsY3VsYXRlZEltYWdlU2V0dGluZ3MpIHtcbiAgICAgICAgICBjdHguZ2xvYmFsQWxwaGEgPSBjYWxjdWxhdGVkSW1hZ2VTZXR0aW5ncy5vcGFjaXR5O1xuICAgICAgICB9XG4gICAgICAgIGlmIChoYXZlSW1hZ2VUb1JlbmRlcikge1xuICAgICAgICAgIGN0eC5kcmF3SW1hZ2UoXG4gICAgICAgICAgICBpbWFnZSxcbiAgICAgICAgICAgIGNhbGN1bGF0ZWRJbWFnZVNldHRpbmdzLnggKyBtYXJnaW4sXG4gICAgICAgICAgICBjYWxjdWxhdGVkSW1hZ2VTZXR0aW5ncy55ICsgbWFyZ2luLFxuICAgICAgICAgICAgY2FsY3VsYXRlZEltYWdlU2V0dGluZ3MudyxcbiAgICAgICAgICAgIGNhbGN1bGF0ZWRJbWFnZVNldHRpbmdzLmhcbiAgICAgICAgICApO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfSk7XG4gICAgUmVhY3QudXNlRWZmZWN0KCgpID0+IHtcbiAgICAgIHNldElzSW1hZ2VMb2FkZWQoZmFsc2UpO1xuICAgIH0sIFtpbWdTcmNdKTtcbiAgICBjb25zdCBjYW52YXNTdHlsZSA9IF9fc3ByZWFkVmFsdWVzKHsgaGVpZ2h0OiBzaXplLCB3aWR0aDogc2l6ZSB9LCBzdHlsZSk7XG4gICAgbGV0IGltZyA9IG51bGw7XG4gICAgaWYgKGltZ1NyYyAhPSBudWxsKSB7XG4gICAgICBpbWcgPSAvKiBAX19QVVJFX18gKi8gUmVhY3QuY3JlYXRlRWxlbWVudChcbiAgICAgICAgXCJpbWdcIixcbiAgICAgICAge1xuICAgICAgICAgIHNyYzogaW1nU3JjLFxuICAgICAgICAgIGtleTogaW1nU3JjLFxuICAgICAgICAgIHN0eWxlOiB7IGRpc3BsYXk6IFwibm9uZVwiIH0sXG4gICAgICAgICAgb25Mb2FkOiAoKSA9PiB7XG4gICAgICAgICAgICBzZXRJc0ltYWdlTG9hZGVkKHRydWUpO1xuICAgICAgICAgIH0sXG4gICAgICAgICAgcmVmOiBfaW1hZ2UsXG4gICAgICAgICAgY3Jvc3NPcmlnaW46IGNhbGN1bGF0ZWRJbWFnZVNldHRpbmdzID09IG51bGwgPyB2b2lkIDAgOiBjYWxjdWxhdGVkSW1hZ2VTZXR0aW5ncy5jcm9zc09yaWdpblxuICAgICAgICB9XG4gICAgICApO1xuICAgIH1cbiAgICByZXR1cm4gLyogQF9fUFVSRV9fICovIFJlYWN0LmNyZWF0ZUVsZW1lbnQoUmVhY3QuRnJhZ21lbnQsIG51bGwsIC8qIEBfX1BVUkVfXyAqLyBSZWFjdC5jcmVhdGVFbGVtZW50KFxuICAgICAgXCJjYW52YXNcIixcbiAgICAgIF9fc3ByZWFkVmFsdWVzKHtcbiAgICAgICAgc3R5bGU6IGNhbnZhc1N0eWxlLFxuICAgICAgICBoZWlnaHQ6IHNpemUsXG4gICAgICAgIHdpZHRoOiBzaXplLFxuICAgICAgICByZWY6IHNldENhbnZhc1JlZixcbiAgICAgICAgcm9sZTogXCJpbWdcIlxuICAgICAgfSwgb3RoZXJQcm9wcylcbiAgICApLCBpbWcpO1xuICB9XG4pO1xuUVJDb2RlQ2FudmFzLmRpc3BsYXlOYW1lID0gXCJRUkNvZGVDYW52YXNcIjtcbnZhciBRUkNvZGVTVkcgPSBSZWFjdC5mb3J3YXJkUmVmKFxuICBmdW5jdGlvbiBRUkNvZGVTVkcyKHByb3BzLCBmb3J3YXJkZWRSZWYpIHtcbiAgICBjb25zdCBfYSA9IHByb3BzLCB7XG4gICAgICB2YWx1ZSxcbiAgICAgIHNpemUgPSBERUZBVUxUX1NJWkUsXG4gICAgICBsZXZlbCA9IERFRkFVTFRfTEVWRUwsXG4gICAgICBiZ0NvbG9yID0gREVGQVVMVF9CR0NPTE9SLFxuICAgICAgZmdDb2xvciA9IERFRkFVTFRfRkdDT0xPUixcbiAgICAgIGluY2x1ZGVNYXJnaW4gPSBERUZBVUxUX0lOQ0xVREVNQVJHSU4sXG4gICAgICBtaW5WZXJzaW9uID0gREVGQVVMVF9NSU5WRVJTSU9OLFxuICAgICAgYm9vc3RMZXZlbCxcbiAgICAgIHRpdGxlLFxuICAgICAgbWFyZ2luU2l6ZSxcbiAgICAgIGltYWdlU2V0dGluZ3NcbiAgICB9ID0gX2EsIG90aGVyUHJvcHMgPSBfX29ialJlc3QoX2EsIFtcbiAgICAgIFwidmFsdWVcIixcbiAgICAgIFwic2l6ZVwiLFxuICAgICAgXCJsZXZlbFwiLFxuICAgICAgXCJiZ0NvbG9yXCIsXG4gICAgICBcImZnQ29sb3JcIixcbiAgICAgIFwiaW5jbHVkZU1hcmdpblwiLFxuICAgICAgXCJtaW5WZXJzaW9uXCIsXG4gICAgICBcImJvb3N0TGV2ZWxcIixcbiAgICAgIFwidGl0bGVcIixcbiAgICAgIFwibWFyZ2luU2l6ZVwiLFxuICAgICAgXCJpbWFnZVNldHRpbmdzXCJcbiAgICBdKTtcbiAgICBjb25zdCB7IG1hcmdpbiwgY2VsbHMsIG51bUNlbGxzLCBjYWxjdWxhdGVkSW1hZ2VTZXR0aW5ncyB9ID0gdXNlUVJDb2RlKHtcbiAgICAgIHZhbHVlLFxuICAgICAgbGV2ZWwsXG4gICAgICBtaW5WZXJzaW9uLFxuICAgICAgYm9vc3RMZXZlbCxcbiAgICAgIGluY2x1ZGVNYXJnaW4sXG4gICAgICBtYXJnaW5TaXplLFxuICAgICAgaW1hZ2VTZXR0aW5ncyxcbiAgICAgIHNpemVcbiAgICB9KTtcbiAgICBsZXQgY2VsbHNUb0RyYXcgPSBjZWxscztcbiAgICBsZXQgaW1hZ2UgPSBudWxsO1xuICAgIGlmIChpbWFnZVNldHRpbmdzICE9IG51bGwgJiYgY2FsY3VsYXRlZEltYWdlU2V0dGluZ3MgIT0gbnVsbCkge1xuICAgICAgaWYgKGNhbGN1bGF0ZWRJbWFnZVNldHRpbmdzLmV4Y2F2YXRpb24gIT0gbnVsbCkge1xuICAgICAgICBjZWxsc1RvRHJhdyA9IGV4Y2F2YXRlTW9kdWxlcyhcbiAgICAgICAgICBjZWxscyxcbiAgICAgICAgICBjYWxjdWxhdGVkSW1hZ2VTZXR0aW5ncy5leGNhdmF0aW9uXG4gICAgICAgICk7XG4gICAgICB9XG4gICAgICBpbWFnZSA9IC8qIEBfX1BVUkVfXyAqLyBSZWFjdC5jcmVhdGVFbGVtZW50KFxuICAgICAgICBcImltYWdlXCIsXG4gICAgICAgIHtcbiAgICAgICAgICBocmVmOiBpbWFnZVNldHRpbmdzLnNyYyxcbiAgICAgICAgICBoZWlnaHQ6IGNhbGN1bGF0ZWRJbWFnZVNldHRpbmdzLmgsXG4gICAgICAgICAgd2lkdGg6IGNhbGN1bGF0ZWRJbWFnZVNldHRpbmdzLncsXG4gICAgICAgICAgeDogY2FsY3VsYXRlZEltYWdlU2V0dGluZ3MueCArIG1hcmdpbixcbiAgICAgICAgICB5OiBjYWxjdWxhdGVkSW1hZ2VTZXR0aW5ncy55ICsgbWFyZ2luLFxuICAgICAgICAgIHByZXNlcnZlQXNwZWN0UmF0aW86IFwibm9uZVwiLFxuICAgICAgICAgIG9wYWNpdHk6IGNhbGN1bGF0ZWRJbWFnZVNldHRpbmdzLm9wYWNpdHksXG4gICAgICAgICAgY3Jvc3NPcmlnaW46IGNhbGN1bGF0ZWRJbWFnZVNldHRpbmdzLmNyb3NzT3JpZ2luXG4gICAgICAgIH1cbiAgICAgICk7XG4gICAgfVxuICAgIGNvbnN0IGZnUGF0aCA9IGdlbmVyYXRlUGF0aChjZWxsc1RvRHJhdywgbWFyZ2luKTtcbiAgICByZXR1cm4gLyogQF9fUFVSRV9fICovIFJlYWN0LmNyZWF0ZUVsZW1lbnQoXG4gICAgICBcInN2Z1wiLFxuICAgICAgX19zcHJlYWRWYWx1ZXMoe1xuICAgICAgICBoZWlnaHQ6IHNpemUsXG4gICAgICAgIHdpZHRoOiBzaXplLFxuICAgICAgICB2aWV3Qm94OiBgMCAwICR7bnVtQ2VsbHN9ICR7bnVtQ2VsbHN9YCxcbiAgICAgICAgcmVmOiBmb3J3YXJkZWRSZWYsXG4gICAgICAgIHJvbGU6IFwiaW1nXCJcbiAgICAgIH0sIG90aGVyUHJvcHMpLFxuICAgICAgISF0aXRsZSAmJiAvKiBAX19QVVJFX18gKi8gUmVhY3QuY3JlYXRlRWxlbWVudChcInRpdGxlXCIsIG51bGwsIHRpdGxlKSxcbiAgICAgIC8qIEBfX1BVUkVfXyAqLyBSZWFjdC5jcmVhdGVFbGVtZW50KFxuICAgICAgICBcInBhdGhcIixcbiAgICAgICAge1xuICAgICAgICAgIGZpbGw6IGJnQ29sb3IsXG4gICAgICAgICAgZDogYE0wLDAgaCR7bnVtQ2VsbHN9diR7bnVtQ2VsbHN9SDB6YCxcbiAgICAgICAgICBzaGFwZVJlbmRlcmluZzogXCJjcmlzcEVkZ2VzXCJcbiAgICAgICAgfVxuICAgICAgKSxcbiAgICAgIC8qIEBfX1BVUkVfXyAqLyBSZWFjdC5jcmVhdGVFbGVtZW50KFwicGF0aFwiLCB7IGZpbGw6IGZnQ29sb3IsIGQ6IGZnUGF0aCwgc2hhcGVSZW5kZXJpbmc6IFwiY3Jpc3BFZGdlc1wiIH0pLFxuICAgICAgaW1hZ2VcbiAgICApO1xuICB9XG4pO1xuUVJDb2RlU1ZHLmRpc3BsYXlOYW1lID0gXCJRUkNvZGVTVkdcIjtcbmV4cG9ydCB7XG4gIFFSQ29kZUNhbnZhcyxcbiAgUVJDb2RlU1ZHXG59O1xuIl0sIm1hcHBpbmdzIjoiOzs7O0FBQUEsSUFBSSxZQUFZLE9BQU87QUFDdkIsSUFBSSxzQkFBc0IsT0FBTztBQUNqQyxJQUFJLGVBQWUsT0FBTyxVQUFVO0FBQ3BDLElBQUksZUFBZSxPQUFPLFVBQVU7QUFDcEMsSUFBSSxtQkFBbUIsS0FBSyxLQUFLLFVBQVUsT0FBTyxNQUFNLFVBQVUsS0FBSyxLQUFLO0NBQUUsWUFBWTtDQUFNLGNBQWM7Q0FBTSxVQUFVO0NBQU07QUFBTSxDQUFDLElBQUksSUFBSSxPQUFPO0FBQzFKLElBQUksa0JBQWtCLEdBQUcsTUFBTTtDQUM3QixLQUFLLElBQUksUUFBUSxNQUFNLElBQUksQ0FBQyxJQUMxQixJQUFJLGFBQWEsS0FBSyxHQUFHLElBQUksR0FDM0IsZ0JBQWdCLEdBQUcsTUFBTSxFQUFFLEtBQUs7Q0FDcEMsSUFBSSxxQkFDRztPQUFBLElBQUksUUFBUSxvQkFBb0IsQ0FBQyxHQUNwQyxJQUFJLGFBQWEsS0FBSyxHQUFHLElBQUksR0FDM0IsZ0JBQWdCLEdBQUcsTUFBTSxFQUFFLEtBQUs7Q0FBQTtDQUV0QyxPQUFPO0FBQ1Q7QUFDQSxJQUFJLGFBQWEsUUFBUSxZQUFZO0NBQ25DLElBQUksU0FBUyxDQUFDO0NBQ2QsS0FBSyxJQUFJLFFBQVEsUUFDZixJQUFJLGFBQWEsS0FBSyxRQUFRLElBQUksS0FBSyxRQUFRLFFBQVEsSUFBSSxJQUFJLEdBQzdELE9BQU8sUUFBUSxPQUFPO0NBQzFCLElBQUksVUFBVSxRQUFRLHFCQUNmO09BQUEsSUFBSSxRQUFRLG9CQUFvQixNQUFNLEdBQ3pDLElBQUksUUFBUSxRQUFRLElBQUksSUFBSSxLQUFLLGFBQWEsS0FBSyxRQUFRLElBQUksR0FDN0QsT0FBTyxRQUFRLE9BQU87Q0FBQTtDQUU1QixPQUFPO0FBQ1Q7Ozs7OztBQVdBLElBQUk7RUFDRixlQUFlO0NBQ2YsTUFBTSxVQUFVLE1BQU0sUUFBUTtFQU01QixZQUFZLFNBQVMsc0JBQXNCLGVBQWUsS0FBSztHQUM3RCxLQUFLLFVBQVU7R0FDZixLQUFLLHVCQUF1QjtHQUc1QixLQUFLLFVBQVUsQ0FBQztHQUVoQixLQUFLLGFBQWEsQ0FBQztHQUNuQixJQUFJLFVBQVUsUUFBUSxlQUFlLFVBQVUsUUFBUSxhQUNyRCxNQUFNLElBQUksV0FBVyw0QkFBNEI7R0FDbkQsSUFBSSxNQUFNLE1BQU0sTUFBTSxHQUNwQixNQUFNLElBQUksV0FBVyx5QkFBeUI7R0FDaEQsS0FBSyxPQUFPLFVBQVUsSUFBSTtHQUMxQixJQUFJLE1BQU0sQ0FBQztHQUNYLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxLQUFLLE1BQU0sS0FDN0IsSUFBSSxLQUFLLEtBQUs7R0FDaEIsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEtBQUssTUFBTSxLQUFLO0lBQ2xDLEtBQUssUUFBUSxLQUFLLElBQUksTUFBTSxDQUFDO0lBQzdCLEtBQUssV0FBVyxLQUFLLElBQUksTUFBTSxDQUFDO0dBQ2xDO0dBQ0EsS0FBSyxxQkFBcUI7R0FDMUIsTUFBTSxlQUFlLEtBQUssb0JBQW9CLGFBQWE7R0FDM0QsS0FBSyxjQUFjLFlBQVk7R0FDL0IsSUFBSSxPQUFPLElBQUk7SUFDYixJQUFJLGFBQWE7SUFDakIsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEdBQUcsS0FBSztLQUMxQixLQUFLLFVBQVUsQ0FBQztLQUNoQixLQUFLLGVBQWUsQ0FBQztLQUNyQixNQUFNLFVBQVUsS0FBSyxnQkFBZ0I7S0FDckMsSUFBSSxVQUFVLFlBQVk7TUFDeEIsTUFBTTtNQUNOLGFBQWE7S0FDZjtLQUNBLEtBQUssVUFBVSxDQUFDO0lBQ2xCO0dBQ0Y7R0FDQSxPQUFPLEtBQUssT0FBTyxPQUFPLENBQUM7R0FDM0IsS0FBSyxPQUFPO0dBQ1osS0FBSyxVQUFVLEdBQUc7R0FDbEIsS0FBSyxlQUFlLEdBQUc7R0FDdkIsS0FBSyxhQUFhLENBQUM7RUFDckI7RUFPQSxPQUFPLFdBQVcsTUFBTSxLQUFLO0dBQzNCLE1BQU0sT0FBTyxXQUFXLFVBQVUsYUFBYSxJQUFJO0dBQ25ELE9BQU8sUUFBUSxlQUFlLE1BQU0sR0FBRztFQUN6QztFQUtBLE9BQU8sYUFBYSxNQUFNLEtBQUs7R0FDN0IsTUFBTSxNQUFNLFdBQVcsVUFBVSxVQUFVLElBQUk7R0FDL0MsT0FBTyxRQUFRLGVBQWUsQ0FBQyxHQUFHLEdBQUcsR0FBRztFQUMxQztFQVdBLE9BQU8sZUFBZSxNQUFNLEtBQUssYUFBYSxHQUFHLGFBQWEsSUFBSSxPQUFPLElBQUksV0FBVyxNQUFNO0dBQzVGLElBQUksRUFBRSxRQUFRLGVBQWUsY0FBYyxjQUFjLGNBQWMsY0FBYyxRQUFRLGdCQUFnQixPQUFPLE1BQU0sT0FBTyxHQUMvSCxNQUFNLElBQUksV0FBVyxlQUFlO0dBQ3RDLElBQUk7R0FDSixJQUFJO0dBQ0osS0FBSyxVQUFVLGFBQWMsV0FBVztJQUN0QyxNQUFNLG9CQUFvQixRQUFRLG9CQUFvQixTQUFTLEdBQUcsSUFBSTtJQUN0RSxNQUFNLFdBQVcsVUFBVSxhQUFhLE1BQU0sT0FBTztJQUNyRCxJQUFJLFlBQVksbUJBQW1CO0tBQ2pDLGVBQWU7S0FDZjtJQUNGO0lBQ0EsSUFBSSxXQUFXLFlBQ2IsTUFBTSxJQUFJLFdBQVcsZUFBZTtHQUN4QztHQUNBLEtBQUssTUFBTSxVQUFVO0lBQUMsUUFBUSxJQUFJO0lBQVEsUUFBUSxJQUFJO0lBQVUsUUFBUSxJQUFJO0dBQUksR0FDOUUsSUFBSSxZQUFZLGdCQUFnQixRQUFRLG9CQUFvQixTQUFTLE1BQU0sSUFBSSxHQUM3RSxNQUFNO0dBRVYsSUFBSSxLQUFLLENBQUM7R0FDVixLQUFLLE1BQU0sT0FBTyxNQUFNO0lBQ3RCLFdBQVcsSUFBSSxLQUFLLFVBQVUsR0FBRyxFQUFFO0lBQ25DLFdBQVcsSUFBSSxVQUFVLElBQUksS0FBSyxpQkFBaUIsT0FBTyxHQUFHLEVBQUU7SUFDL0QsS0FBSyxNQUFNLEtBQUssSUFBSSxRQUFRLEdBQzFCLEdBQUcsS0FBSyxDQUFDO0dBQ2I7R0FDQSxPQUFPLEdBQUcsVUFBVSxZQUFZO0dBQ2hDLE1BQU0sbUJBQW1CLFFBQVEsb0JBQW9CLFNBQVMsR0FBRyxJQUFJO0dBQ3JFLE9BQU8sR0FBRyxVQUFVLGdCQUFnQjtHQUNwQyxXQUFXLEdBQUcsS0FBSyxJQUFJLEdBQUcsbUJBQW1CLEdBQUcsTUFBTSxHQUFHLEVBQUU7R0FDM0QsV0FBVyxJQUFJLElBQUksR0FBRyxTQUFTLEtBQUssR0FBRyxFQUFFO0dBQ3pDLE9BQU8sR0FBRyxTQUFTLEtBQUssQ0FBQztHQUN6QixLQUFLLElBQUksVUFBVSxLQUFLLEdBQUcsU0FBUyxrQkFBa0IsV0FBVyxLQUMvRCxXQUFXLFNBQVMsR0FBRyxFQUFFO0dBQzNCLElBQUksZ0JBQWdCLENBQUM7R0FDckIsT0FBTyxjQUFjLFNBQVMsSUFBSSxHQUFHLFFBQ25DLGNBQWMsS0FBSyxDQUFDO0dBQ3RCLEdBQUcsU0FBUyxHQUFHLE1BQU0sY0FBYyxNQUFNLE1BQU0sS0FBSyxLQUFLLElBQUksRUFBRTtHQUMvRCxPQUFPLElBQUksUUFBUSxTQUFTLEtBQUssZUFBZSxJQUFJO0VBQ3REO0VBS0EsVUFBVSxHQUFHLEdBQUc7R0FDZCxPQUFPLEtBQUssS0FBSyxJQUFJLEtBQUssUUFBUSxLQUFLLEtBQUssSUFBSSxLQUFLLFFBQVEsS0FBSyxRQUFRLEVBQUUsQ0FBQztFQUMvRTtFQUVBLGFBQWE7R0FDWCxPQUFPLEtBQUs7RUFDZDtFQUdBLHVCQUF1QjtHQUNyQixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksS0FBSyxNQUFNLEtBQUs7SUFDbEMsS0FBSyxrQkFBa0IsR0FBRyxHQUFHLElBQUksS0FBSyxDQUFDO0lBQ3ZDLEtBQUssa0JBQWtCLEdBQUcsR0FBRyxJQUFJLEtBQUssQ0FBQztHQUN6QztHQUNBLEtBQUssa0JBQWtCLEdBQUcsQ0FBQztHQUMzQixLQUFLLGtCQUFrQixLQUFLLE9BQU8sR0FBRyxDQUFDO0dBQ3ZDLEtBQUssa0JBQWtCLEdBQUcsS0FBSyxPQUFPLENBQUM7R0FDdkMsTUFBTSxjQUFjLEtBQUssNkJBQTZCO0dBQ3RELE1BQU0sV0FBVyxZQUFZO0dBQzdCLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxVQUFVLEtBQzVCLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxVQUFVLEtBQzVCLElBQUksRUFBRSxLQUFLLEtBQUssS0FBSyxLQUFLLEtBQUssS0FBSyxLQUFLLFdBQVcsS0FBSyxLQUFLLFdBQVcsS0FBSyxLQUFLLElBQ2pGLEtBQUsscUJBQXFCLFlBQVksSUFBSSxZQUFZLEVBQUU7R0FHOUQsS0FBSyxlQUFlLENBQUM7R0FDckIsS0FBSyxZQUFZO0VBQ25CO0VBR0EsZUFBZSxNQUFNO0dBQ25CLE1BQU0sT0FBTyxLQUFLLHFCQUFxQixjQUFjLElBQUk7R0FDekQsSUFBSSxNQUFNO0dBQ1YsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLElBQUksS0FDdEIsTUFBTSxPQUFPLEtBQUssUUFBUSxLQUFLO0dBQ2pDLE1BQU0sUUFBUSxRQUFRLEtBQUssT0FBTztHQUNsQyxPQUFPLFNBQVMsTUFBTSxDQUFDO0dBQ3ZCLEtBQUssSUFBSSxJQUFJLEdBQUcsS0FBSyxHQUFHLEtBQ3RCLEtBQUssa0JBQWtCLEdBQUcsR0FBRyxPQUFPLE1BQU0sQ0FBQyxDQUFDO0dBQzlDLEtBQUssa0JBQWtCLEdBQUcsR0FBRyxPQUFPLE1BQU0sQ0FBQyxDQUFDO0dBQzVDLEtBQUssa0JBQWtCLEdBQUcsR0FBRyxPQUFPLE1BQU0sQ0FBQyxDQUFDO0dBQzVDLEtBQUssa0JBQWtCLEdBQUcsR0FBRyxPQUFPLE1BQU0sQ0FBQyxDQUFDO0dBQzVDLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxJQUFJLEtBQ3RCLEtBQUssa0JBQWtCLEtBQUssR0FBRyxHQUFHLE9BQU8sTUFBTSxDQUFDLENBQUM7R0FDbkQsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEdBQUcsS0FDckIsS0FBSyxrQkFBa0IsS0FBSyxPQUFPLElBQUksR0FBRyxHQUFHLE9BQU8sTUFBTSxDQUFDLENBQUM7R0FDOUQsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLElBQUksS0FDdEIsS0FBSyxrQkFBa0IsR0FBRyxLQUFLLE9BQU8sS0FBSyxHQUFHLE9BQU8sTUFBTSxDQUFDLENBQUM7R0FDL0QsS0FBSyxrQkFBa0IsR0FBRyxLQUFLLE9BQU8sR0FBRyxJQUFJO0VBQy9DO0VBR0EsY0FBYztHQUNaLElBQUksS0FBSyxVQUFVLEdBQ2pCO0dBQ0YsSUFBSSxNQUFNLEtBQUs7R0FDZixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksSUFBSSxLQUN0QixNQUFNLE9BQU8sS0FBSyxRQUFRLE1BQU07R0FDbEMsTUFBTSxPQUFPLEtBQUssV0FBVyxLQUFLO0dBQ2xDLE9BQU8sU0FBUyxNQUFNLENBQUM7R0FDdkIsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLElBQUksS0FBSztJQUMzQixNQUFNLFFBQVEsT0FBTyxNQUFNLENBQUM7SUFDNUIsTUFBTSxJQUFJLEtBQUssT0FBTyxLQUFLLElBQUk7SUFDL0IsTUFBTSxJQUFJLEtBQUssTUFBTSxJQUFJLENBQUM7SUFDMUIsS0FBSyxrQkFBa0IsR0FBRyxHQUFHLEtBQUs7SUFDbEMsS0FBSyxrQkFBa0IsR0FBRyxHQUFHLEtBQUs7R0FDcEM7RUFDRjtFQUdBLGtCQUFrQixHQUFHLEdBQUc7R0FDdEIsS0FBSyxJQUFJLEtBQUssSUFBSSxNQUFNLEdBQUcsTUFDekIsS0FBSyxJQUFJLEtBQUssSUFBSSxNQUFNLEdBQUcsTUFBTTtJQUMvQixNQUFNLE9BQU8sS0FBSyxJQUFJLEtBQUssSUFBSSxFQUFFLEdBQUcsS0FBSyxJQUFJLEVBQUUsQ0FBQztJQUNoRCxNQUFNLEtBQUssSUFBSTtJQUNmLE1BQU0sS0FBSyxJQUFJO0lBQ2YsSUFBSSxLQUFLLE1BQU0sS0FBSyxLQUFLLFFBQVEsS0FBSyxNQUFNLEtBQUssS0FBSyxNQUNwRCxLQUFLLGtCQUFrQixJQUFJLElBQUksUUFBUSxLQUFLLFFBQVEsQ0FBQztHQUN6RDtFQUVKO0VBR0EscUJBQXFCLEdBQUcsR0FBRztHQUN6QixLQUFLLElBQUksS0FBSyxJQUFJLE1BQU0sR0FBRyxNQUN6QixLQUFLLElBQUksS0FBSyxJQUFJLE1BQU0sR0FBRyxNQUN6QixLQUFLLGtCQUFrQixJQUFJLElBQUksSUFBSSxJQUFJLEtBQUssSUFBSSxLQUFLLElBQUksRUFBRSxHQUFHLEtBQUssSUFBSSxFQUFFLENBQUMsS0FBSyxDQUFDO0VBRXRGO0VBR0Esa0JBQWtCLEdBQUcsR0FBRyxRQUFRO0dBQzlCLEtBQUssUUFBUSxFQUFFLENBQUMsS0FBSztHQUNyQixLQUFLLFdBQVcsRUFBRSxDQUFDLEtBQUs7RUFDMUI7RUFJQSxvQkFBb0IsTUFBTTtHQUN4QixNQUFNLE1BQU0sS0FBSztHQUNqQixNQUFNLE1BQU0sS0FBSztHQUNqQixJQUFJLEtBQUssVUFBVSxRQUFRLG9CQUFvQixLQUFLLEdBQUcsR0FDckQsTUFBTSxJQUFJLFdBQVcsa0JBQWtCO0dBQ3pDLE1BQU0sWUFBWSxRQUFRLDRCQUE0QixJQUFJLFFBQVEsQ0FBQztHQUNuRSxNQUFNLGNBQWMsUUFBUSx3QkFBd0IsSUFBSSxRQUFRLENBQUM7R0FDakUsTUFBTSxlQUFlLEtBQUssTUFBTSxRQUFRLHFCQUFxQixHQUFHLElBQUksQ0FBQztHQUNyRSxNQUFNLGlCQUFpQixZQUFZLGVBQWU7R0FDbEQsTUFBTSxnQkFBZ0IsS0FBSyxNQUFNLGVBQWUsU0FBUztHQUN6RCxJQUFJLFNBQVMsQ0FBQztHQUNkLE1BQU0sUUFBUSxRQUFRLDBCQUEwQixXQUFXO0dBQzNELEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxHQUFHLElBQUksV0FBVyxLQUFLO0lBQ3pDLElBQUksTUFBTSxLQUFLLE1BQU0sR0FBRyxJQUFJLGdCQUFnQixlQUFlLElBQUksaUJBQWlCLElBQUksRUFBRTtJQUN0RixLQUFLLElBQUk7SUFDVCxNQUFNLE1BQU0sUUFBUSw0QkFBNEIsS0FBSyxLQUFLO0lBQzFELElBQUksSUFBSSxnQkFDTixJQUFJLEtBQUssQ0FBQztJQUNaLE9BQU8sS0FBSyxJQUFJLE9BQU8sR0FBRyxDQUFDO0dBQzdCO0dBQ0EsSUFBSSxTQUFTLENBQUM7R0FDZCxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksT0FBTyxFQUFFLENBQUMsUUFBUSxLQUNwQyxPQUFPLFNBQVMsT0FBTyxNQUFNO0lBQzNCLElBQUksS0FBSyxnQkFBZ0IsZUFBZSxLQUFLLGdCQUMzQyxPQUFPLEtBQUssTUFBTSxFQUFFO0dBQ3hCLENBQUM7R0FFSCxPQUFPLE9BQU8sVUFBVSxZQUFZO0dBQ3BDLE9BQU87RUFDVDtFQUdBLGNBQWMsTUFBTTtHQUNsQixJQUFJLEtBQUssVUFBVSxLQUFLLE1BQU0sUUFBUSxxQkFBcUIsS0FBSyxPQUFPLElBQUksQ0FBQyxHQUMxRSxNQUFNLElBQUksV0FBVyxrQkFBa0I7R0FDekMsSUFBSSxJQUFJO0dBQ1IsS0FBSyxJQUFJLFFBQVEsS0FBSyxPQUFPLEdBQUcsU0FBUyxHQUFHLFNBQVMsR0FBRztJQUN0RCxJQUFJLFNBQVMsR0FDWCxRQUFRO0lBQ1YsS0FBSyxJQUFJLE9BQU8sR0FBRyxPQUFPLEtBQUssTUFBTSxRQUNuQyxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksR0FBRyxLQUFLO0tBQzFCLE1BQU0sSUFBSSxRQUFRO0tBRWxCLE1BQU0sS0FEVSxRQUFRLElBQUksTUFBTSxJQUNmLEtBQUssT0FBTyxJQUFJLE9BQU87S0FDMUMsSUFBSSxDQUFDLEtBQUssV0FBVyxFQUFFLENBQUMsTUFBTSxJQUFJLEtBQUssU0FBUyxHQUFHO01BQ2pELEtBQUssUUFBUSxFQUFFLENBQUMsS0FBSyxPQUFPLEtBQUssTUFBTSxJQUFJLEtBQUssSUFBSSxFQUFFO01BQ3REO0tBQ0Y7SUFDRjtHQUVKO0dBQ0EsT0FBTyxLQUFLLEtBQUssU0FBUyxDQUFDO0VBQzdCO0VBTUEsVUFBVSxNQUFNO0dBQ2QsSUFBSSxPQUFPLEtBQUssT0FBTyxHQUNyQixNQUFNLElBQUksV0FBVyx5QkFBeUI7R0FDaEQsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEtBQUssTUFBTSxLQUM3QixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksS0FBSyxNQUFNLEtBQUs7SUFDbEMsSUFBSTtJQUNKLFFBQVEsTUFBUjtLQUNFLEtBQUs7TUFDSCxVQUFVLElBQUksS0FBSyxLQUFLO01BQ3hCO0tBQ0YsS0FBSztNQUNILFNBQVMsSUFBSSxLQUFLO01BQ2xCO0tBQ0YsS0FBSztNQUNILFNBQVMsSUFBSSxLQUFLO01BQ2xCO0tBQ0YsS0FBSztNQUNILFVBQVUsSUFBSSxLQUFLLEtBQUs7TUFDeEI7S0FDRixLQUFLO01BQ0gsVUFBVSxLQUFLLE1BQU0sSUFBSSxDQUFDLElBQUksS0FBSyxNQUFNLElBQUksQ0FBQyxLQUFLLEtBQUs7TUFDeEQ7S0FDRixLQUFLO01BQ0gsU0FBUyxJQUFJLElBQUksSUFBSSxJQUFJLElBQUksS0FBSztNQUNsQztLQUNGLEtBQUs7TUFDSCxVQUFVLElBQUksSUFBSSxJQUFJLElBQUksSUFBSSxLQUFLLEtBQUs7TUFDeEM7S0FDRixLQUFLO01BQ0gsV0FBVyxJQUFJLEtBQUssSUFBSSxJQUFJLElBQUksS0FBSyxLQUFLO01BQzFDO0tBQ0YsU0FDRSxNQUFNLElBQUksTUFBTSxhQUFhO0lBQ2pDO0lBQ0EsSUFBSSxDQUFDLEtBQUssV0FBVyxFQUFFLENBQUMsTUFBTSxRQUM1QixLQUFLLFFBQVEsRUFBRSxDQUFDLEtBQUssQ0FBQyxLQUFLLFFBQVEsRUFBRSxDQUFDO0dBQzFDO0VBRUo7RUFHQSxrQkFBa0I7R0FDaEIsSUFBSSxTQUFTO0dBQ2IsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEtBQUssTUFBTSxLQUFLO0lBQ2xDLElBQUksV0FBVztJQUNmLElBQUksT0FBTztJQUNYLElBQUksYUFBYTtLQUFDO0tBQUc7S0FBRztLQUFHO0tBQUc7S0FBRztLQUFHO0lBQUM7SUFDckMsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEtBQUssTUFBTSxLQUM3QixJQUFJLEtBQUssUUFBUSxFQUFFLENBQUMsTUFBTSxVQUFVO0tBQ2xDO0tBQ0EsSUFBSSxRQUFRLEdBQ1YsVUFBVSxRQUFRO1VBQ2YsSUFBSSxPQUFPLEdBQ2Q7SUFDSixPQUFPO0tBQ0wsS0FBSyx3QkFBd0IsTUFBTSxVQUFVO0tBQzdDLElBQUksQ0FBQyxVQUNILFVBQVUsS0FBSywyQkFBMkIsVUFBVSxJQUFJLFFBQVE7S0FDbEUsV0FBVyxLQUFLLFFBQVEsRUFBRSxDQUFDO0tBQzNCLE9BQU87SUFDVDtJQUVGLFVBQVUsS0FBSywrQkFBK0IsVUFBVSxNQUFNLFVBQVUsSUFBSSxRQUFRO0dBQ3RGO0dBQ0EsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEtBQUssTUFBTSxLQUFLO0lBQ2xDLElBQUksV0FBVztJQUNmLElBQUksT0FBTztJQUNYLElBQUksYUFBYTtLQUFDO0tBQUc7S0FBRztLQUFHO0tBQUc7S0FBRztLQUFHO0lBQUM7SUFDckMsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEtBQUssTUFBTSxLQUM3QixJQUFJLEtBQUssUUFBUSxFQUFFLENBQUMsTUFBTSxVQUFVO0tBQ2xDO0tBQ0EsSUFBSSxRQUFRLEdBQ1YsVUFBVSxRQUFRO1VBQ2YsSUFBSSxPQUFPLEdBQ2Q7SUFDSixPQUFPO0tBQ0wsS0FBSyx3QkFBd0IsTUFBTSxVQUFVO0tBQzdDLElBQUksQ0FBQyxVQUNILFVBQVUsS0FBSywyQkFBMkIsVUFBVSxJQUFJLFFBQVE7S0FDbEUsV0FBVyxLQUFLLFFBQVEsRUFBRSxDQUFDO0tBQzNCLE9BQU87SUFDVDtJQUVGLFVBQVUsS0FBSywrQkFBK0IsVUFBVSxNQUFNLFVBQVUsSUFBSSxRQUFRO0dBQ3RGO0dBQ0EsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEtBQUssT0FBTyxHQUFHLEtBQ2pDLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxLQUFLLE9BQU8sR0FBRyxLQUFLO0lBQ3RDLE1BQU0sUUFBUSxLQUFLLFFBQVEsRUFBRSxDQUFDO0lBQzlCLElBQUksU0FBUyxLQUFLLFFBQVEsRUFBRSxDQUFDLElBQUksTUFBTSxTQUFTLEtBQUssUUFBUSxJQUFJLEVBQUUsQ0FBQyxNQUFNLFNBQVMsS0FBSyxRQUFRLElBQUksRUFBRSxDQUFDLElBQUksSUFDekcsVUFBVSxRQUFRO0dBQ3RCO0dBRUYsSUFBSSxPQUFPO0dBQ1gsS0FBSyxNQUFNLE9BQU8sS0FBSyxTQUNyQixPQUFPLElBQUksUUFBUSxLQUFLLFVBQVUsT0FBTyxRQUFRLElBQUksSUFBSSxJQUFJO0dBQy9ELE1BQU0sUUFBUSxLQUFLLE9BQU8sS0FBSztHQUMvQixNQUFNLElBQUksS0FBSyxLQUFLLEtBQUssSUFBSSxPQUFPLEtBQUssUUFBUSxFQUFFLElBQUksS0FBSyxJQUFJO0dBQ2hFLE9BQU8sS0FBSyxLQUFLLEtBQUssQ0FBQztHQUN2QixVQUFVLElBQUksUUFBUTtHQUN0QixPQUFPLEtBQUssVUFBVSxVQUFVLE9BQU87R0FDdkMsT0FBTztFQUNUO0VBS0EsK0JBQStCO0dBQzdCLElBQUksS0FBSyxXQUFXLEdBQ2xCLE9BQU8sQ0FBQztRQUNMO0lBQ0gsTUFBTSxXQUFXLEtBQUssTUFBTSxLQUFLLFVBQVUsQ0FBQyxJQUFJO0lBQ2hELE1BQU0sT0FBTyxLQUFLLFdBQVcsS0FBSyxLQUFLLEtBQUssTUFBTSxLQUFLLFVBQVUsSUFBSSxNQUFNLFdBQVcsSUFBSSxFQUFFLElBQUk7SUFDaEcsSUFBSSxTQUFTLENBQUMsQ0FBQztJQUNmLEtBQUssSUFBSSxNQUFNLEtBQUssT0FBTyxHQUFHLE9BQU8sU0FBUyxVQUFVLE9BQU8sTUFDN0QsT0FBTyxPQUFPLEdBQUcsR0FBRyxHQUFHO0lBQ3pCLE9BQU87R0FDVDtFQUNGO0VBSUEsT0FBTyxxQkFBcUIsS0FBSztHQUMvQixJQUFJLE1BQU0sUUFBUSxlQUFlLE1BQU0sUUFBUSxhQUM3QyxNQUFNLElBQUksV0FBVyw2QkFBNkI7R0FDcEQsSUFBSSxVQUFVLEtBQUssTUFBTSxPQUFPLE1BQU07R0FDdEMsSUFBSSxPQUFPLEdBQUc7SUFDWixNQUFNLFdBQVcsS0FBSyxNQUFNLE1BQU0sQ0FBQyxJQUFJO0lBQ3ZDLFdBQVcsS0FBSyxXQUFXLE1BQU0sV0FBVztJQUM1QyxJQUFJLE9BQU8sR0FDVCxVQUFVO0dBQ2Q7R0FDQSxPQUFPLE9BQU8sVUFBVSxVQUFVLEtBQUs7R0FDdkMsT0FBTztFQUNUO0VBSUEsT0FBTyxvQkFBb0IsS0FBSyxLQUFLO0dBQ25DLE9BQU8sS0FBSyxNQUFNLFFBQVEscUJBQXFCLEdBQUcsSUFBSSxDQUFDLElBQUksUUFBUSx3QkFBd0IsSUFBSSxRQUFRLENBQUMsT0FBTyxRQUFRLDRCQUE0QixJQUFJLFFBQVEsQ0FBQztFQUNsSztFQUdBLE9BQU8sMEJBQTBCLFFBQVE7R0FDdkMsSUFBSSxTQUFTLEtBQUssU0FBUyxLQUN6QixNQUFNLElBQUksV0FBVyxxQkFBcUI7R0FDNUMsSUFBSSxTQUFTLENBQUM7R0FDZCxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksU0FBUyxHQUFHLEtBQzlCLE9BQU8sS0FBSyxDQUFDO0dBQ2YsT0FBTyxLQUFLLENBQUM7R0FDYixJQUFJLE9BQU87R0FDWCxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksUUFBUSxLQUFLO0lBQy9CLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxPQUFPLFFBQVEsS0FBSztLQUN0QyxPQUFPLEtBQUssUUFBUSxvQkFBb0IsT0FBTyxJQUFJLElBQUk7S0FDdkQsSUFBSSxJQUFJLElBQUksT0FBTyxRQUNqQixPQUFPLE1BQU0sT0FBTyxJQUFJO0lBQzVCO0lBQ0EsT0FBTyxRQUFRLG9CQUFvQixNQUFNLENBQUM7R0FDNUM7R0FDQSxPQUFPO0VBQ1Q7RUFFQSxPQUFPLDRCQUE0QixNQUFNLFNBQVM7R0FDaEQsSUFBSSxTQUFTLFFBQVEsS0FBSyxNQUFNLENBQUM7R0FDakMsS0FBSyxNQUFNLEtBQUssTUFBTTtJQUNwQixNQUFNLFNBQVMsSUFBSSxPQUFPLE1BQU07SUFDaEMsT0FBTyxLQUFLLENBQUM7SUFDYixRQUFRLFNBQVMsTUFBTSxNQUFNLE9BQU8sTUFBTSxRQUFRLG9CQUFvQixNQUFNLE1BQU0sQ0FBQztHQUNyRjtHQUNBLE9BQU87RUFDVDtFQUdBLE9BQU8sb0JBQW9CLEdBQUcsR0FBRztHQUMvQixJQUFJLE1BQU0sS0FBSyxLQUFLLE1BQU0sS0FBSyxHQUM3QixNQUFNLElBQUksV0FBVyxtQkFBbUI7R0FDMUMsSUFBSSxJQUFJO0dBQ1IsS0FBSyxJQUFJLElBQUksR0FBRyxLQUFLLEdBQUcsS0FBSztJQUMzQixJQUFJLEtBQUssS0FBSyxNQUFNLEtBQUs7SUFDekIsTUFBTSxNQUFNLElBQUksS0FBSztHQUN2QjtHQUNBLE9BQU8sTUFBTSxLQUFLLENBQUM7R0FDbkIsT0FBTztFQUNUO0VBR0EsMkJBQTJCLFlBQVk7R0FDckMsTUFBTSxJQUFJLFdBQVc7R0FDckIsT0FBTyxLQUFLLEtBQUssT0FBTyxDQUFDO0dBQ3pCLE1BQU0sT0FBTyxJQUFJLEtBQUssV0FBVyxNQUFNLEtBQUssV0FBVyxNQUFNLElBQUksS0FBSyxXQUFXLE1BQU0sS0FBSyxXQUFXLE1BQU07R0FDN0csUUFBUSxRQUFRLFdBQVcsTUFBTSxJQUFJLEtBQUssV0FBVyxNQUFNLElBQUksSUFBSSxNQUFNLFFBQVEsV0FBVyxNQUFNLElBQUksS0FBSyxXQUFXLE1BQU0sSUFBSSxJQUFJO0VBQ3RJO0VBRUEsK0JBQStCLGlCQUFpQixrQkFBa0IsWUFBWTtHQUM1RSxJQUFJLGlCQUFpQjtJQUNuQixLQUFLLHdCQUF3QixrQkFBa0IsVUFBVTtJQUN6RCxtQkFBbUI7R0FDckI7R0FDQSxvQkFBb0IsS0FBSztHQUN6QixLQUFLLHdCQUF3QixrQkFBa0IsVUFBVTtHQUN6RCxPQUFPLEtBQUssMkJBQTJCLFVBQVU7RUFDbkQ7RUFFQSx3QkFBd0Isa0JBQWtCLFlBQVk7R0FDcEQsSUFBSSxXQUFXLE1BQU0sR0FDbkIsb0JBQW9CLEtBQUs7R0FDM0IsV0FBVyxJQUFJO0dBQ2YsV0FBVyxRQUFRLGdCQUFnQjtFQUNyQztDQUNGO0NBR0EsUUFBUSxjQUFjO0NBRXRCLFFBQVEsY0FBYztDQUV0QixRQUFRLGFBQWE7Q0FDckIsUUFBUSxhQUFhO0NBQ3JCLFFBQVEsYUFBYTtDQUNyQixRQUFRLGFBQWE7Q0FDckIsUUFBUSwwQkFBMEI7RUFHaEM7R0FBQztHQUFJO0dBQUc7R0FBSTtHQUFJO0dBQUk7R0FBSTtHQUFJO0dBQUk7R0FBSTtHQUFJO0dBQUk7R0FBSTtHQUFJO0dBQUk7R0FBSTtHQUFJO0dBQUk7R0FBSTtHQUFJO0dBQUk7R0FBSTtHQUFJO0dBQUk7R0FBSTtHQUFJO0dBQUk7R0FBSTtHQUFJO0dBQUk7R0FBSTtHQUFJO0dBQUk7R0FBSTtHQUFJO0dBQUk7R0FBSTtHQUFJO0dBQUk7R0FBSTtHQUFJO0VBQUU7RUFFbEs7R0FBQztHQUFJO0dBQUk7R0FBSTtHQUFJO0dBQUk7R0FBSTtHQUFJO0dBQUk7R0FBSTtHQUFJO0dBQUk7R0FBSTtHQUFJO0dBQUk7R0FBSTtHQUFJO0dBQUk7R0FBSTtHQUFJO0dBQUk7R0FBSTtHQUFJO0dBQUk7R0FBSTtHQUFJO0dBQUk7R0FBSTtHQUFJO0dBQUk7R0FBSTtHQUFJO0dBQUk7R0FBSTtHQUFJO0dBQUk7R0FBSTtHQUFJO0dBQUk7R0FBSTtHQUFJO0VBQUU7RUFFbks7R0FBQztHQUFJO0dBQUk7R0FBSTtHQUFJO0dBQUk7R0FBSTtHQUFJO0dBQUk7R0FBSTtHQUFJO0dBQUk7R0FBSTtHQUFJO0dBQUk7R0FBSTtHQUFJO0dBQUk7R0FBSTtHQUFJO0dBQUk7R0FBSTtHQUFJO0dBQUk7R0FBSTtHQUFJO0dBQUk7R0FBSTtHQUFJO0dBQUk7R0FBSTtHQUFJO0dBQUk7R0FBSTtHQUFJO0dBQUk7R0FBSTtHQUFJO0dBQUk7R0FBSTtHQUFJO0VBQUU7RUFFbks7R0FBQztHQUFJO0dBQUk7R0FBSTtHQUFJO0dBQUk7R0FBSTtHQUFJO0dBQUk7R0FBSTtHQUFJO0dBQUk7R0FBSTtHQUFJO0dBQUk7R0FBSTtHQUFJO0dBQUk7R0FBSTtHQUFJO0dBQUk7R0FBSTtHQUFJO0dBQUk7R0FBSTtHQUFJO0dBQUk7R0FBSTtHQUFJO0dBQUk7R0FBSTtHQUFJO0dBQUk7R0FBSTtHQUFJO0dBQUk7R0FBSTtHQUFJO0dBQUk7R0FBSTtHQUFJO0VBQUU7Q0FFcks7Q0FDQSxRQUFRLDhCQUE4QjtFQUdwQztHQUFDO0dBQUk7R0FBRztHQUFHO0dBQUc7R0FBRztHQUFHO0dBQUc7R0FBRztHQUFHO0dBQUc7R0FBRztHQUFHO0dBQUc7R0FBRztHQUFHO0dBQUc7R0FBRztHQUFHO0dBQUc7R0FBRztHQUFHO0dBQUc7R0FBRztHQUFHO0dBQUk7R0FBSTtHQUFJO0dBQUk7R0FBSTtHQUFJO0dBQUk7R0FBSTtHQUFJO0dBQUk7R0FBSTtHQUFJO0dBQUk7R0FBSTtHQUFJO0dBQUk7RUFBRTtFQUU1STtHQUFDO0dBQUk7R0FBRztHQUFHO0dBQUc7R0FBRztHQUFHO0dBQUc7R0FBRztHQUFHO0dBQUc7R0FBRztHQUFHO0dBQUc7R0FBRztHQUFHO0dBQUk7R0FBSTtHQUFJO0dBQUk7R0FBSTtHQUFJO0dBQUk7R0FBSTtHQUFJO0dBQUk7R0FBSTtHQUFJO0dBQUk7R0FBSTtHQUFJO0dBQUk7R0FBSTtHQUFJO0dBQUk7R0FBSTtHQUFJO0dBQUk7R0FBSTtHQUFJO0dBQUk7RUFBRTtFQUVySjtHQUFDO0dBQUk7R0FBRztHQUFHO0dBQUc7R0FBRztHQUFHO0dBQUc7R0FBRztHQUFHO0dBQUc7R0FBRztHQUFHO0dBQUk7R0FBSTtHQUFJO0dBQUk7R0FBSTtHQUFJO0dBQUk7R0FBSTtHQUFJO0dBQUk7R0FBSTtHQUFJO0dBQUk7R0FBSTtHQUFJO0dBQUk7R0FBSTtHQUFJO0dBQUk7R0FBSTtHQUFJO0dBQUk7R0FBSTtHQUFJO0dBQUk7R0FBSTtHQUFJO0dBQUk7RUFBRTtFQUV4SjtHQUFDO0dBQUk7R0FBRztHQUFHO0dBQUc7R0FBRztHQUFHO0dBQUc7R0FBRztHQUFHO0dBQUc7R0FBRztHQUFJO0dBQUk7R0FBSTtHQUFJO0dBQUk7R0FBSTtHQUFJO0dBQUk7R0FBSTtHQUFJO0dBQUk7R0FBSTtHQUFJO0dBQUk7R0FBSTtHQUFJO0dBQUk7R0FBSTtHQUFJO0dBQUk7R0FBSTtHQUFJO0dBQUk7R0FBSTtHQUFJO0dBQUk7R0FBSTtHQUFJO0dBQUk7RUFBRTtDQUUzSjtDQUVBLFdBQVcsU0FBUztDQUNwQixTQUFTLFdBQVcsS0FBSyxLQUFLLElBQUk7RUFDaEMsSUFBSSxNQUFNLEtBQUssTUFBTSxNQUFNLFFBQVEsT0FBTyxHQUN4QyxNQUFNLElBQUksV0FBVyxvQkFBb0I7RUFDM0MsS0FBSyxJQUFJLElBQUksTUFBTSxHQUFHLEtBQUssR0FBRyxLQUM1QixHQUFHLEtBQUssUUFBUSxJQUFJLENBQUM7Q0FDekI7Q0FDQSxTQUFTLE9BQU8sR0FBRyxHQUFHO0VBQ3BCLFFBQVEsTUFBTSxJQUFJLE1BQU07Q0FDMUI7Q0FDQSxTQUFTLE9BQU8sTUFBTTtFQUNwQixJQUFJLENBQUMsTUFDSCxNQUFNLElBQUksTUFBTSxpQkFBaUI7Q0FDckM7Q0FDQSxNQUFNLGFBQWEsTUFBTSxXQUFXO0VBS2xDLFlBQVksTUFBTSxVQUFVLFNBQVM7R0FDbkMsS0FBSyxPQUFPO0dBQ1osS0FBSyxXQUFXO0dBQ2hCLEtBQUssVUFBVTtHQUNmLElBQUksV0FBVyxHQUNiLE1BQU0sSUFBSSxXQUFXLGtCQUFrQjtHQUN6QyxLQUFLLFVBQVUsUUFBUSxNQUFNO0VBQy9CO0VBS0EsT0FBTyxVQUFVLE1BQU07R0FDckIsSUFBSSxLQUFLLENBQUM7R0FDVixLQUFLLE1BQU0sS0FBSyxNQUNkLFdBQVcsR0FBRyxHQUFHLEVBQUU7R0FDckIsT0FBTyxJQUFJLFdBQVcsV0FBVyxLQUFLLE1BQU0sS0FBSyxRQUFRLEVBQUU7RUFDN0Q7RUFFQSxPQUFPLFlBQVksUUFBUTtHQUN6QixJQUFJLENBQUMsV0FBVyxVQUFVLE1BQU0sR0FDOUIsTUFBTSxJQUFJLFdBQVcsd0NBQXdDO0dBQy9ELElBQUksS0FBSyxDQUFDO0dBQ1YsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLE9BQU8sU0FBVTtJQUNuQyxNQUFNLElBQUksS0FBSyxJQUFJLE9BQU8sU0FBUyxHQUFHLENBQUM7SUFDdkMsV0FBVyxTQUFTLE9BQU8sVUFBVSxHQUFHLElBQUksQ0FBQyxHQUFHLEVBQUUsR0FBRyxJQUFJLElBQUksR0FBRyxFQUFFO0lBQ2xFLEtBQUs7R0FDUDtHQUNBLE9BQU8sSUFBSSxXQUFXLFdBQVcsS0FBSyxTQUFTLE9BQU8sUUFBUSxFQUFFO0VBQ2xFO0VBSUEsT0FBTyxpQkFBaUIsTUFBTTtHQUM1QixJQUFJLENBQUMsV0FBVyxlQUFlLElBQUksR0FDakMsTUFBTSxJQUFJLFdBQVcsNkRBQTZEO0dBQ3BGLElBQUksS0FBSyxDQUFDO0dBQ1YsSUFBSSxJQUNLO0dBQVQsT0FBWSxJQUFJLEtBQUssS0FBSyxRQUFRLEtBQUssR0FBRztJQUN4QyxJQUFJLE9BQU8sV0FBVyxxQkFBcUIsUUFBUSxLQUFLLE9BQU8sQ0FBQyxDQUFDLElBQUk7SUFDckUsUUFBUSxXQUFXLHFCQUFxQixRQUFRLEtBQUssT0FBTyxJQUFJLENBQUMsQ0FBQztJQUNsRSxXQUFXLE1BQU0sSUFBSSxFQUFFO0dBQ3pCO0dBQ0EsSUFBSSxJQUFJLEtBQUssUUFDWCxXQUFXLFdBQVcscUJBQXFCLFFBQVEsS0FBSyxPQUFPLENBQUMsQ0FBQyxHQUFHLEdBQUcsRUFBRTtHQUMzRSxPQUFPLElBQUksV0FBVyxXQUFXLEtBQUssY0FBYyxLQUFLLFFBQVEsRUFBRTtFQUNyRTtFQUdBLE9BQU8sYUFBYSxNQUFNO0dBQ3hCLElBQUksUUFBUSxJQUNWLE9BQU8sQ0FBQztRQUNMLElBQUksV0FBVyxVQUFVLElBQUksR0FDaEMsT0FBTyxDQUFDLFdBQVcsWUFBWSxJQUFJLENBQUM7UUFDakMsSUFBSSxXQUFXLGVBQWUsSUFBSSxHQUNyQyxPQUFPLENBQUMsV0FBVyxpQkFBaUIsSUFBSSxDQUFDO1FBRXpDLE9BQU8sQ0FBQyxXQUFXLFVBQVUsV0FBVyxnQkFBZ0IsSUFBSSxDQUFDLENBQUM7RUFDbEU7RUFHQSxPQUFPLFFBQVEsV0FBVztHQUN4QixJQUFJLEtBQUssQ0FBQztHQUNWLElBQUksWUFBWSxHQUNkLE1BQU0sSUFBSSxXQUFXLG1DQUFtQztRQUNyRCxJQUFJLFlBQVksS0FDbkIsV0FBVyxXQUFXLEdBQUcsRUFBRTtRQUN4QixJQUFJLFlBQVksT0FBUztJQUM1QixXQUFXLEdBQUcsR0FBRyxFQUFFO0lBQ25CLFdBQVcsV0FBVyxJQUFJLEVBQUU7R0FDOUIsT0FBTyxJQUFJLFlBQVksS0FBSztJQUMxQixXQUFXLEdBQUcsR0FBRyxFQUFFO0lBQ25CLFdBQVcsV0FBVyxJQUFJLEVBQUU7R0FDOUIsT0FDRSxNQUFNLElBQUksV0FBVyxtQ0FBbUM7R0FDMUQsT0FBTyxJQUFJLFdBQVcsV0FBVyxLQUFLLEtBQUssR0FBRyxFQUFFO0VBQ2xEO0VBR0EsT0FBTyxVQUFVLE1BQU07R0FDckIsT0FBTyxXQUFXLGNBQWMsS0FBSyxJQUFJO0VBQzNDO0VBSUEsT0FBTyxlQUFlLE1BQU07R0FDMUIsT0FBTyxXQUFXLG1CQUFtQixLQUFLLElBQUk7RUFDaEQ7RUFHQSxVQUFVO0dBQ1IsT0FBTyxLQUFLLFFBQVEsTUFBTTtFQUM1QjtFQUdBLE9BQU8sYUFBYSxNQUFNLFNBQVM7R0FDakMsSUFBSSxTQUFTO0dBQ2IsS0FBSyxNQUFNLE9BQU8sTUFBTTtJQUN0QixNQUFNLFNBQVMsSUFBSSxLQUFLLGlCQUFpQixPQUFPO0lBQ2hELElBQUksSUFBSSxZQUFZLEtBQUssUUFDdkIsT0FBTztJQUNULFVBQVUsSUFBSSxTQUFTLElBQUksUUFBUTtHQUNyQztHQUNBLE9BQU87RUFDVDtFQUVBLE9BQU8sZ0JBQWdCLEtBQUs7R0FDMUIsTUFBTSxVQUFVLEdBQUc7R0FDbkIsSUFBSSxTQUFTLENBQUM7R0FDZCxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksSUFBSSxRQUFRLEtBQzlCLElBQUksSUFBSSxPQUFPLENBQUMsS0FBSyxLQUNuQixPQUFPLEtBQUssSUFBSSxXQUFXLENBQUMsQ0FBQztRQUMxQjtJQUNILE9BQU8sS0FBSyxTQUFTLElBQUksVUFBVSxJQUFJLEdBQUcsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDO0lBQ3JELEtBQUs7R0FDUDtHQUVGLE9BQU87RUFDVDtDQUNGO0NBR0EsV0FBVyxnQkFBZ0I7Q0FFM0IsV0FBVyxxQkFBcUI7Q0FHaEMsV0FBVyx1QkFBdUI7Q0FDbEMsSUFBSSxZQUFZO0NBQ2hCLFdBQVcsWUFBWTtBQUN6QixFQUFBLENBQUcsY0FBYyxZQUFZLENBQUMsRUFBRTtFQUM5QixlQUFlO0NBRWYsRUFBRSxZQUFZO0VBQ1osTUFBTSxPQUFPLE1BQU0sS0FBSztHQUd0QixZQUFZLFNBQVMsWUFBWTtJQUMvQixLQUFLLFVBQVU7SUFDZixLQUFLLGFBQWE7R0FDcEI7RUFDRjtFQUVBLEtBQUssTUFBTSxJQUFJLEtBQUssR0FBRyxDQUFDO0VBRXhCLEtBQUssU0FBUyxJQUFJLEtBQUssR0FBRyxDQUFDO0VBRTNCLEtBQUssV0FBVyxJQUFJLEtBQUssR0FBRyxDQUFDO0VBRTdCLEtBQUssT0FBTyxJQUFJLEtBQUssR0FBRyxDQUFDO0VBRXpCLFFBQVEsTUFBTTtDQUNoQixFQUFBLENBQVksV0FBVyxXQUFXLFdBQVcsU0FBUyxDQUFDLEVBQUU7QUFDM0QsRUFBQSxDQUFHLGNBQWMsWUFBWSxDQUFDLEVBQUU7RUFDOUIsZUFBZTtDQUVmLEVBQUUsZUFBZTtFQUNmLE1BQU0sUUFBUSxNQUFNLE1BQU07R0FFeEIsWUFBWSxVQUFVLGtCQUFrQjtJQUN0QyxLQUFLLFdBQVc7SUFDaEIsS0FBSyxtQkFBbUI7R0FDMUI7R0FJQSxpQkFBaUIsS0FBSztJQUNwQixPQUFPLEtBQUssaUJBQWlCLEtBQUssT0FBTyxNQUFNLEtBQUssRUFBRTtHQUN4RDtFQUNGO0VBRUEsTUFBTSxVQUFVLElBQUksTUFBTSxHQUFHO0dBQUM7R0FBSTtHQUFJO0VBQUUsQ0FBQztFQUN6QyxNQUFNLGVBQWUsSUFBSSxNQUFNLEdBQUc7R0FBQztHQUFHO0dBQUk7RUFBRSxDQUFDO0VBQzdDLE1BQU0sT0FBTyxJQUFJLE1BQU0sR0FBRztHQUFDO0dBQUc7R0FBSTtFQUFFLENBQUM7RUFDckMsTUFBTSxRQUFRLElBQUksTUFBTSxHQUFHO0dBQUM7R0FBRztHQUFJO0VBQUUsQ0FBQztFQUN0QyxNQUFNLE1BQU0sSUFBSSxNQUFNLEdBQUc7R0FBQztHQUFHO0dBQUc7RUFBQyxDQUFDO0VBRWxDLFdBQVcsT0FBTztDQUNwQixFQUFBLENBQWUsV0FBVyxjQUFjLFdBQVcsWUFBWSxDQUFDLEVBQUU7QUFDcEUsRUFBQSxDQUFHLGNBQWMsWUFBWSxDQUFDLEVBQUU7QUFDaEMsSUFBSSxvQkFBb0I7Ozs7OztBQVF4QixJQUFJLGtCQUFrQjtDQUNwQixHQUFHLGtCQUFrQixPQUFPLElBQUk7Q0FDaEMsR0FBRyxrQkFBa0IsT0FBTyxJQUFJO0NBQ2hDLEdBQUcsa0JBQWtCLE9BQU8sSUFBSTtDQUNoQyxHQUFHLGtCQUFrQixPQUFPLElBQUk7QUFDbEM7QUFDQSxJQUFJLGVBQWU7QUFDbkIsSUFBSSxnQkFBZ0I7QUFDcEIsSUFBSSxrQkFBa0I7QUFDdEIsSUFBSSxrQkFBa0I7QUFDdEIsSUFBSSx3QkFBd0I7QUFDNUIsSUFBSSxxQkFBcUI7QUFDekIsSUFBSSxtQkFBbUI7QUFDdkIsSUFBSSxzQkFBc0I7QUFDMUIsSUFBSSxvQkFBb0I7QUFDeEIsU0FBUyxhQUFhLFNBQVMsU0FBUyxHQUFHO0NBQ3pDLE1BQU0sTUFBTSxDQUFDO0NBQ2IsUUFBUSxRQUFRLFNBQVMsS0FBSyxHQUFHO0VBQy9CLElBQUksUUFBUTtFQUNaLElBQUksUUFBUSxTQUFTLE1BQU0sR0FBRztHQUM1QixJQUFJLENBQUMsUUFBUSxVQUFVLE1BQU07SUFDM0IsSUFBSSxLQUNGLElBQUksUUFBUSxPQUFPLEdBQUcsSUFBSSxPQUFPLEdBQUcsSUFBSSxNQUFNLEtBQUssUUFBUSxPQUFPLEVBQ3BFO0lBQ0EsUUFBUTtJQUNSO0dBQ0Y7R0FDQSxJQUFJLE1BQU0sSUFBSSxTQUFTLEdBQUc7SUFDeEIsSUFBSSxDQUFDLE1BQ0g7SUFFRixJQUFJLFVBQVUsTUFDWixJQUFJLEtBQUssSUFBSSxJQUFJLE9BQU8sR0FBRyxJQUFJLE9BQU8sUUFBUSxJQUFJLE9BQU8sRUFBRTtTQUUzRCxJQUFJLEtBQ0YsSUFBSSxRQUFRLE9BQU8sR0FBRyxJQUFJLE9BQU8sSUFBSSxJQUFJLElBQUksTUFBTSxLQUFLLFFBQVEsT0FBTyxFQUN6RTtJQUVGO0dBQ0Y7R0FDQSxJQUFJLFFBQVEsVUFBVSxNQUNwQixRQUFRO0VBRVosQ0FBQztDQUNILENBQUM7Q0FDRCxPQUFPLElBQUksS0FBSyxFQUFFO0FBQ3BCO0FBQ0EsU0FBUyxnQkFBZ0IsU0FBUyxZQUFZO0NBQzVDLE9BQU8sUUFBUSxNQUFNLENBQUMsQ0FBQyxLQUFLLEtBQUssTUFBTTtFQUNyQyxJQUFJLElBQUksV0FBVyxLQUFLLEtBQUssV0FBVyxJQUFJLFdBQVcsR0FDckQsT0FBTztFQUVULE9BQU8sSUFBSSxLQUFLLE1BQU0sTUFBTTtHQUMxQixJQUFJLElBQUksV0FBVyxLQUFLLEtBQUssV0FBVyxJQUFJLFdBQVcsR0FDckQsT0FBTztHQUVULE9BQU87RUFDVCxDQUFDO0NBQ0gsQ0FBQztBQUNIO0FBQ0EsU0FBUyxpQkFBaUIsT0FBTyxNQUFNLFFBQVEsZUFBZTtDQUM1RCxJQUFJLGlCQUFpQixNQUNuQixPQUFPO0NBRVQsTUFBTSxXQUFXLE1BQU0sU0FBUyxTQUFTO0NBQ3pDLE1BQU0sY0FBYyxLQUFLLE1BQU0sT0FBTyxpQkFBaUI7Q0FDdkQsTUFBTSxRQUFRLFdBQVc7Q0FDekIsTUFBTSxLQUFLLGNBQWMsU0FBUyxlQUFlO0NBQ2pELE1BQU0sS0FBSyxjQUFjLFVBQVUsZUFBZTtDQUNsRCxNQUFNLElBQUksY0FBYyxLQUFLLE9BQU8sTUFBTSxTQUFTLElBQUksSUFBSSxJQUFJLGNBQWMsSUFBSTtDQUNqRixNQUFNLElBQUksY0FBYyxLQUFLLE9BQU8sTUFBTSxTQUFTLElBQUksSUFBSSxJQUFJLGNBQWMsSUFBSTtDQUNqRixNQUFNLFVBQVUsY0FBYyxXQUFXLE9BQU8sSUFBSSxjQUFjO0NBQ2xFLElBQUksYUFBYTtDQUNqQixJQUFJLGNBQWMsVUFBVTtFQUMxQixJQUFJLFNBQVMsS0FBSyxNQUFNLENBQUM7RUFDekIsSUFBSSxTQUFTLEtBQUssTUFBTSxDQUFDO0VBR3pCLGFBQWE7R0FBRSxHQUFHO0dBQVEsR0FBRztHQUFRLEdBRnpCLEtBQUssS0FBSyxJQUFJLElBQUksTUFFYztHQUFHLEdBRG5DLEtBQUssS0FBSyxJQUFJLElBQUksTUFDd0I7RUFBRTtDQUMxRDtDQUNBLE1BQU0sY0FBYyxjQUFjO0NBQ2xDLE9BQU87RUFBRTtFQUFHO0VBQUc7RUFBRztFQUFHO0VBQVk7RUFBUztDQUFZO0FBQ3hEO0FBQ0EsU0FBUyxjQUFjLGVBQWUsWUFBWTtDQUNoRCxJQUFJLGNBQWMsTUFDaEIsT0FBTyxLQUFLLElBQUksS0FBSyxNQUFNLFVBQVUsR0FBRyxDQUFDO0NBRTNDLE9BQU8sZ0JBQWdCLG1CQUFtQjtBQUM1QztBQUNBLFNBQVMsVUFBVSxFQUNqQixPQUNBLE9BQ0EsWUFDQSxlQUNBLFlBQ0EsZUFDQSxNQUNBLGNBQ0M7Q0FDRCxJQUFJLFNBQUEsYUFBZSxjQUFjO0VBRS9CLE1BQU0sWUFEUyxNQUFNLFFBQVEsS0FBSyxJQUFJLFFBQVEsQ0FBQyxLQUFLLEVBQUEsQ0FDNUIsUUFBUSxPQUFPLE1BQU07R0FDM0MsTUFBTSxLQUFLLEdBQUcsa0JBQWtCLFVBQVUsYUFBYSxDQUFDLENBQUM7R0FDekQsT0FBTztFQUNULEdBQUcsQ0FBQyxDQUFDO0VBQ0wsT0FBTyxrQkFBa0IsT0FBTyxlQUM5QixVQUNBLGdCQUFnQixRQUNoQixZQUNBLEtBQUssR0FDTCxLQUFLLEdBQ0wsVUFDRjtDQUNGLEdBQUc7RUFBQztFQUFPO0VBQU87RUFBWTtDQUFVLENBQUM7Q0FDekMsTUFBTSxFQUFFLE9BQU8sUUFBUSxVQUFVLDRCQUFBLGFBQWtDLGNBQWM7RUFDL0UsSUFBSSxTQUFTLE9BQU8sV0FBVztFQUMvQixNQUFNLFVBQVUsY0FBYyxlQUFlLFVBQVU7RUFRdkQsT0FBTztHQUNMLE9BQU87R0FDUCxRQUFRO0dBQ1IsVUFWZ0IsT0FBTyxTQUFTLFVBQVU7R0FXMUMseUJBVitCLGlCQUMvQixRQUNBLE1BQ0EsU0FDQSxhQU1nRDtFQUNsRDtDQUNGLEdBQUc7RUFBQztFQUFRO0VBQU07RUFBZTtFQUFlO0NBQVUsQ0FBQztDQUMzRCxPQUFPO0VBQ0w7RUFDQTtFQUNBO0VBQ0E7RUFDQTtDQUNGO0FBQ0Y7QUFDQSxJQUFJLGtCQUFrQixXQUFXO0NBQy9CLElBQUk7RUFDRixJQUFJLE9BQU8sQ0FBQyxDQUFDLFFBQVEsSUFBSSxPQUFPLENBQUM7Q0FDbkMsU0FBUyxHQUFHO0VBQ1YsT0FBTztDQUNUO0NBQ0EsT0FBTztBQUNULEVBQUU7QUFDRixJQUFJLGVBQUEsYUFBcUIsV0FDdkIsU0FBUyxjQUFjLE9BQU8sY0FBYztDQUMxQyxNQUFNLEtBQUssT0FBTyxFQUNoQixPQUNBLE9BQU8sY0FDUCxRQUFRLGVBQ1IsVUFBVSxpQkFDVixVQUFVLGlCQUNWLGdCQUFnQix1QkFDaEIsYUFBYSxvQkFDYixZQUNBLFlBQ0Esa0JBQ0U7Q0FZSixNQUFNLEtBWmUsVUFBVSxJQUFJO0VBQ2pDO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0NBQ0YsQ0FDb0IsR0FBRyxFQUFFLFVBQVUsSUFBSSxhQUFhLFVBQVUsSUFBSSxDQUFDLE9BQU8sQ0FBQztDQUMzRSxNQUFNLFNBQVMsaUJBQWlCLE9BQU8sS0FBSyxJQUFJLGNBQWM7Q0FDOUQsTUFBTSxVQUFBLGFBQWdCLE9BQU8sSUFBSTtDQUNqQyxNQUFNLFNBQUEsYUFBZSxPQUFPLElBQUk7Q0FDaEMsTUFBTSxlQUFBLGFBQXFCLGFBQ3hCLFNBQVM7RUFDUixRQUFRLFVBQVU7RUFDbEIsSUFBSSxPQUFPLGlCQUFpQixZQUMxQixhQUFhLElBQUk7T0FDWixJQUFJLGNBQ1QsYUFBYSxVQUFVO0NBRTNCLEdBQ0EsQ0FBQyxZQUFZLENBQ2Y7Q0FDQSxNQUFNLENBQUMsYUFBYSxvQkFBQSxhQUEwQixTQUFTLEtBQUs7Q0FDNUQsTUFBTSxFQUFFLFFBQVEsT0FBTyxVQUFVLDRCQUE0QixVQUFVO0VBQ3JFO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7Q0FDRixDQUFDO0NBQ0QsYUFBTSxnQkFBZ0I7RUFDcEIsSUFBSSxRQUFRLFdBQVcsTUFBTTtHQUMzQixNQUFNLFNBQVMsUUFBUTtHQUN2QixNQUFNLE1BQU0sT0FBTyxXQUFXLElBQUk7R0FDbEMsSUFBSSxDQUFDLEtBQ0g7R0FFRixJQUFJLGNBQWM7R0FDbEIsTUFBTSxRQUFRLE9BQU87R0FDckIsTUFBTSxvQkFBb0IsMkJBQTJCLFFBQVEsVUFBVSxRQUFRLE1BQU0sWUFBWSxNQUFNLGtCQUFrQixLQUFLLE1BQU0saUJBQWlCO0dBQ3JKLElBQUksbUJBQ0U7UUFBQSx3QkFBd0IsY0FBYyxNQUN4QyxjQUFjLGdCQUNaLE9BQ0Esd0JBQXdCLFVBQzFCO0dBQUE7R0FHSixNQUFNLGFBQWEsT0FBTyxvQkFBb0I7R0FDOUMsT0FBTyxTQUFTLE9BQU8sUUFBUSxPQUFPO0dBQ3RDLE1BQU0sUUFBUSxPQUFPLFdBQVc7R0FDaEMsSUFBSSxNQUFNLE9BQU8sS0FBSztHQUN0QixJQUFJLFlBQVk7R0FDaEIsSUFBSSxTQUFTLEdBQUcsR0FBRyxVQUFVLFFBQVE7R0FDckMsSUFBSSxZQUFZO0dBQ2hCLElBQUksaUJBQ0YsSUFBSSxLQUFLLElBQUksT0FBTyxhQUFhLGFBQWEsTUFBTSxDQUFDLENBQUM7UUFFdEQsTUFBTSxRQUFRLFNBQVMsS0FBSyxLQUFLO0lBQy9CLElBQUksUUFBUSxTQUFTLE1BQU0sS0FBSztLQUM5QixJQUFJLE1BQ0YsSUFBSSxTQUFTLE1BQU0sUUFBUSxNQUFNLFFBQVEsR0FBRyxDQUFDO0lBRWpELENBQUM7R0FDSCxDQUFDO0dBRUgsSUFBSSx5QkFDRixJQUFJLGNBQWMsd0JBQXdCO0dBRTVDLElBQUksbUJBQ0YsSUFBSSxVQUNGLE9BQ0Esd0JBQXdCLElBQUksUUFDNUIsd0JBQXdCLElBQUksUUFDNUIsd0JBQXdCLEdBQ3hCLHdCQUF3QixDQUMxQjtFQUVKO0NBQ0YsQ0FBQztDQUNELGFBQU0sZ0JBQWdCO0VBQ3BCLGlCQUFpQixLQUFLO0NBQ3hCLEdBQUcsQ0FBQyxNQUFNLENBQUM7Q0FDWCxNQUFNLGNBQWMsZUFBZTtFQUFFLFFBQVE7RUFBTSxPQUFPO0NBQUssR0FBRyxLQUFLO0NBQ3ZFLElBQUksTUFBTTtDQUNWLElBQUksVUFBVSxNQUNaLE1BQXNCLDZCQUFNLGNBQzFCLE9BQ0E7RUFDRSxLQUFLO0VBQ0wsS0FBSztFQUNMLE9BQU8sRUFBRSxTQUFTLE9BQU87RUFDekIsY0FBYztHQUNaLGlCQUFpQixJQUFJO0VBQ3ZCO0VBQ0EsS0FBSztFQUNMLGFBQWEsMkJBQTJCLE9BQU8sS0FBSyxJQUFJLHdCQUF3QjtDQUNsRixDQUNGO0NBRUYsT0FBdUIsNkJBQU0sY0FBQSxhQUFvQixVQUFVLE1BQXNCLDZCQUFNLGNBQ3JGLFVBQ0EsZUFBZTtFQUNiLE9BQU87RUFDUCxRQUFRO0VBQ1IsT0FBTztFQUNQLEtBQUs7RUFDTCxNQUFNO0NBQ1IsR0FBRyxVQUFVLENBQ2YsR0FBRyxHQUFHO0FBQ1IsQ0FDRjtBQUNBLGFBQWEsY0FBYztBQUMzQixJQUFJLFlBQUEsYUFBa0IsV0FDcEIsU0FBUyxXQUFXLE9BQU8sY0FBYztDQUN2QyxNQUFNLEtBQUssT0FBTyxFQUNoQixPQUNBLE9BQU8sY0FDUCxRQUFRLGVBQ1IsVUFBVSxpQkFDVixVQUFVLGlCQUNWLGdCQUFnQix1QkFDaEIsYUFBYSxvQkFDYixZQUNBLE9BQ0EsWUFDQSxrQkFDRSxJQUFJLGFBQWEsVUFBVSxJQUFJO0VBQ2pDO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7Q0FDRixDQUFDO0NBQ0QsTUFBTSxFQUFFLFFBQVEsT0FBTyxVQUFVLDRCQUE0QixVQUFVO0VBQ3JFO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7Q0FDRixDQUFDO0NBQ0QsSUFBSSxjQUFjO0NBQ2xCLElBQUksUUFBUTtDQUNaLElBQUksaUJBQWlCLFFBQVEsMkJBQTJCLE1BQU07RUFDNUQsSUFBSSx3QkFBd0IsY0FBYyxNQUN4QyxjQUFjLGdCQUNaLE9BQ0Esd0JBQXdCLFVBQzFCO0VBRUYsUUFBd0IsNkJBQU0sY0FDNUIsU0FDQTtHQUNFLE1BQU0sY0FBYztHQUNwQixRQUFRLHdCQUF3QjtHQUNoQyxPQUFPLHdCQUF3QjtHQUMvQixHQUFHLHdCQUF3QixJQUFJO0dBQy9CLEdBQUcsd0JBQXdCLElBQUk7R0FDL0IscUJBQXFCO0dBQ3JCLFNBQVMsd0JBQXdCO0dBQ2pDLGFBQWEsd0JBQXdCO0VBQ3ZDLENBQ0Y7Q0FDRjtDQUNBLE1BQU0sU0FBUyxhQUFhLGFBQWEsTUFBTTtDQUMvQyxPQUF1Qiw2QkFBTSxjQUMzQixPQUNBLGVBQWU7RUFDYixRQUFRO0VBQ1IsT0FBTztFQUNQLFNBQVMsT0FBTyxTQUFTLEdBQUc7RUFDNUIsS0FBSztFQUNMLE1BQU07Q0FDUixHQUFHLFVBQVUsR0FDYixDQUFDLENBQUMsU0FBeUIsNkJBQU0sY0FBYyxTQUFTLE1BQU0sS0FBSyxHQUNuRCw2QkFBTSxjQUNwQixRQUNBO0VBQ0UsTUFBTTtFQUNOLEdBQUcsU0FBUyxTQUFTLEdBQUcsU0FBUztFQUNqQyxnQkFBZ0I7Q0FDbEIsQ0FDRixHQUNnQiw2QkFBTSxjQUFjLFFBQVE7RUFBRSxNQUFNO0VBQVMsR0FBRztFQUFRLGdCQUFnQjtDQUFhLENBQUMsR0FDdEcsS0FDRjtBQUNGLENBQ0Y7QUFDQSxVQUFVLGNBQWMiLCJ4X2dvb2dsZV9pZ25vcmVMaXN0IjpbMF19