import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/licenciamento/RequerimentosListPage.tsx");const React = __vite__cjsImport0_react; const useMemo = __vite__cjsImport0_react["useMemo"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport6_react_jsxDevRuntime["jsxDEV"];/**
* Fila de Licenciamento Sanitário e Requerimentos de Alvará
* Rota: /licenciamento ou /licenciamento/requerimentos
* Apresenta a fila de trabalho de processos de licenciamento, triagem e decisões fiscais.
*/
import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=0fd2848a";
import { Link, useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=0fd2848a";
import { Award, Clock, FileCheck, FileSearch, Filter, Hourglass, RefreshCw, Search } from "/node_modules/.vite/deps/lucide-react.js?v=0fd2848a";
import { ROUTES } from "/src/config/routes.config.ts";
import { useAlvarasList, useRequerimentosList } from "/src/hooks/useLicenciamento.ts";
import { StatusRequerimentoBadge } from "/src/components/licenciamento/StatusRequerimentoBadge.tsx";
var _jsxFileName = "E:/Projetos VSCODE/visa_braunas/src/pages/licenciamento/RequerimentosListPage.tsx";
import __vite__cjsImport6_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=0fd2848a";
var _s = $RefreshSig$();
export const RequerimentosListPage = () => {
	_s();
	const navigate = useNavigate();
	const [tabAtiva, setTabAtiva] = useState("fila_trabalho");
	const [busca, setBusca] = useState("");
	const [tipoFiltro, setTipoFiltro] = useState("");
	// Consulta da lista com filtros do TanStack Query v5
	const statusParam = tabAtiva === "pendentes" ? "pendente" : tabAtiva === "em_analise" ? "em_analise" : tabAtiva === "aguardando_inspecao" ? "aguardando_inspecao" : tabAtiva === "deferidos" ? "deferido" : tabAtiva === "indeferidos" ? "indeferido" : "";
	const { data: requerimentosData, isLoading, isRefetching, refetch } = useRequerimentosList({
		apenas_fila: tabAtiva === "fila_trabalho" ? true : undefined,
		status: statusParam || undefined,
		limit: 100
	});
	const { data: alvarasData } = useAlvarasList({ limit: 1 });
	const requerimentos = requerimentosData?.items || requerimentosData?.itens || [];
	// Filtragem local complementar por texto (protocolo, razão social declarada ou CNPJ)
	const requerimentosFiltrados = useMemo(() => {
		return requerimentos.filter((item) => {
			if (tipoFiltro && item.tipo_solicitacao !== tipoFiltro) {
				return false;
			}
			if (!busca.trim()) return true;
			const termo = busca.toLowerCase();
			const matchProtocolo = item.numero_protocolo.toLowerCase().includes(termo);
			const matchRazao = item.dados_declarados?.razao_social?.toLowerCase().includes(termo);
			const matchCnpj = item.dados_declarados?.cpf_cnpj?.toLowerCase().includes(termo);
			return matchProtocolo || matchRazao || matchCnpj;
		});
	}, [
		requerimentos,
		busca,
		tipoFiltro
	]);
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-xs",
				children: [/* @__PURE__ */ _jsxDEV("div", { children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-2 text-teal-600 dark:text-teal-400 mb-1",
						children: /* @__PURE__ */ _jsxDEV("span", {
							className: "text-[11px] font-bold uppercase tracking-wider bg-teal-50 dark:bg-teal-950/40 px-2 py-0.5 rounded border border-teal-200 dark:border-teal-800",
							children: "Certificação & Alvarás Sanitários"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 106,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 105,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("h1", {
						className: "text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2",
						children: "Licenciamento Sanitário Municipal"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 110,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("p", {
						className: "text-xs text-slate-500 dark:text-slate-400 mt-1 max-w-2xl",
						children: "Fila de análise técnica de petições, conferência de vistorias e homologação para expedição oficial de Alvarás Sanitários."
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 113,
						columnNumber: 11
					}, this)
				] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 104,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-2.5",
					children: /* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						onClick: () => refetch(),
						disabled: isRefetching,
						className: "p-2 text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl transition-colors shadow-2xs",
						title: "Atualizar lista",
						children: /* @__PURE__ */ _jsxDEV(RefreshCw, { className: `w-4 h-4 ${isRefetching ? "animate-spin text-teal-600" : ""}` }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 126,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 119,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 118,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 103,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 shadow-2xs",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center justify-between",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-xs font-semibold text-slate-500 dark:text-slate-400",
								children: "Fila de Trabalho Ativa"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 138,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV(Hourglass, { className: "w-4 h-4 text-amber-500" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 141,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 137,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "mt-2 flex items-baseline gap-2",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-2xl font-bold text-slate-900 dark:text-white",
								children: requerimentosData?.total ?? 0
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 144,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "text-[11px] text-slate-400",
								children: "processos"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 147,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 143,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 136,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 shadow-2xs",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center justify-between",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-xs font-semibold text-slate-500 dark:text-slate-400",
								children: "Análise Documental"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 154,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV(FileSearch, { className: "w-4 h-4 text-sky-500" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 157,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 153,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "mt-2 flex items-baseline gap-2",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-2xl font-bold text-sky-600 dark:text-sky-400",
								children: requerimentos.filter((r) => r.status === "em_analise").length
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 160,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "text-[11px] text-slate-400",
								children: "em instrução"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 163,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 159,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 152,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 shadow-2xs",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center justify-between",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-xs font-semibold text-slate-500 dark:text-slate-400",
								children: "Aguardando Vistoria"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 170,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV(Clock, { className: "w-4 h-4 text-indigo-500" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 173,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 169,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "mt-2 flex items-baseline gap-2",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-2xl font-bold text-indigo-600 dark:text-indigo-400",
								children: requerimentos.filter((r) => r.status === "aguardando_inspecao").length
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 176,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "text-[11px] text-slate-400",
								children: "de campo"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 179,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 175,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 168,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 shadow-2xs",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center justify-between",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-xs font-semibold text-slate-500 dark:text-slate-400",
								children: "Total Alvarás Emitidos"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 186,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV(Award, { className: "w-4 h-4 text-emerald-600 dark:text-emerald-400" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 189,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 185,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "mt-2 flex items-baseline gap-2",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-2xl font-bold text-emerald-600 dark:text-emerald-400",
								children: alvarasData?.total ?? 0
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 192,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "text-[11px] text-slate-400",
								children: "expedidos"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 195,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 191,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 184,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 134,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-xs overflow-hidden",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "border-b border-slate-200 dark:border-slate-800 px-6 pt-3 flex items-center justify-between gap-4 overflow-x-auto",
						children: /* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-6",
							children: [
								/* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => setTabAtiva("fila_trabalho"),
									className: `pb-3 text-xs font-bold border-b-2 transition-colors whitespace-nowrap flex items-center gap-1.5 ${tabAtiva === "fila_trabalho" ? "border-teal-600 text-teal-600 dark:text-teal-400" : "border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-300"}`,
									children: [/* @__PURE__ */ _jsxDEV(Hourglass, { className: "w-3.5 h-3.5" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 214,
										columnNumber: 15
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Fila de Trabalho (Pendentes)" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 215,
										columnNumber: 15
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 205,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => setTabAtiva("todos"),
									className: `pb-3 text-xs font-bold border-b-2 transition-colors whitespace-nowrap ${tabAtiva === "todos" ? "border-teal-600 text-teal-600 dark:text-teal-400" : "border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-300"}`,
									children: "Todos os Processos"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 218,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => setTabAtiva("em_analise"),
									className: `pb-3 text-xs font-bold border-b-2 transition-colors whitespace-nowrap ${tabAtiva === "em_analise" ? "border-teal-600 text-teal-600 dark:text-teal-400" : "border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-300"}`,
									children: "Em Análise Documental"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 230,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => setTabAtiva("aguardando_inspecao"),
									className: `pb-3 text-xs font-bold border-b-2 transition-colors whitespace-nowrap ${tabAtiva === "aguardando_inspecao" ? "border-teal-600 text-teal-600 dark:text-teal-400" : "border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-300"}`,
									children: "Aguardando Vistoria"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 242,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => setTabAtiva("deferidos"),
									className: `pb-3 text-xs font-bold border-b-2 transition-colors whitespace-nowrap ${tabAtiva === "deferidos" ? "border-teal-600 text-teal-600 dark:text-teal-400" : "border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-300"}`,
									children: "Deferidos / Emitidos"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 254,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => setTabAtiva("indeferidos"),
									className: `pb-3 text-xs font-bold border-b-2 transition-colors whitespace-nowrap ${tabAtiva === "indeferidos" ? "border-teal-600 text-teal-600 dark:text-teal-400" : "border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-300"}`,
									children: "Indeferidos"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 266,
									columnNumber: 13
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 204,
							columnNumber: 11
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 203,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "p-4 bg-slate-50/50 dark:bg-slate-800/40 border-b border-slate-200 dark:border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "relative flex-1 max-w-md",
							children: [/* @__PURE__ */ _jsxDEV(Search, { className: "w-4 h-4 text-slate-400 absolute left-3 top-2.5" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 283,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								type: "text",
								placeholder: "Buscar por protocolo (ex: REQ-2026), empresa ou CNPJ...",
								value: busca,
								onChange: (e) => setBusca(e.target.value),
								className: "w-full pl-9 pr-4 py-2 text-xs bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-teal-500"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 284,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 282,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ _jsxDEV(Filter, { className: "w-3.5 h-3.5 text-slate-400" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 294,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("select", {
								value: tipoFiltro,
								onChange: (e) => setTipoFiltro(e.target.value),
								className: "px-3 py-1.5 text-xs bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-700 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-teal-500",
								children: [
									/* @__PURE__ */ _jsxDEV("option", {
										value: "",
										children: "Todos os Tipos"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 300,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("option", {
										value: "concessao_inicial",
										children: "Concessão Inicial"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 301,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("option", {
										value: "renovacao",
										children: "Renovação"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 302,
										columnNumber: 15
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 295,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 293,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 281,
						columnNumber: 9
					}, this),
					isLoading ? /* @__PURE__ */ _jsxDEV("div", {
						className: "p-16 text-center text-slate-400 text-xs flex flex-col items-center justify-center",
						children: [/* @__PURE__ */ _jsxDEV("div", { className: "w-6 h-6 border-2 border-teal-500 border-t-transparent rounded-full animate-spin mb-3" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 310,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Consultando processos de licenciamento..." }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 311,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 309,
						columnNumber: 11
					}, this) : requerimentosFiltrados.length === 0 ? /* @__PURE__ */ _jsxDEV("div", {
						className: "p-12 text-center text-slate-500 dark:text-slate-400 space-y-3",
						children: [
							/* @__PURE__ */ _jsxDEV(FileCheck, { className: "w-10 h-10 text-slate-300 dark:text-slate-700 mx-auto" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 315,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("p", {
								className: "text-xs font-semibold text-slate-700 dark:text-slate-300",
								children: "Nenhum processo de requerimento encontrado para os critérios selecionados."
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 316,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("p", {
								className: "text-[11px] text-slate-400 max-w-sm mx-auto",
								children: "Novas petições submetidas via formulário eletrônico ou balcão de atendimento constarão nesta fila de trabalho."
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 319,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 314,
						columnNumber: 11
					}, this) : /* @__PURE__ */ _jsxDEV("div", {
						className: "overflow-x-auto",
						children: /* @__PURE__ */ _jsxDEV("table", {
							className: "w-full text-left text-xs border-collapse",
							children: [/* @__PURE__ */ _jsxDEV("thead", {
								className: "bg-slate-50/80 dark:bg-slate-800/60 border-b border-slate-200 dark:border-slate-800 text-slate-500 dark:text-slate-400 font-semibold uppercase tracking-wider",
								children: /* @__PURE__ */ _jsxDEV("tr", { children: [
									/* @__PURE__ */ _jsxDEV("th", {
										className: "py-3.5 px-4",
										children: "Protocolo"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 328,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("th", {
										className: "py-3.5 px-4",
										children: "Tipo"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 329,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("th", {
										className: "py-3.5 px-4",
										children: "Estabelecimento / Requerente"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 330,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("th", {
										className: "py-3.5 px-4",
										children: "Data Submissão"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 331,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("th", {
										className: "py-3.5 px-4",
										children: "Status"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 332,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("th", {
										className: "py-3.5 px-4 text-right",
										children: "Ação"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 333,
										columnNumber: 19
									}, this)
								] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 327,
									columnNumber: 17
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 326,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("tbody", {
								className: "divide-y divide-slate-100 dark:divide-slate-800",
								children: requerimentosFiltrados.map((item) => {
									const razaoSocial = item.dados_declarados?.razao_social || "Razão Social Declarada";
									const cnpjCpf = item.dados_declarados?.cpf_cnpj || "---";
									return /* @__PURE__ */ _jsxDEV("tr", {
										className: "hover:bg-slate-50/60 dark:hover:bg-slate-800/40 transition-colors",
										children: [
											/* @__PURE__ */ _jsxDEV("td", {
												className: "py-3.5 px-4",
												children: /* @__PURE__ */ _jsxDEV("div", {
													className: "flex flex-col",
													children: [/* @__PURE__ */ _jsxDEV("span", {
														className: "font-mono font-bold text-slate-900 dark:text-white",
														children: item.numero_protocolo
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 350,
														columnNumber: 27
													}, this), /* @__PURE__ */ _jsxDEV("span", {
														className: "text-[10px] text-slate-400",
														children: ["Origem: ", item.origem_solicitacao]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 353,
														columnNumber: 27
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 349,
													columnNumber: 25
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 348,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("td", {
												className: "py-3.5 px-4",
												children: /* @__PURE__ */ _jsxDEV("span", {
													className: "capitalize font-medium text-slate-700 dark:text-slate-300",
													children: item.tipo_solicitacao === "concessao_inicial" ? "Concessão Inicial" : "Renovação Anual"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 361,
													columnNumber: 25
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 360,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("td", {
												className: "py-3.5 px-4",
												children: /* @__PURE__ */ _jsxDEV("div", {
													className: "flex flex-col",
													children: [/* @__PURE__ */ _jsxDEV("span", {
														className: "font-bold text-slate-800 dark:text-slate-200",
														children: razaoSocial
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 371,
														columnNumber: 27
													}, this), /* @__PURE__ */ _jsxDEV("span", {
														className: "text-[10px] font-mono text-slate-400",
														children: cnpjCpf
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 374,
														columnNumber: 27
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 370,
													columnNumber: 25
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 369,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("td", {
												className: "py-3.5 px-4 text-slate-600 dark:text-slate-300",
												children: new Date(item.data_submissao).toLocaleDateString("pt-BR", {
													day: "2-digit",
													month: "2-digit",
													year: "numeric",
													hour: "2-digit",
													minute: "2-digit"
												})
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 381,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("td", {
												className: "py-3.5 px-4",
												children: /* @__PURE__ */ _jsxDEV(StatusRequerimentoBadge, { status: item.status }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 393,
													columnNumber: 25
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 392,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("td", {
												className: "py-3.5 px-4 text-right",
												children: /* @__PURE__ */ _jsxDEV(Link, {
													to: ROUTES.LICENCIAMENTO.DETALHE(item.id),
													className: "px-3 py-1.5 text-xs font-bold text-teal-700 dark:text-teal-300 bg-teal-50 dark:bg-teal-950/40 border border-teal-200 dark:border-teal-800 rounded-lg hover:bg-teal-100/60 shadow-2xs transition-colors inline-flex items-center gap-1.5",
													children: [/* @__PURE__ */ _jsxDEV(FileSearch, { className: "w-3.5 h-3.5" }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 402,
														columnNumber: 27
													}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Analisar Processo" }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 403,
														columnNumber: 27
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 398,
													columnNumber: 25
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 397,
												columnNumber: 23
											}, this)
										]
									}, item.id, true, {
										fileName: _jsxFileName,
										lineNumber: 343,
										columnNumber: 21
									}, this);
								})
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 336,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 325,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 324,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 201,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 101,
		columnNumber: 5
	}, this);
};
_s(RequerimentosListPage, "P2GFrvfxsa/c39oJXuKn9hSY4Qg=", false, function() {
	return [
		useNavigate,
		useRequerimentosList,
		useAlvarasList
	];
});
_c = RequerimentosListPage;
export default RequerimentosListPage;
var _c;
$RefreshReg$(_c, "RequerimentosListPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/licenciamento/RequerimentosListPage.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("E:/Projetos VSCODE/visa_braunas/src/pages/licenciamento/RequerimentosListPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("E:/Projetos VSCODE/visa_braunas/src/pages/licenciamento/RequerimentosListPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "E:/Projetos VSCODE/visa_braunas/src/pages/licenciamento/RequerimentosListPage.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7Ozs7QUFNQSxPQUFPLFNBQVMsU0FBUyxnQkFBZ0I7QUFDekMsU0FBUyxNQUFNLG1CQUFtQjtBQUNsQyxTQUVFLE9BSUEsT0FFQSxXQUNBLFlBQ0EsUUFDQSxXQUVBLFdBQ0EsY0FFSztBQUNQLFNBQVMsY0FBYztBQUN2QixTQUFTLGdCQUFnQiw0QkFBNEI7QUFFckQsU0FBUywrQkFBK0I7Ozs7QUFXeEMsT0FBTyxNQUFNLDhCQUF3Qzs7Q0FDbkQsTUFBTSxXQUFXLFlBQVk7Q0FDN0IsTUFBTSxDQUFDLFVBQVUsZUFBZSxTQUFrQixlQUFlO0NBQ2pFLE1BQU0sQ0FBQyxPQUFPLFlBQVksU0FBUyxFQUFFO0NBQ3JDLE1BQU0sQ0FBQyxZQUFZLGlCQUFpQixTQUFxQyxFQUFFOztDQUczRSxNQUFNLGNBQ0osYUFBYSxjQUNULGFBQ0EsYUFBYSxlQUNiLGVBQ0EsYUFBYSx3QkFDYix3QkFDQSxhQUFhLGNBQ2IsYUFDQSxhQUFhLGdCQUNiLGVBQ0E7Q0FFTixNQUFNLEVBQ0osTUFBTSxtQkFDTixXQUNBLGNBQ0EsWUFDRSxxQkFBcUI7RUFDdkIsYUFBYSxhQUFhLGtCQUFrQixPQUFPO0VBQ25ELFFBQVEsZUFBZTtFQUN2QixPQUFPO0NBQ1QsQ0FBQztDQUVELE1BQU0sRUFBRSxNQUFNLGdCQUFnQixlQUFlLEVBQUUsT0FBTyxFQUFFLENBQUM7Q0FFekQsTUFBTSxnQkFDSixtQkFBbUIsU0FDbEIsbUJBQStHLFNBQ2hILENBQUM7O0NBR0gsTUFBTSx5QkFBeUIsY0FBYztFQUMzQyxPQUFPLGNBQWMsUUFBUSxTQUFTO0dBQ3BDLElBQUksY0FBYyxLQUFLLHFCQUFxQixZQUFZO0lBQ3RELE9BQU87R0FDVDtHQUVBLElBQUksQ0FBQyxNQUFNLEtBQUssR0FBRyxPQUFPO0dBRTFCLE1BQU0sUUFBUSxNQUFNLFlBQVk7R0FDaEMsTUFBTSxpQkFBaUIsS0FBSyxpQkFBaUIsWUFBWSxDQUFDLENBQUMsU0FBUyxLQUFLO0dBQ3pFLE1BQU0sYUFBYSxLQUFLLGtCQUFrQixjQUN0QyxZQUFZLENBQUMsQ0FDZCxTQUFTLEtBQUs7R0FDakIsTUFBTSxZQUFZLEtBQUssa0JBQWtCLFVBQ3JDLFlBQVksQ0FBQyxDQUNkLFNBQVMsS0FBSztHQUVqQixPQUFPLGtCQUFrQixjQUFjO0VBQ3pDLENBQUM7Q0FDSCxHQUFHO0VBQUM7RUFBZTtFQUFPO0NBQVUsQ0FBQztDQUVyQyxPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQWY7R0FFRSx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsT0FBRDtLQUNFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUNiLHdCQUFDLFFBQUQ7T0FBTSxXQUFVO2lCQUFnSjtNQUUxSjs7Ozs7S0FDSDs7Ozs7S0FDTCx3QkFBQyxNQUFEO01BQUksV0FBVTtnQkFBMkU7S0FFckY7Ozs7O0tBQ0osd0JBQUMsS0FBRDtNQUFHLFdBQVU7Z0JBQTREO0tBRXRFOzs7OztJQUNBOzs7O2NBRUwsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFDYix3QkFBQyxVQUFEO01BQ0UsTUFBSztNQUNMLGVBQWUsUUFBUTtNQUN2QixVQUFVO01BQ1YsV0FBVTtNQUNWLE9BQU07Z0JBRU4sd0JBQUMsV0FBRCxFQUNFLFdBQVcsV0FBVyxlQUFlLCtCQUErQixLQUNyRTs7Ozs7S0FDSzs7Ozs7SUFDTDs7OztZQUNGOzs7Ozs7R0FHTCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmO0tBRUUsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUEyRDtPQUVyRTs7OztpQkFDTix3QkFBQyxXQUFELEVBQVcsV0FBVSx5QkFBMEI7Ozs7ZUFDNUM7Ozs7O2dCQUNMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQ2IsbUJBQW1CLFNBQVM7T0FDekI7Ozs7aUJBQ04sd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQTZCO09BQWU7Ozs7ZUFDekQ7Ozs7O2NBQ0Y7Ozs7OztLQUdMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBMkQ7T0FFckU7Ozs7aUJBQ04sd0JBQUMsWUFBRCxFQUFZLFdBQVUsdUJBQXdCOzs7O2VBQzNDOzs7OztnQkFDTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUNiLGNBQWMsUUFBUSxNQUFNLEVBQUUsV0FBVyxZQUFZLENBQUMsQ0FBQztPQUNwRDs7OztpQkFDTix3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBNkI7T0FBa0I7Ozs7ZUFDNUQ7Ozs7O2NBQ0Y7Ozs7OztLQUdMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBMkQ7T0FFckU7Ozs7aUJBQ04sd0JBQUMsT0FBRCxFQUFPLFdBQVUsMEJBQTJCOzs7O2VBQ3pDOzs7OztnQkFDTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUNiLGNBQWMsUUFBUSxNQUFNLEVBQUUsV0FBVyxxQkFBcUIsQ0FBQyxDQUFDO09BQzdEOzs7O2lCQUNOLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUE2QjtPQUFjOzs7O2VBQ3hEOzs7OztjQUNGOzs7Ozs7S0FHTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQTJEO09BRXJFOzs7O2lCQUNOLHdCQUFDLE9BQUQsRUFBTyxXQUFVLGlEQUFrRDs7OztlQUNoRTs7Ozs7Z0JBQ0wsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFDYixhQUFhLFNBQVM7T0FDbkI7Ozs7aUJBQ04sd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQTZCO09BQWU7Ozs7ZUFDekQ7Ozs7O2NBQ0Y7Ozs7OztJQUNGOzs7Ozs7R0FHTCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmO0tBRUUsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQ2Isd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWY7UUFDRSx3QkFBQyxVQUFEO1NBQ0UsTUFBSztTQUNMLGVBQWUsWUFBWSxlQUFlO1NBQzFDLFdBQVcsbUdBQ1QsYUFBYSxrQkFDVCxxREFDQTttQkFOUixDQVNFLHdCQUFDLFdBQUQsRUFBVyxXQUFVLGNBQWU7Ozs7bUJBQ3BDLHdCQUFDLFFBQUQsWUFBTSwrQkFBa0M7Ozs7aUJBQ2xDOzs7Ozs7UUFFUix3QkFBQyxVQUFEO1NBQ0UsTUFBSztTQUNMLGVBQWUsWUFBWSxPQUFPO1NBQ2xDLFdBQVcseUVBQ1QsYUFBYSxVQUNULHFEQUNBO21CQUVQO1FBRU87Ozs7O1FBRVIsd0JBQUMsVUFBRDtTQUNFLE1BQUs7U0FDTCxlQUFlLFlBQVksWUFBWTtTQUN2QyxXQUFXLHlFQUNULGFBQWEsZUFDVCxxREFDQTttQkFFUDtRQUVPOzs7OztRQUVSLHdCQUFDLFVBQUQ7U0FDRSxNQUFLO1NBQ0wsZUFBZSxZQUFZLHFCQUFxQjtTQUNoRCxXQUFXLHlFQUNULGFBQWEsd0JBQ1QscURBQ0E7bUJBRVA7UUFFTzs7Ozs7UUFFUix3QkFBQyxVQUFEO1NBQ0UsTUFBSztTQUNMLGVBQWUsWUFBWSxXQUFXO1NBQ3RDLFdBQVcseUVBQ1QsYUFBYSxjQUNULHFEQUNBO21CQUVQO1FBRU87Ozs7O1FBRVIsd0JBQUMsVUFBRDtTQUNFLE1BQUs7U0FDTCxlQUFlLFlBQVksYUFBYTtTQUN4QyxXQUFXLHlFQUNULGFBQWEsZ0JBQ1QscURBQ0E7bUJBRVA7UUFFTzs7Ozs7T0FDTDs7Ozs7O0tBQ0Y7Ozs7O0tBR0wsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLFFBQUQsRUFBUSxXQUFVLGlEQUFrRDs7OztpQkFDcEUsd0JBQUMsU0FBRDtRQUNFLE1BQUs7UUFDTCxhQUFZO1FBQ1osT0FBTztRQUNQLFdBQVcsTUFBTSxTQUFTLEVBQUUsT0FBTyxLQUFLO1FBQ3hDLFdBQVU7T0FDWDs7OztlQUNFOzs7OztnQkFFTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLFFBQUQsRUFBUSxXQUFVLDZCQUE4Qjs7OztpQkFDaEQsd0JBQUMsVUFBRDtRQUNFLE9BQU87UUFDUCxXQUFXLE1BQU0sY0FBYyxFQUFFLE9BQU8sS0FBWTtRQUNwRCxXQUFVO2tCQUhaO1NBS0Usd0JBQUMsVUFBRDtVQUFRLE9BQU07b0JBQUc7U0FBc0I7Ozs7O1NBQ3ZDLHdCQUFDLFVBQUQ7VUFBUSxPQUFNO29CQUFvQjtTQUF5Qjs7Ozs7U0FDM0Qsd0JBQUMsVUFBRDtVQUFRLE9BQU07b0JBQVk7U0FBaUI7Ozs7O1FBQ3JDOzs7OztlQUNMOzs7OztjQUNGOzs7Ozs7S0FHSixZQUNDLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsT0FBRCxFQUFLLFdBQVUsdUZBQXdGOzs7O2dCQUN2Ryx3QkFBQyxRQUFELFlBQU0sNENBQStDOzs7O2NBQ2xEOzs7OztnQkFDSCx1QkFBdUIsV0FBVyxJQUNwQyx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZjtPQUNFLHdCQUFDLFdBQUQsRUFBVyxXQUFVLHVEQUF3RDs7Ozs7T0FDN0Usd0JBQUMsS0FBRDtRQUFHLFdBQVU7a0JBQTJEO09BRXJFOzs7OztPQUNILHdCQUFDLEtBQUQ7UUFBRyxXQUFVO2tCQUE4QztPQUV4RDs7Ozs7TUFDQTs7Ozs7Z0JBRUwsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQ2Isd0JBQUMsU0FBRDtPQUFPLFdBQVU7aUJBQWpCLENBQ0Usd0JBQUMsU0FBRDtRQUFPLFdBQVU7a0JBQ2Ysd0JBQUMsTUFBRDtTQUNFLHdCQUFDLE1BQUQ7VUFBSSxXQUFVO29CQUFjO1NBQWE7Ozs7O1NBQ3pDLHdCQUFDLE1BQUQ7VUFBSSxXQUFVO29CQUFjO1NBQVE7Ozs7O1NBQ3BDLHdCQUFDLE1BQUQ7VUFBSSxXQUFVO29CQUFjO1NBQWdDOzs7OztTQUM1RCx3QkFBQyxNQUFEO1VBQUksV0FBVTtvQkFBYztTQUFrQjs7Ozs7U0FDOUMsd0JBQUMsTUFBRDtVQUFJLFdBQVU7b0JBQWM7U0FBVTs7Ozs7U0FDdEMsd0JBQUMsTUFBRDtVQUFJLFdBQVU7b0JBQXlCO1NBQVE7Ozs7O1FBQzdDOzs7OztPQUNDOzs7O2lCQUNQLHdCQUFDLFNBQUQ7UUFBTyxXQUFVO2tCQUNkLHVCQUF1QixLQUFLLFNBQVM7U0FDcEMsTUFBTSxjQUNKLEtBQUssa0JBQWtCLGdCQUFnQjtTQUN6QyxNQUFNLFVBQVUsS0FBSyxrQkFBa0IsWUFBWTtTQUVuRCxPQUNFLHdCQUFDLE1BQUQ7VUFFRSxXQUFVO29CQUZaO1dBS0Usd0JBQUMsTUFBRDtZQUFJLFdBQVU7c0JBQ1osd0JBQUMsT0FBRDthQUFLLFdBQVU7dUJBQWYsQ0FDRSx3QkFBQyxRQUFEO2NBQU0sV0FBVTt3QkFDYixLQUFLO2FBQ0Y7Ozs7dUJBQ04sd0JBQUMsUUFBRDtjQUFNLFdBQVU7d0JBQWhCLENBQTZDLFlBQ2xDLEtBQUssa0JBQ1Y7Ozs7O3FCQUNIOzs7Ozs7V0FDSDs7Ozs7V0FHSix3QkFBQyxNQUFEO1lBQUksV0FBVTtzQkFDWix3QkFBQyxRQUFEO2FBQU0sV0FBVTt1QkFDYixLQUFLLHFCQUFxQixzQkFDdkIsc0JBQ0E7WUFDQTs7Ozs7V0FDSjs7Ozs7V0FHSix3QkFBQyxNQUFEO1lBQUksV0FBVTtzQkFDWix3QkFBQyxPQUFEO2FBQUssV0FBVTt1QkFBZixDQUNFLHdCQUFDLFFBQUQ7Y0FBTSxXQUFVO3dCQUNiO2FBQ0c7Ozs7dUJBQ04sd0JBQUMsUUFBRDtjQUFNLFdBQVU7d0JBQ2I7YUFDRzs7OztxQkFDSDs7Ozs7O1dBQ0g7Ozs7O1dBR0osd0JBQUMsTUFBRDtZQUFJLFdBQVU7c0JBQ1gsSUFBSSxLQUFLLEtBQUssY0FBYyxDQUFDLENBQUMsbUJBQW1CLFNBQVM7YUFDekQsS0FBSzthQUNMLE9BQU87YUFDUCxNQUFNO2FBQ04sTUFBTTthQUNOLFFBQVE7WUFDVixDQUFDO1dBQ0M7Ozs7O1dBR0osd0JBQUMsTUFBRDtZQUFJLFdBQVU7c0JBQ1osd0JBQUMseUJBQUQsRUFBeUIsUUFBUSxLQUFLLE9BQVM7Ozs7O1dBQzdDOzs7OztXQUdKLHdCQUFDLE1BQUQ7WUFBSSxXQUFVO3NCQUNaLHdCQUFDLE1BQUQ7YUFDRSxJQUFJLE9BQU8sY0FBYyxRQUFRLEtBQUssRUFBRTthQUN4QyxXQUFVO3VCQUZaLENBSUUsd0JBQUMsWUFBRCxFQUFZLFdBQVUsY0FBZTs7Ozt1QkFDckMsd0JBQUMsUUFBRCxZQUFNLG9CQUF1Qjs7OztxQkFDekI7Ozs7OztXQUNKOzs7OztVQUNGO1lBOURHLEtBQUs7Ozs7Z0JBOERSO1FBRVIsQ0FBQztPQUNJOzs7O2VBQ0Y7Ozs7OztLQUNKOzs7OztJQUVKOzs7Ozs7RUFDRjs7Ozs7O0FBRVQ7Ozs7Ozs7OztBQUVBLGVBQWUiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiUmVxdWVyaW1lbnRvc0xpc3RQYWdlLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyIvKipcclxuICogRmlsYSBkZSBMaWNlbmNpYW1lbnRvIFNhbml0w6FyaW8gZSBSZXF1ZXJpbWVudG9zIGRlIEFsdmFyw6FcclxuICogUm90YTogL2xpY2VuY2lhbWVudG8gb3UgL2xpY2VuY2lhbWVudG8vcmVxdWVyaW1lbnRvc1xyXG4gKiBBcHJlc2VudGEgYSBmaWxhIGRlIHRyYWJhbGhvIGRlIHByb2Nlc3NvcyBkZSBsaWNlbmNpYW1lbnRvLCB0cmlhZ2VtIGUgZGVjaXPDtWVzIGZpc2NhaXMuXHJcbiAqL1xyXG5cclxuaW1wb3J0IFJlYWN0LCB7IHVzZU1lbW8sIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7IExpbmssIHVzZU5hdmlnYXRlIH0gZnJvbSBcInJlYWN0LXJvdXRlci1kb21cIjtcclxuaW1wb3J0IHtcclxuICBBbGVydENpcmNsZSxcclxuICBBd2FyZCxcclxuICBCdWlsZGluZzIsXHJcbiAgQ2FsZW5kYXIsXHJcbiAgQ2hlY2tDaXJjbGUyLFxyXG4gIENsb2NrLFxyXG4gIEV4dGVybmFsTGluayxcclxuICBGaWxlQ2hlY2ssXHJcbiAgRmlsZVNlYXJjaCxcclxuICBGaWx0ZXIsXHJcbiAgSG91cmdsYXNzLFxyXG4gIFBsdXMsXHJcbiAgUmVmcmVzaEN3LFxyXG4gIFNlYXJjaCxcclxuICBTaGllbGQsXHJcbn0gZnJvbSBcImx1Y2lkZS1yZWFjdFwiO1xyXG5pbXBvcnQgeyBST1VURVMgfSBmcm9tIFwiLi4vLi4vY29uZmlnL3JvdXRlcy5jb25maWdcIjtcclxuaW1wb3J0IHsgdXNlQWx2YXJhc0xpc3QsIHVzZVJlcXVlcmltZW50b3NMaXN0IH0gZnJvbSBcIi4uLy4uL2hvb2tzL3VzZUxpY2VuY2lhbWVudG9cIjtcclxuaW1wb3J0IHsgU3RhdHVzUmVxdWVyaW1lbnRvLCBUaXBvU29saWNpdGFjYW9BbHZhcmEgfSBmcm9tIFwiLi4vLi4vdHlwZXMvbGljZW5jaWFtZW50b1wiO1xyXG5pbXBvcnQgeyBTdGF0dXNSZXF1ZXJpbWVudG9CYWRnZSB9IGZyb20gXCIuLi8uLi9jb21wb25lbnRzL2xpY2VuY2lhbWVudG8vU3RhdHVzUmVxdWVyaW1lbnRvQmFkZ2VcIjtcclxuXHJcbnR5cGUgVGFiRmlsYSA9XHJcbiAgfCBcImZpbGFfdHJhYmFsaG9cIlxyXG4gIHwgXCJ0b2Rvc1wiXHJcbiAgfCBcInBlbmRlbnRlc1wiXHJcbiAgfCBcImVtX2FuYWxpc2VcIlxyXG4gIHwgXCJhZ3VhcmRhbmRvX2luc3BlY2FvXCJcclxuICB8IFwiZGVmZXJpZG9zXCJcclxuICB8IFwiaW5kZWZlcmlkb3NcIjtcclxuXHJcbmV4cG9ydCBjb25zdCBSZXF1ZXJpbWVudG9zTGlzdFBhZ2U6IFJlYWN0LkZDID0gKCkgPT4ge1xyXG4gIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKTtcclxuICBjb25zdCBbdGFiQXRpdmEsIHNldFRhYkF0aXZhXSA9IHVzZVN0YXRlPFRhYkZpbGE+KFwiZmlsYV90cmFiYWxob1wiKTtcclxuICBjb25zdCBbYnVzY2EsIHNldEJ1c2NhXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFt0aXBvRmlsdHJvLCBzZXRUaXBvRmlsdHJvXSA9IHVzZVN0YXRlPFRpcG9Tb2xpY2l0YWNhb0FsdmFyYSB8IFwiXCI+KFwiXCIpO1xyXG5cclxuICAvLyBDb25zdWx0YSBkYSBsaXN0YSBjb20gZmlsdHJvcyBkbyBUYW5TdGFjayBRdWVyeSB2NVxyXG4gIGNvbnN0IHN0YXR1c1BhcmFtOiBTdGF0dXNSZXF1ZXJpbWVudG8gfCBcIlwiID1cclxuICAgIHRhYkF0aXZhID09PSBcInBlbmRlbnRlc1wiXHJcbiAgICAgID8gXCJwZW5kZW50ZVwiXHJcbiAgICAgIDogdGFiQXRpdmEgPT09IFwiZW1fYW5hbGlzZVwiXHJcbiAgICAgID8gXCJlbV9hbmFsaXNlXCJcclxuICAgICAgOiB0YWJBdGl2YSA9PT0gXCJhZ3VhcmRhbmRvX2luc3BlY2FvXCJcclxuICAgICAgPyBcImFndWFyZGFuZG9faW5zcGVjYW9cIlxyXG4gICAgICA6IHRhYkF0aXZhID09PSBcImRlZmVyaWRvc1wiXHJcbiAgICAgID8gXCJkZWZlcmlkb1wiXHJcbiAgICAgIDogdGFiQXRpdmEgPT09IFwiaW5kZWZlcmlkb3NcIlxyXG4gICAgICA/IFwiaW5kZWZlcmlkb1wiXHJcbiAgICAgIDogXCJcIjtcclxuXHJcbiAgY29uc3Qge1xyXG4gICAgZGF0YTogcmVxdWVyaW1lbnRvc0RhdGEsXHJcbiAgICBpc0xvYWRpbmcsXHJcbiAgICBpc1JlZmV0Y2hpbmcsXHJcbiAgICByZWZldGNoLFxyXG4gIH0gPSB1c2VSZXF1ZXJpbWVudG9zTGlzdCh7XHJcbiAgICBhcGVuYXNfZmlsYTogdGFiQXRpdmEgPT09IFwiZmlsYV90cmFiYWxob1wiID8gdHJ1ZSA6IHVuZGVmaW5lZCxcclxuICAgIHN0YXR1czogc3RhdHVzUGFyYW0gfHwgdW5kZWZpbmVkLFxyXG4gICAgbGltaXQ6IDEwMCxcclxuICB9KTtcclxuXHJcbiAgY29uc3QgeyBkYXRhOiBhbHZhcmFzRGF0YSB9ID0gdXNlQWx2YXJhc0xpc3QoeyBsaW1pdDogMSB9KTtcclxuXHJcbiAgY29uc3QgcmVxdWVyaW1lbnRvcyA9XHJcbiAgICByZXF1ZXJpbWVudG9zRGF0YT8uaXRlbXMgfHxcclxuICAgIChyZXF1ZXJpbWVudG9zRGF0YSBhcyB7IGl0ZW5zPzogdHlwZW9mIHJlcXVlcmltZW50b3NEYXRhIGV4dGVuZHMgeyBpdGVtczogaW5mZXIgVCB9ID8gVCA6IG5ldmVyIH0gfCB1bmRlZmluZWQpPy5pdGVucyB8fFxyXG4gICAgW107XHJcblxyXG4gIC8vIEZpbHRyYWdlbSBsb2NhbCBjb21wbGVtZW50YXIgcG9yIHRleHRvIChwcm90b2NvbG8sIHJhesOjbyBzb2NpYWwgZGVjbGFyYWRhIG91IENOUEopXHJcbiAgY29uc3QgcmVxdWVyaW1lbnRvc0ZpbHRyYWRvcyA9IHVzZU1lbW8oKCkgPT4ge1xyXG4gICAgcmV0dXJuIHJlcXVlcmltZW50b3MuZmlsdGVyKChpdGVtKSA9PiB7XHJcbiAgICAgIGlmICh0aXBvRmlsdHJvICYmIGl0ZW0udGlwb19zb2xpY2l0YWNhbyAhPT0gdGlwb0ZpbHRybykge1xyXG4gICAgICAgIHJldHVybiBmYWxzZTtcclxuICAgICAgfVxyXG5cclxuICAgICAgaWYgKCFidXNjYS50cmltKCkpIHJldHVybiB0cnVlO1xyXG5cclxuICAgICAgY29uc3QgdGVybW8gPSBidXNjYS50b0xvd2VyQ2FzZSgpO1xyXG4gICAgICBjb25zdCBtYXRjaFByb3RvY29sbyA9IGl0ZW0ubnVtZXJvX3Byb3RvY29sby50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKHRlcm1vKTtcclxuICAgICAgY29uc3QgbWF0Y2hSYXphbyA9IGl0ZW0uZGFkb3NfZGVjbGFyYWRvcz8ucmF6YW9fc29jaWFsXHJcbiAgICAgICAgPy50b0xvd2VyQ2FzZSgpXHJcbiAgICAgICAgLmluY2x1ZGVzKHRlcm1vKTtcclxuICAgICAgY29uc3QgbWF0Y2hDbnBqID0gaXRlbS5kYWRvc19kZWNsYXJhZG9zPy5jcGZfY25walxyXG4gICAgICAgID8udG9Mb3dlckNhc2UoKVxyXG4gICAgICAgIC5pbmNsdWRlcyh0ZXJtbyk7XHJcblxyXG4gICAgICByZXR1cm4gbWF0Y2hQcm90b2NvbG8gfHwgbWF0Y2hSYXphbyB8fCBtYXRjaENucGo7XHJcbiAgICB9KTtcclxuICB9LCBbcmVxdWVyaW1lbnRvcywgYnVzY2EsIHRpcG9GaWx0cm9dKTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS02XCI+XHJcbiAgICAgIHsvKiBDYWJlw6dhbGhvIGRhIFDDoWdpbmEgKi99XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBtZDpmbGV4LXJvdyBtZDppdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC00IGJnLXdoaXRlIGRhcms6Ymctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLTJ4bCBwLTYgc2hhZG93LXhzXCI+XHJcbiAgICAgICAgPGRpdj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdGV4dC10ZWFsLTYwMCBkYXJrOnRleHQtdGVhbC00MDAgbWItMVwiPlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSBmb250LWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIGJnLXRlYWwtNTAgZGFyazpiZy10ZWFsLTk1MC80MCBweC0yIHB5LTAuNSByb3VuZGVkIGJvcmRlciBib3JkZXItdGVhbC0yMDAgZGFyazpib3JkZXItdGVhbC04MDBcIj5cclxuICAgICAgICAgICAgICBDZXJ0aWZpY2HDp8OjbyAmIEFsdmFyw6FzIFNhbml0w6FyaW9zXHJcbiAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1ib2xkIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICBMaWNlbmNpYW1lbnRvIFNhbml0w6FyaW8gTXVuaWNpcGFsXHJcbiAgICAgICAgICA8L2gxPlxyXG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTUwMCBkYXJrOnRleHQtc2xhdGUtNDAwIG10LTEgbWF4LXctMnhsXCI+XHJcbiAgICAgICAgICAgIEZpbGEgZGUgYW7DoWxpc2UgdMOpY25pY2EgZGUgcGV0acOnw7VlcywgY29uZmVyw6puY2lhIGRlIHZpc3RvcmlhcyBlIGhvbW9sb2dhw6fDo28gcGFyYSBleHBlZGnDp8OjbyBvZmljaWFsIGRlIEFsdmFyw6FzIFNhbml0w6FyaW9zLlxyXG4gICAgICAgICAgPC9wPlxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yLjVcIj5cclxuICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHJlZmV0Y2goKX1cclxuICAgICAgICAgICAgZGlzYWJsZWQ9e2lzUmVmZXRjaGluZ31cclxuICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0yIHRleHQtc2xhdGUtNTAwIGhvdmVyOnRleHQtc2xhdGUtODAwIGRhcms6aG92ZXI6dGV4dC1zbGF0ZS0yMDAgYmctd2hpdGUgZGFyazpiZy1zbGF0ZS04MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQteGwgdHJhbnNpdGlvbi1jb2xvcnMgc2hhZG93LTJ4c1wiXHJcbiAgICAgICAgICAgIHRpdGxlPVwiQXR1YWxpemFyIGxpc3RhXCJcclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgPFJlZnJlc2hDd1xyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT17YHctNCBoLTQgJHtpc1JlZmV0Y2hpbmcgPyBcImFuaW1hdGUtc3BpbiB0ZXh0LXRlYWwtNjAwXCIgOiBcIlwifWB9XHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICB7LyogQ2FyZHMgZGUgTcOpdHJpY2FzIE9wZXJhY2lvbmFpcyAqL31cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIHNtOmdyaWQtY29scy0yIGxnOmdyaWQtY29scy00IGdhcC00XCI+XHJcbiAgICAgICAgey8qIFRvdGFsIG5hIEZpbGEgQXRpdmEgKi99XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC14bCBwLTQgc2hhZG93LTJ4c1wiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNTAwIGRhcms6dGV4dC1zbGF0ZS00MDBcIj5cclxuICAgICAgICAgICAgICBGaWxhIGRlIFRyYWJhbGhvIEF0aXZhXHJcbiAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgPEhvdXJnbGFzcyBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtYW1iZXItNTAwXCIgLz5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0yIGZsZXggaXRlbXMtYmFzZWxpbmUgZ2FwLTJcIj5cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZVwiPlxyXG4gICAgICAgICAgICAgIHtyZXF1ZXJpbWVudG9zRGF0YT8udG90YWwgPz8gMH1cclxuICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LXNsYXRlLTQwMFwiPnByb2Nlc3Nvczwvc3Bhbj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICB7LyogRW0gQW7DoWxpc2UgKi99XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC14bCBwLTQgc2hhZG93LTJ4c1wiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNTAwIGRhcms6dGV4dC1zbGF0ZS00MDBcIj5cclxuICAgICAgICAgICAgICBBbsOhbGlzZSBEb2N1bWVudGFsXHJcbiAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgPEZpbGVTZWFyY2ggY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LXNreS01MDBcIiAvPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTIgZmxleCBpdGVtcy1iYXNlbGluZSBnYXAtMlwiPlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGQgdGV4dC1za3ktNjAwIGRhcms6dGV4dC1za3ktNDAwXCI+XHJcbiAgICAgICAgICAgICAge3JlcXVlcmltZW50b3MuZmlsdGVyKChyKSA9PiByLnN0YXR1cyA9PT0gXCJlbV9hbmFsaXNlXCIpLmxlbmd0aH1cclxuICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LXNsYXRlLTQwMFwiPmVtIGluc3RydcOnw6NvPC9zcGFuPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIHsvKiBBZ3VhcmRhbmRvIFZpc3RvcmlhICovfVxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGFyazpiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtODAwIHJvdW5kZWQteGwgcC00IHNoYWRvdy0yeHNcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTUwMCBkYXJrOnRleHQtc2xhdGUtNDAwXCI+XHJcbiAgICAgICAgICAgICAgQWd1YXJkYW5kbyBWaXN0b3JpYVxyXG4gICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgIDxDbG9jayBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtaW5kaWdvLTUwMFwiIC8+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMiBmbGV4IGl0ZW1zLWJhc2VsaW5lIGdhcC0yXCI+XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LWluZGlnby02MDAgZGFyazp0ZXh0LWluZGlnby00MDBcIj5cclxuICAgICAgICAgICAgICB7cmVxdWVyaW1lbnRvcy5maWx0ZXIoKHIpID0+IHIuc3RhdHVzID09PSBcImFndWFyZGFuZG9faW5zcGVjYW9cIikubGVuZ3RofVxyXG4gICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtc2xhdGUtNDAwXCI+ZGUgY2FtcG88L3NwYW4+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgey8qIEFsdmFyw6FzIEVtaXRpZG9zICovfVxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGFyazpiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtODAwIHJvdW5kZWQteGwgcC00IHNoYWRvdy0yeHNcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTUwMCBkYXJrOnRleHQtc2xhdGUtNDAwXCI+XHJcbiAgICAgICAgICAgICAgVG90YWwgQWx2YXLDoXMgRW1pdGlkb3NcclxuICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICA8QXdhcmQgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LWVtZXJhbGQtNjAwIGRhcms6dGV4dC1lbWVyYWxkLTQwMFwiIC8+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMiBmbGV4IGl0ZW1zLWJhc2VsaW5lIGdhcC0yXCI+XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LWVtZXJhbGQtNjAwIGRhcms6dGV4dC1lbWVyYWxkLTQwMFwiPlxyXG4gICAgICAgICAgICAgIHthbHZhcmFzRGF0YT8udG90YWwgPz8gMH1cclxuICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LXNsYXRlLTQwMFwiPmV4cGVkaWRvczwvc3Bhbj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIHsvKiBDYWl4YSBjb20gQWJhcyBlIExpc3RhIGRlIFJlcXVlcmltZW50b3MgKi99XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGFyazpiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtODAwIHJvdW5kZWQtMnhsIHNoYWRvdy14cyBvdmVyZmxvdy1oaWRkZW5cIj5cclxuICAgICAgICB7LyogQWJhcyAqL31cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJvcmRlci1iIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtODAwIHB4LTYgcHQtMyBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTQgb3ZlcmZsb3cteC1hdXRvXCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC02XCI+XHJcbiAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRUYWJBdGl2YShcImZpbGFfdHJhYmFsaG9cIil9XHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcGItMyB0ZXh0LXhzIGZvbnQtYm9sZCBib3JkZXItYi0yIHRyYW5zaXRpb24tY29sb3JzIHdoaXRlc3BhY2Utbm93cmFwIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgJHtcclxuICAgICAgICAgICAgICAgIHRhYkF0aXZhID09PSBcImZpbGFfdHJhYmFsaG9cIlxyXG4gICAgICAgICAgICAgICAgICA/IFwiYm9yZGVyLXRlYWwtNjAwIHRleHQtdGVhbC02MDAgZGFyazp0ZXh0LXRlYWwtNDAwXCJcclxuICAgICAgICAgICAgICAgICAgOiBcImJvcmRlci10cmFuc3BhcmVudCB0ZXh0LXNsYXRlLTUwMCBob3Zlcjp0ZXh0LXNsYXRlLTgwMCBkYXJrOmhvdmVyOnRleHQtc2xhdGUtMzAwXCJcclxuICAgICAgICAgICAgICB9YH1cclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIDxIb3VyZ2xhc3MgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPlxyXG4gICAgICAgICAgICAgIDxzcGFuPkZpbGEgZGUgVHJhYmFsaG8gKFBlbmRlbnRlcyk8L3NwYW4+XHJcbiAgICAgICAgICAgIDwvYnV0dG9uPlxyXG5cclxuICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFRhYkF0aXZhKFwidG9kb3NcIil9XHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcGItMyB0ZXh0LXhzIGZvbnQtYm9sZCBib3JkZXItYi0yIHRyYW5zaXRpb24tY29sb3JzIHdoaXRlc3BhY2Utbm93cmFwICR7XHJcbiAgICAgICAgICAgICAgICB0YWJBdGl2YSA9PT0gXCJ0b2Rvc1wiXHJcbiAgICAgICAgICAgICAgICAgID8gXCJib3JkZXItdGVhbC02MDAgdGV4dC10ZWFsLTYwMCBkYXJrOnRleHQtdGVhbC00MDBcIlxyXG4gICAgICAgICAgICAgICAgICA6IFwiYm9yZGVyLXRyYW5zcGFyZW50IHRleHQtc2xhdGUtNTAwIGhvdmVyOnRleHQtc2xhdGUtODAwIGRhcms6aG92ZXI6dGV4dC1zbGF0ZS0zMDBcIlxyXG4gICAgICAgICAgICAgIH1gfVxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgVG9kb3Mgb3MgUHJvY2Vzc29zXHJcbiAgICAgICAgICAgIDwvYnV0dG9uPlxyXG5cclxuICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFRhYkF0aXZhKFwiZW1fYW5hbGlzZVwiKX1cclxuICAgICAgICAgICAgICBjbGFzc05hbWU9e2BwYi0zIHRleHQteHMgZm9udC1ib2xkIGJvcmRlci1iLTIgdHJhbnNpdGlvbi1jb2xvcnMgd2hpdGVzcGFjZS1ub3dyYXAgJHtcclxuICAgICAgICAgICAgICAgIHRhYkF0aXZhID09PSBcImVtX2FuYWxpc2VcIlxyXG4gICAgICAgICAgICAgICAgICA/IFwiYm9yZGVyLXRlYWwtNjAwIHRleHQtdGVhbC02MDAgZGFyazp0ZXh0LXRlYWwtNDAwXCJcclxuICAgICAgICAgICAgICAgICAgOiBcImJvcmRlci10cmFuc3BhcmVudCB0ZXh0LXNsYXRlLTUwMCBob3Zlcjp0ZXh0LXNsYXRlLTgwMCBkYXJrOmhvdmVyOnRleHQtc2xhdGUtMzAwXCJcclxuICAgICAgICAgICAgICB9YH1cclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIEVtIEFuw6FsaXNlIERvY3VtZW50YWxcclxuICAgICAgICAgICAgPC9idXR0b24+XHJcblxyXG4gICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0VGFiQXRpdmEoXCJhZ3VhcmRhbmRvX2luc3BlY2FvXCIpfVxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT17YHBiLTMgdGV4dC14cyBmb250LWJvbGQgYm9yZGVyLWItMiB0cmFuc2l0aW9uLWNvbG9ycyB3aGl0ZXNwYWNlLW5vd3JhcCAke1xyXG4gICAgICAgICAgICAgICAgdGFiQXRpdmEgPT09IFwiYWd1YXJkYW5kb19pbnNwZWNhb1wiXHJcbiAgICAgICAgICAgICAgICAgID8gXCJib3JkZXItdGVhbC02MDAgdGV4dC10ZWFsLTYwMCBkYXJrOnRleHQtdGVhbC00MDBcIlxyXG4gICAgICAgICAgICAgICAgICA6IFwiYm9yZGVyLXRyYW5zcGFyZW50IHRleHQtc2xhdGUtNTAwIGhvdmVyOnRleHQtc2xhdGUtODAwIGRhcms6aG92ZXI6dGV4dC1zbGF0ZS0zMDBcIlxyXG4gICAgICAgICAgICAgIH1gfVxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgQWd1YXJkYW5kbyBWaXN0b3JpYVxyXG4gICAgICAgICAgICA8L2J1dHRvbj5cclxuXHJcbiAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRUYWJBdGl2YShcImRlZmVyaWRvc1wiKX1cclxuICAgICAgICAgICAgICBjbGFzc05hbWU9e2BwYi0zIHRleHQteHMgZm9udC1ib2xkIGJvcmRlci1iLTIgdHJhbnNpdGlvbi1jb2xvcnMgd2hpdGVzcGFjZS1ub3dyYXAgJHtcclxuICAgICAgICAgICAgICAgIHRhYkF0aXZhID09PSBcImRlZmVyaWRvc1wiXHJcbiAgICAgICAgICAgICAgICAgID8gXCJib3JkZXItdGVhbC02MDAgdGV4dC10ZWFsLTYwMCBkYXJrOnRleHQtdGVhbC00MDBcIlxyXG4gICAgICAgICAgICAgICAgICA6IFwiYm9yZGVyLXRyYW5zcGFyZW50IHRleHQtc2xhdGUtNTAwIGhvdmVyOnRleHQtc2xhdGUtODAwIGRhcms6aG92ZXI6dGV4dC1zbGF0ZS0zMDBcIlxyXG4gICAgICAgICAgICAgIH1gfVxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgRGVmZXJpZG9zIC8gRW1pdGlkb3NcclxuICAgICAgICAgICAgPC9idXR0b24+XHJcblxyXG4gICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0VGFiQXRpdmEoXCJpbmRlZmVyaWRvc1wiKX1cclxuICAgICAgICAgICAgICBjbGFzc05hbWU9e2BwYi0zIHRleHQteHMgZm9udC1ib2xkIGJvcmRlci1iLTIgdHJhbnNpdGlvbi1jb2xvcnMgd2hpdGVzcGFjZS1ub3dyYXAgJHtcclxuICAgICAgICAgICAgICAgIHRhYkF0aXZhID09PSBcImluZGVmZXJpZG9zXCJcclxuICAgICAgICAgICAgICAgICAgPyBcImJvcmRlci10ZWFsLTYwMCB0ZXh0LXRlYWwtNjAwIGRhcms6dGV4dC10ZWFsLTQwMFwiXHJcbiAgICAgICAgICAgICAgICAgIDogXCJib3JkZXItdHJhbnNwYXJlbnQgdGV4dC1zbGF0ZS01MDAgaG92ZXI6dGV4dC1zbGF0ZS04MDAgZGFyazpob3Zlcjp0ZXh0LXNsYXRlLTMwMFwiXHJcbiAgICAgICAgICAgICAgfWB9XHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICBJbmRlZmVyaWRvc1xyXG4gICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICB7LyogQmFycmEgZGUgRmlsdHJvcyAqL31cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNCBiZy1zbGF0ZS01MC81MCBkYXJrOmJnLXNsYXRlLTgwMC80MCBib3JkZXItYiBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCBmbGV4IGZsZXgtY29sIHNtOmZsZXgtcm93IHNtOml0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTNcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgZmxleC0xIG1heC13LW1kXCI+XHJcbiAgICAgICAgICAgIDxTZWFyY2ggY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LXNsYXRlLTQwMCBhYnNvbHV0ZSBsZWZ0LTMgdG9wLTIuNVwiIC8+XHJcbiAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkJ1c2NhciBwb3IgcHJvdG9jb2xvIChleDogUkVRLTIwMjYpLCBlbXByZXNhIG91IENOUEouLi5cIlxyXG4gICAgICAgICAgICAgIHZhbHVlPXtidXNjYX1cclxuICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEJ1c2NhKGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcGwtOSBwci00IHB5LTIgdGV4dC14cyBiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC14bCB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGUgcGxhY2Vob2xkZXItc2xhdGUtNDAwIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy10ZWFsLTUwMFwiXHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgIDxGaWx0ZXIgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjUgdGV4dC1zbGF0ZS00MDBcIiAvPlxyXG4gICAgICAgICAgICA8c2VsZWN0XHJcbiAgICAgICAgICAgICAgdmFsdWU9e3RpcG9GaWx0cm99XHJcbiAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRUaXBvRmlsdHJvKGUudGFyZ2V0LnZhbHVlIGFzIGFueSl9XHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtMyBweS0xLjUgdGV4dC14cyBiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC14bCB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMjAwIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy10ZWFsLTUwMFwiXHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiXCI+VG9kb3Mgb3MgVGlwb3M8L29wdGlvbj5cclxuICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiY29uY2Vzc2FvX2luaWNpYWxcIj5Db25jZXNzw6NvIEluaWNpYWw8L29wdGlvbj5cclxuICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwicmVub3ZhY2FvXCI+UmVub3Zhw6fDo288L29wdGlvbj5cclxuICAgICAgICAgICAgPC9zZWxlY3Q+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgey8qIFRhYmVsYSBkZSBSZXF1ZXJpbWVudG9zICovfVxyXG4gICAgICAgIHtpc0xvYWRpbmcgPyAoXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMTYgdGV4dC1jZW50ZXIgdGV4dC1zbGF0ZS00MDAgdGV4dC14cyBmbGV4IGZsZXgtY29sIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlclwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctNiBoLTYgYm9yZGVyLTIgYm9yZGVyLXRlYWwtNTAwIGJvcmRlci10LXRyYW5zcGFyZW50IHJvdW5kZWQtZnVsbCBhbmltYXRlLXNwaW4gbWItM1wiIC8+XHJcbiAgICAgICAgICAgIDxzcGFuPkNvbnN1bHRhbmRvIHByb2Nlc3NvcyBkZSBsaWNlbmNpYW1lbnRvLi4uPC9zcGFuPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgKSA6IHJlcXVlcmltZW50b3NGaWx0cmFkb3MubGVuZ3RoID09PSAwID8gKFxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTEyIHRleHQtY2VudGVyIHRleHQtc2xhdGUtNTAwIGRhcms6dGV4dC1zbGF0ZS00MDAgc3BhY2UteS0zXCI+XHJcbiAgICAgICAgICAgIDxGaWxlQ2hlY2sgY2xhc3NOYW1lPVwidy0xMCBoLTEwIHRleHQtc2xhdGUtMzAwIGRhcms6dGV4dC1zbGF0ZS03MDAgbXgtYXV0b1wiIC8+XHJcbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMzAwXCI+XHJcbiAgICAgICAgICAgICAgTmVuaHVtIHByb2Nlc3NvIGRlIHJlcXVlcmltZW50byBlbmNvbnRyYWRvIHBhcmEgb3MgY3JpdMOpcmlvcyBzZWxlY2lvbmFkb3MuXHJcbiAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1zbGF0ZS00MDAgbWF4LXctc20gbXgtYXV0b1wiPlxyXG4gICAgICAgICAgICAgIE5vdmFzIHBldGnDp8O1ZXMgc3VibWV0aWRhcyB2aWEgZm9ybXVsw6FyaW8gZWxldHLDtG5pY28gb3UgYmFsY8OjbyBkZSBhdGVuZGltZW50byBjb25zdGFyw6NvIG5lc3RhIGZpbGEgZGUgdHJhYmFsaG8uXHJcbiAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICkgOiAoXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm92ZXJmbG93LXgtYXV0b1wiPlxyXG4gICAgICAgICAgICA8dGFibGUgY2xhc3NOYW1lPVwidy1mdWxsIHRleHQtbGVmdCB0ZXh0LXhzIGJvcmRlci1jb2xsYXBzZVwiPlxyXG4gICAgICAgICAgICAgIDx0aGVhZCBjbGFzc05hbWU9XCJiZy1zbGF0ZS01MC84MCBkYXJrOmJnLXNsYXRlLTgwMC82MCBib3JkZXItYiBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCB0ZXh0LXNsYXRlLTUwMCBkYXJrOnRleHQtc2xhdGUtNDAwIGZvbnQtc2VtaWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCI+XHJcbiAgICAgICAgICAgICAgICA8dHI+XHJcbiAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0zLjUgcHgtNFwiPlByb3RvY29sbzwvdGg+XHJcbiAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0zLjUgcHgtNFwiPlRpcG88L3RoPlxyXG4gICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMy41IHB4LTRcIj5Fc3RhYmVsZWNpbWVudG8gLyBSZXF1ZXJlbnRlPC90aD5cclxuICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB5LTMuNSBweC00XCI+RGF0YSBTdWJtaXNzw6NvPC90aD5cclxuICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB5LTMuNSBweC00XCI+U3RhdHVzPC90aD5cclxuICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB5LTMuNSBweC00IHRleHQtcmlnaHRcIj5Bw6fDo288L3RoPlxyXG4gICAgICAgICAgICAgICAgPC90cj5cclxuICAgICAgICAgICAgICA8L3RoZWFkPlxyXG4gICAgICAgICAgICAgIDx0Ym9keSBjbGFzc05hbWU9XCJkaXZpZGUteSBkaXZpZGUtc2xhdGUtMTAwIGRhcms6ZGl2aWRlLXNsYXRlLTgwMFwiPlxyXG4gICAgICAgICAgICAgICAge3JlcXVlcmltZW50b3NGaWx0cmFkb3MubWFwKChpdGVtKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgIGNvbnN0IHJhemFvU29jaWFsID1cclxuICAgICAgICAgICAgICAgICAgICBpdGVtLmRhZG9zX2RlY2xhcmFkb3M/LnJhemFvX3NvY2lhbCB8fCBcIlJhesOjbyBTb2NpYWwgRGVjbGFyYWRhXCI7XHJcbiAgICAgICAgICAgICAgICAgIGNvbnN0IGNucGpDcGYgPSBpdGVtLmRhZG9zX2RlY2xhcmFkb3M/LmNwZl9jbnBqIHx8IFwiLS0tXCI7XHJcblxyXG4gICAgICAgICAgICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgICAgICAgICAgIDx0clxyXG4gICAgICAgICAgICAgICAgICAgICAga2V5PXtpdGVtLmlkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaG92ZXI6Ymctc2xhdGUtNTAvNjAgZGFyazpob3ZlcjpiZy1zbGF0ZS04MDAvNDAgdHJhbnNpdGlvbi1jb2xvcnNcIlxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIHsvKiBQcm90b2NvbG8gKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMy41IHB4LTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tb25vIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpdGVtLm51bWVyb19wcm90b2NvbG99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtc2xhdGUtNDAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBPcmlnZW06IHtpdGVtLm9yaWdlbV9zb2xpY2l0YWNhb31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC90ZD5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICB7LyogVGlwbyAqL31cclxuICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS0zLjUgcHgtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJjYXBpdGFsaXplIGZvbnQtbWVkaXVtIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0zMDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7aXRlbS50aXBvX3NvbGljaXRhY2FvID09PSBcImNvbmNlc3Nhb19pbmljaWFsXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gXCJDb25jZXNzw6NvIEluaWNpYWxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBcIlJlbm92YcOnw6NvIEFudWFsXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgey8qIEVzdGFiZWxlY2ltZW50byAqL31cclxuICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS0zLjUgcHgtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2xcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1zbGF0ZS04MDAgZGFyazp0ZXh0LXNsYXRlLTIwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge3JhemFvU29jaWFsfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSBmb250LW1vbm8gdGV4dC1zbGF0ZS00MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtjbnBqQ3BmfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgIHsvKiBEYXRhICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTMuNSBweC00IHRleHQtc2xhdGUtNjAwIGRhcms6dGV4dC1zbGF0ZS0zMDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAge25ldyBEYXRlKGl0ZW0uZGF0YV9zdWJtaXNzYW8pLnRvTG9jYWxlRGF0ZVN0cmluZyhcInB0LUJSXCIsIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBkYXk6IFwiMi1kaWdpdFwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG1vbnRoOiBcIjItZGlnaXRcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB5ZWFyOiBcIm51bWVyaWNcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBob3VyOiBcIjItZGlnaXRcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBtaW51dGU6IFwiMi1kaWdpdFwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9KX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgey8qIFN0YXR1cyAqL31cclxuICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS0zLjUgcHgtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8U3RhdHVzUmVxdWVyaW1lbnRvQmFkZ2Ugc3RhdHVzPXtpdGVtLnN0YXR1c30gLz5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgey8qIEHDp8O1ZXMgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMy41IHB4LTQgdGV4dC1yaWdodFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8TGlua1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHRvPXtST1VURVMuTElDRU5DSUFNRU5UTy5ERVRBTEhFKGl0ZW0uaWQpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTMgcHktMS41IHRleHQteHMgZm9udC1ib2xkIHRleHQtdGVhbC03MDAgZGFyazp0ZXh0LXRlYWwtMzAwIGJnLXRlYWwtNTAgZGFyazpiZy10ZWFsLTk1MC80MCBib3JkZXIgYm9yZGVyLXRlYWwtMjAwIGRhcms6Ym9yZGVyLXRlYWwtODAwIHJvdW5kZWQtbGcgaG92ZXI6YmctdGVhbC0xMDAvNjAgc2hhZG93LTJ4cyB0cmFuc2l0aW9uLWNvbG9ycyBpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8RmlsZVNlYXJjaCBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNVwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+QW5hbGlzYXIgUHJvY2Vzc288L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgPC90cj5cclxuICAgICAgICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgICAgIH0pfVxyXG4gICAgICAgICAgICAgIDwvdGJvZHk+XHJcbiAgICAgICAgICAgIDwvdGFibGU+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICApfVxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBSZXF1ZXJpbWVudG9zTGlzdFBhZ2U7XHJcbiJdfQ==