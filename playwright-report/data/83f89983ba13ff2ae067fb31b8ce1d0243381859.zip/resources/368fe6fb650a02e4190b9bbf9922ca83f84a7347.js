import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/fiscalizacao/AgendarInspecaoModal.tsx");const React = __vite__cjsImport0_react; const useEffect = __vite__cjsImport0_react["useEffect"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport8_react_jsxDevRuntime["jsxDEV"];/**
* Modal de Agendamento e Abertura de Termo de Inspeção Sanitária
* Validação condicional Zod (regras VAPT - Indicador 11).
*/
import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=0fd2848a";
import { useForm } from "/node_modules/.vite/deps/react-hook-form.js?v=0fd2848a";
import { zodResolver } from "/node_modules/.vite/deps/@hookform_resolvers_zod.js?v=0fd2848a";
import * as z from "/node_modules/.vite/deps/zod.js?v=0fd2848a";
import { AlertTriangle, Building2, Calendar, Clock, HardHat, Search, UserCheck, X } from "/node_modules/.vite/deps/lucide-react.js?v=0fd2848a";
import { useAgendarInspecaoMutation } from "/src/hooks/useFiscalizacao.ts";
import { useEstabelecimentosList } from "/src/hooks/useEstabelecimentos.ts";
import { useAuth } from "/src/contexts/AuthContext.tsx";
var _jsxFileName = "E:/Projetos VSCODE/visa_braunas/src/components/fiscalizacao/AgendarInspecaoModal.tsx";
import __vite__cjsImport8_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=0fd2848a";
var _s = $RefreshSig$();
const MOTIVOS_LABELS = {
	rotina_programada: "Rotina Programada",
	requerimento_alvara: "Requerimento de Alvará",
	denuncia: "Atendimento a Denúncia",
	reinspecao: "Reinspeção Fiscal (Retorno)",
	vapt_trabalhador: "VAPT - Saúde do Trabalhador (Indicador 11)",
	investigacao_surto: "Investigação de Surto / DTA"
};
const agendarInspecaoSchema = z.object({
	numero_termo: z.string().min(3, "Número do termo deve ter no mínimo 3 caracteres"),
	estabelecimento_id: z.string().uuid("Selecione um estabelecimento válido"),
	fiscal_responsavel_id: z.string().uuid("Fiscal responsável é obrigatório"),
	motivo: z.enum([
		"rotina_programada",
		"requerimento_alvara",
		"denuncia",
		"reinspecao",
		"vapt_trabalhador",
		"investigacao_surto"
	]),
	data_inicio: z.string().min(10, "Data de início/abertura é obrigatória"),
	data_agendamento: z.string().optional(),
	hora_inspecao: z.string().optional(),
	fiscais_acompanhantes: z.string().optional(),
	requerimento_id: z.string().optional(),
	denuncia_id: z.string().optional(),
	// VAPT
	nome_local_trabalho: z.string().optional(),
	principais_riscos_identificados: z.string().optional(),
	recomendacoes_orientacoes: z.string().optional()
}).superRefine((data, ctx) => {
	if (data.motivo === "vapt_trabalhador") {
		if (!data.nome_local_trabalho || data.nome_local_trabalho.trim().length === 0) {
			ctx.addIssue({
				code: z.ZodIssueCode.custom,
				path: ["nome_local_trabalho"],
				message: "Para ações VAPT (Saúde do Trabalhador), o nome do posto/local é obrigatório."
			});
		}
		if (!data.principais_riscos_identificados || data.principais_riscos_identificados.trim().length === 0) {
			ctx.addIssue({
				code: z.ZodIssueCode.custom,
				path: ["principais_riscos_identificados"],
				message: "Para ações VAPT, informe os principais riscos ocupacionais identificados."
			});
		}
	}
});
export const AgendarInspecaoModal = ({ isOpen, onClose, estabelecimentoIdPreDefinido, motivoPreDefinido, onSucesso }) => {
	_s();
	const { user } = useAuth();
	const [buscaEstabelecimento, setBuscaEstabelecimento] = useState("");
	const agendarMutation = useAgendarInspecaoMutation();
	const { data: estabelecimentosData } = useEstabelecimentosList({
		busca: buscaEstabelecimento || undefined,
		limit: 20,
		situacao: "Ativo"
	});
	const hoje = new Date().toISOString().split("T")[0];
	const termoGeradoPadrao = `TERM-${new Date().getFullYear()}-${Math.floor(1e3 + Math.random() * 9e3)}`;
	const { register, handleSubmit, watch, setValue, reset, formState: { errors, isSubmitting } } = useForm({
		resolver: zodResolver(agendarInspecaoSchema),
		defaultValues: {
			numero_termo: termoGeradoPadrao,
			estabelecimento_id: estabelecimentoIdPreDefinido || "",
			fiscal_responsavel_id: user?.id || "",
			motivo: motivoPreDefinido || "rotina_programada",
			data_inicio: hoje,
			data_agendamento: hoje,
			hora_inspecao: "09:00",
			fiscais_acompanhantes: "",
			nome_local_trabalho: "",
			principais_riscos_identificados: "",
			recomendacoes_orientacoes: ""
		}
	});
	const motivoSelecionado = watch("motivo");
	const estabelecimentoSelecionadoId = watch("estabelecimento_id");
	useEffect(() => {
		if (isOpen) {
			reset({
				numero_termo: `TERM-${new Date().getFullYear()}-${Math.floor(1e3 + Math.random() * 9e3)}`,
				estabelecimento_id: estabelecimentoIdPreDefinido || "",
				fiscal_responsavel_id: user?.id || "",
				motivo: motivoPreDefinido || "rotina_programada",
				data_inicio: hoje,
				data_agendamento: hoje,
				hora_inspecao: "09:00",
				fiscais_acompanhantes: "",
				nome_local_trabalho: "",
				principais_riscos_identificados: "",
				recomendacoes_orientacoes: ""
			});
		}
	}, [
		isOpen,
		estabelecimentoIdPreDefinido,
		motivoPreDefinido,
		user?.id,
		reset,
		hoje
	]);
	if (!isOpen) return null;
	const onSubmit = async (data) => {
		try {
			const criada = await agendarMutation.mutateAsync(data);
			if (onSucesso) {
				onSucesso(criada);
			}
			onClose();
		} catch (err) {}
	};
	const estabelecimentoObj = estabelecimentosData?.itens.find((e) => e.id === estabelecimentoSelecionadoId);
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-xs",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl w-full max-w-2xl max-h-[90vh] shadow-2xl flex flex-col overflow-hidden animate-in fade-in zoom-in-95 duration-150",
			children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "px-6 py-4 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between bg-slate-50/50 dark:bg-slate-800/40",
				children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h2", {
					className: "text-base font-bold text-slate-900 dark:text-white flex items-center gap-2",
					children: [/* @__PURE__ */ _jsxDEV(Calendar, { className: "w-5 h-5 text-teal-600 dark:text-teal-400" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 188,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Nova Ação Fiscalizatória / Vistoria" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 189,
						columnNumber: 15
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 187,
					columnNumber: 13
				}, this), /* @__PURE__ */ _jsxDEV("p", {
					className: "text-xs text-slate-500 dark:text-slate-400",
					children: "Abertura de termo oficial de inspeção ou agendamento de ação de campo"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 191,
					columnNumber: 13
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 186,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					onClick: onClose,
					className: "p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-300 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors",
					children: /* @__PURE__ */ _jsxDEV(X, { className: "w-5 h-5" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 200,
						columnNumber: 13
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 195,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 185,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("form", {
				onSubmit: handleSubmit(onSubmit),
				className: "flex-1 overflow-y-auto p-6 space-y-5",
				children: [
					agendarMutation.isError && /* @__PURE__ */ _jsxDEV("div", {
						className: "p-3 bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 rounded-xl flex items-center gap-2 text-xs text-rose-700 dark:text-rose-300",
						children: [/* @__PURE__ */ _jsxDEV(AlertTriangle, { className: "w-4 h-4 shrink-0" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 211,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: agendarMutation.error instanceof Error ? agendarMutation.error.message : "Erro ao abrir termo de vistoria sanitária." }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 212,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 210,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "grid grid-cols-1 sm:grid-cols-2 gap-4",
						children: [/* @__PURE__ */ _jsxDEV("div", { children: [
							/* @__PURE__ */ _jsxDEV("label", {
								className: "block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1",
								children: ["Número do Termo ", /* @__PURE__ */ _jsxDEV("span", {
									className: "text-rose-500",
									children: "*"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 224,
									columnNumber: 33
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 223,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("input", {
								type: "text",
								...register("numero_termo"),
								placeholder: "Ex: TERM-2026-0042",
								className: "w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white font-mono placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-teal-500"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 226,
								columnNumber: 15
							}, this),
							errors.numero_termo && /* @__PURE__ */ _jsxDEV("p", {
								className: "text-[11px] text-rose-600 mt-1",
								children: errors.numero_termo.message
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 233,
								columnNumber: 17
							}, this)
						] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 222,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("div", { children: [
							/* @__PURE__ */ _jsxDEV("label", {
								className: "block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1",
								children: ["Motivo da Fiscalização ", /* @__PURE__ */ _jsxDEV("span", {
									className: "text-rose-500",
									children: "*"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 241,
									columnNumber: 40
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 240,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("select", {
								...register("motivo"),
								className: "w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-teal-500",
								children: Object.entries(MOTIVOS_LABELS).map(([valor, rotulo]) => /* @__PURE__ */ _jsxDEV("option", {
									value: valor,
									children: rotulo
								}, valor, false, {
									fileName: _jsxFileName,
									lineNumber: 248,
									columnNumber: 19
								}, this))
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 243,
								columnNumber: 15
							}, this),
							errors.motivo && /* @__PURE__ */ _jsxDEV("p", {
								className: "text-[11px] text-rose-600 mt-1",
								children: errors.motivo.message
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 254,
								columnNumber: 17
							}, this)
						] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 239,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 221,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", { children: [
						/* @__PURE__ */ _jsxDEV("label", {
							className: "block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1",
							children: ["Estabelecimento Alvo ", /* @__PURE__ */ _jsxDEV("span", {
								className: "text-rose-500",
								children: "*"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 264,
								columnNumber: 36
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 263,
							columnNumber: 13
						}, this),
						estabelecimentoIdPreDefinido && estabelecimentoObj ? /* @__PURE__ */ _jsxDEV("div", {
							className: "p-3 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl flex items-center gap-3",
							children: [/* @__PURE__ */ _jsxDEV(Building2, { className: "w-5 h-5 text-teal-600 dark:text-teal-400 shrink-0" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 268,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "flex-1 min-w-0",
								children: [/* @__PURE__ */ _jsxDEV("p", {
									className: "text-xs font-bold text-slate-900 dark:text-white truncate",
									children: estabelecimentoObj.razao_social
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 270,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("p", {
									className: "text-[11px] text-slate-500 dark:text-slate-400",
									children: [
										"CNPJ/CPF: ",
										estabelecimentoObj.cnpj_cpf,
										" • ",
										estabelecimentoObj.bairro
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 273,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 269,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 267,
							columnNumber: 15
						}, this) : /* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-2",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "relative",
								children: [/* @__PURE__ */ _jsxDEV(Search, { className: "w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 281,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("input", {
									type: "text",
									placeholder: "Filtrar por Razão Social, Nome Fantasia ou CNPJ...",
									value: buscaEstabelecimento,
									onChange: (e) => setBuscaEstabelecimento(e.target.value),
									className: "w-full pl-8 pr-3 py-1.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-1 focus:ring-teal-500"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 282,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 280,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("select", {
								...register("estabelecimento_id"),
								className: "w-full px-3 py-2 text-xs bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-teal-500",
								children: [/* @__PURE__ */ _jsxDEV("option", {
									value: "",
									children: "Selecione o estabelecimento..."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 294,
									columnNumber: 19
								}, this), estabelecimentosData?.itens.map((est) => /* @__PURE__ */ _jsxDEV("option", {
									value: est.id,
									children: [
										est.razao_social,
										" (",
										est.cnpj_cpf,
										") - ",
										est.bairro,
										" [",
										est.nivel_risco,
										"]"
									]
								}, est.id, true, {
									fileName: _jsxFileName,
									lineNumber: 296,
									columnNumber: 21
								}, this))]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 290,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 279,
							columnNumber: 15
						}, this),
						errors.estabelecimento_id && /* @__PURE__ */ _jsxDEV("p", {
							className: "text-[11px] text-rose-600 mt-1",
							children: errors.estabelecimento_id.message
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 304,
							columnNumber: 15
						}, this)
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 262,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "grid grid-cols-1 sm:grid-cols-3 gap-4",
						children: [
							/* @__PURE__ */ _jsxDEV("div", { children: [
								/* @__PURE__ */ _jsxDEV("label", {
									className: "block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1",
									children: ["Data de Abertura / Realização ", /* @__PURE__ */ _jsxDEV("span", {
										className: "text-rose-500",
										children: "*"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 314,
										columnNumber: 47
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 313,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("input", {
									type: "date",
									...register("data_inicio"),
									className: "w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-teal-500"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 316,
									columnNumber: 15
								}, this),
								errors.data_inicio && /* @__PURE__ */ _jsxDEV("p", {
									className: "text-[11px] text-rose-600 mt-1",
									children: errors.data_inicio.message
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 322,
									columnNumber: 17
								}, this)
							] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 312,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1",
								children: "Data Agendada (Previsão)"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 329,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								type: "date",
								...register("data_agendamento"),
								className: "w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-teal-500"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 332,
								columnNumber: 15
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 328,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1",
								children: "Horário da Vistoria"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 340,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "relative",
								children: [/* @__PURE__ */ _jsxDEV(Clock, { className: "w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 344,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("input", {
									type: "time",
									...register("hora_inspecao"),
									className: "w-full pl-8 pr-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-teal-500"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 345,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 343,
								columnNumber: 15
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 339,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 311,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "grid grid-cols-1 sm:grid-cols-2 gap-4",
						children: [/* @__PURE__ */ _jsxDEV("div", { children: [
							/* @__PURE__ */ _jsxDEV("label", {
								className: "block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1",
								children: ["Fiscal Responsável ", /* @__PURE__ */ _jsxDEV("span", {
									className: "text-rose-500",
									children: "*"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 358,
									columnNumber: 36
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 357,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-2 p-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg",
								children: [/* @__PURE__ */ _jsxDEV(UserCheck, { className: "w-4 h-4 text-teal-600 dark:text-teal-400 shrink-0" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 361,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("span", {
									className: "text-xs font-medium text-slate-800 dark:text-slate-200 truncate",
									children: user?.nome_completo || "Fiscal Responsável"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 362,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 360,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("input", {
								type: "hidden",
								...register("fiscal_responsavel_id")
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 366,
								columnNumber: 15
							}, this),
							errors.fiscal_responsavel_id && /* @__PURE__ */ _jsxDEV("p", {
								className: "text-[11px] text-rose-600 mt-1",
								children: errors.fiscal_responsavel_id.message
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 368,
								columnNumber: 17
							}, this)
						] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 356,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
							className: "block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1",
							children: "Fiscais Acompanhantes / Equipe"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 375,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("input", {
							type: "text",
							...register("fiscais_acompanhantes"),
							placeholder: "Ex: João da Silva (Fiscal Sanitário II)",
							className: "w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-teal-500"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 378,
							columnNumber: 15
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 374,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 355,
						columnNumber: 11
					}, this),
					motivoSelecionado === "vapt_trabalhador" && /* @__PURE__ */ _jsxDEV("div", {
						className: "p-4 bg-teal-50/60 dark:bg-teal-950/30 border border-teal-200 dark:border-teal-800/80 rounded-xl space-y-3 animate-in fade-in duration-200",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-2 text-teal-800 dark:text-teal-300",
								children: [/* @__PURE__ */ _jsxDEV(HardHat, { className: "w-4 h-4 shrink-0 text-teal-600 dark:text-teal-400" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 391,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("h3", {
									className: "text-xs font-bold uppercase tracking-wider",
									children: "Módulo VAPT - Vigilância em Ambientes e Processos de Trabalho (Indicador 11)"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 392,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 390,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("p", {
								className: "text-[11px] text-teal-700/80 dark:text-teal-400",
								children: "Ação com foco na saúde, segurança e ergonomia do trabalhador no ambiente ocupacional."
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 396,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { children: [
								/* @__PURE__ */ _jsxDEV("label", {
									className: "block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1",
									children: ["Setor / Posto de Trabalho Vistoriado ", /* @__PURE__ */ _jsxDEV("span", {
										className: "text-rose-500",
										children: "*"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 402,
										columnNumber: 56
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 401,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("input", {
									type: "text",
									...register("nome_local_trabalho"),
									placeholder: "Ex: Linha de envase, cozinha industrial, estoque de químicos...",
									className: "w-full px-3 py-2 text-xs bg-white dark:bg-slate-800 border border-teal-300 dark:border-teal-700 rounded-lg text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-teal-500"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 404,
									columnNumber: 17
								}, this),
								errors.nome_local_trabalho && /* @__PURE__ */ _jsxDEV("p", {
									className: "text-[11px] text-rose-600 mt-1",
									children: errors.nome_local_trabalho.message
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 411,
									columnNumber: 19
								}, this)
							] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 400,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { children: [
								/* @__PURE__ */ _jsxDEV("label", {
									className: "block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1",
									children: ["Principais Riscos Ocupacionais Identificados ", /* @__PURE__ */ _jsxDEV("span", {
										className: "text-rose-500",
										children: "*"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 419,
										columnNumber: 64
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 418,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("textarea", {
									rows: 2,
									...register("principais_riscos_identificados"),
									placeholder: "Ex: Risco ergonômico por levantamento de peso repetitivo, risco físico de ruído elevado sem protetor auricular...",
									className: "w-full px-3 py-2 text-xs bg-white dark:bg-slate-800 border border-teal-300 dark:border-teal-700 rounded-lg text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-teal-500"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 421,
									columnNumber: 17
								}, this),
								errors.principais_riscos_identificados && /* @__PURE__ */ _jsxDEV("p", {
									className: "text-[11px] text-rose-600 mt-1",
									children: errors.principais_riscos_identificados.message
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 428,
									columnNumber: 19
								}, this)
							] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 417,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1",
								children: "Recomendações e Orientações Técnicas ao Empregador"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 435,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("textarea", {
								rows: 2,
								...register("recomendacoes_orientacoes"),
								placeholder: "Orientações preliminares de adequação ergonômica ou fornecimento de EPIs...",
								className: "w-full px-3 py-2 text-xs bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-teal-500"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 438,
								columnNumber: 17
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 434,
								columnNumber: 15
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 389,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center justify-end gap-3 pt-4 border-t border-slate-100 dark:border-slate-800",
						children: [/* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							onClick: onClose,
							disabled: isSubmitting,
							className: "px-4 py-2 text-xs font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors",
							children: "Cancelar"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 450,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							type: "submit",
							disabled: isSubmitting,
							className: "px-5 py-2 text-xs font-bold text-white bg-teal-600 hover:bg-teal-700 rounded-lg shadow-xs transition-colors flex items-center gap-2 disabled:opacity-60",
							children: isSubmitting ? /* @__PURE__ */ _jsxDEV("span", { children: "Salvando Termo..." }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 464,
								columnNumber: 17
							}, this) : /* @__PURE__ */ _jsxDEV("span", { children: "Abrir / Agendar Termo" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 466,
								columnNumber: 17
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 458,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 449,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 205,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 183,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 182,
		columnNumber: 5
	}, this);
};
_s(AgendarInspecaoModal, "eE9H+/D9PPE0I19UadfTRgKXJWw=", false, function() {
	return [
		useAuth,
		useAgendarInspecaoMutation,
		useEstabelecimentosList,
		useForm
	];
});
_c = AgendarInspecaoModal;
export default AgendarInspecaoModal;
var _c;
$RefreshReg$(_c, "AgendarInspecaoModal");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/fiscalizacao/AgendarInspecaoModal.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("E:/Projetos VSCODE/visa_braunas/src/components/fiscalizacao/AgendarInspecaoModal.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("E:/Projetos VSCODE/visa_braunas/src/components/fiscalizacao/AgendarInspecaoModal.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "E:/Projetos VSCODE/visa_braunas/src/components/fiscalizacao/AgendarInspecaoModal.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7OztBQUtBLE9BQU8sU0FBUyxXQUFXLGdCQUFnQjtBQUMzQyxTQUFTLGVBQWU7QUFDeEIsU0FBUyxtQkFBbUI7QUFDNUIsWUFBWSxPQUFPO0FBQ25CLFNBQ0UsZUFDQSxXQUNBLFVBQ0EsT0FDQSxTQUNBLFFBQ0EsV0FDQSxTQUNLO0FBRVAsU0FBUyxrQ0FBa0M7QUFDM0MsU0FBUywrQkFBK0I7QUFDeEMsU0FBUyxlQUFlOzs7O0FBRXhCLE1BQU0saUJBQXFEO0NBQ3pELG1CQUFtQjtDQUNuQixxQkFBcUI7Q0FDckIsVUFBVTtDQUNWLFlBQVk7Q0FDWixrQkFBa0I7Q0FDbEIsb0JBQW9CO0FBQ3RCO0FBRUEsTUFBTSx3QkFBd0IsRUFDM0IsT0FBTztDQUNOLGNBQWMsRUFBRSxPQUFPLENBQUMsQ0FBQyxJQUFJLEdBQUcsaURBQWlEO0NBQ2pGLG9CQUFvQixFQUFFLE9BQU8sQ0FBQyxDQUFDLEtBQUsscUNBQXFDO0NBQ3pFLHVCQUF1QixFQUFFLE9BQU8sQ0FBQyxDQUFDLEtBQUssa0NBQWtDO0NBQ3pFLFFBQVEsRUFBRSxLQUFLO0VBQ2I7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0NBQ0YsQ0FBQztDQUNELGFBQWEsRUFBRSxPQUFPLENBQUMsQ0FBQyxJQUFJLElBQUksdUNBQXVDO0NBQ3ZFLGtCQUFrQixFQUFFLE9BQU8sQ0FBQyxDQUFDLFNBQVM7Q0FDdEMsZUFBZSxFQUFFLE9BQU8sQ0FBQyxDQUFDLFNBQVM7Q0FDbkMsdUJBQXVCLEVBQUUsT0FBTyxDQUFDLENBQUMsU0FBUztDQUMzQyxpQkFBaUIsRUFBRSxPQUFPLENBQUMsQ0FBQyxTQUFTO0NBQ3JDLGFBQWEsRUFBRSxPQUFPLENBQUMsQ0FBQyxTQUFTOztDQUVqQyxxQkFBcUIsRUFBRSxPQUFPLENBQUMsQ0FBQyxTQUFTO0NBQ3pDLGlDQUFpQyxFQUFFLE9BQU8sQ0FBQyxDQUFDLFNBQVM7Q0FDckQsMkJBQTJCLEVBQUUsT0FBTyxDQUFDLENBQUMsU0FBUztBQUNqRCxDQUFDLENBQUMsQ0FDRCxhQUFhLE1BQU0sUUFBUTtDQUMxQixJQUFJLEtBQUssV0FBVyxvQkFBb0I7RUFDdEMsSUFBSSxDQUFDLEtBQUssdUJBQXVCLEtBQUssb0JBQW9CLEtBQUssQ0FBQyxDQUFDLFdBQVcsR0FBRztHQUM3RSxJQUFJLFNBQVM7SUFDWCxNQUFNLEVBQUUsYUFBYTtJQUNyQixNQUFNLENBQUMscUJBQXFCO0lBQzVCLFNBQ0U7R0FDSixDQUFDO0VBQ0g7RUFDQSxJQUNFLENBQUMsS0FBSyxtQ0FDTixLQUFLLGdDQUFnQyxLQUFLLENBQUMsQ0FBQyxXQUFXLEdBQ3ZEO0dBQ0EsSUFBSSxTQUFTO0lBQ1gsTUFBTSxFQUFFLGFBQWE7SUFDckIsTUFBTSxDQUFDLGlDQUFpQztJQUN4QyxTQUNFO0dBQ0osQ0FBQztFQUNIO0NBQ0Y7QUFDRixDQUFDO0FBWUgsT0FBTyxNQUFNLHdCQUE2RCxFQUN4RSxRQUNBLFNBQ0EsOEJBQ0EsbUJBQ0EsZ0JBQ0k7O0NBQ0osTUFBTSxFQUFFLFNBQVMsUUFBUTtDQUN6QixNQUFNLENBQUMsc0JBQXNCLDJCQUEyQixTQUFTLEVBQUU7Q0FDbkUsTUFBTSxrQkFBa0IsMkJBQTJCO0NBRW5ELE1BQU0sRUFBRSxNQUFNLHlCQUF5Qix3QkFBd0I7RUFDN0QsT0FBTyx3QkFBd0I7RUFDL0IsT0FBTztFQUNQLFVBQVU7Q0FDWixDQUFDO0NBRUQsTUFBTSxPQUFPLElBQUksS0FBSyxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQztDQUNqRCxNQUFNLG9CQUFvQixRQUFRLElBQUksS0FBSyxDQUFDLENBQUMsWUFBWSxFQUFFLEdBQUcsS0FBSyxNQUNqRSxNQUFPLEtBQUssT0FBTyxJQUFJLEdBQ3pCO0NBRUEsTUFBTSxFQUNKLFVBQ0EsY0FDQSxPQUNBLFVBQ0EsT0FDQSxXQUFXLEVBQUUsUUFBUSxtQkFDbkIsUUFBeUI7RUFDM0IsVUFBVSxZQUFZLHFCQUFxQjtFQUMzQyxlQUFlO0dBQ2IsY0FBYztHQUNkLG9CQUFvQixnQ0FBZ0M7R0FDcEQsdUJBQXVCLE1BQU0sTUFBTTtHQUNuQyxRQUFRLHFCQUFxQjtHQUM3QixhQUFhO0dBQ2Isa0JBQWtCO0dBQ2xCLGVBQWU7R0FDZix1QkFBdUI7R0FDdkIscUJBQXFCO0dBQ3JCLGlDQUFpQztHQUNqQywyQkFBMkI7RUFDN0I7Q0FDRixDQUFDO0NBRUQsTUFBTSxvQkFBb0IsTUFBTSxRQUFRO0NBQ3hDLE1BQU0sK0JBQStCLE1BQU0sb0JBQW9CO0NBRS9ELGdCQUFnQjtFQUNkLElBQUksUUFBUTtHQUNWLE1BQU07SUFDSixjQUFjLFFBQVEsSUFBSSxLQUFLLENBQUMsQ0FBQyxZQUFZLEVBQUUsR0FBRyxLQUFLLE1BQ3JELE1BQU8sS0FBSyxPQUFPLElBQUksR0FDekI7SUFDQSxvQkFBb0IsZ0NBQWdDO0lBQ3BELHVCQUF1QixNQUFNLE1BQU07SUFDbkMsUUFBUSxxQkFBcUI7SUFDN0IsYUFBYTtJQUNiLGtCQUFrQjtJQUNsQixlQUFlO0lBQ2YsdUJBQXVCO0lBQ3ZCLHFCQUFxQjtJQUNyQixpQ0FBaUM7SUFDakMsMkJBQTJCO0dBQzdCLENBQUM7RUFDSDtDQUNGLEdBQUc7RUFBQztFQUFRO0VBQThCO0VBQW1CLE1BQU07RUFBSTtFQUFPO0NBQUksQ0FBQztDQUVuRixJQUFJLENBQUMsUUFBUSxPQUFPO0NBRXBCLE1BQU0sV0FBVyxPQUFPLFNBQTBCO0VBQ2hELElBQUk7R0FDRixNQUFNLFNBQVMsTUFBTSxnQkFBZ0IsWUFDbkMsSUFDRjtHQUNBLElBQUksV0FBVztJQUNiLFVBQVUsTUFBTTtHQUNsQjtHQUNBLFFBQVE7RUFDVixTQUFTLEtBQVUsQ0FFbkI7Q0FDRjtDQUVBLE1BQU0scUJBQXFCLHNCQUFzQixNQUFNLE1BQ3BELE1BQU0sRUFBRSxPQUFPLDRCQUNsQjtDQUVBLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFDYix3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmLENBRUUsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxNQUFEO0tBQUksV0FBVTtlQUFkLENBQ0Usd0JBQUMsVUFBRCxFQUFVLFdBQVUsMkNBQTRDOzs7O2VBQ2hFLHdCQUFDLFFBQUQsWUFBTSxzQ0FBeUM7Ozs7YUFDN0M7Ozs7O2NBQ0osd0JBQUMsS0FBRDtLQUFHLFdBQVU7ZUFBNkM7SUFFdkQ7Ozs7WUFDQTs7OztjQUNMLHdCQUFDLFVBQUQ7S0FDRSxNQUFLO0tBQ0wsU0FBUztLQUNULFdBQVU7ZUFFVix3QkFBQyxHQUFELEVBQUcsV0FBVSxVQUFXOzs7OztJQUNsQjs7OztZQUNMOzs7OzthQUdMLHdCQUFDLFFBQUQ7SUFDRSxVQUFVLGFBQWEsUUFBUTtJQUMvQixXQUFVO2NBRlo7S0FJRyxnQkFBZ0IsV0FDZix3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLGVBQUQsRUFBZSxXQUFVLG1CQUFvQjs7OztnQkFDN0Msd0JBQUMsUUFBRCxZQUNHLGdCQUFnQixpQkFBaUIsUUFDOUIsZ0JBQWdCLE1BQU0sVUFDdEIsNkNBQ0E7Ozs7Y0FDSDs7Ozs7O0tBSVAsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxPQUFEO09BQ0Usd0JBQUMsU0FBRDtRQUFPLFdBQVU7a0JBQWpCLENBQXVGLG9CQUNyRSx3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFBZ0I7UUFBTzs7OztnQkFDbEQ7Ozs7OztPQUNQLHdCQUFDLFNBQUQ7UUFDRSxNQUFLO1FBQ0wsR0FBSSxTQUFTLGNBQWM7UUFDM0IsYUFBWTtRQUNaLFdBQVU7T0FDWDs7Ozs7T0FDQSxPQUFPLGdCQUNOLHdCQUFDLEtBQUQ7UUFBRyxXQUFVO2tCQUNWLE9BQU8sYUFBYTtPQUNwQjs7Ozs7TUFFRjs7OztnQkFFTCx3QkFBQyxPQUFEO09BQ0Usd0JBQUMsU0FBRDtRQUFPLFdBQVU7a0JBQWpCLENBQXVGLDJCQUM5RCx3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFBZ0I7UUFBTzs7OztnQkFDekQ7Ozs7OztPQUNQLHdCQUFDLFVBQUQ7UUFDRSxHQUFJLFNBQVMsUUFBUTtRQUNyQixXQUFVO2tCQUVULE9BQU8sUUFBUSxjQUFjLENBQUMsQ0FBQyxLQUFLLENBQUMsT0FBTyxZQUMzQyx3QkFBQyxVQUFEO1NBQW9CLE9BQU87bUJBQ3hCO1FBQ0ssR0FGSzs7OztlQUVMLENBQ1Q7T0FDSzs7Ozs7T0FDUCxPQUFPLFVBQ04sd0JBQUMsS0FBRDtRQUFHLFdBQVU7a0JBQ1YsT0FBTyxPQUFPO09BQ2Q7Ozs7O01BRUY7Ozs7Y0FDRjs7Ozs7O0tBR0wsd0JBQUMsT0FBRDtNQUNFLHdCQUFDLFNBQUQ7T0FBTyxXQUFVO2lCQUFqQixDQUF1Rix5QkFDaEUsd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQWdCO09BQU87Ozs7ZUFDdkQ7Ozs7OztNQUNOLGdDQUFnQyxxQkFDL0Isd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxXQUFELEVBQVcsV0FBVSxvREFBcUQ7Ozs7aUJBQzFFLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsS0FBRDtTQUFHLFdBQVU7bUJBQ1YsbUJBQW1CO1FBQ25COzs7O2tCQUNILHdCQUFDLEtBQUQ7U0FBRyxXQUFVO21CQUFiO1VBQThEO1VBQ2pELG1CQUFtQjtVQUFTO1VBQUksbUJBQW1CO1NBQzdEOzs7OztnQkFDQTs7Ozs7ZUFDRjs7Ozs7aUJBRUwsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLFFBQUQsRUFBUSxXQUFVLHFEQUFzRDs7OztrQkFDeEUsd0JBQUMsU0FBRDtTQUNFLE1BQUs7U0FDTCxhQUFZO1NBQ1osT0FBTztTQUNQLFdBQVcsTUFBTSx3QkFBd0IsRUFBRSxPQUFPLEtBQUs7U0FDdkQsV0FBVTtRQUNYOzs7O2dCQUNFOzs7OztpQkFDTCx3QkFBQyxVQUFEO1FBQ0UsR0FBSSxTQUFTLG9CQUFvQjtRQUNqQyxXQUFVO2tCQUZaLENBSUUsd0JBQUMsVUFBRDtTQUFRLE9BQU07bUJBQUc7UUFBc0M7Ozs7a0JBQ3RELHNCQUFzQixNQUFNLEtBQUssUUFDaEMsd0JBQUMsVUFBRDtTQUFxQixPQUFPLElBQUk7bUJBQWhDO1VBQ0csSUFBSTtVQUFhO1VBQUcsSUFBSTtVQUFTO1VBQUssSUFBSTtVQUFPO1VBQUcsSUFBSTtVQUFZO1NBQy9EO1dBRkssSUFBSTs7OztlQUVULENBQ1QsQ0FDSzs7Ozs7ZUFDTDs7Ozs7O01BRU4sT0FBTyxzQkFDTix3QkFBQyxLQUFEO09BQUcsV0FBVTtpQkFDVixPQUFPLG1CQUFtQjtNQUMxQjs7Ozs7S0FFRjs7Ozs7S0FHTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZjtPQUNFLHdCQUFDLE9BQUQ7UUFDRSx3QkFBQyxTQUFEO1NBQU8sV0FBVTttQkFBakIsQ0FBdUYsa0NBQ3ZELHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUFnQjtTQUFPOzs7O2lCQUNoRTs7Ozs7O1FBQ1Asd0JBQUMsU0FBRDtTQUNFLE1BQUs7U0FDTCxHQUFJLFNBQVMsYUFBYTtTQUMxQixXQUFVO1FBQ1g7Ozs7O1FBQ0EsT0FBTyxlQUNOLHdCQUFDLEtBQUQ7U0FBRyxXQUFVO21CQUNWLE9BQU8sWUFBWTtRQUNuQjs7Ozs7T0FFRjs7Ozs7T0FFTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtRQUFPLFdBQVU7a0JBQXNFO09BRWhGOzs7O2lCQUNQLHdCQUFDLFNBQUQ7UUFDRSxNQUFLO1FBQ0wsR0FBSSxTQUFTLGtCQUFrQjtRQUMvQixXQUFVO09BQ1g7Ozs7ZUFDRTs7Ozs7T0FFTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtRQUFPLFdBQVU7a0JBQXNFO09BRWhGOzs7O2lCQUNQLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsT0FBRCxFQUFPLFdBQVUscURBQXNEOzs7O2tCQUN2RSx3QkFBQyxTQUFEO1NBQ0UsTUFBSztTQUNMLEdBQUksU0FBUyxlQUFlO1NBQzVCLFdBQVU7UUFDWDs7OztnQkFDRTs7Ozs7ZUFDRjs7Ozs7TUFDRjs7Ozs7O0tBR0wsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxPQUFEO09BQ0Usd0JBQUMsU0FBRDtRQUFPLFdBQVU7a0JBQWpCLENBQXVGLHVCQUNsRSx3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFBZ0I7UUFBTzs7OztnQkFDckQ7Ozs7OztPQUNQLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsV0FBRCxFQUFXLFdBQVUsb0RBQXFEOzs7O2tCQUMxRSx3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFDYixNQUFNLGlCQUFpQjtRQUNwQjs7OztnQkFDSDs7Ozs7O09BQ0wsd0JBQUMsU0FBRDtRQUFPLE1BQUs7UUFBUyxHQUFJLFNBQVMsdUJBQXVCO09BQUk7Ozs7O09BQzVELE9BQU8seUJBQ04sd0JBQUMsS0FBRDtRQUFHLFdBQVU7a0JBQ1YsT0FBTyxzQkFBc0I7T0FDN0I7Ozs7O01BRUY7Ozs7Z0JBRUwsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7T0FBTyxXQUFVO2lCQUFzRTtNQUVoRjs7OztnQkFDUCx3QkFBQyxTQUFEO09BQ0UsTUFBSztPQUNMLEdBQUksU0FBUyx1QkFBdUI7T0FDcEMsYUFBWTtPQUNaLFdBQVU7TUFDWDs7OztjQUNFOzs7O2NBQ0Y7Ozs7OztLQUdKLHNCQUFzQixzQkFDckIsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWY7T0FDRSx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLFNBQUQsRUFBUyxXQUFVLG9EQUFxRDs7OztrQkFDeEUsd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQTZDO1FBRXZEOzs7O2dCQUNEOzs7Ozs7T0FDTCx3QkFBQyxLQUFEO1FBQUcsV0FBVTtrQkFBa0Q7T0FFNUQ7Ozs7O09BRUgsd0JBQUMsT0FBRDtRQUNFLHdCQUFDLFNBQUQ7U0FBTyxXQUFVO21CQUFqQixDQUF1Rix5Q0FDaEQsd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQWdCO1NBQU87Ozs7aUJBQ3ZFOzs7Ozs7UUFDUCx3QkFBQyxTQUFEO1NBQ0UsTUFBSztTQUNMLEdBQUksU0FBUyxxQkFBcUI7U0FDbEMsYUFBWTtTQUNaLFdBQVU7UUFDWDs7Ozs7UUFDQSxPQUFPLHVCQUNOLHdCQUFDLEtBQUQ7U0FBRyxXQUFVO21CQUNWLE9BQU8sb0JBQW9CO1FBQzNCOzs7OztPQUVGOzs7OztPQUVMLHdCQUFDLE9BQUQ7UUFDRSx3QkFBQyxTQUFEO1NBQU8sV0FBVTttQkFBakIsQ0FBdUYsaURBQ3hDLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUFnQjtTQUFPOzs7O2lCQUMvRTs7Ozs7O1FBQ1Asd0JBQUMsWUFBRDtTQUNFLE1BQU07U0FDTixHQUFJLFNBQVMsaUNBQWlDO1NBQzlDLGFBQVk7U0FDWixXQUFVO1FBQ1g7Ozs7O1FBQ0EsT0FBTyxtQ0FDTix3QkFBQyxLQUFEO1NBQUcsV0FBVTttQkFDVixPQUFPLGdDQUFnQztRQUN2Qzs7Ozs7T0FFRjs7Ozs7T0FFTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtRQUFPLFdBQVU7a0JBQXNFO09BRWhGOzs7O2lCQUNQLHdCQUFDLFlBQUQ7UUFDRSxNQUFNO1FBQ04sR0FBSSxTQUFTLDJCQUEyQjtRQUN4QyxhQUFZO1FBQ1osV0FBVTtPQUNYOzs7O2VBQ0U7Ozs7O01BQ0Y7Ozs7OztLQUlQLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsVUFBRDtPQUNFLE1BQUs7T0FDTCxTQUFTO09BQ1QsVUFBVTtPQUNWLFdBQVU7aUJBQ1g7TUFFTzs7OztnQkFDUix3QkFBQyxVQUFEO09BQ0UsTUFBSztPQUNMLFVBQVU7T0FDVixXQUFVO2lCQUVULGVBQ0Msd0JBQUMsUUFBRCxZQUFNLG9CQUF1Qjs7OztrQkFFN0Isd0JBQUMsUUFBRCxZQUFNLHdCQUEyQjs7Ozs7TUFFN0I7Ozs7Y0FDTDs7Ozs7O0lBQ0Q7Ozs7O1dBQ0g7Ozs7OztDQUNGOzs7OztBQUVUOzs7Ozs7Ozs7O0FBRUEsZUFBZSIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJBZ2VuZGFySW5zcGVjYW9Nb2RhbC50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiLyoqXHJcbiAqIE1vZGFsIGRlIEFnZW5kYW1lbnRvIGUgQWJlcnR1cmEgZGUgVGVybW8gZGUgSW5zcGXDp8OjbyBTYW5pdMOhcmlhXHJcbiAqIFZhbGlkYcOnw6NvIGNvbmRpY2lvbmFsIFpvZCAocmVncmFzIFZBUFQgLSBJbmRpY2Fkb3IgMTEpLlxyXG4gKi9cclxuXHJcbmltcG9ydCBSZWFjdCwgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7IHVzZUZvcm0gfSBmcm9tIFwicmVhY3QtaG9vay1mb3JtXCI7XHJcbmltcG9ydCB7IHpvZFJlc29sdmVyIH0gZnJvbSBcIkBob29rZm9ybS9yZXNvbHZlcnMvem9kXCI7XHJcbmltcG9ydCAqIGFzIHogZnJvbSBcInpvZFwiO1xyXG5pbXBvcnQge1xyXG4gIEFsZXJ0VHJpYW5nbGUsXHJcbiAgQnVpbGRpbmcyLFxyXG4gIENhbGVuZGFyLFxyXG4gIENsb2NrLFxyXG4gIEhhcmRIYXQsXHJcbiAgU2VhcmNoLFxyXG4gIFVzZXJDaGVjayxcclxuICBYLFxyXG59IGZyb20gXCJsdWNpZGUtcmVhY3RcIjtcclxuaW1wb3J0IHsgQWdlbmRhckluc3BlY2FvRm9ybVZhbHVlcywgVGlwb01vdGl2b0luc3BlY2FvIH0gZnJvbSBcIi4uLy4uL3R5cGVzL2Zpc2NhbGl6YWNhb1wiO1xyXG5pbXBvcnQgeyB1c2VBZ2VuZGFySW5zcGVjYW9NdXRhdGlvbiB9IGZyb20gXCIuLi8uLi9ob29rcy91c2VGaXNjYWxpemFjYW9cIjtcclxuaW1wb3J0IHsgdXNlRXN0YWJlbGVjaW1lbnRvc0xpc3QgfSBmcm9tIFwiLi4vLi4vaG9va3MvdXNlRXN0YWJlbGVjaW1lbnRvc1wiO1xyXG5pbXBvcnQgeyB1c2VBdXRoIH0gZnJvbSBcIi4uLy4uL2NvbnRleHRzL0F1dGhDb250ZXh0XCI7XHJcblxyXG5jb25zdCBNT1RJVk9TX0xBQkVMUzogUmVjb3JkPFRpcG9Nb3Rpdm9JbnNwZWNhbywgc3RyaW5nPiA9IHtcclxuICByb3RpbmFfcHJvZ3JhbWFkYTogXCJSb3RpbmEgUHJvZ3JhbWFkYVwiLFxyXG4gIHJlcXVlcmltZW50b19hbHZhcmE6IFwiUmVxdWVyaW1lbnRvIGRlIEFsdmFyw6FcIixcclxuICBkZW51bmNpYTogXCJBdGVuZGltZW50byBhIERlbsO6bmNpYVwiLFxyXG4gIHJlaW5zcGVjYW86IFwiUmVpbnNwZcOnw6NvIEZpc2NhbCAoUmV0b3JubylcIixcclxuICB2YXB0X3RyYWJhbGhhZG9yOiBcIlZBUFQgLSBTYcO6ZGUgZG8gVHJhYmFsaGFkb3IgKEluZGljYWRvciAxMSlcIixcclxuICBpbnZlc3RpZ2FjYW9fc3VydG86IFwiSW52ZXN0aWdhw6fDo28gZGUgU3VydG8gLyBEVEFcIixcclxufTtcclxuXHJcbmNvbnN0IGFnZW5kYXJJbnNwZWNhb1NjaGVtYSA9IHpcclxuICAub2JqZWN0KHtcclxuICAgIG51bWVyb190ZXJtbzogei5zdHJpbmcoKS5taW4oMywgXCJOw7ptZXJvIGRvIHRlcm1vIGRldmUgdGVyIG5vIG3DrW5pbW8gMyBjYXJhY3RlcmVzXCIpLFxyXG4gICAgZXN0YWJlbGVjaW1lbnRvX2lkOiB6LnN0cmluZygpLnV1aWQoXCJTZWxlY2lvbmUgdW0gZXN0YWJlbGVjaW1lbnRvIHbDoWxpZG9cIiksXHJcbiAgICBmaXNjYWxfcmVzcG9uc2F2ZWxfaWQ6IHouc3RyaW5nKCkudXVpZChcIkZpc2NhbCByZXNwb25zw6F2ZWwgw6kgb2JyaWdhdMOzcmlvXCIpLFxyXG4gICAgbW90aXZvOiB6LmVudW0oW1xyXG4gICAgICBcInJvdGluYV9wcm9ncmFtYWRhXCIsXHJcbiAgICAgIFwicmVxdWVyaW1lbnRvX2FsdmFyYVwiLFxyXG4gICAgICBcImRlbnVuY2lhXCIsXHJcbiAgICAgIFwicmVpbnNwZWNhb1wiLFxyXG4gICAgICBcInZhcHRfdHJhYmFsaGFkb3JcIixcclxuICAgICAgXCJpbnZlc3RpZ2FjYW9fc3VydG9cIixcclxuICAgIF0pLFxyXG4gICAgZGF0YV9pbmljaW86IHouc3RyaW5nKCkubWluKDEwLCBcIkRhdGEgZGUgaW7DrWNpby9hYmVydHVyYSDDqSBvYnJpZ2F0w7NyaWFcIiksXHJcbiAgICBkYXRhX2FnZW5kYW1lbnRvOiB6LnN0cmluZygpLm9wdGlvbmFsKCksXHJcbiAgICBob3JhX2luc3BlY2FvOiB6LnN0cmluZygpLm9wdGlvbmFsKCksXHJcbiAgICBmaXNjYWlzX2Fjb21wYW5oYW50ZXM6IHouc3RyaW5nKCkub3B0aW9uYWwoKSxcclxuICAgIHJlcXVlcmltZW50b19pZDogei5zdHJpbmcoKS5vcHRpb25hbCgpLFxyXG4gICAgZGVudW5jaWFfaWQ6IHouc3RyaW5nKCkub3B0aW9uYWwoKSxcclxuICAgIC8vIFZBUFRcclxuICAgIG5vbWVfbG9jYWxfdHJhYmFsaG86IHouc3RyaW5nKCkub3B0aW9uYWwoKSxcclxuICAgIHByaW5jaXBhaXNfcmlzY29zX2lkZW50aWZpY2Fkb3M6IHouc3RyaW5nKCkub3B0aW9uYWwoKSxcclxuICAgIHJlY29tZW5kYWNvZXNfb3JpZW50YWNvZXM6IHouc3RyaW5nKCkub3B0aW9uYWwoKSxcclxuICB9KVxyXG4gIC5zdXBlclJlZmluZSgoZGF0YSwgY3R4KSA9PiB7XHJcbiAgICBpZiAoZGF0YS5tb3Rpdm8gPT09IFwidmFwdF90cmFiYWxoYWRvclwiKSB7XHJcbiAgICAgIGlmICghZGF0YS5ub21lX2xvY2FsX3RyYWJhbGhvIHx8IGRhdGEubm9tZV9sb2NhbF90cmFiYWxoby50cmltKCkubGVuZ3RoID09PSAwKSB7XHJcbiAgICAgICAgY3R4LmFkZElzc3VlKHtcclxuICAgICAgICAgIGNvZGU6IHouWm9kSXNzdWVDb2RlLmN1c3RvbSxcclxuICAgICAgICAgIHBhdGg6IFtcIm5vbWVfbG9jYWxfdHJhYmFsaG9cIl0sXHJcbiAgICAgICAgICBtZXNzYWdlOlxyXG4gICAgICAgICAgICBcIlBhcmEgYcOnw7VlcyBWQVBUIChTYcO6ZGUgZG8gVHJhYmFsaGFkb3IpLCBvIG5vbWUgZG8gcG9zdG8vbG9jYWwgw6kgb2JyaWdhdMOzcmlvLlwiLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9XHJcbiAgICAgIGlmIChcclxuICAgICAgICAhZGF0YS5wcmluY2lwYWlzX3Jpc2Nvc19pZGVudGlmaWNhZG9zIHx8XHJcbiAgICAgICAgZGF0YS5wcmluY2lwYWlzX3Jpc2Nvc19pZGVudGlmaWNhZG9zLnRyaW0oKS5sZW5ndGggPT09IDBcclxuICAgICAgKSB7XHJcbiAgICAgICAgY3R4LmFkZElzc3VlKHtcclxuICAgICAgICAgIGNvZGU6IHouWm9kSXNzdWVDb2RlLmN1c3RvbSxcclxuICAgICAgICAgIHBhdGg6IFtcInByaW5jaXBhaXNfcmlzY29zX2lkZW50aWZpY2Fkb3NcIl0sXHJcbiAgICAgICAgICBtZXNzYWdlOlxyXG4gICAgICAgICAgICBcIlBhcmEgYcOnw7VlcyBWQVBULCBpbmZvcm1lIG9zIHByaW5jaXBhaXMgcmlzY29zIG9jdXBhY2lvbmFpcyBpZGVudGlmaWNhZG9zLlwiLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfSk7XHJcblxyXG50eXBlIEFnZW5kYXJGb3JtRGF0YSA9IHouaW5mZXI8dHlwZW9mIGFnZW5kYXJJbnNwZWNhb1NjaGVtYT47XHJcblxyXG5pbnRlcmZhY2UgQWdlbmRhckluc3BlY2FvTW9kYWxQcm9wcyB7XHJcbiAgaXNPcGVuOiBib29sZWFuO1xyXG4gIG9uQ2xvc2U6ICgpID0+IHZvaWQ7XHJcbiAgZXN0YWJlbGVjaW1lbnRvSWRQcmVEZWZpbmlkbz86IHN0cmluZztcclxuICBtb3Rpdm9QcmVEZWZpbmlkbz86IFRpcG9Nb3Rpdm9JbnNwZWNhbztcclxuICBvblN1Y2Vzc28/OiAoaW5zcGVjYW9DcmlhZGE6IGFueSkgPT4gdm9pZDtcclxufVxyXG5cclxuZXhwb3J0IGNvbnN0IEFnZW5kYXJJbnNwZWNhb01vZGFsOiBSZWFjdC5GQzxBZ2VuZGFySW5zcGVjYW9Nb2RhbFByb3BzPiA9ICh7XHJcbiAgaXNPcGVuLFxyXG4gIG9uQ2xvc2UsXHJcbiAgZXN0YWJlbGVjaW1lbnRvSWRQcmVEZWZpbmlkbyxcclxuICBtb3Rpdm9QcmVEZWZpbmlkbyxcclxuICBvblN1Y2Vzc28sXHJcbn0pID0+IHtcclxuICBjb25zdCB7IHVzZXIgfSA9IHVzZUF1dGgoKTtcclxuICBjb25zdCBbYnVzY2FFc3RhYmVsZWNpbWVudG8sIHNldEJ1c2NhRXN0YWJlbGVjaW1lbnRvXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IGFnZW5kYXJNdXRhdGlvbiA9IHVzZUFnZW5kYXJJbnNwZWNhb011dGF0aW9uKCk7XHJcblxyXG4gIGNvbnN0IHsgZGF0YTogZXN0YWJlbGVjaW1lbnRvc0RhdGEgfSA9IHVzZUVzdGFiZWxlY2ltZW50b3NMaXN0KHtcclxuICAgIGJ1c2NhOiBidXNjYUVzdGFiZWxlY2ltZW50byB8fCB1bmRlZmluZWQsXHJcbiAgICBsaW1pdDogMjAsXHJcbiAgICBzaXR1YWNhbzogXCJBdGl2b1wiLFxyXG4gIH0pO1xyXG5cclxuICBjb25zdCBob2plID0gbmV3IERhdGUoKS50b0lTT1N0cmluZygpLnNwbGl0KFwiVFwiKVswXTtcclxuICBjb25zdCB0ZXJtb0dlcmFkb1BhZHJhbyA9IGBURVJNLSR7bmV3IERhdGUoKS5nZXRGdWxsWWVhcigpfS0ke01hdGguZmxvb3IoXHJcbiAgICAxMDAwICsgTWF0aC5yYW5kb20oKSAqIDkwMDBcclxuICApfWA7XHJcblxyXG4gIGNvbnN0IHtcclxuICAgIHJlZ2lzdGVyLFxyXG4gICAgaGFuZGxlU3VibWl0LFxyXG4gICAgd2F0Y2gsXHJcbiAgICBzZXRWYWx1ZSxcclxuICAgIHJlc2V0LFxyXG4gICAgZm9ybVN0YXRlOiB7IGVycm9ycywgaXNTdWJtaXR0aW5nIH0sXHJcbiAgfSA9IHVzZUZvcm08QWdlbmRhckZvcm1EYXRhPih7XHJcbiAgICByZXNvbHZlcjogem9kUmVzb2x2ZXIoYWdlbmRhckluc3BlY2FvU2NoZW1hKSxcclxuICAgIGRlZmF1bHRWYWx1ZXM6IHtcclxuICAgICAgbnVtZXJvX3Rlcm1vOiB0ZXJtb0dlcmFkb1BhZHJhbyxcclxuICAgICAgZXN0YWJlbGVjaW1lbnRvX2lkOiBlc3RhYmVsZWNpbWVudG9JZFByZURlZmluaWRvIHx8IFwiXCIsXHJcbiAgICAgIGZpc2NhbF9yZXNwb25zYXZlbF9pZDogdXNlcj8uaWQgfHwgXCJcIixcclxuICAgICAgbW90aXZvOiBtb3Rpdm9QcmVEZWZpbmlkbyB8fCBcInJvdGluYV9wcm9ncmFtYWRhXCIsXHJcbiAgICAgIGRhdGFfaW5pY2lvOiBob2plLFxyXG4gICAgICBkYXRhX2FnZW5kYW1lbnRvOiBob2plLFxyXG4gICAgICBob3JhX2luc3BlY2FvOiBcIjA5OjAwXCIsXHJcbiAgICAgIGZpc2NhaXNfYWNvbXBhbmhhbnRlczogXCJcIixcclxuICAgICAgbm9tZV9sb2NhbF90cmFiYWxobzogXCJcIixcclxuICAgICAgcHJpbmNpcGFpc19yaXNjb3NfaWRlbnRpZmljYWRvczogXCJcIixcclxuICAgICAgcmVjb21lbmRhY29lc19vcmllbnRhY29lczogXCJcIixcclxuICAgIH0sXHJcbiAgfSk7XHJcblxyXG4gIGNvbnN0IG1vdGl2b1NlbGVjaW9uYWRvID0gd2F0Y2goXCJtb3Rpdm9cIik7XHJcbiAgY29uc3QgZXN0YWJlbGVjaW1lbnRvU2VsZWNpb25hZG9JZCA9IHdhdGNoKFwiZXN0YWJlbGVjaW1lbnRvX2lkXCIpO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgaWYgKGlzT3Blbikge1xyXG4gICAgICByZXNldCh7XHJcbiAgICAgICAgbnVtZXJvX3Rlcm1vOiBgVEVSTS0ke25ldyBEYXRlKCkuZ2V0RnVsbFllYXIoKX0tJHtNYXRoLmZsb29yKFxyXG4gICAgICAgICAgMTAwMCArIE1hdGgucmFuZG9tKCkgKiA5MDAwXHJcbiAgICAgICAgKX1gLFxyXG4gICAgICAgIGVzdGFiZWxlY2ltZW50b19pZDogZXN0YWJlbGVjaW1lbnRvSWRQcmVEZWZpbmlkbyB8fCBcIlwiLFxyXG4gICAgICAgIGZpc2NhbF9yZXNwb25zYXZlbF9pZDogdXNlcj8uaWQgfHwgXCJcIixcclxuICAgICAgICBtb3Rpdm86IG1vdGl2b1ByZURlZmluaWRvIHx8IFwicm90aW5hX3Byb2dyYW1hZGFcIixcclxuICAgICAgICBkYXRhX2luaWNpbzogaG9qZSxcclxuICAgICAgICBkYXRhX2FnZW5kYW1lbnRvOiBob2plLFxyXG4gICAgICAgIGhvcmFfaW5zcGVjYW86IFwiMDk6MDBcIixcclxuICAgICAgICBmaXNjYWlzX2Fjb21wYW5oYW50ZXM6IFwiXCIsXHJcbiAgICAgICAgbm9tZV9sb2NhbF90cmFiYWxobzogXCJcIixcclxuICAgICAgICBwcmluY2lwYWlzX3Jpc2Nvc19pZGVudGlmaWNhZG9zOiBcIlwiLFxyXG4gICAgICAgIHJlY29tZW5kYWNvZXNfb3JpZW50YWNvZXM6IFwiXCIsXHJcbiAgICAgIH0pO1xyXG4gICAgfVxyXG4gIH0sIFtpc09wZW4sIGVzdGFiZWxlY2ltZW50b0lkUHJlRGVmaW5pZG8sIG1vdGl2b1ByZURlZmluaWRvLCB1c2VyPy5pZCwgcmVzZXQsIGhvamVdKTtcclxuXHJcbiAgaWYgKCFpc09wZW4pIHJldHVybiBudWxsO1xyXG5cclxuICBjb25zdCBvblN1Ym1pdCA9IGFzeW5jIChkYXRhOiBBZ2VuZGFyRm9ybURhdGEpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IGNyaWFkYSA9IGF3YWl0IGFnZW5kYXJNdXRhdGlvbi5tdXRhdGVBc3luYyhcclxuICAgICAgICBkYXRhIGFzIEFnZW5kYXJJbnNwZWNhb0Zvcm1WYWx1ZXNcclxuICAgICAgKTtcclxuICAgICAgaWYgKG9uU3VjZXNzbykge1xyXG4gICAgICAgIG9uU3VjZXNzbyhjcmlhZGEpO1xyXG4gICAgICB9XHJcbiAgICAgIG9uQ2xvc2UoKTtcclxuICAgIH0gY2F0Y2ggKGVycjogYW55KSB7XHJcbiAgICAgIC8vIEVycm8gw6kgY2FwdHVyYWRvIHBlbG8gaG9vayBvdSB0cmF0YWRvIG5hIFVJXHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgZXN0YWJlbGVjaW1lbnRvT2JqID0gZXN0YWJlbGVjaW1lbnRvc0RhdGE/Lml0ZW5zLmZpbmQoXHJcbiAgICAoZSkgPT4gZS5pZCA9PT0gZXN0YWJlbGVjaW1lbnRvU2VsZWNpb25hZG9JZFxyXG4gICk7XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LTAgei01MCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBwLTQgYmctYmxhY2svNTAgYmFja2Ryb3AtYmx1ci14c1wiPlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIGRhcms6Ymctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLTJ4bCB3LWZ1bGwgbWF4LXctMnhsIG1heC1oLVs5MHZoXSBzaGFkb3ctMnhsIGZsZXggZmxleC1jb2wgb3ZlcmZsb3ctaGlkZGVuIGFuaW1hdGUtaW4gZmFkZS1pbiB6b29tLWluLTk1IGR1cmF0aW9uLTE1MFwiPlxyXG4gICAgICAgIHsvKiBDYWJlw6dhbGhvICovfVxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHgtNiBweS00IGJvcmRlci1iIGJvcmRlci1zbGF0ZS0xMDAgZGFyazpib3JkZXItc2xhdGUtODAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBiZy1zbGF0ZS01MC81MCBkYXJrOmJnLXNsYXRlLTgwMC80MFwiPlxyXG4gICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtYmFzZSBmb250LWJvbGQgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgPENhbGVuZGFyIGNsYXNzTmFtZT1cInctNSBoLTUgdGV4dC10ZWFsLTYwMCBkYXJrOnRleHQtdGVhbC00MDBcIiAvPlxyXG4gICAgICAgICAgICAgIDxzcGFuPk5vdmEgQcOnw6NvIEZpc2NhbGl6YXTDs3JpYSAvIFZpc3RvcmlhPC9zcGFuPlxyXG4gICAgICAgICAgICA8L2gyPlxyXG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNTAwIGRhcms6dGV4dC1zbGF0ZS00MDBcIj5cclxuICAgICAgICAgICAgICBBYmVydHVyYSBkZSB0ZXJtbyBvZmljaWFsIGRlIGluc3Blw6fDo28gb3UgYWdlbmRhbWVudG8gZGUgYcOnw6NvIGRlIGNhbXBvXHJcbiAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgb25DbGljaz17b25DbG9zZX1cclxuICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0xLjUgdGV4dC1zbGF0ZS00MDAgaG92ZXI6dGV4dC1zbGF0ZS02MDAgZGFyazpob3Zlcjp0ZXh0LXNsYXRlLTMwMCByb3VuZGVkLWxnIGhvdmVyOmJnLXNsYXRlLTEwMCBkYXJrOmhvdmVyOmJnLXNsYXRlLTgwMCB0cmFuc2l0aW9uLWNvbG9yc1wiXHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIDxYIGNsYXNzTmFtZT1cInctNSBoLTVcIiAvPlxyXG4gICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIHsvKiBDb3JwbyBjb20gc2Nyb2xsICovfVxyXG4gICAgICAgIDxmb3JtXHJcbiAgICAgICAgICBvblN1Ym1pdD17aGFuZGxlU3VibWl0KG9uU3VibWl0KX1cclxuICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXgtMSBvdmVyZmxvdy15LWF1dG8gcC02IHNwYWNlLXktNVwiXHJcbiAgICAgICAgPlxyXG4gICAgICAgICAge2FnZW5kYXJNdXRhdGlvbi5pc0Vycm9yICYmIChcclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTMgYmctcm9zZS01MCBkYXJrOmJnLXJvc2UtOTUwLzQwIGJvcmRlciBib3JkZXItcm9zZS0yMDAgZGFyazpib3JkZXItcm9zZS04MDAgcm91bmRlZC14bCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiB0ZXh0LXhzIHRleHQtcm9zZS03MDAgZGFyazp0ZXh0LXJvc2UtMzAwXCI+XHJcbiAgICAgICAgICAgICAgPEFsZXJ0VHJpYW5nbGUgY2xhc3NOYW1lPVwidy00IGgtNCBzaHJpbmstMFwiIC8+XHJcbiAgICAgICAgICAgICAgPHNwYW4+XHJcbiAgICAgICAgICAgICAgICB7YWdlbmRhck11dGF0aW9uLmVycm9yIGluc3RhbmNlb2YgRXJyb3JcclxuICAgICAgICAgICAgICAgICAgPyBhZ2VuZGFyTXV0YXRpb24uZXJyb3IubWVzc2FnZVxyXG4gICAgICAgICAgICAgICAgICA6IFwiRXJybyBhbyBhYnJpciB0ZXJtbyBkZSB2aXN0b3JpYSBzYW5pdMOhcmlhLlwifVxyXG4gICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgIHsvKiBEYWRvcyBkbyBUZXJtbyBlIE1vdGl2byAqL31cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBzbTpncmlkLWNvbHMtMiBnYXAtNFwiPlxyXG4gICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTMwMCBtYi0xXCI+XHJcbiAgICAgICAgICAgICAgICBOw7ptZXJvIGRvIFRlcm1vIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcm9zZS01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICB7Li4ucmVnaXN0ZXIoXCJudW1lcm9fdGVybW9cIil9XHJcbiAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkV4OiBURVJNLTIwMjYtMDA0MlwiXHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIHRleHQteHMgYmctc2xhdGUtNTAgZGFyazpiZy1zbGF0ZS04MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQtbGcgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlIGZvbnQtbW9ubyBwbGFjZWhvbGRlci1zbGF0ZS00MDAgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLXRlYWwtNTAwXCJcclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIHtlcnJvcnMubnVtZXJvX3Rlcm1vICYmIChcclxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtcm9zZS02MDAgbXQtMVwiPlxyXG4gICAgICAgICAgICAgICAgICB7ZXJyb3JzLm51bWVyb190ZXJtby5tZXNzYWdlfVxyXG4gICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0zMDAgbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgTW90aXZvIGRhIEZpc2NhbGl6YcOnw6NvIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcm9zZS01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPHNlbGVjdFxyXG4gICAgICAgICAgICAgICAgey4uLnJlZ2lzdGVyKFwibW90aXZvXCIpfVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMgcHktMiB0ZXh0LXhzIGJnLXNsYXRlLTUwIGRhcms6Ymctc2xhdGUtODAwIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCByb3VuZGVkLWxnIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZSBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctdGVhbC01MDBcIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIHtPYmplY3QuZW50cmllcyhNT1RJVk9TX0xBQkVMUykubWFwKChbdmFsb3IsIHJvdHVsb10pID0+IChcclxuICAgICAgICAgICAgICAgICAgPG9wdGlvbiBrZXk9e3ZhbG9yfSB2YWx1ZT17dmFsb3J9PlxyXG4gICAgICAgICAgICAgICAgICAgIHtyb3R1bG99XHJcbiAgICAgICAgICAgICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgPC9zZWxlY3Q+XHJcbiAgICAgICAgICAgICAge2Vycm9ycy5tb3Rpdm8gJiYgKFxyXG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1yb3NlLTYwMCBtdC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgIHtlcnJvcnMubW90aXZvLm1lc3NhZ2V9XHJcbiAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICB7LyogU2VsZcOnw6NvIGRvIEVzdGFiZWxlY2ltZW50byAqL31cclxuICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTMwMCBtYi0xXCI+XHJcbiAgICAgICAgICAgICAgRXN0YWJlbGVjaW1lbnRvIEFsdm8gPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yb3NlLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgIHtlc3RhYmVsZWNpbWVudG9JZFByZURlZmluaWRvICYmIGVzdGFiZWxlY2ltZW50b09iaiA/IChcclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMyBiZy1zbGF0ZS01MCBkYXJrOmJnLXNsYXRlLTgwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC14bCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxyXG4gICAgICAgICAgICAgICAgPEJ1aWxkaW5nMiBjbGFzc05hbWU9XCJ3LTUgaC01IHRleHQtdGVhbC02MDAgZGFyazp0ZXh0LXRlYWwtNDAwIHNocmluay0wXCIgLz5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xIG1pbi13LTBcIj5cclxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlIHRydW5jYXRlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge2VzdGFiZWxlY2ltZW50b09iai5yYXphb19zb2NpYWx9XHJcbiAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1zbGF0ZS01MDAgZGFyazp0ZXh0LXNsYXRlLTQwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIENOUEovQ1BGOiB7ZXN0YWJlbGVjaW1lbnRvT2JqLmNucGpfY3BmfSDigKIge2VzdGFiZWxlY2ltZW50b09iai5iYWlycm99XHJcbiAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yXCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxTZWFyY2ggY2xhc3NOYW1lPVwidy0zLjUgaC0zLjUgdGV4dC1zbGF0ZS00MDAgYWJzb2x1dGUgbGVmdC0zIHRvcC0yLjVcIiAvPlxyXG4gICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJGaWx0cmFyIHBvciBSYXrDo28gU29jaWFsLCBOb21lIEZhbnRhc2lhIG91IENOUEouLi5cIlxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtidXNjYUVzdGFiZWxlY2ltZW50b31cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEJ1c2NhRXN0YWJlbGVjaW1lbnRvKGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcGwtOCBwci0zIHB5LTEuNSB0ZXh0LXhzIGJnLXNsYXRlLTUwIGRhcms6Ymctc2xhdGUtODAwIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCByb3VuZGVkLWxnIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZSBwbGFjZWhvbGRlci1zbGF0ZS00MDAgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMSBmb2N1czpyaW5nLXRlYWwtNTAwXCJcclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPHNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICB7Li4ucmVnaXN0ZXIoXCJlc3RhYmVsZWNpbWVudG9faWRcIil9XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC0zIHB5LTIgdGV4dC14cyBiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTgwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC1sZyB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGUgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLXRlYWwtNTAwXCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlwiPlNlbGVjaW9uZSBvIGVzdGFiZWxlY2ltZW50by4uLjwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICB7ZXN0YWJlbGVjaW1lbnRvc0RhdGE/Lml0ZW5zLm1hcCgoZXN0KSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiBrZXk9e2VzdC5pZH0gdmFsdWU9e2VzdC5pZH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7ZXN0LnJhemFvX3NvY2lhbH0gKHtlc3QuY25wal9jcGZ9KSAtIHtlc3QuYmFpcnJvfSBbe2VzdC5uaXZlbF9yaXNjb31dXHJcbiAgICAgICAgICAgICAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgPC9zZWxlY3Q+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgIHtlcnJvcnMuZXN0YWJlbGVjaW1lbnRvX2lkICYmIChcclxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LXJvc2UtNjAwIG10LTFcIj5cclxuICAgICAgICAgICAgICAgIHtlcnJvcnMuZXN0YWJlbGVjaW1lbnRvX2lkLm1lc3NhZ2V9XHJcbiAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICApfVxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgey8qIERhdGFzIGUgSG9yw6FyaW9zICovfVxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIHNtOmdyaWQtY29scy0zIGdhcC00XCI+XHJcbiAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMzAwIG1iLTFcIj5cclxuICAgICAgICAgICAgICAgIERhdGEgZGUgQWJlcnR1cmEgLyBSZWFsaXphw6fDo28gPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yb3NlLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgIHR5cGU9XCJkYXRlXCJcclxuICAgICAgICAgICAgICAgIHsuLi5yZWdpc3RlcihcImRhdGFfaW5pY2lvXCIpfVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMgcHktMiB0ZXh0LXhzIGJnLXNsYXRlLTUwIGRhcms6Ymctc2xhdGUtODAwIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCByb3VuZGVkLWxnIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZSBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctdGVhbC01MDBcIlxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAge2Vycm9ycy5kYXRhX2luaWNpbyAmJiAoXHJcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LXJvc2UtNjAwIG10LTFcIj5cclxuICAgICAgICAgICAgICAgICAge2Vycm9ycy5kYXRhX2luaWNpby5tZXNzYWdlfVxyXG4gICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0zMDAgbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgRGF0YSBBZ2VuZGFkYSAoUHJldmlzw6NvKVxyXG4gICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICB0eXBlPVwiZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICB7Li4ucmVnaXN0ZXIoXCJkYXRhX2FnZW5kYW1lbnRvXCIpfVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMgcHktMiB0ZXh0LXhzIGJnLXNsYXRlLTUwIGRhcms6Ymctc2xhdGUtODAwIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCByb3VuZGVkLWxnIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZSBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctdGVhbC01MDBcIlxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0zMDAgbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgSG9yw6FyaW8gZGEgVmlzdG9yaWFcclxuICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmVcIj5cclxuICAgICAgICAgICAgICAgIDxDbG9jayBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNSB0ZXh0LXNsYXRlLTQwMCBhYnNvbHV0ZSBsZWZ0LTMgdG9wLTIuNVwiIC8+XHJcbiAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgdHlwZT1cInRpbWVcIlxyXG4gICAgICAgICAgICAgICAgICB7Li4ucmVnaXN0ZXIoXCJob3JhX2luc3BlY2FvXCIpfVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcGwtOCBwci0zIHB5LTIgdGV4dC14cyBiZy1zbGF0ZS01MCBkYXJrOmJnLXNsYXRlLTgwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC1sZyB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGUgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLXRlYWwtNTAwXCJcclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgey8qIEZpc2NhaXMgKi99XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgc206Z3JpZC1jb2xzLTIgZ2FwLTRcIj5cclxuICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0zMDAgbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgRmlzY2FsIFJlc3BvbnPDoXZlbCA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJvc2UtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgcC0yIGJnLXNsYXRlLTUwIGRhcms6Ymctc2xhdGUtODAwIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCByb3VuZGVkLWxnXCI+XHJcbiAgICAgICAgICAgICAgICA8VXNlckNoZWNrIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC10ZWFsLTYwMCBkYXJrOnRleHQtdGVhbC00MDAgc2hyaW5rLTBcIiAvPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LXNsYXRlLTgwMCBkYXJrOnRleHQtc2xhdGUtMjAwIHRydW5jYXRlXCI+XHJcbiAgICAgICAgICAgICAgICAgIHt1c2VyPy5ub21lX2NvbXBsZXRvIHx8IFwiRmlzY2FsIFJlc3BvbnPDoXZlbFwifVxyXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwiaGlkZGVuXCIgey4uLnJlZ2lzdGVyKFwiZmlzY2FsX3Jlc3BvbnNhdmVsX2lkXCIpfSAvPlxyXG4gICAgICAgICAgICAgIHtlcnJvcnMuZmlzY2FsX3Jlc3BvbnNhdmVsX2lkICYmIChcclxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtcm9zZS02MDAgbXQtMVwiPlxyXG4gICAgICAgICAgICAgICAgICB7ZXJyb3JzLmZpc2NhbF9yZXNwb25zYXZlbF9pZC5tZXNzYWdlfVxyXG4gICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0zMDAgbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgRmlzY2FpcyBBY29tcGFuaGFudGVzIC8gRXF1aXBlXHJcbiAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgIHsuLi5yZWdpc3RlcihcImZpc2NhaXNfYWNvbXBhbmhhbnRlc1wiKX1cclxuICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRXg6IEpvw6NvIGRhIFNpbHZhIChGaXNjYWwgU2FuaXTDoXJpbyBJSSlcIlxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMgcHktMiB0ZXh0LXhzIGJnLXNsYXRlLTUwIGRhcms6Ymctc2xhdGUtODAwIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCByb3VuZGVkLWxnIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZSBwbGFjZWhvbGRlci1zbGF0ZS00MDAgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLXRlYWwtNTAwXCJcclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIHsvKiBCTE9DTyBDT05ESUNJT05BTCBWQVBUIChJTkRJQ0FET1IgMTEpICovfVxyXG4gICAgICAgICAge21vdGl2b1NlbGVjaW9uYWRvID09PSBcInZhcHRfdHJhYmFsaGFkb3JcIiAmJiAoXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC00IGJnLXRlYWwtNTAvNjAgZGFyazpiZy10ZWFsLTk1MC8zMCBib3JkZXIgYm9yZGVyLXRlYWwtMjAwIGRhcms6Ym9yZGVyLXRlYWwtODAwLzgwIHJvdW5kZWQteGwgc3BhY2UteS0zIGFuaW1hdGUtaW4gZmFkZS1pbiBkdXJhdGlvbi0yMDBcIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRleHQtdGVhbC04MDAgZGFyazp0ZXh0LXRlYWwtMzAwXCI+XHJcbiAgICAgICAgICAgICAgICA8SGFyZEhhdCBjbGFzc05hbWU9XCJ3LTQgaC00IHNocmluay0wIHRleHQtdGVhbC02MDAgZGFyazp0ZXh0LXRlYWwtNDAwXCIgLz5cclxuICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXJcIj5cclxuICAgICAgICAgICAgICAgICAgTcOzZHVsbyBWQVBUIC0gVmlnaWzDom5jaWEgZW0gQW1iaWVudGVzIGUgUHJvY2Vzc29zIGRlIFRyYWJhbGhvIChJbmRpY2Fkb3IgMTEpXHJcbiAgICAgICAgICAgICAgICA8L2gzPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtdGVhbC03MDAvODAgZGFyazp0ZXh0LXRlYWwtNDAwXCI+XHJcbiAgICAgICAgICAgICAgICBBw6fDo28gY29tIGZvY28gbmEgc2HDumRlLCBzZWd1cmFuw6dhIGUgZXJnb25vbWlhIGRvIHRyYWJhbGhhZG9yIG5vIGFtYmllbnRlIG9jdXBhY2lvbmFsLlxyXG4gICAgICAgICAgICAgIDwvcD5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTMwMCBtYi0xXCI+XHJcbiAgICAgICAgICAgICAgICAgIFNldG9yIC8gUG9zdG8gZGUgVHJhYmFsaG8gVmlzdG9yaWFkbyA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJvc2UtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICB7Li4ucmVnaXN0ZXIoXCJub21lX2xvY2FsX3RyYWJhbGhvXCIpfVxyXG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkV4OiBMaW5oYSBkZSBlbnZhc2UsIGNvemluaGEgaW5kdXN0cmlhbCwgZXN0b3F1ZSBkZSBxdcOtbWljb3MuLi5cIlxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIHRleHQteHMgYmctd2hpdGUgZGFyazpiZy1zbGF0ZS04MDAgYm9yZGVyIGJvcmRlci10ZWFsLTMwMCBkYXJrOmJvcmRlci10ZWFsLTcwMCByb3VuZGVkLWxnIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZSBwbGFjZWhvbGRlci1zbGF0ZS00MDAgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLXRlYWwtNTAwXCJcclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICB7ZXJyb3JzLm5vbWVfbG9jYWxfdHJhYmFsaG8gJiYgKFxyXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LXJvc2UtNjAwIG10LTFcIj5cclxuICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLm5vbWVfbG9jYWxfdHJhYmFsaG8ubWVzc2FnZX1cclxuICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTMwMCBtYi0xXCI+XHJcbiAgICAgICAgICAgICAgICAgIFByaW5jaXBhaXMgUmlzY29zIE9jdXBhY2lvbmFpcyBJZGVudGlmaWNhZG9zIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcm9zZS01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIDx0ZXh0YXJlYVxyXG4gICAgICAgICAgICAgICAgICByb3dzPXsyfVxyXG4gICAgICAgICAgICAgICAgICB7Li4ucmVnaXN0ZXIoXCJwcmluY2lwYWlzX3Jpc2Nvc19pZGVudGlmaWNhZG9zXCIpfVxyXG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkV4OiBSaXNjbyBlcmdvbsO0bWljbyBwb3IgbGV2YW50YW1lbnRvIGRlIHBlc28gcmVwZXRpdGl2bywgcmlzY28gZsOtc2ljbyBkZSBydcOtZG8gZWxldmFkbyBzZW0gcHJvdGV0b3IgYXVyaWN1bGFyLi4uXCJcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMgcHktMiB0ZXh0LXhzIGJnLXdoaXRlIGRhcms6Ymctc2xhdGUtODAwIGJvcmRlciBib3JkZXItdGVhbC0zMDAgZGFyazpib3JkZXItdGVhbC03MDAgcm91bmRlZC1sZyB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGUgcGxhY2Vob2xkZXItc2xhdGUtNDAwIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy10ZWFsLTUwMFwiXHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAge2Vycm9ycy5wcmluY2lwYWlzX3Jpc2Nvc19pZGVudGlmaWNhZG9zICYmIChcclxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1yb3NlLTYwMCBtdC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5wcmluY2lwYWlzX3Jpc2Nvc19pZGVudGlmaWNhZG9zLm1lc3NhZ2V9XHJcbiAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0zMDAgbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgICBSZWNvbWVuZGHDp8O1ZXMgZSBPcmllbnRhw6fDtWVzIFTDqWNuaWNhcyBhbyBFbXByZWdhZG9yXHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgPHRleHRhcmVhXHJcbiAgICAgICAgICAgICAgICAgIHJvd3M9ezJ9XHJcbiAgICAgICAgICAgICAgICAgIHsuLi5yZWdpc3RlcihcInJlY29tZW5kYWNvZXNfb3JpZW50YWNvZXNcIil9XHJcbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiT3JpZW50YcOnw7VlcyBwcmVsaW1pbmFyZXMgZGUgYWRlcXVhw6fDo28gZXJnb27DtG1pY2Egb3UgZm9ybmVjaW1lbnRvIGRlIEVQSXMuLi5cIlxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIHRleHQteHMgYmctd2hpdGUgZGFyazpiZy1zbGF0ZS04MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQtbGcgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlIHBsYWNlaG9sZGVyLXNsYXRlLTQwMCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctdGVhbC01MDBcIlxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgIHsvKiBCb3TDtWVzIGRlIEHDp8OjbyAqL31cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1lbmQgZ2FwLTMgcHQtNCBib3JkZXItdCBib3JkZXItc2xhdGUtMTAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMFwiPlxyXG4gICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgb25DbGljaz17b25DbG9zZX1cclxuICAgICAgICAgICAgICBkaXNhYmxlZD17aXNTdWJtaXR0aW5nfVxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTQgcHktMiB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS02MDAgZGFyazp0ZXh0LXNsYXRlLTMwMCBob3ZlcjpiZy1zbGF0ZS0xMDAgZGFyazpob3ZlcjpiZy1zbGF0ZS04MDAgcm91bmRlZC1sZyB0cmFuc2l0aW9uLWNvbG9yc1wiXHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICBDYW5jZWxhclxyXG4gICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxyXG4gICAgICAgICAgICAgIGRpc2FibGVkPXtpc1N1Ym1pdHRpbmd9XHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNSBweS0yIHRleHQteHMgZm9udC1ib2xkIHRleHQtd2hpdGUgYmctdGVhbC02MDAgaG92ZXI6YmctdGVhbC03MDAgcm91bmRlZC1sZyBzaGFkb3cteHMgdHJhbnNpdGlvbi1jb2xvcnMgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgZGlzYWJsZWQ6b3BhY2l0eS02MFwiXHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICB7aXNTdWJtaXR0aW5nID8gKFxyXG4gICAgICAgICAgICAgICAgPHNwYW4+U2FsdmFuZG8gVGVybW8uLi48L3NwYW4+XHJcbiAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgIDxzcGFuPkFicmlyIC8gQWdlbmRhciBUZXJtbzwvc3Bhbj5cclxuICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZm9ybT5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgQWdlbmRhckluc3BlY2FvTW9kYWw7XHJcbiJdfQ==