import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ouvidoria/StatusDenunciaBadge.tsx");const React = __vite__cjsImport0_react;const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];/**
* Badge Semântico para Status de Tramitação da Denúncia
*/
import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=0fd2848a";
import { Archive, CheckCircle2, Clock, FileSearch, Hourglass, ShieldAlert, XCircle } from "/node_modules/.vite/deps/lucide-react.js?v=0fd2848a";
var _jsxFileName = "E:/Projetos VSCODE/visa_braunas/src/components/ouvidoria/StatusDenunciaBadge.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=0fd2848a";
const STATUS_CONFIGS = {
	recebida: {
		label: "Recebida",
		bgClass: "bg-amber-50 dark:bg-amber-950/40",
		textClass: "text-amber-700 dark:text-amber-300",
		borderClass: "border-amber-200 dark:border-amber-800",
		icon: Hourglass
	},
	em_analise: {
		label: "Em Triagem",
		bgClass: "bg-sky-50 dark:bg-sky-950/40",
		textClass: "text-sky-700 dark:text-sky-300",
		borderClass: "border-sky-200 dark:border-sky-800",
		icon: FileSearch
	},
	em_triagem: {
		label: "Em Triagem",
		bgClass: "bg-sky-50 dark:bg-sky-950/40",
		textClass: "text-sky-700 dark:text-sky-300",
		borderClass: "border-sky-200 dark:border-sky-800",
		icon: FileSearch
	},
	em_apuracao_fiscal: {
		label: "Em Apuração Fiscal",
		bgClass: "bg-indigo-50 dark:bg-indigo-950/40",
		textClass: "text-indigo-700 dark:text-indigo-300",
		borderClass: "border-indigo-200 dark:border-indigo-800",
		icon: Clock
	},
	despachada_inspecao: {
		label: "Despachada para Fiscalização",
		bgClass: "bg-indigo-50 dark:bg-indigo-950/40",
		textClass: "text-indigo-700 dark:text-indigo-300",
		borderClass: "border-indigo-200 dark:border-indigo-800",
		icon: Clock
	},
	procedente: {
		label: "Procedente",
		bgClass: "bg-emerald-50 dark:bg-emerald-950/40",
		textClass: "text-emerald-700 dark:text-emerald-300",
		borderClass: "border-emerald-200 dark:border-emerald-800",
		icon: CheckCircle2
	},
	concluida: {
		label: "Concluída",
		bgClass: "bg-emerald-50 dark:bg-emerald-950/40",
		textClass: "text-emerald-700 dark:text-emerald-300",
		borderClass: "border-emerald-200 dark:border-emerald-800",
		icon: CheckCircle2
	},
	improcedente: {
		label: "Improcedente",
		bgClass: "bg-slate-100 dark:bg-slate-800",
		textClass: "text-slate-700 dark:text-slate-300",
		borderClass: "border-slate-200 dark:border-slate-700",
		icon: XCircle
	},
	arquivada: {
		label: "Arquivada",
		bgClass: "bg-slate-100 dark:bg-slate-800/80",
		textClass: "text-slate-600 dark:text-slate-400",
		borderClass: "border-slate-200 dark:border-slate-700",
		icon: Archive
	},
	arquivada_improcedente: {
		label: "Arquivada (Improcedente)",
		bgClass: "bg-slate-100 dark:bg-slate-800/80",
		textClass: "text-slate-600 dark:text-slate-400",
		borderClass: "border-slate-200 dark:border-slate-700",
		icon: Archive
	}
};
export const StatusDenunciaBadge = ({ status, className = "" }) => {
	const normalizado = (status || "recebida").toLowerCase().trim();
	const config = STATUS_CONFIGS[normalizado] || {
		label: status,
		bgClass: "bg-slate-100 dark:bg-slate-800",
		textClass: "text-slate-700 dark:text-slate-300",
		borderClass: "border-slate-200 dark:border-slate-700",
		icon: ShieldAlert
	};
	const Icon = config.icon;
	return /* @__PURE__ */ _jsxDEV("span", {
		className: `inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-semibold border ${config.bgClass} ${config.textClass} ${config.borderClass} ${className}`,
		children: [/* @__PURE__ */ _jsxDEV(Icon, { className: "w-3 h-3 shrink-0" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 122,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("span", { children: config.label }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 123,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 119,
		columnNumber: 5
	}, this);
};
_c = StatusDenunciaBadge;
export default StatusDenunciaBadge;
var _c;
$RefreshReg$(_c, "StatusDenunciaBadge");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/ouvidoria/StatusDenunciaBadge.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("E:/Projetos VSCODE/visa_braunas/src/components/ouvidoria/StatusDenunciaBadge.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("E:/Projetos VSCODE/visa_braunas/src/components/ouvidoria/StatusDenunciaBadge.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "E:/Projetos VSCODE/visa_braunas/src/components/ouvidoria/StatusDenunciaBadge.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7O0FBSUEsT0FBTyxXQUFXO0FBQ2xCLFNBQ0UsU0FDQSxjQUNBLE9BQ0EsWUFDQSxXQUNBLGFBQ0EsZUFDSzs7O0FBZ0JQLE1BQU0saUJBQThDO0NBQ2xELFVBQVU7RUFDUixPQUFPO0VBQ1AsU0FBUztFQUNULFdBQVc7RUFDWCxhQUFhO0VBQ2IsTUFBTTtDQUNSO0NBQ0EsWUFBWTtFQUNWLE9BQU87RUFDUCxTQUFTO0VBQ1QsV0FBVztFQUNYLGFBQWE7RUFDYixNQUFNO0NBQ1I7Q0FDQSxZQUFZO0VBQ1YsT0FBTztFQUNQLFNBQVM7RUFDVCxXQUFXO0VBQ1gsYUFBYTtFQUNiLE1BQU07Q0FDUjtDQUNBLG9CQUFvQjtFQUNsQixPQUFPO0VBQ1AsU0FBUztFQUNULFdBQVc7RUFDWCxhQUFhO0VBQ2IsTUFBTTtDQUNSO0NBQ0EscUJBQXFCO0VBQ25CLE9BQU87RUFDUCxTQUFTO0VBQ1QsV0FBVztFQUNYLGFBQWE7RUFDYixNQUFNO0NBQ1I7Q0FDQSxZQUFZO0VBQ1YsT0FBTztFQUNQLFNBQVM7RUFDVCxXQUFXO0VBQ1gsYUFBYTtFQUNiLE1BQU07Q0FDUjtDQUNBLFdBQVc7RUFDVCxPQUFPO0VBQ1AsU0FBUztFQUNULFdBQVc7RUFDWCxhQUFhO0VBQ2IsTUFBTTtDQUNSO0NBQ0EsY0FBYztFQUNaLE9BQU87RUFDUCxTQUFTO0VBQ1QsV0FBVztFQUNYLGFBQWE7RUFDYixNQUFNO0NBQ1I7Q0FDQSxXQUFXO0VBQ1QsT0FBTztFQUNQLFNBQVM7RUFDVCxXQUFXO0VBQ1gsYUFBYTtFQUNiLE1BQU07Q0FDUjtDQUNBLHdCQUF3QjtFQUN0QixPQUFPO0VBQ1AsU0FBUztFQUNULFdBQVc7RUFDWCxhQUFhO0VBQ2IsTUFBTTtDQUNSO0FBQ0Y7QUFFQSxPQUFPLE1BQU0sdUJBQTJELEVBQ3RFLFFBQ0EsWUFBWSxTQUNSO0NBQ0osTUFBTSxlQUFlLFVBQVUsV0FBVSxDQUFFLFlBQVksQ0FBQyxDQUFDLEtBQUs7Q0FDOUQsTUFBTSxTQUFTLGVBQWUsZ0JBQWdCO0VBQzVDLE9BQU87RUFDUCxTQUFTO0VBQ1QsV0FBVztFQUNYLGFBQWE7RUFDYixNQUFNO0NBQ1I7Q0FFQSxNQUFNLE9BQU8sT0FBTztDQUVwQixPQUNFLHdCQUFDLFFBQUQ7RUFDRSxXQUFXLGdHQUFnRyxPQUFPLFFBQVEsR0FBRyxPQUFPLFVBQVUsR0FBRyxPQUFPLFlBQVksR0FBRztZQUR6SyxDQUdFLHdCQUFDLE1BQUQsRUFBTSxXQUFVLG1CQUFvQjs7OztZQUNwQyx3QkFBQyxRQUFELFlBQU8sT0FBTyxNQUFZOzs7O1VBQ3RCOzs7Ozs7QUFFVjs7QUFFQSxlQUFlIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIlN0YXR1c0RlbnVuY2lhQmFkZ2UudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbIi8qKlxyXG4gKiBCYWRnZSBTZW3Dom50aWNvIHBhcmEgU3RhdHVzIGRlIFRyYW1pdGHDp8OjbyBkYSBEZW7Dum5jaWFcclxuICovXHJcblxyXG5pbXBvcnQgUmVhY3QgZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7XHJcbiAgQXJjaGl2ZSxcclxuICBDaGVja0NpcmNsZTIsXHJcbiAgQ2xvY2ssXHJcbiAgRmlsZVNlYXJjaCxcclxuICBIb3VyZ2xhc3MsXHJcbiAgU2hpZWxkQWxlcnQsXHJcbiAgWENpcmNsZSxcclxufSBmcm9tIFwibHVjaWRlLXJlYWN0XCI7XHJcbmltcG9ydCB7IFN0YXR1c0RlbnVuY2lhIH0gZnJvbSBcIi4uLy4uL3R5cGVzL291dmlkb3JpYVwiO1xyXG5cclxuaW50ZXJmYWNlIFN0YXR1c0RlbnVuY2lhQmFkZ2VQcm9wcyB7XHJcbiAgc3RhdHVzOiBTdGF0dXNEZW51bmNpYSB8IHN0cmluZztcclxuICBjbGFzc05hbWU/OiBzdHJpbmc7XHJcbn1cclxuXHJcbmludGVyZmFjZSBCYWRnZUNvbmZpZyB7XHJcbiAgbGFiZWw6IHN0cmluZztcclxuICBiZ0NsYXNzOiBzdHJpbmc7XHJcbiAgdGV4dENsYXNzOiBzdHJpbmc7XHJcbiAgYm9yZGVyQ2xhc3M6IHN0cmluZztcclxuICBpY29uOiBSZWFjdC5Db21wb25lbnRUeXBlPHsgY2xhc3NOYW1lPzogc3RyaW5nIH0+O1xyXG59XHJcblxyXG5jb25zdCBTVEFUVVNfQ09ORklHUzogUmVjb3JkPHN0cmluZywgQmFkZ2VDb25maWc+ID0ge1xyXG4gIHJlY2ViaWRhOiB7XHJcbiAgICBsYWJlbDogXCJSZWNlYmlkYVwiLFxyXG4gICAgYmdDbGFzczogXCJiZy1hbWJlci01MCBkYXJrOmJnLWFtYmVyLTk1MC80MFwiLFxyXG4gICAgdGV4dENsYXNzOiBcInRleHQtYW1iZXItNzAwIGRhcms6dGV4dC1hbWJlci0zMDBcIixcclxuICAgIGJvcmRlckNsYXNzOiBcImJvcmRlci1hbWJlci0yMDAgZGFyazpib3JkZXItYW1iZXItODAwXCIsXHJcbiAgICBpY29uOiBIb3VyZ2xhc3MsXHJcbiAgfSxcclxuICBlbV9hbmFsaXNlOiB7XHJcbiAgICBsYWJlbDogXCJFbSBUcmlhZ2VtXCIsXHJcbiAgICBiZ0NsYXNzOiBcImJnLXNreS01MCBkYXJrOmJnLXNreS05NTAvNDBcIixcclxuICAgIHRleHRDbGFzczogXCJ0ZXh0LXNreS03MDAgZGFyazp0ZXh0LXNreS0zMDBcIixcclxuICAgIGJvcmRlckNsYXNzOiBcImJvcmRlci1za3ktMjAwIGRhcms6Ym9yZGVyLXNreS04MDBcIixcclxuICAgIGljb246IEZpbGVTZWFyY2gsXHJcbiAgfSxcclxuICBlbV90cmlhZ2VtOiB7XHJcbiAgICBsYWJlbDogXCJFbSBUcmlhZ2VtXCIsXHJcbiAgICBiZ0NsYXNzOiBcImJnLXNreS01MCBkYXJrOmJnLXNreS05NTAvNDBcIixcclxuICAgIHRleHRDbGFzczogXCJ0ZXh0LXNreS03MDAgZGFyazp0ZXh0LXNreS0zMDBcIixcclxuICAgIGJvcmRlckNsYXNzOiBcImJvcmRlci1za3ktMjAwIGRhcms6Ym9yZGVyLXNreS04MDBcIixcclxuICAgIGljb246IEZpbGVTZWFyY2gsXHJcbiAgfSxcclxuICBlbV9hcHVyYWNhb19maXNjYWw6IHtcclxuICAgIGxhYmVsOiBcIkVtIEFwdXJhw6fDo28gRmlzY2FsXCIsXHJcbiAgICBiZ0NsYXNzOiBcImJnLWluZGlnby01MCBkYXJrOmJnLWluZGlnby05NTAvNDBcIixcclxuICAgIHRleHRDbGFzczogXCJ0ZXh0LWluZGlnby03MDAgZGFyazp0ZXh0LWluZGlnby0zMDBcIixcclxuICAgIGJvcmRlckNsYXNzOiBcImJvcmRlci1pbmRpZ28tMjAwIGRhcms6Ym9yZGVyLWluZGlnby04MDBcIixcclxuICAgIGljb246IENsb2NrLFxyXG4gIH0sXHJcbiAgZGVzcGFjaGFkYV9pbnNwZWNhbzoge1xyXG4gICAgbGFiZWw6IFwiRGVzcGFjaGFkYSBwYXJhIEZpc2NhbGl6YcOnw6NvXCIsXHJcbiAgICBiZ0NsYXNzOiBcImJnLWluZGlnby01MCBkYXJrOmJnLWluZGlnby05NTAvNDBcIixcclxuICAgIHRleHRDbGFzczogXCJ0ZXh0LWluZGlnby03MDAgZGFyazp0ZXh0LWluZGlnby0zMDBcIixcclxuICAgIGJvcmRlckNsYXNzOiBcImJvcmRlci1pbmRpZ28tMjAwIGRhcms6Ym9yZGVyLWluZGlnby04MDBcIixcclxuICAgIGljb246IENsb2NrLFxyXG4gIH0sXHJcbiAgcHJvY2VkZW50ZToge1xyXG4gICAgbGFiZWw6IFwiUHJvY2VkZW50ZVwiLFxyXG4gICAgYmdDbGFzczogXCJiZy1lbWVyYWxkLTUwIGRhcms6YmctZW1lcmFsZC05NTAvNDBcIixcclxuICAgIHRleHRDbGFzczogXCJ0ZXh0LWVtZXJhbGQtNzAwIGRhcms6dGV4dC1lbWVyYWxkLTMwMFwiLFxyXG4gICAgYm9yZGVyQ2xhc3M6IFwiYm9yZGVyLWVtZXJhbGQtMjAwIGRhcms6Ym9yZGVyLWVtZXJhbGQtODAwXCIsXHJcbiAgICBpY29uOiBDaGVja0NpcmNsZTIsXHJcbiAgfSxcclxuICBjb25jbHVpZGE6IHtcclxuICAgIGxhYmVsOiBcIkNvbmNsdcOtZGFcIixcclxuICAgIGJnQ2xhc3M6IFwiYmctZW1lcmFsZC01MCBkYXJrOmJnLWVtZXJhbGQtOTUwLzQwXCIsXHJcbiAgICB0ZXh0Q2xhc3M6IFwidGV4dC1lbWVyYWxkLTcwMCBkYXJrOnRleHQtZW1lcmFsZC0zMDBcIixcclxuICAgIGJvcmRlckNsYXNzOiBcImJvcmRlci1lbWVyYWxkLTIwMCBkYXJrOmJvcmRlci1lbWVyYWxkLTgwMFwiLFxyXG4gICAgaWNvbjogQ2hlY2tDaXJjbGUyLFxyXG4gIH0sXHJcbiAgaW1wcm9jZWRlbnRlOiB7XHJcbiAgICBsYWJlbDogXCJJbXByb2NlZGVudGVcIixcclxuICAgIGJnQ2xhc3M6IFwiYmctc2xhdGUtMTAwIGRhcms6Ymctc2xhdGUtODAwXCIsXHJcbiAgICB0ZXh0Q2xhc3M6IFwidGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTMwMFwiLFxyXG4gICAgYm9yZGVyQ2xhc3M6IFwiYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDBcIixcclxuICAgIGljb246IFhDaXJjbGUsXHJcbiAgfSxcclxuICBhcnF1aXZhZGE6IHtcclxuICAgIGxhYmVsOiBcIkFycXVpdmFkYVwiLFxyXG4gICAgYmdDbGFzczogXCJiZy1zbGF0ZS0xMDAgZGFyazpiZy1zbGF0ZS04MDAvODBcIixcclxuICAgIHRleHRDbGFzczogXCJ0ZXh0LXNsYXRlLTYwMCBkYXJrOnRleHQtc2xhdGUtNDAwXCIsXHJcbiAgICBib3JkZXJDbGFzczogXCJib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMFwiLFxyXG4gICAgaWNvbjogQXJjaGl2ZSxcclxuICB9LFxyXG4gIGFycXVpdmFkYV9pbXByb2NlZGVudGU6IHtcclxuICAgIGxhYmVsOiBcIkFycXVpdmFkYSAoSW1wcm9jZWRlbnRlKVwiLFxyXG4gICAgYmdDbGFzczogXCJiZy1zbGF0ZS0xMDAgZGFyazpiZy1zbGF0ZS04MDAvODBcIixcclxuICAgIHRleHRDbGFzczogXCJ0ZXh0LXNsYXRlLTYwMCBkYXJrOnRleHQtc2xhdGUtNDAwXCIsXHJcbiAgICBib3JkZXJDbGFzczogXCJib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMFwiLFxyXG4gICAgaWNvbjogQXJjaGl2ZSxcclxuICB9LFxyXG59O1xyXG5cclxuZXhwb3J0IGNvbnN0IFN0YXR1c0RlbnVuY2lhQmFkZ2U6IFJlYWN0LkZDPFN0YXR1c0RlbnVuY2lhQmFkZ2VQcm9wcz4gPSAoe1xyXG4gIHN0YXR1cyxcclxuICBjbGFzc05hbWUgPSBcIlwiLFxyXG59KSA9PiB7XHJcbiAgY29uc3Qgbm9ybWFsaXphZG8gPSAoc3RhdHVzIHx8IFwicmVjZWJpZGFcIikudG9Mb3dlckNhc2UoKS50cmltKCk7XHJcbiAgY29uc3QgY29uZmlnID0gU1RBVFVTX0NPTkZJR1Nbbm9ybWFsaXphZG9dIHx8IHtcclxuICAgIGxhYmVsOiBzdGF0dXMsXHJcbiAgICBiZ0NsYXNzOiBcImJnLXNsYXRlLTEwMCBkYXJrOmJnLXNsYXRlLTgwMFwiLFxyXG4gICAgdGV4dENsYXNzOiBcInRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0zMDBcIixcclxuICAgIGJvcmRlckNsYXNzOiBcImJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtNzAwXCIsXHJcbiAgICBpY29uOiBTaGllbGRBbGVydCxcclxuICB9O1xyXG5cclxuICBjb25zdCBJY29uID0gY29uZmlnLmljb247XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8c3BhblxyXG4gICAgICBjbGFzc05hbWU9e2BpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBweC0yLjUgcHktMC41IHJvdW5kZWQtZnVsbCB0ZXh0LVsxMXB4XSBmb250LXNlbWlib2xkIGJvcmRlciAke2NvbmZpZy5iZ0NsYXNzfSAke2NvbmZpZy50ZXh0Q2xhc3N9ICR7Y29uZmlnLmJvcmRlckNsYXNzfSAke2NsYXNzTmFtZX1gfVxyXG4gICAgPlxyXG4gICAgICA8SWNvbiBjbGFzc05hbWU9XCJ3LTMgaC0zIHNocmluay0wXCIgLz5cclxuICAgICAgPHNwYW4+e2NvbmZpZy5sYWJlbH08L3NwYW4+XHJcbiAgICA8L3NwYW4+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IFN0YXR1c0RlbnVuY2lhQmFkZ2U7XHJcbiJdfQ==