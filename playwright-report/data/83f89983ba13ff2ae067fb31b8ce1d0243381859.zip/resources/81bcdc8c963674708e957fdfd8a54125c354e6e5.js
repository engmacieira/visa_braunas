import { n as __exportAll } from "/node_modules/.vite/deps/rolldown-runtime-SbdDWaPq.js?v=0fd2848a";
// node_modules/axios/lib/helpers/bind.js
/**
* Create a bound version of a function with a specified `this` context
*
* @param {Function} fn - The function to bind
* @param {*} thisArg - The value to be passed as the `this` parameter
* @returns {Function} A new function that will call the original function with the specified `this` context
*/
function bind(fn, thisArg) {
	return function wrap() {
		return fn.apply(thisArg, arguments);
	};
}
// node_modules/axios/lib/utils.js
var { toString } = Object.prototype;
var { getPrototypeOf } = Object;
var { iterator, toStringTag } = Symbol;
var hasOwnProperty = (({ hasOwnProperty }) => (obj, prop) => hasOwnProperty.call(obj, prop))(Object.prototype);
var isUnsafeObjectKey = (prop) => typeof prop === "string" && (prop === "__proto__" || prop === "constructor" || prop === "prototype");
/**
* Determine whether an inherited object must be treated as a shared-prototype
* boundary. Cross-realm Object.prototype objects cannot be distinguished
* reliably from application-created null-prototype objects because their
* properties are mutable, so all inherited terminal prototypes are excluded
* as a fail-closed boundary. A null-prototype source still keeps its own
* properties, as produced by mergeConfig and other safe materialization paths.
*
* @param {*} obj The object to inspect
* @param {*} prototype The object's prototype
* @param {boolean} source Whether obj is the original traversal source
*
* @returns {boolean} True when obj is a safe prototype traversal boundary
*/
var isPrototypeBoundary = (obj, prototype, source) => obj === Object.prototype || !source && prototype === null;
/**
* Determine whether an object can retain its identity through code paths that
* add, replace, and remove config properties without bypassing unsafe-key
* filtering. Immutable objects, unsafe-key-bearing objects, and objects with
* accessor or restricted data properties must be materialized instead.
*
* @param {*} obj The object to inspect
*
* @returns {boolean} True when every own property is safe and fully mutable
*/
var isSafeAndFullyMutable = (obj) => {
	if (!Object.isExtensible(obj)) return false;
	const props = Object.getOwnPropertyNames(obj);
	if (Object.getOwnPropertySymbols) props.push(...Object.getOwnPropertySymbols(obj));
	return props.every((prop) => {
		if (isUnsafeObjectKey(prop)) return false;
		const descriptor = Object.getOwnPropertyDescriptor(obj, prop);
		return !!descriptor && descriptor.configurable && descriptor.writable === true;
	});
};
/**
* Walk the prototype chain (excluding the source realm's Object.prototype)
* looking for an own `prop`. This distinguishes genuine own/inherited members
* — including class accessors and template prototypes — from members injected
* via Object.prototype pollution (e.g. `Object.prototype.username = '...'`),
* which live on Object.prototype itself and are therefore never matched.
*
* @param {*} thing The value whose chain to inspect
* @param {string|symbol} prop The property key to look for
*
* @returns {boolean} True when `prop` is owned below Object.prototype
*/
var hasOwnInPrototypeChain = (thing, prop) => {
	let obj = thing;
	const seen = [];
	while (obj != null) {
		if (seen.indexOf(obj) !== -1) return false;
		seen.push(obj);
		const prototype = getPrototypeOf(obj);
		if (isPrototypeBoundary(obj, prototype, obj === thing)) return false;
		if (hasOwnProperty(obj, prop)) return true;
		obj = prototype;
	}
	return false;
};
/**
* Read `obj[prop]` only when it is safe from Object.prototype pollution. Own
* properties and members inherited from a non-Object.prototype source (a class
* instance or template object) are honored; a value reachable only through a
* polluted Object.prototype is ignored and `undefined` is returned.
*
* @param {*} obj The source object
* @param {string|symbol} prop The property key to read
*
* @returns {*} The resolved value, or undefined when unsafe/absent
*/
var getSafeProp = (obj, prop) => obj != null && hasOwnInPrototypeChain(obj, prop) ? obj[prop] : void 0;
/**
* Flatten an object and its application-defined prototype chain into a
* null-prototype object. Members inherited only from the source realm's
* Object.prototype are deliberately excluded, while class/template members
* below that boundary are preserved.
*
* @param {*} thing The value to flatten
*
* @returns {*} A null-prototype copy, or the original value when it is already
* structurally safe or is not an object
*/
var toSafeFlatObject = (thing) => {
	if (thing == null || typeof thing !== "object" && typeof thing !== "function") return thing;
	const sourcePrototype = getPrototypeOf(thing);
	if (sourcePrototype === null && isSafeAndFullyMutable(thing)) return thing;
	const result = Object.create(null);
	const merged = Object.create(null);
	const seen = [];
	let current = thing;
	while (current != null) {
		if (seen.indexOf(current) !== -1) break;
		seen.push(current);
		const prototype = current === thing ? sourcePrototype : getPrototypeOf(current);
		if (isPrototypeBoundary(current, prototype, current === thing)) break;
		const props = Object.getOwnPropertyNames(current);
		if (Object.getOwnPropertySymbols) props.push(...Object.getOwnPropertySymbols(current));
		for (const prop of props) {
			if (isUnsafeObjectKey(prop)) continue;
			if (!hasOwnProperty(merged, prop)) {
				result[prop] = thing[prop];
				merged[prop] = true;
			}
		}
		current = prototype;
	}
	return result;
};
var kindOf = ((cache) => (thing) => {
	const str = toString.call(thing);
	return cache[str] || (cache[str] = str.slice(8, -1).toLowerCase());
})(Object.create(null));
var kindOfTest = (type) => {
	type = type.toLowerCase();
	return (thing) => kindOf(thing) === type;
};
var typeOfTest = (type) => (thing) => typeof thing === type;
/**
* Determine if a value is a non-null object
*
* @param {Object} val The value to test
*
* @returns {boolean} True if value is an Array, otherwise false
*/
var { isArray } = Array;
/**
* Determine if a value is undefined
*
* @param {*} val The value to test
*
* @returns {boolean} True if the value is undefined, otherwise false
*/
var isUndefined = typeOfTest("undefined");
/**
* Determine if a value is a Buffer
*
* @param {*} val The value to test
*
* @returns {boolean} True if value is a Buffer, otherwise false
*/
function isBuffer(val) {
	return val !== null && !isUndefined(val) && val.constructor !== null && !isUndefined(val.constructor) && isFunction$1(val.constructor.isBuffer) && val.constructor.isBuffer(val);
}
/**
* Determine if a value is an ArrayBuffer
*
* @param {*} val The value to test
*
* @returns {boolean} True if value is an ArrayBuffer, otherwise false
*/
var isArrayBuffer = kindOfTest("ArrayBuffer");
/**
* Determine if a value is a view on an ArrayBuffer
*
* @param {*} val The value to test
*
* @returns {boolean} True if value is a view on an ArrayBuffer, otherwise false
*/
function isArrayBufferView(val) {
	let result;
	if (typeof ArrayBuffer !== "undefined" && ArrayBuffer.isView) result = ArrayBuffer.isView(val);
	else result = val && val.buffer && isArrayBuffer(val.buffer);
	return result;
}
/**
* Determine if a value is a String
*
* @param {*} val The value to test
*
* @returns {boolean} True if value is a String, otherwise false
*/
var isString = typeOfTest("string");
/**
* Determine if a value is a Function
*
* @param {*} val The value to test
* @returns {boolean} True if value is a Function, otherwise false
*/
var isFunction$1 = typeOfTest("function");
/**
* Determine if a value is a Number
*
* @param {*} val The value to test
*
* @returns {boolean} True if value is a Number, otherwise false
*/
var isNumber = typeOfTest("number");
/**
* Determine if a value is an Object
*
* @param {*} thing The value to test
*
* @returns {boolean} True if value is an Object, otherwise false
*/
var isObject = (thing) => thing !== null && typeof thing === "object";
/**
* Determine if a value is a Boolean
*
* @param {*} thing The value to test
* @returns {boolean} True if value is a Boolean, otherwise false
*/
var isBoolean = (thing) => thing === true || thing === false;
/**
* Determine if a value is a plain Object
*
* @param {*} val The value to test
*
* @returns {boolean} True if value is a plain Object, otherwise false
*/
var isPlainObject = (val) => {
	if (!isObject(val)) return false;
	const prototype = getPrototypeOf(val);
	return (prototype === null || prototype === Object.prototype || getPrototypeOf(prototype) === null) && (isPrototypeBoundary(val, prototype, true) || !hasOwnProperty(val, toStringTag) && !hasOwnProperty(val, iterator));
};
/**
* Determine if a value is an empty object (safely handles Buffers)
*
* @param {*} val The value to test
*
* @returns {boolean} True if value is an empty object, otherwise false
*/
var isEmptyObject = (val) => {
	if (!isObject(val) || isBuffer(val)) return false;
	try {
		return Object.keys(val).length === 0 && Object.getPrototypeOf(val) === Object.prototype;
	} catch (e) {
		return false;
	}
};
/**
* Determine if a value is a Date
*
* @param {*} val The value to test
*
* @returns {boolean} True if value is a Date, otherwise false
*/
var isDate = kindOfTest("Date");
/**
* Determine if a value is a File
*
* @param {*} val The value to test
*
* @returns {boolean} True if value is a File, otherwise false
*/
var isFile = kindOfTest("File");
/**
* Determine if a value is a React Native Blob
* React Native "blob": an object with a `uri` attribute. Optionally, it can
* also have a `name` and `type` attribute to specify filename and content type
*
* @see https://github.com/facebook/react-native/blob/26684cf3adf4094eb6c405d345a75bf8c7c0bf88/Libraries/Network/FormData.js#L68-L71
*
* @param {*} value The value to test
*
* @returns {boolean} True if value is a React Native Blob, otherwise false
*/
var isReactNativeBlob = (value) => {
	return !!(value && typeof value.uri !== "undefined");
};
/**
* Determine if environment is React Native
* ReactNative `FormData` has a non-standard `getParts()` method
*
* @param {*} formData The formData to test
*
* @returns {boolean} True if environment is React Native, otherwise false
*/
var isReactNative = (formData) => formData && typeof formData.getParts !== "undefined";
/**
* Determine if a value is a Blob
*
* @param {*} val The value to test
*
* @returns {boolean} True if value is a Blob, otherwise false
*/
var isBlob = kindOfTest("Blob");
/**
* Determine if a value is a FileList
*
* @param {*} val The value to test
*
* @returns {boolean} True if value is a FileList, otherwise false
*/
var isFileList = kindOfTest("FileList");
var isSet = kindOfTest("Set");
/**
* Determine if a value is a Stream
*
* @param {*} val The value to test
*
* @returns {boolean} True if value is a Stream, otherwise false
*/
var isStream = (val) => isObject(val) && isFunction$1(val.pipe);
/**
* Determine if a value is a FormData
*
* @param {*} thing The value to test
*
* @returns {boolean} True if value is an FormData, otherwise false
*/
function getGlobal() {
	if (typeof globalThis !== "undefined") return globalThis;
	if (typeof self !== "undefined") return self;
	if (typeof window !== "undefined") return window;
	if (typeof global !== "undefined") return global;
	return {};
}
var G = getGlobal();
var FormDataCtor = typeof G.FormData !== "undefined" ? G.FormData : void 0;
var isFormData = (thing) => {
	if (!thing) return false;
	if (FormDataCtor && thing instanceof FormDataCtor) return true;
	const proto = getPrototypeOf(thing);
	if (!proto || proto === Object.prototype) return false;
	if (!isFunction$1(thing.append)) return false;
	const kind = kindOf(thing);
	return kind === "formdata" || kind === "object" && isFunction$1(thing.toString) && thing.toString() === "[object FormData]";
};
/**
* Determine if a value is a URLSearchParams object
*
* @param {*} val The value to test
*
* @returns {boolean} True if value is a URLSearchParams object, otherwise false
*/
var isURLSearchParams = kindOfTest("URLSearchParams");
var [isReadableStream, isRequest, isResponse, isHeaders] = [
	"ReadableStream",
	"Request",
	"Response",
	"Headers"
].map(kindOfTest);
/**
* Trim excess whitespace off the beginning and end of a string
*
* @param {String} str The String to trim
*
* @returns {String} The String freed of excess whitespace
*/
var trim = (str) => {
	return str.trim ? str.trim() : str.replace(/^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g, "");
};
/**
* Iterate over an Array or an Object invoking a function for each item.
*
* If `obj` is an Array callback will be called passing
* the value, index, and complete array for each item.
*
* If 'obj' is an Object callback will be called passing
* the value, key, and complete object for each property.
*
* @param {Object|Array<unknown>} obj The object to iterate
* @param {Function} fn The callback to invoke for each item
*
* @param {Object} [options]
* @param {Boolean} [options.allOwnKeys = false]
* @returns {any}
*/
function forEach(obj, fn, { allOwnKeys = false } = {}) {
	if (obj === null || typeof obj === "undefined") return;
	let i;
	let l;
	if (typeof obj !== "object") obj = [obj];
	if (isArray(obj)) for (i = 0, l = obj.length; i < l; i++) fn.call(null, obj[i], i, obj);
	else {
		if (isBuffer(obj)) return;
		const keys = allOwnKeys ? Object.getOwnPropertyNames(obj) : Object.keys(obj);
		const len = keys.length;
		let key;
		for (i = 0; i < len; i++) {
			key = keys[i];
			fn.call(null, obj[key], key, obj);
		}
	}
}
/**
* Finds a key in an object, case-insensitive, returning the actual key name.
* Returns null if the object is a Buffer or if no match is found.
*
* @param {Object} obj - The object to search.
* @param {string} key - The key to find (case-insensitive).
* @returns {?string} The actual key name if found, otherwise null.
*/
function findKey(obj, key) {
	if (isBuffer(obj)) return null;
	key = key.toLowerCase();
	const keys = Object.keys(obj);
	let i = keys.length;
	let _key;
	while (i-- > 0) {
		_key = keys[i];
		if (key === _key.toLowerCase()) return _key;
	}
	return null;
}
var _global = (() => {
	if (typeof globalThis !== "undefined") return globalThis;
	return typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : global;
})();
var isContextDefined = (context) => !isUndefined(context) && context !== _global;
/**
* Accepts varargs expecting each argument to be an object, then
* immutably merges the properties of each object and returns result.
*
* When multiple objects contain the same key the later object in
* the arguments list will take precedence.
*
* Example:
*
* ```js
* const result = merge({foo: 123}, {foo: 456});
* console.log(result.foo); // outputs 456
* ```
*
* @param {Object} obj1 Object to merge
*
* @returns {Object} Result of all merge properties
*/
function merge(...objs) {
	const { caseless, skipUndefined } = isContextDefined(this) && this || {};
	const result = {};
	const lowerCaseKeys = caseless ? Object.create(null) : null;
	const assignValue = (val, key) => {
		if (key === "__proto__" || key === "constructor" || key === "prototype") return;
		let targetKey = key;
		if (lowerCaseKeys && typeof key === "string") {
			const lowerKey = key.toLowerCase();
			const knownKey = lowerCaseKeys[lowerKey];
			if (knownKey !== void 0 && hasOwnProperty(result, knownKey)) targetKey = knownKey;
			else lowerCaseKeys[lowerKey] = key;
		}
		const existing = hasOwnProperty(result, targetKey) ? result[targetKey] : void 0;
		if (isPlainObject(existing) && isPlainObject(val)) result[targetKey] = merge(existing, val);
		else if (isPlainObject(val)) result[targetKey] = merge({}, val);
		else if (isArray(val)) result[targetKey] = val.slice();
		else if (!skipUndefined || !isUndefined(val)) result[targetKey] = val;
	};
	for (let i = 0, l = objs.length; i < l; i++) {
		const source = objs[i];
		if (!source || isBuffer(source)) continue;
		forEach(source, assignValue);
		if (typeof source !== "object" || isArray(source) || !Object.getOwnPropertySymbols) continue;
		const symbols = Object.getOwnPropertySymbols(source);
		for (let j = 0; j < symbols.length; j++) {
			const symbol = symbols[j];
			if (propertyIsEnumerable.call(source, symbol)) assignValue(source[symbol], symbol);
		}
	}
	return result;
}
/**
* Extends object a by mutably adding to it the properties of object b.
*
* @param {Object} a The object to be extended
* @param {Object} b The object to copy properties from
* @param {Object} thisArg The object to bind function to
*
* @param {Object} [options]
* @param {Boolean} [options.allOwnKeys]
* @returns {Object} The resulting value of object a
*/
var extend = (a, b, thisArg, { allOwnKeys } = {}) => {
	forEach(b, (val, key) => {
		if (thisArg && isFunction$1(val)) Object.defineProperty(a, key, {
			__proto__: null,
			value: bind(val, thisArg),
			writable: true,
			enumerable: true,
			configurable: true
		});
		else Object.defineProperty(a, key, {
			__proto__: null,
			value: val,
			writable: true,
			enumerable: true,
			configurable: true
		});
	}, { allOwnKeys });
	return a;
};
/**
* Remove byte order marker. This catches EF BB BF (the UTF-8 BOM)
*
* @param {string} content with BOM
*
* @returns {string} content value without BOM
*/
var stripBOM = (content) => {
	if (content.charCodeAt(0) === 65279) content = content.slice(1);
	return content;
};
/**
* Inherit the prototype methods from one constructor into another
* @param {function} constructor
* @param {function} superConstructor
* @param {object} [props]
* @param {object} [descriptors]
*
* @returns {void}
*/
var inherits = (constructor, superConstructor, props, descriptors) => {
	constructor.prototype = Object.create(superConstructor.prototype, descriptors);
	Object.defineProperty(constructor.prototype, "constructor", {
		__proto__: null,
		value: constructor,
		writable: true,
		enumerable: false,
		configurable: true
	});
	Object.defineProperty(constructor, "super", {
		__proto__: null,
		value: superConstructor.prototype
	});
	props && Object.assign(constructor.prototype, props);
};
/**
* Resolve object with deep prototype chain to a flat object
* @param {Object} sourceObj source object
* @param {Object} [destObj]
* @param {Function|Boolean} [filter]
* @param {Function} [propFilter]
*
* @returns {Object}
*/
var toFlatObject = (sourceObj, destObj, filter, propFilter) => {
	let props;
	let i;
	let prop;
	const merged = {};
	destObj = destObj || {};
	if (sourceObj == null) return destObj;
	do {
		props = Object.getOwnPropertyNames(sourceObj);
		i = props.length;
		while (i-- > 0) {
			prop = props[i];
			if ((!propFilter || propFilter(prop, sourceObj, destObj)) && !merged[prop]) {
				destObj[prop] = sourceObj[prop];
				merged[prop] = true;
			}
		}
		sourceObj = filter !== false && getPrototypeOf(sourceObj);
	} while (sourceObj && (!filter || filter(sourceObj, destObj)) && sourceObj !== Object.prototype);
	return destObj;
};
/**
* Determines whether a string ends with the characters of a specified string
*
* @param {String} str
* @param {String} searchString
* @param {Number} [position= 0]
*
* @returns {boolean}
*/
var endsWith = (str, searchString, position) => {
	str = String(str);
	if (position === void 0 || position > str.length) position = str.length;
	position -= searchString.length;
	const lastIndex = str.indexOf(searchString, position);
	return lastIndex !== -1 && lastIndex === position;
};
/**
* Returns new array from array like object or null if failed
*
* @param {*} [thing]
*
* @returns {?Array}
*/
var toArray = (thing) => {
	if (!thing) return null;
	if (isArray(thing)) return thing;
	let i = thing.length;
	if (!Number.isSafeInteger(i) || i < 0 || i > 4294967295) return null;
	const indexes = /* @__PURE__ */ new Set();
	const seen = /* @__PURE__ */ new Set();
	let source = thing;
	while (source != null && indexes.size < i) {
		if (seen.has(source)) return null;
		seen.add(source);
		const prototype = getPrototypeOf(source);
		if (isPrototypeBoundary(source, prototype, source === thing)) break;
		Object.getOwnPropertyNames(source).forEach((key) => {
			const index = +key;
			if (Number.isInteger(index) && index >= 0 && index < i && String(index) === key && hasOwnProperty(source, key)) indexes.add(index);
		});
		source = prototype;
	}
	if (indexes.size !== i) return null;
	const arr = new Array(i);
	while (i-- > 0) arr[i] = thing[i];
	return arr;
};
/**
* Checking if the Uint8Array exists and if it does, it returns a function that checks if the
* thing passed in is an instance of Uint8Array
*
* @param {TypedArray}
*
* @returns {Array}
*/
var isTypedArray = ((TypedArray) => {
	return (thing) => {
		return TypedArray && thing instanceof TypedArray;
	};
})(typeof Uint8Array !== "undefined" && getPrototypeOf(Uint8Array));
/**
* For each entry in the object, call the function with the key and value.
*
* @param {Object<any, any>} obj - The object to iterate over.
* @param {Function} fn - The function to call for each entry.
*
* @returns {void}
*/
var forEachEntry = (obj, fn) => {
	const _iterator = (obj && obj[iterator]).call(obj);
	let result;
	while ((result = _iterator.next()) && !result.done) {
		const pair = result.value;
		fn.call(obj, pair[0], pair[1]);
	}
};
/**
* It takes a regular expression and a string, and returns an array of all the matches
*
* @param {string} regExp - The regular expression to match against.
* @param {string} str - The string to search.
*
* @returns {Array<boolean>}
*/
var matchAll = (regExp, str) => {
	let matches;
	const arr = [];
	while ((matches = regExp.exec(str)) !== null) arr.push(matches);
	return arr;
};
var isHTMLForm = kindOfTest("HTMLFormElement");
var toCamelCase = (str) => {
	return str.toLowerCase().replace(/[-_\s]([a-z\d])(\w*)/g, function replacer(m, p1, p2) {
		return p1.toUpperCase() + p2;
	});
};
var { propertyIsEnumerable } = Object.prototype;
/**
* Determine if a value is a RegExp object
*
* @param {*} val The value to test
*
* @returns {boolean} True if value is a RegExp object, otherwise false
*/
var isRegExp = kindOfTest("RegExp");
var reduceDescriptors = (obj, reducer) => {
	const descriptors = Object.getOwnPropertyDescriptors(obj);
	const reducedDescriptors = {};
	forEach(descriptors, (descriptor, name) => {
		let ret;
		if ((ret = reducer(descriptor, name, obj)) !== false) reducedDescriptors[name] = ret || descriptor;
	});
	Object.defineProperties(obj, reducedDescriptors);
};
/**
* Makes all methods read-only
* @param {Object} obj
*/
var freezeMethods = (obj) => {
	reduceDescriptors(obj, (descriptor, name) => {
		if (isFunction$1(obj) && [
			"arguments",
			"caller",
			"callee"
		].includes(name)) return false;
		const value = obj[name];
		if (!isFunction$1(value)) return;
		descriptor.enumerable = false;
		if ("writable" in descriptor) {
			descriptor.writable = false;
			return;
		}
		if (!descriptor.set) descriptor.set = () => {
			throw Error("Can not rewrite read-only method '" + name + "'");
		};
	});
};
/**
* Converts an array or a delimited string into an object set with values as keys and true as values.
* Useful for fast membership checks.
*
* @param {Array|string} arrayOrString - The array or string to convert.
* @param {string} delimiter - The delimiter to use if input is a string.
* @returns {Object} An object with keys from the array or string, values set to true.
*/
var toObjectSet = (arrayOrString, delimiter) => {
	const obj = {};
	const define = (arr) => {
		arr.forEach((value) => {
			obj[value] = true;
		});
	};
	isArray(arrayOrString) ? define(arrayOrString) : define(String(arrayOrString).split(delimiter));
	return obj;
};
var noop = () => {};
var toFiniteNumber = (value, defaultValue) => {
	return value != null && Number.isFinite(value = +value) ? value : defaultValue;
};
/**
* If the thing is a FormData object, return true, otherwise return false.
*
* @param {unknown} thing - The thing to check.
*
* @returns {boolean}
*/
function isSpecCompliantForm(thing) {
	return !!(thing && isFunction$1(thing.append) && thing[toStringTag] === "FormData" && thing[iterator]);
}
/**
* Recursively converts an object to a JSON-compatible object, handling circular references and Buffers.
*
* @param {Object} obj - The object to convert.
* @returns {Object} The JSON-compatible object.
*/
var toJSONObject = (obj) => {
	const visited = /* @__PURE__ */ new WeakSet();
	const visit = (source) => {
		if (isObject(source)) {
			if (visited.has(source)) return;
			if (isBuffer(source)) return source;
			if (!("toJSON" in source)) {
				visited.add(source);
				let target;
				if (isSet(source)) {
					target = [];
					for (const value of source) {
						const reducedValue = visit(value);
						!isUndefined(reducedValue) && target.push(reducedValue);
					}
				} else {
					target = isArray(source) ? [] : {};
					forEach(source, (value, key) => {
						const reducedValue = visit(value);
						!isUndefined(reducedValue) && (target[key] = reducedValue);
					});
				}
				visited.delete(source);
				return target;
			}
		}
		return source;
	};
	return visit(obj);
};
/**
* Determines if a value is an async function.
*
* @param {*} thing - The value to test.
* @returns {boolean} True if value is an async function, otherwise false.
*/
var isAsyncFn = kindOfTest("AsyncFunction");
/**
* Determines if a value is thenable (has then and catch methods).
*
* @param {*} thing - The value to test.
* @returns {boolean} True if value is thenable, otherwise false.
*/
var isThenable = (thing) => thing && (isObject(thing) || isFunction$1(thing)) && isFunction$1(thing.then) && isFunction$1(thing.catch);
/**
* Provides a cross-platform setImmediate implementation.
* Uses native setImmediate if available, otherwise falls back to postMessage or setTimeout.
*
* @param {boolean} setImmediateSupported - Whether setImmediate is supported.
* @param {boolean} postMessageSupported - Whether postMessage is supported.
* @returns {Function} A function to schedule a callback asynchronously.
*/
var _setImmediate = ((setImmediateSupported, postMessageSupported) => {
	if (setImmediateSupported) return setImmediate;
	return postMessageSupported ? ((token, callbacks) => {
		_global.addEventListener("message", ({ source, data }) => {
			if (source === _global && data === token) callbacks.length && callbacks.shift()();
		}, false);
		return (cb) => {
			callbacks.push(cb);
			_global.postMessage(token, "*");
		};
	})(`axios@${Math.random()}`, []) : (cb) => setTimeout(cb);
})(typeof setImmediate === "function", isFunction$1(_global.postMessage));
/**
* Schedules a microtask or asynchronous callback as soon as possible.
* Uses queueMicrotask if available, otherwise falls back to process.nextTick or _setImmediate.
*
* @type {Function}
*/
var asap = typeof queueMicrotask !== "undefined" ? queueMicrotask.bind(_global) : typeof process !== "undefined" && process.nextTick || _setImmediate;
var isIterable = (thing) => thing != null && isFunction$1(thing[iterator]);
/**
* Determine if a value is iterable via an iterator that is NOT sourced solely
* from a polluted Object.prototype. Use this instead of `isIterable` whenever
* the iterable comes from untrusted input (e.g. user-supplied header sources),
* so `Object.prototype[Symbol.iterator] = ...` cannot turn an ordinary object
* into an attacker-controlled entries iterator.
*
* @param {*} thing The value to test
*
* @returns {boolean} True if value has a non-polluted iterator
*/
var isSafeIterable = (thing) => thing != null && hasOwnInPrototypeChain(thing, iterator) && isIterable(thing);
var utils_default = {
	isArray,
	isArrayBuffer,
	isBuffer,
	isFormData,
	isArrayBufferView,
	isString,
	isNumber,
	isBoolean,
	isObject,
	isPlainObject,
	isEmptyObject,
	isReadableStream,
	isRequest,
	isResponse,
	isHeaders,
	isUndefined,
	isDate,
	isFile,
	isReactNativeBlob,
	isReactNative,
	isBlob,
	isRegExp,
	isFunction: isFunction$1,
	isStream,
	isURLSearchParams,
	isTypedArray,
	isFileList,
	forEach,
	merge,
	extend,
	trim,
	stripBOM,
	inherits,
	toFlatObject,
	kindOf,
	kindOfTest,
	endsWith,
	toArray,
	forEachEntry,
	matchAll,
	isHTMLForm,
	hasOwnProperty,
	hasOwnProp: hasOwnProperty,
	hasOwnInPrototypeChain,
	getSafeProp,
	toSafeFlatObject,
	reduceDescriptors,
	freezeMethods,
	toObjectSet,
	toCamelCase,
	noop,
	toFiniteNumber,
	findKey,
	global: _global,
	isContextDefined,
	isSpecCompliantForm,
	toJSONObject,
	isAsyncFn,
	isThenable,
	setImmediate: _setImmediate,
	asap,
	isIterable,
	isSafeIterable
};
// node_modules/axios/lib/helpers/parseHeaders.js
var ignoreDuplicateOf = utils_default.toObjectSet([
	"age",
	"authorization",
	"content-length",
	"content-type",
	"etag",
	"expires",
	"from",
	"host",
	"if-modified-since",
	"if-unmodified-since",
	"last-modified",
	"location",
	"max-forwards",
	"proxy-authorization",
	"referer",
	"retry-after",
	"user-agent"
]);
/**
* Parse headers into an object
*
* ```
* Date: Wed, 27 Aug 2014 08:58:49 GMT
* Content-Type: application/json
* Connection: keep-alive
* Transfer-Encoding: chunked
* ```
*
* @param {String} rawHeaders Headers needing to be parsed
*
* @returns {Object} Headers parsed into an object
*/
var parseHeaders_default = (rawHeaders) => {
	const parsed = Object.create(null);
	let key;
	let val;
	let i;
	rawHeaders && rawHeaders.split("\n").forEach(function parser(line) {
		i = line.indexOf(":");
		key = line.substring(0, i).trim().toLowerCase();
		val = line.substring(i + 1).trim();
		const hasKey = utils_default.hasOwnProp(parsed, key);
		if (!key || hasKey && utils_default.hasOwnProp(ignoreDuplicateOf, key)) return;
		if (key === "set-cookie") {
			if (hasKey) parsed[key].push(val);
			else parsed[key] = [val];
		} else parsed[key] = hasKey ? parsed[key] + ", " + val : val;
	});
	return parsed;
};
// node_modules/axios/lib/helpers/sanitizeHeaderValue.js
function trimSPorHTAB(str) {
	let start = 0;
	let end = str.length;
	while (start < end) {
		const code = str.charCodeAt(start);
		if (code !== 9 && code !== 32) break;
		start += 1;
	}
	while (end > start) {
		const code = str.charCodeAt(end - 1);
		if (code !== 9 && code !== 32) break;
		end -= 1;
	}
	return start === 0 && end === str.length ? str : str.slice(start, end);
}
var INVALID_UNICODE_HEADER_VALUE_CHARS = /* @__PURE__ */ new RegExp("[\\u0000-\\u0008\\u000a-\\u001f\\u007f]+", "g");
var INVALID_BYTE_STRING_HEADER_VALUE_CHARS = /* @__PURE__ */ new RegExp("[^\\u0009\\u0020-\\u007e\\u0080-\\u00ff]+", "g");
function sanitizeValue(value, invalidChars) {
	if (utils_default.isArray(value)) return value.map((item) => sanitizeValue(item, invalidChars));
	return trimSPorHTAB(String(value).replace(invalidChars, ""));
}
var sanitizeHeaderValue = (value) => sanitizeValue(value, INVALID_UNICODE_HEADER_VALUE_CHARS);
var sanitizeByteStringHeaderValue = (value) => sanitizeValue(value, INVALID_BYTE_STRING_HEADER_VALUE_CHARS);
function toByteStringHeaderObject(headers) {
	const byteStringHeaders = Object.create(null);
	utils_default.forEach(headers.toJSON(), (value, header) => {
		byteStringHeaders[header] = sanitizeByteStringHeaderValue(value);
	});
	return byteStringHeaders;
}
// node_modules/axios/lib/core/AxiosHeaders.js
var $internals$1 = Symbol("internals");
function normalizeHeader(header) {
	return header && String(header).trim().toLowerCase();
}
function normalizeValue(value) {
	if (value === false || value == null) return value;
	return utils_default.isArray(value) ? value.map(normalizeValue) : sanitizeHeaderValue(String(value));
}
function parseTokens(str) {
	const tokens = Object.create(null);
	const tokensRE = /([^\s,;=]+)\s*(?:=\s*([^,;]+))?/g;
	let match;
	while (match = tokensRE.exec(str)) tokens[match[1]] = match[2];
	return tokens;
}
var parameterNameRE = /^[!#$%&'*+\-.^_`|~0-9A-Za-z]+$/;
function trimOWS(value) {
	let start = 0;
	let end = value.length;
	while (start < end) {
		const code = value.charCodeAt(start);
		if (code !== 9 && code !== 32) break;
		start += 1;
	}
	while (end > start) {
		const code = value.charCodeAt(end - 1);
		if (code !== 9 && code !== 32) break;
		end -= 1;
	}
	return start === 0 && end === value.length ? value : value.slice(start, end);
}
function decodeQuotedString(value) {
	const last = value.length - 1;
	if (last < 1 || value.charCodeAt(0) !== 34 || value.charCodeAt(last) !== 34) return value;
	let decoded = "";
	for (let i = 1; i < last; i++) {
		const code = value.charCodeAt(i);
		if (code === 34) return value;
		if (code === 92) {
			i += 1;
			if (i >= last) return value;
		}
		decoded += value[i];
	}
	return decoded;
}
function parseParameters(value) {
	const parameters = Object.create(null);
	const str = String(value);
	let start = 0;
	let quoted = false;
	let escaped = false;
	function parseParameter(end) {
		const part = trimOWS(str.slice(start, end));
		const equals = part.indexOf("=");
		if (equals < 1) return;
		const name = trimOWS(part.slice(0, equals));
		if (!parameterNameRE.test(name)) return;
		const normalizedName = name.toLowerCase();
		if (normalizedName === "__proto__" || normalizedName === "constructor" || normalizedName === "prototype") return;
		const parameterValue = trimOWS(part.slice(equals + 1));
		parameters[normalizedName] = decodeQuotedString(parameterValue);
	}
	for (let i = 0; i < str.length; i++) {
		const code = str.charCodeAt(i);
		if (quoted) {
			if (escaped) escaped = false;
			else if (code === 92) escaped = true;
			else if (code === 34) quoted = false;
		} else if (code === 34) quoted = true;
		else if (code === 44 || code === 59) {
			parseParameter(i);
			start = i + 1;
		}
	}
	parseParameter(str.length);
	return parameters;
}
var isValidHeaderName = (str) => /^[-_a-zA-Z0-9^`|~,!#$%&'*+.]+$/.test(str.trim());
var PROTO_HEADER_SLOT = "__Proto__";
var headerSlot = (name) => name === "__proto__" ? PROTO_HEADER_SLOT : name;
function matchHeaderValue(context, value, header, filter, isHeaderNameFilter) {
	if (utils_default.isFunction(filter)) return filter.call(context, value, header);
	if (isHeaderNameFilter) value = header;
	if (!utils_default.isString(value)) return;
	if (utils_default.isString(filter)) return value.indexOf(filter) !== -1;
	if (utils_default.isRegExp(filter)) return filter.test(value);
}
function formatHeader(header) {
	return header.trim().toLowerCase().replace(/([a-z\d])(\w*)/g, (w, char, str) => {
		return char.toUpperCase() + str;
	});
}
function buildAccessors(obj, header) {
	const accessorName = utils_default.toCamelCase(" " + header);
	[
		"get",
		"set",
		"has"
	].forEach((methodName) => {
		Object.defineProperty(obj, methodName + accessorName, {
			__proto__: null,
			value: function(arg1, arg2, arg3) {
				return this[methodName].call(this, header, arg1, arg2, arg3);
			},
			configurable: true
		});
	});
}
var AxiosHeaders$1 = class {
	constructor(headers) {
		headers && this.set(headers);
	}
	set(header, valueOrRewrite, rewrite) {
		const self = this;
		function setHeader(_value, _header, _rewrite) {
			const lHeader = normalizeHeader(_header);
			if (!lHeader) return;
			const key = utils_default.findKey(self, lHeader);
			if (!key || self[key] === void 0 || _rewrite === true || _rewrite === void 0 && self[key] !== false) self[headerSlot(key || _header)] = normalizeValue(_value);
		}
		const setHeaders = (headers, _rewrite) => utils_default.forEach(headers, (_value, _header) => setHeader(_value, _header, _rewrite));
		if (utils_default.isPlainObject(header) || header instanceof this.constructor) setHeaders(header, valueOrRewrite);
		else if (utils_default.isString(header) && (header = header.trim()) && !isValidHeaderName(header)) setHeaders(parseHeaders_default(header), valueOrRewrite);
		else if (utils_default.isObject(header) && utils_default.isSafeIterable(header)) {
			let obj = Object.create(null), dest, key;
			for (const entry of header) {
				if (!utils_default.isArray(entry)) throw new TypeError("Object iterator must return a key-value pair");
				key = entry[0];
				if (utils_default.hasOwnProp(obj, key)) {
					dest = obj[key];
					obj[key] = utils_default.isArray(dest) ? [...dest, entry[1]] : [dest, entry[1]];
				} else obj[key] = entry[1];
			}
			setHeaders(obj, valueOrRewrite);
		} else header != null && setHeader(valueOrRewrite, header, rewrite);
		return this;
	}
	get(header, parser) {
		header = normalizeHeader(header);
		if (header) {
			const key = utils_default.findKey(this, header);
			if (key) {
				const value = this[key];
				if (!parser) return value;
				if (parser === true) return parseTokens(value);
				if (utils_default.isFunction(parser)) return parser.call(this, value, key);
				if (utils_default.isRegExp(parser)) return parser.exec(value);
				throw new TypeError("parser must be boolean|regexp|function");
			}
		}
	}
	has(header, matcher) {
		header = normalizeHeader(header);
		if (header) {
			const key = utils_default.findKey(this, header);
			return !!(key && this[key] !== void 0 && (!matcher || matchHeaderValue(this, this[key], key, matcher)));
		}
		return false;
	}
	delete(header, matcher) {
		const self = this;
		let deleted = false;
		function deleteHeader(_header) {
			_header = normalizeHeader(_header);
			if (_header) {
				const key = utils_default.findKey(self, _header);
				if (key && (!matcher || matchHeaderValue(self, self[key], key, matcher))) {
					delete self[key];
					deleted = true;
				}
			}
		}
		if (utils_default.isArray(header)) header.forEach(deleteHeader);
		else deleteHeader(header);
		return deleted;
	}
	clear(matcher) {
		const keys = Object.keys(this);
		let i = keys.length;
		let deleted = false;
		while (i--) {
			const key = keys[i];
			if (!matcher || matchHeaderValue(this, this[key], key, matcher, true)) {
				delete this[key];
				deleted = true;
			}
		}
		return deleted;
	}
	normalize(format) {
		const self = this;
		const headers = Object.create(null);
		utils_default.forEach(this, (value, header) => {
			const key = utils_default.findKey(headers, header);
			if (key) {
				self[key] = normalizeValue(value);
				delete self[header];
				return;
			}
			const normalized = headerSlot(format ? formatHeader(header) : String(header).trim());
			if (normalized !== header) delete self[header];
			self[normalized] = normalizeValue(value);
			headers[normalized] = true;
		});
		return this;
	}
	concat(...targets) {
		return this.constructor.concat(this, ...targets);
	}
	toJSON(asStrings) {
		const obj = Object.create(null);
		utils_default.forEach(this, (value, header) => {
			value != null && value !== false && (obj[header] = asStrings && utils_default.isArray(value) ? value.join(", ") : value);
		});
		return obj;
	}
	[Symbol.iterator]() {
		return Object.entries(this.toJSON())[Symbol.iterator]();
	}
	toString() {
		return Object.entries(this.toJSON()).map(([header, value]) => header + ": " + value).join("\n");
	}
	getSetCookie() {
		const value = this.get("set-cookie");
		return utils_default.isArray(value) ? value : value == null || value === false ? [] : [value];
	}
	get [Symbol.toStringTag]() {
		return "AxiosHeaders";
	}
	static from(thing) {
		return thing instanceof this ? thing : new this(thing);
	}
	static parseParameters(value) {
		return parseParameters(value);
	}
	static concat(first, ...targets) {
		const computed = new this(first);
		targets.forEach((target) => computed.set(target));
		return computed;
	}
	static accessor(header) {
		const accessors = (this[$internals$1] = this[$internals$1] = { accessors: {} }).accessors;
		const prototype = this.prototype;
		function defineAccessor(_header) {
			const lHeader = normalizeHeader(_header);
			if (!accessors[lHeader]) {
				buildAccessors(prototype, _header);
				accessors[lHeader] = true;
			}
		}
		utils_default.isArray(header) ? header.forEach(defineAccessor) : defineAccessor(header);
		return this;
	}
};
AxiosHeaders$1.accessor([
	"Content-Type",
	"Content-Length",
	"Accept",
	"Accept-Encoding",
	"User-Agent",
	"Authorization"
]);
utils_default.reduceDescriptors(AxiosHeaders$1.prototype, ({ value }, key) => {
	let mapped = key[0].toUpperCase() + key.slice(1);
	return {
		get: () => value,
		set(headerValue) {
			this[mapped] = headerValue;
		}
	};
});
utils_default.freezeMethods(AxiosHeaders$1);
// node_modules/axios/lib/core/AxiosError.js
var REDACTED = "[REDACTED ****]";
function hasOwnOrPrototypeToJSON(source) {
	if (utils_default.hasOwnProp(source, "toJSON")) return true;
	let prototype = Object.getPrototypeOf(source);
	while (prototype && prototype !== Object.prototype) {
		if (utils_default.hasOwnProp(prototype, "toJSON")) return true;
		prototype = Object.getPrototypeOf(prototype);
	}
	return false;
}
function redactConfig(config, redactKeys) {
	const lowerKeys = new Set(redactKeys.map((k) => String(k).toLowerCase()));
	const seen = [];
	const visit = (source) => {
		if (source === null || typeof source !== "object") return source;
		if (utils_default.isBuffer(source)) return source;
		if (seen.indexOf(source) !== -1) return void 0;
		if (source instanceof AxiosHeaders$1) source = source.toJSON();
		seen.push(source);
		let result;
		if (utils_default.isArray(source)) {
			result = [];
			source.forEach((v, i) => {
				const reducedValue = visit(v);
				if (!utils_default.isUndefined(reducedValue)) result[i] = reducedValue;
			});
		} else {
			if (!utils_default.isPlainObject(source) && hasOwnOrPrototypeToJSON(source)) {
				seen.pop();
				return source;
			}
			result = Object.create(null);
			for (const [key, value] of Object.entries(source)) {
				const reducedValue = lowerKeys.has(key.toLowerCase()) ? REDACTED : visit(value);
				if (!utils_default.isUndefined(reducedValue)) result[key] = reducedValue;
			}
		}
		seen.pop();
		return result;
	};
	return visit(config);
}
function stringifySafely$1(value) {
	try {
		return String(value);
	} catch (err) {
		return "";
	}
}
function aggregateErrorMessage(error) {
	return error.errors.map((entry) => {
		try {
			return entry && entry.message ? stringifySafely$1(entry.message) : stringifySafely$1(entry);
		} catch (err) {
			return "";
		}
	}).filter(Boolean).join("; ") || error.name || "AggregateError";
}
var CAUSED_BY_SEPARATOR = "\nCaused by: ";
var $causeStack = Symbol("causeStack");
function getCauseStackIndex(error, stack) {
	const causeStack = utils_default.hasOwnProp(error, $causeStack) && error[$causeStack];
	return causeStack && stack.endsWith(causeStack) ? stack.length - causeStack.length : -1;
}
/**
* Append the stack of a wrapped error to `target.stack`.
*
* `cause` already exposes the original error for tooling that walks the standard
* cause chain, but many error reporters read `stack` and nothing else. Inlining
* the wrapped stack there means those reporters surface the underlying failure
* instead of the axios frames that normalized it (see #6670).
*
* Every read is defensive: a custom `Error.prepareStackTrace` hook, a runtime
* without stack support, or a replaced `stack` property can leave the value
* missing, non-string, or read-only, and normalizing an error must not throw
* because of that.
*
* @param {Error} target The AxiosError being built.
* @param {Error} source The error being wrapped.
*
* @returns {void}
*/
function appendCauseStack(target, source) {
	try {
		const sourceStack = source && source.stack;
		if (typeof sourceStack !== "string" || !sourceStack) return;
		const targetStack = target.stack;
		if (typeof targetStack !== "string" || !targetStack) return;
		const causeStack = CAUSED_BY_SEPARATOR + sourceStack;
		target.stack = targetStack + causeStack;
		Object.defineProperty(target, $causeStack, {
			__proto__: null,
			value: causeStack
		});
	} catch (e) {}
}
var AxiosError$1 = class AxiosError$1 extends Error {
	static from(error, code, config, request, response, customProps) {
		let message = error.message;
		if (!message && utils_default.isArray(error.errors) && error.errors.length) message = aggregateErrorMessage(error);
		const axiosError = new AxiosError$1(message, code || error.code, config, request, response);
		Object.defineProperty(axiosError, "cause", {
			__proto__: null,
			value: error,
			writable: true,
			enumerable: false,
			configurable: true
		});
		axiosError.name = error.name;
		appendCauseStack(axiosError, error);
		if (error.status != null && axiosError.status == null) axiosError.status = error.status;
		customProps && Object.assign(axiosError, customProps);
		return axiosError;
	}
	/**
	* Create an Error with the specified message, config, error code, request and response.
	*
	* @param {string} message The error message.
	* @param {string} [code] The error code (for example, 'ECONNABORTED').
	* @param {Object} [config] The config.
	* @param {Object} [request] The request.
	* @param {Object} [response] The response.
	*
	* @returns {Error} The created error.
	*/
	constructor(message, code, config, request, response) {
		super(message);
		Object.defineProperty(this, "message", {
			__proto__: null,
			value: message,
			enumerable: true,
			writable: true,
			configurable: true
		});
		this.name = "AxiosError";
		this.isAxiosError = true;
		code && (this.code = code);
		config && (this.config = config);
		request && (this.request = request);
		if (response) {
			this.response = response;
			this.status = response.status;
		}
	}
	toJSON() {
		const config = this.config;
		const redactKeys = config && utils_default.hasOwnProp(config, "redact") ? config.redact : void 0;
		const serializedConfig = utils_default.isArray(redactKeys) && redactKeys.length > 0 ? redactConfig(config, redactKeys) : utils_default.toJSONObject(config);
		return {
			message: this.message,
			name: this.name,
			description: this.description,
			number: this.number,
			fileName: this.fileName,
			lineNumber: this.lineNumber,
			columnNumber: this.columnNumber,
			stack: this.stack,
			config: serializedConfig,
			code: this.code,
			status: this.status
		};
	}
};
AxiosError$1.ERR_BAD_OPTION_VALUE = "ERR_BAD_OPTION_VALUE";
AxiosError$1.ERR_BAD_OPTION = "ERR_BAD_OPTION";
AxiosError$1.ECONNABORTED = "ECONNABORTED";
AxiosError$1.ETIMEDOUT = "ETIMEDOUT";
AxiosError$1.ECONNREFUSED = "ECONNREFUSED";
AxiosError$1.ERR_NETWORK = "ERR_NETWORK";
AxiosError$1.ERR_FR_TOO_MANY_REDIRECTS = "ERR_FR_TOO_MANY_REDIRECTS";
AxiosError$1.ERR_DEPRECATED = "ERR_DEPRECATED";
AxiosError$1.ERR_BAD_RESPONSE = "ERR_BAD_RESPONSE";
AxiosError$1.ERR_BAD_REQUEST = "ERR_BAD_REQUEST";
AxiosError$1.ERR_CANCELED = "ERR_CANCELED";
AxiosError$1.ERR_NOT_SUPPORT = "ERR_NOT_SUPPORT";
AxiosError$1.ERR_INVALID_URL = "ERR_INVALID_URL";
AxiosError$1.ERR_FORM_DATA_DEPTH_EXCEEDED = "ERR_FORM_DATA_DEPTH_EXCEEDED";
/**
* Determines if the given thing is a array or js object.
*
* @param {string} thing - The object or array to be visited.
*
* @returns {boolean}
*/
function isVisitable(thing) {
	return utils_default.isPlainObject(thing) || utils_default.isArray(thing);
}
/**
* It removes the brackets from the end of a string
*
* @param {string} key - The key of the parameter.
*
* @returns {string} the key without the brackets.
*/
function removeBrackets(key) {
	return utils_default.endsWith(key, "[]") ? key.slice(0, -2) : key;
}
/**
* It takes a path, a key, and a boolean, and returns a string
*
* @param {string} path - The path to the current key.
* @param {string} key - The key of the current object being iterated over.
* @param {string} dots - If true, the key will be rendered with dots instead of brackets.
*
* @returns {string} The path to the current key.
*/
function renderKey(path, key, dots) {
	if (!path) return key;
	return path.concat(key).map(function each(token, i) {
		token = removeBrackets(token);
		return !dots && i ? "[" + token + "]" : token;
	}).join(dots ? "." : "");
}
/**
* If the array is an array and none of its elements are visitable, then it's a flat array.
*
* @param {Array<any>} arr - The array to check
*
* @returns {boolean}
*/
function isFlatArray(arr) {
	return utils_default.isArray(arr) && !arr.some(isVisitable);
}
var predicates = utils_default.toFlatObject(utils_default, {}, null, function filter(prop) {
	return /^is[A-Z]/.test(prop);
});
/**
* Convert a data object to FormData
*
* @param {Object} obj
* @param {?Object} [formData]
* @param {?Object} [options]
* @param {Function} [options.visitor]
* @param {Boolean} [options.metaTokens = true]
* @param {Boolean} [options.dots = false]
* @param {?Boolean} [options.indexes = false]
*
* @returns {Object}
**/
/**
* It converts an object into a FormData object
*
* @param {Object<any, any>} obj - The object to convert to form data.
* @param {string} formData - The FormData object to append to.
* @param {Object<string, any>} options
*
* @returns
*/
function toFormData$1(obj, formData, options) {
	if (!utils_default.isObject(obj)) throw new TypeError("target must be an object");
	formData = formData || new FormData();
	const option = (name, fallback) => {
		const value = utils_default.getSafeProp(options, name);
		return utils_default.isUndefined(value) ? fallback : value;
	};
	const metaTokens = option("metaTokens", true);
	const visitor = option("visitor") || defaultVisitor;
	const dots = option("dots", false);
	const indexes = option("indexes", false);
	const _Blob = option("Blob") || typeof Blob !== "undefined" && Blob;
	const maxDepth = option("maxDepth", 100);
	const useBlob = _Blob && utils_default.isSpecCompliantForm(formData);
	const stack = [];
	if (!utils_default.isFunction(visitor)) throw new TypeError("visitor must be a function");
	function convertValue(value) {
		if (value === null) return "";
		if (utils_default.isDate(value)) return value.toISOString();
		if (utils_default.isBoolean(value)) return value.toString();
		if (!useBlob && utils_default.isBlob(value)) throw new AxiosError$1("Blob is not supported. Use a Buffer instead.");
		if (utils_default.isArrayBuffer(value) || utils_default.isTypedArray(value)) {
			if (useBlob && typeof _Blob === "function") return new _Blob([value]);
			throw new AxiosError$1("Blob is not supported. Use a Buffer instead.", AxiosError$1.ERR_NOT_SUPPORT);
		}
		return value;
	}
	function throwIfMaxDepthExceeded(depth) {
		if (depth > maxDepth) throw new AxiosError$1("Object is too deeply nested (" + depth + " levels). Max depth: " + maxDepth, AxiosError$1.ERR_FORM_DATA_DEPTH_EXCEEDED);
	}
	function stringifyWithDepthLimit(value, depth) {
		if (maxDepth === Infinity) return JSON.stringify(value);
		const ancestors = [];
		return JSON.stringify(value, function limitDepth(_key, currentValue) {
			if (!utils_default.isObject(currentValue)) return currentValue;
			while (ancestors.length && ancestors[ancestors.length - 1] !== this) ancestors.pop();
			ancestors.push(currentValue);
			throwIfMaxDepthExceeded(depth + ancestors.length - 1);
			return currentValue;
		});
	}
	/**
	* Default visitor.
	*
	* @param {*} value
	* @param {String|Number} key
	* @param {Array<String|Number>} path
	* @this {FormData}
	*
	* @returns {boolean} return true to visit the each prop of the value recursively
	*/
	function defaultVisitor(value, key, path) {
		let arr = value;
		if (utils_default.isReactNative(formData) && utils_default.isReactNativeBlob(value)) {
			formData.append(renderKey(path, key, dots), convertValue(value));
			return false;
		}
		if (value && !path && typeof value === "object") {
			if (utils_default.endsWith(key, "{}")) {
				key = metaTokens ? key : key.slice(0, -2);
				value = stringifyWithDepthLimit(value, 1);
			} else if (utils_default.isArray(value) && isFlatArray(value) || (utils_default.isFileList(value) || utils_default.endsWith(key, "[]")) && (arr = utils_default.toArray(value))) {
				key = removeBrackets(key);
				arr.forEach(function each(el, index) {
					!(utils_default.isUndefined(el) || el === null) && formData.append(indexes === true ? renderKey([key], index, dots) : indexes === null ? key : key + "[]", convertValue(el));
				});
				return false;
			}
		}
		if (isVisitable(value)) return true;
		formData.append(renderKey(path, key, dots), convertValue(value));
		return false;
	}
	const exposedHelpers = Object.assign(predicates, {
		defaultVisitor,
		convertValue,
		isVisitable
	});
	function build(value, path, depth = 0) {
		if (utils_default.isUndefined(value)) return;
		throwIfMaxDepthExceeded(depth);
		if (stack.indexOf(value) !== -1) throw new Error("Circular reference detected in " + path.join("."));
		stack.push(value);
		utils_default.forEach(value, function each(el, key) {
			if ((!(utils_default.isUndefined(el) || el === null) && visitor.call(formData, el, utils_default.isString(key) ? key.trim() : key, path, exposedHelpers)) === true) build(el, path ? path.concat(key) : [key], depth + 1);
		});
		stack.pop();
	}
	if (!utils_default.isObject(obj)) throw new TypeError("data must be an object");
	build(obj);
	return formData;
}
// node_modules/axios/lib/helpers/AxiosURLSearchParams.js
/**
* It encodes a string by replacing all characters that are not in the unreserved set with
* their percent-encoded equivalents
*
* @param {string} str - The string to encode.
*
* @returns {string} The encoded string.
*/
function encode$1(str) {
	const charMap = {
		"!": "%21",
		"'": "%27",
		"(": "%28",
		")": "%29",
		"~": "%7E",
		"%20": "+"
	};
	return encodeURIComponent(str).replace(/[!'()~]|%20/g, function replacer(match) {
		return charMap[match];
	});
}
/**
* It takes a params object and converts it to a FormData object
*
* @param {Object<string, any>} params - The parameters to be converted to a FormData object.
* @param {Object<string, any>} options - The options object passed to the Axios constructor.
*
* @returns {void}
*/
function AxiosURLSearchParams(params, options) {
	this._pairs = [];
	params && toFormData$1(params, this, options);
}
var prototype = AxiosURLSearchParams.prototype;
prototype.append = function append(name, value) {
	this._pairs.push([name, value]);
};
prototype.toString = function toString(encoder) {
	const _encode = encoder ? (value) => encoder.call(this, value, encode$1) : encode$1;
	return this._pairs.map(function each(pair) {
		return _encode(pair[0]) + "=" + _encode(pair[1]);
	}, "").join("&");
};
// node_modules/axios/lib/helpers/buildURL.js
/**
* It replaces URL-encoded forms of `:`, `$`, `,`, and spaces with
* their plain counterparts (`:`, `$`, `,`, `+`).
*
* @param {string} val The value to be encoded.
*
* @returns {string} The encoded value.
*/
function encode(val) {
	return encodeURIComponent(val).replace(/%3A/gi, ":").replace(/%24/g, "$").replace(/%2C/gi, ",").replace(/%20/g, "+");
}
/**
* Build a URL by appending params to the end
*
* @param {string} url The base of the url (e.g., http://www.google.com)
* @param {object} [params] The params to be appended
* @param {?(object|Function)} options
*
* @returns {string} The formatted url
*/
function buildURL(url, params, options) {
	if (!params) return url;
	url = url || "";
	const _options = utils_default.isFunction(options) ? { serialize: options } : options;
	const _encode = utils_default.getSafeProp(_options, "encode") || encode;
	const serializeFn = utils_default.getSafeProp(_options, "serialize");
	let serializedParams;
	if (serializeFn) serializedParams = serializeFn(params, _options);
	else serializedParams = utils_default.isURLSearchParams(params) ? params.toString() : new AxiosURLSearchParams(params, _options).toString(_encode);
	if (serializedParams) {
		const hashmarkIndex = url.indexOf("#");
		if (hashmarkIndex !== -1) url = url.slice(0, hashmarkIndex);
		url += (url.indexOf("?") === -1 ? "?" : "&") + serializedParams;
	}
	return url;
}
// node_modules/axios/lib/core/InterceptorManager.js
var $internals = Symbol("internals");
function countHandlers(handlers) {
	return handlers ? handlers.length : 0;
}
function trimHandlers(handlers) {
	if (!handlers) return;
	while (handlers.length && handlers[handlers.length - 1] === null) handlers.pop();
}
function normalizeHandlerId(id) {
	if (typeof id === "string" && id !== "" && String(Number(id)) === id) return Number(id);
	return id;
}
function syncHandlerEntries(manager, internals) {
	const handlers = manager.handlers;
	const length = countHandlers(handlers);
	if (handlers !== internals.handlersRef) {
		internals.handlersRef = handlers;
		internals.handlerEntries.clear();
	} else if (length !== internals.handlersLength) {
		if (!length) internals.handlerEntries.clear();
		else internals.handlerEntries.forEach(function removeStaleEntry(entry, id) {
			if (handlers[entry.index] !== entry.handler) internals.handlerEntries.delete(id);
		});
	}
	internals.handlersLength = length;
}
var InterceptorManager = class {
	constructor() {
		this.handlers = [];
		this[$internals] = {
			handlersRef: this.handlers,
			handlersLength: this.handlers.length,
			handlerEntries: /* @__PURE__ */ new Map(),
			iterationDepth: 0,
			nextId: 0
		};
	}
	/**
	* Add a new interceptor to the stack
	*
	* @param {Function} fulfilled The function to handle `then` for a `Promise`
	* @param {Function} rejected The function to handle `reject` for a `Promise`
	* @param {Object} options The options for the interceptor, synchronous and runWhen
	*
	* @return {Number} An ID used to remove interceptor later
	*/
	use(fulfilled, rejected, options) {
		const handler = {
			fulfilled,
			rejected,
			synchronous: options ? options.synchronous : false,
			runWhen: options ? options.runWhen : null
		};
		const internals = this[$internals];
		if (this.handlers == null) this.handlers = [];
		syncHandlerEntries(this, internals);
		const id = internals.nextId++;
		this.handlers.push(handler);
		internals.handlerEntries.set(id, {
			handler,
			index: this.handlers.length - 1
		});
		internals.handlersLength = this.handlers.length;
		return id;
	}
	/**
	* Remove an interceptor from the stack
	*
	* @param {Number} id The ID that was returned by `use`
	*
	* @returns {void}
	*/
	eject(id) {
		const internals = this[$internals];
		syncHandlerEntries(this, internals);
		const handlerId = normalizeHandlerId(id);
		const entry = internals.handlerEntries.get(handlerId);
		if (entry) {
			internals.handlerEntries.delete(handlerId);
			if (this.handlers[entry.index] !== entry.handler) return;
			this.handlers[entry.index] = null;
			if (!internals.iterationDepth) {
				trimHandlers(this.handlers);
				internals.handlersLength = this.handlers.length;
			}
		}
	}
	/**
	* Clear all interceptors from the stack
	*
	* @returns {void}
	*/
	clear() {
		if (this.handlers) {
			this.handlers = [];
			syncHandlerEntries(this, this[$internals]);
		}
	}
	/**
	* Iterate over all the registered interceptors
	*
	* This method is particularly useful for skipping over any
	* interceptors that may have become `null` calling `eject`.
	*
	* @param {Function} fn The function to call for each interceptor
	*
	* @returns {void}
	*/
	forEach(fn) {
		const internals = this[$internals];
		syncHandlerEntries(this, internals);
		internals.iterationDepth++;
		try {
			utils_default.forEach(this.handlers, function forEachHandler(h) {
				if (h !== null) fn(h);
			});
		} finally {
			if (!--internals.iterationDepth) {
				syncHandlerEntries(this, internals);
				trimHandlers(this.handlers);
				internals.handlersLength = countHandlers(this.handlers);
			}
		}
	}
};
// node_modules/axios/lib/defaults/transitional.js
var transitional_default = {
	silentJSONParsing: true,
	forcedJSONParsing: true,
	clarifyTimeoutError: false,
	legacyInterceptorReqResOrdering: true,
	advertiseZstdAcceptEncoding: false,
	validateStatusUndefinedResolves: true,
	encodeBasicAuthUsername: false
};
// node_modules/axios/lib/platform/browser/index.js
var browser_default = {
	isBrowser: true,
	classes: {
		URLSearchParams: typeof URLSearchParams !== "undefined" ? URLSearchParams : AxiosURLSearchParams,
		FormData: typeof FormData !== "undefined" ? FormData : null,
		Blob: typeof Blob !== "undefined" ? Blob : null
	},
	protocols: [
		"http",
		"https",
		"file",
		"blob",
		"url",
		"data"
	]
};
// node_modules/axios/lib/platform/common/utils.js
var utils_exports = /* @__PURE__ */ __exportAll({
	hasBrowserEnv: () => hasBrowserEnv,
	hasStandardBrowserEnv: () => hasStandardBrowserEnv,
	hasStandardBrowserWebWorkerEnv: () => hasStandardBrowserWebWorkerEnv,
	navigator: () => _navigator,
	origin: () => origin
});
var hasBrowserEnv = typeof window !== "undefined" && typeof document !== "undefined";
var _navigator = typeof navigator === "object" && navigator || void 0;
/**
* Determine if we're running in a standard browser environment
*
* This allows axios to run in a web worker, and react-native.
* Both environments support XMLHttpRequest, but not fully standard globals.
*
* web workers:
*  typeof window -> undefined
*  typeof document -> undefined
*
* react-native:
*  navigator.product -> 'ReactNative'
* nativescript
*  navigator.product -> 'NativeScript' or 'NS'
*
* @returns {boolean}
*/
var hasStandardBrowserEnv = hasBrowserEnv && (!_navigator || [
	"ReactNative",
	"NativeScript",
	"NS"
].indexOf(_navigator.product) < 0);
/**
* Determine if we're running in a standard browser webWorker environment
*
* Although the `isStandardBrowserEnv` method indicates that
* `allows axios to run in a web worker`, the WebWorker will still be
* filtered out due to its judgment standard
* `typeof window !== 'undefined' && typeof document !== 'undefined'`.
* This leads to a problem when axios post `FormData` in webWorker
*/
var hasStandardBrowserWebWorkerEnv = (() => {
	return typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope && typeof self.importScripts === "function";
})();
var origin = hasBrowserEnv && window.location.href || "http://localhost";
// node_modules/axios/lib/platform/index.js
var platform_default = {
	...utils_exports,
	...browser_default
};
// node_modules/axios/lib/helpers/toURLEncodedForm.js
function toURLEncodedForm(data, options) {
	return toFormData$1(data, new platform_default.classes.URLSearchParams(), {
		visitor: function(value, key, path, helpers) {
			if (platform_default.isNode && utils_default.isBuffer(value)) {
				this.append(key, value.toString("base64"));
				return false;
			}
			return helpers.defaultVisitor.apply(this, arguments);
		},
		...options
	});
}
// node_modules/axios/lib/helpers/formDataToJSON.js
var MAX_DEPTH = 100;
function throwIfDepthExceeded(index) {
	if (index > MAX_DEPTH) throw new AxiosError$1("FormData field is too deeply nested (" + index + " levels). Max depth: " + MAX_DEPTH, AxiosError$1.ERR_FORM_DATA_DEPTH_EXCEEDED);
}
/**
* It takes a string like `foo[x][y][z]` and returns an array like `['foo', 'x', 'y', 'z']
*
* @param {string} name - The name of the property to get.
*
* @returns An array of strings.
*/
function parsePropPath(name) {
	const path = [];
	const pattern = /[^.[\]]+|\[([^.[\]]*)]/g;
	let match;
	while ((match = pattern.exec(name)) !== null) {
		throwIfDepthExceeded(path.length);
		path.push(match[0] === "[]" ? "" : match[1] || match[0]);
	}
	return path;
}
/**
* Convert an array to an object.
*
* @param {Array<any>} arr - The array to convert to an object.
*
* @returns An object with the same keys and values as the array.
*/
function arrayToObject(arr) {
	const obj = {};
	const keys = Object.keys(arr);
	let i;
	const len = keys.length;
	let key;
	for (i = 0; i < len; i++) {
		key = keys[i];
		obj[key] = arr[key];
	}
	return obj;
}
function normalizeArray(value) {
	if (!utils_default.isArray(value)) return value;
	const keys = Object.keys(value);
	return keys.length !== value.length || keys.some((key, index) => key !== String(index)) ? arrayToObject(value) : value;
}
function normalizeArrays(obj) {
	const pending = [obj];
	while (pending.length) {
		const target = pending.pop();
		Object.keys(target).forEach((key) => {
			const value = target[key] = normalizeArray(target[key]);
			if (utils_default.isArray(value) || utils_default.isPlainObject(value)) pending.push(value);
		});
	}
	return obj;
}
/**
* It takes a FormData object and returns a JavaScript object
*
* @param {string} formData The FormData object to convert to JSON.
*
* @returns {Object<string, any> | null} The converted object.
*/
function formDataToJSON(formData) {
	function buildPath(path, value, target, index) {
		throwIfDepthExceeded(index);
		let name = path[index++];
		if (name === "__proto__") return true;
		const isNumericKey = Number.isFinite(+name);
		const isLast = index >= path.length;
		name = !name && utils_default.isArray(target) ? target.length : name;
		if (isLast) {
			if (utils_default.hasOwnProp(target, name)) {
				target[name] = normalizeArray(target[name]);
				target[name] = utils_default.isArray(target[name]) ? target[name].concat(value) : [target[name], value];
			} else target[name] = value;
			return !isNumericKey;
		}
		if (!utils_default.hasOwnProp(target, name) || !utils_default.isObject(target[name])) target[name] = [];
		if (buildPath(path, value, target[name], index) && utils_default.isArray(target[name])) target[name] = arrayToObject(target[name]);
		return !isNumericKey;
	}
	if (utils_default.isFormData(formData) && utils_default.isFunction(formData.entries)) {
		const obj = {};
		utils_default.forEachEntry(formData, (name, value) => {
			buildPath(parsePropPath(name), value, obj, 0);
		});
		return normalizeArrays(obj);
	}
	return null;
}
// node_modules/axios/lib/core/methodList.js
var methodList = Object.freeze([
	"get",
	"delete",
	"head",
	"options",
	"post",
	"put",
	"patch",
	"purge",
	"link",
	"unlink",
	"query"
]);
// node_modules/axios/lib/defaults/index.js
var own = (obj, key) => obj != null && utils_default.hasOwnProp(obj, key) ? obj[key] : void 0;
/**
* It takes a string, tries to parse it, and if it fails, it returns the stringified version
* of the input
*
* @param {any} rawValue - The value to be stringified.
* @param {Function} parser - A function that parses a string into a JavaScript object.
* @param {Function} encoder - A function that takes a value and returns a string.
*
* @returns {string} A stringified version of the rawValue.
*/
function stringifySafely(rawValue, parser, encoder) {
	if (utils_default.isString(rawValue)) try {
		(parser || JSON.parse)(rawValue);
		return utils_default.trim(rawValue);
	} catch (e) {
		if (e.name !== "SyntaxError") throw e;
	}
	return (encoder || JSON.stringify)(rawValue);
}
var defaults = {
	transitional: transitional_default,
	adapter: [
		"xhr",
		"http",
		"fetch"
	],
	transformRequest: [function transformRequest(data, headers) {
		const contentType = headers.getContentType() || "";
		const hasJSONContentType = contentType.indexOf("application/json") > -1;
		const isObjectPayload = utils_default.isObject(data);
		if (isObjectPayload && utils_default.isHTMLForm(data)) data = new FormData(data);
		if (utils_default.isFormData(data)) return hasJSONContentType ? JSON.stringify(formDataToJSON(data)) : data;
		if (utils_default.isArrayBuffer(data) || utils_default.isBuffer(data) || utils_default.isStream(data) || utils_default.isFile(data) || utils_default.isBlob(data) || utils_default.isReadableStream(data)) return data;
		if (utils_default.isArrayBufferView(data)) return data.buffer;
		if (utils_default.isURLSearchParams(data)) {
			headers.setContentType("application/x-www-form-urlencoded;charset=utf-8", false);
			return data.toString();
		}
		let isFileList;
		if (isObjectPayload) {
			const formSerializer = own(this, "formSerializer");
			if (contentType.indexOf("application/x-www-form-urlencoded") > -1) return toURLEncodedForm(data, formSerializer).toString();
			if ((isFileList = utils_default.isFileList(data)) || contentType.indexOf("multipart/form-data") > -1) {
				const env = own(this, "env");
				const _FormData = env && env.FormData;
				return toFormData$1(isFileList ? { "files[]": data } : data, _FormData && new _FormData(), formSerializer);
			}
		}
		if (isObjectPayload || hasJSONContentType) {
			headers.setContentType("application/json", false);
			return stringifySafely(data);
		}
		return data;
	}],
	transformResponse: [function transformResponse(data) {
		const transitional = own(this, "transitional") || defaults.transitional;
		const forcedJSONParsing = transitional && transitional.forcedJSONParsing;
		const responseType = own(this, "responseType");
		const JSONRequested = responseType === "json";
		if (utils_default.isResponse(data) || utils_default.isReadableStream(data)) return data;
		if (data && utils_default.isString(data) && (forcedJSONParsing && !responseType || JSONRequested)) {
			const strictJSONParsing = !(transitional && transitional.silentJSONParsing) && JSONRequested;
			try {
				return JSON.parse(data, own(this, "parseReviver"));
			} catch (e) {
				if (strictJSONParsing) {
					if (e.name === "SyntaxError") throw AxiosError$1.from(e, AxiosError$1.ERR_BAD_RESPONSE, this, null, own(this, "response"));
					throw e;
				}
			}
		}
		return data;
	}],
	/**
	* A timeout in milliseconds to abort a request. If set to 0 (default) a
	* timeout is not created.
	*/
	timeout: 0,
	xsrfCookieName: "XSRF-TOKEN",
	xsrfHeaderName: "X-XSRF-TOKEN",
	maxContentLength: -1,
	maxBodyLength: -1,
	env: {
		FormData: platform_default.classes.FormData,
		Blob: platform_default.classes.Blob
	},
	validateStatus: function validateStatus(status) {
		return status >= 200 && status < 300;
	},
	headers: { common: {
		Accept: "application/json, text/plain, */*",
		"Content-Type": void 0
	} }
};
utils_default.forEach(methodList, (method) => {
	defaults.headers[method] = {};
});
// node_modules/axios/lib/core/transformData.js
/**
* Transform the data for a request or a response
*
* @param {Array|Function} fns A single function or Array of functions
* @param {?Object} response The response object
*
* @returns {*} The resulting transformed data
*/
function transformData(fns, response) {
	const config = this || defaults;
	const context = response || config;
	const headers = AxiosHeaders$1.from(context.headers);
	let data = context.data;
	utils_default.forEach(fns, function transform(fn) {
		data = fn.call(config, data, headers.normalize(), response ? response.status : void 0);
	});
	headers.normalize();
	return data;
}
// node_modules/axios/lib/cancel/isCancel.js
function isCancel$1(value) {
	return !!(value && value.__CANCEL__);
}
// node_modules/axios/lib/cancel/CanceledError.js
var CanceledError$1 = class extends AxiosError$1 {
	/**
	* A `CanceledError` is an object that is thrown when an operation is canceled.
	*
	* @param {string=} message The message.
	* @param {Object=} config The config.
	* @param {Object=} request The request.
	*
	* @returns {CanceledError} The created error.
	*/
	constructor(message, config, request) {
		super(message == null ? "canceled" : message, AxiosError$1.ERR_CANCELED, config, request);
		this.name = "CanceledError";
		this.__CANCEL__ = true;
	}
};
// node_modules/axios/lib/core/settle.js
/**
* Resolve or reject a Promise based on response status.
*
* @param {Function} resolve A function that resolves the promise.
* @param {Function} reject A function that rejects the promise.
* @param {object} response The response.
*
* @returns {object} The response.
*/
function settle(resolve, reject, response) {
	const validateStatus = response.config.validateStatus;
	if (!response.status || !validateStatus || validateStatus(response.status)) resolve(response);
	else reject(new AxiosError$1("Request failed with status code " + response.status, response.status >= 400 && response.status < 500 ? AxiosError$1.ERR_BAD_REQUEST : AxiosError$1.ERR_BAD_RESPONSE, response.config, response.request, response));
}
// node_modules/axios/lib/helpers/normalizeURLForProtocolCheck.js
var urlParserControlCharacters = /[\t\n\r]/g;
/**
* Match WHATWG URL preprocessing before checking a URL's protocol.
*
* @param {string} url
*
* @returns {string}
*/
function normalizeURLForProtocolCheck(url) {
	if (typeof url !== "string") return url;
	let start = 0;
	while (start < url.length && url.charCodeAt(start) <= 32) start++;
	return url.slice(start).replace(urlParserControlCharacters, "");
}
// node_modules/axios/lib/helpers/parseProtocol.js
function parseProtocol(url) {
	const match = /^([-+\w]{1,25}):(?:\/\/)?/.exec(url);
	return match && match[1].toLowerCase() || "";
}
// node_modules/axios/lib/helpers/cookies.js
var decodeCookieValue = (value) => {
	try {
		return decodeURIComponent(value);
	} catch (e) {
		return value;
	}
};
var cookies_default = platform_default.hasStandardBrowserEnv ? {
	write(name, value, expires, path, domain, secure, sameSite) {
		if (typeof document === "undefined") return;
		const cookie = [`${name}=${encodeURIComponent(value)}`];
		if (utils_default.isNumber(expires)) cookie.push(`expires=${new Date(expires).toUTCString()}`);
		if (utils_default.isString(path)) cookie.push(`path=${path}`);
		if (utils_default.isString(domain)) cookie.push(`domain=${domain}`);
		if (secure === true) cookie.push("secure");
		if (utils_default.isString(sameSite)) cookie.push(`SameSite=${sameSite}`);
		document.cookie = cookie.join("; ");
	},
	read(name) {
		if (typeof document === "undefined") return null;
		const cookieString = document.cookie;
		if (!cookieString) return null;
		const cookies = cookieString.split(";");
		for (let i = 0; i < cookies.length; i++) {
			const cookie = cookies[i].replace(/^\s+/, "");
			const eq = cookie.indexOf("=");
			if (eq !== -1 && cookie.slice(0, eq) === name) return decodeCookieValue(cookie.slice(eq + 1));
		}
		return null;
	},
	async readAsync(name) {
		try {
			const store = typeof window !== "undefined" && window.cookieStore;
			if (store && utils_default.isFunction(store.get)) {
				const cookie = await store.get(name);
				return cookie ? decodeCookieValue(cookie.value) : null;
			}
		} catch (e) {}
		return this.read(name);
	},
	remove(name) {
		this.write(name, "", Date.now() - 864e5, "/");
	}
} : {
	write() {},
	read() {
		return null;
	},
	async readAsync() {
		return null;
	},
	remove() {}
};
// node_modules/axios/lib/helpers/speedometer.js
/**
* Calculate data maxRate
* @param {Number} [samplesCount= 10]
* @param {Number} [min= 1000]
* @returns {Function}
*/
function speedometer(samplesCount, min) {
	samplesCount = samplesCount || 10;
	const bytes = new Array(samplesCount);
	const timestamps = new Array(samplesCount);
	let head = 0;
	let tail = 0;
	let firstSampleTS;
	min = min !== void 0 ? min : 1e3;
	return function push(chunkLength) {
		const now = Date.now();
		const startedAt = timestamps[tail];
		if (!firstSampleTS) firstSampleTS = now;
		bytes[head] = chunkLength;
		timestamps[head] = now;
		let i = tail;
		let bytesCount = 0;
		while (i !== head) {
			bytesCount += bytes[i++];
			i = i % samplesCount;
		}
		head = (head + 1) % samplesCount;
		if (head === tail) tail = (tail + 1) % samplesCount;
		if (now - firstSampleTS < min) return;
		const passed = startedAt && now - startedAt;
		return passed ? Math.round(bytesCount * 1e3 / passed) : void 0;
	};
}
// node_modules/axios/lib/helpers/throttle.js
/**
* Throttle decorator
* @param {Function} fn
* @param {Number} freq
* @return {Array<Function>}
*/
function throttle(fn, freq) {
	let timestamp = 0;
	let threshold = 1e3 / freq;
	let lastArgs;
	let timer;
	const invoke = (args, now = Date.now()) => {
		timestamp = now;
		lastArgs = null;
		if (timer) {
			clearTimeout(timer);
			timer = null;
		}
		fn(...args);
	};
	const throttled = (...args) => {
		const now = Date.now();
		const passed = now - timestamp;
		if (passed >= threshold) invoke(args, now);
		else {
			lastArgs = args;
			if (!timer) timer = setTimeout(() => {
				timer = null;
				invoke(lastArgs);
			}, threshold - passed);
		}
	};
	const flush = () => lastArgs && invoke(lastArgs);
	const flushWith = (...args) => invoke(args);
	return [
		throttled,
		flush,
		flushWith
	];
}
// node_modules/axios/lib/helpers/progressEventReducer.js
var progressEventReducer = (listener, isDownloadStream, freq = 3) => {
	let bytesNotified = 0;
	const _speedometer = speedometer(50, 250);
	return throttle((e) => {
		if (!e || !utils_default.isNumber(e.loaded)) return;
		const rawLoaded = e.loaded;
		const total = e.lengthComputable ? e.total : void 0;
		const loaded = Math.max(0, total != null ? Math.min(rawLoaded, total) : rawLoaded);
		const progressBytes = Math.max(0, loaded - bytesNotified);
		const rate = _speedometer(progressBytes);
		bytesNotified = Math.max(bytesNotified, loaded);
		listener({
			loaded,
			total,
			progress: total ? loaded / total : void 0,
			bytes: progressBytes,
			rate: rate ? rate : void 0,
			estimated: rate && total ? (total - loaded) / rate : void 0,
			event: e,
			lengthComputable: total != null,
			[isDownloadStream ? "download" : "upload"]: true
		});
	}, freq);
};
var progressEventDecorator = (total, throttled) => {
	const lengthComputable = total != null;
	return [(loaded) => throttled[0]({
		lengthComputable,
		total,
		loaded
	}), throttled[1]];
};
var asyncDecorator = (fn, scheduler = utils_default.asap) => (...args) => scheduler(() => fn(...args));
// node_modules/axios/lib/helpers/isURLSameOrigin.js
var isURLSameOrigin_default = platform_default.hasStandardBrowserEnv ? ((origin) => (url) => {
	url = new URL(url, document.baseURI || platform_default.origin);
	return origin.protocol === url.protocol && origin.host === url.host && origin.port === url.port;
})(new URL(platform_default.origin)) : () => true;
// node_modules/axios/lib/helpers/isAbsoluteURL.js
/**
* Determines whether the specified URL is absolute
*
* @param {string} url The URL to test
*
* @returns {boolean} True if the specified URL is absolute, otherwise false
*/
function isAbsoluteURL(url) {
	if (typeof url !== "string") return false;
	return /^([a-z][a-z\d+\-.]*:)?\/\//i.test(url);
}
// node_modules/axios/lib/helpers/combineURLs.js
/**
* Creates a new URL by combining the specified URLs
*
* @param {string} baseURL The base URL
* @param {string} relativeURL The relative URL
*
* @returns {string} The combined URL
*/
function combineURLs(baseURL, relativeURL) {
	if (!relativeURL) return baseURL;
	let end = baseURL.length;
	while (end > 0 && baseURL.charCodeAt(end - 1) === 47) end--;
	return baseURL.slice(0, end) + "/" + relativeURL.replace(/^\/+/, "");
}
// node_modules/axios/lib/core/buildFullPath.js
var malformedHttpProtocol = /^https?:(?!\/\/)/i;
function redactFragment(fragment) {
	if (!fragment) return fragment;
	return fragment.replace(/(^|&)([^=&]*=)?[^&]+/g, (match, separator, parameterName = "") => {
		return `${separator}${parameterName}${REDACTED}`;
	});
}
function redactSensitiveURLParts(url) {
	const redactedURL = url.replace(/^(https?:\/{0,2})[^/?#]*@/i, `$1${REDACTED}@`);
	const fragmentIndex = redactedURL.indexOf("#");
	const redactedURLWithoutFragment = (fragmentIndex === -1 ? redactedURL : redactedURL.slice(0, fragmentIndex)).replace(/([?&][^=&#]*=)[^&#]*/g, `$1${REDACTED}`);
	if (fragmentIndex === -1) return redactedURLWithoutFragment;
	return `${redactedURLWithoutFragment}#${redactFragment(redactedURL.slice(fragmentIndex + 1))}`;
}
function assertValidHttpProtocolURL(url, config) {
	if (typeof url === "string") {
		const normalizedURL = normalizeURLForProtocolCheck(url);
		if (malformedHttpProtocol.test(normalizedURL)) throw new AxiosError$1(`Invalid URL ${JSON.stringify(redactSensitiveURLParts(normalizedURL))}: missing "//" after protocol`, AxiosError$1.ERR_INVALID_URL, config);
	}
}
/**
* Creates a new URL by combining the baseURL with the requestedURL,
* only when the requestedURL is not already an absolute URL.
* If the requestURL is absolute, this function returns the requestedURL untouched.
*
* @param {string} baseURL The base URL
* @param {string} requestedURL Absolute or relative URL to combine
*
* @returns {string} The combined full path
*/
function buildFullPath(baseURL, requestedURL, allowAbsoluteUrls, config) {
	assertValidHttpProtocolURL(requestedURL, config);
	let isRelativeUrl = !isAbsoluteURL(requestedURL);
	if (baseURL && (isRelativeUrl || allowAbsoluteUrls === false)) {
		assertValidHttpProtocolURL(baseURL, config);
		return combineURLs(baseURL, requestedURL);
	}
	return requestedURL;
}
// node_modules/axios/lib/core/assertParamsAcyclic.js
function assertParamsAcyclic(params) {
	const pending = [{ value: params }];
	const active = /* @__PURE__ */ new WeakSet();
	const visited = /* @__PURE__ */ new WeakSet();
	while (pending.length) {
		const { value, done } = pending.pop();
		if (!utils_default.isPlainObject(value) && !utils_default.isArray(value)) continue;
		if (done) {
			active.delete(value);
			continue;
		}
		if (active.has(value)) throw new AxiosError$1("Circular reference detected in params", AxiosError$1.ERR_BAD_OPTION_VALUE);
		if (visited.has(value)) continue;
		visited.add(value);
		active.add(value);
		pending.push({
			value,
			done: true
		});
		const keys = Object.keys(value);
		if (Object.getOwnPropertySymbols && Object.getOwnPropertyDescriptor) Object.getOwnPropertySymbols(value).forEach((key) => {
			const descriptor = Object.getOwnPropertyDescriptor(value, key);
			if (descriptor && descriptor.enumerable) keys.push(key);
		});
		keys.forEach((key) => {
			if (key === "__proto__" || key === "constructor" || key === "prototype") {
				const descriptor = Object.getOwnPropertyDescriptor(value, key);
				if (descriptor && utils_default.hasOwnProp(descriptor, "value")) pending.push({ value: descriptor.value });
			} else pending.push({ value: value[key] });
		});
	}
}
// node_modules/axios/lib/core/mergeConfig.js
var headersToObject = (thing) => thing instanceof AxiosHeaders$1 ? { ...thing } : thing;
var ownEnumerableKeys = (thing) => {
	if (Object.getOwnPropertySymbols && Object.getOwnPropertyDescriptor) return Object.keys(thing).concat(Object.getOwnPropertySymbols(thing).filter((symbol) => {
		const descriptor = Object.getOwnPropertyDescriptor(thing, symbol);
		return descriptor && descriptor.enumerable;
	}));
	return Object.keys(thing);
};
function mergeParams(a, b) {
	const pending = [];
	const copies = /* @__PURE__ */ new WeakMap();
	const empty = {};
	function copy(target, source) {
		if (!utils_default.isPlainObject(source)) return utils_default.isArray(source) ? source.slice() : source;
		const base = utils_default.isPlainObject(target) ? target : empty;
		let bases = copies.get(source);
		if (!bases) {
			bases = /* @__PURE__ */ new WeakMap();
			copies.set(source, bases);
		}
		if (bases.has(base)) return bases.get(base);
		const result = {};
		bases.set(base, result);
		pending.push({
			base,
			source,
			result
		});
		return result;
	}
	const result = utils_default.isUndefined(b) ? copy(void 0, a) : copy(a, b);
	while (pending.length) {
		const { base, source, result: target } = pending.pop();
		const baseKeys = new Set(ownEnumerableKeys(base));
		const sourceKeys = new Set(ownEnumerableKeys(source));
		(/* @__PURE__ */ new Set([...baseKeys, ...sourceKeys])).forEach((key) => {
			if (key === "__proto__" || key === "constructor" || key === "prototype") return;
			const hasSource = sourceKeys.has(key);
			const value = hasSource ? source[key] : void 0;
			const previous = (!hasSource || utils_default.isPlainObject(value)) && baseKeys.has(key) ? base[key] : void 0;
			target[key] = hasSource ? copy(previous, value) : copy(void 0, previous);
		});
	}
	assertParamsAcyclic(result);
	return result;
}
function getMergedValue(target, source, prop, caseless) {
	if (utils_default.isPlainObject(target) && utils_default.isPlainObject(source)) return utils_default.merge.call({ caseless }, target, source);
	else if (utils_default.isPlainObject(source)) return utils_default.merge({}, source);
	else if (utils_default.isArray(source)) return source.slice();
	return source;
}
function mergeDeepProperties(a, b, prop, caseless) {
	if (!utils_default.isUndefined(b)) return getMergedValue(a, b, prop, caseless);
	else if (!utils_default.isUndefined(a)) return getMergedValue(void 0, a, prop, caseless);
}
function valueFromConfig2(a, b) {
	if (!utils_default.isUndefined(b)) return getMergedValue(void 0, b);
}
function defaultToConfig2(a, b) {
	if (!utils_default.isUndefined(b)) return getMergedValue(void 0, b);
	else if (!utils_default.isUndefined(a)) return getMergedValue(void 0, a);
}
function getMergedTransitionalOption(config1, config2, prop) {
	const transitional2 = utils_default.hasOwnProp(config2, "transitional") ? config2.transitional : void 0;
	if (!utils_default.isUndefined(transitional2)) {
		if (utils_default.isPlainObject(transitional2)) {
			if (utils_default.hasOwnProp(transitional2, prop)) return transitional2[prop];
		} else return;
	}
	const transitional1 = utils_default.hasOwnProp(config1, "transitional") ? config1.transitional : void 0;
	if (utils_default.isPlainObject(transitional1) && utils_default.hasOwnProp(transitional1, prop)) return transitional1[prop];
}
function mergeDirectKeys(a, b, prop, config1, config2) {
	if (utils_default.hasOwnProp(config2, prop)) return getMergedValue(a, b);
	else if (utils_default.hasOwnProp(config1, prop)) return getMergedValue(void 0, a);
}
function mergeHeaders(a, b, prop) {
	return mergeDeepProperties(headersToObject(a), headersToObject(b), prop, true);
}
var hasOwnPropertyDescriptor = Object.freeze({
	__proto__: null,
	value: Object.prototype.hasOwnProperty,
	enumerable: false,
	writable: true,
	configurable: true
});
var mergeMap = {
	url: valueFromConfig2,
	method: valueFromConfig2,
	data: valueFromConfig2,
	baseURL: defaultToConfig2,
	transformRequest: defaultToConfig2,
	transformResponse: defaultToConfig2,
	params: mergeParams,
	paramsSerializer: defaultToConfig2,
	timeout: defaultToConfig2,
	timeoutErrorMessage: defaultToConfig2,
	withCredentials: defaultToConfig2,
	withXSRFToken: defaultToConfig2,
	adapter: defaultToConfig2,
	responseType: defaultToConfig2,
	xsrfCookieName: defaultToConfig2,
	xsrfHeaderName: defaultToConfig2,
	onUploadProgress: defaultToConfig2,
	onDownloadProgress: defaultToConfig2,
	decompress: defaultToConfig2,
	maxContentLength: defaultToConfig2,
	maxBodyLength: defaultToConfig2,
	beforeRedirect: defaultToConfig2,
	transport: defaultToConfig2,
	httpAgent: defaultToConfig2,
	httpsAgent: defaultToConfig2,
	cancelToken: defaultToConfig2,
	socketPath: defaultToConfig2,
	allowedSocketPaths: defaultToConfig2,
	responseEncoding: defaultToConfig2,
	validateStatus: mergeDirectKeys,
	headers: mergeHeaders
};
/**
* Config-specific merge-function which creates a new config-object
* by merging two configuration objects together.
*
* @param {Object} config1
* @param {Object} config2
*
* @returns {Object} New object resulting from merging config2 to config1
*/
function mergeConfig$1(config1, config2) {
	config1 = config1 || {};
	config2 = config2 || {};
	const config = Object.create(null);
	Object.defineProperty(config, "hasOwnProperty", hasOwnPropertyDescriptor);
	const keys = ownEnumerableKeys({
		...config1,
		...config2
	});
	for (let i = 0, len = keys.length; i < len; i++) {
		const prop = keys[i];
		if (prop === "__proto__" || prop === "constructor" || prop === "prototype") continue;
		const merge = utils_default.hasOwnProp(mergeMap, prop) ? mergeMap[prop] : mergeDeepProperties;
		const a = utils_default.hasOwnProp(config1, prop) ? config1[prop] : void 0;
		const b = utils_default.hasOwnProp(config2, prop) ? config2[prop] : void 0;
		const configValue = merge === mergeDirectKeys ? merge(a, b, prop, config1, config2) : merge(a, b, prop);
		utils_default.isUndefined(configValue) && merge !== mergeDirectKeys || (config[prop] = configValue);
	}
	if (utils_default.hasOwnProp(config2, "validateStatus") && utils_default.isUndefined(config2.validateStatus) && getMergedTransitionalOption(config1, config2, "validateStatusUndefinedResolves") === false) {
		if (utils_default.hasOwnProp(config1, "validateStatus")) config.validateStatus = getMergedValue(void 0, config1.validateStatus);
		else delete config.validateStatus;
	}
	return config;
}
// node_modules/axios/lib/core/setFormDataHeaders.js
var FORM_DATA_CONTENT_HEADERS = ["content-type", "content-length"];
/**
* Apply the headers generated by a FormData implementation to the request headers,
* honoring the `formDataHeaderPolicy` option: with 'content-only', copy only the
* content-* headers; otherwise merge all of them.
*
* @param {AxiosHeaders} headers - the request headers to mutate
* @param {Object | null | undefined} formHeaders - headers produced by the FormData implementation
* @param {String} [policy] - the resolved `formDataHeaderPolicy` config value
*
* @returns {void}
*/
function setFormDataHeaders(headers, formHeaders, policy) {
	if (policy !== "content-only") {
		headers.set(formHeaders);
		return;
	}
	Object.entries(formHeaders || {}).forEach(([key, val]) => {
		if (FORM_DATA_CONTENT_HEADERS.includes(key.toLowerCase())) headers.set(key, val);
	});
}
// node_modules/axios/lib/helpers/resolveConfig.js
/**
* Encode a UTF-8 string to a Latin-1 byte string for use with btoa().
* This is a modern replacement for the deprecated unescape(encodeURIComponent(str)) pattern.
*
* @param {string} str The string to encode
*
* @returns {string} UTF-8 bytes as a Latin-1 string
*/
var encodeUTF8$1 = (str) => encodeURIComponent(str).replace(/%([0-9A-F]{2})/gi, (_, hex) => String.fromCharCode(parseInt(hex, 16)));
var readCookie = (name) => cookies_default.read(name);
function resolveConfig(config, readXsrfCookie = readCookie) {
	const newConfig = mergeConfig$1({}, config);
	const own = (key) => utils_default.hasOwnProp(newConfig, key) ? newConfig[key] : void 0;
	const data = own("data");
	let withXSRFToken = own("withXSRFToken");
	const xsrfHeaderName = own("xsrfHeaderName");
	const xsrfCookieName = own("xsrfCookieName");
	let headers = own("headers");
	const auth = own("auth");
	const baseURL = own("baseURL");
	const allowAbsoluteUrls = own("allowAbsoluteUrls");
	const url = own("url");
	newConfig.headers = headers = AxiosHeaders$1.from(headers);
	newConfig.url = buildURL(buildFullPath(baseURL, url, allowAbsoluteUrls, newConfig), own("params"), own("paramsSerializer"));
	if (auth) {
		const username = utils_default.getSafeProp(auth, "username") || "";
		const password = utils_default.getSafeProp(auth, "password") || "";
		const transitional = own("transitional");
		const encodeUsername = transitional && utils_default.hasOwnProp(transitional, "encodeBasicAuthUsername") && transitional.encodeBasicAuthUsername === true;
		try {
			headers.set("Authorization", "Basic " + btoa((encodeUsername ? encodeUTF8$1(username) : username) + ":" + (password ? encodeUTF8$1(password) : "")));
		} catch (e) {
			throw AxiosError$1.from(e, AxiosError$1.ERR_BAD_OPTION_VALUE, config);
		}
	}
	if (utils_default.isFormData(data)) {
		const getHeaders = utils_default.getSafeProp(data, "getHeaders");
		if (platform_default.hasStandardBrowserEnv || platform_default.hasStandardBrowserWebWorkerEnv || utils_default.isReactNative(data)) headers.setContentType(void 0);
		else if (utils_default.isFunction(getHeaders)) setFormDataHeaders(headers, getHeaders.call(data), own("formDataHeaderPolicy"));
	}
	if (platform_default.hasStandardBrowserEnv) {
		if (utils_default.isFunction(withXSRFToken)) withXSRFToken = withXSRFToken(newConfig);
		if (withXSRFToken === true || withXSRFToken == null && isURLSameOrigin_default(newConfig.url)) {
			const xsrfValue = xsrfHeaderName && xsrfCookieName && readXsrfCookie(xsrfCookieName);
			if (xsrfValue) headers.set(xsrfHeaderName, xsrfValue);
		}
	}
	return newConfig;
}
var xhr_default = typeof XMLHttpRequest !== "undefined" && function(config) {
	return new Promise(function dispatchXhrRequest(resolve, reject) {
		let useAsyncXsrf;
		try {
			const store = platform_default.hasStandardBrowserEnv && typeof window !== "undefined" && window.cookieStore;
			useAsyncXsrf = store && utils_default.isFunction(store.get);
		} catch (e) {}
		let xsrfCookieName;
		const _config = resolveConfig(config, useAsyncXsrf ? (name) => {
			xsrfCookieName = name;
			return null;
		} : void 0);
		let requestData = _config.data;
		const requestHeaders = AxiosHeaders$1.from(_config.headers).normalize();
		let { responseType, onUploadProgress, onDownloadProgress } = _config;
		let onCanceled;
		let timeoutId;
		let uploadThrottled, downloadThrottled;
		let flushUpload, flushDownload, flushDownloadWithEvent;
		function done() {
			clearTimeout(timeoutId);
			try {
				flushUpload && flushUpload();
			} catch (err) {
				setTimeout(() => {
					throw err;
				});
			}
			try {
				flushDownload && flushDownload();
			} catch (err) {
				setTimeout(() => {
					throw err;
				});
			}
			if (request) {
				downloadThrottled && request.removeEventListener("progress", downloadThrottled);
				if (request.upload) {
					uploadThrottled && request.upload.removeEventListener("progress", uploadThrottled);
					flushUpload && request.upload.removeEventListener("loadend", flushUpload);
				}
			}
			_config.cancelToken && _config.cancelToken.unsubscribe(onCanceled);
			_config.signal && _config.signal.removeEventListener("abort", onCanceled);
		}
		let request = new XMLHttpRequest();
		request.open(_config.method.toUpperCase(), _config.url, true);
		request.timeout = _config.timeout;
		function onloadend(event) {
			if (!request) return;
			if (request.status === 0 && (parseProtocol(normalizeURLForProtocolCheck(_config.url)) || parseProtocol(platform_default.origin)) !== "file" && !(request.responseURL && request.responseURL.startsWith("file:"))) {
				reject(new AxiosError$1("Request aborted", AxiosError$1.ECONNABORTED, config, request));
				done();
				request = null;
				return;
			}
			try {
				if (event) flushDownloadWithEvent && flushDownloadWithEvent(event);
				else flushDownload && flushDownload();
			} catch (err) {
				setTimeout(() => {
					throw err;
				});
			}
			if (!request) return;
			const responseHeaders = AxiosHeaders$1.from("getAllResponseHeaders" in request && request.getAllResponseHeaders());
			settle(function _resolve(value) {
				resolve(value);
				done();
			}, function _reject(err) {
				reject(err);
				done();
			}, {
				data: !responseType || responseType === "text" || responseType === "json" ? request.responseText : request.response,
				status: request.status,
				statusText: request.statusText,
				headers: responseHeaders,
				config,
				request
			});
			request = null;
		}
		if ("onloadend" in request) request.onloadend = onloadend;
		else request.onreadystatechange = function handleLoad() {
			if (!request || request.readyState !== 4) return;
			if (request.status === 0 && !(request.responseURL && request.responseURL.startsWith("file:"))) return;
			setTimeout(onloadend);
		};
		request.onabort = function handleAbort() {
			if (!request) return;
			reject(new AxiosError$1("Request aborted", AxiosError$1.ECONNABORTED, config, request));
			done();
			request = null;
		};
		request.onerror = function handleError(event) {
			const err = new AxiosError$1(event && event.message ? event.message : "Network Error", AxiosError$1.ERR_NETWORK, config, request);
			err.event = event || null;
			reject(err);
			done();
			request = null;
		};
		request.ontimeout = function handleTimeout() {
			if (!request) return;
			let timeoutErrorMessage = _config.timeout ? "timeout of " + _config.timeout + "ms exceeded" : "timeout exceeded";
			const transitional = _config.transitional || transitional_default;
			if (_config.timeoutErrorMessage) timeoutErrorMessage = _config.timeoutErrorMessage;
			reject(new AxiosError$1(timeoutErrorMessage, transitional.clarifyTimeoutError ? AxiosError$1.ETIMEDOUT : AxiosError$1.ECONNABORTED, config, request));
			done();
			request = null;
		};
		requestData === void 0 && requestHeaders.setContentType(null);
		if (!utils_default.isUndefined(_config.withCredentials)) request.withCredentials = !!_config.withCredentials;
		if (responseType && responseType !== "json") request.responseType = _config.responseType;
		if (onDownloadProgress) {
			[downloadThrottled, flushDownload, flushDownloadWithEvent] = progressEventReducer(onDownloadProgress, true);
			request.addEventListener("progress", downloadThrottled);
		}
		if (onUploadProgress && request.upload) {
			[uploadThrottled, flushUpload] = progressEventReducer(onUploadProgress);
			request.upload.addEventListener("progress", uploadThrottled);
			request.upload.addEventListener("loadend", flushUpload);
		}
		if (_config.cancelToken || _config.signal) {
			onCanceled = (cancel) => {
				if (!request) return;
				reject(!cancel || cancel.type ? new CanceledError$1(null, config, request) : cancel);
				const xhr = request;
				done();
				request = null;
				xhr.abort();
			};
			_config.cancelToken && _config.cancelToken.subscribe(onCanceled);
			if (!request) return;
			if (_config.signal) _config.signal.aborted ? onCanceled() : _config.signal.addEventListener("abort", onCanceled);
		}
		if (!request) return;
		const protocol = parseProtocol(_config.url);
		if (protocol && !platform_default.protocols.includes(protocol)) {
			reject(new AxiosError$1("Unsupported protocol " + protocol + ":", AxiosError$1.ERR_BAD_REQUEST, config));
			done();
			return;
		}
		const sendRequest = () => {
			if (!request) return;
			if ("setRequestHeader" in request) utils_default.forEach(toByteStringHeaderObject(requestHeaders), function setRequestHeader(val, key) {
				request.setRequestHeader(key, val);
			});
			request.send(requestData || null);
		};
		if (xsrfCookieName) {
			const now = typeof performance !== "undefined" && utils_default.isFunction(performance.now) ? () => performance.now() : Date.now;
			const deadline = request.timeout > 0 ? now() + Number(request.timeout) : void 0;
			const abortOnTimeout = () => {
				if (!request) return;
				const xhr = request;
				xhr.ontimeout();
				xhr.abort();
			};
			if (deadline !== void 0) {
				const scheduleTimeout = () => {
					const remaining = deadline - now();
					if (remaining > 0) timeoutId = setTimeout(scheduleTimeout, Math.min(remaining, 2147483647));
					else abortOnTimeout();
				};
				scheduleTimeout();
			}
			cookies_default.readAsync(xsrfCookieName).then((value) => {
				if (!request) return;
				if (deadline !== void 0 && now() >= deadline) {
					abortOnTimeout();
					return;
				}
				if (value) {
					const headerName = utils_default.hasOwnProp(_config, "xsrfHeaderName") && _config.xsrfHeaderName;
					requestHeaders.set(headerName, value);
				}
				sendRequest();
			}).catch((error) => {
				if (!request) return;
				reject(AxiosError$1.from(error, null, config, request));
				done();
				request = null;
			});
		} else sendRequest();
	});
};
// node_modules/axios/lib/helpers/composeSignals.js
var composeSignals = (signals, timeout) => {
	signals = signals ? signals.filter(Boolean) : [];
	if (!timeout && !signals.length) return;
	const controller = new AbortController();
	let aborted = false;
	const onabort = function(reason) {
		if (!aborted) {
			aborted = true;
			unsubscribe();
			const err = reason instanceof Error ? reason : this.reason;
			controller.abort(err instanceof AxiosError$1 ? err : new CanceledError$1(err instanceof Error ? err.message : err));
		}
	};
	let timer = timeout && setTimeout(() => {
		timer = null;
		onabort(new AxiosError$1(`timeout of ${timeout}ms exceeded`, AxiosError$1.ETIMEDOUT));
	}, timeout);
	const unsubscribe = () => {
		if (!signals) return;
		timer && clearTimeout(timer);
		timer = null;
		signals.forEach((signal) => {
			const unsubscribeSignal = utils_default.getSafeProp(signal, "unsubscribe");
			utils_default.isFunction(unsubscribeSignal) ? unsubscribeSignal.call(signal, onabort) : signal.removeEventListener("abort", onabort);
		});
		signals = null;
	};
	signals.forEach((signal) => {
		if (aborted) return;
		if (signal.aborted) {
			onabort.call(signal);
			return;
		}
		signal.addEventListener("abort", onabort, { once: true });
	});
	const { signal } = controller;
	signal.unsubscribe = () => utils_default.asap(unsubscribe);
	return signal;
};
// node_modules/axios/lib/helpers/trackStream.js
var streamChunk = function* (chunk, chunkSize) {
	let len = chunk.byteLength;
	if (!chunkSize || len < chunkSize) {
		yield chunk;
		return;
	}
	let pos = 0;
	let end;
	while (pos < len) {
		end = pos + chunkSize;
		yield chunk.slice(pos, end);
		pos = end;
	}
};
var readBytes = async function* (iterable, chunkSize) {
	for await (const chunk of readStream(iterable)) yield* streamChunk(chunk, chunkSize);
};
var readStream = async function* (stream) {
	if (stream[Symbol.asyncIterator]) {
		yield* stream;
		return;
	}
	const reader = stream.getReader();
	try {
		for (;;) {
			const { done, value } = await reader.read();
			if (done) break;
			yield value;
		}
	} finally {
		await reader.cancel();
	}
};
var trackStream = (stream, chunkSize, onProgress, onFinish) => {
	const iterator = readBytes(stream, chunkSize);
	let bytes = 0;
	let done;
	let _onFinish = (e) => {
		if (!done) {
			done = true;
			onFinish && onFinish(e);
		}
	};
	return new ReadableStream({
		async pull(controller) {
			try {
				const { done, value } = await iterator.next();
				if (done) {
					_onFinish();
					controller.close();
					return;
				}
				let len = value.byteLength;
				if (onProgress) onProgress(bytes += len);
				controller.enqueue(new Uint8Array(value));
			} catch (err) {
				_onFinish(err);
				throw err;
			}
		},
		cancel(reason) {
			_onFinish(reason);
			return iterator.return();
		}
	}, { highWaterMark: 2 });
};
// node_modules/axios/lib/helpers/formDataToBlob.js
var CRLF = "\r\n";
var normalizeLines = (value) => String(value).replace(/\r\n|\r|\n/g, CRLF);
var escapeName = (value) => String(value).replace(/[\r\n"]/g, (char) => char === "\r" ? "%0D" : char === "\n" ? "%0A" : "%22");
var stringBytes = (value, normalize) => {
	let length = 0;
	for (let i = 0; i < value.length; i++) {
		const code = value.charCodeAt(i);
		if (normalize && (code === 13 || code === 10)) {
			if (code === 13 && value.charCodeAt(i + 1) === 10) i++;
			length += 2;
		} else if (code < 128) length++;
		else if (code < 2048) length += 2;
		else if (code >= 55296 && code <= 56319 && value.charCodeAt(i + 1) >= 56320 && value.charCodeAt(i + 1) <= 57343) {
			length += 4;
			i++;
		} else length += 3;
	}
	return length;
};
var FormDataError = class extends TypeError {
	constructor(message, reason) {
		super(message);
		this.name = "FormDataError";
		this.reason = reason;
	}
};
function formDataToBlob(form, Blob, limit, limitError, boundary) {
	if (!utils_default.isFunction(Blob)) throw new FormDataError("Blob is not supported", "blob");
	if (!utils_default.isString(boundary) || !/^[A-Za-z0-9'()+_,./:=? -]{1,70}$/.test(boundary) || / $/.test(boundary)) throw new FormDataError("Invalid multipart boundary", "boundary");
	const footer = "--" + boundary + "--\r\n";
	let length = footer.length;
	const parts = [];
	const checkLength = (extra) => {
		if (length + extra > limit) throw limitError();
	};
	checkLength(0);
	for (const [name, value] of form) {
		const isString = utils_default.isString(value);
		const valueLength = isString ? stringBytes(value, true) : value.size;
		if (!Number.isFinite(valueLength) || valueLength < 0) throw new FormDataError("Unsupported FormData part size", "part");
		checkLength(valueLength + stringBytes(name, true) + (!isString && value.name ? stringBytes(value.name, false) : 0) + (!isString && value.type ? stringBytes(value.type, false) : 0));
		let header = "--" + boundary + "\r\nContent-Disposition: form-data; name=\"" + escapeName(normalizeLines(name)) + "\"";
		if (!isString) header += "; filename=\"" + escapeName(utils_default.isString(value.name) ? value.name : "blob") + "\"\r\nContent-Type: " + String(value.type || "application/octet-stream").replace(/[\r\n]/g, "");
		header += "\r\n\r\n";
		const partLength = stringBytes(header, false) + valueLength + 2;
		checkLength(partLength);
		length += partLength;
		parts.push({
			header,
			value,
			isString
		});
	}
	const blobParts = [];
	for (const part of parts) blobParts.push(part.header, part.isString ? normalizeLines(part.value) : part.value, CRLF);
	blobParts.push(footer);
	return new Blob(blobParts, { type: "multipart/form-data; boundary=" + boundary });
}
// node_modules/axios/lib/core/createMultipartBody.js
function createMultipartBody(form, Blob, limit, limitError, boundary) {
	if (!utils_default.isFunction(Blob)) throw new AxiosError$1("Blob is not supported", AxiosError$1.ERR_NOT_SUPPORT);
	if (boundary === void 0) {
		if (utils_default.isFunction(platform_default.generateString)) boundary = "axios-" + platform_default.generateString(36, "0123456789abcdef");
		else {
			const crypto = utils_default.global.crypto;
			if (!crypto || !utils_default.isFunction(crypto.getRandomValues)) throw new AxiosError$1("Random byte generation is not supported", AxiosError$1.ERR_NOT_SUPPORT);
			const random = /* @__PURE__ */ new Uint8Array(18);
			crypto.getRandomValues(random);
			boundary = "axios-" + Array.from(random, (value) => ("0" + value.toString(16)).slice(-2)).join("");
		}
	}
	try {
		return formDataToBlob(form, Blob, limit, limitError, boundary);
	} catch (error) {
		if (error instanceof FormDataError) {
			const code = error.reason === "boundary" ? AxiosError$1.ERR_BAD_OPTION_VALUE : AxiosError$1.ERR_BAD_REQUEST;
			throw new AxiosError$1(error.message, code);
		}
		throw error;
	}
}
// node_modules/axios/lib/helpers/estimateDataURLDecodedBytes.js
/**
* Estimate data: URL byte lengths *without* allocating large buffers.
* - Fetch percent-decodes a base64 body before decoding it.
* - Node's Buffer.from(body, 'base64') sizes its backing allocation from the
*   percent-decoded body, including ignored characters and content after padding.
* - Non-base64 data is percent-decoded and then encoded as UTF-8.
*/
var isHexDigit = (charCode) => charCode >= 48 && charCode <= 57 || charCode >= 65 && charCode <= 70 || charCode >= 97 && charCode <= 102;
var isPercentEncodedByte = (str, i, len) => i + 2 < len && isHexDigit(str.charCodeAt(i + 1)) && isHexDigit(str.charCodeAt(i + 2));
var hexValue = (charCode) => charCode <= 57 ? charCode - 48 : (charCode & 223) - 55;
var isBase64Char = (charCode) => charCode >= 65 && charCode <= 90 || charCode >= 97 && charCode <= 122 || charCode >= 48 && charCode <= 57 || charCode === 43 || charCode === 47 || charCode === 45 || charCode === 95;
var isBase64Whitespace = (charCode) => charCode === 9 || charCode === 10 || charCode === 12 || charCode === 13 || charCode === 32;
var base64Bytes = (significant) => {
	const groups = Math.floor(significant / 4);
	const remainder = significant % 4;
	return groups * 3 + (remainder === 2 ? 1 : remainder === 3 ? 2 : 0);
};
var estimateBase64BufferAllocation = (body) => {
	const len = body.length;
	let padding = 0;
	if (len > 0 && body.charCodeAt(len - 1) === 61) {
		padding++;
		if (len > 1 && body.charCodeAt(len - 2) === 61) padding++;
	}
	return Math.floor((len - padding) * 3 / 4);
};
var estimatePercentDecodedBase64Bytes = (body) => {
	const len = body.length;
	let significant = 0;
	let padding = 0;
	let invalid = false;
	for (let i = 0; i < len; i++) {
		let code = body.charCodeAt(i);
		if (code === 37 && isPercentEncodedByte(body, i, len)) {
			code = hexValue(body.charCodeAt(i + 1)) * 16 + hexValue(body.charCodeAt(i + 2));
			i += 2;
		}
		if (isBase64Whitespace(code)) continue;
		if (code === 61) {
			padding++;
			continue;
		}
		if (!isBase64Char(code) || padding > 0) {
			invalid = true;
			continue;
		}
		significant++;
	}
	if (invalid || padding > 2 || padding > 0 && (significant + padding) % 4 !== 0 || significant % 4 === 1) return estimateBase64BufferAllocation(body);
	return base64Bytes(significant);
};
var estimateDataURLBytes = (url, estimateBase64, base64Pattern) => {
	if (!url || typeof url !== "string") return 0;
	if (!/^data:/i.test(url)) return 0;
	const comma = url.indexOf(",");
	if (comma < 0) return 0;
	const meta = url.slice(5, comma);
	const body = url.slice(comma + 1);
	if (base64Pattern.test(meta)) return estimateBase64(body);
	let bytes = 0;
	for (let i = 0, len = body.length; i < len; i++) {
		const c = body.charCodeAt(i);
		if (c === 37 && isPercentEncodedByte(body, i, len)) {
			bytes += 1;
			i += 2;
		} else if (c < 128) bytes += 1;
		else if (c < 2048) bytes += 2;
		else if (c >= 55296 && c <= 56319 && i + 1 < len) {
			const next = body.charCodeAt(i + 1);
			if (next >= 56320 && next <= 57343) {
				bytes += 4;
				i++;
			} else bytes += 3;
		} else bytes += 3;
	}
	return bytes;
};
/**
* Estimate the percent-decoded payload size used by Fetch data: URLs.
*
* @param {string} url
* @returns {number}
*/
function estimateDataURLDecodedBytes(url) {
	const fragmentIndex = typeof url === "string" ? url.indexOf("#") : -1;
	return estimateDataURLBytes(fragmentIndex === -1 ? url : url.slice(0, fragmentIndex), estimatePercentDecodedBase64Bytes, /; *base64[\t\n\f\r ]*$/i);
}
// node_modules/axios/lib/env/data.js
var VERSION$1 = "1.21.1";
// node_modules/axios/lib/adapters/fetch.js
var DEFAULT_CHUNK_SIZE = 65536;
var DEFAULT_REQUEST_OPTIONS = {
	cache: "default",
	redirect: "follow",
	referrer: "about:client",
	referrerPolicy: "",
	mode: "cors",
	integrity: "",
	keepalive: false,
	priority: "auto",
	window: null
};
var { isFunction } = utils_default;
/**
* Encode a UTF-8 string to a Latin-1 byte string for use with btoa().
* This is a modern replacement for the deprecated unescape(encodeURIComponent(str)) pattern.
*
* @param {string} str The string to encode
*
* @returns {string} UTF-8 bytes as a Latin-1 string
*/
var encodeUTF8 = (str) => encodeURIComponent(str).replace(/%([0-9A-F]{2})/gi, (_, hex) => String.fromCharCode(parseInt(hex, 16)));
var decodeURIComponentSafe = (value) => {
	if (!utils_default.isString(value)) return value;
	try {
		return decodeURIComponent(value);
	} catch (error) {
		return value;
	}
};
var test = (fn, ...args) => {
	try {
		return !!fn(...args);
	} catch (e) {
		return false;
	}
};
var maybeWithAuthCredentials = (url) => {
	const protocolIndex = url.indexOf("://");
	let urlToCheck = url;
	if (protocolIndex !== -1) urlToCheck = urlToCheck.slice(protocolIndex + 3);
	return urlToCheck.includes("@") || urlToCheck.includes(":");
};
var factory = (env) => {
	const globalObject = utils_default.global !== void 0 && utils_default.global !== null ? utils_default.global : globalThis;
	const { ReadableStream, TextEncoder } = globalObject;
	env = utils_default.merge.call({ skipUndefined: true }, {
		Request: globalObject.Request,
		Response: globalObject.Response,
		Blob: globalObject.Blob
	}, env);
	const envFetch = utils_default.hasOwnProp(env, "fetch") ? env.fetch : void 0;
	const { Request, Response, Blob } = env;
	const isFetchSupported = envFetch ? isFunction(envFetch) : typeof fetch === "function";
	const isRequestSupported = isFunction(Request);
	const isResponseSupported = isFunction(Response);
	if (!isFetchSupported) return false;
	const isReadableStreamSupported = isFetchSupported && isFunction(ReadableStream);
	const encodeText = isFetchSupported && (typeof TextEncoder === "function" ? ((encoder) => (str) => encoder.encode(str))(new TextEncoder()) : async (str) => new Uint8Array(await new Request(str).arrayBuffer()));
	const supportsRequestStream = isRequestSupported && isReadableStreamSupported && test(() => {
		let duplexAccessed = false;
		const request = new Request(platform_default.origin, {
			body: new ReadableStream(),
			method: "POST",
			get duplex() {
				duplexAccessed = true;
				return "half";
			}
		});
		const hasContentType = request.headers.has("Content-Type");
		if (request.body != null) request.body.cancel();
		return duplexAccessed && !hasContentType;
	});
	const supportsResponseStream = isResponseSupported && isReadableStreamSupported && test(() => utils_default.isReadableStream(new Response("").body));
	const requestDefaults = Object.assign(Object.create(null), DEFAULT_REQUEST_OPTIONS);
	if (isRequestSupported && !test(() => new Request(platform_default.origin, requestDefaults))) {
		delete requestDefaults.cache;
		if (!test(() => new Request(platform_default.origin, requestDefaults))) requestDefaults.cache = DEFAULT_REQUEST_OPTIONS.cache;
	}
	const resolvers = { stream: supportsResponseStream && ((res) => res.body) };
	isFetchSupported && (() => {
		[
			"text",
			"arrayBuffer",
			"blob",
			"formData",
			"stream"
		].forEach((type) => {
			!resolvers[type] && (resolvers[type] = (res, config) => {
				let method = res && res[type];
				if (method) return method.call(res);
				throw new AxiosError$1(`Response type '${type}' is not supported`, AxiosError$1.ERR_NOT_SUPPORT, config);
			});
		});
	})();
	const getBodyLength = async (body) => {
		if (body == null) return 0;
		if (utils_default.isBlob(body)) return body.size;
		if (utils_default.isArrayBufferView(body) || utils_default.isArrayBuffer(body)) return body.byteLength;
		if (utils_default.isURLSearchParams(body)) body = body + "";
		if (utils_default.isString(body)) return (await encodeText(body)).byteLength;
	};
	const resolveBodyLength = async (headers, body) => {
		const length = utils_default.toFiniteNumber(headers.getContentLength());
		return length == null ? getBodyLength(body) : length;
	};
	return async (config) => {
		let { url, method, data, signal, cancelToken, timeout, onDownloadProgress, onUploadProgress, responseType, headers, withCredentials = "same-origin", fetchOptions, maxContentLength, maxBodyLength, maxRedirects } = resolveConfig(config);
		const hasMaxContentLength = utils_default.isNumber(maxContentLength) && maxContentLength > -1;
		const hasMaxBodyLength = utils_default.isNumber(maxBodyLength) && maxBodyLength > -1;
		const own = (key) => utils_default.hasOwnProp(config, key) ? config[key] : void 0;
		let _fetch = envFetch || fetch;
		responseType = responseType ? (responseType + "").toLowerCase() : "text";
		let composedSignal = composeSignals([signal, cancelToken && cancelToken.toAbortSignal()], timeout);
		let request = null;
		const unsubscribe = composedSignal && composedSignal.unsubscribe && (() => {
			composedSignal.unsubscribe();
		});
		let requestContentLength;
		let pendingBodyError = null;
		let pendingResponseError = null;
		const maxBodyLengthError = () => new AxiosError$1("Request body larger than maxBodyLength limit", AxiosError$1.ERR_BAD_REQUEST, config, request);
		try {
			let auth = void 0;
			const configAuth = own("auth");
			if (configAuth) auth = {
				username: utils_default.getSafeProp(configAuth, "username") || "",
				password: utils_default.getSafeProp(configAuth, "password") || ""
			};
			let parsedURL;
			if (maybeWithAuthCredentials(url)) {
				parsedURL = new URL(url, platform_default.origin);
				if (!auth && (parsedURL.username || parsedURL.password)) auth = {
					username: decodeURIComponentSafe(parsedURL.username),
					password: decodeURIComponentSafe(parsedURL.password)
				};
				if (parsedURL.username || parsedURL.password) {
					parsedURL.username = "";
					parsedURL.password = "";
					url = parsedURL.href;
				}
			}
			if (auth) {
				headers.delete("authorization");
				headers.set("Authorization", "Basic " + btoa(encodeUTF8((auth.username || "") + ":" + (auth.password || ""))));
			}
			if (hasMaxContentLength && parsedURL && parsedURL.protocol === "data:") {
				if (estimateDataURLDecodedBytes(parsedURL.href) > maxContentLength) throw new AxiosError$1("maxContentLength size of " + maxContentLength + " exceeded", AxiosError$1.ERR_BAD_RESPONSE, config, request);
			}
			const formContentType = utils_default.isSpecCompliantForm(data) && AxiosHeaders$1.from(own("headers")).getContentType();
			let formBoundary;
			if (utils_default.isString(formContentType) && /^multipart\/form-data(?:\s*;|$)/i.test(formContentType.trim())) {
				const parameters = AxiosHeaders$1.parseParameters(formContentType);
				if (utils_default.hasOwnProp(parameters, "boundary")) formBoundary = parameters.boundary;
			}
			if (utils_default.isSpecCompliantForm(data) && method !== "get" && method !== "head" && (hasMaxBodyLength || onUploadProgress && supportsRequestStream || formBoundary !== void 0)) {
				data = createMultipartBody(data, Blob, hasMaxBodyLength ? maxBodyLength : Infinity, maxBodyLengthError, formBoundary);
				headers.setContentType(formBoundary === void 0 ? data.type : formContentType);
				requestContentLength = data.size;
			}
			if (hasMaxBodyLength && method !== "get" && method !== "head") {
				const outboundLength = await getBodyLength(data);
				if (typeof outboundLength === "number" && isFinite(outboundLength)) {
					requestContentLength = outboundLength;
					if (outboundLength > maxBodyLength) throw maxBodyLengthError();
				}
			}
			const mustEnforceStreamBody = hasMaxBodyLength && (utils_default.isReadableStream(data) || utils_default.isStream(data));
			const trackRequestStream = (stream, onProgress, flush) => trackStream(stream, DEFAULT_CHUNK_SIZE, (loadedBytes) => {
				if (hasMaxBodyLength && loadedBytes > maxBodyLength) throw pendingBodyError = maxBodyLengthError();
				onProgress && onProgress(loadedBytes);
			}, flush);
			if (supportsRequestStream && method !== "get" && method !== "head" && (onUploadProgress || mustEnforceStreamBody)) {
				requestContentLength = requestContentLength == null ? await resolveBodyLength(headers, data) : requestContentLength;
				if (requestContentLength !== 0 || mustEnforceStreamBody) {
					let _request = new Request(url, {
						method: "POST",
						body: data,
						duplex: "half"
					});
					let contentTypeHeader;
					if (utils_default.isFormData(data) && (contentTypeHeader = _request.headers.get("content-type"))) headers.setContentType(contentTypeHeader);
					if (_request.body) {
						const [onProgress, flush] = onUploadProgress && progressEventDecorator(requestContentLength, progressEventReducer(asyncDecorator(onUploadProgress))) || [];
						data = trackRequestStream(_request.body, onProgress, flush);
					}
				}
			} else if (mustEnforceStreamBody && !isRequestSupported && isReadableStreamSupported && method !== "get" && method !== "head") data = trackRequestStream(data);
			else if (mustEnforceStreamBody && isRequestSupported && !supportsRequestStream && method !== "get" && method !== "head") throw new AxiosError$1("Stream request bodies are not supported by the current fetch implementation", AxiosError$1.ERR_NOT_SUPPORT, config, request);
			if (!utils_default.isString(withCredentials)) withCredentials = withCredentials ? "include" : "omit";
			const isCredentialsSupported = isRequestSupported && "credentials" in Request.prototype;
			if (utils_default.isFormData(data)) {
				const contentType = headers.getContentType();
				if (contentType && /^multipart\/form-data/i.test(contentType) && !/boundary=/i.test(contentType)) headers.delete("content-type");
			}
			headers.set("User-Agent", "axios/" + VERSION$1, false);
			const safeFetchOptions = fetchOptions == null ? fetchOptions : Object.assign(Object.create(null), fetchOptions);
			if (safeFetchOptions) {
				delete safeFetchOptions.body;
				delete safeFetchOptions.headers;
				delete safeFetchOptions.method;
				delete safeFetchOptions.signal;
				delete safeFetchOptions.duplex;
				delete safeFetchOptions.credentials;
			}
			const resolvedOptions = Object.assign(Object.create(null), safeFetchOptions, {
				signal: composedSignal,
				method: method.toUpperCase(),
				headers: toByteStringHeaderObject(headers.normalize()),
				body: data,
				duplex: "half",
				credentials: isCredentialsSupported ? withCredentials : void 0
			});
			if (isRequestSupported) {
				utils_default.forEach(requestDefaults, (value, key) => {
					if (resolvedOptions[key] === void 0) resolvedOptions[key] = value;
				});
				if (resolvedOptions.signal === void 0) resolvedOptions.signal = null;
				if (resolvedOptions.body === void 0) resolvedOptions.body = null;
			}
			if (maxRedirects === 0) {
				resolvedOptions.redirect = "manual";
				if (safeFetchOptions) safeFetchOptions.redirect = "manual";
			}
			request = isRequestSupported && new Request(url, resolvedOptions);
			let response = await (isRequestSupported ? _fetch(request, safeFetchOptions) : _fetch(url, resolvedOptions));
			const responseHeaders = AxiosHeaders$1.from(response.headers);
			if (hasMaxContentLength) {
				const declaredLength = utils_default.toFiniteNumber(responseHeaders.getContentLength());
				if (declaredLength != null && declaredLength > maxContentLength) throw new AxiosError$1("maxContentLength size of " + maxContentLength + " exceeded", AxiosError$1.ERR_BAD_RESPONSE, config, request);
			}
			const isStreamResponse = supportsResponseStream && (responseType === "stream" || responseType === "response");
			if (supportsResponseStream && response.body && (onDownloadProgress || hasMaxContentLength || isStreamResponse && unsubscribe)) {
				const options = {};
				[
					"status",
					"statusText",
					"headers"
				].forEach((prop) => {
					options[prop] = response[prop];
				});
				const responseContentLength = utils_default.toFiniteNumber(responseHeaders.getContentLength());
				const [onProgress, flush] = onDownloadProgress && progressEventDecorator(responseContentLength, progressEventReducer(asyncDecorator(onDownloadProgress), true)) || [];
				let bytesRead = 0;
				const onChunkProgress = (loadedBytes) => {
					if (hasMaxContentLength) {
						bytesRead = loadedBytes;
						if (bytesRead > maxContentLength) throw pendingResponseError = new AxiosError$1("maxContentLength size of " + maxContentLength + " exceeded", AxiosError$1.ERR_BAD_RESPONSE, config, request);
					}
					onProgress && onProgress(loadedBytes);
				};
				response = new Response(trackStream(response.body, DEFAULT_CHUNK_SIZE, onChunkProgress, () => {
					flush && flush();
					unsubscribe && unsubscribe();
				}), options);
			}
			responseType = responseType || "text";
			let responseData = await resolvers[utils_default.findKey(resolvers, responseType) || "text"](response, config);
			if (hasMaxContentLength && !supportsResponseStream && !isStreamResponse) {
				let materializedSize;
				if (responseData != null) {
					if (typeof responseData.byteLength === "number") materializedSize = responseData.byteLength;
					else if (typeof responseData.size === "number") materializedSize = responseData.size;
					else if (typeof responseData === "string") materializedSize = typeof TextEncoder === "function" ? new TextEncoder().encode(responseData).byteLength : responseData.length;
				}
				if (typeof materializedSize === "number" && materializedSize > maxContentLength) throw new AxiosError$1("maxContentLength size of " + maxContentLength + " exceeded", AxiosError$1.ERR_BAD_RESPONSE, config, request);
			}
			!isStreamResponse && unsubscribe && unsubscribe();
			return await new Promise((resolve, reject) => {
				settle(resolve, reject, {
					data: responseData,
					headers: AxiosHeaders$1.from(response.headers),
					status: response.status,
					statusText: response.statusText,
					config,
					request
				});
			});
		} catch (err) {
			unsubscribe && unsubscribe();
			if (composedSignal && composedSignal.aborted && composedSignal.reason instanceof AxiosError$1) {
				const canceledError = composedSignal.reason;
				canceledError.config = config;
				request && (canceledError.request = request);
				if (err !== canceledError) Object.defineProperty(canceledError, "cause", {
					__proto__: null,
					value: err,
					writable: true,
					enumerable: false,
					configurable: true
				});
				throw canceledError;
			}
			if (pendingBodyError) {
				request && !pendingBodyError.request && (pendingBodyError.request = request);
				throw pendingBodyError;
			}
			if (pendingResponseError) throw pendingResponseError;
			if (err instanceof AxiosError$1) {
				request && !err.request && (err.request = request);
				throw err;
			}
			if (err && err.name === "TypeError" && /Load failed|fetch/i.test(err.message)) {
				const networkError = new AxiosError$1("Network Error", AxiosError$1.ERR_NETWORK, config, request, err && err.response);
				Object.defineProperty(networkError, "cause", {
					__proto__: null,
					value: err.cause || err,
					writable: true,
					enumerable: false,
					configurable: true
				});
				throw networkError;
			}
			throw AxiosError$1.from(err, err && err.code, config, request, err && err.response);
		}
	};
};
var seedCache = /* @__PURE__ */ new Map();
var getFetch = (config) => {
	const env = Object.create(null);
	const configuredEnv = config && utils_default.hasOwnProp(config, "env") && config.env;
	[
		"fetch",
		"Request",
		"Response",
		"Blob"
	].forEach((key) => {
		if (configuredEnv && utils_default.hasOwnProp(configuredEnv, key)) env[key] = configuredEnv[key];
	});
	const { fetch, Request, Response, Blob } = env;
	const seeds = [
		Request,
		Response,
		fetch,
		Blob
	];
	let i = seeds.length, seed, target, map = seedCache;
	while (i--) {
		seed = seeds[i];
		target = map.get(seed);
		target === void 0 && map.set(seed, target = i ? /* @__PURE__ */ new Map() : factory(env));
		map = target;
	}
	return target;
};
getFetch();
// node_modules/axios/lib/adapters/adapters.js
/**
* Known adapters mapping.
* Provides environment-specific adapters for Axios:
* - `http` for Node.js
* - `xhr` for browsers
* - `fetch` for fetch API-based requests
*
* @type {Object<string, Function|Object>}
*/
var knownAdapters = {
	http: null,
	xhr: xhr_default,
	fetch: { get: getFetch }
};
utils_default.forEach(knownAdapters, (fn, value) => {
	if (fn) {
		try {
			Object.defineProperty(fn, "name", {
				__proto__: null,
				value
			});
		} catch (e) {}
		Object.defineProperty(fn, "adapterName", {
			__proto__: null,
			value
		});
	}
});
/**
* Render a rejection reason string for unknown or unsupported adapters
*
* @param {string} reason
* @returns {string}
*/
var renderReason = (reason) => `- ${reason}`;
/**
* Check if the adapter is resolved (function, null, or false)
*
* @param {Function|null|false} adapter
* @returns {boolean}
*/
var isResolvedHandle = (adapter) => utils_default.isFunction(adapter) || adapter === null || adapter === false;
/**
* Get the first suitable adapter from the provided list.
* Tries each adapter in order until a supported one is found.
* Throws an AxiosError if no adapter is suitable.
*
* @param {Array<string|Function>|string|Function} adapters - Adapter(s) by name or function.
* @param {Object} config - Axios request configuration
* @throws {AxiosError} If no suitable adapter is available
* @returns {Function} The resolved adapter function
*/
function getAdapter$1(adapters, config) {
	adapters = utils_default.isArray(adapters) ? adapters : [adapters];
	const { length } = adapters;
	let nameOrAdapter;
	let adapter;
	const rejectedReasons = {};
	for (let i = 0; i < length; i++) {
		nameOrAdapter = adapters[i];
		let id;
		adapter = nameOrAdapter;
		if (!isResolvedHandle(nameOrAdapter)) {
			adapter = knownAdapters[(id = String(nameOrAdapter)).toLowerCase()];
			if (adapter === void 0) throw new AxiosError$1(`Unknown adapter '${id}'`);
		}
		if (adapter && (utils_default.isFunction(adapter) || (adapter = adapter.get(config)))) break;
		rejectedReasons[id || "#" + i] = adapter;
	}
	if (!adapter) {
		const reasons = Object.entries(rejectedReasons).map(([id, state]) => `adapter ${id} ` + (state === false ? "is not supported by the environment" : "is not available in the build"));
		throw new AxiosError$1(`There is no suitable adapter to dispatch the request ` + (length ? reasons.length > 1 ? "since :\n" + reasons.map(renderReason).join("\n") : " " + renderReason(reasons[0]) : "as no adapter specified"), AxiosError$1.ERR_NOT_SUPPORT);
	}
	return adapter;
}
/**
* Exports Axios adapters and utility to resolve an adapter
*/
var adapters_default = {
	/**
	* Resolve an adapter from a list of adapter names or functions.
	* @type {Function}
	*/
	getAdapter: getAdapter$1,
	/**
	* Exposes all known adapters
	* @type {Object<string, Function|Object>}
	*/
	adapters: knownAdapters
};
// node_modules/axios/lib/core/dispatchRequest.js
/**
* Throws a `CanceledError` if cancellation has been requested.
*
* @param {Object} config The config that is to be used for the request
*
* @returns {void}
*/
function throwIfCancellationRequested(config) {
	if (config.cancelToken) config.cancelToken.throwIfRequested();
	if (config.signal && config.signal.aborted) throw new CanceledError$1(null, config);
}
/**
* Resolve the clock used to time adapter execution.
*
* Prefers the monotonic `performance.now()` so wall-clock adjustments do not
* skew the measurement, and so frameworks that forbid reading the current
* time during prerendering (e.g. Next.js Cache Components) accept it. Falls
* back to `Date.now()` in runtimes without the High Resolution Time API.
*
* @returns {() => number} Millisecond clock
*/
function resolveClock() {
	return typeof performance !== "undefined" && utils_default.isFunction(performance.now) ? () => performance.now() : Date.now;
}
/**
* Whole milliseconds elapsed since `start`, floored at zero.
*
* Rounded so the value stays an integer as with `Date.now()`. The fallback
* wall clock can move backwards mid-request, so the result is clamped.
*
* @param {() => number} now Clock returned by `resolveClock()`
* @param {number} start Timestamp read from `now`
*
* @returns {number} Non-negative elapsed milliseconds
*/
function elapsedSince(now, start) {
	return Math.max(0, Math.round(now() - start));
}
/**
* Dispatch a request to the server using the configured adapter.
*
* @param {object} config The config that is to be used for the request
*
* @returns {Promise} The Promise to be fulfilled
*/
function dispatchRequest(_config) {
	const config = utils_default.toSafeFlatObject(_config);
	throwIfCancellationRequested(config);
	config.headers = AxiosHeaders$1.from(utils_default.getSafeProp(config, "headers"));
	config.data = transformData.call(config, config.transformRequest);
	if ([
		"post",
		"put",
		"patch"
	].indexOf(config.method) !== -1) config.headers.setContentType("application/x-www-form-urlencoded", false);
	const adapter = adapters_default.getAdapter(config.adapter || defaults.adapter, config);
	const now = resolveClock();
	const start = now();
	return adapter(config).then(function onAdapterResolution(response) {
		throwIfCancellationRequested(config);
		response.duration = elapsedSince(now, start);
		config.response = response;
		try {
			response.data = transformData.call(config, config.transformResponse, response);
		} finally {
			delete config.response;
		}
		response.headers = AxiosHeaders$1.from(response.headers);
		return response;
	}, function onAdapterRejection(reason) {
		if (!isCancel$1(reason)) {
			throwIfCancellationRequested(config);
			if (reason && reason.response) {
				reason.response.duration = elapsedSince(now, start);
				config.response = reason.response;
				try {
					reason.response.data = transformData.call(config, config.transformResponse, reason.response);
				} finally {
					delete config.response;
				}
				reason.response.headers = AxiosHeaders$1.from(reason.response.headers);
			}
		}
		return Promise.reject(reason);
	});
}
// node_modules/axios/lib/helpers/validator.js
var validators$1 = {};
[
	"object",
	"boolean",
	"number",
	"function",
	"string",
	"symbol"
].forEach((type, i) => {
	validators$1[type] = function validator(thing) {
		return typeof thing === type || "a" + (i < 1 ? "n " : " ") + type;
	};
});
var deprecatedWarnings = {};
/**
* Transitional option validator
*
* @param {function|boolean?} validator - set to false if the transitional option has been removed
* @param {string?} version - deprecated version / removed since version
* @param {string?} message - some message with additional info
*
* @returns {function}
*/
validators$1.transitional = function transitional(validator, version, message) {
	function formatMessage(opt, desc) {
		return "[Axios v" + VERSION$1 + "] Transitional option '" + opt + "'" + desc + (message ? ". " + message : "");
	}
	return (value, opt, opts) => {
		if (validator === false) throw new AxiosError$1(formatMessage(opt, " has been removed" + (version ? " in " + version : "")), AxiosError$1.ERR_DEPRECATED);
		if (version && !deprecatedWarnings[opt]) {
			deprecatedWarnings[opt] = true;
			console.warn(formatMessage(opt, " has been deprecated since v" + version + " and will be removed in the near future"));
		}
		return validator ? validator(value, opt, opts) : true;
	};
};
validators$1.spelling = function spelling(correctSpelling) {
	return (value, opt) => {
		console.warn(`${opt} is likely a misspelling of ${correctSpelling}`);
		return true;
	};
};
/**
* Assert object's properties type
*
* @param {object} options
* @param {object} schema
* @param {boolean?} allowUnknown
*
* @returns {object}
*/
function assertOptions(options, schema, allowUnknown) {
	if (typeof options !== "object" || options === null) throw new AxiosError$1("options must be an object", AxiosError$1.ERR_BAD_OPTION_VALUE);
	const keys = Object.keys(options);
	let i = keys.length;
	while (i-- > 0) {
		const opt = keys[i];
		const validator = Object.prototype.hasOwnProperty.call(schema, opt) ? schema[opt] : void 0;
		if (validator) {
			const value = options[opt];
			const result = value === void 0 || validator(value, opt, options);
			if (result !== true) throw new AxiosError$1("option " + opt + " must be " + result, AxiosError$1.ERR_BAD_OPTION_VALUE);
			continue;
		}
		if (allowUnknown !== true) throw new AxiosError$1("Unknown option " + opt, AxiosError$1.ERR_BAD_OPTION);
	}
}
var validator_default = {
	assertOptions,
	validators: validators$1
};
// node_modules/axios/lib/core/Axios.js
var validators = validator_default.validators;
var isHeadersBucket = (value) => {
	if (value == null || utils_default.isPlainObject(value) || value instanceof AxiosHeaders$1) return true;
	try {
		return utils_default.isObject(value) && utils_default.getSafeProp(value, Symbol.toStringTag) === "AxiosHeaders" && [
			"toJSON",
			"set",
			"get",
			"has",
			"delete",
			"clear",
			"normalize",
			"concat",
			"toString",
			Symbol.iterator
		].every((method) => utils_default.isFunction(utils_default.getSafeProp(value, method)));
	} catch (e) {
		return false;
	}
};
/**
* Create a new instance of Axios
*
* @param {Object} instanceConfig The default config for the instance
*
* @return {Axios} A new instance of Axios
*/
var Axios$1 = class {
	constructor(instanceConfig) {
		this.defaults = instanceConfig || {};
		this.interceptors = {
			request: new InterceptorManager(),
			response: new InterceptorManager()
		};
	}
	/**
	* Dispatch a request
	*
	* @param {String|Object} configOrUrl The config specific for this request (merged with this.defaults)
	* @param {?Object} config
	*
	* @returns {Promise} The Promise to be fulfilled
	*/
	async request(configOrUrl, config) {
		try {
			return await this._request(configOrUrl, config);
		} catch (err) {
			if (err instanceof Error) try {
				let dummy = {};
				Error.captureStackTrace ? Error.captureStackTrace(dummy) : dummy = /* @__PURE__ */ new Error();
				const dummyStack = dummy.stack;
				let stack = "";
				if (typeof dummyStack === "string") {
					const firstNewlineIndex = dummyStack.indexOf("\n");
					stack = firstNewlineIndex === -1 ? "" : dummyStack.slice(firstNewlineIndex + 1);
				}
				if (!err.stack) err.stack = stack;
				else if (stack) {
					const firstNewlineIndex = stack.indexOf("\n");
					const secondNewlineIndex = firstNewlineIndex === -1 ? -1 : stack.indexOf("\n", firstNewlineIndex + 1);
					const duplicateCheckSuffix = secondNewlineIndex === -1 ? stack : stack.slice(secondNewlineIndex + 1);
					const currentStack = String(err.stack);
					const causeIndex = getCauseStackIndex(err, currentStack);
					const stackHead = causeIndex === -1 ? currentStack : currentStack.slice(0, causeIndex);
					const causeSection = causeIndex === -1 ? "" : currentStack.slice(causeIndex);
					if (!stackHead.endsWith(duplicateCheckSuffix)) err.stack = stackHead + "\n" + stack + causeSection;
				}
			} catch (e) {}
			throw err;
		}
	}
	_request(configOrUrl, config) {
		if (typeof configOrUrl === "string") {
			config = config || {};
			config.url = configOrUrl;
		} else config = configOrUrl || {};
		config = mergeConfig$1(this.defaults, config);
		const { transitional, paramsSerializer, headers } = config;
		if (transitional !== void 0) validator_default.assertOptions(transitional, {
			silentJSONParsing: validators.transitional(validators.boolean),
			forcedJSONParsing: validators.transitional(validators.boolean),
			clarifyTimeoutError: validators.transitional(validators.boolean),
			legacyInterceptorReqResOrdering: validators.transitional(validators.boolean),
			advertiseZstdAcceptEncoding: validators.transitional(validators.boolean),
			validateStatusUndefinedResolves: validators.transitional(validators.boolean),
			encodeBasicAuthUsername: validators.transitional(validators.boolean)
		}, false);
		if (paramsSerializer != null) {
			if (utils_default.isFunction(paramsSerializer)) config.paramsSerializer = { serialize: paramsSerializer };
			else validator_default.assertOptions(paramsSerializer, {
				encode: validators.function,
				serialize: validators.function
			}, true);
		}
		if (config.allowAbsoluteUrls !== void 0) {} else if (utils_default.hasOwnProp(this.defaults, "allowAbsoluteUrls") && this.defaults.allowAbsoluteUrls !== void 0) config.allowAbsoluteUrls = this.defaults.allowAbsoluteUrls;
		else config.allowAbsoluteUrls = true;
		validator_default.assertOptions(config, {
			baseUrl: validators.spelling("baseURL"),
			withXsrfToken: validators.spelling("withXSRFToken")
		}, true);
		config.method = (utils_default.getSafeProp(config, "method") || utils_default.getSafeProp(this.defaults, "method") || "get").toLowerCase();
		const commonHeaders = utils_default.getSafeProp(headers, "common");
		const methodHeaders = utils_default.getSafeProp(headers, config.method);
		const contextHeaders = headers && utils_default.merge(isHeadersBucket(commonHeaders) ? commonHeaders : void 0, isHeadersBucket(methodHeaders) ? methodHeaders : void 0);
		headers && utils_default.forEach(methodList.concat("common"), (method) => {
			if (isHeadersBucket(utils_default.getSafeProp(headers, method))) delete headers[method];
		});
		config.headers = AxiosHeaders$1.concat(contextHeaders, headers);
		const requestInterceptorChain = [];
		let synchronousRequestInterceptors = true;
		this.interceptors.request.forEach(function unshiftRequestInterceptors(interceptor) {
			if (typeof interceptor.runWhen === "function" && interceptor.runWhen(config) === false) return;
			synchronousRequestInterceptors = synchronousRequestInterceptors && interceptor.synchronous;
			const transitional = config.transitional || transitional_default;
			if (transitional && transitional.legacyInterceptorReqResOrdering) requestInterceptorChain.unshift(interceptor.fulfilled, interceptor.rejected);
			else requestInterceptorChain.push(interceptor.fulfilled, interceptor.rejected);
		});
		const responseInterceptorChain = [];
		this.interceptors.response.forEach(function pushResponseInterceptors(interceptor) {
			responseInterceptorChain.push(interceptor.fulfilled, interceptor.rejected);
		});
		let promise;
		let i = 0;
		let len;
		if (!synchronousRequestInterceptors) {
			const chain = [dispatchRequest.bind(this), void 0];
			chain.unshift(...requestInterceptorChain);
			chain.push(...responseInterceptorChain);
			len = chain.length;
			promise = Promise.resolve(config);
			while (i < len) promise = promise.then(chain[i++], chain[i++]);
			return promise;
		}
		len = requestInterceptorChain.length;
		let newConfig = config;
		while (i < len) {
			const onFulfilled = requestInterceptorChain[i++];
			const onRejected = requestInterceptorChain[i++];
			try {
				newConfig = onFulfilled ? onFulfilled(newConfig) : newConfig;
			} catch (error) {
				if (!onRejected) {
					promise = Promise.reject(error);
					break;
				}
				try {
					const rejectedResult = onRejected.call(this, error);
					if (utils_default.isThenable(rejectedResult)) promise = Promise.resolve(rejectedResult).then(() => dispatchRequest.call(this, newConfig));
				} catch (rejectedError) {
					promise = Promise.reject(rejectedError);
				}
				break;
			}
		}
		if (!promise) try {
			promise = dispatchRequest.call(this, newConfig);
		} catch (error) {
			promise = Promise.reject(error);
		}
		i = 0;
		len = responseInterceptorChain.length;
		while (i < len) promise = promise.then(responseInterceptorChain[i++], responseInterceptorChain[i++]);
		return promise;
	}
	getUri(config) {
		config = mergeConfig$1(this.defaults, config);
		return buildURL(buildFullPath(config.baseURL, config.url, config.allowAbsoluteUrls, config), config.params, config.paramsSerializer);
	}
};
utils_default.forEach([
	"delete",
	"get",
	"head",
	"options"
], function forEachMethodNoData(method) {
	Axios$1.prototype[method] = async function(url, config) {
		return this.request(mergeConfig$1(config || {}, {
			method,
			url,
			data: config && utils_default.hasOwnProp(config, "data") ? config.data : void 0
		}));
	};
});
utils_default.forEach([
	"post",
	"put",
	"patch",
	"query"
], function forEachMethodWithData(method) {
	function generateHTTPMethod(isForm) {
		return async function httpMethod(url, data, config) {
			return this.request(mergeConfig$1(config || {}, {
				method,
				headers: isForm ? { "Content-Type": "multipart/form-data" } : {},
				url,
				data
			}));
		};
	}
	Axios$1.prototype[method] = generateHTTPMethod();
	if (method !== "query") Axios$1.prototype[method + "Form"] = generateHTTPMethod(true);
});
// node_modules/axios/lib/cancel/CancelToken.js
/**
* A `CancelToken` is an object that can be used to request cancellation of an operation.
*
* @param {Function} executor The executor function.
*
* @returns {CancelToken}
*/
var CancelToken$1 = class CancelToken$1 {
	constructor(executor) {
		if (typeof executor !== "function") throw new TypeError("executor must be a function.");
		let resolvePromise;
		this.promise = new Promise(function promiseExecutor(resolve) {
			resolvePromise = resolve;
		});
		const token = this;
		this.promise.then((cancel) => {
			if (!token._listeners) return;
			let i = token._listeners.length;
			while (i-- > 0) token._listeners[i](cancel);
			token._listeners = null;
		});
		this.promise.then = (onfulfilled) => {
			let _resolve;
			const promise = new Promise((resolve) => {
				token.subscribe(resolve);
				_resolve = resolve;
			}).then(onfulfilled);
			promise.cancel = function reject() {
				token.unsubscribe(_resolve);
			};
			return promise;
		};
		executor(function cancel(message, config, request) {
			if (token.reason) return;
			token.reason = new CanceledError$1(message, config, request);
			resolvePromise(token.reason);
		});
	}
	/**
	* Throws a `CanceledError` if cancellation has been requested.
	*/
	throwIfRequested() {
		if (this.reason) throw this.reason;
	}
	/**
	* Subscribe to the cancel signal
	*/
	subscribe(listener) {
		if (this.reason) {
			listener(this.reason);
			return;
		}
		if (this._listeners) this._listeners.push(listener);
		else this._listeners = [listener];
	}
	/**
	* Unsubscribe from the cancel signal
	*/
	unsubscribe(listener) {
		if (!this._listeners) return;
		const index = this._listeners.indexOf(listener);
		if (index !== -1) this._listeners.splice(index, 1);
	}
	toAbortSignal() {
		const controller = new AbortController();
		const abort = (err) => {
			controller.abort(err);
		};
		this.subscribe(abort);
		controller.signal.unsubscribe = () => this.unsubscribe(abort);
		return controller.signal;
	}
	/**
	* Returns an object that contains a new `CancelToken` and a function that, when called,
	* cancels the `CancelToken`.
	*/
	static source() {
		let cancel;
		return {
			token: new CancelToken$1(function executor(c) {
				cancel = c;
			}),
			cancel
		};
	}
};
// node_modules/axios/lib/helpers/spread.js
/**
* Syntactic sugar for invoking a function and expanding an array for arguments.
*
* Common use case would be to use `Function.prototype.apply`.
*
*  ```js
*  function f(x, y, z) {}
*  const args = [1, 2, 3];
*  f.apply(null, args);
*  ```
*
* With `spread` this example can be re-written.
*
*  ```js
*  spread(function(x, y, z) {})([1, 2, 3]);
*  ```
*
* @param {Function} callback
*
* @returns {Function}
*/
function spread$1(callback) {
	return function wrap(arr) {
		return callback.apply(null, arr);
	};
}
// node_modules/axios/lib/helpers/isAxiosError.js
/**
* Determines whether the payload is an error thrown by Axios
*
* @param {*} payload The value to test
*
* @returns {boolean} True if the payload is an error thrown by Axios, otherwise false
*/
function isAxiosError$1(payload) {
	return utils_default.isObject(payload) && payload.isAxiosError === true;
}
// node_modules/axios/lib/helpers/HttpStatusCode.js
var HttpStatusCode$1 = {
	Continue: 100,
	SwitchingProtocols: 101,
	Processing: 102,
	EarlyHints: 103,
	Ok: 200,
	Created: 201,
	Accepted: 202,
	NonAuthoritativeInformation: 203,
	NoContent: 204,
	ResetContent: 205,
	PartialContent: 206,
	MultiStatus: 207,
	AlreadyReported: 208,
	ImUsed: 226,
	MultipleChoices: 300,
	MovedPermanently: 301,
	Found: 302,
	SeeOther: 303,
	NotModified: 304,
	UseProxy: 305,
	Unused: 306,
	TemporaryRedirect: 307,
	PermanentRedirect: 308,
	BadRequest: 400,
	Unauthorized: 401,
	PaymentRequired: 402,
	Forbidden: 403,
	NotFound: 404,
	MethodNotAllowed: 405,
	NotAcceptable: 406,
	ProxyAuthenticationRequired: 407,
	RequestTimeout: 408,
	Conflict: 409,
	Gone: 410,
	LengthRequired: 411,
	PreconditionFailed: 412,
	/**
	* @deprecated Use `ContentTooLarge` instead.
	*/
	PayloadTooLarge: 413,
	ContentTooLarge: 413,
	UriTooLong: 414,
	UnsupportedMediaType: 415,
	RangeNotSatisfiable: 416,
	ExpectationFailed: 417,
	ImATeapot: 418,
	MisdirectedRequest: 421,
	/**
	* @deprecated Use `UnprocessableContent` instead.
	*/
	UnprocessableEntity: 422,
	UnprocessableContent: 422,
	Locked: 423,
	FailedDependency: 424,
	TooEarly: 425,
	UpgradeRequired: 426,
	PreconditionRequired: 428,
	TooManyRequests: 429,
	RequestHeaderFieldsTooLarge: 431,
	UnavailableForLegalReasons: 451,
	InternalServerError: 500,
	NotImplemented: 501,
	BadGateway: 502,
	ServiceUnavailable: 503,
	GatewayTimeout: 504,
	HttpVersionNotSupported: 505,
	VariantAlsoNegotiates: 506,
	InsufficientStorage: 507,
	LoopDetected: 508,
	NotExtended: 510,
	NetworkAuthenticationRequired: 511,
	WebServerReturnsAnUnknownError: 520,
	WebServerIsDown: 521,
	ConnectionTimedOut: 522,
	OriginIsUnreachable: 523,
	TimeoutOccurred: 524,
	SslHandshakeFailed: 525,
	InvalidSslCertificate: 526
};
Object.entries(HttpStatusCode$1).forEach(([key, value]) => {
	if (HttpStatusCode$1[value] === void 0) HttpStatusCode$1[value] = key;
});
// node_modules/axios/lib/axios.js
/**
* Create an instance of Axios
*
* @param {Object} defaultConfig The default config for the instance
*
* @returns {Axios} A new instance of Axios
*/
function createInstance(defaultConfig) {
	const context = new Axios$1(defaultConfig);
	const instance = bind(Axios$1.prototype.request, context);
	utils_default.extend(instance, Axios$1.prototype, context, { allOwnKeys: true });
	utils_default.extend(instance, context, null, { allOwnKeys: true });
	instance.create = function create(instanceConfig) {
		return createInstance(mergeConfig$1(defaultConfig, instanceConfig));
	};
	return instance;
}
var axios = createInstance(defaults);
axios.Axios = Axios$1;
axios.CanceledError = CanceledError$1;
axios.CancelToken = CancelToken$1;
axios.isCancel = isCancel$1;
axios.VERSION = VERSION$1;
axios.toFormData = toFormData$1;
axios.AxiosError = AxiosError$1;
axios.Cancel = axios.CanceledError;
axios.all = function all(promises) {
	return Promise.all(promises);
};
axios.spread = spread$1;
axios.isAxiosError = isAxiosError$1;
axios.mergeConfig = mergeConfig$1;
axios.AxiosHeaders = AxiosHeaders$1;
axios.formToJSON = (thing) => formDataToJSON(utils_default.isHTMLForm(thing) ? new FormData(thing) : thing);
axios.getAdapter = adapters_default.getAdapter;
axios.HttpStatusCode = HttpStatusCode$1;
axios.default = axios;
// node_modules/axios/index.js
var { Axios, AxiosError, CanceledError, isCancel, CancelToken, VERSION, all, Cancel, isAxiosError, spread, toFormData, AxiosHeaders, HttpStatusCode, formToJSON, getAdapter, mergeConfig, create } = axios;
export { Axios, AxiosError, AxiosHeaders, Cancel, CancelToken, CanceledError, HttpStatusCode, VERSION, all, create, axios as default, formToJSON, getAdapter, isAxiosError, isCancel, mergeConfig, spread, toFormData };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYXhpb3MuanMiLCJuYW1lcyI6WyJpc0Z1bmN0aW9uIiwidXRpbHMiLCJ1dGlscyIsIiRpbnRlcm5hbHMiLCJ1dGlscyIsIkF4aW9zSGVhZGVycyIsInBhcnNlSGVhZGVycyIsInV0aWxzIiwiQXhpb3NIZWFkZXJzIiwic3RyaW5naWZ5U2FmZWx5IiwiQXhpb3NFcnJvciIsInV0aWxzIiwidG9Gb3JtRGF0YSIsIkF4aW9zRXJyb3IiLCJlbmNvZGUiLCJ0b0Zvcm1EYXRhIiwidXRpbHMiLCJ1dGlscyIsInBsYXRmb3JtIiwidG9Gb3JtRGF0YSIsInBsYXRmb3JtIiwidXRpbHMiLCJBeGlvc0Vycm9yIiwidXRpbHMiLCJ1dGlscyIsInRyYW5zaXRpb25hbERlZmF1bHRzIiwidG9Gb3JtRGF0YSIsIkF4aW9zRXJyb3IiLCJwbGF0Zm9ybSIsIkF4aW9zSGVhZGVycyIsImlzQ2FuY2VsIiwiQ2FuY2VsZWRFcnJvciIsIkF4aW9zRXJyb3IiLCJBeGlvc0Vycm9yIiwicGxhdGZvcm0iLCJ1dGlscyIsInV0aWxzIiwicGxhdGZvcm0iLCJBeGlvc0Vycm9yIiwidXRpbHMiLCJBeGlvc0Vycm9yIiwiQXhpb3NIZWFkZXJzIiwidXRpbHMiLCJtZXJnZUNvbmZpZyIsImVuY29kZVVURjgiLCJjb29raWVzIiwibWVyZ2VDb25maWciLCJ1dGlscyIsIkF4aW9zSGVhZGVycyIsIkF4aW9zRXJyb3IiLCJwbGF0Zm9ybSIsImlzVVJMU2FtZU9yaWdpbiIsInBsYXRmb3JtIiwidXRpbHMiLCJBeGlvc0hlYWRlcnMiLCJBeGlvc0Vycm9yIiwidHJhbnNpdGlvbmFsRGVmYXVsdHMiLCJDYW5jZWxlZEVycm9yIiwiQXhpb3NFcnJvciIsIkNhbmNlbGVkRXJyb3IiLCJ1dGlscyIsInV0aWxzIiwidXRpbHMiLCJBeGlvc0Vycm9yIiwicGxhdGZvcm0iLCJWRVJTSU9OIiwidXRpbHMiLCJwbGF0Zm9ybSIsIkF4aW9zRXJyb3IiLCJBeGlvc0hlYWRlcnMiLCJWRVJTSU9OIiwieGhyQWRhcHRlciIsImZldGNoQWRhcHRlci5nZXRGZXRjaCIsInV0aWxzIiwiZ2V0QWRhcHRlciIsIkF4aW9zRXJyb3IiLCJDYW5jZWxlZEVycm9yIiwidXRpbHMiLCJBeGlvc0hlYWRlcnMiLCJhZGFwdGVycyIsImlzQ2FuY2VsIiwidmFsaWRhdG9ycyIsIlZFUlNJT04iLCJBeGlvc0Vycm9yIiwidmFsaWRhdG9yIiwidXRpbHMiLCJBeGlvc0hlYWRlcnMiLCJBeGlvcyIsIm1lcmdlQ29uZmlnIiwidHJhbnNpdGlvbmFsRGVmYXVsdHMiLCJDYW5jZWxUb2tlbiIsIkNhbmNlbGVkRXJyb3IiLCJzcHJlYWQiLCJpc0F4aW9zRXJyb3IiLCJ1dGlscyIsIkh0dHBTdGF0dXNDb2RlIiwiQXhpb3MiLCJtZXJnZUNvbmZpZyIsIkNhbmNlbGVkRXJyb3IiLCJDYW5jZWxUb2tlbiIsImlzQ2FuY2VsIiwiVkVSU0lPTiIsInRvRm9ybURhdGEiLCJBeGlvc0Vycm9yIiwic3ByZWFkIiwiaXNBeGlvc0Vycm9yIiwiQXhpb3NIZWFkZXJzIiwidXRpbHMiLCJhZGFwdGVycyIsIkh0dHBTdGF0dXNDb2RlIl0sInNvdXJjZXMiOlsiLi4vLi4vYXhpb3MvbGliL2hlbHBlcnMvYmluZC5qcyIsIi4uLy4uL2F4aW9zL2xpYi91dGlscy5qcyIsIi4uLy4uL2F4aW9zL2xpYi9oZWxwZXJzL3BhcnNlSGVhZGVycy5qcyIsIi4uLy4uL2F4aW9zL2xpYi9oZWxwZXJzL3Nhbml0aXplSGVhZGVyVmFsdWUuanMiLCIuLi8uLi9heGlvcy9saWIvY29yZS9BeGlvc0hlYWRlcnMuanMiLCIuLi8uLi9heGlvcy9saWIvY29yZS9BeGlvc0Vycm9yLmpzIiwiLi4vLi4vYXhpb3MvbGliL2hlbHBlcnMvdG9Gb3JtRGF0YS5qcyIsIi4uLy4uL2F4aW9zL2xpYi9oZWxwZXJzL0F4aW9zVVJMU2VhcmNoUGFyYW1zLmpzIiwiLi4vLi4vYXhpb3MvbGliL2hlbHBlcnMvYnVpbGRVUkwuanMiLCIuLi8uLi9heGlvcy9saWIvY29yZS9JbnRlcmNlcHRvck1hbmFnZXIuanMiLCIuLi8uLi9heGlvcy9saWIvZGVmYXVsdHMvdHJhbnNpdGlvbmFsLmpzIiwiLi4vLi4vYXhpb3MvbGliL3BsYXRmb3JtL2Jyb3dzZXIvY2xhc3Nlcy9VUkxTZWFyY2hQYXJhbXMuanMiLCIuLi8uLi9heGlvcy9saWIvcGxhdGZvcm0vYnJvd3Nlci9jbGFzc2VzL0Zvcm1EYXRhLmpzIiwiLi4vLi4vYXhpb3MvbGliL3BsYXRmb3JtL2Jyb3dzZXIvY2xhc3Nlcy9CbG9iLmpzIiwiLi4vLi4vYXhpb3MvbGliL3BsYXRmb3JtL2Jyb3dzZXIvaW5kZXguanMiLCIuLi8uLi9heGlvcy9saWIvcGxhdGZvcm0vY29tbW9uL3V0aWxzLmpzIiwiLi4vLi4vYXhpb3MvbGliL3BsYXRmb3JtL2luZGV4LmpzIiwiLi4vLi4vYXhpb3MvbGliL2hlbHBlcnMvdG9VUkxFbmNvZGVkRm9ybS5qcyIsIi4uLy4uL2F4aW9zL2xpYi9oZWxwZXJzL2Zvcm1EYXRhVG9KU09OLmpzIiwiLi4vLi4vYXhpb3MvbGliL2NvcmUvbWV0aG9kTGlzdC5qcyIsIi4uLy4uL2F4aW9zL2xpYi9kZWZhdWx0cy9pbmRleC5qcyIsIi4uLy4uL2F4aW9zL2xpYi9jb3JlL3RyYW5zZm9ybURhdGEuanMiLCIuLi8uLi9heGlvcy9saWIvY2FuY2VsL2lzQ2FuY2VsLmpzIiwiLi4vLi4vYXhpb3MvbGliL2NhbmNlbC9DYW5jZWxlZEVycm9yLmpzIiwiLi4vLi4vYXhpb3MvbGliL2NvcmUvc2V0dGxlLmpzIiwiLi4vLi4vYXhpb3MvbGliL2hlbHBlcnMvbm9ybWFsaXplVVJMRm9yUHJvdG9jb2xDaGVjay5qcyIsIi4uLy4uL2F4aW9zL2xpYi9oZWxwZXJzL3BhcnNlUHJvdG9jb2wuanMiLCIuLi8uLi9heGlvcy9saWIvaGVscGVycy9jb29raWVzLmpzIiwiLi4vLi4vYXhpb3MvbGliL2hlbHBlcnMvc3BlZWRvbWV0ZXIuanMiLCIuLi8uLi9heGlvcy9saWIvaGVscGVycy90aHJvdHRsZS5qcyIsIi4uLy4uL2F4aW9zL2xpYi9oZWxwZXJzL3Byb2dyZXNzRXZlbnRSZWR1Y2VyLmpzIiwiLi4vLi4vYXhpb3MvbGliL2hlbHBlcnMvaXNVUkxTYW1lT3JpZ2luLmpzIiwiLi4vLi4vYXhpb3MvbGliL2hlbHBlcnMvaXNBYnNvbHV0ZVVSTC5qcyIsIi4uLy4uL2F4aW9zL2xpYi9oZWxwZXJzL2NvbWJpbmVVUkxzLmpzIiwiLi4vLi4vYXhpb3MvbGliL2NvcmUvYnVpbGRGdWxsUGF0aC5qcyIsIi4uLy4uL2F4aW9zL2xpYi9jb3JlL2Fzc2VydFBhcmFtc0FjeWNsaWMuanMiLCIuLi8uLi9heGlvcy9saWIvY29yZS9tZXJnZUNvbmZpZy5qcyIsIi4uLy4uL2F4aW9zL2xpYi9jb3JlL3NldEZvcm1EYXRhSGVhZGVycy5qcyIsIi4uLy4uL2F4aW9zL2xpYi9oZWxwZXJzL3Jlc29sdmVDb25maWcuanMiLCIuLi8uLi9heGlvcy9saWIvYWRhcHRlcnMveGhyLmpzIiwiLi4vLi4vYXhpb3MvbGliL2hlbHBlcnMvY29tcG9zZVNpZ25hbHMuanMiLCIuLi8uLi9heGlvcy9saWIvaGVscGVycy90cmFja1N0cmVhbS5qcyIsIi4uLy4uL2F4aW9zL2xpYi9oZWxwZXJzL2Zvcm1EYXRhVG9CbG9iLmpzIiwiLi4vLi4vYXhpb3MvbGliL2NvcmUvY3JlYXRlTXVsdGlwYXJ0Qm9keS5qcyIsIi4uLy4uL2F4aW9zL2xpYi9oZWxwZXJzL2VzdGltYXRlRGF0YVVSTERlY29kZWRCeXRlcy5qcyIsIi4uLy4uL2F4aW9zL2xpYi9lbnYvZGF0YS5qcyIsIi4uLy4uL2F4aW9zL2xpYi9hZGFwdGVycy9mZXRjaC5qcyIsIi4uLy4uL2F4aW9zL2xpYi9hZGFwdGVycy9hZGFwdGVycy5qcyIsIi4uLy4uL2F4aW9zL2xpYi9jb3JlL2Rpc3BhdGNoUmVxdWVzdC5qcyIsIi4uLy4uL2F4aW9zL2xpYi9oZWxwZXJzL3ZhbGlkYXRvci5qcyIsIi4uLy4uL2F4aW9zL2xpYi9jb3JlL0F4aW9zLmpzIiwiLi4vLi4vYXhpb3MvbGliL2NhbmNlbC9DYW5jZWxUb2tlbi5qcyIsIi4uLy4uL2F4aW9zL2xpYi9oZWxwZXJzL3NwcmVhZC5qcyIsIi4uLy4uL2F4aW9zL2xpYi9oZWxwZXJzL2lzQXhpb3NFcnJvci5qcyIsIi4uLy4uL2F4aW9zL2xpYi9oZWxwZXJzL0h0dHBTdGF0dXNDb2RlLmpzIiwiLi4vLi4vYXhpb3MvbGliL2F4aW9zLmpzIiwiLi4vLi4vYXhpb3MvaW5kZXguanMiXSwic291cmNlc0NvbnRlbnQiOlsiJ3VzZSBzdHJpY3QnO1xuXG4vKipcbiAqIENyZWF0ZSBhIGJvdW5kIHZlcnNpb24gb2YgYSBmdW5jdGlvbiB3aXRoIGEgc3BlY2lmaWVkIGB0aGlzYCBjb250ZXh0XG4gKlxuICogQHBhcmFtIHtGdW5jdGlvbn0gZm4gLSBUaGUgZnVuY3Rpb24gdG8gYmluZFxuICogQHBhcmFtIHsqfSB0aGlzQXJnIC0gVGhlIHZhbHVlIHRvIGJlIHBhc3NlZCBhcyB0aGUgYHRoaXNgIHBhcmFtZXRlclxuICogQHJldHVybnMge0Z1bmN0aW9ufSBBIG5ldyBmdW5jdGlvbiB0aGF0IHdpbGwgY2FsbCB0aGUgb3JpZ2luYWwgZnVuY3Rpb24gd2l0aCB0aGUgc3BlY2lmaWVkIGB0aGlzYCBjb250ZXh0XG4gKi9cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIGJpbmQoZm4sIHRoaXNBcmcpIHtcbiAgcmV0dXJuIGZ1bmN0aW9uIHdyYXAoKSB7XG4gICAgcmV0dXJuIGZuLmFwcGx5KHRoaXNBcmcsIGFyZ3VtZW50cyk7XG4gIH07XG59XG4iLCIndXNlIHN0cmljdCc7XG5cbmltcG9ydCBiaW5kIGZyb20gJy4vaGVscGVycy9iaW5kLmpzJztcblxuLy8gdXRpbHMgaXMgYSBsaWJyYXJ5IG9mIGdlbmVyaWMgaGVscGVyIGZ1bmN0aW9ucyBub24tc3BlY2lmaWMgdG8gYXhpb3NcblxuY29uc3QgeyB0b1N0cmluZyB9ID0gT2JqZWN0LnByb3RvdHlwZTtcbmNvbnN0IHsgZ2V0UHJvdG90eXBlT2YgfSA9IE9iamVjdDtcbmNvbnN0IHsgaXRlcmF0b3IsIHRvU3RyaW5nVGFnIH0gPSBTeW1ib2w7XG5cbi8qIENyZWF0aW5nIGEgZnVuY3Rpb24gdGhhdCB3aWxsIGNoZWNrIGlmIGFuIG9iamVjdCBoYXMgYSBwcm9wZXJ0eS4gKi9cbmNvbnN0IGhhc093blByb3BlcnR5ID0gKFxuICAoeyBoYXNPd25Qcm9wZXJ0eSB9KSA9PlxuICAob2JqLCBwcm9wKSA9PlxuICAgIGhhc093blByb3BlcnR5LmNhbGwob2JqLCBwcm9wKVxuKShPYmplY3QucHJvdG90eXBlKTtcblxuY29uc3QgaXNVbnNhZmVPYmplY3RLZXkgPSAocHJvcCkgPT5cbiAgdHlwZW9mIHByb3AgPT09ICdzdHJpbmcnICYmXG4gIChwcm9wID09PSAnX19wcm90b19fJyB8fCBwcm9wID09PSAnY29uc3RydWN0b3InIHx8IHByb3AgPT09ICdwcm90b3R5cGUnKTtcblxuLyoqXG4gKiBEZXRlcm1pbmUgd2hldGhlciBhbiBpbmhlcml0ZWQgb2JqZWN0IG11c3QgYmUgdHJlYXRlZCBhcyBhIHNoYXJlZC1wcm90b3R5cGVcbiAqIGJvdW5kYXJ5LiBDcm9zcy1yZWFsbSBPYmplY3QucHJvdG90eXBlIG9iamVjdHMgY2Fubm90IGJlIGRpc3Rpbmd1aXNoZWRcbiAqIHJlbGlhYmx5IGZyb20gYXBwbGljYXRpb24tY3JlYXRlZCBudWxsLXByb3RvdHlwZSBvYmplY3RzIGJlY2F1c2UgdGhlaXJcbiAqIHByb3BlcnRpZXMgYXJlIG11dGFibGUsIHNvIGFsbCBpbmhlcml0ZWQgdGVybWluYWwgcHJvdG90eXBlcyBhcmUgZXhjbHVkZWRcbiAqIGFzIGEgZmFpbC1jbG9zZWQgYm91bmRhcnkuIEEgbnVsbC1wcm90b3R5cGUgc291cmNlIHN0aWxsIGtlZXBzIGl0cyBvd25cbiAqIHByb3BlcnRpZXMsIGFzIHByb2R1Y2VkIGJ5IG1lcmdlQ29uZmlnIGFuZCBvdGhlciBzYWZlIG1hdGVyaWFsaXphdGlvbiBwYXRocy5cbiAqXG4gKiBAcGFyYW0geyp9IG9iaiBUaGUgb2JqZWN0IHRvIGluc3BlY3RcbiAqIEBwYXJhbSB7Kn0gcHJvdG90eXBlIFRoZSBvYmplY3QncyBwcm90b3R5cGVcbiAqIEBwYXJhbSB7Ym9vbGVhbn0gc291cmNlIFdoZXRoZXIgb2JqIGlzIHRoZSBvcmlnaW5hbCB0cmF2ZXJzYWwgc291cmNlXG4gKlxuICogQHJldHVybnMge2Jvb2xlYW59IFRydWUgd2hlbiBvYmogaXMgYSBzYWZlIHByb3RvdHlwZSB0cmF2ZXJzYWwgYm91bmRhcnlcbiAqL1xuY29uc3QgaXNQcm90b3R5cGVCb3VuZGFyeSA9IChvYmosIHByb3RvdHlwZSwgc291cmNlKSA9PlxuICBvYmogPT09IE9iamVjdC5wcm90b3R5cGUgfHwgKCFzb3VyY2UgJiYgcHJvdG90eXBlID09PSBudWxsKTtcblxuLyoqXG4gKiBEZXRlcm1pbmUgd2hldGhlciBhbiBvYmplY3QgY2FuIHJldGFpbiBpdHMgaWRlbnRpdHkgdGhyb3VnaCBjb2RlIHBhdGhzIHRoYXRcbiAqIGFkZCwgcmVwbGFjZSwgYW5kIHJlbW92ZSBjb25maWcgcHJvcGVydGllcyB3aXRob3V0IGJ5cGFzc2luZyB1bnNhZmUta2V5XG4gKiBmaWx0ZXJpbmcuIEltbXV0YWJsZSBvYmplY3RzLCB1bnNhZmUta2V5LWJlYXJpbmcgb2JqZWN0cywgYW5kIG9iamVjdHMgd2l0aFxuICogYWNjZXNzb3Igb3IgcmVzdHJpY3RlZCBkYXRhIHByb3BlcnRpZXMgbXVzdCBiZSBtYXRlcmlhbGl6ZWQgaW5zdGVhZC5cbiAqXG4gKiBAcGFyYW0geyp9IG9iaiBUaGUgb2JqZWN0IHRvIGluc3BlY3RcbiAqXG4gKiBAcmV0dXJucyB7Ym9vbGVhbn0gVHJ1ZSB3aGVuIGV2ZXJ5IG93biBwcm9wZXJ0eSBpcyBzYWZlIGFuZCBmdWxseSBtdXRhYmxlXG4gKi9cbmNvbnN0IGlzU2FmZUFuZEZ1bGx5TXV0YWJsZSA9IChvYmopID0+IHtcbiAgaWYgKCFPYmplY3QuaXNFeHRlbnNpYmxlKG9iaikpIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cblxuICBjb25zdCBwcm9wcyA9IE9iamVjdC5nZXRPd25Qcm9wZXJ0eU5hbWVzKG9iaik7XG5cbiAgaWYgKE9iamVjdC5nZXRPd25Qcm9wZXJ0eVN5bWJvbHMpIHtcbiAgICBwcm9wcy5wdXNoKC4uLk9iamVjdC5nZXRPd25Qcm9wZXJ0eVN5bWJvbHMob2JqKSk7XG4gIH1cblxuICByZXR1cm4gcHJvcHMuZXZlcnkoKHByb3ApID0+IHtcbiAgICBpZiAoaXNVbnNhZmVPYmplY3RLZXkocHJvcCkpIHtcbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG5cbiAgICBjb25zdCBkZXNjcmlwdG9yID0gT2JqZWN0LmdldE93blByb3BlcnR5RGVzY3JpcHRvcihvYmosIHByb3ApO1xuXG4gICAgcmV0dXJuICEhZGVzY3JpcHRvciAmJiBkZXNjcmlwdG9yLmNvbmZpZ3VyYWJsZSAmJiBkZXNjcmlwdG9yLndyaXRhYmxlID09PSB0cnVlO1xuICB9KTtcbn07XG5cbi8qKlxuICogV2FsayB0aGUgcHJvdG90eXBlIGNoYWluIChleGNsdWRpbmcgdGhlIHNvdXJjZSByZWFsbSdzIE9iamVjdC5wcm90b3R5cGUpXG4gKiBsb29raW5nIGZvciBhbiBvd24gYHByb3BgLiBUaGlzIGRpc3Rpbmd1aXNoZXMgZ2VudWluZSBvd24vaW5oZXJpdGVkIG1lbWJlcnNcbiAqIOKAlCBpbmNsdWRpbmcgY2xhc3MgYWNjZXNzb3JzIGFuZCB0ZW1wbGF0ZSBwcm90b3R5cGVzIOKAlCBmcm9tIG1lbWJlcnMgaW5qZWN0ZWRcbiAqIHZpYSBPYmplY3QucHJvdG90eXBlIHBvbGx1dGlvbiAoZS5nLiBgT2JqZWN0LnByb3RvdHlwZS51c2VybmFtZSA9ICcuLi4nYCksXG4gKiB3aGljaCBsaXZlIG9uIE9iamVjdC5wcm90b3R5cGUgaXRzZWxmIGFuZCBhcmUgdGhlcmVmb3JlIG5ldmVyIG1hdGNoZWQuXG4gKlxuICogQHBhcmFtIHsqfSB0aGluZyBUaGUgdmFsdWUgd2hvc2UgY2hhaW4gdG8gaW5zcGVjdFxuICogQHBhcmFtIHtzdHJpbmd8c3ltYm9sfSBwcm9wIFRoZSBwcm9wZXJ0eSBrZXkgdG8gbG9vayBmb3JcbiAqXG4gKiBAcmV0dXJucyB7Ym9vbGVhbn0gVHJ1ZSB3aGVuIGBwcm9wYCBpcyBvd25lZCBiZWxvdyBPYmplY3QucHJvdG90eXBlXG4gKi9cbmNvbnN0IGhhc093bkluUHJvdG90eXBlQ2hhaW4gPSAodGhpbmcsIHByb3ApID0+IHtcbiAgbGV0IG9iaiA9IHRoaW5nO1xuICBjb25zdCBzZWVuID0gW107XG5cbiAgd2hpbGUgKG9iaiAhPSBudWxsKSB7XG4gICAgaWYgKHNlZW4uaW5kZXhPZihvYmopICE9PSAtMSkge1xuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgICBzZWVuLnB1c2gob2JqKTtcblxuICAgIGNvbnN0IHByb3RvdHlwZSA9IGdldFByb3RvdHlwZU9mKG9iaik7XG5cbiAgICBpZiAoaXNQcm90b3R5cGVCb3VuZGFyeShvYmosIHByb3RvdHlwZSwgb2JqID09PSB0aGluZykpIHtcbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG5cbiAgICBpZiAoaGFzT3duUHJvcGVydHkob2JqLCBwcm9wKSkge1xuICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxuICAgIG9iaiA9IHByb3RvdHlwZTtcbiAgfVxuICByZXR1cm4gZmFsc2U7XG59O1xuXG4vKipcbiAqIFJlYWQgYG9ialtwcm9wXWAgb25seSB3aGVuIGl0IGlzIHNhZmUgZnJvbSBPYmplY3QucHJvdG90eXBlIHBvbGx1dGlvbi4gT3duXG4gKiBwcm9wZXJ0aWVzIGFuZCBtZW1iZXJzIGluaGVyaXRlZCBmcm9tIGEgbm9uLU9iamVjdC5wcm90b3R5cGUgc291cmNlIChhIGNsYXNzXG4gKiBpbnN0YW5jZSBvciB0ZW1wbGF0ZSBvYmplY3QpIGFyZSBob25vcmVkOyBhIHZhbHVlIHJlYWNoYWJsZSBvbmx5IHRocm91Z2ggYVxuICogcG9sbHV0ZWQgT2JqZWN0LnByb3RvdHlwZSBpcyBpZ25vcmVkIGFuZCBgdW5kZWZpbmVkYCBpcyByZXR1cm5lZC5cbiAqXG4gKiBAcGFyYW0geyp9IG9iaiBUaGUgc291cmNlIG9iamVjdFxuICogQHBhcmFtIHtzdHJpbmd8c3ltYm9sfSBwcm9wIFRoZSBwcm9wZXJ0eSBrZXkgdG8gcmVhZFxuICpcbiAqIEByZXR1cm5zIHsqfSBUaGUgcmVzb2x2ZWQgdmFsdWUsIG9yIHVuZGVmaW5lZCB3aGVuIHVuc2FmZS9hYnNlbnRcbiAqL1xuY29uc3QgZ2V0U2FmZVByb3AgPSAob2JqLCBwcm9wKSA9PlxuICBvYmogIT0gbnVsbCAmJiBoYXNPd25JblByb3RvdHlwZUNoYWluKG9iaiwgcHJvcCkgPyBvYmpbcHJvcF0gOiB1bmRlZmluZWQ7XG5cbi8qKlxuICogRmxhdHRlbiBhbiBvYmplY3QgYW5kIGl0cyBhcHBsaWNhdGlvbi1kZWZpbmVkIHByb3RvdHlwZSBjaGFpbiBpbnRvIGFcbiAqIG51bGwtcHJvdG90eXBlIG9iamVjdC4gTWVtYmVycyBpbmhlcml0ZWQgb25seSBmcm9tIHRoZSBzb3VyY2UgcmVhbG0nc1xuICogT2JqZWN0LnByb3RvdHlwZSBhcmUgZGVsaWJlcmF0ZWx5IGV4Y2x1ZGVkLCB3aGlsZSBjbGFzcy90ZW1wbGF0ZSBtZW1iZXJzXG4gKiBiZWxvdyB0aGF0IGJvdW5kYXJ5IGFyZSBwcmVzZXJ2ZWQuXG4gKlxuICogQHBhcmFtIHsqfSB0aGluZyBUaGUgdmFsdWUgdG8gZmxhdHRlblxuICpcbiAqIEByZXR1cm5zIHsqfSBBIG51bGwtcHJvdG90eXBlIGNvcHksIG9yIHRoZSBvcmlnaW5hbCB2YWx1ZSB3aGVuIGl0IGlzIGFscmVhZHlcbiAqIHN0cnVjdHVyYWxseSBzYWZlIG9yIGlzIG5vdCBhbiBvYmplY3RcbiAqL1xuY29uc3QgdG9TYWZlRmxhdE9iamVjdCA9ICh0aGluZykgPT4ge1xuICBpZiAodGhpbmcgPT0gbnVsbCB8fCAodHlwZW9mIHRoaW5nICE9PSAnb2JqZWN0JyAmJiB0eXBlb2YgdGhpbmcgIT09ICdmdW5jdGlvbicpKSB7XG4gICAgcmV0dXJuIHRoaW5nO1xuICB9XG5cbiAgY29uc3Qgc291cmNlUHJvdG90eXBlID0gZ2V0UHJvdG90eXBlT2YodGhpbmcpO1xuXG4gIGlmIChzb3VyY2VQcm90b3R5cGUgPT09IG51bGwgJiYgaXNTYWZlQW5kRnVsbHlNdXRhYmxlKHRoaW5nKSkge1xuICAgIHJldHVybiB0aGluZztcbiAgfVxuXG4gIGNvbnN0IHJlc3VsdCA9IE9iamVjdC5jcmVhdGUobnVsbCk7XG4gIGNvbnN0IG1lcmdlZCA9IE9iamVjdC5jcmVhdGUobnVsbCk7XG4gIGNvbnN0IHNlZW4gPSBbXTtcbiAgbGV0IGN1cnJlbnQgPSB0aGluZztcblxuICB3aGlsZSAoY3VycmVudCAhPSBudWxsKSB7XG4gICAgaWYgKHNlZW4uaW5kZXhPZihjdXJyZW50KSAhPT0gLTEpIHtcbiAgICAgIGJyZWFrO1xuICAgIH1cblxuICAgIHNlZW4ucHVzaChjdXJyZW50KTtcblxuICAgIGNvbnN0IHByb3RvdHlwZSA9IGN1cnJlbnQgPT09IHRoaW5nID8gc291cmNlUHJvdG90eXBlIDogZ2V0UHJvdG90eXBlT2YoY3VycmVudCk7XG5cbiAgICBpZiAoaXNQcm90b3R5cGVCb3VuZGFyeShjdXJyZW50LCBwcm90b3R5cGUsIGN1cnJlbnQgPT09IHRoaW5nKSkge1xuICAgICAgYnJlYWs7XG4gICAgfVxuXG4gICAgY29uc3QgcHJvcHMgPSBPYmplY3QuZ2V0T3duUHJvcGVydHlOYW1lcyhjdXJyZW50KTtcblxuICAgIGlmIChPYmplY3QuZ2V0T3duUHJvcGVydHlTeW1ib2xzKSB7XG4gICAgICBwcm9wcy5wdXNoKC4uLk9iamVjdC5nZXRPd25Qcm9wZXJ0eVN5bWJvbHMoY3VycmVudCkpO1xuICAgIH1cblxuICAgIGZvciAoY29uc3QgcHJvcCBvZiBwcm9wcykge1xuICAgICAgaWYgKGlzVW5zYWZlT2JqZWN0S2V5KHByb3ApKSB7XG4gICAgICAgIGNvbnRpbnVlO1xuICAgICAgfVxuXG4gICAgICBpZiAoIWhhc093blByb3BlcnR5KG1lcmdlZCwgcHJvcCkpIHtcbiAgICAgICAgcmVzdWx0W3Byb3BdID0gdGhpbmdbcHJvcF07XG4gICAgICAgIG1lcmdlZFtwcm9wXSA9IHRydWU7XG4gICAgICB9XG4gICAgfVxuXG4gICAgY3VycmVudCA9IHByb3RvdHlwZTtcbiAgfVxuXG4gIHJldHVybiByZXN1bHQ7XG59O1xuXG5jb25zdCBraW5kT2YgPSAoKGNhY2hlKSA9PiAodGhpbmcpID0+IHtcbiAgY29uc3Qgc3RyID0gdG9TdHJpbmcuY2FsbCh0aGluZyk7XG4gIHJldHVybiBjYWNoZVtzdHJdIHx8IChjYWNoZVtzdHJdID0gc3RyLnNsaWNlKDgsIC0xKS50b0xvd2VyQ2FzZSgpKTtcbn0pKE9iamVjdC5jcmVhdGUobnVsbCkpO1xuXG5jb25zdCBraW5kT2ZUZXN0ID0gKHR5cGUpID0+IHtcbiAgdHlwZSA9IHR5cGUudG9Mb3dlckNhc2UoKTtcbiAgcmV0dXJuICh0aGluZykgPT4ga2luZE9mKHRoaW5nKSA9PT0gdHlwZTtcbn07XG5cbmNvbnN0IHR5cGVPZlRlc3QgPSAodHlwZSkgPT4gKHRoaW5nKSA9PiB0eXBlb2YgdGhpbmcgPT09IHR5cGU7XG5cbi8qKlxuICogRGV0ZXJtaW5lIGlmIGEgdmFsdWUgaXMgYSBub24tbnVsbCBvYmplY3RcbiAqXG4gKiBAcGFyYW0ge09iamVjdH0gdmFsIFRoZSB2YWx1ZSB0byB0ZXN0XG4gKlxuICogQHJldHVybnMge2Jvb2xlYW59IFRydWUgaWYgdmFsdWUgaXMgYW4gQXJyYXksIG90aGVyd2lzZSBmYWxzZVxuICovXG5jb25zdCB7IGlzQXJyYXkgfSA9IEFycmF5O1xuXG4vKipcbiAqIERldGVybWluZSBpZiBhIHZhbHVlIGlzIHVuZGVmaW5lZFxuICpcbiAqIEBwYXJhbSB7Kn0gdmFsIFRoZSB2YWx1ZSB0byB0ZXN0XG4gKlxuICogQHJldHVybnMge2Jvb2xlYW59IFRydWUgaWYgdGhlIHZhbHVlIGlzIHVuZGVmaW5lZCwgb3RoZXJ3aXNlIGZhbHNlXG4gKi9cbmNvbnN0IGlzVW5kZWZpbmVkID0gdHlwZU9mVGVzdCgndW5kZWZpbmVkJyk7XG5cbi8qKlxuICogRGV0ZXJtaW5lIGlmIGEgdmFsdWUgaXMgYSBCdWZmZXJcbiAqXG4gKiBAcGFyYW0geyp9IHZhbCBUaGUgdmFsdWUgdG8gdGVzdFxuICpcbiAqIEByZXR1cm5zIHtib29sZWFufSBUcnVlIGlmIHZhbHVlIGlzIGEgQnVmZmVyLCBvdGhlcndpc2UgZmFsc2VcbiAqL1xuZnVuY3Rpb24gaXNCdWZmZXIodmFsKSB7XG4gIHJldHVybiAoXG4gICAgdmFsICE9PSBudWxsICYmXG4gICAgIWlzVW5kZWZpbmVkKHZhbCkgJiZcbiAgICB2YWwuY29uc3RydWN0b3IgIT09IG51bGwgJiZcbiAgICAhaXNVbmRlZmluZWQodmFsLmNvbnN0cnVjdG9yKSAmJlxuICAgIGlzRnVuY3Rpb24odmFsLmNvbnN0cnVjdG9yLmlzQnVmZmVyKSAmJlxuICAgIHZhbC5jb25zdHJ1Y3Rvci5pc0J1ZmZlcih2YWwpXG4gICk7XG59XG5cbi8qKlxuICogRGV0ZXJtaW5lIGlmIGEgdmFsdWUgaXMgYW4gQXJyYXlCdWZmZXJcbiAqXG4gKiBAcGFyYW0geyp9IHZhbCBUaGUgdmFsdWUgdG8gdGVzdFxuICpcbiAqIEByZXR1cm5zIHtib29sZWFufSBUcnVlIGlmIHZhbHVlIGlzIGFuIEFycmF5QnVmZmVyLCBvdGhlcndpc2UgZmFsc2VcbiAqL1xuY29uc3QgaXNBcnJheUJ1ZmZlciA9IGtpbmRPZlRlc3QoJ0FycmF5QnVmZmVyJyk7XG5cbi8qKlxuICogRGV0ZXJtaW5lIGlmIGEgdmFsdWUgaXMgYSB2aWV3IG9uIGFuIEFycmF5QnVmZmVyXG4gKlxuICogQHBhcmFtIHsqfSB2YWwgVGhlIHZhbHVlIHRvIHRlc3RcbiAqXG4gKiBAcmV0dXJucyB7Ym9vbGVhbn0gVHJ1ZSBpZiB2YWx1ZSBpcyBhIHZpZXcgb24gYW4gQXJyYXlCdWZmZXIsIG90aGVyd2lzZSBmYWxzZVxuICovXG5mdW5jdGlvbiBpc0FycmF5QnVmZmVyVmlldyh2YWwpIHtcbiAgbGV0IHJlc3VsdDtcbiAgaWYgKHR5cGVvZiBBcnJheUJ1ZmZlciAhPT0gJ3VuZGVmaW5lZCcgJiYgQXJyYXlCdWZmZXIuaXNWaWV3KSB7XG4gICAgcmVzdWx0ID0gQXJyYXlCdWZmZXIuaXNWaWV3KHZhbCk7XG4gIH0gZWxzZSB7XG4gICAgcmVzdWx0ID0gdmFsICYmIHZhbC5idWZmZXIgJiYgaXNBcnJheUJ1ZmZlcih2YWwuYnVmZmVyKTtcbiAgfVxuICByZXR1cm4gcmVzdWx0O1xufVxuXG4vKipcbiAqIERldGVybWluZSBpZiBhIHZhbHVlIGlzIGEgU3RyaW5nXG4gKlxuICogQHBhcmFtIHsqfSB2YWwgVGhlIHZhbHVlIHRvIHRlc3RcbiAqXG4gKiBAcmV0dXJucyB7Ym9vbGVhbn0gVHJ1ZSBpZiB2YWx1ZSBpcyBhIFN0cmluZywgb3RoZXJ3aXNlIGZhbHNlXG4gKi9cbmNvbnN0IGlzU3RyaW5nID0gdHlwZU9mVGVzdCgnc3RyaW5nJyk7XG5cbi8qKlxuICogRGV0ZXJtaW5lIGlmIGEgdmFsdWUgaXMgYSBGdW5jdGlvblxuICpcbiAqIEBwYXJhbSB7Kn0gdmFsIFRoZSB2YWx1ZSB0byB0ZXN0XG4gKiBAcmV0dXJucyB7Ym9vbGVhbn0gVHJ1ZSBpZiB2YWx1ZSBpcyBhIEZ1bmN0aW9uLCBvdGhlcndpc2UgZmFsc2VcbiAqL1xuY29uc3QgaXNGdW5jdGlvbiA9IHR5cGVPZlRlc3QoJ2Z1bmN0aW9uJyk7XG5cbi8qKlxuICogRGV0ZXJtaW5lIGlmIGEgdmFsdWUgaXMgYSBOdW1iZXJcbiAqXG4gKiBAcGFyYW0geyp9IHZhbCBUaGUgdmFsdWUgdG8gdGVzdFxuICpcbiAqIEByZXR1cm5zIHtib29sZWFufSBUcnVlIGlmIHZhbHVlIGlzIGEgTnVtYmVyLCBvdGhlcndpc2UgZmFsc2VcbiAqL1xuY29uc3QgaXNOdW1iZXIgPSB0eXBlT2ZUZXN0KCdudW1iZXInKTtcblxuLyoqXG4gKiBEZXRlcm1pbmUgaWYgYSB2YWx1ZSBpcyBhbiBPYmplY3RcbiAqXG4gKiBAcGFyYW0geyp9IHRoaW5nIFRoZSB2YWx1ZSB0byB0ZXN0XG4gKlxuICogQHJldHVybnMge2Jvb2xlYW59IFRydWUgaWYgdmFsdWUgaXMgYW4gT2JqZWN0LCBvdGhlcndpc2UgZmFsc2VcbiAqL1xuY29uc3QgaXNPYmplY3QgPSAodGhpbmcpID0+IHRoaW5nICE9PSBudWxsICYmIHR5cGVvZiB0aGluZyA9PT0gJ29iamVjdCc7XG5cbi8qKlxuICogRGV0ZXJtaW5lIGlmIGEgdmFsdWUgaXMgYSBCb29sZWFuXG4gKlxuICogQHBhcmFtIHsqfSB0aGluZyBUaGUgdmFsdWUgdG8gdGVzdFxuICogQHJldHVybnMge2Jvb2xlYW59IFRydWUgaWYgdmFsdWUgaXMgYSBCb29sZWFuLCBvdGhlcndpc2UgZmFsc2VcbiAqL1xuY29uc3QgaXNCb29sZWFuID0gKHRoaW5nKSA9PiB0aGluZyA9PT0gdHJ1ZSB8fCB0aGluZyA9PT0gZmFsc2U7XG5cbi8qKlxuICogRGV0ZXJtaW5lIGlmIGEgdmFsdWUgaXMgYSBwbGFpbiBPYmplY3RcbiAqXG4gKiBAcGFyYW0geyp9IHZhbCBUaGUgdmFsdWUgdG8gdGVzdFxuICpcbiAqIEByZXR1cm5zIHtib29sZWFufSBUcnVlIGlmIHZhbHVlIGlzIGEgcGxhaW4gT2JqZWN0LCBvdGhlcndpc2UgZmFsc2VcbiAqL1xuY29uc3QgaXNQbGFpbk9iamVjdCA9ICh2YWwpID0+IHtcbiAgaWYgKCFpc09iamVjdCh2YWwpKSB7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG5cbiAgY29uc3QgcHJvdG90eXBlID0gZ2V0UHJvdG90eXBlT2YodmFsKTtcbiAgcmV0dXJuIChcbiAgICAocHJvdG90eXBlID09PSBudWxsIHx8IHByb3RvdHlwZSA9PT0gT2JqZWN0LnByb3RvdHlwZSB8fCBnZXRQcm90b3R5cGVPZihwcm90b3R5cGUpID09PSBudWxsKSAmJlxuICAgIC8vIFRyZWF0IG93biBTeW1ib2wudG9TdHJpbmdUYWcgb3IgU3ltYm9sLml0ZXJhdG9yIG1lbWJlcnMgYXMgZXZpZGVuY2UgdGhlXG4gICAgLy8gdmFsdWUgaXMgdGFnZ2VkL2l0ZXJhYmxlLCBpZ25vcmluZyBtZW1iZXJzIHJlYWNoYWJsZSBvbmx5IHRocm91Z2ggc2hhcmVkXG4gICAgLy8gb3IgdGVybWluYWwgcHJvdG90eXBlIGJvdW5kYXJpZXMuIFRoaXMgaXMgZXhhY3RseSB3aGF0XG4gICAgLy8gaGFzT3duSW5Qcm90b3R5cGVDaGFpbih2YWwsIHByb3ApIGNvbXB1dGVzIGhlcmU6IGV2ZXJ5IHByb3RvdHlwZSBhZG1pdHRlZFxuICAgIC8vIGFib3ZlIChudWxsLCBPYmplY3QucHJvdG90eXBlLCBvciBhIHRlcm1pbmFsIG51bGwtcHJvdG90eXBlIHRlbXBsYXRlKSBpc1xuICAgIC8vIGEgYm91bmRhcnksIHNvIHRoZSB3YWxrIG5ldmVyIGluc3BlY3RzIGFueXRoaW5nIGJ1dCBgdmFsYCdzIG93biBtZW1iZXJzLFxuICAgIC8vIGFuZCBzdG9wcyBiZWZvcmUgZXZlbiB0aG9zZSB3aGVuIGB2YWxgIGlzIGl0c2VsZiB0aGUgYm91bmRhcnlcbiAgICAvLyBPYmplY3QucHJvdG90eXBlLiBDaGVja2luZyB0aGF0IGlubGluZSBhdm9pZHMgYWxsb2NhdGluZyB0aGUgd2Fsa2VyJ3NcbiAgICAvLyBgc2VlbmAgbGlzdCB0d2ljZSBwZXIgY2FsbCBvbiB0aGUgbWVyZ2VDb25maWcgLyBtZXJnZSBob3QgcGF0aC5cbiAgICAoaXNQcm90b3R5cGVCb3VuZGFyeSh2YWwsIHByb3RvdHlwZSwgdHJ1ZSkgfHxcbiAgICAgICghaGFzT3duUHJvcGVydHkodmFsLCB0b1N0cmluZ1RhZykgJiYgIWhhc093blByb3BlcnR5KHZhbCwgaXRlcmF0b3IpKSlcbiAgKTtcbn07XG5cbi8qKlxuICogRGV0ZXJtaW5lIGlmIGEgdmFsdWUgaXMgYW4gZW1wdHkgb2JqZWN0IChzYWZlbHkgaGFuZGxlcyBCdWZmZXJzKVxuICpcbiAqIEBwYXJhbSB7Kn0gdmFsIFRoZSB2YWx1ZSB0byB0ZXN0XG4gKlxuICogQHJldHVybnMge2Jvb2xlYW59IFRydWUgaWYgdmFsdWUgaXMgYW4gZW1wdHkgb2JqZWN0LCBvdGhlcndpc2UgZmFsc2VcbiAqL1xuY29uc3QgaXNFbXB0eU9iamVjdCA9ICh2YWwpID0+IHtcbiAgLy8gRWFybHkgcmV0dXJuIGZvciBub24tb2JqZWN0cyBvciBCdWZmZXJzIHRvIHByZXZlbnQgUmFuZ2VFcnJvclxuICBpZiAoIWlzT2JqZWN0KHZhbCkgfHwgaXNCdWZmZXIodmFsKSkge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuXG4gIHRyeSB7XG4gICAgcmV0dXJuIE9iamVjdC5rZXlzKHZhbCkubGVuZ3RoID09PSAwICYmIE9iamVjdC5nZXRQcm90b3R5cGVPZih2YWwpID09PSBPYmplY3QucHJvdG90eXBlO1xuICB9IGNhdGNoIChlKSB7XG4gICAgLy8gRmFsbGJhY2sgZm9yIGFueSBvdGhlciBvYmplY3RzIHRoYXQgbWlnaHQgY2F1c2UgUmFuZ2VFcnJvciB3aXRoIE9iamVjdC5rZXlzKClcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbn07XG5cbi8qKlxuICogRGV0ZXJtaW5lIGlmIGEgdmFsdWUgaXMgYSBEYXRlXG4gKlxuICogQHBhcmFtIHsqfSB2YWwgVGhlIHZhbHVlIHRvIHRlc3RcbiAqXG4gKiBAcmV0dXJucyB7Ym9vbGVhbn0gVHJ1ZSBpZiB2YWx1ZSBpcyBhIERhdGUsIG90aGVyd2lzZSBmYWxzZVxuICovXG5jb25zdCBpc0RhdGUgPSBraW5kT2ZUZXN0KCdEYXRlJyk7XG5cbi8qKlxuICogRGV0ZXJtaW5lIGlmIGEgdmFsdWUgaXMgYSBGaWxlXG4gKlxuICogQHBhcmFtIHsqfSB2YWwgVGhlIHZhbHVlIHRvIHRlc3RcbiAqXG4gKiBAcmV0dXJucyB7Ym9vbGVhbn0gVHJ1ZSBpZiB2YWx1ZSBpcyBhIEZpbGUsIG90aGVyd2lzZSBmYWxzZVxuICovXG5jb25zdCBpc0ZpbGUgPSBraW5kT2ZUZXN0KCdGaWxlJyk7XG5cbi8qKlxuICogRGV0ZXJtaW5lIGlmIGEgdmFsdWUgaXMgYSBSZWFjdCBOYXRpdmUgQmxvYlxuICogUmVhY3QgTmF0aXZlIFwiYmxvYlwiOiBhbiBvYmplY3Qgd2l0aCBhIGB1cmlgIGF0dHJpYnV0ZS4gT3B0aW9uYWxseSwgaXQgY2FuXG4gKiBhbHNvIGhhdmUgYSBgbmFtZWAgYW5kIGB0eXBlYCBhdHRyaWJ1dGUgdG8gc3BlY2lmeSBmaWxlbmFtZSBhbmQgY29udGVudCB0eXBlXG4gKlxuICogQHNlZSBodHRwczovL2dpdGh1Yi5jb20vZmFjZWJvb2svcmVhY3QtbmF0aXZlL2Jsb2IvMjY2ODRjZjNhZGY0MDk0ZWI2YzQwNWQzNDVhNzViZjhjN2MwYmY4OC9MaWJyYXJpZXMvTmV0d29yay9Gb3JtRGF0YS5qcyNMNjgtTDcxXG4gKlxuICogQHBhcmFtIHsqfSB2YWx1ZSBUaGUgdmFsdWUgdG8gdGVzdFxuICpcbiAqIEByZXR1cm5zIHtib29sZWFufSBUcnVlIGlmIHZhbHVlIGlzIGEgUmVhY3QgTmF0aXZlIEJsb2IsIG90aGVyd2lzZSBmYWxzZVxuICovXG5jb25zdCBpc1JlYWN0TmF0aXZlQmxvYiA9ICh2YWx1ZSkgPT4ge1xuICByZXR1cm4gISEodmFsdWUgJiYgdHlwZW9mIHZhbHVlLnVyaSAhPT0gJ3VuZGVmaW5lZCcpO1xufTtcblxuLyoqXG4gKiBEZXRlcm1pbmUgaWYgZW52aXJvbm1lbnQgaXMgUmVhY3QgTmF0aXZlXG4gKiBSZWFjdE5hdGl2ZSBgRm9ybURhdGFgIGhhcyBhIG5vbi1zdGFuZGFyZCBgZ2V0UGFydHMoKWAgbWV0aG9kXG4gKlxuICogQHBhcmFtIHsqfSBmb3JtRGF0YSBUaGUgZm9ybURhdGEgdG8gdGVzdFxuICpcbiAqIEByZXR1cm5zIHtib29sZWFufSBUcnVlIGlmIGVudmlyb25tZW50IGlzIFJlYWN0IE5hdGl2ZSwgb3RoZXJ3aXNlIGZhbHNlXG4gKi9cbmNvbnN0IGlzUmVhY3ROYXRpdmUgPSAoZm9ybURhdGEpID0+IGZvcm1EYXRhICYmIHR5cGVvZiBmb3JtRGF0YS5nZXRQYXJ0cyAhPT0gJ3VuZGVmaW5lZCc7XG5cbi8qKlxuICogRGV0ZXJtaW5lIGlmIGEgdmFsdWUgaXMgYSBCbG9iXG4gKlxuICogQHBhcmFtIHsqfSB2YWwgVGhlIHZhbHVlIHRvIHRlc3RcbiAqXG4gKiBAcmV0dXJucyB7Ym9vbGVhbn0gVHJ1ZSBpZiB2YWx1ZSBpcyBhIEJsb2IsIG90aGVyd2lzZSBmYWxzZVxuICovXG5jb25zdCBpc0Jsb2IgPSBraW5kT2ZUZXN0KCdCbG9iJyk7XG5cbi8qKlxuICogRGV0ZXJtaW5lIGlmIGEgdmFsdWUgaXMgYSBGaWxlTGlzdFxuICpcbiAqIEBwYXJhbSB7Kn0gdmFsIFRoZSB2YWx1ZSB0byB0ZXN0XG4gKlxuICogQHJldHVybnMge2Jvb2xlYW59IFRydWUgaWYgdmFsdWUgaXMgYSBGaWxlTGlzdCwgb3RoZXJ3aXNlIGZhbHNlXG4gKi9cbmNvbnN0IGlzRmlsZUxpc3QgPSBraW5kT2ZUZXN0KCdGaWxlTGlzdCcpO1xuY29uc3QgaXNTZXQgPSBraW5kT2ZUZXN0KCdTZXQnKTtcblxuLyoqXG4gKiBEZXRlcm1pbmUgaWYgYSB2YWx1ZSBpcyBhIFN0cmVhbVxuICpcbiAqIEBwYXJhbSB7Kn0gdmFsIFRoZSB2YWx1ZSB0byB0ZXN0XG4gKlxuICogQHJldHVybnMge2Jvb2xlYW59IFRydWUgaWYgdmFsdWUgaXMgYSBTdHJlYW0sIG90aGVyd2lzZSBmYWxzZVxuICovXG5jb25zdCBpc1N0cmVhbSA9ICh2YWwpID0+IGlzT2JqZWN0KHZhbCkgJiYgaXNGdW5jdGlvbih2YWwucGlwZSk7XG5cbi8qKlxuICogRGV0ZXJtaW5lIGlmIGEgdmFsdWUgaXMgYSBGb3JtRGF0YVxuICpcbiAqIEBwYXJhbSB7Kn0gdGhpbmcgVGhlIHZhbHVlIHRvIHRlc3RcbiAqXG4gKiBAcmV0dXJucyB7Ym9vbGVhbn0gVHJ1ZSBpZiB2YWx1ZSBpcyBhbiBGb3JtRGF0YSwgb3RoZXJ3aXNlIGZhbHNlXG4gKi9cbmZ1bmN0aW9uIGdldEdsb2JhbCgpIHtcbiAgaWYgKHR5cGVvZiBnbG9iYWxUaGlzICE9PSAndW5kZWZpbmVkJykgcmV0dXJuIGdsb2JhbFRoaXM7XG4gIGlmICh0eXBlb2Ygc2VsZiAhPT0gJ3VuZGVmaW5lZCcpIHJldHVybiBzZWxmO1xuICBpZiAodHlwZW9mIHdpbmRvdyAhPT0gJ3VuZGVmaW5lZCcpIHJldHVybiB3aW5kb3c7XG4gIGlmICh0eXBlb2YgZ2xvYmFsICE9PSAndW5kZWZpbmVkJykgcmV0dXJuIGdsb2JhbDtcbiAgcmV0dXJuIHt9O1xufVxuXG5jb25zdCBHID0gZ2V0R2xvYmFsKCk7XG5jb25zdCBGb3JtRGF0YUN0b3IgPSB0eXBlb2YgRy5Gb3JtRGF0YSAhPT0gJ3VuZGVmaW5lZCcgPyBHLkZvcm1EYXRhIDogdW5kZWZpbmVkO1xuXG5jb25zdCBpc0Zvcm1EYXRhID0gKHRoaW5nKSA9PiB7XG4gIGlmICghdGhpbmcpIHJldHVybiBmYWxzZTtcbiAgaWYgKEZvcm1EYXRhQ3RvciAmJiB0aGluZyBpbnN0YW5jZW9mIEZvcm1EYXRhQ3RvcikgcmV0dXJuIHRydWU7XG4gIC8vIFJlamVjdCBwbGFpbiBvYmplY3RzIGluaGVyaXRpbmcgZGlyZWN0bHkgZnJvbSBPYmplY3QucHJvdG90eXBlIHNvIHByb3RvdHlwZS1wb2xsdXRpb24gZ2FkZ2V0cyBjYW4ndCBzcG9vZiBGb3JtRGF0YS5cbiAgY29uc3QgcHJvdG8gPSBnZXRQcm90b3R5cGVPZih0aGluZyk7XG4gIGlmICghcHJvdG8gfHwgcHJvdG8gPT09IE9iamVjdC5wcm90b3R5cGUpIHJldHVybiBmYWxzZTtcbiAgaWYgKCFpc0Z1bmN0aW9uKHRoaW5nLmFwcGVuZCkpIHJldHVybiBmYWxzZTtcbiAgY29uc3Qga2luZCA9IGtpbmRPZih0aGluZyk7XG4gIHJldHVybiAoXG4gICAga2luZCA9PT0gJ2Zvcm1kYXRhJyB8fFxuICAgIC8vIGRldGVjdCBmb3JtLWRhdGEgaW5zdGFuY2VcbiAgICAoa2luZCA9PT0gJ29iamVjdCcgJiYgaXNGdW5jdGlvbih0aGluZy50b1N0cmluZykgJiYgdGhpbmcudG9TdHJpbmcoKSA9PT0gJ1tvYmplY3QgRm9ybURhdGFdJylcbiAgKTtcbn07XG5cbi8qKlxuICogRGV0ZXJtaW5lIGlmIGEgdmFsdWUgaXMgYSBVUkxTZWFyY2hQYXJhbXMgb2JqZWN0XG4gKlxuICogQHBhcmFtIHsqfSB2YWwgVGhlIHZhbHVlIHRvIHRlc3RcbiAqXG4gKiBAcmV0dXJucyB7Ym9vbGVhbn0gVHJ1ZSBpZiB2YWx1ZSBpcyBhIFVSTFNlYXJjaFBhcmFtcyBvYmplY3QsIG90aGVyd2lzZSBmYWxzZVxuICovXG5jb25zdCBpc1VSTFNlYXJjaFBhcmFtcyA9IGtpbmRPZlRlc3QoJ1VSTFNlYXJjaFBhcmFtcycpO1xuXG5jb25zdCBbaXNSZWFkYWJsZVN0cmVhbSwgaXNSZXF1ZXN0LCBpc1Jlc3BvbnNlLCBpc0hlYWRlcnNdID0gW1xuICAnUmVhZGFibGVTdHJlYW0nLFxuICAnUmVxdWVzdCcsXG4gICdSZXNwb25zZScsXG4gICdIZWFkZXJzJyxcbl0ubWFwKGtpbmRPZlRlc3QpO1xuXG4vKipcbiAqIFRyaW0gZXhjZXNzIHdoaXRlc3BhY2Ugb2ZmIHRoZSBiZWdpbm5pbmcgYW5kIGVuZCBvZiBhIHN0cmluZ1xuICpcbiAqIEBwYXJhbSB7U3RyaW5nfSBzdHIgVGhlIFN0cmluZyB0byB0cmltXG4gKlxuICogQHJldHVybnMge1N0cmluZ30gVGhlIFN0cmluZyBmcmVlZCBvZiBleGNlc3Mgd2hpdGVzcGFjZVxuICovXG5jb25zdCB0cmltID0gKHN0cikgPT4ge1xuICByZXR1cm4gc3RyLnRyaW0gPyBzdHIudHJpbSgpIDogc3RyLnJlcGxhY2UoL15bXFxzXFx1RkVGRlxceEEwXSt8W1xcc1xcdUZFRkZcXHhBMF0rJC9nLCAnJyk7XG59O1xuLyoqXG4gKiBJdGVyYXRlIG92ZXIgYW4gQXJyYXkgb3IgYW4gT2JqZWN0IGludm9raW5nIGEgZnVuY3Rpb24gZm9yIGVhY2ggaXRlbS5cbiAqXG4gKiBJZiBgb2JqYCBpcyBhbiBBcnJheSBjYWxsYmFjayB3aWxsIGJlIGNhbGxlZCBwYXNzaW5nXG4gKiB0aGUgdmFsdWUsIGluZGV4LCBhbmQgY29tcGxldGUgYXJyYXkgZm9yIGVhY2ggaXRlbS5cbiAqXG4gKiBJZiAnb2JqJyBpcyBhbiBPYmplY3QgY2FsbGJhY2sgd2lsbCBiZSBjYWxsZWQgcGFzc2luZ1xuICogdGhlIHZhbHVlLCBrZXksIGFuZCBjb21wbGV0ZSBvYmplY3QgZm9yIGVhY2ggcHJvcGVydHkuXG4gKlxuICogQHBhcmFtIHtPYmplY3R8QXJyYXk8dW5rbm93bj59IG9iaiBUaGUgb2JqZWN0IHRvIGl0ZXJhdGVcbiAqIEBwYXJhbSB7RnVuY3Rpb259IGZuIFRoZSBjYWxsYmFjayB0byBpbnZva2UgZm9yIGVhY2ggaXRlbVxuICpcbiAqIEBwYXJhbSB7T2JqZWN0fSBbb3B0aW9uc11cbiAqIEBwYXJhbSB7Qm9vbGVhbn0gW29wdGlvbnMuYWxsT3duS2V5cyA9IGZhbHNlXVxuICogQHJldHVybnMge2FueX1cbiAqL1xuZnVuY3Rpb24gZm9yRWFjaChvYmosIGZuLCB7IGFsbE93bktleXMgPSBmYWxzZSB9ID0ge30pIHtcbiAgLy8gRG9uJ3QgYm90aGVyIGlmIG5vIHZhbHVlIHByb3ZpZGVkXG4gIGlmIChvYmogPT09IG51bGwgfHwgdHlwZW9mIG9iaiA9PT0gJ3VuZGVmaW5lZCcpIHtcbiAgICByZXR1cm47XG4gIH1cblxuICBsZXQgaTtcbiAgbGV0IGw7XG5cbiAgLy8gRm9yY2UgYW4gYXJyYXkgaWYgbm90IGFscmVhZHkgc29tZXRoaW5nIGl0ZXJhYmxlXG4gIGlmICh0eXBlb2Ygb2JqICE9PSAnb2JqZWN0Jykge1xuICAgIC8qZXNsaW50IG5vLXBhcmFtLXJlYXNzaWduOjAqL1xuICAgIG9iaiA9IFtvYmpdO1xuICB9XG5cbiAgaWYgKGlzQXJyYXkob2JqKSkge1xuICAgIC8vIEl0ZXJhdGUgb3ZlciBhcnJheSB2YWx1ZXNcbiAgICBmb3IgKGkgPSAwLCBsID0gb2JqLmxlbmd0aDsgaSA8IGw7IGkrKykge1xuICAgICAgZm4uY2FsbChudWxsLCBvYmpbaV0sIGksIG9iaik7XG4gICAgfVxuICB9IGVsc2Uge1xuICAgIC8vIEJ1ZmZlciBjaGVja1xuICAgIGlmIChpc0J1ZmZlcihvYmopKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgLy8gSXRlcmF0ZSBvdmVyIG9iamVjdCBrZXlzXG4gICAgY29uc3Qga2V5cyA9IGFsbE93bktleXMgPyBPYmplY3QuZ2V0T3duUHJvcGVydHlOYW1lcyhvYmopIDogT2JqZWN0LmtleXMob2JqKTtcbiAgICBjb25zdCBsZW4gPSBrZXlzLmxlbmd0aDtcbiAgICBsZXQga2V5O1xuXG4gICAgZm9yIChpID0gMDsgaSA8IGxlbjsgaSsrKSB7XG4gICAgICBrZXkgPSBrZXlzW2ldO1xuICAgICAgZm4uY2FsbChudWxsLCBvYmpba2V5XSwga2V5LCBvYmopO1xuICAgIH1cbiAgfVxufVxuXG4vKipcbiAqIEZpbmRzIGEga2V5IGluIGFuIG9iamVjdCwgY2FzZS1pbnNlbnNpdGl2ZSwgcmV0dXJuaW5nIHRoZSBhY3R1YWwga2V5IG5hbWUuXG4gKiBSZXR1cm5zIG51bGwgaWYgdGhlIG9iamVjdCBpcyBhIEJ1ZmZlciBvciBpZiBubyBtYXRjaCBpcyBmb3VuZC5cbiAqXG4gKiBAcGFyYW0ge09iamVjdH0gb2JqIC0gVGhlIG9iamVjdCB0byBzZWFyY2guXG4gKiBAcGFyYW0ge3N0cmluZ30ga2V5IC0gVGhlIGtleSB0byBmaW5kIChjYXNlLWluc2Vuc2l0aXZlKS5cbiAqIEByZXR1cm5zIHs/c3RyaW5nfSBUaGUgYWN0dWFsIGtleSBuYW1lIGlmIGZvdW5kLCBvdGhlcndpc2UgbnVsbC5cbiAqL1xuZnVuY3Rpb24gZmluZEtleShvYmosIGtleSkge1xuICBpZiAoaXNCdWZmZXIob2JqKSkge1xuICAgIHJldHVybiBudWxsO1xuICB9XG5cbiAga2V5ID0ga2V5LnRvTG93ZXJDYXNlKCk7XG4gIGNvbnN0IGtleXMgPSBPYmplY3Qua2V5cyhvYmopO1xuICBsZXQgaSA9IGtleXMubGVuZ3RoO1xuICBsZXQgX2tleTtcbiAgd2hpbGUgKGktLSA+IDApIHtcbiAgICBfa2V5ID0ga2V5c1tpXTtcbiAgICBpZiAoa2V5ID09PSBfa2V5LnRvTG93ZXJDYXNlKCkpIHtcbiAgICAgIHJldHVybiBfa2V5O1xuICAgIH1cbiAgfVxuICByZXR1cm4gbnVsbDtcbn1cblxuY29uc3QgX2dsb2JhbCA9ICgoKSA9PiB7XG4gIC8qZXNsaW50IG5vLXVuZGVmOjAqL1xuICBpZiAodHlwZW9mIGdsb2JhbFRoaXMgIT09ICd1bmRlZmluZWQnKSByZXR1cm4gZ2xvYmFsVGhpcztcbiAgcmV0dXJuIHR5cGVvZiBzZWxmICE9PSAndW5kZWZpbmVkJyA/IHNlbGYgOiB0eXBlb2Ygd2luZG93ICE9PSAndW5kZWZpbmVkJyA/IHdpbmRvdyA6IGdsb2JhbDtcbn0pKCk7XG5cbmNvbnN0IGlzQ29udGV4dERlZmluZWQgPSAoY29udGV4dCkgPT4gIWlzVW5kZWZpbmVkKGNvbnRleHQpICYmIGNvbnRleHQgIT09IF9nbG9iYWw7XG5cbi8qKlxuICogQWNjZXB0cyB2YXJhcmdzIGV4cGVjdGluZyBlYWNoIGFyZ3VtZW50IHRvIGJlIGFuIG9iamVjdCwgdGhlblxuICogaW1tdXRhYmx5IG1lcmdlcyB0aGUgcHJvcGVydGllcyBvZiBlYWNoIG9iamVjdCBhbmQgcmV0dXJucyByZXN1bHQuXG4gKlxuICogV2hlbiBtdWx0aXBsZSBvYmplY3RzIGNvbnRhaW4gdGhlIHNhbWUga2V5IHRoZSBsYXRlciBvYmplY3QgaW5cbiAqIHRoZSBhcmd1bWVudHMgbGlzdCB3aWxsIHRha2UgcHJlY2VkZW5jZS5cbiAqXG4gKiBFeGFtcGxlOlxuICpcbiAqIGBgYGpzXG4gKiBjb25zdCByZXN1bHQgPSBtZXJnZSh7Zm9vOiAxMjN9LCB7Zm9vOiA0NTZ9KTtcbiAqIGNvbnNvbGUubG9nKHJlc3VsdC5mb28pOyAvLyBvdXRwdXRzIDQ1NlxuICogYGBgXG4gKlxuICogQHBhcmFtIHtPYmplY3R9IG9iajEgT2JqZWN0IHRvIG1lcmdlXG4gKlxuICogQHJldHVybnMge09iamVjdH0gUmVzdWx0IG9mIGFsbCBtZXJnZSBwcm9wZXJ0aWVzXG4gKi9cbmZ1bmN0aW9uIG1lcmdlKC4uLm9ianMpIHtcbiAgY29uc3QgeyBjYXNlbGVzcywgc2tpcFVuZGVmaW5lZCB9ID0gKGlzQ29udGV4dERlZmluZWQodGhpcykgJiYgdGhpcykgfHwge307XG4gIGNvbnN0IHJlc3VsdCA9IHt9O1xuICAvLyBDYXNlbGVzcyBsb29rdXAgb25seSBhcHBsaWVzIHRvIHN0cmluZyBrZXlzIOKAlCBzeW1ib2wga2V5cyBhcmVcbiAgLy8gaWRlbnRpdHktbWF0Y2hlZC4gRXZlcnkgc3RyaW5nIGtleSB0aGF0IHJlYWNoZXMgYHJlc3VsdGAgcGFzc2VzIHRocm91Z2hcbiAgLy8gdGhpcyBpbmRleCBmaXJzdCwgc28gaXQgY2FuIG5ldmVyIGhvbGQgdHdvIGNhc2UgdmFyaWFudHMgb2Ygb25lIGtleSBhbmQgYVxuICAvLyBsb3dlcmNhc2UgLT4ga2V5IG1hcCBpcyBleGFjdGx5IHdoYXQgZmluZEtleShyZXN1bHQsIGtleSkgd291bGQgcmVzY2FuXG4gIC8vIE9iamVjdC5rZXlzKHJlc3VsdCkgZm9yIG9uIGVhY2ggYXNzaWdubWVudC5cbiAgY29uc3QgbG93ZXJDYXNlS2V5cyA9IGNhc2VsZXNzID8gT2JqZWN0LmNyZWF0ZShudWxsKSA6IG51bGw7XG4gIGNvbnN0IGFzc2lnblZhbHVlID0gKHZhbCwga2V5KSA9PiB7XG4gICAgLy8gU2tpcCBkYW5nZXJvdXMgcHJvcGVydHkgbmFtZXMgdG8gcHJldmVudCBwcm90b3R5cGUgcG9sbHV0aW9uXG4gICAgaWYgKGtleSA9PT0gJ19fcHJvdG9fXycgfHwga2V5ID09PSAnY29uc3RydWN0b3InIHx8IGtleSA9PT0gJ3Byb3RvdHlwZScpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICBsZXQgdGFyZ2V0S2V5ID0ga2V5O1xuICAgIGlmIChsb3dlckNhc2VLZXlzICYmIHR5cGVvZiBrZXkgPT09ICdzdHJpbmcnKSB7XG4gICAgICBjb25zdCBsb3dlcktleSA9IGtleS50b0xvd2VyQ2FzZSgpO1xuICAgICAgY29uc3Qga25vd25LZXkgPSBsb3dlckNhc2VLZXlzW2xvd2VyS2V5XTtcbiAgICAgIC8vIEEga2V5IHJlY29yZGVkIGJ1dCBhYnNlbnQgZnJvbSBgcmVzdWx0YCB3YXMgc2tpcHBlZCBieSBza2lwVW5kZWZpbmVkO1xuICAgICAgLy8gdGhlIGxhdGVyIHNwZWxsaW5nIHdpbnMgdGhlbiwgYXMgaXQgZG9lcyBmb3IgZmluZEtleS5cbiAgICAgIGlmIChrbm93bktleSAhPT0gdW5kZWZpbmVkICYmIGhhc093blByb3BlcnR5KHJlc3VsdCwga25vd25LZXkpKSB7XG4gICAgICAgIHRhcmdldEtleSA9IGtub3duS2V5O1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgbG93ZXJDYXNlS2V5c1tsb3dlcktleV0gPSBrZXk7XG4gICAgICB9XG4gICAgfVxuICAgIC8vIFJlYWQgdmlhIG93bi1wcm9wIG9ubHkg4oCUIGEgYmFyZSBgcmVzdWx0W3RhcmdldEtleV1gIHdhbGtzIHRoZSBwcm90b3R5cGVcbiAgICAvLyBjaGFpbiwgc28gYSBwb2xsdXRlZCBPYmplY3QucHJvdG90eXBlIHZhbHVlIGNvdWxkIHN1cmZhY2UgaGVyZSBhbmQgZ2V0XG4gICAgLy8gY29waWVkIGludG8gdGhlIG1lcmdlZCByZXN1bHQuXG4gICAgY29uc3QgZXhpc3RpbmcgPSBoYXNPd25Qcm9wZXJ0eShyZXN1bHQsIHRhcmdldEtleSkgPyByZXN1bHRbdGFyZ2V0S2V5XSA6IHVuZGVmaW5lZDtcbiAgICBpZiAoaXNQbGFpbk9iamVjdChleGlzdGluZykgJiYgaXNQbGFpbk9iamVjdCh2YWwpKSB7XG4gICAgICByZXN1bHRbdGFyZ2V0S2V5XSA9IG1lcmdlKGV4aXN0aW5nLCB2YWwpO1xuICAgIH0gZWxzZSBpZiAoaXNQbGFpbk9iamVjdCh2YWwpKSB7XG4gICAgICByZXN1bHRbdGFyZ2V0S2V5XSA9IG1lcmdlKHt9LCB2YWwpO1xuICAgIH0gZWxzZSBpZiAoaXNBcnJheSh2YWwpKSB7XG4gICAgICByZXN1bHRbdGFyZ2V0S2V5XSA9IHZhbC5zbGljZSgpO1xuICAgIH0gZWxzZSBpZiAoIXNraXBVbmRlZmluZWQgfHwgIWlzVW5kZWZpbmVkKHZhbCkpIHtcbiAgICAgIHJlc3VsdFt0YXJnZXRLZXldID0gdmFsO1xuICAgIH1cbiAgfTtcblxuICBmb3IgKGxldCBpID0gMCwgbCA9IG9ianMubGVuZ3RoOyBpIDwgbDsgaSsrKSB7XG4gICAgY29uc3Qgc291cmNlID0gb2Jqc1tpXTtcbiAgICBpZiAoIXNvdXJjZSB8fCBpc0J1ZmZlcihzb3VyY2UpKSB7XG4gICAgICBjb250aW51ZTtcbiAgICB9XG5cbiAgICBmb3JFYWNoKHNvdXJjZSwgYXNzaWduVmFsdWUpO1xuXG4gICAgaWYgKHR5cGVvZiBzb3VyY2UgIT09ICdvYmplY3QnIHx8IGlzQXJyYXkoc291cmNlKSB8fCAhT2JqZWN0LmdldE93blByb3BlcnR5U3ltYm9scykge1xuICAgICAgY29udGludWU7XG4gICAgfVxuXG4gICAgY29uc3Qgc3ltYm9scyA9IE9iamVjdC5nZXRPd25Qcm9wZXJ0eVN5bWJvbHMoc291cmNlKTtcbiAgICBmb3IgKGxldCBqID0gMDsgaiA8IHN5bWJvbHMubGVuZ3RoOyBqKyspIHtcbiAgICAgIGNvbnN0IHN5bWJvbCA9IHN5bWJvbHNbal07XG4gICAgICBpZiAocHJvcGVydHlJc0VudW1lcmFibGUuY2FsbChzb3VyY2UsIHN5bWJvbCkpIHtcbiAgICAgICAgYXNzaWduVmFsdWUoc291cmNlW3N5bWJvbF0sIHN5bWJvbCk7XG4gICAgICB9XG4gICAgfVxuICB9XG4gIHJldHVybiByZXN1bHQ7XG59XG5cbi8qKlxuICogRXh0ZW5kcyBvYmplY3QgYSBieSBtdXRhYmx5IGFkZGluZyB0byBpdCB0aGUgcHJvcGVydGllcyBvZiBvYmplY3QgYi5cbiAqXG4gKiBAcGFyYW0ge09iamVjdH0gYSBUaGUgb2JqZWN0IHRvIGJlIGV4dGVuZGVkXG4gKiBAcGFyYW0ge09iamVjdH0gYiBUaGUgb2JqZWN0IHRvIGNvcHkgcHJvcGVydGllcyBmcm9tXG4gKiBAcGFyYW0ge09iamVjdH0gdGhpc0FyZyBUaGUgb2JqZWN0IHRvIGJpbmQgZnVuY3Rpb24gdG9cbiAqXG4gKiBAcGFyYW0ge09iamVjdH0gW29wdGlvbnNdXG4gKiBAcGFyYW0ge0Jvb2xlYW59IFtvcHRpb25zLmFsbE93bktleXNdXG4gKiBAcmV0dXJucyB7T2JqZWN0fSBUaGUgcmVzdWx0aW5nIHZhbHVlIG9mIG9iamVjdCBhXG4gKi9cbmNvbnN0IGV4dGVuZCA9IChhLCBiLCB0aGlzQXJnLCB7IGFsbE93bktleXMgfSA9IHt9KSA9PiB7XG4gIGZvckVhY2goXG4gICAgYixcbiAgICAodmFsLCBrZXkpID0+IHtcbiAgICAgIGlmICh0aGlzQXJnICYmIGlzRnVuY3Rpb24odmFsKSkge1xuICAgICAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkoYSwga2V5LCB7XG4gICAgICAgICAgLy8gTnVsbC1wcm90byBkZXNjcmlwdG9yIHNvIGEgcG9sbHV0ZWQgT2JqZWN0LnByb3RvdHlwZS5nZXQgY2Fubm90XG4gICAgICAgICAgLy8gaGlqYWNrIGRlZmluZVByb3BlcnR5J3MgYWNjZXNzb3ItdnMtZGF0YSByZXNvbHV0aW9uLlxuICAgICAgICAgIF9fcHJvdG9fXzogbnVsbCxcbiAgICAgICAgICB2YWx1ZTogYmluZCh2YWwsIHRoaXNBcmcpLFxuICAgICAgICAgIHdyaXRhYmxlOiB0cnVlLFxuICAgICAgICAgIGVudW1lcmFibGU6IHRydWUsXG4gICAgICAgICAgY29uZmlndXJhYmxlOiB0cnVlLFxuICAgICAgICB9KTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShhLCBrZXksIHtcbiAgICAgICAgICBfX3Byb3RvX186IG51bGwsXG4gICAgICAgICAgdmFsdWU6IHZhbCxcbiAgICAgICAgICB3cml0YWJsZTogdHJ1ZSxcbiAgICAgICAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgICAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZSxcbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgfSxcbiAgICB7IGFsbE93bktleXMgfVxuICApO1xuICByZXR1cm4gYTtcbn07XG5cbi8qKlxuICogUmVtb3ZlIGJ5dGUgb3JkZXIgbWFya2VyLiBUaGlzIGNhdGNoZXMgRUYgQkIgQkYgKHRoZSBVVEYtOCBCT00pXG4gKlxuICogQHBhcmFtIHtzdHJpbmd9IGNvbnRlbnQgd2l0aCBCT01cbiAqXG4gKiBAcmV0dXJucyB7c3RyaW5nfSBjb250ZW50IHZhbHVlIHdpdGhvdXQgQk9NXG4gKi9cbmNvbnN0IHN0cmlwQk9NID0gKGNvbnRlbnQpID0+IHtcbiAgaWYgKGNvbnRlbnQuY2hhckNvZGVBdCgwKSA9PT0gMHhmZWZmKSB7XG4gICAgY29udGVudCA9IGNvbnRlbnQuc2xpY2UoMSk7XG4gIH1cbiAgcmV0dXJuIGNvbnRlbnQ7XG59O1xuXG4vKipcbiAqIEluaGVyaXQgdGhlIHByb3RvdHlwZSBtZXRob2RzIGZyb20gb25lIGNvbnN0cnVjdG9yIGludG8gYW5vdGhlclxuICogQHBhcmFtIHtmdW5jdGlvbn0gY29uc3RydWN0b3JcbiAqIEBwYXJhbSB7ZnVuY3Rpb259IHN1cGVyQ29uc3RydWN0b3JcbiAqIEBwYXJhbSB7b2JqZWN0fSBbcHJvcHNdXG4gKiBAcGFyYW0ge29iamVjdH0gW2Rlc2NyaXB0b3JzXVxuICpcbiAqIEByZXR1cm5zIHt2b2lkfVxuICovXG5jb25zdCBpbmhlcml0cyA9IChjb25zdHJ1Y3Rvciwgc3VwZXJDb25zdHJ1Y3RvciwgcHJvcHMsIGRlc2NyaXB0b3JzKSA9PiB7XG4gIGNvbnN0cnVjdG9yLnByb3RvdHlwZSA9IE9iamVjdC5jcmVhdGUoc3VwZXJDb25zdHJ1Y3Rvci5wcm90b3R5cGUsIGRlc2NyaXB0b3JzKTtcbiAgT2JqZWN0LmRlZmluZVByb3BlcnR5KGNvbnN0cnVjdG9yLnByb3RvdHlwZSwgJ2NvbnN0cnVjdG9yJywge1xuICAgIF9fcHJvdG9fXzogbnVsbCxcbiAgICB2YWx1ZTogY29uc3RydWN0b3IsXG4gICAgd3JpdGFibGU6IHRydWUsXG4gICAgZW51bWVyYWJsZTogZmFsc2UsXG4gICAgY29uZmlndXJhYmxlOiB0cnVlLFxuICB9KTtcbiAgT2JqZWN0LmRlZmluZVByb3BlcnR5KGNvbnN0cnVjdG9yLCAnc3VwZXInLCB7XG4gICAgX19wcm90b19fOiBudWxsLFxuICAgIHZhbHVlOiBzdXBlckNvbnN0cnVjdG9yLnByb3RvdHlwZSxcbiAgfSk7XG4gIHByb3BzICYmIE9iamVjdC5hc3NpZ24oY29uc3RydWN0b3IucHJvdG90eXBlLCBwcm9wcyk7XG59O1xuXG4vKipcbiAqIFJlc29sdmUgb2JqZWN0IHdpdGggZGVlcCBwcm90b3R5cGUgY2hhaW4gdG8gYSBmbGF0IG9iamVjdFxuICogQHBhcmFtIHtPYmplY3R9IHNvdXJjZU9iaiBzb3VyY2Ugb2JqZWN0XG4gKiBAcGFyYW0ge09iamVjdH0gW2Rlc3RPYmpdXG4gKiBAcGFyYW0ge0Z1bmN0aW9ufEJvb2xlYW59IFtmaWx0ZXJdXG4gKiBAcGFyYW0ge0Z1bmN0aW9ufSBbcHJvcEZpbHRlcl1cbiAqXG4gKiBAcmV0dXJucyB7T2JqZWN0fVxuICovXG5jb25zdCB0b0ZsYXRPYmplY3QgPSAoc291cmNlT2JqLCBkZXN0T2JqLCBmaWx0ZXIsIHByb3BGaWx0ZXIpID0+IHtcbiAgbGV0IHByb3BzO1xuICBsZXQgaTtcbiAgbGV0IHByb3A7XG4gIGNvbnN0IG1lcmdlZCA9IHt9O1xuXG4gIGRlc3RPYmogPSBkZXN0T2JqIHx8IHt9O1xuICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgbm8tZXEtbnVsbCxlcWVxZXFcbiAgaWYgKHNvdXJjZU9iaiA9PSBudWxsKSByZXR1cm4gZGVzdE9iajtcblxuICBkbyB7XG4gICAgcHJvcHMgPSBPYmplY3QuZ2V0T3duUHJvcGVydHlOYW1lcyhzb3VyY2VPYmopO1xuICAgIGkgPSBwcm9wcy5sZW5ndGg7XG4gICAgd2hpbGUgKGktLSA+IDApIHtcbiAgICAgIHByb3AgPSBwcm9wc1tpXTtcbiAgICAgIGlmICgoIXByb3BGaWx0ZXIgfHwgcHJvcEZpbHRlcihwcm9wLCBzb3VyY2VPYmosIGRlc3RPYmopKSAmJiAhbWVyZ2VkW3Byb3BdKSB7XG4gICAgICAgIGRlc3RPYmpbcHJvcF0gPSBzb3VyY2VPYmpbcHJvcF07XG4gICAgICAgIG1lcmdlZFtwcm9wXSA9IHRydWU7XG4gICAgICB9XG4gICAgfVxuICAgIHNvdXJjZU9iaiA9IGZpbHRlciAhPT0gZmFsc2UgJiYgZ2V0UHJvdG90eXBlT2Yoc291cmNlT2JqKTtcbiAgfSB3aGlsZSAoc291cmNlT2JqICYmICghZmlsdGVyIHx8IGZpbHRlcihzb3VyY2VPYmosIGRlc3RPYmopKSAmJiBzb3VyY2VPYmogIT09IE9iamVjdC5wcm90b3R5cGUpO1xuXG4gIHJldHVybiBkZXN0T2JqO1xufTtcblxuLyoqXG4gKiBEZXRlcm1pbmVzIHdoZXRoZXIgYSBzdHJpbmcgZW5kcyB3aXRoIHRoZSBjaGFyYWN0ZXJzIG9mIGEgc3BlY2lmaWVkIHN0cmluZ1xuICpcbiAqIEBwYXJhbSB7U3RyaW5nfSBzdHJcbiAqIEBwYXJhbSB7U3RyaW5nfSBzZWFyY2hTdHJpbmdcbiAqIEBwYXJhbSB7TnVtYmVyfSBbcG9zaXRpb249IDBdXG4gKlxuICogQHJldHVybnMge2Jvb2xlYW59XG4gKi9cbmNvbnN0IGVuZHNXaXRoID0gKHN0ciwgc2VhcmNoU3RyaW5nLCBwb3NpdGlvbikgPT4ge1xuICBzdHIgPSBTdHJpbmcoc3RyKTtcbiAgaWYgKHBvc2l0aW9uID09PSB1bmRlZmluZWQgfHwgcG9zaXRpb24gPiBzdHIubGVuZ3RoKSB7XG4gICAgcG9zaXRpb24gPSBzdHIubGVuZ3RoO1xuICB9XG4gIHBvc2l0aW9uIC09IHNlYXJjaFN0cmluZy5sZW5ndGg7XG4gIGNvbnN0IGxhc3RJbmRleCA9IHN0ci5pbmRleE9mKHNlYXJjaFN0cmluZywgcG9zaXRpb24pO1xuICByZXR1cm4gbGFzdEluZGV4ICE9PSAtMSAmJiBsYXN0SW5kZXggPT09IHBvc2l0aW9uO1xufTtcblxuLyoqXG4gKiBSZXR1cm5zIG5ldyBhcnJheSBmcm9tIGFycmF5IGxpa2Ugb2JqZWN0IG9yIG51bGwgaWYgZmFpbGVkXG4gKlxuICogQHBhcmFtIHsqfSBbdGhpbmddXG4gKlxuICogQHJldHVybnMgez9BcnJheX1cbiAqL1xuY29uc3QgdG9BcnJheSA9ICh0aGluZykgPT4ge1xuICBpZiAoIXRoaW5nKSByZXR1cm4gbnVsbDtcbiAgaWYgKGlzQXJyYXkodGhpbmcpKSByZXR1cm4gdGhpbmc7XG4gIGxldCBpID0gdGhpbmcubGVuZ3RoO1xuICBpZiAoIU51bWJlci5pc1NhZmVJbnRlZ2VyKGkpIHx8IGkgPCAwIHx8IGkgPiAweGZmZmZmZmZmKSByZXR1cm4gbnVsbDtcblxuICAvLyBCb3VuZCB0aGUgY29weSBieSBhY3R1YWwgaW5kZXhlZCBwcm9wZXJ0aWVzLCBpbmNsdWRpbmcgaGlkZGVuIGFuZCBpbmhlcml0ZWRcbiAgLy8gbWVtYmVycyBvZiBhcnJheS1saWtlIGNvbGxlY3Rpb25zLCByYXRoZXIgdGhhbiBieSB0aGUgZGVjbGFyZWQgbGVuZ3RoIGFsb25lLlxuICBjb25zdCBpbmRleGVzID0gbmV3IFNldCgpO1xuICBjb25zdCBzZWVuID0gbmV3IFNldCgpO1xuICBsZXQgc291cmNlID0gdGhpbmc7XG5cbiAgd2hpbGUgKHNvdXJjZSAhPSBudWxsICYmIGluZGV4ZXMuc2l6ZSA8IGkpIHtcbiAgICBpZiAoc2Vlbi5oYXMoc291cmNlKSkgcmV0dXJuIG51bGw7XG4gICAgc2Vlbi5hZGQoc291cmNlKTtcblxuICAgIGNvbnN0IHByb3RvdHlwZSA9IGdldFByb3RvdHlwZU9mKHNvdXJjZSk7XG4gICAgaWYgKGlzUHJvdG90eXBlQm91bmRhcnkoc291cmNlLCBwcm90b3R5cGUsIHNvdXJjZSA9PT0gdGhpbmcpKSBicmVhaztcblxuICAgIE9iamVjdC5nZXRPd25Qcm9wZXJ0eU5hbWVzKHNvdXJjZSkuZm9yRWFjaCgoa2V5KSA9PiB7XG4gICAgICBjb25zdCBpbmRleCA9ICtrZXk7XG4gICAgICBpZiAoXG4gICAgICAgIE51bWJlci5pc0ludGVnZXIoaW5kZXgpICYmXG4gICAgICAgIGluZGV4ID49IDAgJiZcbiAgICAgICAgaW5kZXggPCBpICYmXG4gICAgICAgIFN0cmluZyhpbmRleCkgPT09IGtleSAmJlxuICAgICAgICBoYXNPd25Qcm9wZXJ0eShzb3VyY2UsIGtleSlcbiAgICAgICkge1xuICAgICAgICBpbmRleGVzLmFkZChpbmRleCk7XG4gICAgICB9XG4gICAgfSk7XG4gICAgc291cmNlID0gcHJvdG90eXBlO1xuICB9XG5cbiAgaWYgKGluZGV4ZXMuc2l6ZSAhPT0gaSkgcmV0dXJuIG51bGw7XG4gIGNvbnN0IGFyciA9IG5ldyBBcnJheShpKTtcbiAgd2hpbGUgKGktLSA+IDApIHtcbiAgICBhcnJbaV0gPSB0aGluZ1tpXTtcbiAgfVxuICByZXR1cm4gYXJyO1xufTtcblxuLyoqXG4gKiBDaGVja2luZyBpZiB0aGUgVWludDhBcnJheSBleGlzdHMgYW5kIGlmIGl0IGRvZXMsIGl0IHJldHVybnMgYSBmdW5jdGlvbiB0aGF0IGNoZWNrcyBpZiB0aGVcbiAqIHRoaW5nIHBhc3NlZCBpbiBpcyBhbiBpbnN0YW5jZSBvZiBVaW50OEFycmF5XG4gKlxuICogQHBhcmFtIHtUeXBlZEFycmF5fVxuICpcbiAqIEByZXR1cm5zIHtBcnJheX1cbiAqL1xuLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIGZ1bmMtbmFtZXNcbmNvbnN0IGlzVHlwZWRBcnJheSA9ICgoVHlwZWRBcnJheSkgPT4ge1xuICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgZnVuYy1uYW1lc1xuICByZXR1cm4gKHRoaW5nKSA9PiB7XG4gICAgcmV0dXJuIFR5cGVkQXJyYXkgJiYgdGhpbmcgaW5zdGFuY2VvZiBUeXBlZEFycmF5O1xuICB9O1xufSkodHlwZW9mIFVpbnQ4QXJyYXkgIT09ICd1bmRlZmluZWQnICYmIGdldFByb3RvdHlwZU9mKFVpbnQ4QXJyYXkpKTtcblxuLyoqXG4gKiBGb3IgZWFjaCBlbnRyeSBpbiB0aGUgb2JqZWN0LCBjYWxsIHRoZSBmdW5jdGlvbiB3aXRoIHRoZSBrZXkgYW5kIHZhbHVlLlxuICpcbiAqIEBwYXJhbSB7T2JqZWN0PGFueSwgYW55Pn0gb2JqIC0gVGhlIG9iamVjdCB0byBpdGVyYXRlIG92ZXIuXG4gKiBAcGFyYW0ge0Z1bmN0aW9ufSBmbiAtIFRoZSBmdW5jdGlvbiB0byBjYWxsIGZvciBlYWNoIGVudHJ5LlxuICpcbiAqIEByZXR1cm5zIHt2b2lkfVxuICovXG5jb25zdCBmb3JFYWNoRW50cnkgPSAob2JqLCBmbikgPT4ge1xuICBjb25zdCBnZW5lcmF0b3IgPSBvYmogJiYgb2JqW2l0ZXJhdG9yXTtcblxuICBjb25zdCBfaXRlcmF0b3IgPSBnZW5lcmF0b3IuY2FsbChvYmopO1xuXG4gIGxldCByZXN1bHQ7XG5cbiAgd2hpbGUgKChyZXN1bHQgPSBfaXRlcmF0b3IubmV4dCgpKSAmJiAhcmVzdWx0LmRvbmUpIHtcbiAgICBjb25zdCBwYWlyID0gcmVzdWx0LnZhbHVlO1xuICAgIGZuLmNhbGwob2JqLCBwYWlyWzBdLCBwYWlyWzFdKTtcbiAgfVxufTtcblxuLyoqXG4gKiBJdCB0YWtlcyBhIHJlZ3VsYXIgZXhwcmVzc2lvbiBhbmQgYSBzdHJpbmcsIGFuZCByZXR1cm5zIGFuIGFycmF5IG9mIGFsbCB0aGUgbWF0Y2hlc1xuICpcbiAqIEBwYXJhbSB7c3RyaW5nfSByZWdFeHAgLSBUaGUgcmVndWxhciBleHByZXNzaW9uIHRvIG1hdGNoIGFnYWluc3QuXG4gKiBAcGFyYW0ge3N0cmluZ30gc3RyIC0gVGhlIHN0cmluZyB0byBzZWFyY2guXG4gKlxuICogQHJldHVybnMge0FycmF5PGJvb2xlYW4+fVxuICovXG5jb25zdCBtYXRjaEFsbCA9IChyZWdFeHAsIHN0cikgPT4ge1xuICBsZXQgbWF0Y2hlcztcbiAgY29uc3QgYXJyID0gW107XG5cbiAgd2hpbGUgKChtYXRjaGVzID0gcmVnRXhwLmV4ZWMoc3RyKSkgIT09IG51bGwpIHtcbiAgICBhcnIucHVzaChtYXRjaGVzKTtcbiAgfVxuXG4gIHJldHVybiBhcnI7XG59O1xuXG4vKiBDaGVja2luZyBpZiB0aGUga2luZE9mVGVzdCBmdW5jdGlvbiByZXR1cm5zIHRydWUgd2hlbiBwYXNzZWQgYW4gSFRNTEZvcm1FbGVtZW50LiAqL1xuY29uc3QgaXNIVE1MRm9ybSA9IGtpbmRPZlRlc3QoJ0hUTUxGb3JtRWxlbWVudCcpO1xuXG5jb25zdCB0b0NhbWVsQ2FzZSA9IChzdHIpID0+IHtcbiAgcmV0dXJuIHN0ci50b0xvd2VyQ2FzZSgpLnJlcGxhY2UoL1stX1xcc10oW2EtelxcZF0pKFxcdyopL2csIGZ1bmN0aW9uIHJlcGxhY2VyKG0sIHAxLCBwMikge1xuICAgIHJldHVybiBwMS50b1VwcGVyQ2FzZSgpICsgcDI7XG4gIH0pO1xufTtcblxuY29uc3QgeyBwcm9wZXJ0eUlzRW51bWVyYWJsZSB9ID0gT2JqZWN0LnByb3RvdHlwZTtcblxuLyoqXG4gKiBEZXRlcm1pbmUgaWYgYSB2YWx1ZSBpcyBhIFJlZ0V4cCBvYmplY3RcbiAqXG4gKiBAcGFyYW0geyp9IHZhbCBUaGUgdmFsdWUgdG8gdGVzdFxuICpcbiAqIEByZXR1cm5zIHtib29sZWFufSBUcnVlIGlmIHZhbHVlIGlzIGEgUmVnRXhwIG9iamVjdCwgb3RoZXJ3aXNlIGZhbHNlXG4gKi9cbmNvbnN0IGlzUmVnRXhwID0ga2luZE9mVGVzdCgnUmVnRXhwJyk7XG5cbmNvbnN0IHJlZHVjZURlc2NyaXB0b3JzID0gKG9iaiwgcmVkdWNlcikgPT4ge1xuICBjb25zdCBkZXNjcmlwdG9ycyA9IE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3JzKG9iaik7XG4gIGNvbnN0IHJlZHVjZWREZXNjcmlwdG9ycyA9IHt9O1xuXG4gIGZvckVhY2goZGVzY3JpcHRvcnMsIChkZXNjcmlwdG9yLCBuYW1lKSA9PiB7XG4gICAgbGV0IHJldDtcbiAgICBpZiAoKHJldCA9IHJlZHVjZXIoZGVzY3JpcHRvciwgbmFtZSwgb2JqKSkgIT09IGZhbHNlKSB7XG4gICAgICByZWR1Y2VkRGVzY3JpcHRvcnNbbmFtZV0gPSByZXQgfHwgZGVzY3JpcHRvcjtcbiAgICB9XG4gIH0pO1xuXG4gIE9iamVjdC5kZWZpbmVQcm9wZXJ0aWVzKG9iaiwgcmVkdWNlZERlc2NyaXB0b3JzKTtcbn07XG5cbi8qKlxuICogTWFrZXMgYWxsIG1ldGhvZHMgcmVhZC1vbmx5XG4gKiBAcGFyYW0ge09iamVjdH0gb2JqXG4gKi9cblxuY29uc3QgZnJlZXplTWV0aG9kcyA9IChvYmopID0+IHtcbiAgcmVkdWNlRGVzY3JpcHRvcnMob2JqLCAoZGVzY3JpcHRvciwgbmFtZSkgPT4ge1xuICAgIC8vIHNraXAgcmVzdHJpY3RlZCBwcm9wcyBpbiBzdHJpY3QgbW9kZVxuICAgIGlmIChpc0Z1bmN0aW9uKG9iaikgJiYgWydhcmd1bWVudHMnLCAnY2FsbGVyJywgJ2NhbGxlZSddLmluY2x1ZGVzKG5hbWUpKSB7XG4gICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuXG4gICAgY29uc3QgdmFsdWUgPSBvYmpbbmFtZV07XG5cbiAgICBpZiAoIWlzRnVuY3Rpb24odmFsdWUpKSByZXR1cm47XG5cbiAgICBkZXNjcmlwdG9yLmVudW1lcmFibGUgPSBmYWxzZTtcblxuICAgIGlmICgnd3JpdGFibGUnIGluIGRlc2NyaXB0b3IpIHtcbiAgICAgIGRlc2NyaXB0b3Iud3JpdGFibGUgPSBmYWxzZTtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICBpZiAoIWRlc2NyaXB0b3Iuc2V0KSB7XG4gICAgICBkZXNjcmlwdG9yLnNldCA9ICgpID0+IHtcbiAgICAgICAgdGhyb3cgRXJyb3IoXCJDYW4gbm90IHJld3JpdGUgcmVhZC1vbmx5IG1ldGhvZCAnXCIgKyBuYW1lICsgXCInXCIpO1xuICAgICAgfTtcbiAgICB9XG4gIH0pO1xufTtcblxuLyoqXG4gKiBDb252ZXJ0cyBhbiBhcnJheSBvciBhIGRlbGltaXRlZCBzdHJpbmcgaW50byBhbiBvYmplY3Qgc2V0IHdpdGggdmFsdWVzIGFzIGtleXMgYW5kIHRydWUgYXMgdmFsdWVzLlxuICogVXNlZnVsIGZvciBmYXN0IG1lbWJlcnNoaXAgY2hlY2tzLlxuICpcbiAqIEBwYXJhbSB7QXJyYXl8c3RyaW5nfSBhcnJheU9yU3RyaW5nIC0gVGhlIGFycmF5IG9yIHN0cmluZyB0byBjb252ZXJ0LlxuICogQHBhcmFtIHtzdHJpbmd9IGRlbGltaXRlciAtIFRoZSBkZWxpbWl0ZXIgdG8gdXNlIGlmIGlucHV0IGlzIGEgc3RyaW5nLlxuICogQHJldHVybnMge09iamVjdH0gQW4gb2JqZWN0IHdpdGgga2V5cyBmcm9tIHRoZSBhcnJheSBvciBzdHJpbmcsIHZhbHVlcyBzZXQgdG8gdHJ1ZS5cbiAqL1xuY29uc3QgdG9PYmplY3RTZXQgPSAoYXJyYXlPclN0cmluZywgZGVsaW1pdGVyKSA9PiB7XG4gIGNvbnN0IG9iaiA9IHt9O1xuXG4gIGNvbnN0IGRlZmluZSA9IChhcnIpID0+IHtcbiAgICBhcnIuZm9yRWFjaCgodmFsdWUpID0+IHtcbiAgICAgIG9ialt2YWx1ZV0gPSB0cnVlO1xuICAgIH0pO1xuICB9O1xuXG4gIGlzQXJyYXkoYXJyYXlPclN0cmluZykgPyBkZWZpbmUoYXJyYXlPclN0cmluZykgOiBkZWZpbmUoU3RyaW5nKGFycmF5T3JTdHJpbmcpLnNwbGl0KGRlbGltaXRlcikpO1xuXG4gIHJldHVybiBvYmo7XG59O1xuXG5jb25zdCBub29wID0gKCkgPT4ge307XG5cbmNvbnN0IHRvRmluaXRlTnVtYmVyID0gKHZhbHVlLCBkZWZhdWx0VmFsdWUpID0+IHtcbiAgcmV0dXJuIHZhbHVlICE9IG51bGwgJiYgTnVtYmVyLmlzRmluaXRlKCh2YWx1ZSA9ICt2YWx1ZSkpID8gdmFsdWUgOiBkZWZhdWx0VmFsdWU7XG59O1xuXG4vKipcbiAqIElmIHRoZSB0aGluZyBpcyBhIEZvcm1EYXRhIG9iamVjdCwgcmV0dXJuIHRydWUsIG90aGVyd2lzZSByZXR1cm4gZmFsc2UuXG4gKlxuICogQHBhcmFtIHt1bmtub3dufSB0aGluZyAtIFRoZSB0aGluZyB0byBjaGVjay5cbiAqXG4gKiBAcmV0dXJucyB7Ym9vbGVhbn1cbiAqL1xuZnVuY3Rpb24gaXNTcGVjQ29tcGxpYW50Rm9ybSh0aGluZykge1xuICByZXR1cm4gISEoXG4gICAgdGhpbmcgJiZcbiAgICBpc0Z1bmN0aW9uKHRoaW5nLmFwcGVuZCkgJiZcbiAgICB0aGluZ1t0b1N0cmluZ1RhZ10gPT09ICdGb3JtRGF0YScgJiZcbiAgICB0aGluZ1tpdGVyYXRvcl1cbiAgKTtcbn1cblxuLyoqXG4gKiBSZWN1cnNpdmVseSBjb252ZXJ0cyBhbiBvYmplY3QgdG8gYSBKU09OLWNvbXBhdGlibGUgb2JqZWN0LCBoYW5kbGluZyBjaXJjdWxhciByZWZlcmVuY2VzIGFuZCBCdWZmZXJzLlxuICpcbiAqIEBwYXJhbSB7T2JqZWN0fSBvYmogLSBUaGUgb2JqZWN0IHRvIGNvbnZlcnQuXG4gKiBAcmV0dXJucyB7T2JqZWN0fSBUaGUgSlNPTi1jb21wYXRpYmxlIG9iamVjdC5cbiAqL1xuY29uc3QgdG9KU09OT2JqZWN0ID0gKG9iaikgPT4ge1xuICBjb25zdCB2aXNpdGVkID0gbmV3IFdlYWtTZXQoKTtcblxuICBjb25zdCB2aXNpdCA9IChzb3VyY2UpID0+IHtcbiAgICBpZiAoaXNPYmplY3Qoc291cmNlKSkge1xuICAgICAgaWYgKHZpc2l0ZWQuaGFzKHNvdXJjZSkpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuXG4gICAgICAvL0J1ZmZlciBjaGVja1xuICAgICAgaWYgKGlzQnVmZmVyKHNvdXJjZSkpIHtcbiAgICAgICAgcmV0dXJuIHNvdXJjZTtcbiAgICAgIH1cblxuICAgICAgaWYgKCEoJ3RvSlNPTicgaW4gc291cmNlKSkge1xuICAgICAgICAvLyBhZGQtb24gZGVzY2VudCAvIGRlbGV0ZS1vbi1hc2NlbnQ6IHByZXNlcnZlcyBwYXRoIHNlbWFudGljcywgc28gREFHIG5vZGVzIHNlcmlhbGlzZSBhdCBldmVyeSBvY2N1cnJlbmNlIChzZWUgIzcyMzApLlxuICAgICAgICB2aXNpdGVkLmFkZChzb3VyY2UpO1xuXG4gICAgICAgIGxldCB0YXJnZXQ7XG5cbiAgICAgICAgaWYgKGlzU2V0KHNvdXJjZSkpIHtcbiAgICAgICAgICB0YXJnZXQgPSBbXTtcbiAgICAgICAgICBmb3IgKGNvbnN0IHZhbHVlIG9mIHNvdXJjZSkge1xuICAgICAgICAgICAgY29uc3QgcmVkdWNlZFZhbHVlID0gdmlzaXQodmFsdWUpO1xuICAgICAgICAgICAgIWlzVW5kZWZpbmVkKHJlZHVjZWRWYWx1ZSkgJiYgdGFyZ2V0LnB1c2gocmVkdWNlZFZhbHVlKTtcbiAgICAgICAgICB9XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgdGFyZ2V0ID0gaXNBcnJheShzb3VyY2UpID8gW10gOiB7fTtcblxuICAgICAgICAgIGZvckVhY2goc291cmNlLCAodmFsdWUsIGtleSkgPT4ge1xuICAgICAgICAgICAgY29uc3QgcmVkdWNlZFZhbHVlID0gdmlzaXQodmFsdWUpO1xuICAgICAgICAgICAgIWlzVW5kZWZpbmVkKHJlZHVjZWRWYWx1ZSkgJiYgKHRhcmdldFtrZXldID0gcmVkdWNlZFZhbHVlKTtcbiAgICAgICAgICB9KTtcbiAgICAgICAgfVxuXG4gICAgICAgIHZpc2l0ZWQuZGVsZXRlKHNvdXJjZSk7XG5cbiAgICAgICAgcmV0dXJuIHRhcmdldDtcbiAgICAgIH1cbiAgICB9XG5cbiAgICByZXR1cm4gc291cmNlO1xuICB9O1xuXG4gIHJldHVybiB2aXNpdChvYmopO1xufTtcblxuLyoqXG4gKiBEZXRlcm1pbmVzIGlmIGEgdmFsdWUgaXMgYW4gYXN5bmMgZnVuY3Rpb24uXG4gKlxuICogQHBhcmFtIHsqfSB0aGluZyAtIFRoZSB2YWx1ZSB0byB0ZXN0LlxuICogQHJldHVybnMge2Jvb2xlYW59IFRydWUgaWYgdmFsdWUgaXMgYW4gYXN5bmMgZnVuY3Rpb24sIG90aGVyd2lzZSBmYWxzZS5cbiAqL1xuY29uc3QgaXNBc3luY0ZuID0ga2luZE9mVGVzdCgnQXN5bmNGdW5jdGlvbicpO1xuXG4vKipcbiAqIERldGVybWluZXMgaWYgYSB2YWx1ZSBpcyB0aGVuYWJsZSAoaGFzIHRoZW4gYW5kIGNhdGNoIG1ldGhvZHMpLlxuICpcbiAqIEBwYXJhbSB7Kn0gdGhpbmcgLSBUaGUgdmFsdWUgdG8gdGVzdC5cbiAqIEByZXR1cm5zIHtib29sZWFufSBUcnVlIGlmIHZhbHVlIGlzIHRoZW5hYmxlLCBvdGhlcndpc2UgZmFsc2UuXG4gKi9cbmNvbnN0IGlzVGhlbmFibGUgPSAodGhpbmcpID0+XG4gIHRoaW5nICYmXG4gIChpc09iamVjdCh0aGluZykgfHwgaXNGdW5jdGlvbih0aGluZykpICYmXG4gIGlzRnVuY3Rpb24odGhpbmcudGhlbikgJiZcbiAgaXNGdW5jdGlvbih0aGluZy5jYXRjaCk7XG5cbi8vIG9yaWdpbmFsIGNvZGVcbi8vIGh0dHBzOi8vZ2l0aHViLmNvbS9EaWdpdGFsQnJhaW5KUy9BeGlvc1Byb21pc2UvYmxvYi8xNmRlYWIxMzcxMGVjMDk3Nzk5MjIxMzFmM2ZhNTk1NDMyMGY4M2FiL2xpYi91dGlscy5qcyNMMTEtTDM0XG5cbi8qKlxuICogUHJvdmlkZXMgYSBjcm9zcy1wbGF0Zm9ybSBzZXRJbW1lZGlhdGUgaW1wbGVtZW50YXRpb24uXG4gKiBVc2VzIG5hdGl2ZSBzZXRJbW1lZGlhdGUgaWYgYXZhaWxhYmxlLCBvdGhlcndpc2UgZmFsbHMgYmFjayB0byBwb3N0TWVzc2FnZSBvciBzZXRUaW1lb3V0LlxuICpcbiAqIEBwYXJhbSB7Ym9vbGVhbn0gc2V0SW1tZWRpYXRlU3VwcG9ydGVkIC0gV2hldGhlciBzZXRJbW1lZGlhdGUgaXMgc3VwcG9ydGVkLlxuICogQHBhcmFtIHtib29sZWFufSBwb3N0TWVzc2FnZVN1cHBvcnRlZCAtIFdoZXRoZXIgcG9zdE1lc3NhZ2UgaXMgc3VwcG9ydGVkLlxuICogQHJldHVybnMge0Z1bmN0aW9ufSBBIGZ1bmN0aW9uIHRvIHNjaGVkdWxlIGEgY2FsbGJhY2sgYXN5bmNocm9ub3VzbHkuXG4gKi9cbmNvbnN0IF9zZXRJbW1lZGlhdGUgPSAoKHNldEltbWVkaWF0ZVN1cHBvcnRlZCwgcG9zdE1lc3NhZ2VTdXBwb3J0ZWQpID0+IHtcbiAgaWYgKHNldEltbWVkaWF0ZVN1cHBvcnRlZCkge1xuICAgIHJldHVybiBzZXRJbW1lZGlhdGU7XG4gIH1cblxuICByZXR1cm4gcG9zdE1lc3NhZ2VTdXBwb3J0ZWRcbiAgICA/ICgodG9rZW4sIGNhbGxiYWNrcykgPT4ge1xuICAgICAgICBfZ2xvYmFsLmFkZEV2ZW50TGlzdGVuZXIoXG4gICAgICAgICAgJ21lc3NhZ2UnLFxuICAgICAgICAgICh7IHNvdXJjZSwgZGF0YSB9KSA9PiB7XG4gICAgICAgICAgICBpZiAoc291cmNlID09PSBfZ2xvYmFsICYmIGRhdGEgPT09IHRva2VuKSB7XG4gICAgICAgICAgICAgIGNhbGxiYWNrcy5sZW5ndGggJiYgY2FsbGJhY2tzLnNoaWZ0KCkoKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9LFxuICAgICAgICAgIGZhbHNlXG4gICAgICAgICk7XG5cbiAgICAgICAgcmV0dXJuIChjYikgPT4ge1xuICAgICAgICAgIGNhbGxiYWNrcy5wdXNoKGNiKTtcbiAgICAgICAgICBfZ2xvYmFsLnBvc3RNZXNzYWdlKHRva2VuLCAnKicpO1xuICAgICAgICB9O1xuICAgICAgfSkoYGF4aW9zQCR7TWF0aC5yYW5kb20oKX1gLCBbXSlcbiAgICA6IChjYikgPT4gc2V0VGltZW91dChjYik7XG59KSh0eXBlb2Ygc2V0SW1tZWRpYXRlID09PSAnZnVuY3Rpb24nLCBpc0Z1bmN0aW9uKF9nbG9iYWwucG9zdE1lc3NhZ2UpKTtcblxuLyoqXG4gKiBTY2hlZHVsZXMgYSBtaWNyb3Rhc2sgb3IgYXN5bmNocm9ub3VzIGNhbGxiYWNrIGFzIHNvb24gYXMgcG9zc2libGUuXG4gKiBVc2VzIHF1ZXVlTWljcm90YXNrIGlmIGF2YWlsYWJsZSwgb3RoZXJ3aXNlIGZhbGxzIGJhY2sgdG8gcHJvY2Vzcy5uZXh0VGljayBvciBfc2V0SW1tZWRpYXRlLlxuICpcbiAqIEB0eXBlIHtGdW5jdGlvbn1cbiAqL1xuY29uc3QgYXNhcCA9XG4gIHR5cGVvZiBxdWV1ZU1pY3JvdGFzayAhPT0gJ3VuZGVmaW5lZCdcbiAgICA/IHF1ZXVlTWljcm90YXNrLmJpbmQoX2dsb2JhbClcbiAgICA6ICh0eXBlb2YgcHJvY2VzcyAhPT0gJ3VuZGVmaW5lZCcgJiYgcHJvY2Vzcy5uZXh0VGljaykgfHwgX3NldEltbWVkaWF0ZTtcblxuLy8gKioqKioqKioqKioqKioqKioqKioqXG5cbmNvbnN0IGlzSXRlcmFibGUgPSAodGhpbmcpID0+IHRoaW5nICE9IG51bGwgJiYgaXNGdW5jdGlvbih0aGluZ1tpdGVyYXRvcl0pO1xuXG4vKipcbiAqIERldGVybWluZSBpZiBhIHZhbHVlIGlzIGl0ZXJhYmxlIHZpYSBhbiBpdGVyYXRvciB0aGF0IGlzIE5PVCBzb3VyY2VkIHNvbGVseVxuICogZnJvbSBhIHBvbGx1dGVkIE9iamVjdC5wcm90b3R5cGUuIFVzZSB0aGlzIGluc3RlYWQgb2YgYGlzSXRlcmFibGVgIHdoZW5ldmVyXG4gKiB0aGUgaXRlcmFibGUgY29tZXMgZnJvbSB1bnRydXN0ZWQgaW5wdXQgKGUuZy4gdXNlci1zdXBwbGllZCBoZWFkZXIgc291cmNlcyksXG4gKiBzbyBgT2JqZWN0LnByb3RvdHlwZVtTeW1ib2wuaXRlcmF0b3JdID0gLi4uYCBjYW5ub3QgdHVybiBhbiBvcmRpbmFyeSBvYmplY3RcbiAqIGludG8gYW4gYXR0YWNrZXItY29udHJvbGxlZCBlbnRyaWVzIGl0ZXJhdG9yLlxuICpcbiAqIEBwYXJhbSB7Kn0gdGhpbmcgVGhlIHZhbHVlIHRvIHRlc3RcbiAqXG4gKiBAcmV0dXJucyB7Ym9vbGVhbn0gVHJ1ZSBpZiB2YWx1ZSBoYXMgYSBub24tcG9sbHV0ZWQgaXRlcmF0b3JcbiAqL1xuY29uc3QgaXNTYWZlSXRlcmFibGUgPSAodGhpbmcpID0+XG4gIHRoaW5nICE9IG51bGwgJiYgaGFzT3duSW5Qcm90b3R5cGVDaGFpbih0aGluZywgaXRlcmF0b3IpICYmIGlzSXRlcmFibGUodGhpbmcpO1xuXG5leHBvcnQgZGVmYXVsdCB7XG4gIGlzQXJyYXksXG4gIGlzQXJyYXlCdWZmZXIsXG4gIGlzQnVmZmVyLFxuICBpc0Zvcm1EYXRhLFxuICBpc0FycmF5QnVmZmVyVmlldyxcbiAgaXNTdHJpbmcsXG4gIGlzTnVtYmVyLFxuICBpc0Jvb2xlYW4sXG4gIGlzT2JqZWN0LFxuICBpc1BsYWluT2JqZWN0LFxuICBpc0VtcHR5T2JqZWN0LFxuICBpc1JlYWRhYmxlU3RyZWFtLFxuICBpc1JlcXVlc3QsXG4gIGlzUmVzcG9uc2UsXG4gIGlzSGVhZGVycyxcbiAgaXNVbmRlZmluZWQsXG4gIGlzRGF0ZSxcbiAgaXNGaWxlLFxuICBpc1JlYWN0TmF0aXZlQmxvYixcbiAgaXNSZWFjdE5hdGl2ZSxcbiAgaXNCbG9iLFxuICBpc1JlZ0V4cCxcbiAgaXNGdW5jdGlvbixcbiAgaXNTdHJlYW0sXG4gIGlzVVJMU2VhcmNoUGFyYW1zLFxuICBpc1R5cGVkQXJyYXksXG4gIGlzRmlsZUxpc3QsXG4gIGZvckVhY2gsXG4gIG1lcmdlLFxuICBleHRlbmQsXG4gIHRyaW0sXG4gIHN0cmlwQk9NLFxuICBpbmhlcml0cyxcbiAgdG9GbGF0T2JqZWN0LFxuICBraW5kT2YsXG4gIGtpbmRPZlRlc3QsXG4gIGVuZHNXaXRoLFxuICB0b0FycmF5LFxuICBmb3JFYWNoRW50cnksXG4gIG1hdGNoQWxsLFxuICBpc0hUTUxGb3JtLFxuICBoYXNPd25Qcm9wZXJ0eSxcbiAgaGFzT3duUHJvcDogaGFzT3duUHJvcGVydHksIC8vIGFuIGFsaWFzIHRvIGF2b2lkIEVTTGludCBuby1wcm90b3R5cGUtYnVpbHRpbnMgZGV0ZWN0aW9uXG4gIGhhc093bkluUHJvdG90eXBlQ2hhaW4sXG4gIGdldFNhZmVQcm9wLFxuICB0b1NhZmVGbGF0T2JqZWN0LFxuICByZWR1Y2VEZXNjcmlwdG9ycyxcbiAgZnJlZXplTWV0aG9kcyxcbiAgdG9PYmplY3RTZXQsXG4gIHRvQ2FtZWxDYXNlLFxuICBub29wLFxuICB0b0Zpbml0ZU51bWJlcixcbiAgZmluZEtleSxcbiAgZ2xvYmFsOiBfZ2xvYmFsLFxuICBpc0NvbnRleHREZWZpbmVkLFxuICBpc1NwZWNDb21wbGlhbnRGb3JtLFxuICB0b0pTT05PYmplY3QsXG4gIGlzQXN5bmNGbixcbiAgaXNUaGVuYWJsZSxcbiAgc2V0SW1tZWRpYXRlOiBfc2V0SW1tZWRpYXRlLFxuICBhc2FwLFxuICBpc0l0ZXJhYmxlLFxuICBpc1NhZmVJdGVyYWJsZSxcbn07XG4iLCIndXNlIHN0cmljdCc7XG5cbmltcG9ydCB1dGlscyBmcm9tICcuLi91dGlscy5qcyc7XG5cbi8vIFJhd0F4aW9zSGVhZGVycyB3aG9zZSBkdXBsaWNhdGVzIGFyZSBpZ25vcmVkIGJ5IG5vZGVcbi8vIGMuZi4gaHR0cHM6Ly9ub2RlanMub3JnL2FwaS9odHRwLmh0bWwjaHR0cF9tZXNzYWdlX2hlYWRlcnNcbmNvbnN0IGlnbm9yZUR1cGxpY2F0ZU9mID0gdXRpbHMudG9PYmplY3RTZXQoW1xuICAnYWdlJyxcbiAgJ2F1dGhvcml6YXRpb24nLFxuICAnY29udGVudC1sZW5ndGgnLFxuICAnY29udGVudC10eXBlJyxcbiAgJ2V0YWcnLFxuICAnZXhwaXJlcycsXG4gICdmcm9tJyxcbiAgJ2hvc3QnLFxuICAnaWYtbW9kaWZpZWQtc2luY2UnLFxuICAnaWYtdW5tb2RpZmllZC1zaW5jZScsXG4gICdsYXN0LW1vZGlmaWVkJyxcbiAgJ2xvY2F0aW9uJyxcbiAgJ21heC1mb3J3YXJkcycsXG4gICdwcm94eS1hdXRob3JpemF0aW9uJyxcbiAgJ3JlZmVyZXInLFxuICAncmV0cnktYWZ0ZXInLFxuICAndXNlci1hZ2VudCcsXG5dKTtcblxuLyoqXG4gKiBQYXJzZSBoZWFkZXJzIGludG8gYW4gb2JqZWN0XG4gKlxuICogYGBgXG4gKiBEYXRlOiBXZWQsIDI3IEF1ZyAyMDE0IDA4OjU4OjQ5IEdNVFxuICogQ29udGVudC1UeXBlOiBhcHBsaWNhdGlvbi9qc29uXG4gKiBDb25uZWN0aW9uOiBrZWVwLWFsaXZlXG4gKiBUcmFuc2Zlci1FbmNvZGluZzogY2h1bmtlZFxuICogYGBgXG4gKlxuICogQHBhcmFtIHtTdHJpbmd9IHJhd0hlYWRlcnMgSGVhZGVycyBuZWVkaW5nIHRvIGJlIHBhcnNlZFxuICpcbiAqIEByZXR1cm5zIHtPYmplY3R9IEhlYWRlcnMgcGFyc2VkIGludG8gYW4gb2JqZWN0XG4gKi9cbmV4cG9ydCBkZWZhdWx0IChyYXdIZWFkZXJzKSA9PiB7XG4gIC8vIEhlYWRlciBuYW1lcyBhcmUgZGF0YSwgaW5jbHVkaW5nIF9fcHJvdG9fXzsgYXZvaWQgaW5oZXJpdGVkIHNldHRlcnMuXG4gIGNvbnN0IHBhcnNlZCA9IE9iamVjdC5jcmVhdGUobnVsbCk7XG4gIGxldCBrZXk7XG4gIGxldCB2YWw7XG4gIGxldCBpO1xuXG4gIHJhd0hlYWRlcnMgJiZcbiAgICByYXdIZWFkZXJzLnNwbGl0KCdcXG4nKS5mb3JFYWNoKGZ1bmN0aW9uIHBhcnNlcihsaW5lKSB7XG4gICAgICBpID0gbGluZS5pbmRleE9mKCc6Jyk7XG4gICAgICBrZXkgPSBsaW5lLnN1YnN0cmluZygwLCBpKS50cmltKCkudG9Mb3dlckNhc2UoKTtcbiAgICAgIHZhbCA9IGxpbmUuc3Vic3RyaW5nKGkgKyAxKS50cmltKCk7XG5cbiAgICAgIGNvbnN0IGhhc0tleSA9IHV0aWxzLmhhc093blByb3AocGFyc2VkLCBrZXkpO1xuXG4gICAgICBpZiAoIWtleSB8fCAoaGFzS2V5ICYmIHV0aWxzLmhhc093blByb3AoaWdub3JlRHVwbGljYXRlT2YsIGtleSkpKSB7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cblxuICAgICAgaWYgKGtleSA9PT0gJ3NldC1jb29raWUnKSB7XG4gICAgICAgIGlmIChoYXNLZXkpIHtcbiAgICAgICAgICBwYXJzZWRba2V5XS5wdXNoKHZhbCk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgcGFyc2VkW2tleV0gPSBbdmFsXTtcbiAgICAgICAgfVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgcGFyc2VkW2tleV0gPSBoYXNLZXkgPyBwYXJzZWRba2V5XSArICcsICcgKyB2YWwgOiB2YWw7XG4gICAgICB9XG4gICAgfSk7XG5cbiAgcmV0dXJuIHBhcnNlZDtcbn07XG4iLCIndXNlIHN0cmljdCc7XG5cbmltcG9ydCB1dGlscyBmcm9tICcuLi91dGlscy5qcyc7XG5cbmZ1bmN0aW9uIHRyaW1TUG9ySFRBQihzdHIpIHtcbiAgbGV0IHN0YXJ0ID0gMDtcbiAgbGV0IGVuZCA9IHN0ci5sZW5ndGg7XG5cbiAgd2hpbGUgKHN0YXJ0IDwgZW5kKSB7XG4gICAgY29uc3QgY29kZSA9IHN0ci5jaGFyQ29kZUF0KHN0YXJ0KTtcblxuICAgIGlmIChjb2RlICE9PSAweDA5ICYmIGNvZGUgIT09IDB4MjApIHtcbiAgICAgIGJyZWFrO1xuICAgIH1cblxuICAgIHN0YXJ0ICs9IDE7XG4gIH1cblxuICB3aGlsZSAoZW5kID4gc3RhcnQpIHtcbiAgICBjb25zdCBjb2RlID0gc3RyLmNoYXJDb2RlQXQoZW5kIC0gMSk7XG5cbiAgICBpZiAoY29kZSAhPT0gMHgwOSAmJiBjb2RlICE9PSAweDIwKSB7XG4gICAgICBicmVhaztcbiAgICB9XG5cbiAgICBlbmQgLT0gMTtcbiAgfVxuXG4gIHJldHVybiBzdGFydCA9PT0gMCAmJiBlbmQgPT09IHN0ci5sZW5ndGggPyBzdHIgOiBzdHIuc2xpY2Uoc3RhcnQsIGVuZCk7XG59XG5cbi8vIFRoZSBjb250cm9sLWNvZGUgcmFuZ2VzIGFyZSBpbnRlbnRpb25hbDogaGVhZGVyIHNhbml0aXphdGlvbiBzdHJpcHMgQzAvREVMIGJ5dGVzLlxuLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIG5vLWNvbnRyb2wtcmVnZXhcbmNvbnN0IElOVkFMSURfVU5JQ09ERV9IRUFERVJfVkFMVUVfQ0hBUlMgPSBuZXcgUmVnRXhwKCdbXFxcXHUwMDAwLVxcXFx1MDAwOFxcXFx1MDAwYS1cXFxcdTAwMWZcXFxcdTAwN2ZdKycsICdnJyk7XG4vLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgbm8tY29udHJvbC1yZWdleFxuY29uc3QgSU5WQUxJRF9CWVRFX1NUUklOR19IRUFERVJfVkFMVUVfQ0hBUlMgPSBuZXcgUmVnRXhwKCdbXlxcXFx1MDAwOVxcXFx1MDAyMC1cXFxcdTAwN2VcXFxcdTAwODAtXFxcXHUwMGZmXSsnLCAnZycpO1xuXG5mdW5jdGlvbiBzYW5pdGl6ZVZhbHVlKHZhbHVlLCBpbnZhbGlkQ2hhcnMpIHtcbiAgaWYgKHV0aWxzLmlzQXJyYXkodmFsdWUpKSB7XG4gICAgcmV0dXJuIHZhbHVlLm1hcCgoaXRlbSkgPT4gc2FuaXRpemVWYWx1ZShpdGVtLCBpbnZhbGlkQ2hhcnMpKTtcbiAgfVxuXG4gIHJldHVybiB0cmltU1BvckhUQUIoU3RyaW5nKHZhbHVlKS5yZXBsYWNlKGludmFsaWRDaGFycywgJycpKTtcbn1cblxuZXhwb3J0IGNvbnN0IHNhbml0aXplSGVhZGVyVmFsdWUgPSAodmFsdWUpID0+XG4gIHNhbml0aXplVmFsdWUodmFsdWUsIElOVkFMSURfVU5JQ09ERV9IRUFERVJfVkFMVUVfQ0hBUlMpO1xuXG5leHBvcnQgY29uc3Qgc2FuaXRpemVCeXRlU3RyaW5nSGVhZGVyVmFsdWUgPSAodmFsdWUpID0+XG4gIHNhbml0aXplVmFsdWUodmFsdWUsIElOVkFMSURfQllURV9TVFJJTkdfSEVBREVSX1ZBTFVFX0NIQVJTKTtcblxuZXhwb3J0IGZ1bmN0aW9uIHRvQnl0ZVN0cmluZ0hlYWRlck9iamVjdChoZWFkZXJzKSB7XG4gIGNvbnN0IGJ5dGVTdHJpbmdIZWFkZXJzID0gT2JqZWN0LmNyZWF0ZShudWxsKTtcblxuICB1dGlscy5mb3JFYWNoKGhlYWRlcnMudG9KU09OKCksICh2YWx1ZSwgaGVhZGVyKSA9PiB7XG4gICAgYnl0ZVN0cmluZ0hlYWRlcnNbaGVhZGVyXSA9IHNhbml0aXplQnl0ZVN0cmluZ0hlYWRlclZhbHVlKHZhbHVlKTtcbiAgfSk7XG5cbiAgcmV0dXJuIGJ5dGVTdHJpbmdIZWFkZXJzO1xufVxuIiwiJ3VzZSBzdHJpY3QnO1xuXG5pbXBvcnQgdXRpbHMgZnJvbSAnLi4vdXRpbHMuanMnO1xuaW1wb3J0IHBhcnNlSGVhZGVycyBmcm9tICcuLi9oZWxwZXJzL3BhcnNlSGVhZGVycy5qcyc7XG5pbXBvcnQgeyBzYW5pdGl6ZUhlYWRlclZhbHVlIH0gZnJvbSAnLi4vaGVscGVycy9zYW5pdGl6ZUhlYWRlclZhbHVlLmpzJztcblxuY29uc3QgJGludGVybmFscyA9IFN5bWJvbCgnaW50ZXJuYWxzJyk7XG5cbmZ1bmN0aW9uIG5vcm1hbGl6ZUhlYWRlcihoZWFkZXIpIHtcbiAgcmV0dXJuIGhlYWRlciAmJiBTdHJpbmcoaGVhZGVyKS50cmltKCkudG9Mb3dlckNhc2UoKTtcbn1cblxuZnVuY3Rpb24gbm9ybWFsaXplVmFsdWUodmFsdWUpIHtcbiAgaWYgKHZhbHVlID09PSBmYWxzZSB8fCB2YWx1ZSA9PSBudWxsKSB7XG4gICAgcmV0dXJuIHZhbHVlO1xuICB9XG5cbiAgcmV0dXJuIHV0aWxzLmlzQXJyYXkodmFsdWUpID8gdmFsdWUubWFwKG5vcm1hbGl6ZVZhbHVlKSA6IHNhbml0aXplSGVhZGVyVmFsdWUoU3RyaW5nKHZhbHVlKSk7XG59XG5cbmZ1bmN0aW9uIHBhcnNlVG9rZW5zKHN0cikge1xuICBjb25zdCB0b2tlbnMgPSBPYmplY3QuY3JlYXRlKG51bGwpO1xuICBjb25zdCB0b2tlbnNSRSA9IC8oW15cXHMsOz1dKylcXHMqKD86PVxccyooW14sO10rKSk/L2c7XG4gIGxldCBtYXRjaDtcblxuICB3aGlsZSAoKG1hdGNoID0gdG9rZW5zUkUuZXhlYyhzdHIpKSkge1xuICAgIHRva2Vuc1ttYXRjaFsxXV0gPSBtYXRjaFsyXTtcbiAgfVxuXG4gIHJldHVybiB0b2tlbnM7XG59XG5cbmNvbnN0IHBhcmFtZXRlck5hbWVSRSA9IC9eWyEjJCUmJyorXFwtLl5fYHx+MC05QS1aYS16XSskLztcblxuZnVuY3Rpb24gdHJpbU9XUyh2YWx1ZSkge1xuICBsZXQgc3RhcnQgPSAwO1xuICBsZXQgZW5kID0gdmFsdWUubGVuZ3RoO1xuXG4gIHdoaWxlIChzdGFydCA8IGVuZCkge1xuICAgIGNvbnN0IGNvZGUgPSB2YWx1ZS5jaGFyQ29kZUF0KHN0YXJ0KTtcblxuICAgIGlmIChjb2RlICE9PSAweDA5ICYmIGNvZGUgIT09IDB4MjApIHtcbiAgICAgIGJyZWFrO1xuICAgIH1cblxuICAgIHN0YXJ0ICs9IDE7XG4gIH1cblxuICB3aGlsZSAoZW5kID4gc3RhcnQpIHtcbiAgICBjb25zdCBjb2RlID0gdmFsdWUuY2hhckNvZGVBdChlbmQgLSAxKTtcblxuICAgIGlmIChjb2RlICE9PSAweDA5ICYmIGNvZGUgIT09IDB4MjApIHtcbiAgICAgIGJyZWFrO1xuICAgIH1cblxuICAgIGVuZCAtPSAxO1xuICB9XG5cbiAgcmV0dXJuIHN0YXJ0ID09PSAwICYmIGVuZCA9PT0gdmFsdWUubGVuZ3RoID8gdmFsdWUgOiB2YWx1ZS5zbGljZShzdGFydCwgZW5kKTtcbn1cblxuZnVuY3Rpb24gZGVjb2RlUXVvdGVkU3RyaW5nKHZhbHVlKSB7XG4gIGNvbnN0IGxhc3QgPSB2YWx1ZS5sZW5ndGggLSAxO1xuXG4gIGlmIChsYXN0IDwgMSB8fCB2YWx1ZS5jaGFyQ29kZUF0KDApICE9PSAweDIyIHx8IHZhbHVlLmNoYXJDb2RlQXQobGFzdCkgIT09IDB4MjIpIHtcbiAgICByZXR1cm4gdmFsdWU7XG4gIH1cblxuICBsZXQgZGVjb2RlZCA9ICcnO1xuXG4gIGZvciAobGV0IGkgPSAxOyBpIDwgbGFzdDsgaSsrKSB7XG4gICAgY29uc3QgY29kZSA9IHZhbHVlLmNoYXJDb2RlQXQoaSk7XG5cbiAgICBpZiAoY29kZSA9PT0gMHgyMikge1xuICAgICAgcmV0dXJuIHZhbHVlO1xuICAgIH1cblxuICAgIGlmIChjb2RlID09PSAweDVjKSB7XG4gICAgICBpICs9IDE7XG5cbiAgICAgIGlmIChpID49IGxhc3QpIHtcbiAgICAgICAgcmV0dXJuIHZhbHVlO1xuICAgICAgfVxuICAgIH1cblxuICAgIGRlY29kZWQgKz0gdmFsdWVbaV07XG4gIH1cblxuICByZXR1cm4gZGVjb2RlZDtcbn1cblxuZnVuY3Rpb24gcGFyc2VQYXJhbWV0ZXJzKHZhbHVlKSB7XG4gIGNvbnN0IHBhcmFtZXRlcnMgPSBPYmplY3QuY3JlYXRlKG51bGwpO1xuICBjb25zdCBzdHIgPSBTdHJpbmcodmFsdWUpO1xuICBsZXQgc3RhcnQgPSAwO1xuICBsZXQgcXVvdGVkID0gZmFsc2U7XG4gIGxldCBlc2NhcGVkID0gZmFsc2U7XG5cbiAgZnVuY3Rpb24gcGFyc2VQYXJhbWV0ZXIoZW5kKSB7XG4gICAgY29uc3QgcGFydCA9IHRyaW1PV1Moc3RyLnNsaWNlKHN0YXJ0LCBlbmQpKTtcbiAgICBjb25zdCBlcXVhbHMgPSBwYXJ0LmluZGV4T2YoJz0nKTtcblxuICAgIGlmIChlcXVhbHMgPCAxKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgY29uc3QgbmFtZSA9IHRyaW1PV1MocGFydC5zbGljZSgwLCBlcXVhbHMpKTtcblxuICAgIGlmICghcGFyYW1ldGVyTmFtZVJFLnRlc3QobmFtZSkpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICBjb25zdCBub3JtYWxpemVkTmFtZSA9IG5hbWUudG9Mb3dlckNhc2UoKTtcblxuICAgIGlmIChcbiAgICAgIG5vcm1hbGl6ZWROYW1lID09PSAnX19wcm90b19fJyB8fFxuICAgICAgbm9ybWFsaXplZE5hbWUgPT09ICdjb25zdHJ1Y3RvcicgfHxcbiAgICAgIG5vcm1hbGl6ZWROYW1lID09PSAncHJvdG90eXBlJ1xuICAgICkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIGNvbnN0IHBhcmFtZXRlclZhbHVlID0gdHJpbU9XUyhwYXJ0LnNsaWNlKGVxdWFscyArIDEpKTtcbiAgICBwYXJhbWV0ZXJzW25vcm1hbGl6ZWROYW1lXSA9IGRlY29kZVF1b3RlZFN0cmluZyhwYXJhbWV0ZXJWYWx1ZSk7XG4gIH1cblxuICBmb3IgKGxldCBpID0gMDsgaSA8IHN0ci5sZW5ndGg7IGkrKykge1xuICAgIGNvbnN0IGNvZGUgPSBzdHIuY2hhckNvZGVBdChpKTtcblxuICAgIGlmIChxdW90ZWQpIHtcbiAgICAgIGlmIChlc2NhcGVkKSB7XG4gICAgICAgIGVzY2FwZWQgPSBmYWxzZTtcbiAgICAgIH0gZWxzZSBpZiAoY29kZSA9PT0gMHg1Yykge1xuICAgICAgICBlc2NhcGVkID0gdHJ1ZTtcbiAgICAgIH0gZWxzZSBpZiAoY29kZSA9PT0gMHgyMikge1xuICAgICAgICBxdW90ZWQgPSBmYWxzZTtcbiAgICAgIH1cbiAgICB9IGVsc2UgaWYgKGNvZGUgPT09IDB4MjIpIHtcbiAgICAgIHF1b3RlZCA9IHRydWU7XG4gICAgfSBlbHNlIGlmIChjb2RlID09PSAweDJjIHx8IGNvZGUgPT09IDB4M2IpIHtcbiAgICAgIHBhcnNlUGFyYW1ldGVyKGkpO1xuICAgICAgc3RhcnQgPSBpICsgMTtcbiAgICB9XG4gIH1cblxuICBwYXJzZVBhcmFtZXRlcihzdHIubGVuZ3RoKTtcblxuICByZXR1cm4gcGFyYW1ldGVycztcbn1cblxuY29uc3QgaXNWYWxpZEhlYWRlck5hbWUgPSAoc3RyKSA9PiAvXlstX2EtekEtWjAtOV5gfH4sISMkJSYnKisuXSskLy50ZXN0KHN0ci50cmltKCkpO1xuXG4vLyBgX19wcm90b19fYCBpcyBhIHZhbGlkIGZpZWxkIG5hbWUsIGFuZCB0aGUgb25lIG5hbWUgdGhlIHVwcGVyY2FzZSBtYXBwaW5nIGF0XG4vLyB0aGUgYm90dG9tIG9mIHRoaXMgZmlsZSBjYW5ub3QgcmVhY2g6IGl0IGlzIGluaGVyaXRlZCBmcm9tIE9iamVjdC5wcm90b3R5cGVcbi8vIGluc3RlYWQgb2YgYmVpbmcgZGVjbGFyZWQgb24gQXhpb3NIZWFkZXJzLnByb3RvdHlwZSwgc28gYHNlbGYuX19wcm90b19fID0gdmBcbi8vIHJ1bnMgdGhlIGluaGVyaXRlZCBzZXR0ZXIuIFRoYXQgc2lsZW50bHkgZGlzY2FyZHMgdGhlIGhlYWRlciwgYW5kIGFuIGFycmF5XG4vLyB2YWx1ZSByZXBsYWNlcyB0aGUgaW5zdGFuY2UgcHJvdG90eXBlLCB0YWtpbmcgZXZlcnkgbWV0aG9kIHdpdGggaXQuXG4vLyBTdG9yZSBpdCB1bmRlciB0aGUgc2FtZSBraW5kIG9mIGNhc2UgdmFyaWFudCB0aGF0IG1hcHBpbmcgdXNlcyBmb3IgYHNldGAgYW5kXG4vLyBgY29uc3RydWN0b3JgLiBIZWFkZXIgbG9va3VwIGlzIGNhc2VsZXNzLCBzbyBpdCByZWFkcyBiYWNrIHVuZGVyIGVpdGhlclxuLy8gc3BlbGxpbmcsIGFuZCBubyBvd24gYF9fcHJvdG9fX2Agc2xvdCBpcyBldmVyIGNyZWF0ZWQgZm9yIGEgbGF0ZXJcbi8vIGBPYmplY3QuYXNzaWduYCB0byBjb3B5IG9udG8gYSBwbGFpbiBvYmplY3QgdGhyb3VnaCB0aGUgc2FtZSBzZXR0ZXIuXG5jb25zdCBQUk9UT19IRUFERVJfU0xPVCA9ICdfX1Byb3RvX18nO1xuXG5jb25zdCBoZWFkZXJTbG90ID0gKG5hbWUpID0+IChuYW1lID09PSAnX19wcm90b19fJyA/IFBST1RPX0hFQURFUl9TTE9UIDogbmFtZSk7XG5cbmZ1bmN0aW9uIG1hdGNoSGVhZGVyVmFsdWUoY29udGV4dCwgdmFsdWUsIGhlYWRlciwgZmlsdGVyLCBpc0hlYWRlck5hbWVGaWx0ZXIpIHtcbiAgaWYgKHV0aWxzLmlzRnVuY3Rpb24oZmlsdGVyKSkge1xuICAgIHJldHVybiBmaWx0ZXIuY2FsbChjb250ZXh0LCB2YWx1ZSwgaGVhZGVyKTtcbiAgfVxuXG4gIGlmIChpc0hlYWRlck5hbWVGaWx0ZXIpIHtcbiAgICB2YWx1ZSA9IGhlYWRlcjtcbiAgfVxuXG4gIGlmICghdXRpbHMuaXNTdHJpbmcodmFsdWUpKSByZXR1cm47XG5cbiAgaWYgKHV0aWxzLmlzU3RyaW5nKGZpbHRlcikpIHtcbiAgICByZXR1cm4gdmFsdWUuaW5kZXhPZihmaWx0ZXIpICE9PSAtMTtcbiAgfVxuXG4gIGlmICh1dGlscy5pc1JlZ0V4cChmaWx0ZXIpKSB7XG4gICAgcmV0dXJuIGZpbHRlci50ZXN0KHZhbHVlKTtcbiAgfVxufVxuXG5mdW5jdGlvbiBmb3JtYXRIZWFkZXIoaGVhZGVyKSB7XG4gIHJldHVybiBoZWFkZXJcbiAgICAudHJpbSgpXG4gICAgLnRvTG93ZXJDYXNlKClcbiAgICAucmVwbGFjZSgvKFthLXpcXGRdKShcXHcqKS9nLCAodywgY2hhciwgc3RyKSA9PiB7XG4gICAgICByZXR1cm4gY2hhci50b1VwcGVyQ2FzZSgpICsgc3RyO1xuICAgIH0pO1xufVxuXG5mdW5jdGlvbiBidWlsZEFjY2Vzc29ycyhvYmosIGhlYWRlcikge1xuICBjb25zdCBhY2Nlc3Nvck5hbWUgPSB1dGlscy50b0NhbWVsQ2FzZSgnICcgKyBoZWFkZXIpO1xuXG4gIFsnZ2V0JywgJ3NldCcsICdoYXMnXS5mb3JFYWNoKChtZXRob2ROYW1lKSA9PiB7XG4gICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KG9iaiwgbWV0aG9kTmFtZSArIGFjY2Vzc29yTmFtZSwge1xuICAgICAgLy8gTnVsbC1wcm90byBkZXNjcmlwdG9yIHNvIGEgcG9sbHV0ZWQgT2JqZWN0LnByb3RvdHlwZS5nZXQgY2Fubm90IHR1cm5cbiAgICAgIC8vIHRoaXMgZGF0YSBkZXNjcmlwdG9yIGludG8gYW4gYWNjZXNzb3IgZGVzY3JpcHRvciBvbiB0aGUgd2F5IGluLlxuICAgICAgX19wcm90b19fOiBudWxsLFxuICAgICAgdmFsdWU6IGZ1bmN0aW9uIChhcmcxLCBhcmcyLCBhcmczKSB7XG4gICAgICAgIHJldHVybiB0aGlzW21ldGhvZE5hbWVdLmNhbGwodGhpcywgaGVhZGVyLCBhcmcxLCBhcmcyLCBhcmczKTtcbiAgICAgIH0sXG4gICAgICBjb25maWd1cmFibGU6IHRydWUsXG4gICAgfSk7XG4gIH0pO1xufVxuXG5jbGFzcyBBeGlvc0hlYWRlcnMge1xuICBjb25zdHJ1Y3RvcihoZWFkZXJzKSB7XG4gICAgaGVhZGVycyAmJiB0aGlzLnNldChoZWFkZXJzKTtcbiAgfVxuXG4gIHNldChoZWFkZXIsIHZhbHVlT3JSZXdyaXRlLCByZXdyaXRlKSB7XG4gICAgY29uc3Qgc2VsZiA9IHRoaXM7XG5cbiAgICBmdW5jdGlvbiBzZXRIZWFkZXIoX3ZhbHVlLCBfaGVhZGVyLCBfcmV3cml0ZSkge1xuICAgICAgY29uc3QgbEhlYWRlciA9IG5vcm1hbGl6ZUhlYWRlcihfaGVhZGVyKTtcblxuICAgICAgaWYgKCFsSGVhZGVyKSB7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cblxuICAgICAgY29uc3Qga2V5ID0gdXRpbHMuZmluZEtleShzZWxmLCBsSGVhZGVyKTtcblxuICAgICAgaWYgKFxuICAgICAgICAha2V5IHx8XG4gICAgICAgIHNlbGZba2V5XSA9PT0gdW5kZWZpbmVkIHx8XG4gICAgICAgIF9yZXdyaXRlID09PSB0cnVlIHx8XG4gICAgICAgIChfcmV3cml0ZSA9PT0gdW5kZWZpbmVkICYmIHNlbGZba2V5XSAhPT0gZmFsc2UpXG4gICAgICApIHtcbiAgICAgICAgc2VsZltoZWFkZXJTbG90KGtleSB8fCBfaGVhZGVyKV0gPSBub3JtYWxpemVWYWx1ZShfdmFsdWUpO1xuICAgICAgfVxuICAgIH1cblxuICAgIGNvbnN0IHNldEhlYWRlcnMgPSAoaGVhZGVycywgX3Jld3JpdGUpID0+XG4gICAgICB1dGlscy5mb3JFYWNoKGhlYWRlcnMsIChfdmFsdWUsIF9oZWFkZXIpID0+IHNldEhlYWRlcihfdmFsdWUsIF9oZWFkZXIsIF9yZXdyaXRlKSk7XG5cbiAgICBpZiAodXRpbHMuaXNQbGFpbk9iamVjdChoZWFkZXIpIHx8IGhlYWRlciBpbnN0YW5jZW9mIHRoaXMuY29uc3RydWN0b3IpIHtcbiAgICAgIHNldEhlYWRlcnMoaGVhZGVyLCB2YWx1ZU9yUmV3cml0ZSk7XG4gICAgfSBlbHNlIGlmICh1dGlscy5pc1N0cmluZyhoZWFkZXIpICYmIChoZWFkZXIgPSBoZWFkZXIudHJpbSgpKSAmJiAhaXNWYWxpZEhlYWRlck5hbWUoaGVhZGVyKSkge1xuICAgICAgc2V0SGVhZGVycyhwYXJzZUhlYWRlcnMoaGVhZGVyKSwgdmFsdWVPclJld3JpdGUpO1xuICAgIH0gZWxzZSBpZiAodXRpbHMuaXNPYmplY3QoaGVhZGVyKSAmJiB1dGlscy5pc1NhZmVJdGVyYWJsZShoZWFkZXIpKSB7XG4gICAgICBsZXQgb2JqID0gT2JqZWN0LmNyZWF0ZShudWxsKSxcbiAgICAgICAgZGVzdCxcbiAgICAgICAga2V5O1xuICAgICAgZm9yIChjb25zdCBlbnRyeSBvZiBoZWFkZXIpIHtcbiAgICAgICAgaWYgKCF1dGlscy5pc0FycmF5KGVudHJ5KSkge1xuICAgICAgICAgIHRocm93IG5ldyBUeXBlRXJyb3IoJ09iamVjdCBpdGVyYXRvciBtdXN0IHJldHVybiBhIGtleS12YWx1ZSBwYWlyJyk7XG4gICAgICAgIH1cblxuICAgICAgICBrZXkgPSBlbnRyeVswXTtcblxuICAgICAgICBpZiAodXRpbHMuaGFzT3duUHJvcChvYmosIGtleSkpIHtcbiAgICAgICAgICBkZXN0ID0gb2JqW2tleV07XG4gICAgICAgICAgb2JqW2tleV0gPSB1dGlscy5pc0FycmF5KGRlc3QpID8gWy4uLmRlc3QsIGVudHJ5WzFdXSA6IFtkZXN0LCBlbnRyeVsxXV07XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgb2JqW2tleV0gPSBlbnRyeVsxXTtcbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICBzZXRIZWFkZXJzKG9iaiwgdmFsdWVPclJld3JpdGUpO1xuICAgIH0gZWxzZSB7XG4gICAgICBoZWFkZXIgIT0gbnVsbCAmJiBzZXRIZWFkZXIodmFsdWVPclJld3JpdGUsIGhlYWRlciwgcmV3cml0ZSk7XG4gICAgfVxuXG4gICAgcmV0dXJuIHRoaXM7XG4gIH1cblxuICBnZXQoaGVhZGVyLCBwYXJzZXIpIHtcbiAgICBoZWFkZXIgPSBub3JtYWxpemVIZWFkZXIoaGVhZGVyKTtcblxuICAgIGlmIChoZWFkZXIpIHtcbiAgICAgIGNvbnN0IGtleSA9IHV0aWxzLmZpbmRLZXkodGhpcywgaGVhZGVyKTtcblxuICAgICAgaWYgKGtleSkge1xuICAgICAgICBjb25zdCB2YWx1ZSA9IHRoaXNba2V5XTtcblxuICAgICAgICBpZiAoIXBhcnNlcikge1xuICAgICAgICAgIHJldHVybiB2YWx1ZTtcbiAgICAgICAgfVxuXG4gICAgICAgIGlmIChwYXJzZXIgPT09IHRydWUpIHtcbiAgICAgICAgICByZXR1cm4gcGFyc2VUb2tlbnModmFsdWUpO1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKHV0aWxzLmlzRnVuY3Rpb24ocGFyc2VyKSkge1xuICAgICAgICAgIHJldHVybiBwYXJzZXIuY2FsbCh0aGlzLCB2YWx1ZSwga2V5KTtcbiAgICAgICAgfVxuXG4gICAgICAgIGlmICh1dGlscy5pc1JlZ0V4cChwYXJzZXIpKSB7XG4gICAgICAgICAgcmV0dXJuIHBhcnNlci5leGVjKHZhbHVlKTtcbiAgICAgICAgfVxuXG4gICAgICAgIHRocm93IG5ldyBUeXBlRXJyb3IoJ3BhcnNlciBtdXN0IGJlIGJvb2xlYW58cmVnZXhwfGZ1bmN0aW9uJyk7XG4gICAgICB9XG4gICAgfVxuICB9XG5cbiAgaGFzKGhlYWRlciwgbWF0Y2hlcikge1xuICAgIGhlYWRlciA9IG5vcm1hbGl6ZUhlYWRlcihoZWFkZXIpO1xuXG4gICAgaWYgKGhlYWRlcikge1xuICAgICAgY29uc3Qga2V5ID0gdXRpbHMuZmluZEtleSh0aGlzLCBoZWFkZXIpO1xuXG4gICAgICByZXR1cm4gISEoXG4gICAgICAgIGtleSAmJlxuICAgICAgICB0aGlzW2tleV0gIT09IHVuZGVmaW5lZCAmJlxuICAgICAgICAoIW1hdGNoZXIgfHwgbWF0Y2hIZWFkZXJWYWx1ZSh0aGlzLCB0aGlzW2tleV0sIGtleSwgbWF0Y2hlcikpXG4gICAgICApO1xuICAgIH1cblxuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuXG4gIGRlbGV0ZShoZWFkZXIsIG1hdGNoZXIpIHtcbiAgICBjb25zdCBzZWxmID0gdGhpcztcbiAgICBsZXQgZGVsZXRlZCA9IGZhbHNlO1xuXG4gICAgZnVuY3Rpb24gZGVsZXRlSGVhZGVyKF9oZWFkZXIpIHtcbiAgICAgIF9oZWFkZXIgPSBub3JtYWxpemVIZWFkZXIoX2hlYWRlcik7XG5cbiAgICAgIGlmIChfaGVhZGVyKSB7XG4gICAgICAgIGNvbnN0IGtleSA9IHV0aWxzLmZpbmRLZXkoc2VsZiwgX2hlYWRlcik7XG5cbiAgICAgICAgaWYgKGtleSAmJiAoIW1hdGNoZXIgfHwgbWF0Y2hIZWFkZXJWYWx1ZShzZWxmLCBzZWxmW2tleV0sIGtleSwgbWF0Y2hlcikpKSB7XG4gICAgICAgICAgZGVsZXRlIHNlbGZba2V5XTtcblxuICAgICAgICAgIGRlbGV0ZWQgPSB0cnVlO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuXG4gICAgaWYgKHV0aWxzLmlzQXJyYXkoaGVhZGVyKSkge1xuICAgICAgaGVhZGVyLmZvckVhY2goZGVsZXRlSGVhZGVyKTtcbiAgICB9IGVsc2Uge1xuICAgICAgZGVsZXRlSGVhZGVyKGhlYWRlcik7XG4gICAgfVxuXG4gICAgcmV0dXJuIGRlbGV0ZWQ7XG4gIH1cblxuICBjbGVhcihtYXRjaGVyKSB7XG4gICAgY29uc3Qga2V5cyA9IE9iamVjdC5rZXlzKHRoaXMpO1xuICAgIGxldCBpID0ga2V5cy5sZW5ndGg7XG4gICAgbGV0IGRlbGV0ZWQgPSBmYWxzZTtcblxuICAgIHdoaWxlIChpLS0pIHtcbiAgICAgIGNvbnN0IGtleSA9IGtleXNbaV07XG4gICAgICBpZiAoIW1hdGNoZXIgfHwgbWF0Y2hIZWFkZXJWYWx1ZSh0aGlzLCB0aGlzW2tleV0sIGtleSwgbWF0Y2hlciwgdHJ1ZSkpIHtcbiAgICAgICAgZGVsZXRlIHRoaXNba2V5XTtcbiAgICAgICAgZGVsZXRlZCA9IHRydWU7XG4gICAgICB9XG4gICAgfVxuXG4gICAgcmV0dXJuIGRlbGV0ZWQ7XG4gIH1cblxuICBub3JtYWxpemUoZm9ybWF0KSB7XG4gICAgY29uc3Qgc2VsZiA9IHRoaXM7XG4gICAgY29uc3QgaGVhZGVycyA9IE9iamVjdC5jcmVhdGUobnVsbCk7XG5cbiAgICB1dGlscy5mb3JFYWNoKHRoaXMsICh2YWx1ZSwgaGVhZGVyKSA9PiB7XG4gICAgICBjb25zdCBrZXkgPSB1dGlscy5maW5kS2V5KGhlYWRlcnMsIGhlYWRlcik7XG5cbiAgICAgIGlmIChrZXkpIHtcbiAgICAgICAgc2VsZltrZXldID0gbm9ybWFsaXplVmFsdWUodmFsdWUpO1xuICAgICAgICBkZWxldGUgc2VsZltoZWFkZXJdO1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG5cbiAgICAgIGNvbnN0IG5vcm1hbGl6ZWQgPSBoZWFkZXJTbG90KGZvcm1hdCA/IGZvcm1hdEhlYWRlcihoZWFkZXIpIDogU3RyaW5nKGhlYWRlcikudHJpbSgpKTtcblxuICAgICAgaWYgKG5vcm1hbGl6ZWQgIT09IGhlYWRlcikge1xuICAgICAgICBkZWxldGUgc2VsZltoZWFkZXJdO1xuICAgICAgfVxuXG4gICAgICBzZWxmW25vcm1hbGl6ZWRdID0gbm9ybWFsaXplVmFsdWUodmFsdWUpO1xuXG4gICAgICBoZWFkZXJzW25vcm1hbGl6ZWRdID0gdHJ1ZTtcbiAgICB9KTtcblxuICAgIHJldHVybiB0aGlzO1xuICB9XG5cbiAgY29uY2F0KC4uLnRhcmdldHMpIHtcbiAgICByZXR1cm4gdGhpcy5jb25zdHJ1Y3Rvci5jb25jYXQodGhpcywgLi4udGFyZ2V0cyk7XG4gIH1cblxuICB0b0pTT04oYXNTdHJpbmdzKSB7XG4gICAgY29uc3Qgb2JqID0gT2JqZWN0LmNyZWF0ZShudWxsKTtcblxuICAgIHV0aWxzLmZvckVhY2godGhpcywgKHZhbHVlLCBoZWFkZXIpID0+IHtcbiAgICAgIHZhbHVlICE9IG51bGwgJiZcbiAgICAgICAgdmFsdWUgIT09IGZhbHNlICYmXG4gICAgICAgIChvYmpbaGVhZGVyXSA9IGFzU3RyaW5ncyAmJiB1dGlscy5pc0FycmF5KHZhbHVlKSA/IHZhbHVlLmpvaW4oJywgJykgOiB2YWx1ZSk7XG4gICAgfSk7XG5cbiAgICByZXR1cm4gb2JqO1xuICB9XG5cbiAgW1N5bWJvbC5pdGVyYXRvcl0oKSB7XG4gICAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHRoaXMudG9KU09OKCkpW1N5bWJvbC5pdGVyYXRvcl0oKTtcbiAgfVxuXG4gIHRvU3RyaW5nKCkge1xuICAgIHJldHVybiBPYmplY3QuZW50cmllcyh0aGlzLnRvSlNPTigpKVxuICAgICAgLm1hcCgoW2hlYWRlciwgdmFsdWVdKSA9PiBoZWFkZXIgKyAnOiAnICsgdmFsdWUpXG4gICAgICAuam9pbignXFxuJyk7XG4gIH1cblxuICBnZXRTZXRDb29raWUoKSB7XG4gICAgY29uc3QgdmFsdWUgPSB0aGlzLmdldCgnc2V0LWNvb2tpZScpO1xuICAgIHJldHVybiB1dGlscy5pc0FycmF5KHZhbHVlKSA/IHZhbHVlIDogdmFsdWUgPT0gbnVsbCB8fCB2YWx1ZSA9PT0gZmFsc2UgPyBbXSA6IFt2YWx1ZV07XG4gIH1cblxuICBnZXQgW1N5bWJvbC50b1N0cmluZ1RhZ10oKSB7XG4gICAgcmV0dXJuICdBeGlvc0hlYWRlcnMnO1xuICB9XG5cbiAgc3RhdGljIGZyb20odGhpbmcpIHtcbiAgICByZXR1cm4gdGhpbmcgaW5zdGFuY2VvZiB0aGlzID8gdGhpbmcgOiBuZXcgdGhpcyh0aGluZyk7XG4gIH1cblxuICBzdGF0aWMgcGFyc2VQYXJhbWV0ZXJzKHZhbHVlKSB7XG4gICAgcmV0dXJuIHBhcnNlUGFyYW1ldGVycyh2YWx1ZSk7XG4gIH1cblxuICBzdGF0aWMgY29uY2F0KGZpcnN0LCAuLi50YXJnZXRzKSB7XG4gICAgY29uc3QgY29tcHV0ZWQgPSBuZXcgdGhpcyhmaXJzdCk7XG5cbiAgICB0YXJnZXRzLmZvckVhY2goKHRhcmdldCkgPT4gY29tcHV0ZWQuc2V0KHRhcmdldCkpO1xuXG4gICAgcmV0dXJuIGNvbXB1dGVkO1xuICB9XG5cbiAgc3RhdGljIGFjY2Vzc29yKGhlYWRlcikge1xuICAgIGNvbnN0IGludGVybmFscyA9XG4gICAgICAodGhpc1skaW50ZXJuYWxzXSA9XG4gICAgICB0aGlzWyRpbnRlcm5hbHNdID1cbiAgICAgICAge1xuICAgICAgICAgIGFjY2Vzc29yczoge30sXG4gICAgICAgIH0pO1xuXG4gICAgY29uc3QgYWNjZXNzb3JzID0gaW50ZXJuYWxzLmFjY2Vzc29ycztcbiAgICBjb25zdCBwcm90b3R5cGUgPSB0aGlzLnByb3RvdHlwZTtcblxuICAgIGZ1bmN0aW9uIGRlZmluZUFjY2Vzc29yKF9oZWFkZXIpIHtcbiAgICAgIGNvbnN0IGxIZWFkZXIgPSBub3JtYWxpemVIZWFkZXIoX2hlYWRlcik7XG5cbiAgICAgIGlmICghYWNjZXNzb3JzW2xIZWFkZXJdKSB7XG4gICAgICAgIGJ1aWxkQWNjZXNzb3JzKHByb3RvdHlwZSwgX2hlYWRlcik7XG4gICAgICAgIGFjY2Vzc29yc1tsSGVhZGVyXSA9IHRydWU7XG4gICAgICB9XG4gICAgfVxuXG4gICAgdXRpbHMuaXNBcnJheShoZWFkZXIpID8gaGVhZGVyLmZvckVhY2goZGVmaW5lQWNjZXNzb3IpIDogZGVmaW5lQWNjZXNzb3IoaGVhZGVyKTtcblxuICAgIHJldHVybiB0aGlzO1xuICB9XG59XG5cbkF4aW9zSGVhZGVycy5hY2Nlc3NvcihbXG4gICdDb250ZW50LVR5cGUnLFxuICAnQ29udGVudC1MZW5ndGgnLFxuICAnQWNjZXB0JyxcbiAgJ0FjY2VwdC1FbmNvZGluZycsXG4gICdVc2VyLUFnZW50JyxcbiAgJ0F1dGhvcml6YXRpb24nLFxuXSk7XG5cbi8vIHJlc2VydmVkIG5hbWVzIGhvdGZpeFxudXRpbHMucmVkdWNlRGVzY3JpcHRvcnMoQXhpb3NIZWFkZXJzLnByb3RvdHlwZSwgKHsgdmFsdWUgfSwga2V5KSA9PiB7XG4gIGxldCBtYXBwZWQgPSBrZXlbMF0udG9VcHBlckNhc2UoKSArIGtleS5zbGljZSgxKTsgLy8gbWFwIGBzZXRgID0+IGBTZXRgXG4gIHJldHVybiB7XG4gICAgZ2V0OiAoKSA9PiB2YWx1ZSxcbiAgICBzZXQoaGVhZGVyVmFsdWUpIHtcbiAgICAgIHRoaXNbbWFwcGVkXSA9IGhlYWRlclZhbHVlO1xuICAgIH0sXG4gIH07XG59KTtcblxudXRpbHMuZnJlZXplTWV0aG9kcyhBeGlvc0hlYWRlcnMpO1xuXG5leHBvcnQgZGVmYXVsdCBBeGlvc0hlYWRlcnM7XG4iLCIndXNlIHN0cmljdCc7XG5cbmltcG9ydCB1dGlscyBmcm9tICcuLi91dGlscy5qcyc7XG5pbXBvcnQgQXhpb3NIZWFkZXJzIGZyb20gJy4vQXhpb3NIZWFkZXJzLmpzJztcblxuZXhwb3J0IGNvbnN0IFJFREFDVEVEID0gJ1tSRURBQ1RFRCAqKioqXSc7XG5cbmZ1bmN0aW9uIGhhc093bk9yUHJvdG90eXBlVG9KU09OKHNvdXJjZSkge1xuICBpZiAodXRpbHMuaGFzT3duUHJvcChzb3VyY2UsICd0b0pTT04nKSkge1xuICAgIHJldHVybiB0cnVlO1xuICB9XG5cbiAgbGV0IHByb3RvdHlwZSA9IE9iamVjdC5nZXRQcm90b3R5cGVPZihzb3VyY2UpO1xuXG4gIHdoaWxlIChwcm90b3R5cGUgJiYgcHJvdG90eXBlICE9PSBPYmplY3QucHJvdG90eXBlKSB7XG4gICAgaWYgKHV0aWxzLmhhc093blByb3AocHJvdG90eXBlLCAndG9KU09OJykpIHtcbiAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cblxuICAgIHByb3RvdHlwZSA9IE9iamVjdC5nZXRQcm90b3R5cGVPZihwcm90b3R5cGUpO1xuICB9XG5cbiAgcmV0dXJuIGZhbHNlO1xufVxuXG4vLyBCdWlsZCBhIHBsYWluLW9iamVjdCBzbmFwc2hvdCBvZiBgY29uZmlnYCBhbmQgcmVwbGFjZSB0aGUgdmFsdWUgb2YgYW55IGtleVxuLy8gKGNhc2UtaW5zZW5zaXRpdmUpIGxpc3RlZCBpbiBgcmVkYWN0S2V5c2Agd2l0aCBSRURBQ1RFRC4gV2Fsa3MgdGhyb3VnaCBhcnJheXNcbi8vIGFuZCBBeGlvc0hlYWRlcnMsIGFuZCBzaG9ydC1jaXJjdWl0cyBvbiBjaXJjdWxhciByZWZlcmVuY2VzLlxuZnVuY3Rpb24gcmVkYWN0Q29uZmlnKGNvbmZpZywgcmVkYWN0S2V5cykge1xuICBjb25zdCBsb3dlcktleXMgPSBuZXcgU2V0KHJlZGFjdEtleXMubWFwKChrKSA9PiBTdHJpbmcoaykudG9Mb3dlckNhc2UoKSkpO1xuICBjb25zdCBzZWVuID0gW107XG5cbiAgY29uc3QgdmlzaXQgPSAoc291cmNlKSA9PiB7XG4gICAgaWYgKHNvdXJjZSA9PT0gbnVsbCB8fCB0eXBlb2Ygc291cmNlICE9PSAnb2JqZWN0JykgcmV0dXJuIHNvdXJjZTtcbiAgICBpZiAodXRpbHMuaXNCdWZmZXIoc291cmNlKSkgcmV0dXJuIHNvdXJjZTtcbiAgICBpZiAoc2Vlbi5pbmRleE9mKHNvdXJjZSkgIT09IC0xKSByZXR1cm4gdW5kZWZpbmVkO1xuXG4gICAgaWYgKHNvdXJjZSBpbnN0YW5jZW9mIEF4aW9zSGVhZGVycykge1xuICAgICAgc291cmNlID0gc291cmNlLnRvSlNPTigpO1xuICAgIH1cblxuICAgIHNlZW4ucHVzaChzb3VyY2UpO1xuXG4gICAgbGV0IHJlc3VsdDtcbiAgICBpZiAodXRpbHMuaXNBcnJheShzb3VyY2UpKSB7XG4gICAgICByZXN1bHQgPSBbXTtcbiAgICAgIHNvdXJjZS5mb3JFYWNoKCh2LCBpKSA9PiB7XG4gICAgICAgIGNvbnN0IHJlZHVjZWRWYWx1ZSA9IHZpc2l0KHYpO1xuICAgICAgICBpZiAoIXV0aWxzLmlzVW5kZWZpbmVkKHJlZHVjZWRWYWx1ZSkpIHtcbiAgICAgICAgICByZXN1bHRbaV0gPSByZWR1Y2VkVmFsdWU7XG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgIH0gZWxzZSB7XG4gICAgICBpZiAoIXV0aWxzLmlzUGxhaW5PYmplY3Qoc291cmNlKSAmJiBoYXNPd25PclByb3RvdHlwZVRvSlNPTihzb3VyY2UpKSB7XG4gICAgICAgIHNlZW4ucG9wKCk7XG4gICAgICAgIHJldHVybiBzb3VyY2U7XG4gICAgICB9XG5cbiAgICAgIHJlc3VsdCA9IE9iamVjdC5jcmVhdGUobnVsbCk7XG4gICAgICBmb3IgKGNvbnN0IFtrZXksIHZhbHVlXSBvZiBPYmplY3QuZW50cmllcyhzb3VyY2UpKSB7XG4gICAgICAgIGNvbnN0IHJlZHVjZWRWYWx1ZSA9IGxvd2VyS2V5cy5oYXMoa2V5LnRvTG93ZXJDYXNlKCkpID8gUkVEQUNURUQgOiB2aXNpdCh2YWx1ZSk7XG4gICAgICAgIGlmICghdXRpbHMuaXNVbmRlZmluZWQocmVkdWNlZFZhbHVlKSkge1xuICAgICAgICAgIHJlc3VsdFtrZXldID0gcmVkdWNlZFZhbHVlO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuXG4gICAgc2Vlbi5wb3AoKTtcbiAgICByZXR1cm4gcmVzdWx0O1xuICB9O1xuXG4gIHJldHVybiB2aXNpdChjb25maWcpO1xufVxuXG5mdW5jdGlvbiBzdHJpbmdpZnlTYWZlbHkodmFsdWUpIHtcbiAgdHJ5IHtcbiAgICByZXR1cm4gU3RyaW5nKHZhbHVlKTtcbiAgfSBjYXRjaCAoZXJyKSB7XG4gICAgcmV0dXJuICcnO1xuICB9XG59XG5cbmZ1bmN0aW9uIGFnZ3JlZ2F0ZUVycm9yTWVzc2FnZShlcnJvcikge1xuICBjb25zdCBtZXNzYWdlID0gZXJyb3IuZXJyb3JzXG4gICAgLm1hcCgoZW50cnkpID0+IHtcbiAgICAgIHRyeSB7XG4gICAgICAgIHJldHVybiBlbnRyeSAmJiBlbnRyeS5tZXNzYWdlID8gc3RyaW5naWZ5U2FmZWx5KGVudHJ5Lm1lc3NhZ2UpIDogc3RyaW5naWZ5U2FmZWx5KGVudHJ5KTtcbiAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICByZXR1cm4gJyc7XG4gICAgICB9XG4gICAgfSlcbiAgICAuZmlsdGVyKEJvb2xlYW4pXG4gICAgLmpvaW4oJzsgJyk7XG5cbiAgcmV0dXJuIG1lc3NhZ2UgfHwgZXJyb3IubmFtZSB8fCAnQWdncmVnYXRlRXJyb3InO1xufVxuXG4vLyBTaGFyZWQgd2l0aCBgQXhpb3MucHJvdG90eXBlLnJlcXVlc3RgLCB3aGljaCBzcGxpY2VzIHRoZSByZWNvbnN0cnVjdGVkXG4vLyBjYWxsZXIgZnJhbWVzIGluIGFoZWFkIG9mIHRoaXMgbWFya2VyLlxuZXhwb3J0IGNvbnN0IENBVVNFRF9CWV9TRVBBUkFUT1IgPSAnXFxuQ2F1c2VkIGJ5OiAnO1xuY29uc3QgJGNhdXNlU3RhY2sgPSBTeW1ib2woJ2NhdXNlU3RhY2snKTtcblxuLy8gTWF0Y2ggdGhlIHNlY3Rpb24gd2UgYXBwZW5kZWQsIG5vdCBtYXJrZXItbGlrZSB0ZXh0IGluIGFuIGVycm9yIG1lc3NhZ2Ugb3Jcbi8vIGEgcmVwbGFjZW1lbnQgc3RhY2sgc3VwcGxpZWQgYnkgdGhlIGNhbGxlci4gRG8gbm90IHJlLXJlYWQgdGhlIGNhdXNlJ3Mgc3RhY2suXG5leHBvcnQgZnVuY3Rpb24gZ2V0Q2F1c2VTdGFja0luZGV4KGVycm9yLCBzdGFjaykge1xuICBjb25zdCBjYXVzZVN0YWNrID0gdXRpbHMuaGFzT3duUHJvcChlcnJvciwgJGNhdXNlU3RhY2spICYmIGVycm9yWyRjYXVzZVN0YWNrXTtcblxuICByZXR1cm4gY2F1c2VTdGFjayAmJiBzdGFjay5lbmRzV2l0aChjYXVzZVN0YWNrKSA/IHN0YWNrLmxlbmd0aCAtIGNhdXNlU3RhY2subGVuZ3RoIDogLTE7XG59XG5cbi8qKlxuICogQXBwZW5kIHRoZSBzdGFjayBvZiBhIHdyYXBwZWQgZXJyb3IgdG8gYHRhcmdldC5zdGFja2AuXG4gKlxuICogYGNhdXNlYCBhbHJlYWR5IGV4cG9zZXMgdGhlIG9yaWdpbmFsIGVycm9yIGZvciB0b29saW5nIHRoYXQgd2Fsa3MgdGhlIHN0YW5kYXJkXG4gKiBjYXVzZSBjaGFpbiwgYnV0IG1hbnkgZXJyb3IgcmVwb3J0ZXJzIHJlYWQgYHN0YWNrYCBhbmQgbm90aGluZyBlbHNlLiBJbmxpbmluZ1xuICogdGhlIHdyYXBwZWQgc3RhY2sgdGhlcmUgbWVhbnMgdGhvc2UgcmVwb3J0ZXJzIHN1cmZhY2UgdGhlIHVuZGVybHlpbmcgZmFpbHVyZVxuICogaW5zdGVhZCBvZiB0aGUgYXhpb3MgZnJhbWVzIHRoYXQgbm9ybWFsaXplZCBpdCAoc2VlICM2NjcwKS5cbiAqXG4gKiBFdmVyeSByZWFkIGlzIGRlZmVuc2l2ZTogYSBjdXN0b20gYEVycm9yLnByZXBhcmVTdGFja1RyYWNlYCBob29rLCBhIHJ1bnRpbWVcbiAqIHdpdGhvdXQgc3RhY2sgc3VwcG9ydCwgb3IgYSByZXBsYWNlZCBgc3RhY2tgIHByb3BlcnR5IGNhbiBsZWF2ZSB0aGUgdmFsdWVcbiAqIG1pc3NpbmcsIG5vbi1zdHJpbmcsIG9yIHJlYWQtb25seSwgYW5kIG5vcm1hbGl6aW5nIGFuIGVycm9yIG11c3Qgbm90IHRocm93XG4gKiBiZWNhdXNlIG9mIHRoYXQuXG4gKlxuICogQHBhcmFtIHtFcnJvcn0gdGFyZ2V0IFRoZSBBeGlvc0Vycm9yIGJlaW5nIGJ1aWx0LlxuICogQHBhcmFtIHtFcnJvcn0gc291cmNlIFRoZSBlcnJvciBiZWluZyB3cmFwcGVkLlxuICpcbiAqIEByZXR1cm5zIHt2b2lkfVxuICovXG5mdW5jdGlvbiBhcHBlbmRDYXVzZVN0YWNrKHRhcmdldCwgc291cmNlKSB7XG4gIHRyeSB7XG4gICAgY29uc3Qgc291cmNlU3RhY2sgPSBzb3VyY2UgJiYgc291cmNlLnN0YWNrO1xuXG4gICAgaWYgKHR5cGVvZiBzb3VyY2VTdGFjayAhPT0gJ3N0cmluZycgfHwgIXNvdXJjZVN0YWNrKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgY29uc3QgdGFyZ2V0U3RhY2sgPSB0YXJnZXQuc3RhY2s7XG5cbiAgICBpZiAodHlwZW9mIHRhcmdldFN0YWNrICE9PSAnc3RyaW5nJyB8fCAhdGFyZ2V0U3RhY2spIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICAvLyBFYWNoIGNhbGwgdG8gYGZyb20oKWAgY3JlYXRlcyBhIGZyZXNoIHRhcmdldC4gUmUtd3JhcHBpbmcgaW5jbHVkZXMgdGhlXG4gICAgLy8gcHJldmlvdXMgc3RhY2sgdmVyYmF0aW0sIGFkZGluZyBvbmUgY2F1c2Ugc2VjdGlvbiBwZXIgd3JhcC5cbiAgICBjb25zdCBjYXVzZVN0YWNrID0gQ0FVU0VEX0JZX1NFUEFSQVRPUiArIHNvdXJjZVN0YWNrO1xuICAgIHRhcmdldC5zdGFjayA9IHRhcmdldFN0YWNrICsgY2F1c2VTdGFjaztcbiAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkodGFyZ2V0LCAkY2F1c2VTdGFjaywgeyBfX3Byb3RvX186IG51bGwsIHZhbHVlOiBjYXVzZVN0YWNrIH0pO1xuICB9IGNhdGNoIChlKSB7XG4gICAgLy8gSWdub3JlIGZhaWx1cmVzIGZyb20gY3VzdG9tIHN0YWNrIGhvb2tzIG9yIHVuLXdyaXRhYmxlIHN0YWNrIHByb3BlcnRpZXMuXG4gIH1cbn1cblxuY2xhc3MgQXhpb3NFcnJvciBleHRlbmRzIEVycm9yIHtcbiAgc3RhdGljIGZyb20oZXJyb3IsIGNvZGUsIGNvbmZpZywgcmVxdWVzdCwgcmVzcG9uc2UsIGN1c3RvbVByb3BzKSB7XG4gICAgLy8gYEFnZ3JlZ2F0ZUVycm9yYCAodGhyb3duIGJ5IE5vZGUgb24gZHVhbC1zdGFjay9IYXBweS1FeWViYWxscyBjb25uZWN0aW9uXG4gICAgLy8gZmFpbHVyZXMpIGhhcyBhbiBlbXB0eSBgbWVzc2FnZWA7IGl0cyBkZXRhaWwgbGl2ZXMgaW4gYGVycm9yc1tdYC4gV2l0aG91dFxuICAgIC8vIHRoaXMsIHRoZSB3cmFwcGVkIGVycm9yIHN1cmZhY2VzIHdpdGggYSBibGFuayBtZXNzYWdlIChzZWUgIzY3MjEpLlxuICAgIGxldCBtZXNzYWdlID0gZXJyb3IubWVzc2FnZTtcbiAgICBpZiAoIW1lc3NhZ2UgJiYgdXRpbHMuaXNBcnJheShlcnJvci5lcnJvcnMpICYmIGVycm9yLmVycm9ycy5sZW5ndGgpIHtcbiAgICAgIG1lc3NhZ2UgPSBhZ2dyZWdhdGVFcnJvck1lc3NhZ2UoZXJyb3IpO1xuICAgIH1cblxuICAgIGNvbnN0IGF4aW9zRXJyb3IgPSBuZXcgQXhpb3NFcnJvcihtZXNzYWdlLCBjb2RlIHx8IGVycm9yLmNvZGUsIGNvbmZpZywgcmVxdWVzdCwgcmVzcG9uc2UpO1xuICAgIC8vIE1hdGNoIG5hdGl2ZSBgRXJyb3JgIGBjYXVzZWAgc2VtYW50aWNzOiBub24tZW51bWVyYWJsZS4gVGhlIHdyYXBwZWRcbiAgICAvLyBlcnJvciBvZnRlbiBjYXJyaWVzIGNpcmN1bGFyIGludGVybmFscyAoc29ja2V0cywgcmVxdWVzdHMsIGFnZW50cyksIHNvXG4gICAgLy8gYW4gZW51bWVyYWJsZSBgY2F1c2VgIG1ha2VzIHN0cnVjdHVyZWQgbG9nZ2VycyAocGluby93aW5zdG9uKSBhbmQgYW55XG4gICAgLy8gb3duLXByb3BlcnR5IHdhbGsgdGhyb3cgXCJDb252ZXJ0aW5nIGNpcmN1bGFyIHN0cnVjdHVyZSB0byBKU09OXCIuXG4gICAgLy8gUmVncmVzc2lvbiBmcm9tICM2OTgyOyBzZWUgIzcyMDUuIGBfX3Byb3RvX186IG51bGxgIG1pcnJvcnMgdGhlXG4gICAgLy8gYG1lc3NhZ2VgIGRlc2NyaXB0b3IgYmVsb3cgKHByb3RvdHlwZS1wb2xsdXRpb24tc2FmZSBkZXNjcmlwdG9yKS5cbiAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkoYXhpb3NFcnJvciwgJ2NhdXNlJywge1xuICAgICAgX19wcm90b19fOiBudWxsLFxuICAgICAgdmFsdWU6IGVycm9yLFxuICAgICAgd3JpdGFibGU6IHRydWUsXG4gICAgICBlbnVtZXJhYmxlOiBmYWxzZSxcbiAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZSxcbiAgICB9KTtcbiAgICBheGlvc0Vycm9yLm5hbWUgPSBlcnJvci5uYW1lO1xuXG4gICAgLy8gSW5saW5lIHRoZSB3cmFwcGVkIHN0YWNrIGZvciByZXBvcnRlcnMgdGhhdCByZWFkIG9ubHkgYHN0YWNrYDsgdGhlIGBjYXVzZWBcbiAgICAvLyBwcm9wZXJ0eSBhYm92ZSBhbHJlYWR5IGNvdmVycyBjYXVzZS1hd2FyZSB0b29saW5nLlxuICAgIGFwcGVuZENhdXNlU3RhY2soYXhpb3NFcnJvciwgZXJyb3IpO1xuXG4gICAgLy8gUHJlc2VydmUgc3RhdHVzIGZyb20gdGhlIG9yaWdpbmFsIGVycm9yIGlmIG5vdCBhbHJlYWR5IHNldCBmcm9tIHJlc3BvbnNlXG4gICAgaWYgKGVycm9yLnN0YXR1cyAhPSBudWxsICYmIGF4aW9zRXJyb3Iuc3RhdHVzID09IG51bGwpIHtcbiAgICAgIGF4aW9zRXJyb3Iuc3RhdHVzID0gZXJyb3Iuc3RhdHVzO1xuICAgIH1cblxuICAgIGN1c3RvbVByb3BzICYmIE9iamVjdC5hc3NpZ24oYXhpb3NFcnJvciwgY3VzdG9tUHJvcHMpO1xuICAgIHJldHVybiBheGlvc0Vycm9yO1xuICB9XG5cbiAgLyoqXG4gICAqIENyZWF0ZSBhbiBFcnJvciB3aXRoIHRoZSBzcGVjaWZpZWQgbWVzc2FnZSwgY29uZmlnLCBlcnJvciBjb2RlLCByZXF1ZXN0IGFuZCByZXNwb25zZS5cbiAgICpcbiAgICogQHBhcmFtIHtzdHJpbmd9IG1lc3NhZ2UgVGhlIGVycm9yIG1lc3NhZ2UuXG4gICAqIEBwYXJhbSB7c3RyaW5nfSBbY29kZV0gVGhlIGVycm9yIGNvZGUgKGZvciBleGFtcGxlLCAnRUNPTk5BQk9SVEVEJykuXG4gICAqIEBwYXJhbSB7T2JqZWN0fSBbY29uZmlnXSBUaGUgY29uZmlnLlxuICAgKiBAcGFyYW0ge09iamVjdH0gW3JlcXVlc3RdIFRoZSByZXF1ZXN0LlxuICAgKiBAcGFyYW0ge09iamVjdH0gW3Jlc3BvbnNlXSBUaGUgcmVzcG9uc2UuXG4gICAqXG4gICAqIEByZXR1cm5zIHtFcnJvcn0gVGhlIGNyZWF0ZWQgZXJyb3IuXG4gICAqL1xuICBjb25zdHJ1Y3RvcihtZXNzYWdlLCBjb2RlLCBjb25maWcsIHJlcXVlc3QsIHJlc3BvbnNlKSB7XG4gICAgc3VwZXIobWVzc2FnZSk7XG5cbiAgICAvLyBNYWtlIG1lc3NhZ2UgZW51bWVyYWJsZSB0byBtYWludGFpbiBiYWNrd2FyZCBjb21wYXRpYmlsaXR5XG4gICAgLy8gVGhlIG5hdGl2ZSBFcnJvciBjb25zdHJ1Y3RvciBzZXRzIG1lc3NhZ2UgYXMgbm9uLWVudW1lcmFibGUsXG4gICAgLy8gYnV0IGF4aW9zIDwgdjEuMTMuMyBoYWQgaXQgYXMgZW51bWVyYWJsZVxuICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eSh0aGlzLCAnbWVzc2FnZScsIHtcbiAgICAgIC8vIE51bGwtcHJvdG8gZGVzY3JpcHRvciBzbyBhIHBvbGx1dGVkIE9iamVjdC5wcm90b3R5cGUuZ2V0IGNhbm5vdCB0dXJuXG4gICAgICAvLyB0aGlzIGRhdGEgZGVzY3JpcHRvciBpbnRvIGFuIGFjY2Vzc29yIGRlc2NyaXB0b3Igb24gdGhlIHdheSBpbi5cbiAgICAgIF9fcHJvdG9fXzogbnVsbCxcbiAgICAgIHZhbHVlOiBtZXNzYWdlLFxuICAgICAgZW51bWVyYWJsZTogdHJ1ZSxcbiAgICAgIHdyaXRhYmxlOiB0cnVlLFxuICAgICAgY29uZmlndXJhYmxlOiB0cnVlLFxuICAgIH0pO1xuXG4gICAgdGhpcy5uYW1lID0gJ0F4aW9zRXJyb3InO1xuICAgIHRoaXMuaXNBeGlvc0Vycm9yID0gdHJ1ZTtcbiAgICBjb2RlICYmICh0aGlzLmNvZGUgPSBjb2RlKTtcbiAgICBjb25maWcgJiYgKHRoaXMuY29uZmlnID0gY29uZmlnKTtcbiAgICByZXF1ZXN0ICYmICh0aGlzLnJlcXVlc3QgPSByZXF1ZXN0KTtcbiAgICBpZiAocmVzcG9uc2UpIHtcbiAgICAgIHRoaXMucmVzcG9uc2UgPSByZXNwb25zZTtcbiAgICAgIHRoaXMuc3RhdHVzID0gcmVzcG9uc2Uuc3RhdHVzO1xuICAgIH1cbiAgfVxuXG4gIHRvSlNPTigpIHtcbiAgICAvLyBPcHQtaW4gcmVkYWN0aW9uOiB3aGVuIHRoZSByZXF1ZXN0IGNvbmZpZyBjYXJyaWVzIGEgYHJlZGFjdGAgYXJyYXksIHRoZVxuICAgIC8vIHZhbHVlIG9mIGFueSBtYXRjaGluZyBrZXkgKGNhc2UtaW5zZW5zaXRpdmUsIGF0IGFueSBkZXB0aCkgaXMgcmVwbGFjZWRcbiAgICAvLyB3aXRoIFJFREFDVEVEIGluIHRoZSBzZXJpYWxpemVkIHNuYXBzaG90LiBVbmRlZmluZWQgb3IgZW1wdHkgbGVhdmVzIHRoZVxuICAgIC8vIGV4aXN0aW5nIHNlcmlhbGl6YXRpb24gYmVoYXZpb3IgdW5jaGFuZ2VkLlxuICAgIGNvbnN0IGNvbmZpZyA9IHRoaXMuY29uZmlnO1xuICAgIGNvbnN0IHJlZGFjdEtleXMgPSBjb25maWcgJiYgdXRpbHMuaGFzT3duUHJvcChjb25maWcsICdyZWRhY3QnKSA/IGNvbmZpZy5yZWRhY3QgOiB1bmRlZmluZWQ7XG4gICAgY29uc3Qgc2VyaWFsaXplZENvbmZpZyA9XG4gICAgICB1dGlscy5pc0FycmF5KHJlZGFjdEtleXMpICYmIHJlZGFjdEtleXMubGVuZ3RoID4gMFxuICAgICAgICA/IHJlZGFjdENvbmZpZyhjb25maWcsIHJlZGFjdEtleXMpXG4gICAgICAgIDogdXRpbHMudG9KU09OT2JqZWN0KGNvbmZpZyk7XG5cbiAgICByZXR1cm4ge1xuICAgICAgLy8gU3RhbmRhcmRcbiAgICAgIG1lc3NhZ2U6IHRoaXMubWVzc2FnZSxcbiAgICAgIG5hbWU6IHRoaXMubmFtZSxcbiAgICAgIC8vIE1pY3Jvc29mdFxuICAgICAgZGVzY3JpcHRpb246IHRoaXMuZGVzY3JpcHRpb24sXG4gICAgICBudW1iZXI6IHRoaXMubnVtYmVyLFxuICAgICAgLy8gTW96aWxsYVxuICAgICAgZmlsZU5hbWU6IHRoaXMuZmlsZU5hbWUsXG4gICAgICBsaW5lTnVtYmVyOiB0aGlzLmxpbmVOdW1iZXIsXG4gICAgICBjb2x1bW5OdW1iZXI6IHRoaXMuY29sdW1uTnVtYmVyLFxuICAgICAgc3RhY2s6IHRoaXMuc3RhY2ssXG4gICAgICAvLyBBeGlvc1xuICAgICAgY29uZmlnOiBzZXJpYWxpemVkQ29uZmlnLFxuICAgICAgY29kZTogdGhpcy5jb2RlLFxuICAgICAgc3RhdHVzOiB0aGlzLnN0YXR1cyxcbiAgICB9O1xuICB9XG59XG5cbi8vIFRoaXMgY2FuIGJlIGNoYW5nZWQgdG8gc3RhdGljIHByb3BlcnRpZXMgYXMgc29vbiBhcyB0aGUgcGFyc2VyIG9wdGlvbnMgaW4gLmVzbGludC5janMgYXJlIHVwZGF0ZWQuXG5BeGlvc0Vycm9yLkVSUl9CQURfT1BUSU9OX1ZBTFVFID0gJ0VSUl9CQURfT1BUSU9OX1ZBTFVFJztcbkF4aW9zRXJyb3IuRVJSX0JBRF9PUFRJT04gPSAnRVJSX0JBRF9PUFRJT04nO1xuQXhpb3NFcnJvci5FQ09OTkFCT1JURUQgPSAnRUNPTk5BQk9SVEVEJztcbkF4aW9zRXJyb3IuRVRJTUVET1VUID0gJ0VUSU1FRE9VVCc7XG5BeGlvc0Vycm9yLkVDT05OUkVGVVNFRCA9ICdFQ09OTlJFRlVTRUQnO1xuQXhpb3NFcnJvci5FUlJfTkVUV09SSyA9ICdFUlJfTkVUV09SSyc7XG5BeGlvc0Vycm9yLkVSUl9GUl9UT09fTUFOWV9SRURJUkVDVFMgPSAnRVJSX0ZSX1RPT19NQU5ZX1JFRElSRUNUUyc7XG5BeGlvc0Vycm9yLkVSUl9ERVBSRUNBVEVEID0gJ0VSUl9ERVBSRUNBVEVEJztcbkF4aW9zRXJyb3IuRVJSX0JBRF9SRVNQT05TRSA9ICdFUlJfQkFEX1JFU1BPTlNFJztcbkF4aW9zRXJyb3IuRVJSX0JBRF9SRVFVRVNUID0gJ0VSUl9CQURfUkVRVUVTVCc7XG5BeGlvc0Vycm9yLkVSUl9DQU5DRUxFRCA9ICdFUlJfQ0FOQ0VMRUQnO1xuQXhpb3NFcnJvci5FUlJfTk9UX1NVUFBPUlQgPSAnRVJSX05PVF9TVVBQT1JUJztcbkF4aW9zRXJyb3IuRVJSX0lOVkFMSURfVVJMID0gJ0VSUl9JTlZBTElEX1VSTCc7XG5BeGlvc0Vycm9yLkVSUl9GT1JNX0RBVEFfREVQVEhfRVhDRUVERUQgPSAnRVJSX0ZPUk1fREFUQV9ERVBUSF9FWENFRURFRCc7XG5cbmV4cG9ydCBkZWZhdWx0IEF4aW9zRXJyb3I7XG4iLCIndXNlIHN0cmljdCc7XG5cbmltcG9ydCB1dGlscyBmcm9tICcuLi91dGlscy5qcyc7XG5pbXBvcnQgQXhpb3NFcnJvciBmcm9tICcuLi9jb3JlL0F4aW9zRXJyb3IuanMnO1xuLy8gdGVtcG9yYXJ5IGhvdGZpeCB0byBhdm9pZCBjaXJjdWxhciByZWZlcmVuY2VzIHVudGlsIEF4aW9zVVJMU2VhcmNoUGFyYW1zIGlzIHJlZmFjdG9yZWRcbmltcG9ydCBQbGF0Zm9ybUZvcm1EYXRhIGZyb20gJy4uL3BsYXRmb3JtL25vZGUvY2xhc3Nlcy9Gb3JtRGF0YS5qcyc7XG5pbXBvcnQgUGxhdGZvcm1CdWZmZXIgZnJvbSAnLi4vcGxhdGZvcm0vbm9kZS9jbGFzc2VzL0J1ZmZlci5qcyc7XG5cbi8vIERlZmF1bHQgbmVzdGluZyBsaW1pdCBzaGFyZWQgd2l0aCB0aGUgaW52ZXJzZSB0cmFuc2Zvcm0gKGZvcm1EYXRhVG9KU09OKSBzb1xuLy8gdGhlIEZvcm1EYXRhIDwtPiBKU09OIHJvdW5kLXRyaXAgc3RheXMgc3ltbWV0cmljLlxuZXhwb3J0IGNvbnN0IERFRkFVTFRfRk9STV9EQVRBX01BWF9ERVBUSCA9IDEwMDtcblxuLyoqXG4gKiBEZXRlcm1pbmVzIGlmIHRoZSBnaXZlbiB0aGluZyBpcyBhIGFycmF5IG9yIGpzIG9iamVjdC5cbiAqXG4gKiBAcGFyYW0ge3N0cmluZ30gdGhpbmcgLSBUaGUgb2JqZWN0IG9yIGFycmF5IHRvIGJlIHZpc2l0ZWQuXG4gKlxuICogQHJldHVybnMge2Jvb2xlYW59XG4gKi9cbmZ1bmN0aW9uIGlzVmlzaXRhYmxlKHRoaW5nKSB7XG4gIHJldHVybiB1dGlscy5pc1BsYWluT2JqZWN0KHRoaW5nKSB8fCB1dGlscy5pc0FycmF5KHRoaW5nKTtcbn1cblxuLyoqXG4gKiBJdCByZW1vdmVzIHRoZSBicmFja2V0cyBmcm9tIHRoZSBlbmQgb2YgYSBzdHJpbmdcbiAqXG4gKiBAcGFyYW0ge3N0cmluZ30ga2V5IC0gVGhlIGtleSBvZiB0aGUgcGFyYW1ldGVyLlxuICpcbiAqIEByZXR1cm5zIHtzdHJpbmd9IHRoZSBrZXkgd2l0aG91dCB0aGUgYnJhY2tldHMuXG4gKi9cbmZ1bmN0aW9uIHJlbW92ZUJyYWNrZXRzKGtleSkge1xuICByZXR1cm4gdXRpbHMuZW5kc1dpdGgoa2V5LCAnW10nKSA/IGtleS5zbGljZSgwLCAtMikgOiBrZXk7XG59XG5cbi8qKlxuICogSXQgdGFrZXMgYSBwYXRoLCBhIGtleSwgYW5kIGEgYm9vbGVhbiwgYW5kIHJldHVybnMgYSBzdHJpbmdcbiAqXG4gKiBAcGFyYW0ge3N0cmluZ30gcGF0aCAtIFRoZSBwYXRoIHRvIHRoZSBjdXJyZW50IGtleS5cbiAqIEBwYXJhbSB7c3RyaW5nfSBrZXkgLSBUaGUga2V5IG9mIHRoZSBjdXJyZW50IG9iamVjdCBiZWluZyBpdGVyYXRlZCBvdmVyLlxuICogQHBhcmFtIHtzdHJpbmd9IGRvdHMgLSBJZiB0cnVlLCB0aGUga2V5IHdpbGwgYmUgcmVuZGVyZWQgd2l0aCBkb3RzIGluc3RlYWQgb2YgYnJhY2tldHMuXG4gKlxuICogQHJldHVybnMge3N0cmluZ30gVGhlIHBhdGggdG8gdGhlIGN1cnJlbnQga2V5LlxuICovXG5mdW5jdGlvbiByZW5kZXJLZXkocGF0aCwga2V5LCBkb3RzKSB7XG4gIGlmICghcGF0aCkgcmV0dXJuIGtleTtcbiAgcmV0dXJuIHBhdGhcbiAgICAuY29uY2F0KGtleSlcbiAgICAubWFwKGZ1bmN0aW9uIGVhY2godG9rZW4sIGkpIHtcbiAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBuby1wYXJhbS1yZWFzc2lnblxuICAgICAgdG9rZW4gPSByZW1vdmVCcmFja2V0cyh0b2tlbik7XG4gICAgICByZXR1cm4gIWRvdHMgJiYgaSA/ICdbJyArIHRva2VuICsgJ10nIDogdG9rZW47XG4gICAgfSlcbiAgICAuam9pbihkb3RzID8gJy4nIDogJycpO1xufVxuXG4vKipcbiAqIElmIHRoZSBhcnJheSBpcyBhbiBhcnJheSBhbmQgbm9uZSBvZiBpdHMgZWxlbWVudHMgYXJlIHZpc2l0YWJsZSwgdGhlbiBpdCdzIGEgZmxhdCBhcnJheS5cbiAqXG4gKiBAcGFyYW0ge0FycmF5PGFueT59IGFyciAtIFRoZSBhcnJheSB0byBjaGVja1xuICpcbiAqIEByZXR1cm5zIHtib29sZWFufVxuICovXG5mdW5jdGlvbiBpc0ZsYXRBcnJheShhcnIpIHtcbiAgcmV0dXJuIHV0aWxzLmlzQXJyYXkoYXJyKSAmJiAhYXJyLnNvbWUoaXNWaXNpdGFibGUpO1xufVxuXG5jb25zdCBwcmVkaWNhdGVzID0gdXRpbHMudG9GbGF0T2JqZWN0KHV0aWxzLCB7fSwgbnVsbCwgZnVuY3Rpb24gZmlsdGVyKHByb3ApIHtcbiAgcmV0dXJuIC9eaXNbQS1aXS8udGVzdChwcm9wKTtcbn0pO1xuXG4vKipcbiAqIENvbnZlcnQgYSBkYXRhIG9iamVjdCB0byBGb3JtRGF0YVxuICpcbiAqIEBwYXJhbSB7T2JqZWN0fSBvYmpcbiAqIEBwYXJhbSB7P09iamVjdH0gW2Zvcm1EYXRhXVxuICogQHBhcmFtIHs/T2JqZWN0fSBbb3B0aW9uc11cbiAqIEBwYXJhbSB7RnVuY3Rpb259IFtvcHRpb25zLnZpc2l0b3JdXG4gKiBAcGFyYW0ge0Jvb2xlYW59IFtvcHRpb25zLm1ldGFUb2tlbnMgPSB0cnVlXVxuICogQHBhcmFtIHtCb29sZWFufSBbb3B0aW9ucy5kb3RzID0gZmFsc2VdXG4gKiBAcGFyYW0gez9Cb29sZWFufSBbb3B0aW9ucy5pbmRleGVzID0gZmFsc2VdXG4gKlxuICogQHJldHVybnMge09iamVjdH1cbiAqKi9cblxuLyoqXG4gKiBJdCBjb252ZXJ0cyBhbiBvYmplY3QgaW50byBhIEZvcm1EYXRhIG9iamVjdFxuICpcbiAqIEBwYXJhbSB7T2JqZWN0PGFueSwgYW55Pn0gb2JqIC0gVGhlIG9iamVjdCB0byBjb252ZXJ0IHRvIGZvcm0gZGF0YS5cbiAqIEBwYXJhbSB7c3RyaW5nfSBmb3JtRGF0YSAtIFRoZSBGb3JtRGF0YSBvYmplY3QgdG8gYXBwZW5kIHRvLlxuICogQHBhcmFtIHtPYmplY3Q8c3RyaW5nLCBhbnk+fSBvcHRpb25zXG4gKlxuICogQHJldHVybnNcbiAqL1xuZnVuY3Rpb24gdG9Gb3JtRGF0YShvYmosIGZvcm1EYXRhLCBvcHRpb25zKSB7XG4gIGlmICghdXRpbHMuaXNPYmplY3Qob2JqKSkge1xuICAgIHRocm93IG5ldyBUeXBlRXJyb3IoJ3RhcmdldCBtdXN0IGJlIGFuIG9iamVjdCcpO1xuICB9XG5cbiAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIG5vLXBhcmFtLXJlYXNzaWduXG4gIGZvcm1EYXRhID0gZm9ybURhdGEgfHwgbmV3IChQbGF0Zm9ybUZvcm1EYXRhIHx8IEZvcm1EYXRhKSgpO1xuXG4gIGNvbnN0IG9wdGlvbiA9IChuYW1lLCBmYWxsYmFjaykgPT4ge1xuICAgIGNvbnN0IHZhbHVlID0gdXRpbHMuZ2V0U2FmZVByb3Aob3B0aW9ucywgbmFtZSk7XG4gICAgcmV0dXJuIHV0aWxzLmlzVW5kZWZpbmVkKHZhbHVlKSA/IGZhbGxiYWNrIDogdmFsdWU7XG4gIH07XG5cbiAgY29uc3QgbWV0YVRva2VucyA9IG9wdGlvbignbWV0YVRva2VucycsIHRydWUpO1xuICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgbm8tdXNlLWJlZm9yZS1kZWZpbmVcbiAgY29uc3QgdmlzaXRvciA9IG9wdGlvbigndmlzaXRvcicpIHx8IGRlZmF1bHRWaXNpdG9yO1xuICBjb25zdCBkb3RzID0gb3B0aW9uKCdkb3RzJywgZmFsc2UpO1xuICBjb25zdCBpbmRleGVzID0gb3B0aW9uKCdpbmRleGVzJywgZmFsc2UpO1xuICBjb25zdCBfQmxvYiA9IG9wdGlvbignQmxvYicpIHx8ICh0eXBlb2YgQmxvYiAhPT0gJ3VuZGVmaW5lZCcgJiYgQmxvYik7XG4gIGNvbnN0IG1heERlcHRoID0gb3B0aW9uKCdtYXhEZXB0aCcsIERFRkFVTFRfRk9STV9EQVRBX01BWF9ERVBUSCk7XG4gIGNvbnN0IHVzZUJsb2IgPSBfQmxvYiAmJiB1dGlscy5pc1NwZWNDb21wbGlhbnRGb3JtKGZvcm1EYXRhKTtcbiAgY29uc3Qgc3RhY2sgPSBbXTtcblxuICBpZiAoIXV0aWxzLmlzRnVuY3Rpb24odmlzaXRvcikpIHtcbiAgICB0aHJvdyBuZXcgVHlwZUVycm9yKCd2aXNpdG9yIG11c3QgYmUgYSBmdW5jdGlvbicpO1xuICB9XG5cbiAgZnVuY3Rpb24gY29udmVydFZhbHVlKHZhbHVlKSB7XG4gICAgaWYgKHZhbHVlID09PSBudWxsKSByZXR1cm4gJyc7XG5cbiAgICBpZiAodXRpbHMuaXNEYXRlKHZhbHVlKSkge1xuICAgICAgcmV0dXJuIHZhbHVlLnRvSVNPU3RyaW5nKCk7XG4gICAgfVxuXG4gICAgaWYgKHV0aWxzLmlzQm9vbGVhbih2YWx1ZSkpIHtcbiAgICAgIHJldHVybiB2YWx1ZS50b1N0cmluZygpO1xuICAgIH1cblxuICAgIGlmICghdXNlQmxvYiAmJiB1dGlscy5pc0Jsb2IodmFsdWUpKSB7XG4gICAgICB0aHJvdyBuZXcgQXhpb3NFcnJvcignQmxvYiBpcyBub3Qgc3VwcG9ydGVkLiBVc2UgYSBCdWZmZXIgaW5zdGVhZC4nKTtcbiAgICB9XG5cbiAgICBpZiAodXRpbHMuaXNBcnJheUJ1ZmZlcih2YWx1ZSkgfHwgdXRpbHMuaXNUeXBlZEFycmF5KHZhbHVlKSkge1xuICAgICAgaWYgKHVzZUJsb2IgJiYgdHlwZW9mIF9CbG9iID09PSAnZnVuY3Rpb24nKSB7XG4gICAgICAgIHJldHVybiBuZXcgX0Jsb2IoW3ZhbHVlXSk7XG4gICAgICB9XG4gICAgICBpZiAoUGxhdGZvcm1CdWZmZXIgJiYgUGxhdGZvcm1CdWZmZXIuaXNCdWZmZXJBdmFpbGFibGUoKSkge1xuICAgICAgICByZXR1cm4gUGxhdGZvcm1CdWZmZXIuZnJvbSh2YWx1ZSk7XG4gICAgICB9XG4gICAgICB0aHJvdyBuZXcgQXhpb3NFcnJvcihcbiAgICAgICAgJ0Jsb2IgaXMgbm90IHN1cHBvcnRlZC4gVXNlIGEgQnVmZmVyIGluc3RlYWQuJyxcbiAgICAgICAgQXhpb3NFcnJvci5FUlJfTk9UX1NVUFBPUlRcbiAgICAgICk7XG4gICAgfVxuXG4gICAgcmV0dXJuIHZhbHVlO1xuICB9XG5cbiAgZnVuY3Rpb24gdGhyb3dJZk1heERlcHRoRXhjZWVkZWQoZGVwdGgpIHtcbiAgICBpZiAoZGVwdGggPiBtYXhEZXB0aCkge1xuICAgICAgdGhyb3cgbmV3IEF4aW9zRXJyb3IoXG4gICAgICAgICdPYmplY3QgaXMgdG9vIGRlZXBseSBuZXN0ZWQgKCcgKyBkZXB0aCArICcgbGV2ZWxzKS4gTWF4IGRlcHRoOiAnICsgbWF4RGVwdGgsXG4gICAgICAgIEF4aW9zRXJyb3IuRVJSX0ZPUk1fREFUQV9ERVBUSF9FWENFRURFRFxuICAgICAgKTtcbiAgICB9XG4gIH1cblxuICBmdW5jdGlvbiBzdHJpbmdpZnlXaXRoRGVwdGhMaW1pdCh2YWx1ZSwgZGVwdGgpIHtcbiAgICBpZiAobWF4RGVwdGggPT09IEluZmluaXR5KSB7XG4gICAgICByZXR1cm4gSlNPTi5zdHJpbmdpZnkodmFsdWUpO1xuICAgIH1cblxuICAgIGNvbnN0IGFuY2VzdG9ycyA9IFtdO1xuXG4gICAgcmV0dXJuIEpTT04uc3RyaW5naWZ5KHZhbHVlLCBmdW5jdGlvbiBsaW1pdERlcHRoKF9rZXksIGN1cnJlbnRWYWx1ZSkge1xuICAgICAgaWYgKCF1dGlscy5pc09iamVjdChjdXJyZW50VmFsdWUpKSB7XG4gICAgICAgIHJldHVybiBjdXJyZW50VmFsdWU7XG4gICAgICB9XG5cbiAgICAgIHdoaWxlIChhbmNlc3RvcnMubGVuZ3RoICYmIGFuY2VzdG9yc1thbmNlc3RvcnMubGVuZ3RoIC0gMV0gIT09IHRoaXMpIHtcbiAgICAgICAgYW5jZXN0b3JzLnBvcCgpO1xuICAgICAgfVxuXG4gICAgICBhbmNlc3RvcnMucHVzaChjdXJyZW50VmFsdWUpO1xuICAgICAgdGhyb3dJZk1heERlcHRoRXhjZWVkZWQoZGVwdGggKyBhbmNlc3RvcnMubGVuZ3RoIC0gMSk7XG5cbiAgICAgIHJldHVybiBjdXJyZW50VmFsdWU7XG4gICAgfSk7XG4gIH1cblxuICAvKipcbiAgICogRGVmYXVsdCB2aXNpdG9yLlxuICAgKlxuICAgKiBAcGFyYW0geyp9IHZhbHVlXG4gICAqIEBwYXJhbSB7U3RyaW5nfE51bWJlcn0ga2V5XG4gICAqIEBwYXJhbSB7QXJyYXk8U3RyaW5nfE51bWJlcj59IHBhdGhcbiAgICogQHRoaXMge0Zvcm1EYXRhfVxuICAgKlxuICAgKiBAcmV0dXJucyB7Ym9vbGVhbn0gcmV0dXJuIHRydWUgdG8gdmlzaXQgdGhlIGVhY2ggcHJvcCBvZiB0aGUgdmFsdWUgcmVjdXJzaXZlbHlcbiAgICovXG4gIGZ1bmN0aW9uIGRlZmF1bHRWaXNpdG9yKHZhbHVlLCBrZXksIHBhdGgpIHtcbiAgICBsZXQgYXJyID0gdmFsdWU7XG5cbiAgICBpZiAodXRpbHMuaXNSZWFjdE5hdGl2ZShmb3JtRGF0YSkgJiYgdXRpbHMuaXNSZWFjdE5hdGl2ZUJsb2IodmFsdWUpKSB7XG4gICAgICBmb3JtRGF0YS5hcHBlbmQocmVuZGVyS2V5KHBhdGgsIGtleSwgZG90cyksIGNvbnZlcnRWYWx1ZSh2YWx1ZSkpO1xuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cblxuICAgIGlmICh2YWx1ZSAmJiAhcGF0aCAmJiB0eXBlb2YgdmFsdWUgPT09ICdvYmplY3QnKSB7XG4gICAgICBpZiAodXRpbHMuZW5kc1dpdGgoa2V5LCAne30nKSkge1xuICAgICAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgbm8tcGFyYW0tcmVhc3NpZ25cbiAgICAgICAga2V5ID0gbWV0YVRva2VucyA/IGtleSA6IGtleS5zbGljZSgwLCAtMik7XG4gICAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBuby1wYXJhbS1yZWFzc2lnblxuICAgICAgICB2YWx1ZSA9IHN0cmluZ2lmeVdpdGhEZXB0aExpbWl0KHZhbHVlLCAxKTtcbiAgICAgIH0gZWxzZSBpZiAoXG4gICAgICAgICh1dGlscy5pc0FycmF5KHZhbHVlKSAmJiBpc0ZsYXRBcnJheSh2YWx1ZSkpIHx8XG4gICAgICAgICgodXRpbHMuaXNGaWxlTGlzdCh2YWx1ZSkgfHwgdXRpbHMuZW5kc1dpdGgoa2V5LCAnW10nKSkgJiYgKGFyciA9IHV0aWxzLnRvQXJyYXkodmFsdWUpKSlcbiAgICAgICkge1xuICAgICAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgbm8tcGFyYW0tcmVhc3NpZ25cbiAgICAgICAga2V5ID0gcmVtb3ZlQnJhY2tldHMoa2V5KTtcblxuICAgICAgICBhcnIuZm9yRWFjaChmdW5jdGlvbiBlYWNoKGVsLCBpbmRleCkge1xuICAgICAgICAgICEodXRpbHMuaXNVbmRlZmluZWQoZWwpIHx8IGVsID09PSBudWxsKSAmJlxuICAgICAgICAgICAgZm9ybURhdGEuYXBwZW5kKFxuICAgICAgICAgICAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgbm8tbmVzdGVkLXRlcm5hcnlcbiAgICAgICAgICAgICAgaW5kZXhlcyA9PT0gdHJ1ZVxuICAgICAgICAgICAgICAgID8gcmVuZGVyS2V5KFtrZXldLCBpbmRleCwgZG90cylcbiAgICAgICAgICAgICAgICA6IGluZGV4ZXMgPT09IG51bGxcbiAgICAgICAgICAgICAgICAgID8ga2V5XG4gICAgICAgICAgICAgICAgICA6IGtleSArICdbXScsXG4gICAgICAgICAgICAgIGNvbnZlcnRWYWx1ZShlbClcbiAgICAgICAgICAgICk7XG4gICAgICAgIH0pO1xuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICB9XG4gICAgfVxuXG4gICAgaWYgKGlzVmlzaXRhYmxlKHZhbHVlKSkge1xuICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxuXG4gICAgZm9ybURhdGEuYXBwZW5kKHJlbmRlcktleShwYXRoLCBrZXksIGRvdHMpLCBjb252ZXJ0VmFsdWUodmFsdWUpKTtcblxuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuXG4gIGNvbnN0IGV4cG9zZWRIZWxwZXJzID0gT2JqZWN0LmFzc2lnbihwcmVkaWNhdGVzLCB7XG4gICAgZGVmYXVsdFZpc2l0b3IsXG4gICAgY29udmVydFZhbHVlLFxuICAgIGlzVmlzaXRhYmxlLFxuICB9KTtcblxuICBmdW5jdGlvbiBidWlsZCh2YWx1ZSwgcGF0aCwgZGVwdGggPSAwKSB7XG4gICAgaWYgKHV0aWxzLmlzVW5kZWZpbmVkKHZhbHVlKSkgcmV0dXJuO1xuXG4gICAgdGhyb3dJZk1heERlcHRoRXhjZWVkZWQoZGVwdGgpO1xuXG4gICAgaWYgKHN0YWNrLmluZGV4T2YodmFsdWUpICE9PSAtMSkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKCdDaXJjdWxhciByZWZlcmVuY2UgZGV0ZWN0ZWQgaW4gJyArIHBhdGguam9pbignLicpKTtcbiAgICB9XG5cbiAgICBzdGFjay5wdXNoKHZhbHVlKTtcblxuICAgIHV0aWxzLmZvckVhY2godmFsdWUsIGZ1bmN0aW9uIGVhY2goZWwsIGtleSkge1xuICAgICAgY29uc3QgcmVzdWx0ID1cbiAgICAgICAgISh1dGlscy5pc1VuZGVmaW5lZChlbCkgfHwgZWwgPT09IG51bGwpICYmXG4gICAgICAgIHZpc2l0b3IuY2FsbChmb3JtRGF0YSwgZWwsIHV0aWxzLmlzU3RyaW5nKGtleSkgPyBrZXkudHJpbSgpIDoga2V5LCBwYXRoLCBleHBvc2VkSGVscGVycyk7XG5cbiAgICAgIGlmIChyZXN1bHQgPT09IHRydWUpIHtcbiAgICAgICAgYnVpbGQoZWwsIHBhdGggPyBwYXRoLmNvbmNhdChrZXkpIDogW2tleV0sIGRlcHRoICsgMSk7XG4gICAgICB9XG4gICAgfSk7XG5cbiAgICBzdGFjay5wb3AoKTtcbiAgfVxuXG4gIGlmICghdXRpbHMuaXNPYmplY3Qob2JqKSkge1xuICAgIHRocm93IG5ldyBUeXBlRXJyb3IoJ2RhdGEgbXVzdCBiZSBhbiBvYmplY3QnKTtcbiAgfVxuXG4gIGJ1aWxkKG9iaik7XG5cbiAgcmV0dXJuIGZvcm1EYXRhO1xufVxuXG5leHBvcnQgZGVmYXVsdCB0b0Zvcm1EYXRhO1xuIiwiJ3VzZSBzdHJpY3QnO1xuXG5pbXBvcnQgdG9Gb3JtRGF0YSBmcm9tICcuL3RvRm9ybURhdGEuanMnO1xuXG4vKipcbiAqIEl0IGVuY29kZXMgYSBzdHJpbmcgYnkgcmVwbGFjaW5nIGFsbCBjaGFyYWN0ZXJzIHRoYXQgYXJlIG5vdCBpbiB0aGUgdW5yZXNlcnZlZCBzZXQgd2l0aFxuICogdGhlaXIgcGVyY2VudC1lbmNvZGVkIGVxdWl2YWxlbnRzXG4gKlxuICogQHBhcmFtIHtzdHJpbmd9IHN0ciAtIFRoZSBzdHJpbmcgdG8gZW5jb2RlLlxuICpcbiAqIEByZXR1cm5zIHtzdHJpbmd9IFRoZSBlbmNvZGVkIHN0cmluZy5cbiAqL1xuZnVuY3Rpb24gZW5jb2RlKHN0cikge1xuICBjb25zdCBjaGFyTWFwID0ge1xuICAgICchJzogJyUyMScsXG4gICAgXCInXCI6ICclMjcnLFxuICAgICcoJzogJyUyOCcsXG4gICAgJyknOiAnJTI5JyxcbiAgICAnfic6ICclN0UnLFxuICAgICclMjAnOiAnKycsXG4gIH07XG4gIHJldHVybiBlbmNvZGVVUklDb21wb25lbnQoc3RyKS5yZXBsYWNlKC9bIScoKX5dfCUyMC9nLCBmdW5jdGlvbiByZXBsYWNlcihtYXRjaCkge1xuICAgIHJldHVybiBjaGFyTWFwW21hdGNoXTtcbiAgfSk7XG59XG5cbi8qKlxuICogSXQgdGFrZXMgYSBwYXJhbXMgb2JqZWN0IGFuZCBjb252ZXJ0cyBpdCB0byBhIEZvcm1EYXRhIG9iamVjdFxuICpcbiAqIEBwYXJhbSB7T2JqZWN0PHN0cmluZywgYW55Pn0gcGFyYW1zIC0gVGhlIHBhcmFtZXRlcnMgdG8gYmUgY29udmVydGVkIHRvIGEgRm9ybURhdGEgb2JqZWN0LlxuICogQHBhcmFtIHtPYmplY3Q8c3RyaW5nLCBhbnk+fSBvcHRpb25zIC0gVGhlIG9wdGlvbnMgb2JqZWN0IHBhc3NlZCB0byB0aGUgQXhpb3MgY29uc3RydWN0b3IuXG4gKlxuICogQHJldHVybnMge3ZvaWR9XG4gKi9cbmZ1bmN0aW9uIEF4aW9zVVJMU2VhcmNoUGFyYW1zKHBhcmFtcywgb3B0aW9ucykge1xuICB0aGlzLl9wYWlycyA9IFtdO1xuXG4gIHBhcmFtcyAmJiB0b0Zvcm1EYXRhKHBhcmFtcywgdGhpcywgb3B0aW9ucyk7XG59XG5cbmNvbnN0IHByb3RvdHlwZSA9IEF4aW9zVVJMU2VhcmNoUGFyYW1zLnByb3RvdHlwZTtcblxucHJvdG90eXBlLmFwcGVuZCA9IGZ1bmN0aW9uIGFwcGVuZChuYW1lLCB2YWx1ZSkge1xuICB0aGlzLl9wYWlycy5wdXNoKFtuYW1lLCB2YWx1ZV0pO1xufTtcblxucHJvdG90eXBlLnRvU3RyaW5nID0gZnVuY3Rpb24gdG9TdHJpbmcoZW5jb2Rlcikge1xuICBjb25zdCBfZW5jb2RlID0gZW5jb2RlclxuICAgID8gKHZhbHVlKSA9PiBlbmNvZGVyLmNhbGwodGhpcywgdmFsdWUsIGVuY29kZSlcbiAgICA6IGVuY29kZTtcblxuICByZXR1cm4gdGhpcy5fcGFpcnNcbiAgICAubWFwKGZ1bmN0aW9uIGVhY2gocGFpcikge1xuICAgICAgcmV0dXJuIF9lbmNvZGUocGFpclswXSkgKyAnPScgKyBfZW5jb2RlKHBhaXJbMV0pO1xuICAgIH0sICcnKVxuICAgIC5qb2luKCcmJyk7XG59O1xuXG5leHBvcnQgZGVmYXVsdCBBeGlvc1VSTFNlYXJjaFBhcmFtcztcbiIsIid1c2Ugc3RyaWN0JztcblxuaW1wb3J0IHV0aWxzIGZyb20gJy4uL3V0aWxzLmpzJztcbmltcG9ydCBBeGlvc1VSTFNlYXJjaFBhcmFtcyBmcm9tICcuL0F4aW9zVVJMU2VhcmNoUGFyYW1zLmpzJztcblxuLyoqXG4gKiBJdCByZXBsYWNlcyBVUkwtZW5jb2RlZCBmb3JtcyBvZiBgOmAsIGAkYCwgYCxgLCBhbmQgc3BhY2VzIHdpdGhcbiAqIHRoZWlyIHBsYWluIGNvdW50ZXJwYXJ0cyAoYDpgLCBgJGAsIGAsYCwgYCtgKS5cbiAqXG4gKiBAcGFyYW0ge3N0cmluZ30gdmFsIFRoZSB2YWx1ZSB0byBiZSBlbmNvZGVkLlxuICpcbiAqIEByZXR1cm5zIHtzdHJpbmd9IFRoZSBlbmNvZGVkIHZhbHVlLlxuICovXG5leHBvcnQgZnVuY3Rpb24gZW5jb2RlKHZhbCkge1xuICByZXR1cm4gZW5jb2RlVVJJQ29tcG9uZW50KHZhbClcbiAgICAucmVwbGFjZSgvJTNBL2dpLCAnOicpXG4gICAgLnJlcGxhY2UoLyUyNC9nLCAnJCcpXG4gICAgLnJlcGxhY2UoLyUyQy9naSwgJywnKVxuICAgIC5yZXBsYWNlKC8lMjAvZywgJysnKTtcbn1cblxuLyoqXG4gKiBCdWlsZCBhIFVSTCBieSBhcHBlbmRpbmcgcGFyYW1zIHRvIHRoZSBlbmRcbiAqXG4gKiBAcGFyYW0ge3N0cmluZ30gdXJsIFRoZSBiYXNlIG9mIHRoZSB1cmwgKGUuZy4sIGh0dHA6Ly93d3cuZ29vZ2xlLmNvbSlcbiAqIEBwYXJhbSB7b2JqZWN0fSBbcGFyYW1zXSBUaGUgcGFyYW1zIHRvIGJlIGFwcGVuZGVkXG4gKiBAcGFyYW0gez8ob2JqZWN0fEZ1bmN0aW9uKX0gb3B0aW9uc1xuICpcbiAqIEByZXR1cm5zIHtzdHJpbmd9IFRoZSBmb3JtYXR0ZWQgdXJsXG4gKi9cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIGJ1aWxkVVJMKHVybCwgcGFyYW1zLCBvcHRpb25zKSB7XG4gIGlmICghcGFyYW1zKSB7XG4gICAgcmV0dXJuIHVybDtcbiAgfVxuICB1cmwgPSB1cmwgfHwgJyc7XG5cbiAgY29uc3QgX29wdGlvbnMgPSB1dGlscy5pc0Z1bmN0aW9uKG9wdGlvbnMpXG4gICAgPyB7XG4gICAgICAgIHNlcmlhbGl6ZTogb3B0aW9ucyxcbiAgICAgIH1cbiAgICA6IG9wdGlvbnM7XG5cbiAgLy8gUmVhZCBzZXJpYWxpemVyIG9wdGlvbnMgcG9sbHV0aW9uLXNhZmVseTogb3duIHByb3BlcnRpZXMgYW5kIG1ldGhvZHMgb24gYVxuICAvLyBjbGFzcy90ZW1wbGF0ZSBwcm90b3R5cGUgYXJlIGhvbm9yZWQsIGJ1dCB2YWx1ZXMgaW5qZWN0ZWQgb250byBhIHBvbGx1dGVkXG4gIC8vIE9iamVjdC5wcm90b3R5cGUgYXJlIGlnbm9yZWQuXG4gIGNvbnN0IF9lbmNvZGUgPSB1dGlscy5nZXRTYWZlUHJvcChfb3B0aW9ucywgJ2VuY29kZScpIHx8IGVuY29kZTtcbiAgY29uc3Qgc2VyaWFsaXplRm4gPSB1dGlscy5nZXRTYWZlUHJvcChfb3B0aW9ucywgJ3NlcmlhbGl6ZScpO1xuXG4gIGxldCBzZXJpYWxpemVkUGFyYW1zO1xuXG4gIGlmIChzZXJpYWxpemVGbikge1xuICAgIHNlcmlhbGl6ZWRQYXJhbXMgPSBzZXJpYWxpemVGbihwYXJhbXMsIF9vcHRpb25zKTtcbiAgfSBlbHNlIHtcbiAgICBzZXJpYWxpemVkUGFyYW1zID0gdXRpbHMuaXNVUkxTZWFyY2hQYXJhbXMocGFyYW1zKVxuICAgICAgPyBwYXJhbXMudG9TdHJpbmcoKVxuICAgICAgOiBuZXcgQXhpb3NVUkxTZWFyY2hQYXJhbXMocGFyYW1zLCBfb3B0aW9ucykudG9TdHJpbmcoX2VuY29kZSk7XG4gIH1cblxuICBpZiAoc2VyaWFsaXplZFBhcmFtcykge1xuICAgIGNvbnN0IGhhc2htYXJrSW5kZXggPSB1cmwuaW5kZXhPZignIycpO1xuXG4gICAgaWYgKGhhc2htYXJrSW5kZXggIT09IC0xKSB7XG4gICAgICB1cmwgPSB1cmwuc2xpY2UoMCwgaGFzaG1hcmtJbmRleCk7XG4gICAgfVxuICAgIHVybCArPSAodXJsLmluZGV4T2YoJz8nKSA9PT0gLTEgPyAnPycgOiAnJicpICsgc2VyaWFsaXplZFBhcmFtcztcbiAgfVxuXG4gIHJldHVybiB1cmw7XG59XG4iLCIndXNlIHN0cmljdCc7XG5cbmltcG9ydCB1dGlscyBmcm9tICcuLi91dGlscy5qcyc7XG5cbmNvbnN0ICRpbnRlcm5hbHMgPSBTeW1ib2woJ2ludGVybmFscycpO1xuXG4vLyBgaGFuZGxlcnNgIGlzIHB1YmxpYyBhbmQgbWF5IGJlIHJlcGxhY2VkIHdpdGggYSBudWxsaXNoIHZhbHVlIGJ5IHVzZXIgY29kZTtcbi8vIGBjbGVhcigpYCBoYXMgYWx3YXlzIHRvbGVyYXRlZCB0aGF0LiBUcmVhdCBpdCBhcyBhbiBlbXB0eSBzdGFjayByYXRoZXIgdGhhblxuLy8gZGVyZWZlcmVuY2luZyBpdC5cbmZ1bmN0aW9uIGNvdW50SGFuZGxlcnMoaGFuZGxlcnMpIHtcbiAgcmV0dXJuIGhhbmRsZXJzID8gaGFuZGxlcnMubGVuZ3RoIDogMDtcbn1cblxuZnVuY3Rpb24gdHJpbUhhbmRsZXJzKGhhbmRsZXJzKSB7XG4gIGlmICghaGFuZGxlcnMpIHtcbiAgICByZXR1cm47XG4gIH1cblxuICB3aGlsZSAoaGFuZGxlcnMubGVuZ3RoICYmIGhhbmRsZXJzW2hhbmRsZXJzLmxlbmd0aCAtIDFdID09PSBudWxsKSB7XG4gICAgaGFuZGxlcnMucG9wKCk7XG4gIH1cbn1cblxuLy8gUHJlc2VydmUgdGhlIGFycmF5LWtleSBjb2VyY2lvbiB1c2VkIGJlZm9yZSBJRHMgd2VyZSBzdG9yZWQgaW4gYSBNYXAsIHdpdGhvdXRcbi8vIHRyZWF0aW5nIG51bGwsIGVtcHR5IHN0cmluZ3MsIG9yIG5vbmNhbm9uaWNhbCBudW1lcmljIHN0cmluZ3MgYXMgSUQgemVyby5cbmZ1bmN0aW9uIG5vcm1hbGl6ZUhhbmRsZXJJZChpZCkge1xuICBpZiAodHlwZW9mIGlkID09PSAnc3RyaW5nJyAmJiBpZCAhPT0gJycgJiYgU3RyaW5nKE51bWJlcihpZCkpID09PSBpZCkge1xuICAgIHJldHVybiBOdW1iZXIoaWQpO1xuICB9XG5cbiAgcmV0dXJuIGlkO1xufVxuXG5mdW5jdGlvbiBzeW5jSGFuZGxlckVudHJpZXMobWFuYWdlciwgaW50ZXJuYWxzKSB7XG4gIGNvbnN0IGhhbmRsZXJzID0gbWFuYWdlci5oYW5kbGVycztcbiAgY29uc3QgbGVuZ3RoID0gY291bnRIYW5kbGVycyhoYW5kbGVycyk7XG5cbiAgaWYgKGhhbmRsZXJzICE9PSBpbnRlcm5hbHMuaGFuZGxlcnNSZWYpIHtcbiAgICBpbnRlcm5hbHMuaGFuZGxlcnNSZWYgPSBoYW5kbGVycztcbiAgICBpbnRlcm5hbHMuaGFuZGxlckVudHJpZXMuY2xlYXIoKTtcbiAgfSBlbHNlIGlmIChsZW5ndGggIT09IGludGVybmFscy5oYW5kbGVyc0xlbmd0aCkge1xuICAgIGlmICghbGVuZ3RoKSB7XG4gICAgICBpbnRlcm5hbHMuaGFuZGxlckVudHJpZXMuY2xlYXIoKTtcbiAgICB9IGVsc2Uge1xuICAgICAgaW50ZXJuYWxzLmhhbmRsZXJFbnRyaWVzLmZvckVhY2goZnVuY3Rpb24gcmVtb3ZlU3RhbGVFbnRyeShlbnRyeSwgaWQpIHtcbiAgICAgICAgaWYgKGhhbmRsZXJzW2VudHJ5LmluZGV4XSAhPT0gZW50cnkuaGFuZGxlcikge1xuICAgICAgICAgIGludGVybmFscy5oYW5kbGVyRW50cmllcy5kZWxldGUoaWQpO1xuICAgICAgICB9XG4gICAgICB9KTtcbiAgICB9XG4gIH1cblxuICBpbnRlcm5hbHMuaGFuZGxlcnNMZW5ndGggPSBsZW5ndGg7XG59XG5cbmNsYXNzIEludGVyY2VwdG9yTWFuYWdlciB7XG4gIGNvbnN0cnVjdG9yKCkge1xuICAgIHRoaXMuaGFuZGxlcnMgPSBbXTtcbiAgICB0aGlzWyRpbnRlcm5hbHNdID0ge1xuICAgICAgaGFuZGxlcnNSZWY6IHRoaXMuaGFuZGxlcnMsXG4gICAgICBoYW5kbGVyc0xlbmd0aDogdGhpcy5oYW5kbGVycy5sZW5ndGgsXG4gICAgICBoYW5kbGVyRW50cmllczogbmV3IE1hcCgpLFxuICAgICAgaXRlcmF0aW9uRGVwdGg6IDAsXG4gICAgICBuZXh0SWQ6IDAsXG4gICAgfTtcbiAgfVxuXG4gIC8qKlxuICAgKiBBZGQgYSBuZXcgaW50ZXJjZXB0b3IgdG8gdGhlIHN0YWNrXG4gICAqXG4gICAqIEBwYXJhbSB7RnVuY3Rpb259IGZ1bGZpbGxlZCBUaGUgZnVuY3Rpb24gdG8gaGFuZGxlIGB0aGVuYCBmb3IgYSBgUHJvbWlzZWBcbiAgICogQHBhcmFtIHtGdW5jdGlvbn0gcmVqZWN0ZWQgVGhlIGZ1bmN0aW9uIHRvIGhhbmRsZSBgcmVqZWN0YCBmb3IgYSBgUHJvbWlzZWBcbiAgICogQHBhcmFtIHtPYmplY3R9IG9wdGlvbnMgVGhlIG9wdGlvbnMgZm9yIHRoZSBpbnRlcmNlcHRvciwgc3luY2hyb25vdXMgYW5kIHJ1bldoZW5cbiAgICpcbiAgICogQHJldHVybiB7TnVtYmVyfSBBbiBJRCB1c2VkIHRvIHJlbW92ZSBpbnRlcmNlcHRvciBsYXRlclxuICAgKi9cbiAgdXNlKGZ1bGZpbGxlZCwgcmVqZWN0ZWQsIG9wdGlvbnMpIHtcbiAgICBjb25zdCBoYW5kbGVyID0ge1xuICAgICAgZnVsZmlsbGVkLFxuICAgICAgcmVqZWN0ZWQsXG4gICAgICBzeW5jaHJvbm91czogb3B0aW9ucyA/IG9wdGlvbnMuc3luY2hyb25vdXMgOiBmYWxzZSxcbiAgICAgIHJ1bldoZW46IG9wdGlvbnMgPyBvcHRpb25zLnJ1bldoZW4gOiBudWxsLFxuICAgIH07XG4gICAgY29uc3QgaW50ZXJuYWxzID0gdGhpc1skaW50ZXJuYWxzXTtcblxuICAgIGlmICh0aGlzLmhhbmRsZXJzID09IG51bGwpIHtcbiAgICAgIHRoaXMuaGFuZGxlcnMgPSBbXTtcbiAgICB9XG5cbiAgICBzeW5jSGFuZGxlckVudHJpZXModGhpcywgaW50ZXJuYWxzKTtcblxuICAgIGNvbnN0IGlkID0gaW50ZXJuYWxzLm5leHRJZCsrO1xuXG4gICAgdGhpcy5oYW5kbGVycy5wdXNoKGhhbmRsZXIpO1xuICAgIGludGVybmFscy5oYW5kbGVyRW50cmllcy5zZXQoaWQsIHtcbiAgICAgIGhhbmRsZXIsXG4gICAgICBpbmRleDogdGhpcy5oYW5kbGVycy5sZW5ndGggLSAxLFxuICAgIH0pO1xuICAgIGludGVybmFscy5oYW5kbGVyc0xlbmd0aCA9IHRoaXMuaGFuZGxlcnMubGVuZ3RoO1xuXG4gICAgcmV0dXJuIGlkO1xuICB9XG5cbiAgLyoqXG4gICAqIFJlbW92ZSBhbiBpbnRlcmNlcHRvciBmcm9tIHRoZSBzdGFja1xuICAgKlxuICAgKiBAcGFyYW0ge051bWJlcn0gaWQgVGhlIElEIHRoYXQgd2FzIHJldHVybmVkIGJ5IGB1c2VgXG4gICAqXG4gICAqIEByZXR1cm5zIHt2b2lkfVxuICAgKi9cbiAgZWplY3QoaWQpIHtcbiAgICBjb25zdCBpbnRlcm5hbHMgPSB0aGlzWyRpbnRlcm5hbHNdO1xuXG4gICAgc3luY0hhbmRsZXJFbnRyaWVzKHRoaXMsIGludGVybmFscyk7XG5cbiAgICBjb25zdCBoYW5kbGVySWQgPSBub3JtYWxpemVIYW5kbGVySWQoaWQpO1xuICAgIGNvbnN0IGVudHJ5ID0gaW50ZXJuYWxzLmhhbmRsZXJFbnRyaWVzLmdldChoYW5kbGVySWQpO1xuXG4gICAgaWYgKGVudHJ5KSB7XG4gICAgICBpbnRlcm5hbHMuaGFuZGxlckVudHJpZXMuZGVsZXRlKGhhbmRsZXJJZCk7XG5cbiAgICAgIC8vIElnbm9yZSBJRHMgaW52YWxpZGF0ZWQgYnkgY2xlYXIgb3IgZGlyZWN0IHJlcGxhY2VtZW50IG9mIGhhbmRsZXJzLlxuICAgICAgaWYgKHRoaXMuaGFuZGxlcnNbZW50cnkuaW5kZXhdICE9PSBlbnRyeS5oYW5kbGVyKSB7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cblxuICAgICAgdGhpcy5oYW5kbGVyc1tlbnRyeS5pbmRleF0gPSBudWxsO1xuXG4gICAgICAvLyBEbyBub3QgcmV1c2UgYW4gaW5kZXggd2hpbGUgZm9yRWFjaCBpcyB3YWxraW5nIGl0cyBsZW5ndGggc25hcHNob3QuXG4gICAgICBpZiAoIWludGVybmFscy5pdGVyYXRpb25EZXB0aCkge1xuICAgICAgICB0cmltSGFuZGxlcnModGhpcy5oYW5kbGVycyk7XG4gICAgICAgIGludGVybmFscy5oYW5kbGVyc0xlbmd0aCA9IHRoaXMuaGFuZGxlcnMubGVuZ3RoO1xuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBDbGVhciBhbGwgaW50ZXJjZXB0b3JzIGZyb20gdGhlIHN0YWNrXG4gICAqXG4gICAqIEByZXR1cm5zIHt2b2lkfVxuICAgKi9cbiAgY2xlYXIoKSB7XG4gICAgaWYgKHRoaXMuaGFuZGxlcnMpIHtcbiAgICAgIHRoaXMuaGFuZGxlcnMgPSBbXTtcbiAgICAgIHN5bmNIYW5kbGVyRW50cmllcyh0aGlzLCB0aGlzWyRpbnRlcm5hbHNdKTtcbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogSXRlcmF0ZSBvdmVyIGFsbCB0aGUgcmVnaXN0ZXJlZCBpbnRlcmNlcHRvcnNcbiAgICpcbiAgICogVGhpcyBtZXRob2QgaXMgcGFydGljdWxhcmx5IHVzZWZ1bCBmb3Igc2tpcHBpbmcgb3ZlciBhbnlcbiAgICogaW50ZXJjZXB0b3JzIHRoYXQgbWF5IGhhdmUgYmVjb21lIGBudWxsYCBjYWxsaW5nIGBlamVjdGAuXG4gICAqXG4gICAqIEBwYXJhbSB7RnVuY3Rpb259IGZuIFRoZSBmdW5jdGlvbiB0byBjYWxsIGZvciBlYWNoIGludGVyY2VwdG9yXG4gICAqXG4gICAqIEByZXR1cm5zIHt2b2lkfVxuICAgKi9cbiAgZm9yRWFjaChmbikge1xuICAgIGNvbnN0IGludGVybmFscyA9IHRoaXNbJGludGVybmFsc107XG5cbiAgICBzeW5jSGFuZGxlckVudHJpZXModGhpcywgaW50ZXJuYWxzKTtcblxuICAgIGludGVybmFscy5pdGVyYXRpb25EZXB0aCsrO1xuXG4gICAgdHJ5IHtcbiAgICAgIHV0aWxzLmZvckVhY2godGhpcy5oYW5kbGVycywgZnVuY3Rpb24gZm9yRWFjaEhhbmRsZXIoaCkge1xuICAgICAgICBpZiAoaCAhPT0gbnVsbCkge1xuICAgICAgICAgIGZuKGgpO1xuICAgICAgICB9XG4gICAgICB9KTtcbiAgICB9IGZpbmFsbHkge1xuICAgICAgaWYgKCEtLWludGVybmFscy5pdGVyYXRpb25EZXB0aCkge1xuICAgICAgICBzeW5jSGFuZGxlckVudHJpZXModGhpcywgaW50ZXJuYWxzKTtcbiAgICAgICAgdHJpbUhhbmRsZXJzKHRoaXMuaGFuZGxlcnMpO1xuICAgICAgICBpbnRlcm5hbHMuaGFuZGxlcnNMZW5ndGggPSBjb3VudEhhbmRsZXJzKHRoaXMuaGFuZGxlcnMpO1xuICAgICAgfVxuICAgIH1cbiAgfVxufVxuXG5leHBvcnQgZGVmYXVsdCBJbnRlcmNlcHRvck1hbmFnZXI7XG4iLCIndXNlIHN0cmljdCc7XG5cbmV4cG9ydCBkZWZhdWx0IHtcbiAgc2lsZW50SlNPTlBhcnNpbmc6IHRydWUsXG4gIGZvcmNlZEpTT05QYXJzaW5nOiB0cnVlLFxuICBjbGFyaWZ5VGltZW91dEVycm9yOiBmYWxzZSxcbiAgbGVnYWN5SW50ZXJjZXB0b3JSZXFSZXNPcmRlcmluZzogdHJ1ZSxcbiAgYWR2ZXJ0aXNlWnN0ZEFjY2VwdEVuY29kaW5nOiBmYWxzZSxcbiAgdmFsaWRhdGVTdGF0dXNVbmRlZmluZWRSZXNvbHZlczogdHJ1ZSxcbiAgZW5jb2RlQmFzaWNBdXRoVXNlcm5hbWU6IGZhbHNlLFxufTtcbiIsIid1c2Ugc3RyaWN0JztcblxuaW1wb3J0IEF4aW9zVVJMU2VhcmNoUGFyYW1zIGZyb20gJy4uLy4uLy4uL2hlbHBlcnMvQXhpb3NVUkxTZWFyY2hQYXJhbXMuanMnO1xuZXhwb3J0IGRlZmF1bHQgdHlwZW9mIFVSTFNlYXJjaFBhcmFtcyAhPT0gJ3VuZGVmaW5lZCcgPyBVUkxTZWFyY2hQYXJhbXMgOiBBeGlvc1VSTFNlYXJjaFBhcmFtcztcbiIsIid1c2Ugc3RyaWN0JztcblxuZXhwb3J0IGRlZmF1bHQgdHlwZW9mIEZvcm1EYXRhICE9PSAndW5kZWZpbmVkJyA/IEZvcm1EYXRhIDogbnVsbDtcbiIsIid1c2Ugc3RyaWN0JztcblxuZXhwb3J0IGRlZmF1bHQgdHlwZW9mIEJsb2IgIT09ICd1bmRlZmluZWQnID8gQmxvYiA6IG51bGw7XG4iLCJpbXBvcnQgVVJMU2VhcmNoUGFyYW1zIGZyb20gJy4vY2xhc3Nlcy9VUkxTZWFyY2hQYXJhbXMuanMnO1xuaW1wb3J0IEZvcm1EYXRhIGZyb20gJy4vY2xhc3Nlcy9Gb3JtRGF0YS5qcyc7XG5pbXBvcnQgQmxvYiBmcm9tICcuL2NsYXNzZXMvQmxvYi5qcyc7XG5cbmV4cG9ydCBkZWZhdWx0IHtcbiAgaXNCcm93c2VyOiB0cnVlLFxuICBjbGFzc2VzOiB7XG4gICAgVVJMU2VhcmNoUGFyYW1zLFxuICAgIEZvcm1EYXRhLFxuICAgIEJsb2IsXG4gIH0sXG4gIHByb3RvY29sczogWydodHRwJywgJ2h0dHBzJywgJ2ZpbGUnLCAnYmxvYicsICd1cmwnLCAnZGF0YSddLFxufTtcbiIsImNvbnN0IGhhc0Jyb3dzZXJFbnYgPSB0eXBlb2Ygd2luZG93ICE9PSAndW5kZWZpbmVkJyAmJiB0eXBlb2YgZG9jdW1lbnQgIT09ICd1bmRlZmluZWQnO1xuXG5jb25zdCBfbmF2aWdhdG9yID0gKHR5cGVvZiBuYXZpZ2F0b3IgPT09ICdvYmplY3QnICYmIG5hdmlnYXRvcikgfHwgdW5kZWZpbmVkO1xuXG4vKipcbiAqIERldGVybWluZSBpZiB3ZSdyZSBydW5uaW5nIGluIGEgc3RhbmRhcmQgYnJvd3NlciBlbnZpcm9ubWVudFxuICpcbiAqIFRoaXMgYWxsb3dzIGF4aW9zIHRvIHJ1biBpbiBhIHdlYiB3b3JrZXIsIGFuZCByZWFjdC1uYXRpdmUuXG4gKiBCb3RoIGVudmlyb25tZW50cyBzdXBwb3J0IFhNTEh0dHBSZXF1ZXN0LCBidXQgbm90IGZ1bGx5IHN0YW5kYXJkIGdsb2JhbHMuXG4gKlxuICogd2ViIHdvcmtlcnM6XG4gKiAgdHlwZW9mIHdpbmRvdyAtPiB1bmRlZmluZWRcbiAqICB0eXBlb2YgZG9jdW1lbnQgLT4gdW5kZWZpbmVkXG4gKlxuICogcmVhY3QtbmF0aXZlOlxuICogIG5hdmlnYXRvci5wcm9kdWN0IC0+ICdSZWFjdE5hdGl2ZSdcbiAqIG5hdGl2ZXNjcmlwdFxuICogIG5hdmlnYXRvci5wcm9kdWN0IC0+ICdOYXRpdmVTY3JpcHQnIG9yICdOUydcbiAqXG4gKiBAcmV0dXJucyB7Ym9vbGVhbn1cbiAqL1xuY29uc3QgaGFzU3RhbmRhcmRCcm93c2VyRW52ID1cbiAgaGFzQnJvd3NlckVudiAmJlxuICAoIV9uYXZpZ2F0b3IgfHwgWydSZWFjdE5hdGl2ZScsICdOYXRpdmVTY3JpcHQnLCAnTlMnXS5pbmRleE9mKF9uYXZpZ2F0b3IucHJvZHVjdCkgPCAwKTtcblxuLyoqXG4gKiBEZXRlcm1pbmUgaWYgd2UncmUgcnVubmluZyBpbiBhIHN0YW5kYXJkIGJyb3dzZXIgd2ViV29ya2VyIGVudmlyb25tZW50XG4gKlxuICogQWx0aG91Z2ggdGhlIGBpc1N0YW5kYXJkQnJvd3NlckVudmAgbWV0aG9kIGluZGljYXRlcyB0aGF0XG4gKiBgYWxsb3dzIGF4aW9zIHRvIHJ1biBpbiBhIHdlYiB3b3JrZXJgLCB0aGUgV2ViV29ya2VyIHdpbGwgc3RpbGwgYmVcbiAqIGZpbHRlcmVkIG91dCBkdWUgdG8gaXRzIGp1ZGdtZW50IHN0YW5kYXJkXG4gKiBgdHlwZW9mIHdpbmRvdyAhPT0gJ3VuZGVmaW5lZCcgJiYgdHlwZW9mIGRvY3VtZW50ICE9PSAndW5kZWZpbmVkJ2AuXG4gKiBUaGlzIGxlYWRzIHRvIGEgcHJvYmxlbSB3aGVuIGF4aW9zIHBvc3QgYEZvcm1EYXRhYCBpbiB3ZWJXb3JrZXJcbiAqL1xuY29uc3QgaGFzU3RhbmRhcmRCcm93c2VyV2ViV29ya2VyRW52ID0gKCgpID0+IHtcbiAgcmV0dXJuIChcbiAgICB0eXBlb2YgV29ya2VyR2xvYmFsU2NvcGUgIT09ICd1bmRlZmluZWQnICYmXG4gICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIG5vLXVuZGVmXG4gICAgc2VsZiBpbnN0YW5jZW9mIFdvcmtlckdsb2JhbFNjb3BlICYmXG4gICAgdHlwZW9mIHNlbGYuaW1wb3J0U2NyaXB0cyA9PT0gJ2Z1bmN0aW9uJ1xuICApO1xufSkoKTtcblxuY29uc3Qgb3JpZ2luID0gKGhhc0Jyb3dzZXJFbnYgJiYgd2luZG93LmxvY2F0aW9uLmhyZWYpIHx8ICdodHRwOi8vbG9jYWxob3N0JztcblxuZXhwb3J0IHtcbiAgaGFzQnJvd3NlckVudixcbiAgaGFzU3RhbmRhcmRCcm93c2VyV2ViV29ya2VyRW52LFxuICBoYXNTdGFuZGFyZEJyb3dzZXJFbnYsXG4gIF9uYXZpZ2F0b3IgYXMgbmF2aWdhdG9yLFxuICBvcmlnaW4sXG59O1xuIiwiaW1wb3J0IHBsYXRmb3JtIGZyb20gJy4vbm9kZS9pbmRleC5qcyc7XG5pbXBvcnQgKiBhcyB1dGlscyBmcm9tICcuL2NvbW1vbi91dGlscy5qcyc7XG5cbmV4cG9ydCBkZWZhdWx0IHtcbiAgLi4udXRpbHMsXG4gIC4uLnBsYXRmb3JtLFxufTtcbiIsIid1c2Ugc3RyaWN0JztcblxuaW1wb3J0IHV0aWxzIGZyb20gJy4uL3V0aWxzLmpzJztcbmltcG9ydCB0b0Zvcm1EYXRhIGZyb20gJy4vdG9Gb3JtRGF0YS5qcyc7XG5pbXBvcnQgcGxhdGZvcm0gZnJvbSAnLi4vcGxhdGZvcm0vaW5kZXguanMnO1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiB0b1VSTEVuY29kZWRGb3JtKGRhdGEsIG9wdGlvbnMpIHtcbiAgcmV0dXJuIHRvRm9ybURhdGEoZGF0YSwgbmV3IHBsYXRmb3JtLmNsYXNzZXMuVVJMU2VhcmNoUGFyYW1zKCksIHtcbiAgICB2aXNpdG9yOiBmdW5jdGlvbiAodmFsdWUsIGtleSwgcGF0aCwgaGVscGVycykge1xuICAgICAgaWYgKHBsYXRmb3JtLmlzTm9kZSAmJiB1dGlscy5pc0J1ZmZlcih2YWx1ZSkpIHtcbiAgICAgICAgdGhpcy5hcHBlbmQoa2V5LCB2YWx1ZS50b1N0cmluZygnYmFzZTY0JykpO1xuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICB9XG5cbiAgICAgIHJldHVybiBoZWxwZXJzLmRlZmF1bHRWaXNpdG9yLmFwcGx5KHRoaXMsIGFyZ3VtZW50cyk7XG4gICAgfSxcbiAgICAuLi5vcHRpb25zLFxuICB9KTtcbn1cbiIsIid1c2Ugc3RyaWN0JztcblxuaW1wb3J0IHV0aWxzIGZyb20gJy4uL3V0aWxzLmpzJztcbmltcG9ydCBBeGlvc0Vycm9yIGZyb20gJy4uL2NvcmUvQXhpb3NFcnJvci5qcyc7XG5pbXBvcnQgeyBERUZBVUxUX0ZPUk1fREFUQV9NQVhfREVQVEggfSBmcm9tICcuL3RvRm9ybURhdGEuanMnO1xuXG5jb25zdCBNQVhfREVQVEggPSBERUZBVUxUX0ZPUk1fREFUQV9NQVhfREVQVEg7XG5cbmZ1bmN0aW9uIHRocm93SWZEZXB0aEV4Y2VlZGVkKGluZGV4KSB7XG4gIGlmIChpbmRleCA+IE1BWF9ERVBUSCkge1xuICAgIHRocm93IG5ldyBBeGlvc0Vycm9yKFxuICAgICAgJ0Zvcm1EYXRhIGZpZWxkIGlzIHRvbyBkZWVwbHkgbmVzdGVkICgnICsgaW5kZXggKyAnIGxldmVscykuIE1heCBkZXB0aDogJyArIE1BWF9ERVBUSCxcbiAgICAgIEF4aW9zRXJyb3IuRVJSX0ZPUk1fREFUQV9ERVBUSF9FWENFRURFRFxuICAgICk7XG4gIH1cbn1cblxuLyoqXG4gKiBJdCB0YWtlcyBhIHN0cmluZyBsaWtlIGBmb29beF1beV1bel1gIGFuZCByZXR1cm5zIGFuIGFycmF5IGxpa2UgYFsnZm9vJywgJ3gnLCAneScsICd6J11cbiAqXG4gKiBAcGFyYW0ge3N0cmluZ30gbmFtZSAtIFRoZSBuYW1lIG9mIHRoZSBwcm9wZXJ0eSB0byBnZXQuXG4gKlxuICogQHJldHVybnMgQW4gYXJyYXkgb2Ygc3RyaW5ncy5cbiAqL1xuZnVuY3Rpb24gcGFyc2VQcm9wUGF0aChuYW1lKSB7XG4gIC8vIGZvb1t4XVt5XVt6XSAtPiBbJ2ZvbycsICd4JywgJ3knLCAneiddXG4gIC8vIGZvby54LnkueiAgICAtPiBbJ2ZvbycsICd4JywgJ3knLCAneiddXG4gIC8vIEEgcGF0aCBpcyBzcGxpdCBvbiBgLmAgYW5kIG9uIGBbLi4uXWAgZ3JvdXBzLiBBIHNlZ21lbnQg4oCUIHdoZXRoZXIgd3JpdHRlblxuICAvLyBpbiBkb3Qgbm90YXRpb24gb3IgY2FwdHVyZWQgaW5zaWRlIGJyYWNrZXRzIOKAlCBtYXkgY29udGFpbiBhbnkgY2hhcmFjdGVyXG4gIC8vIGV4Y2VwdCBgLmAsIGBbYCBhbmQgYF1gLCBzbyBhIGtleSBsaWtlIGB1c2VyLW5hbWVgIG9yIGB1c2VyIG5hbWVgIGlzIGtlcHRcbiAgLy8gbGl0ZXJhbCBpbnN0ZWFkIG9mIGJlaW5nIHNwbGl0ICgjNTQwMikuIGAuYCwgYFtgIGFuZCBgXWAga2VlcCB0aGVpciBleGlzdGluZ1xuICAvLyBtZWFuaW5nLCBlLmcuIGBmb29bYmFyLmJhel1gIC0+IFsnZm9vJywgJ2JhcicsICdiYXonXSBhbmQgYFtdYCBpcyBhbiBhcnJheSBwdXNoLlxuICAvLyBFeGNsdWRpbmcgYFtgIGZyb20gdGhlIGJyYWNrZXQgZ3JvdXAgYWxzbyBtYWtlcyB0aGUgbWF0Y2ggZmFpbCBmYXN0IGF0IHRoZVxuICAvLyBuZXh0IGBbYCwgc28gYSBtYWxmb3JtZWQgbmFtZSBjYW5ub3QgcmVzY2FuIHRvIHRoZSBlbmQgb2YgdGhlIHN0cmluZyBmcm9tXG4gIC8vIGV2ZXJ5IHVubWF0Y2hlZCBgW2Ag4oCUIHBhcnNpbmcgc3RheXMgbGluZWFyIGluIHRoZSBsZW5ndGggb2YgdGhlIG5hbWUuXG4gIGNvbnN0IHBhdGggPSBbXTtcbiAgY29uc3QgcGF0dGVybiA9IC9bXi5bXFxdXSt8XFxbKFteLltcXF1dKildL2c7XG4gIGxldCBtYXRjaDtcblxuICB3aGlsZSAoKG1hdGNoID0gcGF0dGVybi5leGVjKG5hbWUpKSAhPT0gbnVsbCkge1xuICAgIHRocm93SWZEZXB0aEV4Y2VlZGVkKHBhdGgubGVuZ3RoKTtcbiAgICBwYXRoLnB1c2gobWF0Y2hbMF0gPT09ICdbXScgPyAnJyA6IG1hdGNoWzFdIHx8IG1hdGNoWzBdKTtcbiAgfVxuXG4gIHJldHVybiBwYXRoO1xufVxuXG4vKipcbiAqIENvbnZlcnQgYW4gYXJyYXkgdG8gYW4gb2JqZWN0LlxuICpcbiAqIEBwYXJhbSB7QXJyYXk8YW55Pn0gYXJyIC0gVGhlIGFycmF5IHRvIGNvbnZlcnQgdG8gYW4gb2JqZWN0LlxuICpcbiAqIEByZXR1cm5zIEFuIG9iamVjdCB3aXRoIHRoZSBzYW1lIGtleXMgYW5kIHZhbHVlcyBhcyB0aGUgYXJyYXkuXG4gKi9cbmZ1bmN0aW9uIGFycmF5VG9PYmplY3QoYXJyKSB7XG4gIGNvbnN0IG9iaiA9IHt9O1xuICBjb25zdCBrZXlzID0gT2JqZWN0LmtleXMoYXJyKTtcbiAgbGV0IGk7XG4gIGNvbnN0IGxlbiA9IGtleXMubGVuZ3RoO1xuICBsZXQga2V5O1xuICBmb3IgKGkgPSAwOyBpIDwgbGVuOyBpKyspIHtcbiAgICBrZXkgPSBrZXlzW2ldO1xuICAgIG9ialtrZXldID0gYXJyW2tleV07XG4gIH1cbiAgcmV0dXJuIG9iajtcbn1cblxuZnVuY3Rpb24gbm9ybWFsaXplQXJyYXkodmFsdWUpIHtcbiAgaWYgKCF1dGlscy5pc0FycmF5KHZhbHVlKSkgcmV0dXJuIHZhbHVlO1xuXG4gIGNvbnN0IGtleXMgPSBPYmplY3Qua2V5cyh2YWx1ZSk7XG4gIHJldHVybiBrZXlzLmxlbmd0aCAhPT0gdmFsdWUubGVuZ3RoIHx8IGtleXMuc29tZSgoa2V5LCBpbmRleCkgPT4ga2V5ICE9PSBTdHJpbmcoaW5kZXgpKVxuICAgID8gYXJyYXlUb09iamVjdCh2YWx1ZSlcbiAgICA6IHZhbHVlO1xufVxuXG5mdW5jdGlvbiBub3JtYWxpemVBcnJheXMob2JqKSB7XG4gIGNvbnN0IHBlbmRpbmcgPSBbb2JqXTtcbiAgd2hpbGUgKHBlbmRpbmcubGVuZ3RoKSB7XG4gICAgY29uc3QgdGFyZ2V0ID0gcGVuZGluZy5wb3AoKTtcbiAgICBPYmplY3Qua2V5cyh0YXJnZXQpLmZvckVhY2goKGtleSkgPT4ge1xuICAgICAgY29uc3QgdmFsdWUgPSAodGFyZ2V0W2tleV0gPSBub3JtYWxpemVBcnJheSh0YXJnZXRba2V5XSkpO1xuICAgICAgaWYgKHV0aWxzLmlzQXJyYXkodmFsdWUpIHx8IHV0aWxzLmlzUGxhaW5PYmplY3QodmFsdWUpKSB7XG4gICAgICAgIHBlbmRpbmcucHVzaCh2YWx1ZSk7XG4gICAgICB9XG4gICAgfSk7XG4gIH1cbiAgcmV0dXJuIG9iajtcbn1cblxuLyoqXG4gKiBJdCB0YWtlcyBhIEZvcm1EYXRhIG9iamVjdCBhbmQgcmV0dXJucyBhIEphdmFTY3JpcHQgb2JqZWN0XG4gKlxuICogQHBhcmFtIHtzdHJpbmd9IGZvcm1EYXRhIFRoZSBGb3JtRGF0YSBvYmplY3QgdG8gY29udmVydCB0byBKU09OLlxuICpcbiAqIEByZXR1cm5zIHtPYmplY3Q8c3RyaW5nLCBhbnk+IHwgbnVsbH0gVGhlIGNvbnZlcnRlZCBvYmplY3QuXG4gKi9cbmZ1bmN0aW9uIGZvcm1EYXRhVG9KU09OKGZvcm1EYXRhKSB7XG4gIGZ1bmN0aW9uIGJ1aWxkUGF0aChwYXRoLCB2YWx1ZSwgdGFyZ2V0LCBpbmRleCkge1xuICAgIHRocm93SWZEZXB0aEV4Y2VlZGVkKGluZGV4KTtcblxuICAgIGxldCBuYW1lID0gcGF0aFtpbmRleCsrXTtcblxuICAgIGlmIChuYW1lID09PSAnX19wcm90b19fJykgcmV0dXJuIHRydWU7XG5cbiAgICBjb25zdCBpc051bWVyaWNLZXkgPSBOdW1iZXIuaXNGaW5pdGUoK25hbWUpO1xuICAgIGNvbnN0IGlzTGFzdCA9IGluZGV4ID49IHBhdGgubGVuZ3RoO1xuICAgIG5hbWUgPSAhbmFtZSAmJiB1dGlscy5pc0FycmF5KHRhcmdldCkgPyB0YXJnZXQubGVuZ3RoIDogbmFtZTtcblxuICAgIGlmIChpc0xhc3QpIHtcbiAgICAgIGlmICh1dGlscy5oYXNPd25Qcm9wKHRhcmdldCwgbmFtZSkpIHtcbiAgICAgICAgdGFyZ2V0W25hbWVdID0gbm9ybWFsaXplQXJyYXkodGFyZ2V0W25hbWVdKTtcbiAgICAgICAgdGFyZ2V0W25hbWVdID0gdXRpbHMuaXNBcnJheSh0YXJnZXRbbmFtZV0pXG4gICAgICAgICAgPyB0YXJnZXRbbmFtZV0uY29uY2F0KHZhbHVlKVxuICAgICAgICAgIDogW3RhcmdldFtuYW1lXSwgdmFsdWVdO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgdGFyZ2V0W25hbWVdID0gdmFsdWU7XG4gICAgICB9XG5cbiAgICAgIHJldHVybiAhaXNOdW1lcmljS2V5O1xuICAgIH1cblxuICAgIGlmICghdXRpbHMuaGFzT3duUHJvcCh0YXJnZXQsIG5hbWUpIHx8ICF1dGlscy5pc09iamVjdCh0YXJnZXRbbmFtZV0pKSB7XG4gICAgICB0YXJnZXRbbmFtZV0gPSBbXTtcbiAgICB9XG5cbiAgICBjb25zdCByZXN1bHQgPSBidWlsZFBhdGgocGF0aCwgdmFsdWUsIHRhcmdldFtuYW1lXSwgaW5kZXgpO1xuXG4gICAgaWYgKHJlc3VsdCAmJiB1dGlscy5pc0FycmF5KHRhcmdldFtuYW1lXSkpIHtcbiAgICAgIHRhcmdldFtuYW1lXSA9IGFycmF5VG9PYmplY3QodGFyZ2V0W25hbWVdKTtcbiAgICB9XG5cbiAgICByZXR1cm4gIWlzTnVtZXJpY0tleTtcbiAgfVxuXG4gIGlmICh1dGlscy5pc0Zvcm1EYXRhKGZvcm1EYXRhKSAmJiB1dGlscy5pc0Z1bmN0aW9uKGZvcm1EYXRhLmVudHJpZXMpKSB7XG4gICAgY29uc3Qgb2JqID0ge307XG5cbiAgICB1dGlscy5mb3JFYWNoRW50cnkoZm9ybURhdGEsIChuYW1lLCB2YWx1ZSkgPT4ge1xuICAgICAgYnVpbGRQYXRoKHBhcnNlUHJvcFBhdGgobmFtZSksIHZhbHVlLCBvYmosIDApO1xuICAgIH0pO1xuXG4gICAgcmV0dXJuIG5vcm1hbGl6ZUFycmF5cyhvYmopO1xuICB9XG5cbiAgcmV0dXJuIG51bGw7XG59XG5cbmV4cG9ydCBkZWZhdWx0IGZvcm1EYXRhVG9KU09OO1xuIiwiJ3VzZSBzdHJpY3QnO1xuXG5jb25zdCBtZXRob2RMaXN0ID0gT2JqZWN0LmZyZWV6ZShbXG4gICdnZXQnLFxuICAnZGVsZXRlJyxcbiAgJ2hlYWQnLFxuICAnb3B0aW9ucycsXG4gICdwb3N0JyxcbiAgJ3B1dCcsXG4gICdwYXRjaCcsXG4gICdwdXJnZScsXG4gICdsaW5rJyxcbiAgJ3VubGluaycsXG4gICdxdWVyeScsXG5dKTtcblxuZXhwb3J0IGRlZmF1bHQgbWV0aG9kTGlzdDtcbiIsIid1c2Ugc3RyaWN0JztcblxuaW1wb3J0IHV0aWxzIGZyb20gJy4uL3V0aWxzLmpzJztcbmltcG9ydCBBeGlvc0Vycm9yIGZyb20gJy4uL2NvcmUvQXhpb3NFcnJvci5qcyc7XG5pbXBvcnQgdHJhbnNpdGlvbmFsRGVmYXVsdHMgZnJvbSAnLi90cmFuc2l0aW9uYWwuanMnO1xuaW1wb3J0IHRvRm9ybURhdGEgZnJvbSAnLi4vaGVscGVycy90b0Zvcm1EYXRhLmpzJztcbmltcG9ydCB0b1VSTEVuY29kZWRGb3JtIGZyb20gJy4uL2hlbHBlcnMvdG9VUkxFbmNvZGVkRm9ybS5qcyc7XG5pbXBvcnQgcGxhdGZvcm0gZnJvbSAnLi4vcGxhdGZvcm0vaW5kZXguanMnO1xuaW1wb3J0IGZvcm1EYXRhVG9KU09OIGZyb20gJy4uL2hlbHBlcnMvZm9ybURhdGFUb0pTT04uanMnO1xuaW1wb3J0IG1ldGhvZExpc3QgZnJvbSAnLi4vY29yZS9tZXRob2RMaXN0LmpzJztcblxuY29uc3Qgb3duID0gKG9iaiwga2V5KSA9PiAob2JqICE9IG51bGwgJiYgdXRpbHMuaGFzT3duUHJvcChvYmosIGtleSkgPyBvYmpba2V5XSA6IHVuZGVmaW5lZCk7XG5cbi8qKlxuICogSXQgdGFrZXMgYSBzdHJpbmcsIHRyaWVzIHRvIHBhcnNlIGl0LCBhbmQgaWYgaXQgZmFpbHMsIGl0IHJldHVybnMgdGhlIHN0cmluZ2lmaWVkIHZlcnNpb25cbiAqIG9mIHRoZSBpbnB1dFxuICpcbiAqIEBwYXJhbSB7YW55fSByYXdWYWx1ZSAtIFRoZSB2YWx1ZSB0byBiZSBzdHJpbmdpZmllZC5cbiAqIEBwYXJhbSB7RnVuY3Rpb259IHBhcnNlciAtIEEgZnVuY3Rpb24gdGhhdCBwYXJzZXMgYSBzdHJpbmcgaW50byBhIEphdmFTY3JpcHQgb2JqZWN0LlxuICogQHBhcmFtIHtGdW5jdGlvbn0gZW5jb2RlciAtIEEgZnVuY3Rpb24gdGhhdCB0YWtlcyBhIHZhbHVlIGFuZCByZXR1cm5zIGEgc3RyaW5nLlxuICpcbiAqIEByZXR1cm5zIHtzdHJpbmd9IEEgc3RyaW5naWZpZWQgdmVyc2lvbiBvZiB0aGUgcmF3VmFsdWUuXG4gKi9cbmZ1bmN0aW9uIHN0cmluZ2lmeVNhZmVseShyYXdWYWx1ZSwgcGFyc2VyLCBlbmNvZGVyKSB7XG4gIGlmICh1dGlscy5pc1N0cmluZyhyYXdWYWx1ZSkpIHtcbiAgICB0cnkge1xuICAgICAgKHBhcnNlciB8fCBKU09OLnBhcnNlKShyYXdWYWx1ZSk7XG4gICAgICByZXR1cm4gdXRpbHMudHJpbShyYXdWYWx1ZSk7XG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgaWYgKGUubmFtZSAhPT0gJ1N5bnRheEVycm9yJykge1xuICAgICAgICB0aHJvdyBlO1xuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIHJldHVybiAoZW5jb2RlciB8fCBKU09OLnN0cmluZ2lmeSkocmF3VmFsdWUpO1xufVxuXG5jb25zdCBkZWZhdWx0cyA9IHtcbiAgdHJhbnNpdGlvbmFsOiB0cmFuc2l0aW9uYWxEZWZhdWx0cyxcblxuICBhZGFwdGVyOiBbJ3hocicsICdodHRwJywgJ2ZldGNoJ10sXG5cbiAgdHJhbnNmb3JtUmVxdWVzdDogW1xuICAgIGZ1bmN0aW9uIHRyYW5zZm9ybVJlcXVlc3QoZGF0YSwgaGVhZGVycykge1xuICAgICAgY29uc3QgY29udGVudFR5cGUgPSBoZWFkZXJzLmdldENvbnRlbnRUeXBlKCkgfHwgJyc7XG4gICAgICBjb25zdCBoYXNKU09OQ29udGVudFR5cGUgPSBjb250ZW50VHlwZS5pbmRleE9mKCdhcHBsaWNhdGlvbi9qc29uJykgPiAtMTtcbiAgICAgIGNvbnN0IGlzT2JqZWN0UGF5bG9hZCA9IHV0aWxzLmlzT2JqZWN0KGRhdGEpO1xuXG4gICAgICBpZiAoaXNPYmplY3RQYXlsb2FkICYmIHV0aWxzLmlzSFRNTEZvcm0oZGF0YSkpIHtcbiAgICAgICAgZGF0YSA9IG5ldyBGb3JtRGF0YShkYXRhKTtcbiAgICAgIH1cblxuICAgICAgY29uc3QgaXNGb3JtRGF0YSA9IHV0aWxzLmlzRm9ybURhdGEoZGF0YSk7XG5cbiAgICAgIGlmIChpc0Zvcm1EYXRhKSB7XG4gICAgICAgIHJldHVybiBoYXNKU09OQ29udGVudFR5cGUgPyBKU09OLnN0cmluZ2lmeShmb3JtRGF0YVRvSlNPTihkYXRhKSkgOiBkYXRhO1xuICAgICAgfVxuXG4gICAgICBpZiAoXG4gICAgICAgIHV0aWxzLmlzQXJyYXlCdWZmZXIoZGF0YSkgfHxcbiAgICAgICAgdXRpbHMuaXNCdWZmZXIoZGF0YSkgfHxcbiAgICAgICAgdXRpbHMuaXNTdHJlYW0oZGF0YSkgfHxcbiAgICAgICAgdXRpbHMuaXNGaWxlKGRhdGEpIHx8XG4gICAgICAgIHV0aWxzLmlzQmxvYihkYXRhKSB8fFxuICAgICAgICB1dGlscy5pc1JlYWRhYmxlU3RyZWFtKGRhdGEpXG4gICAgICApIHtcbiAgICAgICAgcmV0dXJuIGRhdGE7XG4gICAgICB9XG4gICAgICBpZiAodXRpbHMuaXNBcnJheUJ1ZmZlclZpZXcoZGF0YSkpIHtcbiAgICAgICAgcmV0dXJuIGRhdGEuYnVmZmVyO1xuICAgICAgfVxuICAgICAgaWYgKHV0aWxzLmlzVVJMU2VhcmNoUGFyYW1zKGRhdGEpKSB7XG4gICAgICAgIGhlYWRlcnMuc2V0Q29udGVudFR5cGUoJ2FwcGxpY2F0aW9uL3gtd3d3LWZvcm0tdXJsZW5jb2RlZDtjaGFyc2V0PXV0Zi04JywgZmFsc2UpO1xuICAgICAgICByZXR1cm4gZGF0YS50b1N0cmluZygpO1xuICAgICAgfVxuXG4gICAgICBsZXQgaXNGaWxlTGlzdDtcblxuICAgICAgaWYgKGlzT2JqZWN0UGF5bG9hZCkge1xuICAgICAgICBjb25zdCBmb3JtU2VyaWFsaXplciA9IG93bih0aGlzLCAnZm9ybVNlcmlhbGl6ZXInKTtcbiAgICAgICAgaWYgKGNvbnRlbnRUeXBlLmluZGV4T2YoJ2FwcGxpY2F0aW9uL3gtd3d3LWZvcm0tdXJsZW5jb2RlZCcpID4gLTEpIHtcbiAgICAgICAgICByZXR1cm4gdG9VUkxFbmNvZGVkRm9ybShkYXRhLCBmb3JtU2VyaWFsaXplcikudG9TdHJpbmcoKTtcbiAgICAgICAgfVxuXG4gICAgICAgIGlmIChcbiAgICAgICAgICAoaXNGaWxlTGlzdCA9IHV0aWxzLmlzRmlsZUxpc3QoZGF0YSkpIHx8XG4gICAgICAgICAgY29udGVudFR5cGUuaW5kZXhPZignbXVsdGlwYXJ0L2Zvcm0tZGF0YScpID4gLTFcbiAgICAgICAgKSB7XG4gICAgICAgICAgY29uc3QgZW52ID0gb3duKHRoaXMsICdlbnYnKTtcbiAgICAgICAgICBjb25zdCBfRm9ybURhdGEgPSBlbnYgJiYgZW52LkZvcm1EYXRhO1xuXG4gICAgICAgICAgcmV0dXJuIHRvRm9ybURhdGEoXG4gICAgICAgICAgICBpc0ZpbGVMaXN0ID8geyAnZmlsZXNbXSc6IGRhdGEgfSA6IGRhdGEsXG4gICAgICAgICAgICBfRm9ybURhdGEgJiYgbmV3IF9Gb3JtRGF0YSgpLFxuICAgICAgICAgICAgZm9ybVNlcmlhbGl6ZXJcbiAgICAgICAgICApO1xuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgIGlmIChpc09iamVjdFBheWxvYWQgfHwgaGFzSlNPTkNvbnRlbnRUeXBlKSB7XG4gICAgICAgIGhlYWRlcnMuc2V0Q29udGVudFR5cGUoJ2FwcGxpY2F0aW9uL2pzb24nLCBmYWxzZSk7XG4gICAgICAgIHJldHVybiBzdHJpbmdpZnlTYWZlbHkoZGF0YSk7XG4gICAgICB9XG5cbiAgICAgIHJldHVybiBkYXRhO1xuICAgIH0sXG4gIF0sXG5cbiAgdHJhbnNmb3JtUmVzcG9uc2U6IFtcbiAgICBmdW5jdGlvbiB0cmFuc2Zvcm1SZXNwb25zZShkYXRhKSB7XG4gICAgICBjb25zdCB0cmFuc2l0aW9uYWwgPSBvd24odGhpcywgJ3RyYW5zaXRpb25hbCcpIHx8IGRlZmF1bHRzLnRyYW5zaXRpb25hbDtcbiAgICAgIGNvbnN0IGZvcmNlZEpTT05QYXJzaW5nID0gdHJhbnNpdGlvbmFsICYmIHRyYW5zaXRpb25hbC5mb3JjZWRKU09OUGFyc2luZztcbiAgICAgIGNvbnN0IHJlc3BvbnNlVHlwZSA9IG93bih0aGlzLCAncmVzcG9uc2VUeXBlJyk7XG4gICAgICBjb25zdCBKU09OUmVxdWVzdGVkID0gcmVzcG9uc2VUeXBlID09PSAnanNvbic7XG5cbiAgICAgIGlmICh1dGlscy5pc1Jlc3BvbnNlKGRhdGEpIHx8IHV0aWxzLmlzUmVhZGFibGVTdHJlYW0oZGF0YSkpIHtcbiAgICAgICAgcmV0dXJuIGRhdGE7XG4gICAgICB9XG5cbiAgICAgIGlmIChcbiAgICAgICAgZGF0YSAmJlxuICAgICAgICB1dGlscy5pc1N0cmluZyhkYXRhKSAmJlxuICAgICAgICAoKGZvcmNlZEpTT05QYXJzaW5nICYmICFyZXNwb25zZVR5cGUpIHx8IEpTT05SZXF1ZXN0ZWQpXG4gICAgICApIHtcbiAgICAgICAgY29uc3Qgc2lsZW50SlNPTlBhcnNpbmcgPSB0cmFuc2l0aW9uYWwgJiYgdHJhbnNpdGlvbmFsLnNpbGVudEpTT05QYXJzaW5nO1xuICAgICAgICBjb25zdCBzdHJpY3RKU09OUGFyc2luZyA9ICFzaWxlbnRKU09OUGFyc2luZyAmJiBKU09OUmVxdWVzdGVkO1xuXG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgcmV0dXJuIEpTT04ucGFyc2UoZGF0YSwgb3duKHRoaXMsICdwYXJzZVJldml2ZXInKSk7XG4gICAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgICBpZiAoc3RyaWN0SlNPTlBhcnNpbmcpIHtcbiAgICAgICAgICAgIGlmIChlLm5hbWUgPT09ICdTeW50YXhFcnJvcicpIHtcbiAgICAgICAgICAgICAgdGhyb3cgQXhpb3NFcnJvci5mcm9tKGUsIEF4aW9zRXJyb3IuRVJSX0JBRF9SRVNQT05TRSwgdGhpcywgbnVsbCwgb3duKHRoaXMsICdyZXNwb25zZScpKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHRocm93IGU7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgIHJldHVybiBkYXRhO1xuICAgIH0sXG4gIF0sXG5cbiAgLyoqXG4gICAqIEEgdGltZW91dCBpbiBtaWxsaXNlY29uZHMgdG8gYWJvcnQgYSByZXF1ZXN0LiBJZiBzZXQgdG8gMCAoZGVmYXVsdCkgYVxuICAgKiB0aW1lb3V0IGlzIG5vdCBjcmVhdGVkLlxuICAgKi9cbiAgdGltZW91dDogMCxcblxuICB4c3JmQ29va2llTmFtZTogJ1hTUkYtVE9LRU4nLFxuICB4c3JmSGVhZGVyTmFtZTogJ1gtWFNSRi1UT0tFTicsXG5cbiAgbWF4Q29udGVudExlbmd0aDogLTEsXG4gIG1heEJvZHlMZW5ndGg6IC0xLFxuXG4gIGVudjoge1xuICAgIEZvcm1EYXRhOiBwbGF0Zm9ybS5jbGFzc2VzLkZvcm1EYXRhLFxuICAgIEJsb2I6IHBsYXRmb3JtLmNsYXNzZXMuQmxvYixcbiAgfSxcblxuICB2YWxpZGF0ZVN0YXR1czogZnVuY3Rpb24gdmFsaWRhdGVTdGF0dXMoc3RhdHVzKSB7XG4gICAgcmV0dXJuIHN0YXR1cyA+PSAyMDAgJiYgc3RhdHVzIDwgMzAwO1xuICB9LFxuXG4gIGhlYWRlcnM6IHtcbiAgICBjb21tb246IHtcbiAgICAgIEFjY2VwdDogJ2FwcGxpY2F0aW9uL2pzb24sIHRleHQvcGxhaW4sICovKicsXG4gICAgICAnQ29udGVudC1UeXBlJzogdW5kZWZpbmVkLFxuICAgIH0sXG4gIH0sXG59O1xuXG51dGlscy5mb3JFYWNoKG1ldGhvZExpc3QsIChtZXRob2QpID0+IHtcbiAgZGVmYXVsdHMuaGVhZGVyc1ttZXRob2RdID0ge307XG59KTtcblxuZXhwb3J0IGRlZmF1bHQgZGVmYXVsdHM7XG4iLCIndXNlIHN0cmljdCc7XG5cbmltcG9ydCB1dGlscyBmcm9tICcuLi91dGlscy5qcyc7XG5pbXBvcnQgZGVmYXVsdHMgZnJvbSAnLi4vZGVmYXVsdHMvaW5kZXguanMnO1xuaW1wb3J0IEF4aW9zSGVhZGVycyBmcm9tICcuLi9jb3JlL0F4aW9zSGVhZGVycy5qcyc7XG5cbi8qKlxuICogVHJhbnNmb3JtIHRoZSBkYXRhIGZvciBhIHJlcXVlc3Qgb3IgYSByZXNwb25zZVxuICpcbiAqIEBwYXJhbSB7QXJyYXl8RnVuY3Rpb259IGZucyBBIHNpbmdsZSBmdW5jdGlvbiBvciBBcnJheSBvZiBmdW5jdGlvbnNcbiAqIEBwYXJhbSB7P09iamVjdH0gcmVzcG9uc2UgVGhlIHJlc3BvbnNlIG9iamVjdFxuICpcbiAqIEByZXR1cm5zIHsqfSBUaGUgcmVzdWx0aW5nIHRyYW5zZm9ybWVkIGRhdGFcbiAqL1xuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gdHJhbnNmb3JtRGF0YShmbnMsIHJlc3BvbnNlKSB7XG4gIGNvbnN0IGNvbmZpZyA9IHRoaXMgfHwgZGVmYXVsdHM7XG4gIGNvbnN0IGNvbnRleHQgPSByZXNwb25zZSB8fCBjb25maWc7XG4gIGNvbnN0IGhlYWRlcnMgPSBBeGlvc0hlYWRlcnMuZnJvbShjb250ZXh0LmhlYWRlcnMpO1xuICBsZXQgZGF0YSA9IGNvbnRleHQuZGF0YTtcblxuICB1dGlscy5mb3JFYWNoKGZucywgZnVuY3Rpb24gdHJhbnNmb3JtKGZuKSB7XG4gICAgZGF0YSA9IGZuLmNhbGwoY29uZmlnLCBkYXRhLCBoZWFkZXJzLm5vcm1hbGl6ZSgpLCByZXNwb25zZSA/IHJlc3BvbnNlLnN0YXR1cyA6IHVuZGVmaW5lZCk7XG4gIH0pO1xuXG4gIGhlYWRlcnMubm9ybWFsaXplKCk7XG5cbiAgcmV0dXJuIGRhdGE7XG59XG4iLCIndXNlIHN0cmljdCc7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIGlzQ2FuY2VsKHZhbHVlKSB7XG4gIHJldHVybiAhISh2YWx1ZSAmJiB2YWx1ZS5fX0NBTkNFTF9fKTtcbn1cbiIsIid1c2Ugc3RyaWN0JztcblxuaW1wb3J0IEF4aW9zRXJyb3IgZnJvbSAnLi4vY29yZS9BeGlvc0Vycm9yLmpzJztcblxuY2xhc3MgQ2FuY2VsZWRFcnJvciBleHRlbmRzIEF4aW9zRXJyb3Ige1xuICAvKipcbiAgICogQSBgQ2FuY2VsZWRFcnJvcmAgaXMgYW4gb2JqZWN0IHRoYXQgaXMgdGhyb3duIHdoZW4gYW4gb3BlcmF0aW9uIGlzIGNhbmNlbGVkLlxuICAgKlxuICAgKiBAcGFyYW0ge3N0cmluZz19IG1lc3NhZ2UgVGhlIG1lc3NhZ2UuXG4gICAqIEBwYXJhbSB7T2JqZWN0PX0gY29uZmlnIFRoZSBjb25maWcuXG4gICAqIEBwYXJhbSB7T2JqZWN0PX0gcmVxdWVzdCBUaGUgcmVxdWVzdC5cbiAgICpcbiAgICogQHJldHVybnMge0NhbmNlbGVkRXJyb3J9IFRoZSBjcmVhdGVkIGVycm9yLlxuICAgKi9cbiAgY29uc3RydWN0b3IobWVzc2FnZSwgY29uZmlnLCByZXF1ZXN0KSB7XG4gICAgc3VwZXIobWVzc2FnZSA9PSBudWxsID8gJ2NhbmNlbGVkJyA6IG1lc3NhZ2UsIEF4aW9zRXJyb3IuRVJSX0NBTkNFTEVELCBjb25maWcsIHJlcXVlc3QpO1xuICAgIHRoaXMubmFtZSA9ICdDYW5jZWxlZEVycm9yJztcbiAgICB0aGlzLl9fQ0FOQ0VMX18gPSB0cnVlO1xuICB9XG59XG5cbmV4cG9ydCBkZWZhdWx0IENhbmNlbGVkRXJyb3I7XG4iLCIndXNlIHN0cmljdCc7XG5cbmltcG9ydCBBeGlvc0Vycm9yIGZyb20gJy4vQXhpb3NFcnJvci5qcyc7XG5cbi8qKlxuICogUmVzb2x2ZSBvciByZWplY3QgYSBQcm9taXNlIGJhc2VkIG9uIHJlc3BvbnNlIHN0YXR1cy5cbiAqXG4gKiBAcGFyYW0ge0Z1bmN0aW9ufSByZXNvbHZlIEEgZnVuY3Rpb24gdGhhdCByZXNvbHZlcyB0aGUgcHJvbWlzZS5cbiAqIEBwYXJhbSB7RnVuY3Rpb259IHJlamVjdCBBIGZ1bmN0aW9uIHRoYXQgcmVqZWN0cyB0aGUgcHJvbWlzZS5cbiAqIEBwYXJhbSB7b2JqZWN0fSByZXNwb25zZSBUaGUgcmVzcG9uc2UuXG4gKlxuICogQHJldHVybnMge29iamVjdH0gVGhlIHJlc3BvbnNlLlxuICovXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBzZXR0bGUocmVzb2x2ZSwgcmVqZWN0LCByZXNwb25zZSkge1xuICBjb25zdCB2YWxpZGF0ZVN0YXR1cyA9IHJlc3BvbnNlLmNvbmZpZy52YWxpZGF0ZVN0YXR1cztcbiAgaWYgKCFyZXNwb25zZS5zdGF0dXMgfHwgIXZhbGlkYXRlU3RhdHVzIHx8IHZhbGlkYXRlU3RhdHVzKHJlc3BvbnNlLnN0YXR1cykpIHtcbiAgICByZXNvbHZlKHJlc3BvbnNlKTtcbiAgfSBlbHNlIHtcbiAgICByZWplY3QobmV3IEF4aW9zRXJyb3IoXG4gICAgICAnUmVxdWVzdCBmYWlsZWQgd2l0aCBzdGF0dXMgY29kZSAnICsgcmVzcG9uc2Uuc3RhdHVzLFxuICAgICAgcmVzcG9uc2Uuc3RhdHVzID49IDQwMCAmJiByZXNwb25zZS5zdGF0dXMgPCA1MDAgPyBBeGlvc0Vycm9yLkVSUl9CQURfUkVRVUVTVCA6IEF4aW9zRXJyb3IuRVJSX0JBRF9SRVNQT05TRSxcbiAgICAgIHJlc3BvbnNlLmNvbmZpZyxcbiAgICAgIHJlc3BvbnNlLnJlcXVlc3QsXG4gICAgICByZXNwb25zZVxuICAgICkpO1xuICB9XG59XG4iLCIndXNlIHN0cmljdCc7XG5cbmNvbnN0IHVybFBhcnNlckNvbnRyb2xDaGFyYWN0ZXJzID0gL1tcXHRcXG5cXHJdL2c7XG5cbi8qKlxuICogTWF0Y2ggV0hBVFdHIFVSTCBwcmVwcm9jZXNzaW5nIGJlZm9yZSBjaGVja2luZyBhIFVSTCdzIHByb3RvY29sLlxuICpcbiAqIEBwYXJhbSB7c3RyaW5nfSB1cmxcbiAqXG4gKiBAcmV0dXJucyB7c3RyaW5nfVxuICovXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBub3JtYWxpemVVUkxGb3JQcm90b2NvbENoZWNrKHVybCkge1xuICBpZiAodHlwZW9mIHVybCAhPT0gJ3N0cmluZycpIHtcbiAgICByZXR1cm4gdXJsO1xuICB9XG5cbiAgbGV0IHN0YXJ0ID0gMDtcblxuICB3aGlsZSAoc3RhcnQgPCB1cmwubGVuZ3RoICYmIHVybC5jaGFyQ29kZUF0KHN0YXJ0KSA8PSAweDIwKSB7XG4gICAgc3RhcnQrKztcbiAgfVxuXG4gIHJldHVybiB1cmwuc2xpY2Uoc3RhcnQpLnJlcGxhY2UodXJsUGFyc2VyQ29udHJvbENoYXJhY3RlcnMsICcnKTtcbn1cbiIsIid1c2Ugc3RyaWN0JztcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gcGFyc2VQcm90b2NvbCh1cmwpIHtcbiAgY29uc3QgbWF0Y2ggPSAvXihbLStcXHddezEsMjV9KTooPzpcXC9cXC8pPy8uZXhlYyh1cmwpO1xuICByZXR1cm4gKG1hdGNoICYmIG1hdGNoWzFdLnRvTG93ZXJDYXNlKCkpIHx8ICcnO1xufVxuIiwiaW1wb3J0IHV0aWxzIGZyb20gJy4uL3V0aWxzLmpzJztcbmltcG9ydCBwbGF0Zm9ybSBmcm9tICcuLi9wbGF0Zm9ybS9pbmRleC5qcyc7XG5cbmNvbnN0IGRlY29kZUNvb2tpZVZhbHVlID0gKHZhbHVlKSA9PiB7XG4gIHRyeSB7XG4gICAgcmV0dXJuIGRlY29kZVVSSUNvbXBvbmVudCh2YWx1ZSk7XG4gIH0gY2F0Y2ggKGUpIHtcbiAgICByZXR1cm4gdmFsdWU7XG4gIH1cbn07XG5cbmV4cG9ydCBkZWZhdWx0IHBsYXRmb3JtLmhhc1N0YW5kYXJkQnJvd3NlckVudlxuICA/IC8vIFN0YW5kYXJkIGJyb3dzZXIgZW52cyBzdXBwb3J0IGRvY3VtZW50LmNvb2tpZVxuICAgIHtcbiAgICAgIHdyaXRlKG5hbWUsIHZhbHVlLCBleHBpcmVzLCBwYXRoLCBkb21haW4sIHNlY3VyZSwgc2FtZVNpdGUpIHtcbiAgICAgICAgaWYgKHR5cGVvZiBkb2N1bWVudCA9PT0gJ3VuZGVmaW5lZCcpIHJldHVybjtcblxuICAgICAgICBjb25zdCBjb29raWUgPSBbYCR7bmFtZX09JHtlbmNvZGVVUklDb21wb25lbnQodmFsdWUpfWBdO1xuXG4gICAgICAgIGlmICh1dGlscy5pc051bWJlcihleHBpcmVzKSkge1xuICAgICAgICAgIGNvb2tpZS5wdXNoKGBleHBpcmVzPSR7bmV3IERhdGUoZXhwaXJlcykudG9VVENTdHJpbmcoKX1gKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAodXRpbHMuaXNTdHJpbmcocGF0aCkpIHtcbiAgICAgICAgICBjb29raWUucHVzaChgcGF0aD0ke3BhdGh9YCk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHV0aWxzLmlzU3RyaW5nKGRvbWFpbikpIHtcbiAgICAgICAgICBjb29raWUucHVzaChgZG9tYWluPSR7ZG9tYWlufWApO1xuICAgICAgICB9XG4gICAgICAgIGlmIChzZWN1cmUgPT09IHRydWUpIHtcbiAgICAgICAgICBjb29raWUucHVzaCgnc2VjdXJlJyk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHV0aWxzLmlzU3RyaW5nKHNhbWVTaXRlKSkge1xuICAgICAgICAgIGNvb2tpZS5wdXNoKGBTYW1lU2l0ZT0ke3NhbWVTaXRlfWApO1xuICAgICAgICB9XG5cbiAgICAgICAgZG9jdW1lbnQuY29va2llID0gY29va2llLmpvaW4oJzsgJyk7XG4gICAgICB9LFxuXG4gICAgICByZWFkKG5hbWUpIHtcbiAgICAgICAgaWYgKHR5cGVvZiBkb2N1bWVudCA9PT0gJ3VuZGVmaW5lZCcpIHJldHVybiBudWxsO1xuICAgICAgICBjb25zdCBjb29raWVTdHJpbmcgPSBkb2N1bWVudC5jb29raWU7XG4gICAgICAgIGlmICghY29va2llU3RyaW5nKSByZXR1cm4gbnVsbDtcbiAgICAgICAgLy8gTWF0Y2ggbmFtZT12YWx1ZSBieSBzcGxpdHRpbmcgb24gdGhlIHNlbWljb2xvbiBzZXBhcmF0b3IgaW5zdGVhZCBvZiBidWlsZGluZyBhXG4gICAgICAgIC8vIFJlZ0V4cCBmcm9tIGBuYW1lYCDigJQgaW50ZXJwb2xhdGluZyBhbiB1bmVzY2FwZWQgc3RyaW5nIGludG8gYSBSZWdFeHAgd291bGQgbGV0XG4gICAgICAgIC8vIG1ldGFjaGFyYWN0ZXJzIChlLmcuIGAuKz9gIGluIGFuIGF0dGFja2VyLWluZmx1ZW5jZWQgY29va2llIG5hbWUpIGNhdXNlIFJlRG9TIG9yXG4gICAgICAgIC8vIG1hdGNoIHRoZSB3cm9uZyBjb29raWUuIEJyb3dzZXJzIG1heSBzZXJpYWxpemUgY29va2llIHBhaXJzIGFzIGVpdGhlciBcIjtcIiBvclxuICAgICAgICAvLyBcIjsgXCIsIHNvIGlnbm9yZSBvcHRpb25hbCB3aGl0ZXNwYWNlIGJlZm9yZSBlYWNoIGNvb2tpZSBuYW1lLlxuICAgICAgICBjb25zdCBjb29raWVzID0gY29va2llU3RyaW5nLnNwbGl0KCc7Jyk7XG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgY29va2llcy5sZW5ndGg7IGkrKykge1xuICAgICAgICAgIGNvbnN0IGNvb2tpZSA9IGNvb2tpZXNbaV0ucmVwbGFjZSgvXlxccysvLCAnJyk7XG4gICAgICAgICAgY29uc3QgZXEgPSBjb29raWUuaW5kZXhPZignPScpO1xuICAgICAgICAgIGlmIChlcSAhPT0gLTEgJiYgY29va2llLnNsaWNlKDAsIGVxKSA9PT0gbmFtZSkge1xuICAgICAgICAgICAgcmV0dXJuIGRlY29kZUNvb2tpZVZhbHVlKGNvb2tpZS5zbGljZShlcSArIDEpKTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgICB9LFxuXG4gICAgICBhc3luYyByZWFkQXN5bmMobmFtZSkge1xuICAgICAgICB0cnkge1xuICAgICAgICAgIGNvbnN0IHN0b3JlID0gdHlwZW9mIHdpbmRvdyAhPT0gJ3VuZGVmaW5lZCcgJiYgd2luZG93LmNvb2tpZVN0b3JlO1xuICAgICAgICAgIGlmIChzdG9yZSAmJiB1dGlscy5pc0Z1bmN0aW9uKHN0b3JlLmdldCkpIHtcbiAgICAgICAgICAgIGNvbnN0IGNvb2tpZSA9IGF3YWl0IHN0b3JlLmdldChuYW1lKTtcbiAgICAgICAgICAgIC8vIEJvdGggQVBJcyBleHBvc2Ugc3RvcmVkIGJ5dGVzOyBwcmVzZXJ2ZSBBeGlvcydzIGV4aXN0aW5nIFVSSSBkZWNvZGluZy5cbiAgICAgICAgICAgIHJldHVybiBjb29raWUgPyBkZWNvZGVDb29raWVWYWx1ZShjb29raWUudmFsdWUpIDogbnVsbDtcbiAgICAgICAgICB9XG4gICAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgICAvLyBSZXN0cmljdGVkIG9yIHVuYXZhaWxhYmxlIHN0b3JhZ2UgcmV0YWlucyB0aGUgc3luY2hyb25vdXMgZmFsbGJhY2suXG4gICAgICAgIH1cblxuICAgICAgICByZXR1cm4gdGhpcy5yZWFkKG5hbWUpO1xuICAgICAgfSxcblxuICAgICAgcmVtb3ZlKG5hbWUpIHtcbiAgICAgICAgdGhpcy53cml0ZShuYW1lLCAnJywgRGF0ZS5ub3coKSAtIDg2NDAwMDAwLCAnLycpO1xuICAgICAgfSxcbiAgICB9XG4gIDogLy8gTm9uLXN0YW5kYXJkIGJyb3dzZXIgZW52ICh3ZWIgd29ya2VycywgcmVhY3QtbmF0aXZlKSBsYWNrIG5lZWRlZCBzdXBwb3J0LlxuICAgIHtcbiAgICAgIHdyaXRlKCkge30sXG4gICAgICByZWFkKCkge1xuICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAgIH0sXG4gICAgICBhc3luYyByZWFkQXN5bmMoKSB7XG4gICAgICAgIHJldHVybiBudWxsO1xuICAgICAgfSxcbiAgICAgIHJlbW92ZSgpIHt9LFxuICAgIH07XG4iLCIndXNlIHN0cmljdCc7XG5cbi8qKlxuICogQ2FsY3VsYXRlIGRhdGEgbWF4UmF0ZVxuICogQHBhcmFtIHtOdW1iZXJ9IFtzYW1wbGVzQ291bnQ9IDEwXVxuICogQHBhcmFtIHtOdW1iZXJ9IFttaW49IDEwMDBdXG4gKiBAcmV0dXJucyB7RnVuY3Rpb259XG4gKi9cbmZ1bmN0aW9uIHNwZWVkb21ldGVyKHNhbXBsZXNDb3VudCwgbWluKSB7XG4gIHNhbXBsZXNDb3VudCA9IHNhbXBsZXNDb3VudCB8fCAxMDtcbiAgY29uc3QgYnl0ZXMgPSBuZXcgQXJyYXkoc2FtcGxlc0NvdW50KTtcbiAgY29uc3QgdGltZXN0YW1wcyA9IG5ldyBBcnJheShzYW1wbGVzQ291bnQpO1xuICBsZXQgaGVhZCA9IDA7XG4gIGxldCB0YWlsID0gMDtcbiAgbGV0IGZpcnN0U2FtcGxlVFM7XG5cbiAgbWluID0gbWluICE9PSB1bmRlZmluZWQgPyBtaW4gOiAxMDAwO1xuXG4gIHJldHVybiBmdW5jdGlvbiBwdXNoKGNodW5rTGVuZ3RoKSB7XG4gICAgY29uc3Qgbm93ID0gRGF0ZS5ub3coKTtcblxuICAgIGNvbnN0IHN0YXJ0ZWRBdCA9IHRpbWVzdGFtcHNbdGFpbF07XG5cbiAgICBpZiAoIWZpcnN0U2FtcGxlVFMpIHtcbiAgICAgIGZpcnN0U2FtcGxlVFMgPSBub3c7XG4gICAgfVxuXG4gICAgYnl0ZXNbaGVhZF0gPSBjaHVua0xlbmd0aDtcbiAgICB0aW1lc3RhbXBzW2hlYWRdID0gbm93O1xuXG4gICAgbGV0IGkgPSB0YWlsO1xuICAgIGxldCBieXRlc0NvdW50ID0gMDtcblxuICAgIHdoaWxlIChpICE9PSBoZWFkKSB7XG4gICAgICBieXRlc0NvdW50ICs9IGJ5dGVzW2krK107XG4gICAgICBpID0gaSAlIHNhbXBsZXNDb3VudDtcbiAgICB9XG5cbiAgICBoZWFkID0gKGhlYWQgKyAxKSAlIHNhbXBsZXNDb3VudDtcblxuICAgIGlmIChoZWFkID09PSB0YWlsKSB7XG4gICAgICB0YWlsID0gKHRhaWwgKyAxKSAlIHNhbXBsZXNDb3VudDtcbiAgICB9XG5cbiAgICBpZiAobm93IC0gZmlyc3RTYW1wbGVUUyA8IG1pbikge1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIGNvbnN0IHBhc3NlZCA9IHN0YXJ0ZWRBdCAmJiBub3cgLSBzdGFydGVkQXQ7XG5cbiAgICByZXR1cm4gcGFzc2VkID8gTWF0aC5yb3VuZCgoYnl0ZXNDb3VudCAqIDEwMDApIC8gcGFzc2VkKSA6IHVuZGVmaW5lZDtcbiAgfTtcbn1cblxuZXhwb3J0IGRlZmF1bHQgc3BlZWRvbWV0ZXI7XG4iLCIvKipcbiAqIFRocm90dGxlIGRlY29yYXRvclxuICogQHBhcmFtIHtGdW5jdGlvbn0gZm5cbiAqIEBwYXJhbSB7TnVtYmVyfSBmcmVxXG4gKiBAcmV0dXJuIHtBcnJheTxGdW5jdGlvbj59XG4gKi9cbmZ1bmN0aW9uIHRocm90dGxlKGZuLCBmcmVxKSB7XG4gIGxldCB0aW1lc3RhbXAgPSAwO1xuICBsZXQgdGhyZXNob2xkID0gMTAwMCAvIGZyZXE7XG4gIGxldCBsYXN0QXJncztcbiAgbGV0IHRpbWVyO1xuXG4gIGNvbnN0IGludm9rZSA9IChhcmdzLCBub3cgPSBEYXRlLm5vdygpKSA9PiB7XG4gICAgdGltZXN0YW1wID0gbm93O1xuICAgIGxhc3RBcmdzID0gbnVsbDtcbiAgICBpZiAodGltZXIpIHtcbiAgICAgIGNsZWFyVGltZW91dCh0aW1lcik7XG4gICAgICB0aW1lciA9IG51bGw7XG4gICAgfVxuICAgIGZuKC4uLmFyZ3MpO1xuICB9O1xuXG4gIGNvbnN0IHRocm90dGxlZCA9ICguLi5hcmdzKSA9PiB7XG4gICAgY29uc3Qgbm93ID0gRGF0ZS5ub3coKTtcbiAgICBjb25zdCBwYXNzZWQgPSBub3cgLSB0aW1lc3RhbXA7XG4gICAgaWYgKHBhc3NlZCA+PSB0aHJlc2hvbGQpIHtcbiAgICAgIGludm9rZShhcmdzLCBub3cpO1xuICAgIH0gZWxzZSB7XG4gICAgICBsYXN0QXJncyA9IGFyZ3M7XG4gICAgICBpZiAoIXRpbWVyKSB7XG4gICAgICAgIHRpbWVyID0gc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgICAgdGltZXIgPSBudWxsO1xuICAgICAgICAgIGludm9rZShsYXN0QXJncyk7XG4gICAgICAgIH0sIHRocmVzaG9sZCAtIHBhc3NlZCk7XG4gICAgICB9XG4gICAgfVxuICB9O1xuXG4gIGNvbnN0IGZsdXNoID0gKCkgPT4gbGFzdEFyZ3MgJiYgaW52b2tlKGxhc3RBcmdzKTtcbiAgY29uc3QgZmx1c2hXaXRoID0gKC4uLmFyZ3MpID0+IGludm9rZShhcmdzKTtcblxuICByZXR1cm4gW3Rocm90dGxlZCwgZmx1c2gsIGZsdXNoV2l0aF07XG59XG5cbmV4cG9ydCBkZWZhdWx0IHRocm90dGxlO1xuIiwiaW1wb3J0IHNwZWVkb21ldGVyIGZyb20gJy4vc3BlZWRvbWV0ZXIuanMnO1xuaW1wb3J0IHRocm90dGxlIGZyb20gJy4vdGhyb3R0bGUuanMnO1xuaW1wb3J0IHV0aWxzIGZyb20gJy4uL3V0aWxzLmpzJztcblxuZXhwb3J0IGNvbnN0IHByb2dyZXNzRXZlbnRSZWR1Y2VyID0gKGxpc3RlbmVyLCBpc0Rvd25sb2FkU3RyZWFtLCBmcmVxID0gMykgPT4ge1xuICBsZXQgYnl0ZXNOb3RpZmllZCA9IDA7XG4gIGNvbnN0IF9zcGVlZG9tZXRlciA9IHNwZWVkb21ldGVyKDUwLCAyNTApO1xuXG4gIHJldHVybiB0aHJvdHRsZSgoZSkgPT4ge1xuICAgIGlmICghZSB8fCAhdXRpbHMuaXNOdW1iZXIoZS5sb2FkZWQpKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGNvbnN0IHJhd0xvYWRlZCA9IGUubG9hZGVkO1xuICAgIGNvbnN0IHRvdGFsID0gZS5sZW5ndGhDb21wdXRhYmxlID8gZS50b3RhbCA6IHVuZGVmaW5lZDtcbiAgICBjb25zdCBsb2FkZWQgPSBNYXRoLm1heCgwLCB0b3RhbCAhPSBudWxsID8gTWF0aC5taW4ocmF3TG9hZGVkLCB0b3RhbCkgOiByYXdMb2FkZWQpO1xuICAgIGNvbnN0IHByb2dyZXNzQnl0ZXMgPSBNYXRoLm1heCgwLCBsb2FkZWQgLSBieXRlc05vdGlmaWVkKTtcbiAgICBjb25zdCByYXRlID0gX3NwZWVkb21ldGVyKHByb2dyZXNzQnl0ZXMpO1xuXG4gICAgYnl0ZXNOb3RpZmllZCA9IE1hdGgubWF4KGJ5dGVzTm90aWZpZWQsIGxvYWRlZCk7XG5cbiAgICBjb25zdCBkYXRhID0ge1xuICAgICAgbG9hZGVkLFxuICAgICAgdG90YWwsXG4gICAgICBwcm9ncmVzczogdG90YWwgPyBsb2FkZWQgLyB0b3RhbCA6IHVuZGVmaW5lZCxcbiAgICAgIGJ5dGVzOiBwcm9ncmVzc0J5dGVzLFxuICAgICAgcmF0ZTogcmF0ZSA/IHJhdGUgOiB1bmRlZmluZWQsXG4gICAgICBlc3RpbWF0ZWQ6IHJhdGUgJiYgdG90YWwgPyAodG90YWwgLSBsb2FkZWQpIC8gcmF0ZSA6IHVuZGVmaW5lZCxcbiAgICAgIGV2ZW50OiBlLFxuICAgICAgbGVuZ3RoQ29tcHV0YWJsZTogdG90YWwgIT0gbnVsbCxcbiAgICAgIFtpc0Rvd25sb2FkU3RyZWFtID8gJ2Rvd25sb2FkJyA6ICd1cGxvYWQnXTogdHJ1ZSxcbiAgICB9O1xuXG4gICAgbGlzdGVuZXIoZGF0YSk7XG4gIH0sIGZyZXEpO1xufTtcblxuZXhwb3J0IGNvbnN0IHByb2dyZXNzRXZlbnREZWNvcmF0b3IgPSAodG90YWwsIHRocm90dGxlZCkgPT4ge1xuICBjb25zdCBsZW5ndGhDb21wdXRhYmxlID0gdG90YWwgIT0gbnVsbDtcblxuICByZXR1cm4gW1xuICAgIChsb2FkZWQpID0+XG4gICAgICB0aHJvdHRsZWRbMF0oe1xuICAgICAgICBsZW5ndGhDb21wdXRhYmxlLFxuICAgICAgICB0b3RhbCxcbiAgICAgICAgbG9hZGVkLFxuICAgICAgfSksXG4gICAgdGhyb3R0bGVkWzFdLFxuICBdO1xufTtcblxuZXhwb3J0IGNvbnN0IGFzeW5jRGVjb3JhdG9yID1cbiAgKGZuLCBzY2hlZHVsZXIgPSB1dGlscy5hc2FwKSA9PlxuICAoLi4uYXJncykgPT5cbiAgICBzY2hlZHVsZXIoKCkgPT4gZm4oLi4uYXJncykpO1xuIiwiaW1wb3J0IHBsYXRmb3JtIGZyb20gJy4uL3BsYXRmb3JtL2luZGV4LmpzJztcblxuZXhwb3J0IGRlZmF1bHQgcGxhdGZvcm0uaGFzU3RhbmRhcmRCcm93c2VyRW52XG4gID8gKChvcmlnaW4pID0+ICh1cmwpID0+IHtcbiAgICAgIHVybCA9IG5ldyBVUkwodXJsLCBkb2N1bWVudC5iYXNlVVJJIHx8IHBsYXRmb3JtLm9yaWdpbik7XG5cbiAgICAgIHJldHVybiAoXG4gICAgICAgIG9yaWdpbi5wcm90b2NvbCA9PT0gdXJsLnByb3RvY29sICYmIG9yaWdpbi5ob3N0ID09PSB1cmwuaG9zdCAmJiBvcmlnaW4ucG9ydCA9PT0gdXJsLnBvcnRcbiAgICAgICk7XG4gICAgfSkobmV3IFVSTChwbGF0Zm9ybS5vcmlnaW4pKVxuICA6ICgpID0+IHRydWU7XG4iLCIndXNlIHN0cmljdCc7XG5cbi8qKlxuICogRGV0ZXJtaW5lcyB3aGV0aGVyIHRoZSBzcGVjaWZpZWQgVVJMIGlzIGFic29sdXRlXG4gKlxuICogQHBhcmFtIHtzdHJpbmd9IHVybCBUaGUgVVJMIHRvIHRlc3RcbiAqXG4gKiBAcmV0dXJucyB7Ym9vbGVhbn0gVHJ1ZSBpZiB0aGUgc3BlY2lmaWVkIFVSTCBpcyBhYnNvbHV0ZSwgb3RoZXJ3aXNlIGZhbHNlXG4gKi9cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIGlzQWJzb2x1dGVVUkwodXJsKSB7XG4gIC8vIEEgVVJMIGlzIGNvbnNpZGVyZWQgYWJzb2x1dGUgaWYgaXQgYmVnaW5zIHdpdGggXCI8c2NoZW1lPjovL1wiIG9yIFwiLy9cIiAocHJvdG9jb2wtcmVsYXRpdmUgVVJMKS5cbiAgLy8gUkZDIDM5ODYgZGVmaW5lcyBzY2hlbWUgbmFtZSBhcyBhIHNlcXVlbmNlIG9mIGNoYXJhY3RlcnMgYmVnaW5uaW5nIHdpdGggYSBsZXR0ZXIgYW5kIGZvbGxvd2VkXG4gIC8vIGJ5IGFueSBjb21iaW5hdGlvbiBvZiBsZXR0ZXJzLCBkaWdpdHMsIHBsdXMsIHBlcmlvZCwgb3IgaHlwaGVuLlxuICBpZiAodHlwZW9mIHVybCAhPT0gJ3N0cmluZycpIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cblxuICByZXR1cm4gL14oW2Etel1bYS16XFxkK1xcLS5dKjopP1xcL1xcLy9pLnRlc3QodXJsKTtcbn1cbiIsIid1c2Ugc3RyaWN0JztcblxuLyoqXG4gKiBDcmVhdGVzIGEgbmV3IFVSTCBieSBjb21iaW5pbmcgdGhlIHNwZWNpZmllZCBVUkxzXG4gKlxuICogQHBhcmFtIHtzdHJpbmd9IGJhc2VVUkwgVGhlIGJhc2UgVVJMXG4gKiBAcGFyYW0ge3N0cmluZ30gcmVsYXRpdmVVUkwgVGhlIHJlbGF0aXZlIFVSTFxuICpcbiAqIEByZXR1cm5zIHtzdHJpbmd9IFRoZSBjb21iaW5lZCBVUkxcbiAqL1xuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gY29tYmluZVVSTHMoYmFzZVVSTCwgcmVsYXRpdmVVUkwpIHtcbiAgaWYgKCFyZWxhdGl2ZVVSTCkge1xuICAgIHJldHVybiBiYXNlVVJMO1xuICB9XG5cbiAgbGV0IGVuZCA9IGJhc2VVUkwubGVuZ3RoO1xuXG4gIHdoaWxlIChlbmQgPiAwICYmIGJhc2VVUkwuY2hhckNvZGVBdChlbmQgLSAxKSA9PT0gNDcpIHtcbiAgICBlbmQtLTtcbiAgfVxuXG4gIHJldHVybiBiYXNlVVJMLnNsaWNlKDAsIGVuZCkgKyAnLycgKyByZWxhdGl2ZVVSTC5yZXBsYWNlKC9eXFwvKy8sICcnKTtcbn1cbiIsIid1c2Ugc3RyaWN0JztcblxuaW1wb3J0IEF4aW9zRXJyb3IsIHsgUkVEQUNURUQgfSBmcm9tICcuL0F4aW9zRXJyb3IuanMnO1xuaW1wb3J0IGlzQWJzb2x1dGVVUkwgZnJvbSAnLi4vaGVscGVycy9pc0Fic29sdXRlVVJMLmpzJztcbmltcG9ydCBjb21iaW5lVVJMcyBmcm9tICcuLi9oZWxwZXJzL2NvbWJpbmVVUkxzLmpzJztcbmltcG9ydCBub3JtYWxpemVVUkxGb3JQcm90b2NvbENoZWNrIGZyb20gJy4uL2hlbHBlcnMvbm9ybWFsaXplVVJMRm9yUHJvdG9jb2xDaGVjay5qcyc7XG5cbmNvbnN0IG1hbGZvcm1lZEh0dHBQcm90b2NvbCA9IC9eaHR0cHM/Oig/IVxcL1xcLykvaTtcblxuLy8gUmVkYWN0IHRoZSBwYXJ0cyBvZiBhIFVSTCB0aGF0IGNhbiBjYXJyeSBzZWNyZXRzIGJlZm9yZSBpdCBpcyBlbWJlZGRlZCBpbiBhblxuLy8gZXJyb3IgbWVzc2FnZS4gQXhpb3NFcnJvci50b0pTT04oKSBzZXJpYWxpemVzIGBtZXNzYWdlYCB2ZXJiYXRpbSBhbmQgZXJyb3JzXG4vLyBhcmUgY29tbW9ubHkgbG9nZ2VkLCB3aGlsZSB0aGUgb3B0LWluIGBjb25maWcucmVkYWN0YCBtb2RlbCBvbmx5IGNsZWFuc1xuLy8gY29uZmlnIGtleXMg4oCUIGl0IGNhbm5vdCByZWFjaCB0aGUgbWVzc2FnZS4gUmVkYWN0IG9ubHkgdGhlIGdlbnVpbmVseVxuLy8gc2Vuc2l0aXZlIHN1YnN0cmluZ3Mg4oCUIHVzZXJpbmZvIChjcmVkZW50aWFscyksIHF1ZXJ5IHBhcmFtZXRlciB2YWx1ZXMgYW5kXG4vLyBmcmFnbWVudCBjb250ZW50cyDigJQgd2l0aCB0aGUgc2FtZSBSRURBQ1RFRCBtYXJrZXIgdGhlIGNvbmZpZyByZWRhY3Rpb24gdXNlcyxcbi8vIHdoaWxlIGtlZXBpbmcgdGhlIHNjaGVtZSwgaG9zdCwgcGF0aCBhbmQgcGFyYW1ldGVyIG5hbWVzIHNvIHRoZSBvZmZlbmRpbmdcbi8vIHJlcXVlc3Qgc3RheXMgYWNjdXJhdGVseSBpZGVudGlmaWFibGUuXG5mdW5jdGlvbiByZWRhY3RGcmFnbWVudChmcmFnbWVudCkge1xuICBpZiAoIWZyYWdtZW50KSB7XG4gICAgcmV0dXJuIGZyYWdtZW50O1xuICB9XG5cbiAgcmV0dXJuIGZyYWdtZW50LnJlcGxhY2UoLyhefCYpKFtePSZdKj0pP1teJl0rL2csIChtYXRjaCwgc2VwYXJhdG9yLCBwYXJhbWV0ZXJOYW1lID0gJycpID0+IHtcbiAgICByZXR1cm4gYCR7c2VwYXJhdG9yfSR7cGFyYW1ldGVyTmFtZX0ke1JFREFDVEVEfWA7XG4gIH0pO1xufVxuXG5mdW5jdGlvbiByZWRhY3RTZW5zaXRpdmVVUkxQYXJ0cyh1cmwpIHtcbiAgY29uc3QgcmVkYWN0ZWRVUkwgPSB1cmwucmVwbGFjZSgvXihodHRwcz86XFwvezAsMn0pW14vPyNdKkAvaSwgYCQxJHtSRURBQ1RFRH1AYCk7XG4gIGNvbnN0IGZyYWdtZW50SW5kZXggPSByZWRhY3RlZFVSTC5pbmRleE9mKCcjJyk7XG4gIGNvbnN0IHVybFdpdGhvdXRGcmFnbWVudCA9XG4gICAgZnJhZ21lbnRJbmRleCA9PT0gLTEgPyByZWRhY3RlZFVSTCA6IHJlZGFjdGVkVVJMLnNsaWNlKDAsIGZyYWdtZW50SW5kZXgpO1xuICBjb25zdCByZWRhY3RlZFVSTFdpdGhvdXRGcmFnbWVudCA9IHVybFdpdGhvdXRGcmFnbWVudC5yZXBsYWNlKFxuICAgIC8oWz8mXVtePSYjXSo9KVteJiNdKi9nLFxuICAgIGAkMSR7UkVEQUNURUR9YFxuICApO1xuXG4gIGlmIChmcmFnbWVudEluZGV4ID09PSAtMSkge1xuICAgIHJldHVybiByZWRhY3RlZFVSTFdpdGhvdXRGcmFnbWVudDtcbiAgfVxuXG4gIHJldHVybiBgJHtyZWRhY3RlZFVSTFdpdGhvdXRGcmFnbWVudH0jJHtyZWRhY3RGcmFnbWVudChyZWRhY3RlZFVSTC5zbGljZShmcmFnbWVudEluZGV4ICsgMSkpfWA7XG59XG5cbmZ1bmN0aW9uIGFzc2VydFZhbGlkSHR0cFByb3RvY29sVVJMKHVybCwgY29uZmlnKSB7XG4gIGlmICh0eXBlb2YgdXJsID09PSAnc3RyaW5nJykge1xuICAgIGNvbnN0IG5vcm1hbGl6ZWRVUkwgPSBub3JtYWxpemVVUkxGb3JQcm90b2NvbENoZWNrKHVybCk7XG4gICAgaWYgKG1hbGZvcm1lZEh0dHBQcm90b2NvbC50ZXN0KG5vcm1hbGl6ZWRVUkwpKSB7XG4gICAgICB0aHJvdyBuZXcgQXhpb3NFcnJvcihcbiAgICAgICAgYEludmFsaWQgVVJMICR7SlNPTi5zdHJpbmdpZnkocmVkYWN0U2Vuc2l0aXZlVVJMUGFydHMobm9ybWFsaXplZFVSTCkpfTogbWlzc2luZyBcIi8vXCIgYWZ0ZXIgcHJvdG9jb2xgLFxuICAgICAgICBBeGlvc0Vycm9yLkVSUl9JTlZBTElEX1VSTCxcbiAgICAgICAgY29uZmlnXG4gICAgICApO1xuICAgIH1cbiAgfVxufVxuXG4vKipcbiAqIENyZWF0ZXMgYSBuZXcgVVJMIGJ5IGNvbWJpbmluZyB0aGUgYmFzZVVSTCB3aXRoIHRoZSByZXF1ZXN0ZWRVUkwsXG4gKiBvbmx5IHdoZW4gdGhlIHJlcXVlc3RlZFVSTCBpcyBub3QgYWxyZWFkeSBhbiBhYnNvbHV0ZSBVUkwuXG4gKiBJZiB0aGUgcmVxdWVzdFVSTCBpcyBhYnNvbHV0ZSwgdGhpcyBmdW5jdGlvbiByZXR1cm5zIHRoZSByZXF1ZXN0ZWRVUkwgdW50b3VjaGVkLlxuICpcbiAqIEBwYXJhbSB7c3RyaW5nfSBiYXNlVVJMIFRoZSBiYXNlIFVSTFxuICogQHBhcmFtIHtzdHJpbmd9IHJlcXVlc3RlZFVSTCBBYnNvbHV0ZSBvciByZWxhdGl2ZSBVUkwgdG8gY29tYmluZVxuICpcbiAqIEByZXR1cm5zIHtzdHJpbmd9IFRoZSBjb21iaW5lZCBmdWxsIHBhdGhcbiAqL1xuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gYnVpbGRGdWxsUGF0aChiYXNlVVJMLCByZXF1ZXN0ZWRVUkwsIGFsbG93QWJzb2x1dGVVcmxzLCBjb25maWcpIHtcbiAgYXNzZXJ0VmFsaWRIdHRwUHJvdG9jb2xVUkwocmVxdWVzdGVkVVJMLCBjb25maWcpO1xuICBsZXQgaXNSZWxhdGl2ZVVybCA9ICFpc0Fic29sdXRlVVJMKHJlcXVlc3RlZFVSTCk7XG4gIGlmIChiYXNlVVJMICYmIChpc1JlbGF0aXZlVXJsIHx8IGFsbG93QWJzb2x1dGVVcmxzID09PSBmYWxzZSkpIHtcbiAgICBhc3NlcnRWYWxpZEh0dHBQcm90b2NvbFVSTChiYXNlVVJMLCBjb25maWcpO1xuICAgIHJldHVybiBjb21iaW5lVVJMcyhiYXNlVVJMLCByZXF1ZXN0ZWRVUkwpO1xuICB9XG4gIHJldHVybiByZXF1ZXN0ZWRVUkw7XG59XG4iLCIndXNlIHN0cmljdCc7XG5cbmltcG9ydCB1dGlscyBmcm9tICcuLi91dGlscy5qcyc7XG5pbXBvcnQgQXhpb3NFcnJvciBmcm9tICcuL0F4aW9zRXJyb3IuanMnO1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBhc3NlcnRQYXJhbXNBY3ljbGljKHBhcmFtcykge1xuICBjb25zdCBwZW5kaW5nID0gW3sgdmFsdWU6IHBhcmFtcyB9XTtcbiAgY29uc3QgYWN0aXZlID0gbmV3IFdlYWtTZXQoKTtcbiAgY29uc3QgdmlzaXRlZCA9IG5ldyBXZWFrU2V0KCk7XG5cbiAgd2hpbGUgKHBlbmRpbmcubGVuZ3RoKSB7XG4gICAgY29uc3QgeyB2YWx1ZSwgZG9uZSB9ID0gcGVuZGluZy5wb3AoKTtcbiAgICBpZiAoIXV0aWxzLmlzUGxhaW5PYmplY3QodmFsdWUpICYmICF1dGlscy5pc0FycmF5KHZhbHVlKSkgY29udGludWU7XG4gICAgaWYgKGRvbmUpIHtcbiAgICAgIGFjdGl2ZS5kZWxldGUodmFsdWUpO1xuICAgICAgY29udGludWU7XG4gICAgfVxuICAgIGlmIChhY3RpdmUuaGFzKHZhbHVlKSkge1xuICAgICAgdGhyb3cgbmV3IEF4aW9zRXJyb3IoXG4gICAgICAgICdDaXJjdWxhciByZWZlcmVuY2UgZGV0ZWN0ZWQgaW4gcGFyYW1zJyxcbiAgICAgICAgQXhpb3NFcnJvci5FUlJfQkFEX09QVElPTl9WQUxVRVxuICAgICAgKTtcbiAgICB9XG4gICAgaWYgKHZpc2l0ZWQuaGFzKHZhbHVlKSkgY29udGludWU7XG4gICAgdmlzaXRlZC5hZGQodmFsdWUpO1xuICAgIGFjdGl2ZS5hZGQodmFsdWUpO1xuICAgIHBlbmRpbmcucHVzaCh7IHZhbHVlLCBkb25lOiB0cnVlIH0pO1xuXG4gICAgY29uc3Qga2V5cyA9IE9iamVjdC5rZXlzKHZhbHVlKTtcbiAgICBpZiAoT2JqZWN0LmdldE93blByb3BlcnR5U3ltYm9scyAmJiBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yKSB7XG4gICAgICBPYmplY3QuZ2V0T3duUHJvcGVydHlTeW1ib2xzKHZhbHVlKS5mb3JFYWNoKChrZXkpID0+IHtcbiAgICAgICAgY29uc3QgZGVzY3JpcHRvciA9IE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3IodmFsdWUsIGtleSk7XG4gICAgICAgIGlmIChkZXNjcmlwdG9yICYmIGRlc2NyaXB0b3IuZW51bWVyYWJsZSkga2V5cy5wdXNoKGtleSk7XG4gICAgICB9KTtcbiAgICB9XG4gICAgLy8gU2hhbGxvdyBhcnJheSBlbGVtZW50cyByZXRhaW4gZmllbGRzIGZpbHRlcmVkIGR1cmluZyBwbGFpbi1vYmplY3QgbWVyZ2VzLlxuICAgIC8vIEluc3BlY3QgcmVzZXJ2ZWQgZGF0YSBwcm9wZXJ0aWVzIHdpdGhvdXQgZXZhbHVhdGluZyB0aGVpciBhY2Nlc3NvcnMuXG4gICAga2V5cy5mb3JFYWNoKChrZXkpID0+IHtcbiAgICAgIGlmIChrZXkgPT09ICdfX3Byb3RvX18nIHx8IGtleSA9PT0gJ2NvbnN0cnVjdG9yJyB8fCBrZXkgPT09ICdwcm90b3R5cGUnKSB7XG4gICAgICAgIGNvbnN0IGRlc2NyaXB0b3IgPSBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yKHZhbHVlLCBrZXkpO1xuICAgICAgICBpZiAoZGVzY3JpcHRvciAmJiB1dGlscy5oYXNPd25Qcm9wKGRlc2NyaXB0b3IsICd2YWx1ZScpKSB7XG4gICAgICAgICAgcGVuZGluZy5wdXNoKHsgdmFsdWU6IGRlc2NyaXB0b3IudmFsdWUgfSk7XG4gICAgICAgIH1cbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHBlbmRpbmcucHVzaCh7IHZhbHVlOiB2YWx1ZVtrZXldIH0pO1xuICAgICAgfVxuICAgIH0pO1xuICB9XG59XG4iLCIndXNlIHN0cmljdCc7XG5cbmltcG9ydCB1dGlscyBmcm9tICcuLi91dGlscy5qcyc7XG5pbXBvcnQgQXhpb3NIZWFkZXJzIGZyb20gJy4vQXhpb3NIZWFkZXJzLmpzJztcbmltcG9ydCBhc3NlcnRQYXJhbXNBY3ljbGljIGZyb20gJy4vYXNzZXJ0UGFyYW1zQWN5Y2xpYy5qcyc7XG5cbmNvbnN0IGhlYWRlcnNUb09iamVjdCA9ICh0aGluZykgPT4gKHRoaW5nIGluc3RhbmNlb2YgQXhpb3NIZWFkZXJzID8geyAuLi50aGluZyB9IDogdGhpbmcpO1xuXG5jb25zdCBvd25FbnVtZXJhYmxlS2V5cyA9ICh0aGluZykgPT4ge1xuICBpZiAoT2JqZWN0LmdldE93blByb3BlcnR5U3ltYm9scyAmJiBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yKSB7XG4gICAgcmV0dXJuIE9iamVjdC5rZXlzKHRoaW5nKS5jb25jYXQoXG4gICAgICBPYmplY3QuZ2V0T3duUHJvcGVydHlTeW1ib2xzKHRoaW5nKS5maWx0ZXIoKHN5bWJvbCkgPT4ge1xuICAgICAgICBjb25zdCBkZXNjcmlwdG9yID0gT2JqZWN0LmdldE93blByb3BlcnR5RGVzY3JpcHRvcih0aGluZywgc3ltYm9sKTtcbiAgICAgICAgcmV0dXJuIGRlc2NyaXB0b3IgJiYgZGVzY3JpcHRvci5lbnVtZXJhYmxlO1xuICAgICAgfSlcbiAgICApO1xuICB9XG4gIHJldHVybiBPYmplY3Qua2V5cyh0aGluZyk7XG59O1xuXG4vLyBDb3B5IHBhcmFtcyB3aXRob3V0IHJlY3Vyc2l2ZSBtZXJnZXMgc28gdGhlIHNlcmlhbGl6ZXIgcmVtYWlucyByZXNwb25zaWJsZVxuLy8gZm9yIGl0cyBkZXB0aCBwb2xpY3kuIE9ubHkgdmlzaXQgZGVmYXVsdHMgdGhhdCBjb250cmlidXRlIHRvIHRoZSByZXN1bHQuXG5mdW5jdGlvbiBtZXJnZVBhcmFtcyhhLCBiKSB7XG4gIGNvbnN0IHBlbmRpbmcgPSBbXTtcbiAgY29uc3QgY29waWVzID0gbmV3IFdlYWtNYXAoKTtcbiAgY29uc3QgZW1wdHkgPSB7fTtcblxuICBmdW5jdGlvbiBjb3B5KHRhcmdldCwgc291cmNlKSB7XG4gICAgaWYgKCF1dGlscy5pc1BsYWluT2JqZWN0KHNvdXJjZSkpIHtcbiAgICAgIHJldHVybiB1dGlscy5pc0FycmF5KHNvdXJjZSkgPyBzb3VyY2Uuc2xpY2UoKSA6IHNvdXJjZTtcbiAgICB9XG5cbiAgICBjb25zdCBiYXNlID0gdXRpbHMuaXNQbGFpbk9iamVjdCh0YXJnZXQpID8gdGFyZ2V0IDogZW1wdHk7XG4gICAgbGV0IGJhc2VzID0gY29waWVzLmdldChzb3VyY2UpO1xuICAgIGlmICghYmFzZXMpIHtcbiAgICAgIGJhc2VzID0gbmV3IFdlYWtNYXAoKTtcbiAgICAgIGNvcGllcy5zZXQoc291cmNlLCBiYXNlcyk7XG4gICAgfVxuICAgIGlmIChiYXNlcy5oYXMoYmFzZSkpIHJldHVybiBiYXNlcy5nZXQoYmFzZSk7XG5cbiAgICBjb25zdCByZXN1bHQgPSB7fTtcbiAgICBiYXNlcy5zZXQoYmFzZSwgcmVzdWx0KTtcbiAgICBwZW5kaW5nLnB1c2goeyBiYXNlLCBzb3VyY2UsIHJlc3VsdCB9KTtcbiAgICByZXR1cm4gcmVzdWx0O1xuICB9XG5cbiAgY29uc3QgcmVzdWx0ID0gdXRpbHMuaXNVbmRlZmluZWQoYikgPyBjb3B5KHVuZGVmaW5lZCwgYSkgOiBjb3B5KGEsIGIpO1xuICB3aGlsZSAocGVuZGluZy5sZW5ndGgpIHtcbiAgICBjb25zdCB7IGJhc2UsIHNvdXJjZSwgcmVzdWx0OiB0YXJnZXQgfSA9IHBlbmRpbmcucG9wKCk7XG4gICAgY29uc3QgYmFzZUtleXMgPSBuZXcgU2V0KG93bkVudW1lcmFibGVLZXlzKGJhc2UpKTtcbiAgICBjb25zdCBzb3VyY2VLZXlzID0gbmV3IFNldChvd25FbnVtZXJhYmxlS2V5cyhzb3VyY2UpKTtcbiAgICBjb25zdCBrZXlzID0gbmV3IFNldChbLi4uYmFzZUtleXMsIC4uLnNvdXJjZUtleXNdKTtcblxuICAgIGtleXMuZm9yRWFjaCgoa2V5KSA9PiB7XG4gICAgICBpZiAoa2V5ID09PSAnX19wcm90b19fJyB8fCBrZXkgPT09ICdjb25zdHJ1Y3RvcicgfHwga2V5ID09PSAncHJvdG90eXBlJykgcmV0dXJuO1xuICAgICAgY29uc3QgaGFzU291cmNlID0gc291cmNlS2V5cy5oYXMoa2V5KTtcbiAgICAgIGNvbnN0IHZhbHVlID0gaGFzU291cmNlID8gc291cmNlW2tleV0gOiB1bmRlZmluZWQ7XG4gICAgICBjb25zdCBwcmV2aW91cyA9XG4gICAgICAgICghaGFzU291cmNlIHx8IHV0aWxzLmlzUGxhaW5PYmplY3QodmFsdWUpKSAmJiBiYXNlS2V5cy5oYXMoa2V5KSA/IGJhc2Vba2V5XSA6IHVuZGVmaW5lZDtcbiAgICAgIHRhcmdldFtrZXldID0gaGFzU291cmNlID8gY29weShwcmV2aW91cywgdmFsdWUpIDogY29weSh1bmRlZmluZWQsIHByZXZpb3VzKTtcbiAgICB9KTtcbiAgfVxuXG4gIGFzc2VydFBhcmFtc0FjeWNsaWMocmVzdWx0KTtcbiAgcmV0dXJuIHJlc3VsdDtcbn1cblxuZnVuY3Rpb24gZ2V0TWVyZ2VkVmFsdWUodGFyZ2V0LCBzb3VyY2UsIHByb3AsIGNhc2VsZXNzKSB7XG4gIGlmICh1dGlscy5pc1BsYWluT2JqZWN0KHRhcmdldCkgJiYgdXRpbHMuaXNQbGFpbk9iamVjdChzb3VyY2UpKSB7XG4gICAgcmV0dXJuIHV0aWxzLm1lcmdlLmNhbGwoeyBjYXNlbGVzcyB9LCB0YXJnZXQsIHNvdXJjZSk7XG4gIH0gZWxzZSBpZiAodXRpbHMuaXNQbGFpbk9iamVjdChzb3VyY2UpKSB7XG4gICAgcmV0dXJuIHV0aWxzLm1lcmdlKHt9LCBzb3VyY2UpO1xuICB9IGVsc2UgaWYgKHV0aWxzLmlzQXJyYXkoc291cmNlKSkge1xuICAgIHJldHVybiBzb3VyY2Uuc2xpY2UoKTtcbiAgfVxuICByZXR1cm4gc291cmNlO1xufVxuXG5mdW5jdGlvbiBtZXJnZURlZXBQcm9wZXJ0aWVzKGEsIGIsIHByb3AsIGNhc2VsZXNzKSB7XG4gIGlmICghdXRpbHMuaXNVbmRlZmluZWQoYikpIHtcbiAgICByZXR1cm4gZ2V0TWVyZ2VkVmFsdWUoYSwgYiwgcHJvcCwgY2FzZWxlc3MpO1xuICB9IGVsc2UgaWYgKCF1dGlscy5pc1VuZGVmaW5lZChhKSkge1xuICAgIHJldHVybiBnZXRNZXJnZWRWYWx1ZSh1bmRlZmluZWQsIGEsIHByb3AsIGNhc2VsZXNzKTtcbiAgfVxufVxuXG4vLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgY29uc2lzdGVudC1yZXR1cm5cbmZ1bmN0aW9uIHZhbHVlRnJvbUNvbmZpZzIoYSwgYikge1xuICBpZiAoIXV0aWxzLmlzVW5kZWZpbmVkKGIpKSB7XG4gICAgcmV0dXJuIGdldE1lcmdlZFZhbHVlKHVuZGVmaW5lZCwgYik7XG4gIH1cbn1cblxuLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIGNvbnNpc3RlbnQtcmV0dXJuXG5mdW5jdGlvbiBkZWZhdWx0VG9Db25maWcyKGEsIGIpIHtcbiAgaWYgKCF1dGlscy5pc1VuZGVmaW5lZChiKSkge1xuICAgIHJldHVybiBnZXRNZXJnZWRWYWx1ZSh1bmRlZmluZWQsIGIpO1xuICB9IGVsc2UgaWYgKCF1dGlscy5pc1VuZGVmaW5lZChhKSkge1xuICAgIHJldHVybiBnZXRNZXJnZWRWYWx1ZSh1bmRlZmluZWQsIGEpO1xuICB9XG59XG5cbmZ1bmN0aW9uIGdldE1lcmdlZFRyYW5zaXRpb25hbE9wdGlvbihjb25maWcxLCBjb25maWcyLCBwcm9wKSB7XG4gIGNvbnN0IHRyYW5zaXRpb25hbDIgPSB1dGlscy5oYXNPd25Qcm9wKGNvbmZpZzIsICd0cmFuc2l0aW9uYWwnKVxuICAgID8gY29uZmlnMi50cmFuc2l0aW9uYWxcbiAgICA6IHVuZGVmaW5lZDtcblxuICBpZiAoIXV0aWxzLmlzVW5kZWZpbmVkKHRyYW5zaXRpb25hbDIpKSB7XG4gICAgaWYgKHV0aWxzLmlzUGxhaW5PYmplY3QodHJhbnNpdGlvbmFsMikpIHtcbiAgICAgIGlmICh1dGlscy5oYXNPd25Qcm9wKHRyYW5zaXRpb25hbDIsIHByb3ApKSB7XG4gICAgICAgIHJldHVybiB0cmFuc2l0aW9uYWwyW3Byb3BdO1xuICAgICAgfVxuICAgIH0gZWxzZSB7XG4gICAgICByZXR1cm4gdW5kZWZpbmVkO1xuICAgIH1cbiAgfVxuXG4gIGNvbnN0IHRyYW5zaXRpb25hbDEgPSB1dGlscy5oYXNPd25Qcm9wKGNvbmZpZzEsICd0cmFuc2l0aW9uYWwnKVxuICAgID8gY29uZmlnMS50cmFuc2l0aW9uYWxcbiAgICA6IHVuZGVmaW5lZDtcblxuICBpZiAodXRpbHMuaXNQbGFpbk9iamVjdCh0cmFuc2l0aW9uYWwxKSAmJiB1dGlscy5oYXNPd25Qcm9wKHRyYW5zaXRpb25hbDEsIHByb3ApKSB7XG4gICAgcmV0dXJuIHRyYW5zaXRpb25hbDFbcHJvcF07XG4gIH1cblxuICByZXR1cm4gdW5kZWZpbmVkO1xufVxuXG4vLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgY29uc2lzdGVudC1yZXR1cm5cbmZ1bmN0aW9uIG1lcmdlRGlyZWN0S2V5cyhhLCBiLCBwcm9wLCBjb25maWcxLCBjb25maWcyKSB7XG4gIGlmICh1dGlscy5oYXNPd25Qcm9wKGNvbmZpZzIsIHByb3ApKSB7XG4gICAgcmV0dXJuIGdldE1lcmdlZFZhbHVlKGEsIGIpO1xuICB9IGVsc2UgaWYgKHV0aWxzLmhhc093blByb3AoY29uZmlnMSwgcHJvcCkpIHtcbiAgICByZXR1cm4gZ2V0TWVyZ2VkVmFsdWUodW5kZWZpbmVkLCBhKTtcbiAgfVxufVxuXG5mdW5jdGlvbiBtZXJnZUhlYWRlcnMoYSwgYiwgcHJvcCkge1xuICByZXR1cm4gbWVyZ2VEZWVwUHJvcGVydGllcyhoZWFkZXJzVG9PYmplY3QoYSksIGhlYWRlcnNUb09iamVjdChiKSwgcHJvcCwgdHJ1ZSk7XG59XG5cbi8vIE51bGwtcHJvdG8sIGZyb3plbiBkZXNjcmlwdG9yIHNvIGEgcG9sbHV0ZWQgT2JqZWN0LnByb3RvdHlwZS5nZXQgY2Fubm90IHR1cm5cbi8vIHRoaXMgZGF0YSBkZXNjcmlwdG9yIGludG8gYW4gYWNjZXNzb3IgZGVzY3JpcHRvciBvbiB0aGUgd2F5IGluLlxuLy8gZGVmaW5lUHJvcGVydHkgb25seSByZWFkcyBpdCwgc28gb25lIHNoYXJlZCBpbnN0YW5jZSBzZXJ2ZXMgZXZlcnkgY2FsbC5cbmNvbnN0IGhhc093blByb3BlcnR5RGVzY3JpcHRvciA9IE9iamVjdC5mcmVlemUoe1xuICBfX3Byb3RvX186IG51bGwsXG4gIHZhbHVlOiBPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LFxuICBlbnVtZXJhYmxlOiBmYWxzZSxcbiAgd3JpdGFibGU6IHRydWUsXG4gIGNvbmZpZ3VyYWJsZTogdHJ1ZSxcbn0pO1xuXG4vLyBUaGUgc3RyYXRlZ3kgdGFibGUgYW5kIHRoZSBzdHJhdGVnaWVzIGFib3ZlIGFyZSBzdGF0ZWxlc3MsIHNvIHRoZXkgYXJlXG4vLyBidWlsdCBvbmNlIGF0IG1vZHVsZSBsb2FkIGluc3RlYWQgb2Ygb24gZXZlcnkgY2FsbDogbWVyZ2VDb25maWcgcnVucyBhdFxuLy8gbW9zdCB0d2ljZSBwZXIgcmVxdWVzdCAob25jZSBmcm9tIGEgbWV0aG9kIGFsaWFzLCBvbmNlIGZyb20gYF9yZXF1ZXN0YCkuXG5jb25zdCBtZXJnZU1hcCA9IHtcbiAgdXJsOiB2YWx1ZUZyb21Db25maWcyLFxuICBtZXRob2Q6IHZhbHVlRnJvbUNvbmZpZzIsXG4gIGRhdGE6IHZhbHVlRnJvbUNvbmZpZzIsXG4gIGJhc2VVUkw6IGRlZmF1bHRUb0NvbmZpZzIsXG4gIHRyYW5zZm9ybVJlcXVlc3Q6IGRlZmF1bHRUb0NvbmZpZzIsXG4gIHRyYW5zZm9ybVJlc3BvbnNlOiBkZWZhdWx0VG9Db25maWcyLFxuICBwYXJhbXM6IG1lcmdlUGFyYW1zLFxuICBwYXJhbXNTZXJpYWxpemVyOiBkZWZhdWx0VG9Db25maWcyLFxuICB0aW1lb3V0OiBkZWZhdWx0VG9Db25maWcyLFxuICB0aW1lb3V0RXJyb3JNZXNzYWdlOiBkZWZhdWx0VG9Db25maWcyLFxuICB3aXRoQ3JlZGVudGlhbHM6IGRlZmF1bHRUb0NvbmZpZzIsXG4gIHdpdGhYU1JGVG9rZW46IGRlZmF1bHRUb0NvbmZpZzIsXG4gIGFkYXB0ZXI6IGRlZmF1bHRUb0NvbmZpZzIsXG4gIHJlc3BvbnNlVHlwZTogZGVmYXVsdFRvQ29uZmlnMixcbiAgeHNyZkNvb2tpZU5hbWU6IGRlZmF1bHRUb0NvbmZpZzIsXG4gIHhzcmZIZWFkZXJOYW1lOiBkZWZhdWx0VG9Db25maWcyLFxuICBvblVwbG9hZFByb2dyZXNzOiBkZWZhdWx0VG9Db25maWcyLFxuICBvbkRvd25sb2FkUHJvZ3Jlc3M6IGRlZmF1bHRUb0NvbmZpZzIsXG4gIGRlY29tcHJlc3M6IGRlZmF1bHRUb0NvbmZpZzIsXG4gIG1heENvbnRlbnRMZW5ndGg6IGRlZmF1bHRUb0NvbmZpZzIsXG4gIG1heEJvZHlMZW5ndGg6IGRlZmF1bHRUb0NvbmZpZzIsXG4gIGJlZm9yZVJlZGlyZWN0OiBkZWZhdWx0VG9Db25maWcyLFxuICB0cmFuc3BvcnQ6IGRlZmF1bHRUb0NvbmZpZzIsXG4gIGh0dHBBZ2VudDogZGVmYXVsdFRvQ29uZmlnMixcbiAgaHR0cHNBZ2VudDogZGVmYXVsdFRvQ29uZmlnMixcbiAgY2FuY2VsVG9rZW46IGRlZmF1bHRUb0NvbmZpZzIsXG4gIHNvY2tldFBhdGg6IGRlZmF1bHRUb0NvbmZpZzIsXG4gIGFsbG93ZWRTb2NrZXRQYXRoczogZGVmYXVsdFRvQ29uZmlnMixcbiAgcmVzcG9uc2VFbmNvZGluZzogZGVmYXVsdFRvQ29uZmlnMixcbiAgdmFsaWRhdGVTdGF0dXM6IG1lcmdlRGlyZWN0S2V5cyxcbiAgaGVhZGVyczogbWVyZ2VIZWFkZXJzLFxufTtcblxuLyoqXG4gKiBDb25maWctc3BlY2lmaWMgbWVyZ2UtZnVuY3Rpb24gd2hpY2ggY3JlYXRlcyBhIG5ldyBjb25maWctb2JqZWN0XG4gKiBieSBtZXJnaW5nIHR3byBjb25maWd1cmF0aW9uIG9iamVjdHMgdG9nZXRoZXIuXG4gKlxuICogQHBhcmFtIHtPYmplY3R9IGNvbmZpZzFcbiAqIEBwYXJhbSB7T2JqZWN0fSBjb25maWcyXG4gKlxuICogQHJldHVybnMge09iamVjdH0gTmV3IG9iamVjdCByZXN1bHRpbmcgZnJvbSBtZXJnaW5nIGNvbmZpZzIgdG8gY29uZmlnMVxuICovXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBtZXJnZUNvbmZpZyhjb25maWcxLCBjb25maWcyKSB7XG4gIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBuby1wYXJhbS1yZWFzc2lnblxuICBjb25maWcxID0gY29uZmlnMSB8fCB7fTtcbiAgY29uZmlnMiA9IGNvbmZpZzIgfHwge307XG5cbiAgLy8gVXNlIGEgbnVsbC1wcm90b3R5cGUgb2JqZWN0IHNvIHRoYXQgZG93bnN0cmVhbSByZWFkcyBzdWNoIGFzIGBjb25maWcuYXV0aGBcbiAgLy8gb3IgYGNvbmZpZy5iYXNlVVJMYCBjYW5ub3QgaW5oZXJpdCBwb2xsdXRlZCB2YWx1ZXMgZnJvbSBPYmplY3QucHJvdG90eXBlLlxuICAvLyBgaGFzT3duUHJvcGVydHlgIGlzIHJlc3RvcmVkIGFzIGEgbm9uLWVudW1lcmFibGUgb3duIHNsb3QgdG8gcHJlc2VydmVcbiAgLy8gZXJnb25vbWljcyBmb3IgdXNlciBjb2RlIHRoYXQgcmVsaWVzIG9uIGl0LlxuICBjb25zdCBjb25maWcgPSBPYmplY3QuY3JlYXRlKG51bGwpO1xuICBPYmplY3QuZGVmaW5lUHJvcGVydHkoY29uZmlnLCAnaGFzT3duUHJvcGVydHknLCBoYXNPd25Qcm9wZXJ0eURlc2NyaXB0b3IpO1xuXG4gIGNvbnN0IGtleXMgPSBvd25FbnVtZXJhYmxlS2V5cyh7IC4uLmNvbmZpZzEsIC4uLmNvbmZpZzIgfSk7XG5cbiAgZm9yIChsZXQgaSA9IDAsIGxlbiA9IGtleXMubGVuZ3RoOyBpIDwgbGVuOyBpKyspIHtcbiAgICBjb25zdCBwcm9wID0ga2V5c1tpXTtcbiAgICBpZiAocHJvcCA9PT0gJ19fcHJvdG9fXycgfHwgcHJvcCA9PT0gJ2NvbnN0cnVjdG9yJyB8fCBwcm9wID09PSAncHJvdG90eXBlJykgY29udGludWU7XG4gICAgY29uc3QgbWVyZ2UgPSB1dGlscy5oYXNPd25Qcm9wKG1lcmdlTWFwLCBwcm9wKSA/IG1lcmdlTWFwW3Byb3BdIDogbWVyZ2VEZWVwUHJvcGVydGllcztcbiAgICBjb25zdCBhID0gdXRpbHMuaGFzT3duUHJvcChjb25maWcxLCBwcm9wKSA/IGNvbmZpZzFbcHJvcF0gOiB1bmRlZmluZWQ7XG4gICAgY29uc3QgYiA9IHV0aWxzLmhhc093blByb3AoY29uZmlnMiwgcHJvcCkgPyBjb25maWcyW3Byb3BdIDogdW5kZWZpbmVkO1xuICAgIGNvbnN0IGNvbmZpZ1ZhbHVlID1cbiAgICAgIG1lcmdlID09PSBtZXJnZURpcmVjdEtleXMgPyBtZXJnZShhLCBiLCBwcm9wLCBjb25maWcxLCBjb25maWcyKSA6IG1lcmdlKGEsIGIsIHByb3ApO1xuICAgICh1dGlscy5pc1VuZGVmaW5lZChjb25maWdWYWx1ZSkgJiYgbWVyZ2UgIT09IG1lcmdlRGlyZWN0S2V5cykgfHwgKGNvbmZpZ1twcm9wXSA9IGNvbmZpZ1ZhbHVlKTtcbiAgfVxuXG4gIGlmIChcbiAgICB1dGlscy5oYXNPd25Qcm9wKGNvbmZpZzIsICd2YWxpZGF0ZVN0YXR1cycpICYmXG4gICAgdXRpbHMuaXNVbmRlZmluZWQoY29uZmlnMi52YWxpZGF0ZVN0YXR1cykgJiZcbiAgICBnZXRNZXJnZWRUcmFuc2l0aW9uYWxPcHRpb24oY29uZmlnMSwgY29uZmlnMiwgJ3ZhbGlkYXRlU3RhdHVzVW5kZWZpbmVkUmVzb2x2ZXMnKSA9PT0gZmFsc2VcbiAgKSB7XG4gICAgaWYgKHV0aWxzLmhhc093blByb3AoY29uZmlnMSwgJ3ZhbGlkYXRlU3RhdHVzJykpIHtcbiAgICAgIGNvbmZpZy52YWxpZGF0ZVN0YXR1cyA9IGdldE1lcmdlZFZhbHVlKHVuZGVmaW5lZCwgY29uZmlnMS52YWxpZGF0ZVN0YXR1cyk7XG4gICAgfSBlbHNlIHtcbiAgICAgIGRlbGV0ZSBjb25maWcudmFsaWRhdGVTdGF0dXM7XG4gICAgfVxuICB9XG5cbiAgcmV0dXJuIGNvbmZpZztcbn1cbiIsIid1c2Ugc3RyaWN0JztcblxuY29uc3QgRk9STV9EQVRBX0NPTlRFTlRfSEVBREVSUyA9IFsnY29udGVudC10eXBlJywgJ2NvbnRlbnQtbGVuZ3RoJ107XG5cbi8qKlxuICogQXBwbHkgdGhlIGhlYWRlcnMgZ2VuZXJhdGVkIGJ5IGEgRm9ybURhdGEgaW1wbGVtZW50YXRpb24gdG8gdGhlIHJlcXVlc3QgaGVhZGVycyxcbiAqIGhvbm9yaW5nIHRoZSBgZm9ybURhdGFIZWFkZXJQb2xpY3lgIG9wdGlvbjogd2l0aCAnY29udGVudC1vbmx5JywgY29weSBvbmx5IHRoZVxuICogY29udGVudC0qIGhlYWRlcnM7IG90aGVyd2lzZSBtZXJnZSBhbGwgb2YgdGhlbS5cbiAqXG4gKiBAcGFyYW0ge0F4aW9zSGVhZGVyc30gaGVhZGVycyAtIHRoZSByZXF1ZXN0IGhlYWRlcnMgdG8gbXV0YXRlXG4gKiBAcGFyYW0ge09iamVjdCB8IG51bGwgfCB1bmRlZmluZWR9IGZvcm1IZWFkZXJzIC0gaGVhZGVycyBwcm9kdWNlZCBieSB0aGUgRm9ybURhdGEgaW1wbGVtZW50YXRpb25cbiAqIEBwYXJhbSB7U3RyaW5nfSBbcG9saWN5XSAtIHRoZSByZXNvbHZlZCBgZm9ybURhdGFIZWFkZXJQb2xpY3lgIGNvbmZpZyB2YWx1ZVxuICpcbiAqIEByZXR1cm5zIHt2b2lkfVxuICovXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBzZXRGb3JtRGF0YUhlYWRlcnMoaGVhZGVycywgZm9ybUhlYWRlcnMsIHBvbGljeSkge1xuICBpZiAocG9saWN5ICE9PSAnY29udGVudC1vbmx5Jykge1xuICAgIGhlYWRlcnMuc2V0KGZvcm1IZWFkZXJzKTtcbiAgICByZXR1cm47XG4gIH1cblxuICBPYmplY3QuZW50cmllcyhmb3JtSGVhZGVycyB8fCB7fSkuZm9yRWFjaCgoW2tleSwgdmFsXSkgPT4ge1xuICAgIGlmIChGT1JNX0RBVEFfQ09OVEVOVF9IRUFERVJTLmluY2x1ZGVzKGtleS50b0xvd2VyQ2FzZSgpKSkge1xuICAgICAgaGVhZGVycy5zZXQoa2V5LCB2YWwpO1xuICAgIH1cbiAgfSk7XG59XG4iLCJpbXBvcnQgcGxhdGZvcm0gZnJvbSAnLi4vcGxhdGZvcm0vaW5kZXguanMnO1xuaW1wb3J0IHV0aWxzIGZyb20gJy4uL3V0aWxzLmpzJztcbmltcG9ydCBBeGlvc0Vycm9yIGZyb20gJy4uL2NvcmUvQXhpb3NFcnJvci5qcyc7XG5pbXBvcnQgaXNVUkxTYW1lT3JpZ2luIGZyb20gJy4vaXNVUkxTYW1lT3JpZ2luLmpzJztcbmltcG9ydCBjb29raWVzIGZyb20gJy4vY29va2llcy5qcyc7XG5pbXBvcnQgYnVpbGRGdWxsUGF0aCBmcm9tICcuLi9jb3JlL2J1aWxkRnVsbFBhdGguanMnO1xuaW1wb3J0IG1lcmdlQ29uZmlnIGZyb20gJy4uL2NvcmUvbWVyZ2VDb25maWcuanMnO1xuaW1wb3J0IEF4aW9zSGVhZGVycyBmcm9tICcuLi9jb3JlL0F4aW9zSGVhZGVycy5qcyc7XG5pbXBvcnQgc2V0Rm9ybURhdGFIZWFkZXJzIGZyb20gJy4uL2NvcmUvc2V0Rm9ybURhdGFIZWFkZXJzLmpzJztcbmltcG9ydCBidWlsZFVSTCBmcm9tICcuL2J1aWxkVVJMLmpzJztcblxuLyoqXG4gKiBFbmNvZGUgYSBVVEYtOCBzdHJpbmcgdG8gYSBMYXRpbi0xIGJ5dGUgc3RyaW5nIGZvciB1c2Ugd2l0aCBidG9hKCkuXG4gKiBUaGlzIGlzIGEgbW9kZXJuIHJlcGxhY2VtZW50IGZvciB0aGUgZGVwcmVjYXRlZCB1bmVzY2FwZShlbmNvZGVVUklDb21wb25lbnQoc3RyKSkgcGF0dGVybi5cbiAqXG4gKiBAcGFyYW0ge3N0cmluZ30gc3RyIFRoZSBzdHJpbmcgdG8gZW5jb2RlXG4gKlxuICogQHJldHVybnMge3N0cmluZ30gVVRGLTggYnl0ZXMgYXMgYSBMYXRpbi0xIHN0cmluZ1xuICovXG5jb25zdCBlbmNvZGVVVEY4ID0gKHN0cikgPT5cbiAgZW5jb2RlVVJJQ29tcG9uZW50KHN0cikucmVwbGFjZSgvJShbMC05QS1GXXsyfSkvZ2ksIChfLCBoZXgpID0+XG4gICAgU3RyaW5nLmZyb21DaGFyQ29kZShwYXJzZUludChoZXgsIDE2KSlcbiAgKTtcblxuY29uc3QgcmVhZENvb2tpZSA9IChuYW1lKSA9PiBjb29raWVzLnJlYWQobmFtZSk7XG5cbmZ1bmN0aW9uIHJlc29sdmVDb25maWcoY29uZmlnLCByZWFkWHNyZkNvb2tpZSA9IHJlYWRDb29raWUpIHtcbiAgY29uc3QgbmV3Q29uZmlnID0gbWVyZ2VDb25maWcoe30sIGNvbmZpZyk7XG5cbiAgLy8gUmVhZCBvbmx5IG93biBwcm9wZXJ0aWVzIHRvIHByZXZlbnQgcHJvdG90eXBlIHBvbGx1dGlvbiBnYWRnZXRzXG4gIC8vIChlLmcuIE9iamVjdC5wcm90b3R5cGUuYmFzZVVSTCA9ICdodHRwczovL2V2aWwuY29tJykuXG4gIGNvbnN0IG93biA9IChrZXkpID0+ICh1dGlscy5oYXNPd25Qcm9wKG5ld0NvbmZpZywga2V5KSA/IG5ld0NvbmZpZ1trZXldIDogdW5kZWZpbmVkKTtcblxuICBjb25zdCBkYXRhID0gb3duKCdkYXRhJyk7XG4gIGxldCB3aXRoWFNSRlRva2VuID0gb3duKCd3aXRoWFNSRlRva2VuJyk7XG4gIGNvbnN0IHhzcmZIZWFkZXJOYW1lID0gb3duKCd4c3JmSGVhZGVyTmFtZScpO1xuICBjb25zdCB4c3JmQ29va2llTmFtZSA9IG93bigneHNyZkNvb2tpZU5hbWUnKTtcbiAgbGV0IGhlYWRlcnMgPSBvd24oJ2hlYWRlcnMnKTtcbiAgY29uc3QgYXV0aCA9IG93bignYXV0aCcpO1xuICBjb25zdCBiYXNlVVJMID0gb3duKCdiYXNlVVJMJyk7XG4gIGNvbnN0IGFsbG93QWJzb2x1dGVVcmxzID0gb3duKCdhbGxvd0Fic29sdXRlVXJscycpO1xuICBjb25zdCB1cmwgPSBvd24oJ3VybCcpO1xuXG4gIG5ld0NvbmZpZy5oZWFkZXJzID0gaGVhZGVycyA9IEF4aW9zSGVhZGVycy5mcm9tKGhlYWRlcnMpO1xuXG4gIG5ld0NvbmZpZy51cmwgPSBidWlsZFVSTChcbiAgICBidWlsZEZ1bGxQYXRoKGJhc2VVUkwsIHVybCwgYWxsb3dBYnNvbHV0ZVVybHMsIG5ld0NvbmZpZyksXG4gICAgb3duKCdwYXJhbXMnKSxcbiAgICBvd24oJ3BhcmFtc1NlcmlhbGl6ZXInKVxuICApO1xuXG4gIC8vIEhUVFAgYmFzaWMgYXV0aGVudGljYXRpb25cbiAgaWYgKGF1dGgpIHtcbiAgICBjb25zdCB1c2VybmFtZSA9IHV0aWxzLmdldFNhZmVQcm9wKGF1dGgsICd1c2VybmFtZScpIHx8ICcnO1xuICAgIGNvbnN0IHBhc3N3b3JkID0gdXRpbHMuZ2V0U2FmZVByb3AoYXV0aCwgJ3Bhc3N3b3JkJykgfHwgJyc7XG4gICAgY29uc3QgdHJhbnNpdGlvbmFsID0gb3duKCd0cmFuc2l0aW9uYWwnKTtcbiAgICBjb25zdCBlbmNvZGVVc2VybmFtZSA9XG4gICAgICB0cmFuc2l0aW9uYWwgJiZcbiAgICAgIHV0aWxzLmhhc093blByb3AodHJhbnNpdGlvbmFsLCAnZW5jb2RlQmFzaWNBdXRoVXNlcm5hbWUnKSAmJlxuICAgICAgdHJhbnNpdGlvbmFsLmVuY29kZUJhc2ljQXV0aFVzZXJuYW1lID09PSB0cnVlO1xuXG4gICAgdHJ5IHtcbiAgICAgIGhlYWRlcnMuc2V0KFxuICAgICAgICAnQXV0aG9yaXphdGlvbicsXG4gICAgICAgIC8vIFByZXNlcnZlIGxlZ2FjeSB1c2VybmFtZSBieXRlcyB1bmxlc3MgdGhlIGNhbGxlciBvcHRzIGluIHRvIFVURi04LlxuICAgICAgICAnQmFzaWMgJyArXG4gICAgICAgICAgYnRvYShcbiAgICAgICAgICAgIChlbmNvZGVVc2VybmFtZSA/IGVuY29kZVVURjgodXNlcm5hbWUpIDogdXNlcm5hbWUpICtcbiAgICAgICAgICAgICAgJzonICtcbiAgICAgICAgICAgICAgKHBhc3N3b3JkID8gZW5jb2RlVVRGOChwYXNzd29yZCkgOiAnJylcbiAgICAgICAgICApXG4gICAgICApO1xuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgIHRocm93IEF4aW9zRXJyb3IuZnJvbShlLCBBeGlvc0Vycm9yLkVSUl9CQURfT1BUSU9OX1ZBTFVFLCBjb25maWcpO1xuICAgIH1cbiAgfVxuXG4gIGlmICh1dGlscy5pc0Zvcm1EYXRhKGRhdGEpKSB7XG4gICAgY29uc3QgZ2V0SGVhZGVycyA9IHV0aWxzLmdldFNhZmVQcm9wKGRhdGEsICdnZXRIZWFkZXJzJyk7XG5cbiAgICBpZiAoXG4gICAgICBwbGF0Zm9ybS5oYXNTdGFuZGFyZEJyb3dzZXJFbnYgfHxcbiAgICAgIHBsYXRmb3JtLmhhc1N0YW5kYXJkQnJvd3NlcldlYldvcmtlckVudiB8fFxuICAgICAgdXRpbHMuaXNSZWFjdE5hdGl2ZShkYXRhKVxuICAgICkge1xuICAgICAgaGVhZGVycy5zZXRDb250ZW50VHlwZSh1bmRlZmluZWQpOyAvLyBicm93c2VyL3dlYiB3b3JrZXIvUk4gaGFuZGxlcyBpdFxuICAgIH0gZWxzZSBpZiAodXRpbHMuaXNGdW5jdGlvbihnZXRIZWFkZXJzKSkge1xuICAgICAgLy8gTm9kZS5qcyBGb3JtRGF0YSAobGlrZSBmb3JtLWRhdGEgcGFja2FnZSlcbiAgICAgIHNldEZvcm1EYXRhSGVhZGVycyhoZWFkZXJzLCBnZXRIZWFkZXJzLmNhbGwoZGF0YSksIG93bignZm9ybURhdGFIZWFkZXJQb2xpY3knKSk7XG4gICAgfVxuICB9XG5cbiAgLy8gQWRkIHhzcmYgaGVhZGVyXG4gIC8vIFRoaXMgaXMgb25seSBkb25lIGlmIHJ1bm5pbmcgaW4gYSBzdGFuZGFyZCBicm93c2VyIGVudmlyb25tZW50LlxuICAvLyBTcGVjaWZpY2FsbHkgbm90IGlmIHdlJ3JlIGluIGEgd2ViIHdvcmtlciwgb3IgcmVhY3QtbmF0aXZlLlxuXG4gIGlmIChwbGF0Zm9ybS5oYXNTdGFuZGFyZEJyb3dzZXJFbnYpIHtcbiAgICBpZiAodXRpbHMuaXNGdW5jdGlvbih3aXRoWFNSRlRva2VuKSkge1xuICAgICAgd2l0aFhTUkZUb2tlbiA9IHdpdGhYU1JGVG9rZW4obmV3Q29uZmlnKTtcbiAgICB9XG5cbiAgICAvLyBTdHJpY3QgYm9vbGVhbiBjaGVjayDigJQgcHJldmVudHMgcHJvdG8tcG9sbHV0aW9uIGdhZGdldHMgKGUuZy4gT2JqZWN0LnByb3RvdHlwZS53aXRoWFNSRlRva2VuID0gMSlcbiAgICAvLyBhbmQgbWlzY29uZmlndXJhdGlvbnMgKGUuZy4gXCJmYWxzZVwiKSBmcm9tIHNob3J0LWNpcmN1aXRpbmcgdGhlIHNhbWUtb3JpZ2luIGNoZWNrIGFuZCBsZWFraW5nXG4gICAgLy8gdGhlIFhTUkYgdG9rZW4gY3Jvc3Mtb3JpZ2luLlxuICAgIGNvbnN0IHNob3VsZFNlbmRYU1JGID1cbiAgICAgIHdpdGhYU1JGVG9rZW4gPT09IHRydWUgfHwgKHdpdGhYU1JGVG9rZW4gPT0gbnVsbCAmJiBpc1VSTFNhbWVPcmlnaW4obmV3Q29uZmlnLnVybCkpO1xuXG4gICAgaWYgKHNob3VsZFNlbmRYU1JGKSB7XG4gICAgICBjb25zdCB4c3JmVmFsdWUgPSB4c3JmSGVhZGVyTmFtZSAmJiB4c3JmQ29va2llTmFtZSAmJiByZWFkWHNyZkNvb2tpZSh4c3JmQ29va2llTmFtZSk7XG5cbiAgICAgIGlmICh4c3JmVmFsdWUpIHtcbiAgICAgICAgaGVhZGVycy5zZXQoeHNyZkhlYWRlck5hbWUsIHhzcmZWYWx1ZSk7XG4gICAgICB9XG4gICAgfVxuICB9XG5cbiAgcmV0dXJuIG5ld0NvbmZpZztcbn1cblxuZXhwb3J0IGRlZmF1bHQgcmVzb2x2ZUNvbmZpZztcbiIsImltcG9ydCB1dGlscyBmcm9tICcuLi91dGlscy5qcyc7XG5pbXBvcnQgc2V0dGxlIGZyb20gJy4uL2NvcmUvc2V0dGxlLmpzJztcbmltcG9ydCB0cmFuc2l0aW9uYWxEZWZhdWx0cyBmcm9tICcuLi9kZWZhdWx0cy90cmFuc2l0aW9uYWwuanMnO1xuaW1wb3J0IEF4aW9zRXJyb3IgZnJvbSAnLi4vY29yZS9BeGlvc0Vycm9yLmpzJztcbmltcG9ydCBDYW5jZWxlZEVycm9yIGZyb20gJy4uL2NhbmNlbC9DYW5jZWxlZEVycm9yLmpzJztcbmltcG9ydCBub3JtYWxpemVVUkxGb3JQcm90b2NvbENoZWNrIGZyb20gJy4uL2hlbHBlcnMvbm9ybWFsaXplVVJMRm9yUHJvdG9jb2xDaGVjay5qcyc7XG5pbXBvcnQgcGFyc2VQcm90b2NvbCBmcm9tICcuLi9oZWxwZXJzL3BhcnNlUHJvdG9jb2wuanMnO1xuaW1wb3J0IHBsYXRmb3JtIGZyb20gJy4uL3BsYXRmb3JtL2luZGV4LmpzJztcbmltcG9ydCBBeGlvc0hlYWRlcnMgZnJvbSAnLi4vY29yZS9BeGlvc0hlYWRlcnMuanMnO1xuaW1wb3J0IGNvb2tpZXMgZnJvbSAnLi4vaGVscGVycy9jb29raWVzLmpzJztcbmltcG9ydCB7IHByb2dyZXNzRXZlbnRSZWR1Y2VyIH0gZnJvbSAnLi4vaGVscGVycy9wcm9ncmVzc0V2ZW50UmVkdWNlci5qcyc7XG5pbXBvcnQgcmVzb2x2ZUNvbmZpZyBmcm9tICcuLi9oZWxwZXJzL3Jlc29sdmVDb25maWcuanMnO1xuaW1wb3J0IHsgdG9CeXRlU3RyaW5nSGVhZGVyT2JqZWN0IH0gZnJvbSAnLi4vaGVscGVycy9zYW5pdGl6ZUhlYWRlclZhbHVlLmpzJztcblxuY29uc3QgaXNYSFJBZGFwdGVyU3VwcG9ydGVkID0gdHlwZW9mIFhNTEh0dHBSZXF1ZXN0ICE9PSAndW5kZWZpbmVkJztcblxuZXhwb3J0IGRlZmF1bHQgaXNYSFJBZGFwdGVyU3VwcG9ydGVkICYmXG4gIGZ1bmN0aW9uIChjb25maWcpIHtcbiAgICByZXR1cm4gbmV3IFByb21pc2UoZnVuY3Rpb24gZGlzcGF0Y2hYaHJSZXF1ZXN0KHJlc29sdmUsIHJlamVjdCkge1xuICAgICAgbGV0IHVzZUFzeW5jWHNyZjtcbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHN0b3JlID1cbiAgICAgICAgICBwbGF0Zm9ybS5oYXNTdGFuZGFyZEJyb3dzZXJFbnYgJiYgdHlwZW9mIHdpbmRvdyAhPT0gJ3VuZGVmaW5lZCcgJiYgd2luZG93LmNvb2tpZVN0b3JlO1xuICAgICAgICB1c2VBc3luY1hzcmYgPSBzdG9yZSAmJiB1dGlscy5pc0Z1bmN0aW9uKHN0b3JlLmdldCk7XG4gICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgIC8vIEEgcmVzdHJpY3RlZCBDb29raWUgU3RvcmUgZ2V0dGVyIG11c3QgcmV0YWluIHRoZSBzeW5jaHJvbm91cyBmYWxsYmFjay5cbiAgICAgIH1cbiAgICAgIGxldCB4c3JmQ29va2llTmFtZTtcbiAgICAgIGNvbnN0IF9jb25maWcgPSByZXNvbHZlQ29uZmlnKFxuICAgICAgICBjb25maWcsXG4gICAgICAgIHVzZUFzeW5jWHNyZlxuICAgICAgICAgID8gKG5hbWUpID0+IHtcbiAgICAgICAgICAgICAgeHNyZkNvb2tpZU5hbWUgPSBuYW1lO1xuICAgICAgICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICA6IHVuZGVmaW5lZFxuICAgICAgKTtcbiAgICAgIGxldCByZXF1ZXN0RGF0YSA9IF9jb25maWcuZGF0YTtcbiAgICAgIGNvbnN0IHJlcXVlc3RIZWFkZXJzID0gQXhpb3NIZWFkZXJzLmZyb20oX2NvbmZpZy5oZWFkZXJzKS5ub3JtYWxpemUoKTtcbiAgICAgIGxldCB7IHJlc3BvbnNlVHlwZSwgb25VcGxvYWRQcm9ncmVzcywgb25Eb3dubG9hZFByb2dyZXNzIH0gPSBfY29uZmlnO1xuICAgICAgbGV0IG9uQ2FuY2VsZWQ7XG4gICAgICBsZXQgdGltZW91dElkO1xuICAgICAgbGV0IHVwbG9hZFRocm90dGxlZCwgZG93bmxvYWRUaHJvdHRsZWQ7XG4gICAgICBsZXQgZmx1c2hVcGxvYWQsIGZsdXNoRG93bmxvYWQsIGZsdXNoRG93bmxvYWRXaXRoRXZlbnQ7XG5cbiAgICAgIGZ1bmN0aW9uIGRvbmUoKSB7XG4gICAgICAgIGNsZWFyVGltZW91dCh0aW1lb3V0SWQpO1xuICAgICAgICAvLyBBIGZpbmFsIHByb2dyZXNzIGNhbGxiYWNrIG11c3Qgbm90IHByZXZlbnQgdGhlIHJlbWFpbmluZyBjbGVhbnVwLlxuICAgICAgICAvLyBSZXBvcnQgZXJyb3JzIGFzeW5jaHJvbm91c2x5LCBhcyBvbmxvYWRlbmQgYW5kIHRoZSB0aHJvdHRsZSB0aW1lciBkby5cbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICBmbHVzaFVwbG9hZCAmJiBmbHVzaFVwbG9hZCgpOyAvLyBmbHVzaCBldmVudHNcbiAgICAgICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAgICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgICAgICB0aHJvdyBlcnI7XG4gICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICBmbHVzaERvd25sb2FkICYmIGZsdXNoRG93bmxvYWQoKTsgLy8gZmx1c2ggZXZlbnRzXG4gICAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICAgICAgdGhyb3cgZXJyO1xuICAgICAgICAgIH0pO1xuICAgICAgICB9XG5cbiAgICAgICAgLy8gQSBmbHVzaCBjYW4gc3luY2hyb25vdXNseSBjYW5jZWwgdGhlIHJlcXVlc3QgYW5kIHJlZW50ZXIgZG9uZSgpLlxuICAgICAgICAvLyBJbiB0aGF0IGNhc2UgdGhlIGlubmVyIGNhbGwgaGFzIGFscmVhZHkgZGV0YWNoZWQgdGhlc2UgbGlzdGVuZXJzLlxuICAgICAgICBpZiAocmVxdWVzdCkge1xuICAgICAgICAgIGRvd25sb2FkVGhyb3R0bGVkICYmIHJlcXVlc3QucmVtb3ZlRXZlbnRMaXN0ZW5lcigncHJvZ3Jlc3MnLCBkb3dubG9hZFRocm90dGxlZCk7XG4gICAgICAgICAgaWYgKHJlcXVlc3QudXBsb2FkKSB7XG4gICAgICAgICAgICB1cGxvYWRUaHJvdHRsZWQgJiYgcmVxdWVzdC51cGxvYWQucmVtb3ZlRXZlbnRMaXN0ZW5lcigncHJvZ3Jlc3MnLCB1cGxvYWRUaHJvdHRsZWQpO1xuICAgICAgICAgICAgZmx1c2hVcGxvYWQgJiYgcmVxdWVzdC51cGxvYWQucmVtb3ZlRXZlbnRMaXN0ZW5lcignbG9hZGVuZCcsIGZsdXNoVXBsb2FkKTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICBfY29uZmlnLmNhbmNlbFRva2VuICYmIF9jb25maWcuY2FuY2VsVG9rZW4udW5zdWJzY3JpYmUob25DYW5jZWxlZCk7XG5cbiAgICAgICAgX2NvbmZpZy5zaWduYWwgJiYgX2NvbmZpZy5zaWduYWwucmVtb3ZlRXZlbnRMaXN0ZW5lcignYWJvcnQnLCBvbkNhbmNlbGVkKTtcbiAgICAgIH1cblxuICAgICAgbGV0IHJlcXVlc3QgPSBuZXcgWE1MSHR0cFJlcXVlc3QoKTtcblxuICAgICAgcmVxdWVzdC5vcGVuKF9jb25maWcubWV0aG9kLnRvVXBwZXJDYXNlKCksIF9jb25maWcudXJsLCB0cnVlKTtcblxuICAgICAgLy8gU2V0IHRoZSByZXF1ZXN0IHRpbWVvdXQgaW4gTVNcbiAgICAgIHJlcXVlc3QudGltZW91dCA9IF9jb25maWcudGltZW91dDtcblxuICAgICAgZnVuY3Rpb24gb25sb2FkZW5kKGV2ZW50KSB7XG4gICAgICAgIGlmICghcmVxdWVzdCkge1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuXG4gICAgICAgIC8vIFN0YXR1cyAwIG1lYW5zIG5vIHJlc3BvbnNlIHdhcyByZWNlaXZlZCwgd2hpY2ggb25lcnJvciBhbmQgb25hYm9ydCBub3JtYWxseVxuICAgICAgICAvLyByZWplY3QgYmVmb3JlIHRoaXMgcnVucy4gRmlyZWZveCAxNTIgZmlyZXMgb25seSByZWFkeXN0YXRlY2hhbmdlIGFuZCBsb2FkZW5kIGZvclxuICAgICAgICAvLyBuYXZpZ2F0aW9uLWNhbmNlbGVkIHJlcXVlc3RzIChodHRwczovL2J1Z3ppbGxhLm1vemlsbGEub3JnL3Nob3dfYnVnLmNnaT9pZD0xNTA1Mzg5KSxcbiAgICAgICAgLy8gbGVhdmluZyBzZXR0bGUoKSB0byByZXNvbHZlIHRoZW0gYXMgYW4gZW1wdHkgc3VjY2Vzcy4gRUNPTk5BQk9SVEVEIGlzIHRoZSBlcnJvclxuICAgICAgICAvLyBvbmFib3J0IHJhaXNlZCBvbiBGaXJlZm94IDE1MS4gUmVhZHMgb3ZlciBmaWxlOiwgd2hpY2ggc29tZSBlbnZpcm9ubWVudHMgcmVwb3J0IGFzXG4gICAgICAgIC8vIHN0YXR1cyAwIG9uIHN1Y2Nlc3MsIGFyZSBleGNsdWRlZCBieSB0aGUgcmVxdWVzdCBVUkwncyBzY2hlbWUgYWZ0ZXIgYnJvd3Nlci1zdHlsZVxuICAgICAgICAvLyBwcmVwcm9jZXNzaW5nLCBieSB0aGUgcGFnZSBvcmlnaW4ncyBzY2hlbWUgZm9yIHJlbGF0aXZlIFVSTHMgKHdoaWNoIGluaGVyaXQgaXQpLCBvclxuICAgICAgICAvLyBieSByZXNwb25zZVVSTCB3aGVyZSBpbXBsZW1lbnRlZC5cbiAgICAgICAgaWYgKFxuICAgICAgICAgIHJlcXVlc3Quc3RhdHVzID09PSAwICYmXG4gICAgICAgICAgKHBhcnNlUHJvdG9jb2wobm9ybWFsaXplVVJMRm9yUHJvdG9jb2xDaGVjayhfY29uZmlnLnVybCkpIHx8XG4gICAgICAgICAgICBwYXJzZVByb3RvY29sKHBsYXRmb3JtLm9yaWdpbikpICE9PSAnZmlsZScgJiZcbiAgICAgICAgICAhKHJlcXVlc3QucmVzcG9uc2VVUkwgJiYgcmVxdWVzdC5yZXNwb25zZVVSTC5zdGFydHNXaXRoKCdmaWxlOicpKVxuICAgICAgICApIHtcbiAgICAgICAgICByZWplY3QobmV3IEF4aW9zRXJyb3IoJ1JlcXVlc3QgYWJvcnRlZCcsIEF4aW9zRXJyb3IuRUNPTk5BQk9SVEVELCBjb25maWcsIHJlcXVlc3QpKTtcbiAgICAgICAgICBkb25lKCk7XG5cbiAgICAgICAgICAvLyBDbGVhbiB1cCByZXF1ZXN0XG4gICAgICAgICAgcmVxdWVzdCA9IG51bGw7XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG5cbiAgICAgICAgLy8gV2hlbiBsb2FkZW5kIGlzIHN0aWxsIGRpc3BhdGNoaW5nLCBmbHVzaGluZyB3aXRoIGl0IGdpdmVzIHByb2dyZXNzXG4gICAgICAgIC8vIGxpc3RlbmVycyBhIGZpbmFsIGRlbGl2ZXJ5IHdob3NlIGV2ZW50IGhhcyBhIGxpdmUgdGFyZ2V0LiBUaGUgbGVnYWN5XG4gICAgICAgIC8vIHJlYWR5LXN0YXRlIGZhbGxiYWNrIGhhcyBubyBldmVudCwgc28gcmVwbGF5IGl0cyBwZW5kaW5nIHByb2dyZXNzLlxuICAgICAgICAvLyBBIHRocm93aW5nIGxpc3RlbmVyIG11c3Qgbm90IGJsb2NrIHNldHRsZW1lbnQ7IHJldGhyb3cgYXN5bmNocm9ub3VzbHksXG4gICAgICAgIC8vIG1hdGNoaW5nIGhvdyBsaXN0ZW5lciBlcnJvcnMgc3VyZmFjZSBvbiB0aGUgdGhyb3R0bGUgdGltZXIgcGF0aC5cbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICBpZiAoZXZlbnQpIHtcbiAgICAgICAgICAgIGZsdXNoRG93bmxvYWRXaXRoRXZlbnQgJiYgZmx1c2hEb3dubG9hZFdpdGhFdmVudChldmVudCk7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGZsdXNoRG93bmxvYWQgJiYgZmx1c2hEb3dubG9hZCgpO1xuICAgICAgICAgIH1cbiAgICAgICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAgICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgICAgICB0aHJvdyBlcnI7XG4gICAgICAgICAgfSk7XG4gICAgICAgIH1cblxuICAgICAgICAvLyBBIGZpbmFsIHByb2dyZXNzIGNhbGxiYWNrIGNhbiBjYW5jZWwgdGhlIHJlcXVlc3Qgc3luY2hyb25vdXNseS5cbiAgICAgICAgaWYgKCFyZXF1ZXN0KSB7XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG5cbiAgICAgICAgLy8gUHJlcGFyZSB0aGUgcmVzcG9uc2VcbiAgICAgICAgY29uc3QgcmVzcG9uc2VIZWFkZXJzID0gQXhpb3NIZWFkZXJzLmZyb20oXG4gICAgICAgICAgJ2dldEFsbFJlc3BvbnNlSGVhZGVycycgaW4gcmVxdWVzdCAmJiByZXF1ZXN0LmdldEFsbFJlc3BvbnNlSGVhZGVycygpXG4gICAgICAgICk7XG4gICAgICAgIGNvbnN0IHJlc3BvbnNlRGF0YSA9XG4gICAgICAgICAgIXJlc3BvbnNlVHlwZSB8fCByZXNwb25zZVR5cGUgPT09ICd0ZXh0JyB8fCByZXNwb25zZVR5cGUgPT09ICdqc29uJ1xuICAgICAgICAgICAgPyByZXF1ZXN0LnJlc3BvbnNlVGV4dFxuICAgICAgICAgICAgOiByZXF1ZXN0LnJlc3BvbnNlO1xuICAgICAgICBjb25zdCByZXNwb25zZSA9IHtcbiAgICAgICAgICBkYXRhOiByZXNwb25zZURhdGEsXG4gICAgICAgICAgc3RhdHVzOiByZXF1ZXN0LnN0YXR1cyxcbiAgICAgICAgICBzdGF0dXNUZXh0OiByZXF1ZXN0LnN0YXR1c1RleHQsXG4gICAgICAgICAgaGVhZGVyczogcmVzcG9uc2VIZWFkZXJzLFxuICAgICAgICAgIGNvbmZpZyxcbiAgICAgICAgICByZXF1ZXN0LFxuICAgICAgICB9O1xuXG4gICAgICAgIHNldHRsZShcbiAgICAgICAgICBmdW5jdGlvbiBfcmVzb2x2ZSh2YWx1ZSkge1xuICAgICAgICAgICAgcmVzb2x2ZSh2YWx1ZSk7XG4gICAgICAgICAgICBkb25lKCk7XG4gICAgICAgICAgfSxcbiAgICAgICAgICBmdW5jdGlvbiBfcmVqZWN0KGVycikge1xuICAgICAgICAgICAgcmVqZWN0KGVycik7XG4gICAgICAgICAgICBkb25lKCk7XG4gICAgICAgICAgfSxcbiAgICAgICAgICByZXNwb25zZVxuICAgICAgICApO1xuXG4gICAgICAgIC8vIENsZWFuIHVwIHJlcXVlc3RcbiAgICAgICAgcmVxdWVzdCA9IG51bGw7XG4gICAgICB9XG5cbiAgICAgIGlmICgnb25sb2FkZW5kJyBpbiByZXF1ZXN0KSB7XG4gICAgICAgIC8vIFVzZSBvbmxvYWRlbmQgaWYgYXZhaWxhYmxlXG4gICAgICAgIHJlcXVlc3Qub25sb2FkZW5kID0gb25sb2FkZW5kO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgLy8gTGlzdGVuIGZvciByZWFkeSBzdGF0ZSB0byBlbXVsYXRlIG9ubG9hZGVuZFxuICAgICAgICByZXF1ZXN0Lm9ucmVhZHlzdGF0ZWNoYW5nZSA9IGZ1bmN0aW9uIGhhbmRsZUxvYWQoKSB7XG4gICAgICAgICAgaWYgKCFyZXF1ZXN0IHx8IHJlcXVlc3QucmVhZHlTdGF0ZSAhPT0gNCkge1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgIH1cblxuICAgICAgICAgIC8vIFRoZSByZXF1ZXN0IGVycm9yZWQgb3V0IGFuZCB3ZSBkaWRuJ3QgZ2V0IGEgcmVzcG9uc2UsIHRoaXMgd2lsbCBiZVxuICAgICAgICAgIC8vIGhhbmRsZWQgYnkgb25lcnJvciBpbnN0ZWFkXG4gICAgICAgICAgLy8gV2l0aCBvbmUgZXhjZXB0aW9uOiByZXF1ZXN0IHRoYXQgdXNpbmcgZmlsZTogcHJvdG9jb2wsIG1vc3QgYnJvd3NlcnNcbiAgICAgICAgICAvLyB3aWxsIHJldHVybiBzdGF0dXMgYXMgMCBldmVuIHRob3VnaCBpdCdzIGEgc3VjY2Vzc2Z1bCByZXF1ZXN0XG4gICAgICAgICAgaWYgKFxuICAgICAgICAgICAgcmVxdWVzdC5zdGF0dXMgPT09IDAgJiZcbiAgICAgICAgICAgICEocmVxdWVzdC5yZXNwb25zZVVSTCAmJiByZXF1ZXN0LnJlc3BvbnNlVVJMLnN0YXJ0c1dpdGgoJ2ZpbGU6JykpXG4gICAgICAgICAgKSB7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgfVxuICAgICAgICAgIC8vIHJlYWR5c3RhdGUgaGFuZGxlciBpcyBjYWxsaW5nIGJlZm9yZSBvbmVycm9yIG9yIG9udGltZW91dCBoYW5kbGVycyxcbiAgICAgICAgICAvLyBzbyB3ZSBzaG91bGQgY2FsbCBvbmxvYWRlbmQgb24gdGhlIG5leHQgJ3RpY2snXG4gICAgICAgICAgc2V0VGltZW91dChvbmxvYWRlbmQpO1xuICAgICAgICB9O1xuICAgICAgfVxuXG4gICAgICAvLyBIYW5kbGUgYnJvd3NlciByZXF1ZXN0IGNhbmNlbGxhdGlvbiAoYXMgb3Bwb3NlZCB0byBhIG1hbnVhbCBjYW5jZWxsYXRpb24pXG4gICAgICByZXF1ZXN0Lm9uYWJvcnQgPSBmdW5jdGlvbiBoYW5kbGVBYm9ydCgpIHtcbiAgICAgICAgaWYgKCFyZXF1ZXN0KSB7XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG5cbiAgICAgICAgcmVqZWN0KG5ldyBBeGlvc0Vycm9yKCdSZXF1ZXN0IGFib3J0ZWQnLCBBeGlvc0Vycm9yLkVDT05OQUJPUlRFRCwgY29uZmlnLCByZXF1ZXN0KSk7XG4gICAgICAgIGRvbmUoKTtcblxuICAgICAgICAvLyBDbGVhbiB1cCByZXF1ZXN0XG4gICAgICAgIHJlcXVlc3QgPSBudWxsO1xuICAgICAgfTtcblxuICAgICAgLy8gSGFuZGxlIGxvdyBsZXZlbCBuZXR3b3JrIGVycm9yc1xuICAgICAgcmVxdWVzdC5vbmVycm9yID0gZnVuY3Rpb24gaGFuZGxlRXJyb3IoZXZlbnQpIHtcbiAgICAgICAgLy8gQnJvd3NlcnMgZGVsaXZlciBhIFByb2dyZXNzRXZlbnQgaW4gWEhSIG9uZXJyb3JcbiAgICAgICAgLy8gKG1lc3NhZ2UgbWF5IGJlIGVtcHR5OyB3aGVuIHByZXNlbnQsIHN1cmZhY2UgaXQpXG4gICAgICAgIC8vIFNlZSBodHRwczovL2RldmVsb3Blci5tb3ppbGxhLm9yZy9kb2NzL1dlYi9BUEkvWE1MSHR0cFJlcXVlc3QvZXJyb3JfZXZlbnRcbiAgICAgICAgY29uc3QgbXNnID0gZXZlbnQgJiYgZXZlbnQubWVzc2FnZSA/IGV2ZW50Lm1lc3NhZ2UgOiAnTmV0d29yayBFcnJvcic7XG4gICAgICAgIGNvbnN0IGVyciA9IG5ldyBBeGlvc0Vycm9yKG1zZywgQXhpb3NFcnJvci5FUlJfTkVUV09SSywgY29uZmlnLCByZXF1ZXN0KTtcbiAgICAgICAgLy8gYXR0YWNoIHRoZSB1bmRlcmx5aW5nIGV2ZW50IGZvciBjb25zdW1lcnMgd2hvIHdhbnQgZGV0YWlsc1xuICAgICAgICBlcnIuZXZlbnQgPSBldmVudCB8fCBudWxsO1xuICAgICAgICByZWplY3QoZXJyKTtcbiAgICAgICAgZG9uZSgpO1xuICAgICAgICByZXF1ZXN0ID0gbnVsbDtcbiAgICAgIH07XG5cbiAgICAgIC8vIEhhbmRsZSB0aW1lb3V0XG4gICAgICByZXF1ZXN0Lm9udGltZW91dCA9IGZ1bmN0aW9uIGhhbmRsZVRpbWVvdXQoKSB7XG4gICAgICAgIGlmICghcmVxdWVzdCkgcmV0dXJuO1xuICAgICAgICBsZXQgdGltZW91dEVycm9yTWVzc2FnZSA9IF9jb25maWcudGltZW91dFxuICAgICAgICAgID8gJ3RpbWVvdXQgb2YgJyArIF9jb25maWcudGltZW91dCArICdtcyBleGNlZWRlZCdcbiAgICAgICAgICA6ICd0aW1lb3V0IGV4Y2VlZGVkJztcbiAgICAgICAgY29uc3QgdHJhbnNpdGlvbmFsID0gX2NvbmZpZy50cmFuc2l0aW9uYWwgfHwgdHJhbnNpdGlvbmFsRGVmYXVsdHM7XG4gICAgICAgIGlmIChfY29uZmlnLnRpbWVvdXRFcnJvck1lc3NhZ2UpIHtcbiAgICAgICAgICB0aW1lb3V0RXJyb3JNZXNzYWdlID0gX2NvbmZpZy50aW1lb3V0RXJyb3JNZXNzYWdlO1xuICAgICAgICB9XG4gICAgICAgIHJlamVjdChcbiAgICAgICAgICBuZXcgQXhpb3NFcnJvcihcbiAgICAgICAgICAgIHRpbWVvdXRFcnJvck1lc3NhZ2UsXG4gICAgICAgICAgICB0cmFuc2l0aW9uYWwuY2xhcmlmeVRpbWVvdXRFcnJvciA/IEF4aW9zRXJyb3IuRVRJTUVET1VUIDogQXhpb3NFcnJvci5FQ09OTkFCT1JURUQsXG4gICAgICAgICAgICBjb25maWcsXG4gICAgICAgICAgICByZXF1ZXN0XG4gICAgICAgICAgKVxuICAgICAgICApO1xuICAgICAgICBkb25lKCk7XG5cbiAgICAgICAgLy8gQ2xlYW4gdXAgcmVxdWVzdFxuICAgICAgICByZXF1ZXN0ID0gbnVsbDtcbiAgICAgIH07XG5cbiAgICAgIC8vIFJlbW92ZSBDb250ZW50LVR5cGUgaWYgZGF0YSBpcyB1bmRlZmluZWRcbiAgICAgIHJlcXVlc3REYXRhID09PSB1bmRlZmluZWQgJiYgcmVxdWVzdEhlYWRlcnMuc2V0Q29udGVudFR5cGUobnVsbCk7XG5cbiAgICAgIC8vIEFkZCB3aXRoQ3JlZGVudGlhbHMgdG8gcmVxdWVzdCBpZiBuZWVkZWRcbiAgICAgIGlmICghdXRpbHMuaXNVbmRlZmluZWQoX2NvbmZpZy53aXRoQ3JlZGVudGlhbHMpKSB7XG4gICAgICAgIHJlcXVlc3Qud2l0aENyZWRlbnRpYWxzID0gISFfY29uZmlnLndpdGhDcmVkZW50aWFscztcbiAgICAgIH1cblxuICAgICAgLy8gQWRkIHJlc3BvbnNlVHlwZSB0byByZXF1ZXN0IGlmIG5lZWRlZFxuICAgICAgaWYgKHJlc3BvbnNlVHlwZSAmJiByZXNwb25zZVR5cGUgIT09ICdqc29uJykge1xuICAgICAgICByZXF1ZXN0LnJlc3BvbnNlVHlwZSA9IF9jb25maWcucmVzcG9uc2VUeXBlO1xuICAgICAgfVxuXG4gICAgICAvLyBIYW5kbGUgcHJvZ3Jlc3MgaWYgbmVlZGVkXG4gICAgICBpZiAob25Eb3dubG9hZFByb2dyZXNzKSB7XG4gICAgICAgIFtkb3dubG9hZFRocm90dGxlZCwgZmx1c2hEb3dubG9hZCwgZmx1c2hEb3dubG9hZFdpdGhFdmVudF0gPSBwcm9ncmVzc0V2ZW50UmVkdWNlcihcbiAgICAgICAgICBvbkRvd25sb2FkUHJvZ3Jlc3MsXG4gICAgICAgICAgdHJ1ZVxuICAgICAgICApO1xuICAgICAgICByZXF1ZXN0LmFkZEV2ZW50TGlzdGVuZXIoJ3Byb2dyZXNzJywgZG93bmxvYWRUaHJvdHRsZWQpO1xuICAgICAgfVxuXG4gICAgICAvLyBOb3QgYWxsIGJyb3dzZXJzIHN1cHBvcnQgdXBsb2FkIGV2ZW50c1xuICAgICAgaWYgKG9uVXBsb2FkUHJvZ3Jlc3MgJiYgcmVxdWVzdC51cGxvYWQpIHtcbiAgICAgICAgW3VwbG9hZFRocm90dGxlZCwgZmx1c2hVcGxvYWRdID0gcHJvZ3Jlc3NFdmVudFJlZHVjZXIob25VcGxvYWRQcm9ncmVzcyk7XG5cbiAgICAgICAgcmVxdWVzdC51cGxvYWQuYWRkRXZlbnRMaXN0ZW5lcigncHJvZ3Jlc3MnLCB1cGxvYWRUaHJvdHRsZWQpO1xuXG4gICAgICAgIHJlcXVlc3QudXBsb2FkLmFkZEV2ZW50TGlzdGVuZXIoJ2xvYWRlbmQnLCBmbHVzaFVwbG9hZCk7XG4gICAgICB9XG5cbiAgICAgIGlmIChfY29uZmlnLmNhbmNlbFRva2VuIHx8IF9jb25maWcuc2lnbmFsKSB7XG4gICAgICAgIC8vIEhhbmRsZSBjYW5jZWxsYXRpb25cbiAgICAgICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIGZ1bmMtbmFtZXNcbiAgICAgICAgb25DYW5jZWxlZCA9IChjYW5jZWwpID0+IHtcbiAgICAgICAgICBpZiAoIXJlcXVlc3QpIHtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICB9XG4gICAgICAgICAgcmVqZWN0KCFjYW5jZWwgfHwgY2FuY2VsLnR5cGUgPyBuZXcgQ2FuY2VsZWRFcnJvcihudWxsLCBjb25maWcsIHJlcXVlc3QpIDogY2FuY2VsKTtcbiAgICAgICAgICBjb25zdCB4aHIgPSByZXF1ZXN0O1xuICAgICAgICAgIGRvbmUoKTtcbiAgICAgICAgICByZXF1ZXN0ID0gbnVsbDtcbiAgICAgICAgICB4aHIuYWJvcnQoKTtcbiAgICAgICAgfTtcblxuICAgICAgICBfY29uZmlnLmNhbmNlbFRva2VuICYmIF9jb25maWcuY2FuY2VsVG9rZW4uc3Vic2NyaWJlKG9uQ2FuY2VsZWQpO1xuICAgICAgICBpZiAoIXJlcXVlc3QpIHJldHVybjtcbiAgICAgICAgaWYgKF9jb25maWcuc2lnbmFsKSB7XG4gICAgICAgICAgX2NvbmZpZy5zaWduYWwuYWJvcnRlZFxuICAgICAgICAgICAgPyBvbkNhbmNlbGVkKClcbiAgICAgICAgICAgIDogX2NvbmZpZy5zaWduYWwuYWRkRXZlbnRMaXN0ZW5lcignYWJvcnQnLCBvbkNhbmNlbGVkKTtcbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICBpZiAoIXJlcXVlc3QpIHJldHVybjtcblxuICAgICAgY29uc3QgcHJvdG9jb2wgPSBwYXJzZVByb3RvY29sKF9jb25maWcudXJsKTtcblxuICAgICAgaWYgKHByb3RvY29sICYmICFwbGF0Zm9ybS5wcm90b2NvbHMuaW5jbHVkZXMocHJvdG9jb2wpKSB7XG4gICAgICAgIHJlamVjdChcbiAgICAgICAgICBuZXcgQXhpb3NFcnJvcihcbiAgICAgICAgICAgICdVbnN1cHBvcnRlZCBwcm90b2NvbCAnICsgcHJvdG9jb2wgKyAnOicsXG4gICAgICAgICAgICBBeGlvc0Vycm9yLkVSUl9CQURfUkVRVUVTVCxcbiAgICAgICAgICAgIGNvbmZpZ1xuICAgICAgICAgIClcbiAgICAgICAgKTtcbiAgICAgICAgZG9uZSgpO1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG5cbiAgICAgIGNvbnN0IHNlbmRSZXF1ZXN0ID0gKCkgPT4ge1xuICAgICAgICBpZiAoIXJlcXVlc3QpIHJldHVybjtcbiAgICAgICAgLy8gQXBwbHkgaGVhZGVycyBhZnRlciBhbiBhc3luY2hyb25vdXMgWFNSRiByZWFkIHNvIGV4aXN0aW5nIGhlYWRlcnMgYXJlXG4gICAgICAgIC8vIHJlcGxhY2VkIHRocm91Z2ggQXhpb3NIZWFkZXJzIHJhdGhlciB0aGFuIGFwcGVuZGVkIGJ5IHRoZSBuYXRpdmUgWEhSLlxuICAgICAgICBpZiAoJ3NldFJlcXVlc3RIZWFkZXInIGluIHJlcXVlc3QpIHtcbiAgICAgICAgICB1dGlscy5mb3JFYWNoKFxuICAgICAgICAgICAgdG9CeXRlU3RyaW5nSGVhZGVyT2JqZWN0KHJlcXVlc3RIZWFkZXJzKSxcbiAgICAgICAgICAgIGZ1bmN0aW9uIHNldFJlcXVlc3RIZWFkZXIodmFsLCBrZXkpIHtcbiAgICAgICAgICAgICAgcmVxdWVzdC5zZXRSZXF1ZXN0SGVhZGVyKGtleSwgdmFsKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICApO1xuICAgICAgICB9XG4gICAgICAgIHJlcXVlc3Quc2VuZChyZXF1ZXN0RGF0YSB8fCBudWxsKTtcbiAgICAgIH07XG5cbiAgICAgIGlmICh4c3JmQ29va2llTmFtZSkge1xuICAgICAgICAvLyBOYXRpdmUgWEhSIHRpbWVvdXQgc3RhcnRzIGF0IHNlbmQoKS4gQ292ZXIgY29va2llIHByZXBhcmF0aW9uIGFuZCB0aGVcbiAgICAgICAgLy8gc3Vic2VxdWVudCByZXF1ZXN0IHdpdGggdGhlIHNhbWUgYnVkZ2V0IGFuZCBleGlzdGluZyB0aW1lb3V0IGhhbmRsZXIuXG4gICAgICAgIGNvbnN0IG5vdyA9XG4gICAgICAgICAgdHlwZW9mIHBlcmZvcm1hbmNlICE9PSAndW5kZWZpbmVkJyAmJiB1dGlscy5pc0Z1bmN0aW9uKHBlcmZvcm1hbmNlLm5vdylcbiAgICAgICAgICAgID8gKCkgPT4gcGVyZm9ybWFuY2Uubm93KClcbiAgICAgICAgICAgIDogRGF0ZS5ub3c7XG4gICAgICAgIGNvbnN0IGRlYWRsaW5lID0gcmVxdWVzdC50aW1lb3V0ID4gMCA/IG5vdygpICsgTnVtYmVyKHJlcXVlc3QudGltZW91dCkgOiB1bmRlZmluZWQ7XG4gICAgICAgIGNvbnN0IGFib3J0T25UaW1lb3V0ID0gKCkgPT4ge1xuICAgICAgICAgIGlmICghcmVxdWVzdCkgcmV0dXJuO1xuICAgICAgICAgIGNvbnN0IHhociA9IHJlcXVlc3Q7XG4gICAgICAgICAgeGhyLm9udGltZW91dCgpO1xuICAgICAgICAgIHhoci5hYm9ydCgpO1xuICAgICAgICB9O1xuICAgICAgICBpZiAoZGVhZGxpbmUgIT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgIGNvbnN0IHNjaGVkdWxlVGltZW91dCA9ICgpID0+IHtcbiAgICAgICAgICAgIGNvbnN0IHJlbWFpbmluZyA9IGRlYWRsaW5lIC0gbm93KCk7XG4gICAgICAgICAgICBpZiAocmVtYWluaW5nID4gMCkge1xuICAgICAgICAgICAgICAvLyBCcm93c2VyIHRpbWVycyBvdmVyZmxvdyBhYm92ZSB0aGUgc2lnbmVkIDMyLWJpdCBkZWxheSBsaW1pdC5cbiAgICAgICAgICAgICAgdGltZW91dElkID0gc2V0VGltZW91dChzY2hlZHVsZVRpbWVvdXQsIE1hdGgubWluKHJlbWFpbmluZywgMHg3ZmZmZmZmZikpO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgYWJvcnRPblRpbWVvdXQoKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9O1xuICAgICAgICAgIHNjaGVkdWxlVGltZW91dCgpO1xuICAgICAgICB9XG5cbiAgICAgICAgY29va2llc1xuICAgICAgICAgIC5yZWFkQXN5bmMoeHNyZkNvb2tpZU5hbWUpXG4gICAgICAgICAgLnRoZW4oKHZhbHVlKSA9PiB7XG4gICAgICAgICAgICBpZiAoIXJlcXVlc3QpIHJldHVybjtcbiAgICAgICAgICAgIC8vIFByb21pc2UgY2FsbGJhY2tzIG1heSBydW4gYmVmb3JlIGFuIG92ZXJkdWUgdGltZXIgYWZ0ZXIgYSBidXN5IHRhc2suXG4gICAgICAgICAgICBpZiAoZGVhZGxpbmUgIT09IHVuZGVmaW5lZCAmJiBub3coKSA+PSBkZWFkbGluZSkge1xuICAgICAgICAgICAgICBhYm9ydE9uVGltZW91dCgpO1xuICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAodmFsdWUpIHtcbiAgICAgICAgICAgICAgY29uc3QgaGVhZGVyTmFtZSA9XG4gICAgICAgICAgICAgICAgdXRpbHMuaGFzT3duUHJvcChfY29uZmlnLCAneHNyZkhlYWRlck5hbWUnKSAmJiBfY29uZmlnLnhzcmZIZWFkZXJOYW1lO1xuICAgICAgICAgICAgICByZXF1ZXN0SGVhZGVycy5zZXQoaGVhZGVyTmFtZSwgdmFsdWUpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgc2VuZFJlcXVlc3QoKTtcbiAgICAgICAgICB9KVxuICAgICAgICAgIC5jYXRjaCgoZXJyb3IpID0+IHtcbiAgICAgICAgICAgIGlmICghcmVxdWVzdCkgcmV0dXJuO1xuICAgICAgICAgICAgcmVqZWN0KEF4aW9zRXJyb3IuZnJvbShlcnJvciwgbnVsbCwgY29uZmlnLCByZXF1ZXN0KSk7XG4gICAgICAgICAgICBkb25lKCk7XG4gICAgICAgICAgICByZXF1ZXN0ID0gbnVsbDtcbiAgICAgICAgICB9KTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHNlbmRSZXF1ZXN0KCk7XG4gICAgICB9XG4gICAgfSk7XG4gIH07XG4iLCJpbXBvcnQgQ2FuY2VsZWRFcnJvciBmcm9tICcuLi9jYW5jZWwvQ2FuY2VsZWRFcnJvci5qcyc7XG5pbXBvcnQgQXhpb3NFcnJvciBmcm9tICcuLi9jb3JlL0F4aW9zRXJyb3IuanMnO1xuaW1wb3J0IHV0aWxzIGZyb20gJy4uL3V0aWxzLmpzJztcblxuY29uc3QgY29tcG9zZVNpZ25hbHMgPSAoc2lnbmFscywgdGltZW91dCkgPT4ge1xuICBzaWduYWxzID0gc2lnbmFscyA/IHNpZ25hbHMuZmlsdGVyKEJvb2xlYW4pIDogW107XG5cbiAgaWYgKCF0aW1lb3V0ICYmICFzaWduYWxzLmxlbmd0aCkge1xuICAgIHJldHVybjtcbiAgfVxuXG4gIGNvbnN0IGNvbnRyb2xsZXIgPSBuZXcgQWJvcnRDb250cm9sbGVyKCk7XG5cbiAgbGV0IGFib3J0ZWQgPSBmYWxzZTtcblxuICBjb25zdCBvbmFib3J0ID0gZnVuY3Rpb24gKHJlYXNvbikge1xuICAgIGlmICghYWJvcnRlZCkge1xuICAgICAgYWJvcnRlZCA9IHRydWU7XG4gICAgICB1bnN1YnNjcmliZSgpO1xuICAgICAgY29uc3QgZXJyID0gcmVhc29uIGluc3RhbmNlb2YgRXJyb3IgPyByZWFzb24gOiB0aGlzLnJlYXNvbjtcbiAgICAgIGNvbnRyb2xsZXIuYWJvcnQoXG4gICAgICAgIGVyciBpbnN0YW5jZW9mIEF4aW9zRXJyb3JcbiAgICAgICAgICA/IGVyclxuICAgICAgICAgIDogbmV3IENhbmNlbGVkRXJyb3IoZXJyIGluc3RhbmNlb2YgRXJyb3IgPyBlcnIubWVzc2FnZSA6IGVycilcbiAgICAgICk7XG4gICAgfVxuICB9O1xuXG4gIGxldCB0aW1lciA9XG4gICAgdGltZW91dCAmJlxuICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgdGltZXIgPSBudWxsO1xuICAgICAgb25hYm9ydChuZXcgQXhpb3NFcnJvcihgdGltZW91dCBvZiAke3RpbWVvdXR9bXMgZXhjZWVkZWRgLCBBeGlvc0Vycm9yLkVUSU1FRE9VVCkpO1xuICAgIH0sIHRpbWVvdXQpO1xuXG4gIGNvbnN0IHVuc3Vic2NyaWJlID0gKCkgPT4ge1xuICAgIGlmICghc2lnbmFscykge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICB0aW1lciAmJiBjbGVhclRpbWVvdXQodGltZXIpO1xuICAgIHRpbWVyID0gbnVsbDtcbiAgICBzaWduYWxzLmZvckVhY2goKHNpZ25hbCkgPT4ge1xuICAgICAgY29uc3QgdW5zdWJzY3JpYmVTaWduYWwgPSB1dGlscy5nZXRTYWZlUHJvcChzaWduYWwsICd1bnN1YnNjcmliZScpO1xuICAgICAgdXRpbHMuaXNGdW5jdGlvbih1bnN1YnNjcmliZVNpZ25hbClcbiAgICAgICAgPyB1bnN1YnNjcmliZVNpZ25hbC5jYWxsKHNpZ25hbCwgb25hYm9ydClcbiAgICAgICAgOiBzaWduYWwucmVtb3ZlRXZlbnRMaXN0ZW5lcignYWJvcnQnLCBvbmFib3J0KTtcbiAgICB9KTtcbiAgICBzaWduYWxzID0gbnVsbDtcbiAgfTtcblxuICBzaWduYWxzLmZvckVhY2goKHNpZ25hbCkgPT4ge1xuICAgIGlmIChhYm9ydGVkKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgaWYgKHNpZ25hbC5hYm9ydGVkKSB7XG4gICAgICBvbmFib3J0LmNhbGwoc2lnbmFsKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICBzaWduYWwuYWRkRXZlbnRMaXN0ZW5lcignYWJvcnQnLCBvbmFib3J0LCB7IG9uY2U6IHRydWUgfSk7XG4gIH0pO1xuXG4gIGNvbnN0IHsgc2lnbmFsIH0gPSBjb250cm9sbGVyO1xuXG4gIHNpZ25hbC51bnN1YnNjcmliZSA9ICgpID0+IHV0aWxzLmFzYXAodW5zdWJzY3JpYmUpO1xuXG4gIHJldHVybiBzaWduYWw7XG59O1xuXG5leHBvcnQgZGVmYXVsdCBjb21wb3NlU2lnbmFscztcbiIsImV4cG9ydCBjb25zdCBzdHJlYW1DaHVuayA9IGZ1bmN0aW9uKiAoY2h1bmssIGNodW5rU2l6ZSkge1xuICBsZXQgbGVuID0gY2h1bmsuYnl0ZUxlbmd0aDtcblxuICBpZiAoIWNodW5rU2l6ZSB8fCBsZW4gPCBjaHVua1NpemUpIHtcbiAgICB5aWVsZCBjaHVuaztcbiAgICByZXR1cm47XG4gIH1cblxuICBsZXQgcG9zID0gMDtcbiAgbGV0IGVuZDtcblxuICB3aGlsZSAocG9zIDwgbGVuKSB7XG4gICAgZW5kID0gcG9zICsgY2h1bmtTaXplO1xuICAgIHlpZWxkIGNodW5rLnNsaWNlKHBvcywgZW5kKTtcbiAgICBwb3MgPSBlbmQ7XG4gIH1cbn07XG5cbmV4cG9ydCBjb25zdCByZWFkQnl0ZXMgPSBhc3luYyBmdW5jdGlvbiogKGl0ZXJhYmxlLCBjaHVua1NpemUpIHtcbiAgZm9yIGF3YWl0IChjb25zdCBjaHVuayBvZiByZWFkU3RyZWFtKGl0ZXJhYmxlKSkge1xuICAgIHlpZWxkKiBzdHJlYW1DaHVuayhjaHVuaywgY2h1bmtTaXplKTtcbiAgfVxufTtcblxuY29uc3QgcmVhZFN0cmVhbSA9IGFzeW5jIGZ1bmN0aW9uKiAoc3RyZWFtKSB7XG4gIGlmIChzdHJlYW1bU3ltYm9sLmFzeW5jSXRlcmF0b3JdKSB7XG4gICAgeWllbGQqIHN0cmVhbTtcbiAgICByZXR1cm47XG4gIH1cblxuICBjb25zdCByZWFkZXIgPSBzdHJlYW0uZ2V0UmVhZGVyKCk7XG4gIHRyeSB7XG4gICAgZm9yICg7Oykge1xuICAgICAgY29uc3QgeyBkb25lLCB2YWx1ZSB9ID0gYXdhaXQgcmVhZGVyLnJlYWQoKTtcbiAgICAgIGlmIChkb25lKSB7XG4gICAgICAgIGJyZWFrO1xuICAgICAgfVxuICAgICAgeWllbGQgdmFsdWU7XG4gICAgfVxuICB9IGZpbmFsbHkge1xuICAgIGF3YWl0IHJlYWRlci5jYW5jZWwoKTtcbiAgfVxufTtcblxuZXhwb3J0IGNvbnN0IHRyYWNrU3RyZWFtID0gKHN0cmVhbSwgY2h1bmtTaXplLCBvblByb2dyZXNzLCBvbkZpbmlzaCkgPT4ge1xuICBjb25zdCBpdGVyYXRvciA9IHJlYWRCeXRlcyhzdHJlYW0sIGNodW5rU2l6ZSk7XG5cbiAgbGV0IGJ5dGVzID0gMDtcbiAgbGV0IGRvbmU7XG4gIGxldCBfb25GaW5pc2ggPSAoZSkgPT4ge1xuICAgIGlmICghZG9uZSkge1xuICAgICAgZG9uZSA9IHRydWU7XG4gICAgICBvbkZpbmlzaCAmJiBvbkZpbmlzaChlKTtcbiAgICB9XG4gIH07XG5cbiAgcmV0dXJuIG5ldyBSZWFkYWJsZVN0cmVhbShcbiAgICB7XG4gICAgICBhc3luYyBwdWxsKGNvbnRyb2xsZXIpIHtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICBjb25zdCB7IGRvbmUsIHZhbHVlIH0gPSBhd2FpdCBpdGVyYXRvci5uZXh0KCk7XG5cbiAgICAgICAgICBpZiAoZG9uZSkge1xuICAgICAgICAgICAgX29uRmluaXNoKCk7XG4gICAgICAgICAgICBjb250cm9sbGVyLmNsb3NlKCk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgfVxuXG4gICAgICAgICAgbGV0IGxlbiA9IHZhbHVlLmJ5dGVMZW5ndGg7XG4gICAgICAgICAgaWYgKG9uUHJvZ3Jlc3MpIHtcbiAgICAgICAgICAgIGxldCBsb2FkZWRCeXRlcyA9IChieXRlcyArPSBsZW4pO1xuICAgICAgICAgICAgb25Qcm9ncmVzcyhsb2FkZWRCeXRlcyk7XG4gICAgICAgICAgfVxuICAgICAgICAgIGNvbnRyb2xsZXIuZW5xdWV1ZShuZXcgVWludDhBcnJheSh2YWx1ZSkpO1xuICAgICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgICBfb25GaW5pc2goZXJyKTtcbiAgICAgICAgICB0aHJvdyBlcnI7XG4gICAgICAgIH1cbiAgICAgIH0sXG4gICAgICBjYW5jZWwocmVhc29uKSB7XG4gICAgICAgIF9vbkZpbmlzaChyZWFzb24pO1xuICAgICAgICByZXR1cm4gaXRlcmF0b3IucmV0dXJuKCk7XG4gICAgICB9LFxuICAgIH0sXG4gICAge1xuICAgICAgaGlnaFdhdGVyTWFyazogMixcbiAgICB9XG4gICk7XG59O1xuIiwiaW1wb3J0IHV0aWxzIGZyb20gJy4uL3V0aWxzLmpzJztcblxuY29uc3QgQ1JMRiA9ICdcXHJcXG4nO1xuY29uc3Qgbm9ybWFsaXplTGluZXMgPSAodmFsdWUpID0+IFN0cmluZyh2YWx1ZSkucmVwbGFjZSgvXFxyXFxufFxccnxcXG4vZywgQ1JMRik7XG5jb25zdCBlc2NhcGVOYW1lID0gKHZhbHVlKSA9PlxuICBTdHJpbmcodmFsdWUpLnJlcGxhY2UoL1tcXHJcXG5cIl0vZywgKGNoYXIpID0+XG4gICAgY2hhciA9PT0gJ1xccicgPyAnJTBEJyA6IGNoYXIgPT09ICdcXG4nID8gJyUwQScgOiAnJTIyJ1xuICApO1xuXG4vLyBDb3VudCBVVEYtOCBieXRlcyB3aXRob3V0IGFsbG9jYXRpbmcgYW4gZW5jb2RlZCBjb3B5IG9mIGEgZmllbGQuIEZvcm1EYXRhXG4vLyBzdHJpbmcgdmFsdWVzIG5vcm1hbGl6ZSBsaW5lIGVuZGluZ3M7IEJsb2IvRmlsZSBjb250ZW50cyByZW1haW4gdW5jaGFuZ2VkLlxuY29uc3Qgc3RyaW5nQnl0ZXMgPSAodmFsdWUsIG5vcm1hbGl6ZSkgPT4ge1xuICBsZXQgbGVuZ3RoID0gMDtcbiAgZm9yIChsZXQgaSA9IDA7IGkgPCB2YWx1ZS5sZW5ndGg7IGkrKykge1xuICAgIGNvbnN0IGNvZGUgPSB2YWx1ZS5jaGFyQ29kZUF0KGkpO1xuICAgIGlmIChub3JtYWxpemUgJiYgKGNvZGUgPT09IDEzIHx8IGNvZGUgPT09IDEwKSkge1xuICAgICAgaWYgKGNvZGUgPT09IDEzICYmIHZhbHVlLmNoYXJDb2RlQXQoaSArIDEpID09PSAxMCkgaSsrO1xuICAgICAgbGVuZ3RoICs9IDI7XG4gICAgfSBlbHNlIGlmIChjb2RlIDwgMHg4MCkge1xuICAgICAgbGVuZ3RoKys7XG4gICAgfSBlbHNlIGlmIChjb2RlIDwgMHg4MDApIHtcbiAgICAgIGxlbmd0aCArPSAyO1xuICAgIH0gZWxzZSBpZiAoXG4gICAgICBjb2RlID49IDB4ZDgwMCAmJlxuICAgICAgY29kZSA8PSAweGRiZmYgJiZcbiAgICAgIHZhbHVlLmNoYXJDb2RlQXQoaSArIDEpID49IDB4ZGMwMCAmJlxuICAgICAgdmFsdWUuY2hhckNvZGVBdChpICsgMSkgPD0gMHhkZmZmXG4gICAgKSB7XG4gICAgICBsZW5ndGggKz0gNDtcbiAgICAgIGkrKztcbiAgICB9IGVsc2Uge1xuICAgICAgbGVuZ3RoICs9IDM7XG4gICAgfVxuICB9XG4gIHJldHVybiBsZW5ndGg7XG59O1xuXG4vLyBEZXNjcmliZSBzZXJpYWxpemF0aW9uIGZhaWx1cmVzIGluZGVwZW5kZW50bHkgb2YgYW55IHJlcXVlc3QgbGlicmFyeS5cbmV4cG9ydCBjbGFzcyBGb3JtRGF0YUVycm9yIGV4dGVuZHMgVHlwZUVycm9yIHtcbiAgY29uc3RydWN0b3IobWVzc2FnZSwgcmVhc29uKSB7XG4gICAgc3VwZXIobWVzc2FnZSk7XG4gICAgdGhpcy5uYW1lID0gJ0Zvcm1EYXRhRXJyb3InO1xuICAgIHRoaXMucmVhc29uID0gcmVhc29uO1xuICB9XG59XG5cbi8vIFRoZSBjYWxsZXIgc3VwcGxpZXMgdGhlIGJvdW5kYXJ5LCBCbG9iIGltcGxlbWVudGF0aW9uLCBhbmQgbGltaXQgZXJyb3IuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBmb3JtRGF0YVRvQmxvYihmb3JtLCBCbG9iLCBsaW1pdCwgbGltaXRFcnJvciwgYm91bmRhcnkpIHtcbiAgaWYgKCF1dGlscy5pc0Z1bmN0aW9uKEJsb2IpKSB7XG4gICAgdGhyb3cgbmV3IEZvcm1EYXRhRXJyb3IoJ0Jsb2IgaXMgbm90IHN1cHBvcnRlZCcsICdibG9iJyk7XG4gIH1cblxuICBpZiAoXG4gICAgIXV0aWxzLmlzU3RyaW5nKGJvdW5kYXJ5KSB8fFxuICAgICEvXltBLVphLXowLTknKCkrXywuLzo9PyAtXXsxLDcwfSQvLnRlc3QoYm91bmRhcnkpIHx8XG4gICAgLyAkLy50ZXN0KGJvdW5kYXJ5KVxuICApIHtcbiAgICB0aHJvdyBuZXcgRm9ybURhdGFFcnJvcignSW52YWxpZCBtdWx0aXBhcnQgYm91bmRhcnknLCAnYm91bmRhcnknKTtcbiAgfVxuICBjb25zdCBmb290ZXIgPSAnLS0nICsgYm91bmRhcnkgKyAnLS0nICsgQ1JMRjtcbiAgbGV0IGxlbmd0aCA9IGZvb3Rlci5sZW5ndGg7XG4gIGNvbnN0IHBhcnRzID0gW107XG4gIGNvbnN0IGNoZWNrTGVuZ3RoID0gKGV4dHJhKSA9PiB7XG4gICAgaWYgKGxlbmd0aCArIGV4dHJhID4gbGltaXQpIHRocm93IGxpbWl0RXJyb3IoKTtcbiAgfTtcbiAgY2hlY2tMZW5ndGgoMCk7XG5cbiAgZm9yIChjb25zdCBbbmFtZSwgdmFsdWVdIG9mIGZvcm0pIHtcbiAgICBjb25zdCBpc1N0cmluZyA9IHV0aWxzLmlzU3RyaW5nKHZhbHVlKTtcbiAgICBjb25zdCB2YWx1ZUxlbmd0aCA9IGlzU3RyaW5nID8gc3RyaW5nQnl0ZXModmFsdWUsIHRydWUpIDogdmFsdWUuc2l6ZTtcbiAgICBpZiAoIU51bWJlci5pc0Zpbml0ZSh2YWx1ZUxlbmd0aCkgfHwgdmFsdWVMZW5ndGggPCAwKSB7XG4gICAgICB0aHJvdyBuZXcgRm9ybURhdGFFcnJvcignVW5zdXBwb3J0ZWQgRm9ybURhdGEgcGFydCBzaXplJywgJ3BhcnQnKTtcbiAgICB9XG4gICAgLy8gUmVqZWN0IGxhcmdlIHZhbHVlcyBhbmQgbmFtZXMgYmVmb3JlIGJ1aWxkaW5nIG5vcm1hbGl6ZWQgaGVhZGVyIHN0cmluZ3MuXG4gICAgY2hlY2tMZW5ndGgoXG4gICAgICB2YWx1ZUxlbmd0aCArXG4gICAgICAgIHN0cmluZ0J5dGVzKG5hbWUsIHRydWUpICtcbiAgICAgICAgKCFpc1N0cmluZyAmJiB2YWx1ZS5uYW1lID8gc3RyaW5nQnl0ZXModmFsdWUubmFtZSwgZmFsc2UpIDogMCkgK1xuICAgICAgICAoIWlzU3RyaW5nICYmIHZhbHVlLnR5cGUgPyBzdHJpbmdCeXRlcyh2YWx1ZS50eXBlLCBmYWxzZSkgOiAwKVxuICAgICk7XG5cbiAgICBsZXQgaGVhZGVyID1cbiAgICAgICctLScgK1xuICAgICAgYm91bmRhcnkgK1xuICAgICAgQ1JMRiArXG4gICAgICAnQ29udGVudC1EaXNwb3NpdGlvbjogZm9ybS1kYXRhOyBuYW1lPVwiJyArXG4gICAgICBlc2NhcGVOYW1lKG5vcm1hbGl6ZUxpbmVzKG5hbWUpKSArXG4gICAgICAnXCInO1xuICAgIGlmICghaXNTdHJpbmcpIHtcbiAgICAgIGhlYWRlciArPVxuICAgICAgICAnOyBmaWxlbmFtZT1cIicgK1xuICAgICAgICBlc2NhcGVOYW1lKHV0aWxzLmlzU3RyaW5nKHZhbHVlLm5hbWUpID8gdmFsdWUubmFtZSA6ICdibG9iJykgK1xuICAgICAgICAnXCInICtcbiAgICAgICAgQ1JMRiArXG4gICAgICAgICdDb250ZW50LVR5cGU6ICcgK1xuICAgICAgICBTdHJpbmcodmFsdWUudHlwZSB8fCAnYXBwbGljYXRpb24vb2N0ZXQtc3RyZWFtJykucmVwbGFjZSgvW1xcclxcbl0vZywgJycpO1xuICAgIH1cbiAgICBoZWFkZXIgKz0gQ1JMRiArIENSTEY7XG4gICAgY29uc3QgcGFydExlbmd0aCA9IHN0cmluZ0J5dGVzKGhlYWRlciwgZmFsc2UpICsgdmFsdWVMZW5ndGggKyBDUkxGLmxlbmd0aDtcbiAgICBjaGVja0xlbmd0aChwYXJ0TGVuZ3RoKTtcbiAgICBsZW5ndGggKz0gcGFydExlbmd0aDtcbiAgICBwYXJ0cy5wdXNoKHsgaGVhZGVyLCB2YWx1ZSwgaXNTdHJpbmcgfSk7XG4gIH1cblxuICAvLyBOYXRpdmUgQmxvYiBjb21wb3NpdGlvbiByZXRhaW5zIGV4aXN0aW5nIEJsb2IvRmlsZSBkYXRhLiBObyBmaWxlIGlzIHJlYWRcbiAgLy8gYW5kIG5vIGNvbXBsZXRlIG11bHRpcGFydCBBcnJheUJ1ZmZlciBpcyBjcmVhdGVkIHRvIGRldGVybWluZSBpdHMgbGVuZ3RoLlxuICBjb25zdCBibG9iUGFydHMgPSBbXTtcbiAgZm9yIChjb25zdCBwYXJ0IG9mIHBhcnRzKSB7XG4gICAgYmxvYlBhcnRzLnB1c2gocGFydC5oZWFkZXIsIHBhcnQuaXNTdHJpbmcgPyBub3JtYWxpemVMaW5lcyhwYXJ0LnZhbHVlKSA6IHBhcnQudmFsdWUsIENSTEYpO1xuICB9XG4gIGJsb2JQYXJ0cy5wdXNoKGZvb3Rlcik7XG4gIHJldHVybiBuZXcgQmxvYihibG9iUGFydHMsIHsgdHlwZTogJ211bHRpcGFydC9mb3JtLWRhdGE7IGJvdW5kYXJ5PScgKyBib3VuZGFyeSB9KTtcbn1cbiIsImltcG9ydCB1dGlscyBmcm9tICcuLi91dGlscy5qcyc7XG5pbXBvcnQgcGxhdGZvcm0gZnJvbSAnLi4vcGxhdGZvcm0vaW5kZXguanMnO1xuaW1wb3J0IEF4aW9zRXJyb3IgZnJvbSAnLi9BeGlvc0Vycm9yLmpzJztcbmltcG9ydCBmb3JtRGF0YVRvQmxvYiwgeyBGb3JtRGF0YUVycm9yIH0gZnJvbSAnLi4vaGVscGVycy9mb3JtRGF0YVRvQmxvYi5qcyc7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIGNyZWF0ZU11bHRpcGFydEJvZHkoZm9ybSwgQmxvYiwgbGltaXQsIGxpbWl0RXJyb3IsIGJvdW5kYXJ5KSB7XG4gIC8vIFJlcG9ydCBtaXNzaW5nIEJsb2Igc3VwcG9ydCBiZWZvcmUgdHJ5aW5nIHRvIHNlbGVjdCBhIHJhbmRvbSBzb3VyY2UuXG4gIGlmICghdXRpbHMuaXNGdW5jdGlvbihCbG9iKSkge1xuICAgIHRocm93IG5ldyBBeGlvc0Vycm9yKCdCbG9iIGlzIG5vdCBzdXBwb3J0ZWQnLCBBeGlvc0Vycm9yLkVSUl9OT1RfU1VQUE9SVCk7XG4gIH1cblxuICBpZiAoYm91bmRhcnkgPT09IHVuZGVmaW5lZCkge1xuICAgIGlmICh1dGlscy5pc0Z1bmN0aW9uKHBsYXRmb3JtLmdlbmVyYXRlU3RyaW5nKSkge1xuICAgICAgYm91bmRhcnkgPSAnYXhpb3MtJyArIHBsYXRmb3JtLmdlbmVyYXRlU3RyaW5nKDM2LCAnMDEyMzQ1Njc4OWFiY2RlZicpO1xuICAgIH0gZWxzZSB7XG4gICAgICBjb25zdCBjcnlwdG8gPSB1dGlscy5nbG9iYWwuY3J5cHRvO1xuICAgICAgaWYgKCFjcnlwdG8gfHwgIXV0aWxzLmlzRnVuY3Rpb24oY3J5cHRvLmdldFJhbmRvbVZhbHVlcykpIHtcbiAgICAgICAgdGhyb3cgbmV3IEF4aW9zRXJyb3IoJ1JhbmRvbSBieXRlIGdlbmVyYXRpb24gaXMgbm90IHN1cHBvcnRlZCcsIEF4aW9zRXJyb3IuRVJSX05PVF9TVVBQT1JUKTtcbiAgICAgIH1cbiAgICAgIGNvbnN0IHJhbmRvbSA9IG5ldyBVaW50OEFycmF5KDE4KTtcbiAgICAgIGNyeXB0by5nZXRSYW5kb21WYWx1ZXMocmFuZG9tKTtcbiAgICAgIGJvdW5kYXJ5ID1cbiAgICAgICAgJ2F4aW9zLScgKyBBcnJheS5mcm9tKHJhbmRvbSwgKHZhbHVlKSA9PiAoJzAnICsgdmFsdWUudG9TdHJpbmcoMTYpKS5zbGljZSgtMikpLmpvaW4oJycpO1xuICAgIH1cbiAgfVxuXG4gIHRyeSB7XG4gICAgcmV0dXJuIGZvcm1EYXRhVG9CbG9iKGZvcm0sIEJsb2IsIGxpbWl0LCBsaW1pdEVycm9yLCBib3VuZGFyeSk7XG4gIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgaWYgKGVycm9yIGluc3RhbmNlb2YgRm9ybURhdGFFcnJvcikge1xuICAgICAgY29uc3QgY29kZSA9XG4gICAgICAgIGVycm9yLnJlYXNvbiA9PT0gJ2JvdW5kYXJ5JyA/IEF4aW9zRXJyb3IuRVJSX0JBRF9PUFRJT05fVkFMVUUgOiBBeGlvc0Vycm9yLkVSUl9CQURfUkVRVUVTVDtcbiAgICAgIHRocm93IG5ldyBBeGlvc0Vycm9yKGVycm9yLm1lc3NhZ2UsIGNvZGUpO1xuICAgIH1cbiAgICB0aHJvdyBlcnJvcjtcbiAgfVxufVxuIiwiLyoqXG4gKiBFc3RpbWF0ZSBkYXRhOiBVUkwgYnl0ZSBsZW5ndGhzICp3aXRob3V0KiBhbGxvY2F0aW5nIGxhcmdlIGJ1ZmZlcnMuXG4gKiAtIEZldGNoIHBlcmNlbnQtZGVjb2RlcyBhIGJhc2U2NCBib2R5IGJlZm9yZSBkZWNvZGluZyBpdC5cbiAqIC0gTm9kZSdzIEJ1ZmZlci5mcm9tKGJvZHksICdiYXNlNjQnKSBzaXplcyBpdHMgYmFja2luZyBhbGxvY2F0aW9uIGZyb20gdGhlXG4gKiAgIHBlcmNlbnQtZGVjb2RlZCBib2R5LCBpbmNsdWRpbmcgaWdub3JlZCBjaGFyYWN0ZXJzIGFuZCBjb250ZW50IGFmdGVyIHBhZGRpbmcuXG4gKiAtIE5vbi1iYXNlNjQgZGF0YSBpcyBwZXJjZW50LWRlY29kZWQgYW5kIHRoZW4gZW5jb2RlZCBhcyBVVEYtOC5cbiAqL1xuY29uc3QgaXNIZXhEaWdpdCA9IChjaGFyQ29kZSkgPT5cbiAgKGNoYXJDb2RlID49IDQ4ICYmIGNoYXJDb2RlIDw9IDU3KSB8fFxuICAoY2hhckNvZGUgPj0gNjUgJiYgY2hhckNvZGUgPD0gNzApIHx8XG4gIChjaGFyQ29kZSA+PSA5NyAmJiBjaGFyQ29kZSA8PSAxMDIpO1xuXG5jb25zdCBpc1BlcmNlbnRFbmNvZGVkQnl0ZSA9IChzdHIsIGksIGxlbikgPT5cbiAgaSArIDIgPCBsZW4gJiYgaXNIZXhEaWdpdChzdHIuY2hhckNvZGVBdChpICsgMSkpICYmIGlzSGV4RGlnaXQoc3RyLmNoYXJDb2RlQXQoaSArIDIpKTtcblxuY29uc3QgaGV4VmFsdWUgPSAoY2hhckNvZGUpID0+IChjaGFyQ29kZSA8PSA1NyA/IGNoYXJDb2RlIC0gNDggOiAoY2hhckNvZGUgJiAweGRmKSAtIDU1KTtcblxuY29uc3QgaXNCYXNlNjRDaGFyID0gKGNoYXJDb2RlKSA9PlxuICAoY2hhckNvZGUgPj0gNjUgJiYgY2hhckNvZGUgPD0gOTApIHx8IC8vIEEtWlxuICAoY2hhckNvZGUgPj0gOTcgJiYgY2hhckNvZGUgPD0gMTIyKSB8fCAvLyBhLXpcbiAgKGNoYXJDb2RlID49IDQ4ICYmIGNoYXJDb2RlIDw9IDU3KSB8fCAvLyAwLTlcbiAgY2hhckNvZGUgPT09IDQzIHx8IC8vICtcbiAgY2hhckNvZGUgPT09IDQ3IHx8IC8vIC9cbiAgY2hhckNvZGUgPT09IDQ1IHx8IC8vIC0gKGJhc2U2NHVybClcbiAgY2hhckNvZGUgPT09IDk1OyAvLyBfIChiYXNlNjR1cmwpXG5cbmNvbnN0IGlzQmFzZTY0V2hpdGVzcGFjZSA9IChjaGFyQ29kZSkgPT5cbiAgY2hhckNvZGUgPT09IDkgfHwgY2hhckNvZGUgPT09IDEwIHx8IGNoYXJDb2RlID09PSAxMiB8fCBjaGFyQ29kZSA9PT0gMTMgfHwgY2hhckNvZGUgPT09IDMyO1xuXG5jb25zdCBiYXNlNjRCeXRlcyA9IChzaWduaWZpY2FudCkgPT4ge1xuICBjb25zdCBncm91cHMgPSBNYXRoLmZsb29yKHNpZ25pZmljYW50IC8gNCk7XG4gIGNvbnN0IHJlbWFpbmRlciA9IHNpZ25pZmljYW50ICUgNDtcbiAgcmV0dXJuIGdyb3VwcyAqIDMgKyAocmVtYWluZGVyID09PSAyID8gMSA6IHJlbWFpbmRlciA9PT0gMyA/IDIgOiAwKTtcbn07XG5cbi8vIEJ1ZmZlci5ieXRlTGVuZ3RoKGJvZHksICdiYXNlNjQnKSB1c2VzIHRoZSByYXcgc3RyaW5nIGxlbmd0aCBhcyBhbiBhbGxvY2F0aW9uXG4vLyB1cHBlciBib3VuZCBldmVuIHdoZW4gQnVmZmVyLmZyb20gbGF0ZXIgaWdub3JlcyBjaGFyYWN0ZXJzIG9yIHN0b3BzIGF0ICc9Jy5cbmNvbnN0IGVzdGltYXRlQmFzZTY0QnVmZmVyQWxsb2NhdGlvbiA9IChib2R5KSA9PiB7XG4gIGNvbnN0IGxlbiA9IGJvZHkubGVuZ3RoO1xuICBsZXQgcGFkZGluZyA9IDA7XG5cbiAgaWYgKGxlbiA+IDAgJiYgYm9keS5jaGFyQ29kZUF0KGxlbiAtIDEpID09PSA2MSAvKiAnPScgKi8pIHtcbiAgICBwYWRkaW5nKys7XG5cbiAgICBpZiAobGVuID4gMSAmJiBib2R5LmNoYXJDb2RlQXQobGVuIC0gMikgPT09IDYxIC8qICc9JyAqLykge1xuICAgICAgcGFkZGluZysrO1xuICAgIH1cbiAgfVxuXG4gIHJldHVybiBNYXRoLmZsb29yKCgobGVuIC0gcGFkZGluZykgKiAzKSAvIDQpO1xufTtcblxuY29uc3QgZXN0aW1hdGVQZXJjZW50RGVjb2RlZEJhc2U2NEJ1ZmZlckFsbG9jYXRpb24gPSAoYm9keSkgPT4ge1xuICAvLyBPcmRpbmFyeSBCYXNlNjQgbmVlZHMgb25seSBpdHMgbGVuZ3RoIGFuZCB0cmFpbGluZyBwYWRkaW5nLlxuICBpZiAoYm9keS5pbmRleE9mKCclJykgPT09IC0xKSB7XG4gICAgcmV0dXJuIGVzdGltYXRlQmFzZTY0QnVmZmVyQWxsb2NhdGlvbihib2R5KTtcbiAgfVxuXG4gIGxldCBsZW5ndGggPSAwO1xuICBsZXQgcHJldmlvdXMgPSAwO1xuICBsZXQgbGFzdCA9IDA7XG5cbiAgZm9yIChsZXQgaSA9IDAsIGxlbiA9IGJvZHkubGVuZ3RoOyBpIDwgbGVuOyBpKyspIHtcbiAgICBsZXQgY29kZSA9IGJvZHkuY2hhckNvZGVBdChpKTtcbiAgICBpZiAoY29kZSA9PT0gMzcgLyogJyUnICovICYmIGlzUGVyY2VudEVuY29kZWRCeXRlKGJvZHksIGksIGxlbikpIHtcbiAgICAgIGNvZGUgPSBoZXhWYWx1ZShib2R5LmNoYXJDb2RlQXQoaSArIDEpKSAqIDE2ICsgaGV4VmFsdWUoYm9keS5jaGFyQ29kZUF0KGkgKyAyKSk7XG4gICAgICBpICs9IDI7XG4gICAgfVxuICAgIGxlbmd0aCsrO1xuICAgIHByZXZpb3VzID0gbGFzdDtcbiAgICBsYXN0ID0gY29kZTtcbiAgfVxuXG4gIGNvbnN0IHBhZGRpbmcgPSBsYXN0ID09PSA2MSA/IChwcmV2aW91cyA9PT0gNjEgPyAyIDogMSkgOiAwO1xuICByZXR1cm4gTWF0aC5mbG9vcigoKGxlbmd0aCAtIHBhZGRpbmcpICogMykgLyA0KTtcbn07XG5cbmNvbnN0IGVzdGltYXRlUGVyY2VudERlY29kZWRCYXNlNjRCeXRlcyA9IChib2R5KSA9PiB7XG4gIGNvbnN0IGxlbiA9IGJvZHkubGVuZ3RoO1xuICBsZXQgc2lnbmlmaWNhbnQgPSAwO1xuICBsZXQgcGFkZGluZyA9IDA7XG4gIGxldCBpbnZhbGlkID0gZmFsc2U7XG5cbiAgZm9yIChsZXQgaSA9IDA7IGkgPCBsZW47IGkrKykge1xuICAgIGxldCBjb2RlID0gYm9keS5jaGFyQ29kZUF0KGkpO1xuXG4gICAgaWYgKGNvZGUgPT09IDM3IC8qICclJyAqLyAmJiBpc1BlcmNlbnRFbmNvZGVkQnl0ZShib2R5LCBpLCBsZW4pKSB7XG4gICAgICBjb2RlID0gaGV4VmFsdWUoYm9keS5jaGFyQ29kZUF0KGkgKyAxKSkgKiAxNiArIGhleFZhbHVlKGJvZHkuY2hhckNvZGVBdChpICsgMikpO1xuICAgICAgaSArPSAyO1xuICAgIH1cblxuICAgIGlmIChpc0Jhc2U2NFdoaXRlc3BhY2UoY29kZSkpIHtcbiAgICAgIGNvbnRpbnVlO1xuICAgIH1cblxuICAgIGlmIChjb2RlID09PSA2MSAvKiAnPScgKi8pIHtcbiAgICAgIHBhZGRpbmcrKztcbiAgICAgIGNvbnRpbnVlO1xuICAgIH1cblxuICAgIGlmICghaXNCYXNlNjRDaGFyKGNvZGUpIHx8IHBhZGRpbmcgPiAwKSB7XG4gICAgICBpbnZhbGlkID0gdHJ1ZTtcbiAgICAgIGNvbnRpbnVlO1xuICAgIH1cblxuICAgIHNpZ25pZmljYW50Kys7XG4gIH1cblxuICAvLyBGZXRjaCByZWplY3RzIG1hbGZvcm1lZCBmb3JnaXZpbmctYmFzZTY0IGlucHV0LiBSZXR1cm5pbmcgdGhlIHJhdy1zaXplXG4gIC8vIGFsbG9jYXRpb24gYm91bmQga2VlcHMgdGhhdCBpbnZhbGlkIGlucHV0IGZyb20gYmVjb21pbmcgYSBwcmUtY2hlY2sgYnlwYXNzLlxuICBpZiAoXG4gICAgaW52YWxpZCB8fFxuICAgIHBhZGRpbmcgPiAyIHx8XG4gICAgKHBhZGRpbmcgPiAwICYmIChzaWduaWZpY2FudCArIHBhZGRpbmcpICUgNCAhPT0gMCkgfHxcbiAgICBzaWduaWZpY2FudCAlIDQgPT09IDFcbiAgKSB7XG4gICAgcmV0dXJuIGVzdGltYXRlQmFzZTY0QnVmZmVyQWxsb2NhdGlvbihib2R5KTtcbiAgfVxuXG4gIHJldHVybiBiYXNlNjRCeXRlcyhzaWduaWZpY2FudCk7XG59O1xuXG5jb25zdCBlc3RpbWF0ZURhdGFVUkxCeXRlcyA9ICh1cmwsIGVzdGltYXRlQmFzZTY0LCBiYXNlNjRQYXR0ZXJuKSA9PiB7XG4gIGlmICghdXJsIHx8IHR5cGVvZiB1cmwgIT09ICdzdHJpbmcnKSByZXR1cm4gMDtcbiAgaWYgKCEvXmRhdGE6L2kudGVzdCh1cmwpKSByZXR1cm4gMDtcblxuICBjb25zdCBjb21tYSA9IHVybC5pbmRleE9mKCcsJyk7XG4gIGlmIChjb21tYSA8IDApIHJldHVybiAwO1xuXG4gIGNvbnN0IG1ldGEgPSB1cmwuc2xpY2UoNSwgY29tbWEpO1xuICBjb25zdCBib2R5ID0gdXJsLnNsaWNlKGNvbW1hICsgMSk7XG4gIGNvbnN0IGlzQmFzZTY0ID0gYmFzZTY0UGF0dGVybi50ZXN0KG1ldGEpO1xuXG4gIGlmIChpc0Jhc2U2NCkge1xuICAgIHJldHVybiBlc3RpbWF0ZUJhc2U2NChib2R5KTtcbiAgfVxuXG4gIC8vIENvbXB1dGUgVVRGLTggYnl0ZSBsZW5ndGggZGlyZWN0bHkgZnJvbSBVVEYtMTYgY29kZSB1bml0cyB3aXRob3V0IGFsbG9jYXRpbmdcbiAgLy8gYSBieXRlIGJ1ZmZlciAoVGV4dEVuY29kZXIuZW5jb2RlIHdvdWxkIGRlZmVhdCB0aGUgRG9TIGd1YXJkIG9uIGxhcmdlIGJvZGllcykuXG4gIC8vIFZhbGlkICVYWCB0cmlwbGV0cyBjb3VudCBhcyBvbmUgZGVjb2RlZCBieXRlOyB0aGlzIG1hdGNoZXMgdGhlIGJ5dGVzIHRoYXRcbiAgLy8gZGVjb2RlVVJJQ29tcG9uZW50KGJvZHkpIHdvdWxkIHByb2R1Y2UgYmVmb3JlIEJ1ZmZlciByZS1lbmNvZGVzIHRoZSBzdHJpbmcuXG4gIGxldCBieXRlcyA9IDA7XG4gIGZvciAobGV0IGkgPSAwLCBsZW4gPSBib2R5Lmxlbmd0aDsgaSA8IGxlbjsgaSsrKSB7XG4gICAgY29uc3QgYyA9IGJvZHkuY2hhckNvZGVBdChpKTtcbiAgICBpZiAoYyA9PT0gMzcgLyogJyUnICovICYmIGlzUGVyY2VudEVuY29kZWRCeXRlKGJvZHksIGksIGxlbikpIHtcbiAgICAgIGJ5dGVzICs9IDE7XG4gICAgICBpICs9IDI7XG4gICAgfSBlbHNlIGlmIChjIDwgMHg4MCkge1xuICAgICAgYnl0ZXMgKz0gMTtcbiAgICB9IGVsc2UgaWYgKGMgPCAweDgwMCkge1xuICAgICAgYnl0ZXMgKz0gMjtcbiAgICB9IGVsc2UgaWYgKGMgPj0gMHhkODAwICYmIGMgPD0gMHhkYmZmICYmIGkgKyAxIDwgbGVuKSB7XG4gICAgICBjb25zdCBuZXh0ID0gYm9keS5jaGFyQ29kZUF0KGkgKyAxKTtcbiAgICAgIGlmIChuZXh0ID49IDB4ZGMwMCAmJiBuZXh0IDw9IDB4ZGZmZikge1xuICAgICAgICBieXRlcyArPSA0O1xuICAgICAgICBpKys7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBieXRlcyArPSAzO1xuICAgICAgfVxuICAgIH0gZWxzZSB7XG4gICAgICBieXRlcyArPSAzO1xuICAgIH1cbiAgfVxuICByZXR1cm4gYnl0ZXM7XG59O1xuXG4vKipcbiAqIEVzdGltYXRlIHRoZSBwZXJjZW50LWRlY29kZWQgcGF5bG9hZCBzaXplIHVzZWQgYnkgRmV0Y2ggZGF0YTogVVJMcy5cbiAqXG4gKiBAcGFyYW0ge3N0cmluZ30gdXJsXG4gKiBAcmV0dXJucyB7bnVtYmVyfVxuICovXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBlc3RpbWF0ZURhdGFVUkxEZWNvZGVkQnl0ZXModXJsKSB7XG4gIC8vIEZldGNoIHJlbW92ZXMgVVJMIGZyYWdtZW50cyBiZWZvcmUgcHJvY2Vzc2luZyBhIGRhdGE6IFVSTC5cbiAgY29uc3QgZnJhZ21lbnRJbmRleCA9IHR5cGVvZiB1cmwgPT09ICdzdHJpbmcnID8gdXJsLmluZGV4T2YoJyMnKSA6IC0xO1xuXG4gIHJldHVybiBlc3RpbWF0ZURhdGFVUkxCeXRlcyhcbiAgICBmcmFnbWVudEluZGV4ID09PSAtMSA/IHVybCA6IHVybC5zbGljZSgwLCBmcmFnbWVudEluZGV4KSxcbiAgICBlc3RpbWF0ZVBlcmNlbnREZWNvZGVkQmFzZTY0Qnl0ZXMsXG4gICAgLzsgKmJhc2U2NFtcXHRcXG5cXGZcXHIgXSokL2lcbiAgKTtcbn1cblxuLyoqXG4gKiBFc3RpbWF0ZSB0aGUgQnVmZmVyIGJhY2tpbmcgYWxsb2NhdGlvbiB1c2VkIGFmdGVyIE5vZGUncyBwZXJjZW50LWRlY29kaW5nIHN0ZXAuXG4gKlxuICogQHBhcmFtIHtzdHJpbmd9IHVybFxuICogQHJldHVybnMge251bWJlcn1cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGVzdGltYXRlRGF0YVVSTEJ1ZmZlckFsbG9jYXRpb24odXJsKSB7XG4gIC8vIE1hdGNoIGZyb21EYXRhVVJJJ3MgY2FzZS1pbnNlbnNpdGl2ZSBwcm90b2NvbCBhbmQgZW5jb2Rpbmcgc3VmZml4LlxuICByZXR1cm4gZXN0aW1hdGVEYXRhVVJMQnl0ZXModXJsLCBlc3RpbWF0ZVBlcmNlbnREZWNvZGVkQmFzZTY0QnVmZmVyQWxsb2NhdGlvbiwgLztiYXNlNjQkL2kpO1xufVxuIiwiZXhwb3J0IGNvbnN0IFZFUlNJT04gPSBcIjEuMjEuMVwiOyIsImltcG9ydCBwbGF0Zm9ybSBmcm9tICcuLi9wbGF0Zm9ybS9pbmRleC5qcyc7XG5pbXBvcnQgdXRpbHMgZnJvbSAnLi4vdXRpbHMuanMnO1xuaW1wb3J0IEF4aW9zRXJyb3IgZnJvbSAnLi4vY29yZS9BeGlvc0Vycm9yLmpzJztcbmltcG9ydCBjb21wb3NlU2lnbmFscyBmcm9tICcuLi9oZWxwZXJzL2NvbXBvc2VTaWduYWxzLmpzJztcbmltcG9ydCB7IHRyYWNrU3RyZWFtIH0gZnJvbSAnLi4vaGVscGVycy90cmFja1N0cmVhbS5qcyc7XG5pbXBvcnQgY3JlYXRlTXVsdGlwYXJ0Qm9keSBmcm9tICcuLi9jb3JlL2NyZWF0ZU11bHRpcGFydEJvZHkuanMnO1xuaW1wb3J0IEF4aW9zSGVhZGVycyBmcm9tICcuLi9jb3JlL0F4aW9zSGVhZGVycy5qcyc7XG5pbXBvcnQge1xuICBwcm9ncmVzc0V2ZW50UmVkdWNlcixcbiAgcHJvZ3Jlc3NFdmVudERlY29yYXRvcixcbiAgYXN5bmNEZWNvcmF0b3IsXG59IGZyb20gJy4uL2hlbHBlcnMvcHJvZ3Jlc3NFdmVudFJlZHVjZXIuanMnO1xuaW1wb3J0IHJlc29sdmVDb25maWcgZnJvbSAnLi4vaGVscGVycy9yZXNvbHZlQ29uZmlnLmpzJztcbmltcG9ydCBzZXR0bGUgZnJvbSAnLi4vY29yZS9zZXR0bGUuanMnO1xuaW1wb3J0IGVzdGltYXRlRGF0YVVSTERlY29kZWRCeXRlcyBmcm9tICcuLi9oZWxwZXJzL2VzdGltYXRlRGF0YVVSTERlY29kZWRCeXRlcy5qcyc7XG5pbXBvcnQgeyBWRVJTSU9OIH0gZnJvbSAnLi4vZW52L2RhdGEuanMnO1xuaW1wb3J0IHsgdG9CeXRlU3RyaW5nSGVhZGVyT2JqZWN0IH0gZnJvbSAnLi4vaGVscGVycy9zYW5pdGl6ZUhlYWRlclZhbHVlLmpzJztcblxuY29uc3QgREVGQVVMVF9DSFVOS19TSVpFID0gNjQgKiAxMDI0O1xuXG5jb25zdCBERUZBVUxUX1JFUVVFU1RfT1BUSU9OUyA9IHtcbiAgY2FjaGU6ICdkZWZhdWx0JyxcbiAgcmVkaXJlY3Q6ICdmb2xsb3cnLFxuICByZWZlcnJlcjogJ2Fib3V0OmNsaWVudCcsXG4gIHJlZmVycmVyUG9saWN5OiAnJyxcbiAgbW9kZTogJ2NvcnMnLFxuICBpbnRlZ3JpdHk6ICcnLFxuICBrZWVwYWxpdmU6IGZhbHNlLFxuICBwcmlvcml0eTogJ2F1dG8nLFxuICB3aW5kb3c6IG51bGwsXG59O1xuXG5jb25zdCB7IGlzRnVuY3Rpb24gfSA9IHV0aWxzO1xuXG4vKipcbiAqIEVuY29kZSBhIFVURi04IHN0cmluZyB0byBhIExhdGluLTEgYnl0ZSBzdHJpbmcgZm9yIHVzZSB3aXRoIGJ0b2EoKS5cbiAqIFRoaXMgaXMgYSBtb2Rlcm4gcmVwbGFjZW1lbnQgZm9yIHRoZSBkZXByZWNhdGVkIHVuZXNjYXBlKGVuY29kZVVSSUNvbXBvbmVudChzdHIpKSBwYXR0ZXJuLlxuICpcbiAqIEBwYXJhbSB7c3RyaW5nfSBzdHIgVGhlIHN0cmluZyB0byBlbmNvZGVcbiAqXG4gKiBAcmV0dXJucyB7c3RyaW5nfSBVVEYtOCBieXRlcyBhcyBhIExhdGluLTEgc3RyaW5nXG4gKi9cbmNvbnN0IGVuY29kZVVURjggPSAoc3RyKSA9PlxuICBlbmNvZGVVUklDb21wb25lbnQoc3RyKS5yZXBsYWNlKC8lKFswLTlBLUZdezJ9KS9naSwgKF8sIGhleCkgPT5cbiAgICBTdHJpbmcuZnJvbUNoYXJDb2RlKHBhcnNlSW50KGhleCwgMTYpKVxuICApO1xuXG4vLyBOb2RlJ3MgV0hBVFdHIFVSTCBwYXJzZXIgcmV0dXJucyBgdXNlcm5hbWVgIGFuZCBgcGFzc3dvcmRgIHBlcmNlbnQtZW5jb2RlZC5cbi8vIERlY29kZSBiZWZvcmUgY29tcG9zaW5nIHRoZSBgYXV0aGAgb3B0aW9uIHNvIGNyZWRlbnRpYWxzIHN1Y2ggYXNcbi8vIGBteSU0MGVtYWlsLmNvbTpwYXNzYCBhcmUgc2VudCBhcyBgbXlAZW1haWwuY29tOnBhc3NgLiBGYWxscyBiYWNrIHRvIHRoZVxuLy8gb3JpZ2luYWwgdmFsdWUgZm9yIG1hbGZvcm1lZCBpbnB1dCBzbyBhIGJhZCBlbmNvZGluZyBuZXZlciB0aHJvd3MuXG5jb25zdCBkZWNvZGVVUklDb21wb25lbnRTYWZlID0gKHZhbHVlKSA9PiB7XG4gIGlmICghdXRpbHMuaXNTdHJpbmcodmFsdWUpKSB7XG4gICAgcmV0dXJuIHZhbHVlO1xuICB9XG5cbiAgdHJ5IHtcbiAgICByZXR1cm4gZGVjb2RlVVJJQ29tcG9uZW50KHZhbHVlKTtcbiAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICByZXR1cm4gdmFsdWU7XG4gIH1cbn07XG5cbmNvbnN0IHRlc3QgPSAoZm4sIC4uLmFyZ3MpID0+IHtcbiAgdHJ5IHtcbiAgICByZXR1cm4gISFmbiguLi5hcmdzKTtcbiAgfSBjYXRjaCAoZSkge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxufTtcblxuY29uc3QgbWF5YmVXaXRoQXV0aENyZWRlbnRpYWxzID0gKHVybCkgPT4ge1xuICBjb25zdCBwcm90b2NvbEluZGV4ID0gdXJsLmluZGV4T2YoJzovLycpO1xuICBsZXQgdXJsVG9DaGVjayA9IHVybDtcbiAgaWYgKHByb3RvY29sSW5kZXggIT09IC0xKSB7XG4gICAgdXJsVG9DaGVjayA9IHVybFRvQ2hlY2suc2xpY2UocHJvdG9jb2xJbmRleCArIDMpO1xuICB9XG4gIHJldHVybiB1cmxUb0NoZWNrLmluY2x1ZGVzKCdAJykgfHwgdXJsVG9DaGVjay5pbmNsdWRlcygnOicpO1xufTtcblxuY29uc3QgZmFjdG9yeSA9IChlbnYpID0+IHtcbiAgY29uc3QgZ2xvYmFsT2JqZWN0ID1cbiAgICB1dGlscy5nbG9iYWwgIT09IHVuZGVmaW5lZCAmJiB1dGlscy5nbG9iYWwgIT09IG51bGwgPyB1dGlscy5nbG9iYWwgOiBnbG9iYWxUaGlzO1xuICBjb25zdCB7IFJlYWRhYmxlU3RyZWFtLCBUZXh0RW5jb2RlciB9ID0gZ2xvYmFsT2JqZWN0O1xuXG4gIGVudiA9IHV0aWxzLm1lcmdlLmNhbGwoXG4gICAge1xuICAgICAgc2tpcFVuZGVmaW5lZDogdHJ1ZSxcbiAgICB9LFxuICAgIHtcbiAgICAgIFJlcXVlc3Q6IGdsb2JhbE9iamVjdC5SZXF1ZXN0LFxuICAgICAgUmVzcG9uc2U6IGdsb2JhbE9iamVjdC5SZXNwb25zZSxcbiAgICAgIEJsb2I6IGdsb2JhbE9iamVjdC5CbG9iLFxuICAgIH0sXG4gICAgZW52XG4gICk7XG5cbiAgY29uc3QgZW52RmV0Y2ggPSB1dGlscy5oYXNPd25Qcm9wKGVudiwgJ2ZldGNoJykgPyBlbnYuZmV0Y2ggOiB1bmRlZmluZWQ7XG4gIGNvbnN0IHsgUmVxdWVzdCwgUmVzcG9uc2UsIEJsb2IgfSA9IGVudjtcbiAgY29uc3QgaXNGZXRjaFN1cHBvcnRlZCA9IGVudkZldGNoID8gaXNGdW5jdGlvbihlbnZGZXRjaCkgOiB0eXBlb2YgZmV0Y2ggPT09ICdmdW5jdGlvbic7XG4gIGNvbnN0IGlzUmVxdWVzdFN1cHBvcnRlZCA9IGlzRnVuY3Rpb24oUmVxdWVzdCk7XG4gIGNvbnN0IGlzUmVzcG9uc2VTdXBwb3J0ZWQgPSBpc0Z1bmN0aW9uKFJlc3BvbnNlKTtcblxuICBpZiAoIWlzRmV0Y2hTdXBwb3J0ZWQpIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cblxuICBjb25zdCBpc1JlYWRhYmxlU3RyZWFtU3VwcG9ydGVkID0gaXNGZXRjaFN1cHBvcnRlZCAmJiBpc0Z1bmN0aW9uKFJlYWRhYmxlU3RyZWFtKTtcblxuICBjb25zdCBlbmNvZGVUZXh0ID1cbiAgICBpc0ZldGNoU3VwcG9ydGVkICYmXG4gICAgKHR5cGVvZiBUZXh0RW5jb2RlciA9PT0gJ2Z1bmN0aW9uJ1xuICAgICAgPyAoXG4gICAgICAgICAgKGVuY29kZXIpID0+IChzdHIpID0+XG4gICAgICAgICAgICBlbmNvZGVyLmVuY29kZShzdHIpXG4gICAgICAgICkobmV3IFRleHRFbmNvZGVyKCkpXG4gICAgICA6IGFzeW5jIChzdHIpID0+IG5ldyBVaW50OEFycmF5KGF3YWl0IG5ldyBSZXF1ZXN0KHN0cikuYXJyYXlCdWZmZXIoKSkpO1xuXG4gIGNvbnN0IHN1cHBvcnRzUmVxdWVzdFN0cmVhbSA9XG4gICAgaXNSZXF1ZXN0U3VwcG9ydGVkICYmXG4gICAgaXNSZWFkYWJsZVN0cmVhbVN1cHBvcnRlZCAmJlxuICAgIHRlc3QoKCkgPT4ge1xuICAgICAgbGV0IGR1cGxleEFjY2Vzc2VkID0gZmFsc2U7XG5cbiAgICAgIGNvbnN0IHJlcXVlc3QgPSBuZXcgUmVxdWVzdChwbGF0Zm9ybS5vcmlnaW4sIHtcbiAgICAgICAgYm9keTogbmV3IFJlYWRhYmxlU3RyZWFtKCksXG4gICAgICAgIG1ldGhvZDogJ1BPU1QnLFxuICAgICAgICBnZXQgZHVwbGV4KCkge1xuICAgICAgICAgIGR1cGxleEFjY2Vzc2VkID0gdHJ1ZTtcbiAgICAgICAgICByZXR1cm4gJ2hhbGYnO1xuICAgICAgICB9LFxuICAgICAgfSk7XG5cbiAgICAgIGNvbnN0IGhhc0NvbnRlbnRUeXBlID0gcmVxdWVzdC5oZWFkZXJzLmhhcygnQ29udGVudC1UeXBlJyk7XG5cbiAgICAgIGlmIChyZXF1ZXN0LmJvZHkgIT0gbnVsbCkge1xuICAgICAgICByZXF1ZXN0LmJvZHkuY2FuY2VsKCk7XG4gICAgICB9XG5cbiAgICAgIHJldHVybiBkdXBsZXhBY2Nlc3NlZCAmJiAhaGFzQ29udGVudFR5cGU7XG4gICAgfSk7XG5cbiAgY29uc3Qgc3VwcG9ydHNSZXNwb25zZVN0cmVhbSA9XG4gICAgaXNSZXNwb25zZVN1cHBvcnRlZCAmJlxuICAgIGlzUmVhZGFibGVTdHJlYW1TdXBwb3J0ZWQgJiZcbiAgICB0ZXN0KCgpID0+IHV0aWxzLmlzUmVhZGFibGVTdHJlYW0obmV3IFJlc3BvbnNlKCcnKS5ib2R5KSk7XG5cbiAgLy8gU29tZSBydW50aW1lcyByZWplY3QgZXZlcnkgZXhwbGljaXQgY2FjaGUgbW9kZS4gVXNlIG93biBkZWZhdWx0cyBmb3IgYm90aFxuICAvLyBwcm9iZXMgc28gdW5yZWxhdGVkIHBvbGx1dGVkIG9wdGlvbnMgY2Fubm90IGFmZmVjdCBjYWNoZS1tb2RlIGRldGVjdGlvbi5cbiAgY29uc3QgcmVxdWVzdERlZmF1bHRzID0gT2JqZWN0LmFzc2lnbihPYmplY3QuY3JlYXRlKG51bGwpLCBERUZBVUxUX1JFUVVFU1RfT1BUSU9OUyk7XG5cbiAgaWYgKGlzUmVxdWVzdFN1cHBvcnRlZCAmJiAhdGVzdCgoKSA9PiBuZXcgUmVxdWVzdChwbGF0Zm9ybS5vcmlnaW4sIHJlcXVlc3REZWZhdWx0cykpKSB7XG4gICAgZGVsZXRlIHJlcXVlc3REZWZhdWx0cy5jYWNoZTtcblxuICAgIC8vIE9ubHkgb21pdCBjYWNoZSB3aGVuIHRoYXQgbWFrZXMgUmVxdWVzdCBjb25zdHJ1Y3Rpb24gc3VjY2VlZC4gT3RoZXJ3aXNlXG4gICAgLy8gcmV0YWluIHRoZSBleHBsaWNpdCBkZWZhdWx0IHRoYXQgcHJvdGVjdHMgc3VwcG9ydGluZyBydW50aW1lcyBmcm9tIHBvbGx1dGlvbi5cbiAgICBpZiAoIXRlc3QoKCkgPT4gbmV3IFJlcXVlc3QocGxhdGZvcm0ub3JpZ2luLCByZXF1ZXN0RGVmYXVsdHMpKSkge1xuICAgICAgcmVxdWVzdERlZmF1bHRzLmNhY2hlID0gREVGQVVMVF9SRVFVRVNUX09QVElPTlMuY2FjaGU7XG4gICAgfVxuICB9XG5cbiAgY29uc3QgcmVzb2x2ZXJzID0ge1xuICAgIHN0cmVhbTogc3VwcG9ydHNSZXNwb25zZVN0cmVhbSAmJiAoKHJlcykgPT4gcmVzLmJvZHkpLFxuICB9O1xuXG4gIGlzRmV0Y2hTdXBwb3J0ZWQgJiZcbiAgICAoKCkgPT4ge1xuICAgICAgWyd0ZXh0JywgJ2FycmF5QnVmZmVyJywgJ2Jsb2InLCAnZm9ybURhdGEnLCAnc3RyZWFtJ10uZm9yRWFjaCgodHlwZSkgPT4ge1xuICAgICAgICAhcmVzb2x2ZXJzW3R5cGVdICYmXG4gICAgICAgICAgKHJlc29sdmVyc1t0eXBlXSA9IChyZXMsIGNvbmZpZykgPT4ge1xuICAgICAgICAgICAgbGV0IG1ldGhvZCA9IHJlcyAmJiByZXNbdHlwZV07XG5cbiAgICAgICAgICAgIGlmIChtZXRob2QpIHtcbiAgICAgICAgICAgICAgcmV0dXJuIG1ldGhvZC5jYWxsKHJlcyk7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIHRocm93IG5ldyBBeGlvc0Vycm9yKFxuICAgICAgICAgICAgICBgUmVzcG9uc2UgdHlwZSAnJHt0eXBlfScgaXMgbm90IHN1cHBvcnRlZGAsXG4gICAgICAgICAgICAgIEF4aW9zRXJyb3IuRVJSX05PVF9TVVBQT1JULFxuICAgICAgICAgICAgICBjb25maWdcbiAgICAgICAgICAgICk7XG4gICAgICAgICAgfSk7XG4gICAgICB9KTtcbiAgICB9KSgpO1xuXG4gIGNvbnN0IGdldEJvZHlMZW5ndGggPSBhc3luYyAoYm9keSkgPT4ge1xuICAgIGlmIChib2R5ID09IG51bGwpIHtcbiAgICAgIHJldHVybiAwO1xuICAgIH1cblxuICAgIGlmICh1dGlscy5pc0Jsb2IoYm9keSkpIHtcbiAgICAgIHJldHVybiBib2R5LnNpemU7XG4gICAgfVxuXG4gICAgaWYgKHV0aWxzLmlzQXJyYXlCdWZmZXJWaWV3KGJvZHkpIHx8IHV0aWxzLmlzQXJyYXlCdWZmZXIoYm9keSkpIHtcbiAgICAgIHJldHVybiBib2R5LmJ5dGVMZW5ndGg7XG4gICAgfVxuXG4gICAgaWYgKHV0aWxzLmlzVVJMU2VhcmNoUGFyYW1zKGJvZHkpKSB7XG4gICAgICBib2R5ID0gYm9keSArICcnO1xuICAgIH1cblxuICAgIGlmICh1dGlscy5pc1N0cmluZyhib2R5KSkge1xuICAgICAgcmV0dXJuIChhd2FpdCBlbmNvZGVUZXh0KGJvZHkpKS5ieXRlTGVuZ3RoO1xuICAgIH1cbiAgfTtcblxuICBjb25zdCByZXNvbHZlQm9keUxlbmd0aCA9IGFzeW5jIChoZWFkZXJzLCBib2R5KSA9PiB7XG4gICAgY29uc3QgbGVuZ3RoID0gdXRpbHMudG9GaW5pdGVOdW1iZXIoaGVhZGVycy5nZXRDb250ZW50TGVuZ3RoKCkpO1xuXG4gICAgcmV0dXJuIGxlbmd0aCA9PSBudWxsID8gZ2V0Qm9keUxlbmd0aChib2R5KSA6IGxlbmd0aDtcbiAgfTtcblxuICByZXR1cm4gYXN5bmMgKGNvbmZpZykgPT4ge1xuICAgIGxldCB7XG4gICAgICB1cmwsXG4gICAgICBtZXRob2QsXG4gICAgICBkYXRhLFxuICAgICAgc2lnbmFsLFxuICAgICAgY2FuY2VsVG9rZW4sXG4gICAgICB0aW1lb3V0LFxuICAgICAgb25Eb3dubG9hZFByb2dyZXNzLFxuICAgICAgb25VcGxvYWRQcm9ncmVzcyxcbiAgICAgIHJlc3BvbnNlVHlwZSxcbiAgICAgIGhlYWRlcnMsXG4gICAgICB3aXRoQ3JlZGVudGlhbHMgPSAnc2FtZS1vcmlnaW4nLFxuICAgICAgZmV0Y2hPcHRpb25zLFxuICAgICAgbWF4Q29udGVudExlbmd0aCxcbiAgICAgIG1heEJvZHlMZW5ndGgsXG4gICAgICBtYXhSZWRpcmVjdHMsXG4gICAgfSA9IHJlc29sdmVDb25maWcoY29uZmlnKTtcblxuICAgIGNvbnN0IGhhc01heENvbnRlbnRMZW5ndGggPSB1dGlscy5pc051bWJlcihtYXhDb250ZW50TGVuZ3RoKSAmJiBtYXhDb250ZW50TGVuZ3RoID4gLTE7XG4gICAgY29uc3QgaGFzTWF4Qm9keUxlbmd0aCA9IHV0aWxzLmlzTnVtYmVyKG1heEJvZHlMZW5ndGgpICYmIG1heEJvZHlMZW5ndGggPiAtMTtcbiAgICBjb25zdCBvd24gPSAoa2V5KSA9PiAodXRpbHMuaGFzT3duUHJvcChjb25maWcsIGtleSkgPyBjb25maWdba2V5XSA6IHVuZGVmaW5lZCk7XG5cbiAgICBsZXQgX2ZldGNoID0gZW52RmV0Y2ggfHwgZmV0Y2g7XG5cbiAgICByZXNwb25zZVR5cGUgPSByZXNwb25zZVR5cGUgPyAocmVzcG9uc2VUeXBlICsgJycpLnRvTG93ZXJDYXNlKCkgOiAndGV4dCc7XG5cbiAgICBsZXQgY29tcG9zZWRTaWduYWwgPSBjb21wb3NlU2lnbmFscyhcbiAgICAgIFtzaWduYWwsIGNhbmNlbFRva2VuICYmIGNhbmNlbFRva2VuLnRvQWJvcnRTaWduYWwoKV0sXG4gICAgICB0aW1lb3V0XG4gICAgKTtcblxuICAgIGxldCByZXF1ZXN0ID0gbnVsbDtcblxuICAgIGNvbnN0IHVuc3Vic2NyaWJlID1cbiAgICAgIGNvbXBvc2VkU2lnbmFsICYmXG4gICAgICBjb21wb3NlZFNpZ25hbC51bnN1YnNjcmliZSAmJlxuICAgICAgKCgpID0+IHtcbiAgICAgICAgY29tcG9zZWRTaWduYWwudW5zdWJzY3JpYmUoKTtcbiAgICAgIH0pO1xuXG4gICAgbGV0IHJlcXVlc3RDb250ZW50TGVuZ3RoO1xuXG4gICAgLy8gQXhpb3NFcnJvcnMgd2UgcmFpc2Ugd2hpbGUgcmVxdWVzdCBvciByZXNwb25zZSBib2RpZXMgYXJlIGJlaW5nIHN0cmVhbWVkLiBDYXB0dXJlZFxuICAgIC8vIGJ5IGlkZW50aXR5IHNvIHRoZSBjYXRjaCBibG9jayBjYW4gc3VyZmFjZSBpdCBkaXJlY3RseSwgcmVnYXJkbGVzcyBvZlxuICAgIC8vIGhvdyB0aGUgcnVudGltZSB3cmFwcyB0aGUgcmVzdWx0aW5nIGZldGNoIHJlamVjdGlvbiAodW5kaWNpIGV4cG9zZXMgaXRcbiAgICAvLyBhcyBgZXJyLmNhdXNlYDsgc29tZSBicm93c2VycyBkcm9wIHRoZSBvcmlnaW5hbCBlcnJvciBlbnRpcmVseSkuXG4gICAgbGV0IHBlbmRpbmdCb2R5RXJyb3IgPSBudWxsO1xuICAgIGxldCBwZW5kaW5nUmVzcG9uc2VFcnJvciA9IG51bGw7XG5cbiAgICBjb25zdCBtYXhCb2R5TGVuZ3RoRXJyb3IgPSAoKSA9PlxuICAgICAgbmV3IEF4aW9zRXJyb3IoXG4gICAgICAgICdSZXF1ZXN0IGJvZHkgbGFyZ2VyIHRoYW4gbWF4Qm9keUxlbmd0aCBsaW1pdCcsXG4gICAgICAgIEF4aW9zRXJyb3IuRVJSX0JBRF9SRVFVRVNULFxuICAgICAgICBjb25maWcsXG4gICAgICAgIHJlcXVlc3RcbiAgICAgICk7XG5cbiAgICB0cnkge1xuICAgICAgLy8gSFRUUCBiYXNpYyBhdXRoZW50aWNhdGlvblxuICAgICAgbGV0IGF1dGggPSB1bmRlZmluZWQ7XG4gICAgICBjb25zdCBjb25maWdBdXRoID0gb3duKCdhdXRoJyk7XG5cbiAgICAgIGlmIChjb25maWdBdXRoKSB7XG4gICAgICAgIGNvbnN0IHVzZXJuYW1lID0gdXRpbHMuZ2V0U2FmZVByb3AoY29uZmlnQXV0aCwgJ3VzZXJuYW1lJykgfHwgJyc7XG4gICAgICAgIGNvbnN0IHBhc3N3b3JkID0gdXRpbHMuZ2V0U2FmZVByb3AoY29uZmlnQXV0aCwgJ3Bhc3N3b3JkJykgfHwgJyc7XG4gICAgICAgIGF1dGggPSB7XG4gICAgICAgICAgdXNlcm5hbWUsXG4gICAgICAgICAgcGFzc3dvcmQsXG4gICAgICAgIH07XG4gICAgICB9XG5cbiAgICAgIGxldCBwYXJzZWRVUkw7XG4gICAgICBpZiAobWF5YmVXaXRoQXV0aENyZWRlbnRpYWxzKHVybCkpIHtcbiAgICAgICAgcGFyc2VkVVJMID0gbmV3IFVSTCh1cmwsIHBsYXRmb3JtLm9yaWdpbik7XG5cbiAgICAgICAgaWYgKCFhdXRoICYmIChwYXJzZWRVUkwudXNlcm5hbWUgfHwgcGFyc2VkVVJMLnBhc3N3b3JkKSkge1xuICAgICAgICAgIGNvbnN0IHVybFVzZXJuYW1lID0gZGVjb2RlVVJJQ29tcG9uZW50U2FmZShwYXJzZWRVUkwudXNlcm5hbWUpO1xuICAgICAgICAgIGNvbnN0IHVybFBhc3N3b3JkID0gZGVjb2RlVVJJQ29tcG9uZW50U2FmZShwYXJzZWRVUkwucGFzc3dvcmQpO1xuICAgICAgICAgIGF1dGggPSB7XG4gICAgICAgICAgICB1c2VybmFtZTogdXJsVXNlcm5hbWUsXG4gICAgICAgICAgICBwYXNzd29yZDogdXJsUGFzc3dvcmQsXG4gICAgICAgICAgfTtcbiAgICAgICAgfVxuXG4gICAgICAgIGlmIChwYXJzZWRVUkwudXNlcm5hbWUgfHwgcGFyc2VkVVJMLnBhc3N3b3JkKSB7XG4gICAgICAgICAgcGFyc2VkVVJMLnVzZXJuYW1lID0gJyc7XG4gICAgICAgICAgcGFyc2VkVVJMLnBhc3N3b3JkID0gJyc7XG4gICAgICAgICAgdXJsID0gcGFyc2VkVVJMLmhyZWY7XG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgaWYgKGF1dGgpIHtcbiAgICAgICAgaGVhZGVycy5kZWxldGUoJ2F1dGhvcml6YXRpb24nKTtcbiAgICAgICAgaGVhZGVycy5zZXQoXG4gICAgICAgICAgJ0F1dGhvcml6YXRpb24nLFxuICAgICAgICAgICdCYXNpYyAnICsgYnRvYShlbmNvZGVVVEY4KChhdXRoLnVzZXJuYW1lIHx8ICcnKSArICc6JyArIChhdXRoLnBhc3N3b3JkIHx8ICcnKSkpXG4gICAgICAgICk7XG4gICAgICB9XG5cbiAgICAgIC8vIEVuZm9yY2UgbWF4Q29udGVudExlbmd0aCBmb3IgZGF0YTogVVJMcyB1cC1mcm9udCBzbyB3ZSBuZXZlciBtYXRlcmlhbGl6ZVxuICAgICAgLy8gYW4gb3ZlcnNpemVkIHBheWxvYWQuIFRoZSBIVFRQIGFkYXB0ZXIgYXBwbGllcyB0aGUgc2FtZSBjaGVjayAoc2VlIGh0dHAuanNcbiAgICAgIC8vIFwiaWYgKHByb3RvY29sID09PSAnZGF0YTonKVwiIGJyYW5jaCkuXG4gICAgICBpZiAoaGFzTWF4Q29udGVudExlbmd0aCAmJiBwYXJzZWRVUkwgJiYgcGFyc2VkVVJMLnByb3RvY29sID09PSAnZGF0YTonKSB7XG4gICAgICAgIGNvbnN0IGVzdGltYXRlZCA9IGVzdGltYXRlRGF0YVVSTERlY29kZWRCeXRlcyhwYXJzZWRVUkwuaHJlZik7XG4gICAgICAgIGlmIChlc3RpbWF0ZWQgPiBtYXhDb250ZW50TGVuZ3RoKSB7XG4gICAgICAgICAgdGhyb3cgbmV3IEF4aW9zRXJyb3IoXG4gICAgICAgICAgICAnbWF4Q29udGVudExlbmd0aCBzaXplIG9mICcgKyBtYXhDb250ZW50TGVuZ3RoICsgJyBleGNlZWRlZCcsXG4gICAgICAgICAgICBBeGlvc0Vycm9yLkVSUl9CQURfUkVTUE9OU0UsXG4gICAgICAgICAgICBjb25maWcsXG4gICAgICAgICAgICByZXF1ZXN0XG4gICAgICAgICAgKTtcbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICBjb25zdCBmb3JtQ29udGVudFR5cGUgPVxuICAgICAgICB1dGlscy5pc1NwZWNDb21wbGlhbnRGb3JtKGRhdGEpICYmIEF4aW9zSGVhZGVycy5mcm9tKG93bignaGVhZGVycycpKS5nZXRDb250ZW50VHlwZSgpO1xuICAgICAgbGV0IGZvcm1Cb3VuZGFyeTtcbiAgICAgIGlmIChcbiAgICAgICAgdXRpbHMuaXNTdHJpbmcoZm9ybUNvbnRlbnRUeXBlKSAmJlxuICAgICAgICAvXm11bHRpcGFydFxcL2Zvcm0tZGF0YSg/Olxccyo7fCQpL2kudGVzdChmb3JtQ29udGVudFR5cGUudHJpbSgpKVxuICAgICAgKSB7XG4gICAgICAgIGNvbnN0IHBhcmFtZXRlcnMgPSBBeGlvc0hlYWRlcnMucGFyc2VQYXJhbWV0ZXJzKGZvcm1Db250ZW50VHlwZSk7XG4gICAgICAgIGlmICh1dGlscy5oYXNPd25Qcm9wKHBhcmFtZXRlcnMsICdib3VuZGFyeScpKSBmb3JtQm91bmRhcnkgPSBwYXJhbWV0ZXJzLmJvdW5kYXJ5O1xuICAgICAgfVxuXG4gICAgICBpZiAoXG4gICAgICAgIHV0aWxzLmlzU3BlY0NvbXBsaWFudEZvcm0oZGF0YSkgJiZcbiAgICAgICAgbWV0aG9kICE9PSAnZ2V0JyAmJlxuICAgICAgICBtZXRob2QgIT09ICdoZWFkJyAmJlxuICAgICAgICAoaGFzTWF4Qm9keUxlbmd0aCB8fFxuICAgICAgICAgIChvblVwbG9hZFByb2dyZXNzICYmIHN1cHBvcnRzUmVxdWVzdFN0cmVhbSkgfHxcbiAgICAgICAgICBmb3JtQm91bmRhcnkgIT09IHVuZGVmaW5lZClcbiAgICAgICkge1xuICAgICAgICBkYXRhID0gY3JlYXRlTXVsdGlwYXJ0Qm9keShcbiAgICAgICAgICBkYXRhLFxuICAgICAgICAgIEJsb2IsXG4gICAgICAgICAgaGFzTWF4Qm9keUxlbmd0aCA/IG1heEJvZHlMZW5ndGggOiBJbmZpbml0eSxcbiAgICAgICAgICBtYXhCb2R5TGVuZ3RoRXJyb3IsXG4gICAgICAgICAgZm9ybUJvdW5kYXJ5XG4gICAgICAgICk7XG4gICAgICAgIC8vIEJsb2IudHlwZSBsb3dlcmNhc2VzIGl0cyB2YWx1ZSwgaW5jbHVkaW5nIGEgY2FzZS1zZW5zaXRpdmUgYm91bmRhcnkuXG4gICAgICAgIC8vIFJldGFpbiB0aGUgY2FsbGVyJ3MgaGVhZGVyIHdoZW4gYW4gZXhwbGljaXQgYm91bmRhcnkgd2FzIHNlcmlhbGl6ZWQuXG4gICAgICAgIGhlYWRlcnMuc2V0Q29udGVudFR5cGUoZm9ybUJvdW5kYXJ5ID09PSB1bmRlZmluZWQgPyBkYXRhLnR5cGUgOiBmb3JtQ29udGVudFR5cGUpO1xuICAgICAgICByZXF1ZXN0Q29udGVudExlbmd0aCA9IGRhdGEuc2l6ZTtcbiAgICAgIH1cblxuICAgICAgLy8gRW5mb3JjZSBtYXhCb2R5TGVuZ3RoIGFnYWluc3Qga25vd24tc2l6ZSBib2RpZXMgYmVmb3JlIGRpc3BhdGNoIHVzaW5nXG4gICAgICAvLyB0aGUgYm9keSdzICphY3R1YWwqIHNpemUg4oCUIG5ldmVyIGEgY2FsbGVyLWRlY2xhcmVkIENvbnRlbnQtTGVuZ3RoLFxuICAgICAgLy8gd2hpY2ggY291bGQgdW5kZXItcmVwb3J0IHRvIHNsaXAgYW4gb3ZlcnNpemVkIGJvZHkgcGFzdCB0aGUgY2hlY2suXG4gICAgICAvLyBVbmtub3duLXNpemUgc3RyZWFtcyByZXR1cm4gdW5kZWZpbmVkIGhlcmUgYW5kIGFyZSBjb3VudGVkIHBlci1jaHVua1xuICAgICAgLy8gYmVsb3cgYXMgZmV0Y2ggY29uc3VtZXMgdGhlbS5cbiAgICAgIGlmIChoYXNNYXhCb2R5TGVuZ3RoICYmIG1ldGhvZCAhPT0gJ2dldCcgJiYgbWV0aG9kICE9PSAnaGVhZCcpIHtcbiAgICAgICAgY29uc3Qgb3V0Ym91bmRMZW5ndGggPSBhd2FpdCBnZXRCb2R5TGVuZ3RoKGRhdGEpO1xuICAgICAgICBpZiAodHlwZW9mIG91dGJvdW5kTGVuZ3RoID09PSAnbnVtYmVyJyAmJiBpc0Zpbml0ZShvdXRib3VuZExlbmd0aCkpIHtcbiAgICAgICAgICByZXF1ZXN0Q29udGVudExlbmd0aCA9IG91dGJvdW5kTGVuZ3RoO1xuICAgICAgICAgIGlmIChvdXRib3VuZExlbmd0aCA+IG1heEJvZHlMZW5ndGgpIHtcbiAgICAgICAgICAgIHRocm93IG1heEJvZHlMZW5ndGhFcnJvcigpO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICAvLyBBIHN0cmVhbWVkIGJvZHkgdW5kZXIgbWF4Qm9keUxlbmd0aCBtdXN0IGJlIGNvdW50ZWQgYXMgZmV0Y2ggY29uc3VtZXNcbiAgICAgIC8vIGl0OyBpdHMgc2l6ZSBpcyBuZXZlciB0cnVzdGVkIGZyb20gYSBjYWxsZXItZGVjbGFyZWQgQ29udGVudC1MZW5ndGguXG4gICAgICBjb25zdCBtdXN0RW5mb3JjZVN0cmVhbUJvZHkgPVxuICAgICAgICBoYXNNYXhCb2R5TGVuZ3RoICYmICh1dGlscy5pc1JlYWRhYmxlU3RyZWFtKGRhdGEpIHx8IHV0aWxzLmlzU3RyZWFtKGRhdGEpKTtcblxuICAgICAgY29uc3QgdHJhY2tSZXF1ZXN0U3RyZWFtID0gKHN0cmVhbSwgb25Qcm9ncmVzcywgZmx1c2gpID0+XG4gICAgICAgIHRyYWNrU3RyZWFtKFxuICAgICAgICAgIHN0cmVhbSxcbiAgICAgICAgICBERUZBVUxUX0NIVU5LX1NJWkUsXG4gICAgICAgICAgKGxvYWRlZEJ5dGVzKSA9PiB7XG4gICAgICAgICAgICBpZiAoaGFzTWF4Qm9keUxlbmd0aCAmJiBsb2FkZWRCeXRlcyA+IG1heEJvZHlMZW5ndGgpIHtcbiAgICAgICAgICAgICAgdGhyb3cgKHBlbmRpbmdCb2R5RXJyb3IgPSBtYXhCb2R5TGVuZ3RoRXJyb3IoKSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBvblByb2dyZXNzICYmIG9uUHJvZ3Jlc3MobG9hZGVkQnl0ZXMpO1xuICAgICAgICAgIH0sXG4gICAgICAgICAgZmx1c2hcbiAgICAgICAgKTtcblxuICAgICAgaWYgKFxuICAgICAgICBzdXBwb3J0c1JlcXVlc3RTdHJlYW0gJiZcbiAgICAgICAgbWV0aG9kICE9PSAnZ2V0JyAmJlxuICAgICAgICBtZXRob2QgIT09ICdoZWFkJyAmJlxuICAgICAgICAob25VcGxvYWRQcm9ncmVzcyB8fCBtdXN0RW5mb3JjZVN0cmVhbUJvZHkpXG4gICAgICApIHtcbiAgICAgICAgcmVxdWVzdENvbnRlbnRMZW5ndGggPVxuICAgICAgICAgIHJlcXVlc3RDb250ZW50TGVuZ3RoID09IG51bGxcbiAgICAgICAgICAgID8gYXdhaXQgcmVzb2x2ZUJvZHlMZW5ndGgoaGVhZGVycywgZGF0YSlcbiAgICAgICAgICAgIDogcmVxdWVzdENvbnRlbnRMZW5ndGg7XG5cbiAgICAgICAgLy8gQSBkZWNsYXJlZCBsZW5ndGggb2YgMCBpcyBvbmx5IHRydXN0ZWQgdG8gc2tpcCB0aGUgd3JhcCB3aGVuIHdlIGFyZVxuICAgICAgICAvLyBub3QgZW5mb3JjaW5nIGEgc3RyZWFtIGxpbWl0ICh3aGljaCBtdXN0IG5vdCByZWx5IG9uIHRoYXQgaGVhZGVyKS5cbiAgICAgICAgaWYgKHJlcXVlc3RDb250ZW50TGVuZ3RoICE9PSAwIHx8IG11c3RFbmZvcmNlU3RyZWFtQm9keSkge1xuICAgICAgICAgIGxldCBfcmVxdWVzdCA9IG5ldyBSZXF1ZXN0KHVybCwge1xuICAgICAgICAgICAgbWV0aG9kOiAnUE9TVCcsXG4gICAgICAgICAgICBib2R5OiBkYXRhLFxuICAgICAgICAgICAgZHVwbGV4OiAnaGFsZicsXG4gICAgICAgICAgfSk7XG5cbiAgICAgICAgICBsZXQgY29udGVudFR5cGVIZWFkZXI7XG5cbiAgICAgICAgICBpZiAoXG4gICAgICAgICAgICB1dGlscy5pc0Zvcm1EYXRhKGRhdGEpICYmXG4gICAgICAgICAgICAoY29udGVudFR5cGVIZWFkZXIgPSBfcmVxdWVzdC5oZWFkZXJzLmdldCgnY29udGVudC10eXBlJykpXG4gICAgICAgICAgKSB7XG4gICAgICAgICAgICBoZWFkZXJzLnNldENvbnRlbnRUeXBlKGNvbnRlbnRUeXBlSGVhZGVyKTtcbiAgICAgICAgICB9XG5cbiAgICAgICAgICBpZiAoX3JlcXVlc3QuYm9keSkge1xuICAgICAgICAgICAgY29uc3QgW29uUHJvZ3Jlc3MsIGZsdXNoXSA9XG4gICAgICAgICAgICAgIChvblVwbG9hZFByb2dyZXNzICYmXG4gICAgICAgICAgICAgICAgcHJvZ3Jlc3NFdmVudERlY29yYXRvcihcbiAgICAgICAgICAgICAgICAgIHJlcXVlc3RDb250ZW50TGVuZ3RoLFxuICAgICAgICAgICAgICAgICAgcHJvZ3Jlc3NFdmVudFJlZHVjZXIoYXN5bmNEZWNvcmF0b3Iob25VcGxvYWRQcm9ncmVzcykpXG4gICAgICAgICAgICAgICAgKSkgfHxcbiAgICAgICAgICAgICAgW107XG5cbiAgICAgICAgICAgIGRhdGEgPSB0cmFja1JlcXVlc3RTdHJlYW0oX3JlcXVlc3QuYm9keSwgb25Qcm9ncmVzcywgZmx1c2gpO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfSBlbHNlIGlmIChcbiAgICAgICAgbXVzdEVuZm9yY2VTdHJlYW1Cb2R5ICYmXG4gICAgICAgICFpc1JlcXVlc3RTdXBwb3J0ZWQgJiZcbiAgICAgICAgaXNSZWFkYWJsZVN0cmVhbVN1cHBvcnRlZCAmJlxuICAgICAgICBtZXRob2QgIT09ICdnZXQnICYmXG4gICAgICAgIG1ldGhvZCAhPT0gJ2hlYWQnXG4gICAgICApIHtcbiAgICAgICAgZGF0YSA9IHRyYWNrUmVxdWVzdFN0cmVhbShkYXRhKTtcbiAgICAgIH0gZWxzZSBpZiAoXG4gICAgICAgIG11c3RFbmZvcmNlU3RyZWFtQm9keSAmJlxuICAgICAgICBpc1JlcXVlc3RTdXBwb3J0ZWQgJiZcbiAgICAgICAgIXN1cHBvcnRzUmVxdWVzdFN0cmVhbSAmJlxuICAgICAgICBtZXRob2QgIT09ICdnZXQnICYmXG4gICAgICAgIG1ldGhvZCAhPT0gJ2hlYWQnXG4gICAgICApIHtcbiAgICAgICAgdGhyb3cgbmV3IEF4aW9zRXJyb3IoXG4gICAgICAgICAgJ1N0cmVhbSByZXF1ZXN0IGJvZGllcyBhcmUgbm90IHN1cHBvcnRlZCBieSB0aGUgY3VycmVudCBmZXRjaCBpbXBsZW1lbnRhdGlvbicsXG4gICAgICAgICAgQXhpb3NFcnJvci5FUlJfTk9UX1NVUFBPUlQsXG4gICAgICAgICAgY29uZmlnLFxuICAgICAgICAgIHJlcXVlc3RcbiAgICAgICAgKTtcbiAgICAgIH1cblxuICAgICAgaWYgKCF1dGlscy5pc1N0cmluZyh3aXRoQ3JlZGVudGlhbHMpKSB7XG4gICAgICAgIHdpdGhDcmVkZW50aWFscyA9IHdpdGhDcmVkZW50aWFscyA/ICdpbmNsdWRlJyA6ICdvbWl0JztcbiAgICAgIH1cblxuICAgICAgLy8gQ2xvdWRmbGFyZSBXb3JrZXJzIHRocm93cyB3aGVuIGNyZWRlbnRpYWxzIGFyZSBkZWZpbmVkXG4gICAgICAvLyBzZWUgaHR0cHM6Ly9naXRodWIuY29tL2Nsb3VkZmxhcmUvd29ya2VyZC9pc3N1ZXMvOTAyXG4gICAgICBjb25zdCBpc0NyZWRlbnRpYWxzU3VwcG9ydGVkID0gaXNSZXF1ZXN0U3VwcG9ydGVkICYmICdjcmVkZW50aWFscycgaW4gUmVxdWVzdC5wcm90b3R5cGU7XG5cbiAgICAgIC8vIElmIGRhdGEgaXMgRm9ybURhdGEgYW5kIENvbnRlbnQtVHlwZSBpcyBtdWx0aXBhcnQvZm9ybS1kYXRhIHdpdGhvdXQgYm91bmRhcnksXG4gICAgICAvLyBkZWxldGUgaXQgc28gZmV0Y2ggY2FuIHNldCBpdCBjb3JyZWN0bHkgd2l0aCB0aGUgYm91bmRhcnlcbiAgICAgIGlmICh1dGlscy5pc0Zvcm1EYXRhKGRhdGEpKSB7XG4gICAgICAgIGNvbnN0IGNvbnRlbnRUeXBlID0gaGVhZGVycy5nZXRDb250ZW50VHlwZSgpO1xuICAgICAgICBpZiAoXG4gICAgICAgICAgY29udGVudFR5cGUgJiZcbiAgICAgICAgICAvXm11bHRpcGFydFxcL2Zvcm0tZGF0YS9pLnRlc3QoY29udGVudFR5cGUpICYmXG4gICAgICAgICAgIS9ib3VuZGFyeT0vaS50ZXN0KGNvbnRlbnRUeXBlKVxuICAgICAgICApIHtcbiAgICAgICAgICBoZWFkZXJzLmRlbGV0ZSgnY29udGVudC10eXBlJyk7XG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgLy8gU2V0IFVzZXItQWdlbnQgaGVhZGVyIGlmIG5vdCBhbHJlYWR5IHNldCAoZmV0Y2ggZGVmYXVsdHMgdG8gJ25vZGUnIGluIE5vZGUuanMpXG4gICAgICBoZWFkZXJzLnNldCgnVXNlci1BZ2VudCcsICdheGlvcy8nICsgVkVSU0lPTiwgZmFsc2UpO1xuXG4gICAgICBjb25zdCBzYWZlRmV0Y2hPcHRpb25zID1cbiAgICAgICAgZmV0Y2hPcHRpb25zID09IG51bGwgPyBmZXRjaE9wdGlvbnMgOiBPYmplY3QuYXNzaWduKE9iamVjdC5jcmVhdGUobnVsbCksIGZldGNoT3B0aW9ucyk7XG5cbiAgICAgIGlmIChzYWZlRmV0Y2hPcHRpb25zKSB7XG4gICAgICAgIC8vIFRoZXNlIG9wdGlvbnMgYXJlIG93bmVkIGJ5IEF4aW9zIGFuZCBhcmUgYWxyZWFkeSByZWZsZWN0ZWQgaW4gdGhlXG4gICAgICAgIC8vIHJlc29sdmVkIFJlcXVlc3QgcGFzc2VkIHRvIGZldGNoLlxuICAgICAgICBkZWxldGUgc2FmZUZldGNoT3B0aW9ucy5ib2R5O1xuICAgICAgICBkZWxldGUgc2FmZUZldGNoT3B0aW9ucy5oZWFkZXJzO1xuICAgICAgICBkZWxldGUgc2FmZUZldGNoT3B0aW9ucy5tZXRob2Q7XG4gICAgICAgIGRlbGV0ZSBzYWZlRmV0Y2hPcHRpb25zLnNpZ25hbDtcbiAgICAgICAgZGVsZXRlIHNhZmVGZXRjaE9wdGlvbnMuZHVwbGV4O1xuICAgICAgICBkZWxldGUgc2FmZUZldGNoT3B0aW9ucy5jcmVkZW50aWFscztcbiAgICAgIH1cblxuICAgICAgY29uc3QgcmVzb2x2ZWRPcHRpb25zID0gT2JqZWN0LmFzc2lnbihPYmplY3QuY3JlYXRlKG51bGwpLCBzYWZlRmV0Y2hPcHRpb25zLCB7XG4gICAgICAgIHNpZ25hbDogY29tcG9zZWRTaWduYWwsXG4gICAgICAgIG1ldGhvZDogbWV0aG9kLnRvVXBwZXJDYXNlKCksXG4gICAgICAgIGhlYWRlcnM6IHRvQnl0ZVN0cmluZ0hlYWRlck9iamVjdChoZWFkZXJzLm5vcm1hbGl6ZSgpKSxcbiAgICAgICAgYm9keTogZGF0YSxcbiAgICAgICAgZHVwbGV4OiAnaGFsZicsXG4gICAgICAgIGNyZWRlbnRpYWxzOiBpc0NyZWRlbnRpYWxzU3VwcG9ydGVkID8gd2l0aENyZWRlbnRpYWxzIDogdW5kZWZpbmVkLFxuICAgICAgfSk7XG5cbiAgICAgIGlmIChpc1JlcXVlc3RTdXBwb3J0ZWQpIHtcbiAgICAgICAgdXRpbHMuZm9yRWFjaChyZXF1ZXN0RGVmYXVsdHMsICh2YWx1ZSwga2V5KSA9PiB7XG4gICAgICAgICAgaWYgKHJlc29sdmVkT3B0aW9uc1trZXldID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgIHJlc29sdmVkT3B0aW9uc1trZXldID0gdmFsdWU7XG4gICAgICAgICAgfVxuICAgICAgICB9KTtcblxuICAgICAgICBpZiAocmVzb2x2ZWRPcHRpb25zLnNpZ25hbCA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgcmVzb2x2ZWRPcHRpb25zLnNpZ25hbCA9IG51bGw7XG4gICAgICAgIH1cblxuICAgICAgICBpZiAocmVzb2x2ZWRPcHRpb25zLmJvZHkgPT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgIHJlc29sdmVkT3B0aW9ucy5ib2R5ID0gbnVsbDtcbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICBpZiAobWF4UmVkaXJlY3RzID09PSAwKSB7XG4gICAgICAgIHJlc29sdmVkT3B0aW9ucy5yZWRpcmVjdCA9ICdtYW51YWwnO1xuXG4gICAgICAgIGlmIChzYWZlRmV0Y2hPcHRpb25zKSB7XG4gICAgICAgICAgc2FmZUZldGNoT3B0aW9ucy5yZWRpcmVjdCA9ICdtYW51YWwnO1xuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgIHJlcXVlc3QgPSBpc1JlcXVlc3RTdXBwb3J0ZWQgJiYgbmV3IFJlcXVlc3QodXJsLCByZXNvbHZlZE9wdGlvbnMpO1xuXG4gICAgICBsZXQgcmVzcG9uc2UgPSBhd2FpdCAoaXNSZXF1ZXN0U3VwcG9ydGVkXG4gICAgICAgID8gX2ZldGNoKHJlcXVlc3QsIHNhZmVGZXRjaE9wdGlvbnMpXG4gICAgICAgIDogX2ZldGNoKHVybCwgcmVzb2x2ZWRPcHRpb25zKSk7XG5cbiAgICAgIGNvbnN0IHJlc3BvbnNlSGVhZGVycyA9IEF4aW9zSGVhZGVycy5mcm9tKHJlc3BvbnNlLmhlYWRlcnMpO1xuXG4gICAgICAvLyBDaGVhcCBwcmUtY2hlY2s6IGlmIHRoZSBzZXJ2ZXIgaG9uZXN0bHkgZGVjbGFyZXMgYSBjb250ZW50LWxlbmd0aCB0aGF0XG4gICAgICAvLyBhbHJlYWR5IGV4Y2VlZHMgdGhlIGNhcCwgcmVqZWN0IGJlZm9yZSB3ZSBzdGFydCBzdHJlYW1pbmcuXG4gICAgICBpZiAoaGFzTWF4Q29udGVudExlbmd0aCkge1xuICAgICAgICBjb25zdCBkZWNsYXJlZExlbmd0aCA9IHV0aWxzLnRvRmluaXRlTnVtYmVyKHJlc3BvbnNlSGVhZGVycy5nZXRDb250ZW50TGVuZ3RoKCkpO1xuICAgICAgICBpZiAoZGVjbGFyZWRMZW5ndGggIT0gbnVsbCAmJiBkZWNsYXJlZExlbmd0aCA+IG1heENvbnRlbnRMZW5ndGgpIHtcbiAgICAgICAgICB0aHJvdyBuZXcgQXhpb3NFcnJvcihcbiAgICAgICAgICAgICdtYXhDb250ZW50TGVuZ3RoIHNpemUgb2YgJyArIG1heENvbnRlbnRMZW5ndGggKyAnIGV4Y2VlZGVkJyxcbiAgICAgICAgICAgIEF4aW9zRXJyb3IuRVJSX0JBRF9SRVNQT05TRSxcbiAgICAgICAgICAgIGNvbmZpZyxcbiAgICAgICAgICAgIHJlcXVlc3RcbiAgICAgICAgICApO1xuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgIGNvbnN0IGlzU3RyZWFtUmVzcG9uc2UgPVxuICAgICAgICBzdXBwb3J0c1Jlc3BvbnNlU3RyZWFtICYmIChyZXNwb25zZVR5cGUgPT09ICdzdHJlYW0nIHx8IHJlc3BvbnNlVHlwZSA9PT0gJ3Jlc3BvbnNlJyk7XG5cbiAgICAgIGlmIChcbiAgICAgICAgc3VwcG9ydHNSZXNwb25zZVN0cmVhbSAmJlxuICAgICAgICByZXNwb25zZS5ib2R5ICYmXG4gICAgICAgIChvbkRvd25sb2FkUHJvZ3Jlc3MgfHwgaGFzTWF4Q29udGVudExlbmd0aCB8fCAoaXNTdHJlYW1SZXNwb25zZSAmJiB1bnN1YnNjcmliZSkpXG4gICAgICApIHtcbiAgICAgICAgY29uc3Qgb3B0aW9ucyA9IHt9O1xuXG4gICAgICAgIFsnc3RhdHVzJywgJ3N0YXR1c1RleHQnLCAnaGVhZGVycyddLmZvckVhY2goKHByb3ApID0+IHtcbiAgICAgICAgICBvcHRpb25zW3Byb3BdID0gcmVzcG9uc2VbcHJvcF07XG4gICAgICAgIH0pO1xuXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlQ29udGVudExlbmd0aCA9IHV0aWxzLnRvRmluaXRlTnVtYmVyKHJlc3BvbnNlSGVhZGVycy5nZXRDb250ZW50TGVuZ3RoKCkpO1xuXG4gICAgICAgIGNvbnN0IFtvblByb2dyZXNzLCBmbHVzaF0gPVxuICAgICAgICAgIChvbkRvd25sb2FkUHJvZ3Jlc3MgJiZcbiAgICAgICAgICAgIHByb2dyZXNzRXZlbnREZWNvcmF0b3IoXG4gICAgICAgICAgICAgIHJlc3BvbnNlQ29udGVudExlbmd0aCxcbiAgICAgICAgICAgICAgcHJvZ3Jlc3NFdmVudFJlZHVjZXIoYXN5bmNEZWNvcmF0b3Iob25Eb3dubG9hZFByb2dyZXNzKSwgdHJ1ZSlcbiAgICAgICAgICAgICkpIHx8XG4gICAgICAgICAgW107XG5cbiAgICAgICAgbGV0IGJ5dGVzUmVhZCA9IDA7XG4gICAgICAgIGNvbnN0IG9uQ2h1bmtQcm9ncmVzcyA9IChsb2FkZWRCeXRlcykgPT4ge1xuICAgICAgICAgIGlmIChoYXNNYXhDb250ZW50TGVuZ3RoKSB7XG4gICAgICAgICAgICBieXRlc1JlYWQgPSBsb2FkZWRCeXRlcztcbiAgICAgICAgICAgIGlmIChieXRlc1JlYWQgPiBtYXhDb250ZW50TGVuZ3RoKSB7XG4gICAgICAgICAgICAgIHRocm93IChwZW5kaW5nUmVzcG9uc2VFcnJvciA9IG5ldyBBeGlvc0Vycm9yKFxuICAgICAgICAgICAgICAgICdtYXhDb250ZW50TGVuZ3RoIHNpemUgb2YgJyArIG1heENvbnRlbnRMZW5ndGggKyAnIGV4Y2VlZGVkJyxcbiAgICAgICAgICAgICAgICBBeGlvc0Vycm9yLkVSUl9CQURfUkVTUE9OU0UsXG4gICAgICAgICAgICAgICAgY29uZmlnLFxuICAgICAgICAgICAgICAgIHJlcXVlc3RcbiAgICAgICAgICAgICAgKSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICAgIG9uUHJvZ3Jlc3MgJiYgb25Qcm9ncmVzcyhsb2FkZWRCeXRlcyk7XG4gICAgICAgIH07XG5cbiAgICAgICAgcmVzcG9uc2UgPSBuZXcgUmVzcG9uc2UoXG4gICAgICAgICAgdHJhY2tTdHJlYW0ocmVzcG9uc2UuYm9keSwgREVGQVVMVF9DSFVOS19TSVpFLCBvbkNodW5rUHJvZ3Jlc3MsICgpID0+IHtcbiAgICAgICAgICAgIGZsdXNoICYmIGZsdXNoKCk7XG4gICAgICAgICAgICB1bnN1YnNjcmliZSAmJiB1bnN1YnNjcmliZSgpO1xuICAgICAgICAgIH0pLFxuICAgICAgICAgIG9wdGlvbnNcbiAgICAgICAgKTtcbiAgICAgIH1cblxuICAgICAgcmVzcG9uc2VUeXBlID0gcmVzcG9uc2VUeXBlIHx8ICd0ZXh0JztcblxuICAgICAgbGV0IHJlc3BvbnNlRGF0YSA9IGF3YWl0IHJlc29sdmVyc1t1dGlscy5maW5kS2V5KHJlc29sdmVycywgcmVzcG9uc2VUeXBlKSB8fCAndGV4dCddKFxuICAgICAgICByZXNwb25zZSxcbiAgICAgICAgY29uZmlnXG4gICAgICApO1xuXG4gICAgICAvLyBGYWxsYmFjayBlbmZvcmNlbWVudCBmb3IgZW52aXJvbm1lbnRzIHdpdGhvdXQgUmVhZGFibGVTdHJlYW0gc3VwcG9ydFxuICAgICAgLy8gKGxlZ2FjeSBydW50aW1lcykuIERldGVjdCBtYXRlcmlhbGl6ZWQgc2l6ZSBmcm9tIHR5cGVkIG91dHB1dDsgc2tpcFxuICAgICAgLy8gc3RyZWFtcy9SZXNwb25zZSBwYXNzdGhyb3VnaCBzaW5jZSB0aGUgdXNlciB3aWxsIHJlYWQgdGhvc2UgdGhlbXNlbHZlcy5cbiAgICAgIGlmIChoYXNNYXhDb250ZW50TGVuZ3RoICYmICFzdXBwb3J0c1Jlc3BvbnNlU3RyZWFtICYmICFpc1N0cmVhbVJlc3BvbnNlKSB7XG4gICAgICAgIGxldCBtYXRlcmlhbGl6ZWRTaXplO1xuICAgICAgICBpZiAocmVzcG9uc2VEYXRhICE9IG51bGwpIHtcbiAgICAgICAgICBpZiAodHlwZW9mIHJlc3BvbnNlRGF0YS5ieXRlTGVuZ3RoID09PSAnbnVtYmVyJykge1xuICAgICAgICAgICAgbWF0ZXJpYWxpemVkU2l6ZSA9IHJlc3BvbnNlRGF0YS5ieXRlTGVuZ3RoO1xuICAgICAgICAgIH0gZWxzZSBpZiAodHlwZW9mIHJlc3BvbnNlRGF0YS5zaXplID09PSAnbnVtYmVyJykge1xuICAgICAgICAgICAgbWF0ZXJpYWxpemVkU2l6ZSA9IHJlc3BvbnNlRGF0YS5zaXplO1xuICAgICAgICAgIH0gZWxzZSBpZiAodHlwZW9mIHJlc3BvbnNlRGF0YSA9PT0gJ3N0cmluZycpIHtcbiAgICAgICAgICAgIG1hdGVyaWFsaXplZFNpemUgPVxuICAgICAgICAgICAgICB0eXBlb2YgVGV4dEVuY29kZXIgPT09ICdmdW5jdGlvbidcbiAgICAgICAgICAgICAgICA/IG5ldyBUZXh0RW5jb2RlcigpLmVuY29kZShyZXNwb25zZURhdGEpLmJ5dGVMZW5ndGhcbiAgICAgICAgICAgICAgICA6IHJlc3BvbnNlRGF0YS5sZW5ndGg7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGlmICh0eXBlb2YgbWF0ZXJpYWxpemVkU2l6ZSA9PT0gJ251bWJlcicgJiYgbWF0ZXJpYWxpemVkU2l6ZSA+IG1heENvbnRlbnRMZW5ndGgpIHtcbiAgICAgICAgICB0aHJvdyBuZXcgQXhpb3NFcnJvcihcbiAgICAgICAgICAgICdtYXhDb250ZW50TGVuZ3RoIHNpemUgb2YgJyArIG1heENvbnRlbnRMZW5ndGggKyAnIGV4Y2VlZGVkJyxcbiAgICAgICAgICAgIEF4aW9zRXJyb3IuRVJSX0JBRF9SRVNQT05TRSxcbiAgICAgICAgICAgIGNvbmZpZyxcbiAgICAgICAgICAgIHJlcXVlc3RcbiAgICAgICAgICApO1xuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgICFpc1N0cmVhbVJlc3BvbnNlICYmIHVuc3Vic2NyaWJlICYmIHVuc3Vic2NyaWJlKCk7XG5cbiAgICAgIHJldHVybiBhd2FpdCBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG4gICAgICAgIHNldHRsZShyZXNvbHZlLCByZWplY3QsIHtcbiAgICAgICAgICBkYXRhOiByZXNwb25zZURhdGEsXG4gICAgICAgICAgaGVhZGVyczogQXhpb3NIZWFkZXJzLmZyb20ocmVzcG9uc2UuaGVhZGVycyksXG4gICAgICAgICAgc3RhdHVzOiByZXNwb25zZS5zdGF0dXMsXG4gICAgICAgICAgc3RhdHVzVGV4dDogcmVzcG9uc2Uuc3RhdHVzVGV4dCxcbiAgICAgICAgICBjb25maWcsXG4gICAgICAgICAgcmVxdWVzdCxcbiAgICAgICAgfSk7XG4gICAgICB9KTtcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIHVuc3Vic2NyaWJlICYmIHVuc3Vic2NyaWJlKCk7XG5cbiAgICAgIC8vIFNhZmFyaSBjYW4gc3VyZmFjZSBmZXRjaCBhYm9ydHMgYXMgYSBET01FeGNlcHRpb24tbGlrZSBvYmplY3Qgd2hvc2VcbiAgICAgIC8vIGJyYW5kZWQgZ2V0dGVycyB0aHJvdy4gUHJlZmVyIG91ciBjb21wb3NlZCBzaWduYWwgcmVhc29uIGJlZm9yZSByZWFkaW5nXG4gICAgICAvLyB0aGUgY2F1Z2h0IGVycm9yLCBwcmVzZXJ2aW5nIHRpbWVvdXQgdnMgY2FuY2VsbGF0aW9uIHNlbWFudGljcy5cbiAgICAgIGlmIChjb21wb3NlZFNpZ25hbCAmJiBjb21wb3NlZFNpZ25hbC5hYm9ydGVkICYmIGNvbXBvc2VkU2lnbmFsLnJlYXNvbiBpbnN0YW5jZW9mIEF4aW9zRXJyb3IpIHtcbiAgICAgICAgY29uc3QgY2FuY2VsZWRFcnJvciA9IGNvbXBvc2VkU2lnbmFsLnJlYXNvbjtcbiAgICAgICAgY2FuY2VsZWRFcnJvci5jb25maWcgPSBjb25maWc7XG4gICAgICAgIHJlcXVlc3QgJiYgKGNhbmNlbGVkRXJyb3IucmVxdWVzdCA9IHJlcXVlc3QpO1xuICAgICAgICBpZiAoZXJyICE9PSBjYW5jZWxlZEVycm9yKSB7XG4gICAgICAgICAgLy8gTm9uLWVudW1lcmFibGUgdG8gbWF0Y2ggbmF0aXZlIEVycm9yIGBjYXVzZWAgc2VtYW50aWNzIHNvIGxvZ2dlcnNcbiAgICAgICAgICAvLyBkb24ndCByZWN1cnNlIGludG8gY2lyY3VsYXIgZmV0Y2ggaW50ZXJuYWxzIChzZWUgIzcyMDUpLlxuICAgICAgICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShjYW5jZWxlZEVycm9yLCAnY2F1c2UnLCB7XG4gICAgICAgICAgICBfX3Byb3RvX186IG51bGwsXG4gICAgICAgICAgICB2YWx1ZTogZXJyLFxuICAgICAgICAgICAgd3JpdGFibGU6IHRydWUsXG4gICAgICAgICAgICBlbnVtZXJhYmxlOiBmYWxzZSxcbiAgICAgICAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZSxcbiAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgICB0aHJvdyBjYW5jZWxlZEVycm9yO1xuICAgICAgfVxuXG4gICAgICAvLyBTdXJmYWNlIGEgbWF4Qm9keUxlbmd0aCB2aW9sYXRpb24gd2UgcmFpc2VkIHdoaWxlIHRoZSByZXF1ZXN0IGJvZHkgd2FzXG4gICAgICAvLyBiZWluZyBzdHJlYW1lZC4gS2VlcGluZyB0aGUgb3JpZ2luYWwgZXJyb3IgKHJhdGhlciB0aGFuIHJlYWRpbmdcbiAgICAgIC8vIGBlcnIuY2F1c2UuaXNBeGlvc0Vycm9yYCkga2VlcHMgdGhlIGVycm9yIGRldGVybWluaXN0aWMgYWNyb3NzIHJ1bnRpbWVzXG4gICAgICAvLyBhbmQgYXZvaWRzIGJvdGggcHJvdG90eXBlLXBvbGx1dGlvbiByZWFkcyBhbmQgbWlzLWF0dHJpYnV0aW5nIGEgZm9yZWlnblxuICAgICAgLy8gQXhpb3NFcnJvciB0aGF0IG1lcmVseSBoYXBwZW5lZCB0byBsYW5kIGluIGBlcnIuY2F1c2VgLlxuICAgICAgaWYgKHBlbmRpbmdCb2R5RXJyb3IpIHtcbiAgICAgICAgcmVxdWVzdCAmJiAhcGVuZGluZ0JvZHlFcnJvci5yZXF1ZXN0ICYmIChwZW5kaW5nQm9keUVycm9yLnJlcXVlc3QgPSByZXF1ZXN0KTtcbiAgICAgICAgdGhyb3cgcGVuZGluZ0JvZHlFcnJvcjtcbiAgICAgIH1cblxuICAgICAgaWYgKHBlbmRpbmdSZXNwb25zZUVycm9yKSB7XG4gICAgICAgIHRocm93IHBlbmRpbmdSZXNwb25zZUVycm9yO1xuICAgICAgfVxuXG4gICAgICAvLyBSZS10aHJvdyBBeGlvc0Vycm9ycyB3ZSByYWlzZWQgc3luY2hyb25vdXNseSAoZGF0YTogVVJMIC8gY29udGVudC1sZW5ndGhcbiAgICAgIC8vIHByZS1jaGVja3MsIHJlc3BvbnNlIHNpemUgZW5mb3JjZW1lbnQpIHdpdGhvdXQgcmUtd3JhcHBpbmcgdGhlbS5cbiAgICAgIGlmIChlcnIgaW5zdGFuY2VvZiBBeGlvc0Vycm9yKSB7XG4gICAgICAgIHJlcXVlc3QgJiYgIWVyci5yZXF1ZXN0ICYmIChlcnIucmVxdWVzdCA9IHJlcXVlc3QpO1xuICAgICAgICB0aHJvdyBlcnI7XG4gICAgICB9XG5cbiAgICAgIGlmIChlcnIgJiYgZXJyLm5hbWUgPT09ICdUeXBlRXJyb3InICYmIC9Mb2FkIGZhaWxlZHxmZXRjaC9pLnRlc3QoZXJyLm1lc3NhZ2UpKSB7XG4gICAgICAgIGNvbnN0IG5ldHdvcmtFcnJvciA9IG5ldyBBeGlvc0Vycm9yKFxuICAgICAgICAgICdOZXR3b3JrIEVycm9yJyxcbiAgICAgICAgICBBeGlvc0Vycm9yLkVSUl9ORVRXT1JLLFxuICAgICAgICAgIGNvbmZpZyxcbiAgICAgICAgICByZXF1ZXN0LFxuICAgICAgICAgIGVyciAmJiBlcnIucmVzcG9uc2VcbiAgICAgICAgKTtcbiAgICAgICAgLy8gTm9uLWVudW1lcmFibGUgdG8gbWF0Y2ggbmF0aXZlIEVycm9yIGBjYXVzZWAgc2VtYW50aWNzIHNvIGxvZ2dlcnNcbiAgICAgICAgLy8gZG9uJ3QgcmVjdXJzZSBpbnRvIGNpcmN1bGFyIGZldGNoIGludGVybmFscyAoc2VlICM3MjA1KS5cbiAgICAgICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KG5ldHdvcmtFcnJvciwgJ2NhdXNlJywge1xuICAgICAgICAgIF9fcHJvdG9fXzogbnVsbCxcbiAgICAgICAgICB2YWx1ZTogZXJyLmNhdXNlIHx8IGVycixcbiAgICAgICAgICB3cml0YWJsZTogdHJ1ZSxcbiAgICAgICAgICBlbnVtZXJhYmxlOiBmYWxzZSxcbiAgICAgICAgICBjb25maWd1cmFibGU6IHRydWUsXG4gICAgICAgIH0pO1xuICAgICAgICB0aHJvdyBuZXR3b3JrRXJyb3I7XG4gICAgICB9XG5cbiAgICAgIHRocm93IEF4aW9zRXJyb3IuZnJvbShlcnIsIGVyciAmJiBlcnIuY29kZSwgY29uZmlnLCByZXF1ZXN0LCBlcnIgJiYgZXJyLnJlc3BvbnNlKTtcbiAgICB9XG4gIH07XG59O1xuXG5jb25zdCBzZWVkQ2FjaGUgPSBuZXcgTWFwKCk7XG5cbmV4cG9ydCBjb25zdCBnZXRGZXRjaCA9IChjb25maWcpID0+IHtcbiAgY29uc3QgZW52ID0gT2JqZWN0LmNyZWF0ZShudWxsKTtcbiAgY29uc3QgY29uZmlndXJlZEVudiA9IGNvbmZpZyAmJiB1dGlscy5oYXNPd25Qcm9wKGNvbmZpZywgJ2VudicpICYmIGNvbmZpZy5lbnY7XG4gIFsnZmV0Y2gnLCAnUmVxdWVzdCcsICdSZXNwb25zZScsICdCbG9iJ10uZm9yRWFjaCgoa2V5KSA9PiB7XG4gICAgaWYgKGNvbmZpZ3VyZWRFbnYgJiYgdXRpbHMuaGFzT3duUHJvcChjb25maWd1cmVkRW52LCBrZXkpKSB7XG4gICAgICBlbnZba2V5XSA9IGNvbmZpZ3VyZWRFbnZba2V5XTtcbiAgICB9XG4gIH0pO1xuICBjb25zdCB7IGZldGNoLCBSZXF1ZXN0LCBSZXNwb25zZSwgQmxvYiB9ID0gZW52O1xuICBjb25zdCBzZWVkcyA9IFtSZXF1ZXN0LCBSZXNwb25zZSwgZmV0Y2gsIEJsb2JdO1xuXG4gIGxldCBsZW4gPSBzZWVkcy5sZW5ndGgsXG4gICAgaSA9IGxlbixcbiAgICBzZWVkLFxuICAgIHRhcmdldCxcbiAgICBtYXAgPSBzZWVkQ2FjaGU7XG5cbiAgd2hpbGUgKGktLSkge1xuICAgIHNlZWQgPSBzZWVkc1tpXTtcbiAgICB0YXJnZXQgPSBtYXAuZ2V0KHNlZWQpO1xuXG4gICAgdGFyZ2V0ID09PSB1bmRlZmluZWQgJiYgbWFwLnNldChzZWVkLCAodGFyZ2V0ID0gaSA/IG5ldyBNYXAoKSA6IGZhY3RvcnkoZW52KSkpO1xuXG4gICAgbWFwID0gdGFyZ2V0O1xuICB9XG5cbiAgcmV0dXJuIHRhcmdldDtcbn07XG5cbmNvbnN0IGFkYXB0ZXIgPSBnZXRGZXRjaCgpO1xuXG5leHBvcnQgZGVmYXVsdCBhZGFwdGVyO1xuIiwiaW1wb3J0IHV0aWxzIGZyb20gJy4uL3V0aWxzLmpzJztcbmltcG9ydCBodHRwQWRhcHRlciBmcm9tICcuL2h0dHAuanMnO1xuaW1wb3J0IHhockFkYXB0ZXIgZnJvbSAnLi94aHIuanMnO1xuaW1wb3J0ICogYXMgZmV0Y2hBZGFwdGVyIGZyb20gJy4vZmV0Y2guanMnO1xuaW1wb3J0IEF4aW9zRXJyb3IgZnJvbSAnLi4vY29yZS9BeGlvc0Vycm9yLmpzJztcblxuLyoqXG4gKiBLbm93biBhZGFwdGVycyBtYXBwaW5nLlxuICogUHJvdmlkZXMgZW52aXJvbm1lbnQtc3BlY2lmaWMgYWRhcHRlcnMgZm9yIEF4aW9zOlxuICogLSBgaHR0cGAgZm9yIE5vZGUuanNcbiAqIC0gYHhocmAgZm9yIGJyb3dzZXJzXG4gKiAtIGBmZXRjaGAgZm9yIGZldGNoIEFQSS1iYXNlZCByZXF1ZXN0c1xuICpcbiAqIEB0eXBlIHtPYmplY3Q8c3RyaW5nLCBGdW5jdGlvbnxPYmplY3Q+fVxuICovXG5jb25zdCBrbm93bkFkYXB0ZXJzID0ge1xuICBodHRwOiBodHRwQWRhcHRlcixcbiAgeGhyOiB4aHJBZGFwdGVyLFxuICBmZXRjaDoge1xuICAgIGdldDogZmV0Y2hBZGFwdGVyLmdldEZldGNoLFxuICB9LFxufTtcblxuLy8gQXNzaWduIGFkYXB0ZXIgbmFtZXMgZm9yIGVhc2llciBkZWJ1Z2dpbmcgYW5kIGlkZW50aWZpY2F0aW9uXG51dGlscy5mb3JFYWNoKGtub3duQWRhcHRlcnMsIChmbiwgdmFsdWUpID0+IHtcbiAgaWYgKGZuKSB7XG4gICAgdHJ5IHtcbiAgICAgIC8vIE51bGwtcHJvdG8gZGVzY3JpcHRvcnMgc28gYSBwb2xsdXRlZCBPYmplY3QucHJvdG90eXBlLmdldCBjYW5ub3QgdHVyblxuICAgICAgLy8gdGhlc2UgZGF0YSBkZXNjcmlwdG9ycyBpbnRvIGFjY2Vzc29yIGRlc2NyaXB0b3JzIG9uIHRoZSB3YXkgaW4uXG4gICAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkoZm4sICduYW1lJywgeyBfX3Byb3RvX186IG51bGwsIHZhbHVlIH0pO1xuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBuby1lbXB0eVxuICAgIH1cbiAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkoZm4sICdhZGFwdGVyTmFtZScsIHsgX19wcm90b19fOiBudWxsLCB2YWx1ZSB9KTtcbiAgfVxufSk7XG5cbi8qKlxuICogUmVuZGVyIGEgcmVqZWN0aW9uIHJlYXNvbiBzdHJpbmcgZm9yIHVua25vd24gb3IgdW5zdXBwb3J0ZWQgYWRhcHRlcnNcbiAqXG4gKiBAcGFyYW0ge3N0cmluZ30gcmVhc29uXG4gKiBAcmV0dXJucyB7c3RyaW5nfVxuICovXG5jb25zdCByZW5kZXJSZWFzb24gPSAocmVhc29uKSA9PiBgLSAke3JlYXNvbn1gO1xuXG4vKipcbiAqIENoZWNrIGlmIHRoZSBhZGFwdGVyIGlzIHJlc29sdmVkIChmdW5jdGlvbiwgbnVsbCwgb3IgZmFsc2UpXG4gKlxuICogQHBhcmFtIHtGdW5jdGlvbnxudWxsfGZhbHNlfSBhZGFwdGVyXG4gKiBAcmV0dXJucyB7Ym9vbGVhbn1cbiAqL1xuY29uc3QgaXNSZXNvbHZlZEhhbmRsZSA9IChhZGFwdGVyKSA9PlxuICB1dGlscy5pc0Z1bmN0aW9uKGFkYXB0ZXIpIHx8IGFkYXB0ZXIgPT09IG51bGwgfHwgYWRhcHRlciA9PT0gZmFsc2U7XG5cbi8qKlxuICogR2V0IHRoZSBmaXJzdCBzdWl0YWJsZSBhZGFwdGVyIGZyb20gdGhlIHByb3ZpZGVkIGxpc3QuXG4gKiBUcmllcyBlYWNoIGFkYXB0ZXIgaW4gb3JkZXIgdW50aWwgYSBzdXBwb3J0ZWQgb25lIGlzIGZvdW5kLlxuICogVGhyb3dzIGFuIEF4aW9zRXJyb3IgaWYgbm8gYWRhcHRlciBpcyBzdWl0YWJsZS5cbiAqXG4gKiBAcGFyYW0ge0FycmF5PHN0cmluZ3xGdW5jdGlvbj58c3RyaW5nfEZ1bmN0aW9ufSBhZGFwdGVycyAtIEFkYXB0ZXIocykgYnkgbmFtZSBvciBmdW5jdGlvbi5cbiAqIEBwYXJhbSB7T2JqZWN0fSBjb25maWcgLSBBeGlvcyByZXF1ZXN0IGNvbmZpZ3VyYXRpb25cbiAqIEB0aHJvd3Mge0F4aW9zRXJyb3J9IElmIG5vIHN1aXRhYmxlIGFkYXB0ZXIgaXMgYXZhaWxhYmxlXG4gKiBAcmV0dXJucyB7RnVuY3Rpb259IFRoZSByZXNvbHZlZCBhZGFwdGVyIGZ1bmN0aW9uXG4gKi9cbmZ1bmN0aW9uIGdldEFkYXB0ZXIoYWRhcHRlcnMsIGNvbmZpZykge1xuICBhZGFwdGVycyA9IHV0aWxzLmlzQXJyYXkoYWRhcHRlcnMpID8gYWRhcHRlcnMgOiBbYWRhcHRlcnNdO1xuXG4gIGNvbnN0IHsgbGVuZ3RoIH0gPSBhZGFwdGVycztcbiAgbGV0IG5hbWVPckFkYXB0ZXI7XG4gIGxldCBhZGFwdGVyO1xuXG4gIGNvbnN0IHJlamVjdGVkUmVhc29ucyA9IHt9O1xuXG4gIGZvciAobGV0IGkgPSAwOyBpIDwgbGVuZ3RoOyBpKyspIHtcbiAgICBuYW1lT3JBZGFwdGVyID0gYWRhcHRlcnNbaV07XG4gICAgbGV0IGlkO1xuXG4gICAgYWRhcHRlciA9IG5hbWVPckFkYXB0ZXI7XG5cbiAgICBpZiAoIWlzUmVzb2x2ZWRIYW5kbGUobmFtZU9yQWRhcHRlcikpIHtcbiAgICAgIGFkYXB0ZXIgPSBrbm93bkFkYXB0ZXJzWyhpZCA9IFN0cmluZyhuYW1lT3JBZGFwdGVyKSkudG9Mb3dlckNhc2UoKV07XG5cbiAgICAgIGlmIChhZGFwdGVyID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgdGhyb3cgbmV3IEF4aW9zRXJyb3IoYFVua25vd24gYWRhcHRlciAnJHtpZH0nYCk7XG4gICAgICB9XG4gICAgfVxuXG4gICAgaWYgKGFkYXB0ZXIgJiYgKHV0aWxzLmlzRnVuY3Rpb24oYWRhcHRlcikgfHwgKGFkYXB0ZXIgPSBhZGFwdGVyLmdldChjb25maWcpKSkpIHtcbiAgICAgIGJyZWFrO1xuICAgIH1cblxuICAgIHJlamVjdGVkUmVhc29uc1tpZCB8fCAnIycgKyBpXSA9IGFkYXB0ZXI7XG4gIH1cblxuICBpZiAoIWFkYXB0ZXIpIHtcbiAgICBjb25zdCByZWFzb25zID0gT2JqZWN0LmVudHJpZXMocmVqZWN0ZWRSZWFzb25zKS5tYXAoXG4gICAgICAoW2lkLCBzdGF0ZV0pID0+XG4gICAgICAgIGBhZGFwdGVyICR7aWR9IGAgK1xuICAgICAgICAoc3RhdGUgPT09IGZhbHNlID8gJ2lzIG5vdCBzdXBwb3J0ZWQgYnkgdGhlIGVudmlyb25tZW50JyA6ICdpcyBub3QgYXZhaWxhYmxlIGluIHRoZSBidWlsZCcpXG4gICAgKTtcblxuICAgIGxldCBzID0gbGVuZ3RoXG4gICAgICA/IHJlYXNvbnMubGVuZ3RoID4gMVxuICAgICAgICA/ICdzaW5jZSA6XFxuJyArIHJlYXNvbnMubWFwKHJlbmRlclJlYXNvbikuam9pbignXFxuJylcbiAgICAgICAgOiAnICcgKyByZW5kZXJSZWFzb24ocmVhc29uc1swXSlcbiAgICAgIDogJ2FzIG5vIGFkYXB0ZXIgc3BlY2lmaWVkJztcblxuICAgIHRocm93IG5ldyBBeGlvc0Vycm9yKFxuICAgICAgYFRoZXJlIGlzIG5vIHN1aXRhYmxlIGFkYXB0ZXIgdG8gZGlzcGF0Y2ggdGhlIHJlcXVlc3QgYCArIHMsXG4gICAgICBBeGlvc0Vycm9yLkVSUl9OT1RfU1VQUE9SVFxuICAgICk7XG4gIH1cblxuICByZXR1cm4gYWRhcHRlcjtcbn1cblxuLyoqXG4gKiBFeHBvcnRzIEF4aW9zIGFkYXB0ZXJzIGFuZCB1dGlsaXR5IHRvIHJlc29sdmUgYW4gYWRhcHRlclxuICovXG5leHBvcnQgZGVmYXVsdCB7XG4gIC8qKlxuICAgKiBSZXNvbHZlIGFuIGFkYXB0ZXIgZnJvbSBhIGxpc3Qgb2YgYWRhcHRlciBuYW1lcyBvciBmdW5jdGlvbnMuXG4gICAqIEB0eXBlIHtGdW5jdGlvbn1cbiAgICovXG4gIGdldEFkYXB0ZXIsXG5cbiAgLyoqXG4gICAqIEV4cG9zZXMgYWxsIGtub3duIGFkYXB0ZXJzXG4gICAqIEB0eXBlIHtPYmplY3Q8c3RyaW5nLCBGdW5jdGlvbnxPYmplY3Q+fVxuICAgKi9cbiAgYWRhcHRlcnM6IGtub3duQWRhcHRlcnMsXG59O1xuIiwiJ3VzZSBzdHJpY3QnO1xuXG5pbXBvcnQgdHJhbnNmb3JtRGF0YSBmcm9tICcuL3RyYW5zZm9ybURhdGEuanMnO1xuaW1wb3J0IGlzQ2FuY2VsIGZyb20gJy4uL2NhbmNlbC9pc0NhbmNlbC5qcyc7XG5pbXBvcnQgZGVmYXVsdHMgZnJvbSAnLi4vZGVmYXVsdHMvaW5kZXguanMnO1xuaW1wb3J0IENhbmNlbGVkRXJyb3IgZnJvbSAnLi4vY2FuY2VsL0NhbmNlbGVkRXJyb3IuanMnO1xuaW1wb3J0IEF4aW9zSGVhZGVycyBmcm9tICcuLi9jb3JlL0F4aW9zSGVhZGVycy5qcyc7XG5pbXBvcnQgYWRhcHRlcnMgZnJvbSAnLi4vYWRhcHRlcnMvYWRhcHRlcnMuanMnO1xuaW1wb3J0IHV0aWxzIGZyb20gJy4uL3V0aWxzLmpzJztcblxuLyoqXG4gKiBUaHJvd3MgYSBgQ2FuY2VsZWRFcnJvcmAgaWYgY2FuY2VsbGF0aW9uIGhhcyBiZWVuIHJlcXVlc3RlZC5cbiAqXG4gKiBAcGFyYW0ge09iamVjdH0gY29uZmlnIFRoZSBjb25maWcgdGhhdCBpcyB0byBiZSB1c2VkIGZvciB0aGUgcmVxdWVzdFxuICpcbiAqIEByZXR1cm5zIHt2b2lkfVxuICovXG5mdW5jdGlvbiB0aHJvd0lmQ2FuY2VsbGF0aW9uUmVxdWVzdGVkKGNvbmZpZykge1xuICBpZiAoY29uZmlnLmNhbmNlbFRva2VuKSB7XG4gICAgY29uZmlnLmNhbmNlbFRva2VuLnRocm93SWZSZXF1ZXN0ZWQoKTtcbiAgfVxuXG4gIGlmIChjb25maWcuc2lnbmFsICYmIGNvbmZpZy5zaWduYWwuYWJvcnRlZCkge1xuICAgIHRocm93IG5ldyBDYW5jZWxlZEVycm9yKG51bGwsIGNvbmZpZyk7XG4gIH1cbn1cblxuLyoqXG4gKiBSZXNvbHZlIHRoZSBjbG9jayB1c2VkIHRvIHRpbWUgYWRhcHRlciBleGVjdXRpb24uXG4gKlxuICogUHJlZmVycyB0aGUgbW9ub3RvbmljIGBwZXJmb3JtYW5jZS5ub3coKWAgc28gd2FsbC1jbG9jayBhZGp1c3RtZW50cyBkbyBub3RcbiAqIHNrZXcgdGhlIG1lYXN1cmVtZW50LCBhbmQgc28gZnJhbWV3b3JrcyB0aGF0IGZvcmJpZCByZWFkaW5nIHRoZSBjdXJyZW50XG4gKiB0aW1lIGR1cmluZyBwcmVyZW5kZXJpbmcgKGUuZy4gTmV4dC5qcyBDYWNoZSBDb21wb25lbnRzKSBhY2NlcHQgaXQuIEZhbGxzXG4gKiBiYWNrIHRvIGBEYXRlLm5vdygpYCBpbiBydW50aW1lcyB3aXRob3V0IHRoZSBIaWdoIFJlc29sdXRpb24gVGltZSBBUEkuXG4gKlxuICogQHJldHVybnMgeygpID0+IG51bWJlcn0gTWlsbGlzZWNvbmQgY2xvY2tcbiAqL1xuZnVuY3Rpb24gcmVzb2x2ZUNsb2NrKCkge1xuICByZXR1cm4gdHlwZW9mIHBlcmZvcm1hbmNlICE9PSAndW5kZWZpbmVkJyAmJiB1dGlscy5pc0Z1bmN0aW9uKHBlcmZvcm1hbmNlLm5vdylcbiAgICA/ICgpID0+IHBlcmZvcm1hbmNlLm5vdygpXG4gICAgOiBEYXRlLm5vdztcbn1cblxuLyoqXG4gKiBXaG9sZSBtaWxsaXNlY29uZHMgZWxhcHNlZCBzaW5jZSBgc3RhcnRgLCBmbG9vcmVkIGF0IHplcm8uXG4gKlxuICogUm91bmRlZCBzbyB0aGUgdmFsdWUgc3RheXMgYW4gaW50ZWdlciBhcyB3aXRoIGBEYXRlLm5vdygpYC4gVGhlIGZhbGxiYWNrXG4gKiB3YWxsIGNsb2NrIGNhbiBtb3ZlIGJhY2t3YXJkcyBtaWQtcmVxdWVzdCwgc28gdGhlIHJlc3VsdCBpcyBjbGFtcGVkLlxuICpcbiAqIEBwYXJhbSB7KCkgPT4gbnVtYmVyfSBub3cgQ2xvY2sgcmV0dXJuZWQgYnkgYHJlc29sdmVDbG9jaygpYFxuICogQHBhcmFtIHtudW1iZXJ9IHN0YXJ0IFRpbWVzdGFtcCByZWFkIGZyb20gYG5vd2BcbiAqXG4gKiBAcmV0dXJucyB7bnVtYmVyfSBOb24tbmVnYXRpdmUgZWxhcHNlZCBtaWxsaXNlY29uZHNcbiAqL1xuZnVuY3Rpb24gZWxhcHNlZFNpbmNlKG5vdywgc3RhcnQpIHtcbiAgcmV0dXJuIE1hdGgubWF4KDAsIE1hdGgucm91bmQobm93KCkgLSBzdGFydCkpO1xufVxuXG4vKipcbiAqIERpc3BhdGNoIGEgcmVxdWVzdCB0byB0aGUgc2VydmVyIHVzaW5nIHRoZSBjb25maWd1cmVkIGFkYXB0ZXIuXG4gKlxuICogQHBhcmFtIHtvYmplY3R9IGNvbmZpZyBUaGUgY29uZmlnIHRoYXQgaXMgdG8gYmUgdXNlZCBmb3IgdGhlIHJlcXVlc3RcbiAqXG4gKiBAcmV0dXJucyB7UHJvbWlzZX0gVGhlIFByb21pc2UgdG8gYmUgZnVsZmlsbGVkXG4gKi9cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIGRpc3BhdGNoUmVxdWVzdChfY29uZmlnKSB7XG4gIC8vIEludGVyY2VwdG9ycyBtYXkgcmVwbGFjZSB0aGUgbWVyZ2VkIGNvbmZpZyB3aXRoIGFuIG9yZGluYXJ5IG9iamVjdC4gRmxhdHRlblxuICAvLyBpdCBhdCB0aGUgZGlzcGF0Y2ggYm91bmRhcnkgc28gc2hhcmVkIHByb3RvdHlwZSBtZW1iZXJzIGNhbm5vdCBiZWNvbWVcbiAgLy8gcmVxdWVzdCBiZWhhdmlvciwgd2hpbGUgcHJlc2VydmluZyBpbnRlbnRpb25hbCB0ZW1wbGF0ZS9jbGFzcyBtZW1iZXJzLlxuICBjb25zdCBjb25maWcgPSB1dGlscy50b1NhZmVGbGF0T2JqZWN0KF9jb25maWcpO1xuXG4gIHRocm93SWZDYW5jZWxsYXRpb25SZXF1ZXN0ZWQoY29uZmlnKTtcblxuICBjb25maWcuaGVhZGVycyA9IEF4aW9zSGVhZGVycy5mcm9tKHV0aWxzLmdldFNhZmVQcm9wKGNvbmZpZywgJ2hlYWRlcnMnKSk7XG5cbiAgLy8gVHJhbnNmb3JtIHJlcXVlc3QgZGF0YVxuICBjb25maWcuZGF0YSA9IHRyYW5zZm9ybURhdGEuY2FsbChjb25maWcsIGNvbmZpZy50cmFuc2Zvcm1SZXF1ZXN0KTtcblxuICBpZiAoWydwb3N0JywgJ3B1dCcsICdwYXRjaCddLmluZGV4T2YoY29uZmlnLm1ldGhvZCkgIT09IC0xKSB7XG4gICAgY29uZmlnLmhlYWRlcnMuc2V0Q29udGVudFR5cGUoJ2FwcGxpY2F0aW9uL3gtd3d3LWZvcm0tdXJsZW5jb2RlZCcsIGZhbHNlKTtcbiAgfVxuXG4gIGNvbnN0IGFkYXB0ZXIgPSBhZGFwdGVycy5nZXRBZGFwdGVyKGNvbmZpZy5hZGFwdGVyIHx8IGRlZmF1bHRzLmFkYXB0ZXIsIGNvbmZpZyk7XG5cbiAgY29uc3Qgbm93ID0gcmVzb2x2ZUNsb2NrKCk7XG4gIGNvbnN0IHN0YXJ0ID0gbm93KCk7XG5cbiAgcmV0dXJuIGFkYXB0ZXIoY29uZmlnKS50aGVuKFxuICAgIGZ1bmN0aW9uIG9uQWRhcHRlclJlc29sdXRpb24ocmVzcG9uc2UpIHtcbiAgICAgIHRocm93SWZDYW5jZWxsYXRpb25SZXF1ZXN0ZWQoY29uZmlnKTtcblxuICAgICAgcmVzcG9uc2UuZHVyYXRpb24gPSBlbGFwc2VkU2luY2Uobm93LCBzdGFydCk7XG5cbiAgICAgIC8vIEV4cG9zZSB0aGUgY3VycmVudCByZXNwb25zZSBvbiBjb25maWcgc28gdGhhdCB0cmFuc2Zvcm1SZXNwb25zZSBjYW5cbiAgICAgIC8vIGF0dGFjaCBpdCB0byBhbnkgQXhpb3NFcnJvciBpdCB0aHJvd3MgKGUuZy4gb24gSlNPTiBwYXJzZSBmYWlsdXJlKS5cbiAgICAgIC8vIFdlIGNsZWFuIGl0IHVwIGFmdGVyd2FyZHMgdG8gYXZvaWQgcG9sbHV0aW5nIHRoZSBjb25maWcgb2JqZWN0LlxuICAgICAgY29uZmlnLnJlc3BvbnNlID0gcmVzcG9uc2U7XG4gICAgICB0cnkge1xuICAgICAgICByZXNwb25zZS5kYXRhID0gdHJhbnNmb3JtRGF0YS5jYWxsKGNvbmZpZywgY29uZmlnLnRyYW5zZm9ybVJlc3BvbnNlLCByZXNwb25zZSk7XG4gICAgICB9IGZpbmFsbHkge1xuICAgICAgICBkZWxldGUgY29uZmlnLnJlc3BvbnNlO1xuICAgICAgfVxuXG4gICAgICByZXNwb25zZS5oZWFkZXJzID0gQXhpb3NIZWFkZXJzLmZyb20ocmVzcG9uc2UuaGVhZGVycyk7XG5cbiAgICAgIHJldHVybiByZXNwb25zZTtcbiAgICB9LFxuICAgIGZ1bmN0aW9uIG9uQWRhcHRlclJlamVjdGlvbihyZWFzb24pIHtcbiAgICAgIGlmICghaXNDYW5jZWwocmVhc29uKSkge1xuICAgICAgICB0aHJvd0lmQ2FuY2VsbGF0aW9uUmVxdWVzdGVkKGNvbmZpZyk7XG5cbiAgICAgICAgLy8gVHJhbnNmb3JtIHJlc3BvbnNlIGRhdGFcbiAgICAgICAgaWYgKHJlYXNvbiAmJiByZWFzb24ucmVzcG9uc2UpIHtcbiAgICAgICAgICByZWFzb24ucmVzcG9uc2UuZHVyYXRpb24gPSBlbGFwc2VkU2luY2Uobm93LCBzdGFydCk7XG4gICAgICAgICAgY29uZmlnLnJlc3BvbnNlID0gcmVhc29uLnJlc3BvbnNlO1xuICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICByZWFzb24ucmVzcG9uc2UuZGF0YSA9IHRyYW5zZm9ybURhdGEuY2FsbChcbiAgICAgICAgICAgICAgY29uZmlnLFxuICAgICAgICAgICAgICBjb25maWcudHJhbnNmb3JtUmVzcG9uc2UsXG4gICAgICAgICAgICAgIHJlYXNvbi5yZXNwb25zZVxuICAgICAgICAgICAgKTtcbiAgICAgICAgICB9IGZpbmFsbHkge1xuICAgICAgICAgICAgZGVsZXRlIGNvbmZpZy5yZXNwb25zZTtcbiAgICAgICAgICB9XG4gICAgICAgICAgcmVhc29uLnJlc3BvbnNlLmhlYWRlcnMgPSBBeGlvc0hlYWRlcnMuZnJvbShyZWFzb24ucmVzcG9uc2UuaGVhZGVycyk7XG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgcmV0dXJuIFByb21pc2UucmVqZWN0KHJlYXNvbik7XG4gICAgfVxuICApO1xufVxuIiwiJ3VzZSBzdHJpY3QnO1xuXG5pbXBvcnQgeyBWRVJTSU9OIH0gZnJvbSAnLi4vZW52L2RhdGEuanMnO1xuaW1wb3J0IEF4aW9zRXJyb3IgZnJvbSAnLi4vY29yZS9BeGlvc0Vycm9yLmpzJztcblxuY29uc3QgdmFsaWRhdG9ycyA9IHt9O1xuXG4vLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgZnVuYy1uYW1lc1xuWydvYmplY3QnLCAnYm9vbGVhbicsICdudW1iZXInLCAnZnVuY3Rpb24nLCAnc3RyaW5nJywgJ3N5bWJvbCddLmZvckVhY2goKHR5cGUsIGkpID0+IHtcbiAgdmFsaWRhdG9yc1t0eXBlXSA9IGZ1bmN0aW9uIHZhbGlkYXRvcih0aGluZykge1xuICAgIHJldHVybiB0eXBlb2YgdGhpbmcgPT09IHR5cGUgfHwgJ2EnICsgKGkgPCAxID8gJ24gJyA6ICcgJykgKyB0eXBlO1xuICB9O1xufSk7XG5cbmNvbnN0IGRlcHJlY2F0ZWRXYXJuaW5ncyA9IHt9O1xuXG4vKipcbiAqIFRyYW5zaXRpb25hbCBvcHRpb24gdmFsaWRhdG9yXG4gKlxuICogQHBhcmFtIHtmdW5jdGlvbnxib29sZWFuP30gdmFsaWRhdG9yIC0gc2V0IHRvIGZhbHNlIGlmIHRoZSB0cmFuc2l0aW9uYWwgb3B0aW9uIGhhcyBiZWVuIHJlbW92ZWRcbiAqIEBwYXJhbSB7c3RyaW5nP30gdmVyc2lvbiAtIGRlcHJlY2F0ZWQgdmVyc2lvbiAvIHJlbW92ZWQgc2luY2UgdmVyc2lvblxuICogQHBhcmFtIHtzdHJpbmc/fSBtZXNzYWdlIC0gc29tZSBtZXNzYWdlIHdpdGggYWRkaXRpb25hbCBpbmZvXG4gKlxuICogQHJldHVybnMge2Z1bmN0aW9ufVxuICovXG52YWxpZGF0b3JzLnRyYW5zaXRpb25hbCA9IGZ1bmN0aW9uIHRyYW5zaXRpb25hbCh2YWxpZGF0b3IsIHZlcnNpb24sIG1lc3NhZ2UpIHtcbiAgZnVuY3Rpb24gZm9ybWF0TWVzc2FnZShvcHQsIGRlc2MpIHtcbiAgICByZXR1cm4gKFxuICAgICAgJ1tBeGlvcyB2JyArXG4gICAgICBWRVJTSU9OICtcbiAgICAgIFwiXSBUcmFuc2l0aW9uYWwgb3B0aW9uICdcIiArXG4gICAgICBvcHQgK1xuICAgICAgXCInXCIgK1xuICAgICAgZGVzYyArXG4gICAgICAobWVzc2FnZSA/ICcuICcgKyBtZXNzYWdlIDogJycpXG4gICAgKTtcbiAgfVxuXG4gIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBmdW5jLW5hbWVzXG4gIHJldHVybiAodmFsdWUsIG9wdCwgb3B0cykgPT4ge1xuICAgIGlmICh2YWxpZGF0b3IgPT09IGZhbHNlKSB7XG4gICAgICB0aHJvdyBuZXcgQXhpb3NFcnJvcihcbiAgICAgICAgZm9ybWF0TWVzc2FnZShvcHQsICcgaGFzIGJlZW4gcmVtb3ZlZCcgKyAodmVyc2lvbiA/ICcgaW4gJyArIHZlcnNpb24gOiAnJykpLFxuICAgICAgICBBeGlvc0Vycm9yLkVSUl9ERVBSRUNBVEVEXG4gICAgICApO1xuICAgIH1cblxuICAgIGlmICh2ZXJzaW9uICYmICFkZXByZWNhdGVkV2FybmluZ3Nbb3B0XSkge1xuICAgICAgZGVwcmVjYXRlZFdhcm5pbmdzW29wdF0gPSB0cnVlO1xuICAgICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIG5vLWNvbnNvbGVcbiAgICAgIGNvbnNvbGUud2FybihcbiAgICAgICAgZm9ybWF0TWVzc2FnZShcbiAgICAgICAgICBvcHQsXG4gICAgICAgICAgJyBoYXMgYmVlbiBkZXByZWNhdGVkIHNpbmNlIHYnICsgdmVyc2lvbiArICcgYW5kIHdpbGwgYmUgcmVtb3ZlZCBpbiB0aGUgbmVhciBmdXR1cmUnXG4gICAgICAgIClcbiAgICAgICk7XG4gICAgfVxuXG4gICAgcmV0dXJuIHZhbGlkYXRvciA/IHZhbGlkYXRvcih2YWx1ZSwgb3B0LCBvcHRzKSA6IHRydWU7XG4gIH07XG59O1xuXG52YWxpZGF0b3JzLnNwZWxsaW5nID0gZnVuY3Rpb24gc3BlbGxpbmcoY29ycmVjdFNwZWxsaW5nKSB7XG4gIHJldHVybiAodmFsdWUsIG9wdCkgPT4ge1xuICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBuby1jb25zb2xlXG4gICAgY29uc29sZS53YXJuKGAke29wdH0gaXMgbGlrZWx5IGEgbWlzc3BlbGxpbmcgb2YgJHtjb3JyZWN0U3BlbGxpbmd9YCk7XG4gICAgcmV0dXJuIHRydWU7XG4gIH07XG59O1xuXG4vKipcbiAqIEFzc2VydCBvYmplY3QncyBwcm9wZXJ0aWVzIHR5cGVcbiAqXG4gKiBAcGFyYW0ge29iamVjdH0gb3B0aW9uc1xuICogQHBhcmFtIHtvYmplY3R9IHNjaGVtYVxuICogQHBhcmFtIHtib29sZWFuP30gYWxsb3dVbmtub3duXG4gKlxuICogQHJldHVybnMge29iamVjdH1cbiAqL1xuXG5mdW5jdGlvbiBhc3NlcnRPcHRpb25zKG9wdGlvbnMsIHNjaGVtYSwgYWxsb3dVbmtub3duKSB7XG4gIGlmICh0eXBlb2Ygb3B0aW9ucyAhPT0gJ29iamVjdCcgfHwgb3B0aW9ucyA9PT0gbnVsbCkge1xuICAgIHRocm93IG5ldyBBeGlvc0Vycm9yKCdvcHRpb25zIG11c3QgYmUgYW4gb2JqZWN0JywgQXhpb3NFcnJvci5FUlJfQkFEX09QVElPTl9WQUxVRSk7XG4gIH1cbiAgY29uc3Qga2V5cyA9IE9iamVjdC5rZXlzKG9wdGlvbnMpO1xuICBsZXQgaSA9IGtleXMubGVuZ3RoO1xuICB3aGlsZSAoaS0tID4gMCkge1xuICAgIGNvbnN0IG9wdCA9IGtleXNbaV07XG4gICAgLy8gVXNlIGhhc093blByb3BlcnR5IHNvIGEgcG9sbHV0ZWQgT2JqZWN0LnByb3RvdHlwZS48b3B0PiBjYW5ub3Qgc3VwcGx5XG4gICAgLy8gYSBub24tZnVuY3Rpb24gdmFsaWRhdG9yIGFuZCBjYXVzZSBhIFR5cGVFcnJvci5cbiAgICBjb25zdCB2YWxpZGF0b3IgPSBPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwoc2NoZW1hLCBvcHQpID8gc2NoZW1hW29wdF0gOiB1bmRlZmluZWQ7XG4gICAgaWYgKHZhbGlkYXRvcikge1xuICAgICAgY29uc3QgdmFsdWUgPSBvcHRpb25zW29wdF07XG4gICAgICBjb25zdCByZXN1bHQgPSB2YWx1ZSA9PT0gdW5kZWZpbmVkIHx8IHZhbGlkYXRvcih2YWx1ZSwgb3B0LCBvcHRpb25zKTtcbiAgICAgIGlmIChyZXN1bHQgIT09IHRydWUpIHtcbiAgICAgICAgdGhyb3cgbmV3IEF4aW9zRXJyb3IoXG4gICAgICAgICAgJ29wdGlvbiAnICsgb3B0ICsgJyBtdXN0IGJlICcgKyByZXN1bHQsXG4gICAgICAgICAgQXhpb3NFcnJvci5FUlJfQkFEX09QVElPTl9WQUxVRVxuICAgICAgICApO1xuICAgICAgfVxuICAgICAgY29udGludWU7XG4gICAgfVxuICAgIGlmIChhbGxvd1Vua25vd24gIT09IHRydWUpIHtcbiAgICAgIHRocm93IG5ldyBBeGlvc0Vycm9yKCdVbmtub3duIG9wdGlvbiAnICsgb3B0LCBBeGlvc0Vycm9yLkVSUl9CQURfT1BUSU9OKTtcbiAgICB9XG4gIH1cbn1cblxuZXhwb3J0IGRlZmF1bHQge1xuICBhc3NlcnRPcHRpb25zLFxuICB2YWxpZGF0b3JzLFxufTtcbiIsIid1c2Ugc3RyaWN0JztcblxuaW1wb3J0IHV0aWxzIGZyb20gJy4uL3V0aWxzLmpzJztcbmltcG9ydCBidWlsZFVSTCBmcm9tICcuLi9oZWxwZXJzL2J1aWxkVVJMLmpzJztcbmltcG9ydCBJbnRlcmNlcHRvck1hbmFnZXIgZnJvbSAnLi9JbnRlcmNlcHRvck1hbmFnZXIuanMnO1xuaW1wb3J0IGRpc3BhdGNoUmVxdWVzdCBmcm9tICcuL2Rpc3BhdGNoUmVxdWVzdC5qcyc7XG5pbXBvcnQgbWVyZ2VDb25maWcgZnJvbSAnLi9tZXJnZUNvbmZpZy5qcyc7XG5pbXBvcnQgYnVpbGRGdWxsUGF0aCBmcm9tICcuL2J1aWxkRnVsbFBhdGguanMnO1xuaW1wb3J0IG1ldGhvZExpc3QgZnJvbSAnLi9tZXRob2RMaXN0LmpzJztcbmltcG9ydCB2YWxpZGF0b3IgZnJvbSAnLi4vaGVscGVycy92YWxpZGF0b3IuanMnO1xuaW1wb3J0IEF4aW9zSGVhZGVycyBmcm9tICcuL0F4aW9zSGVhZGVycy5qcyc7XG5pbXBvcnQgdHJhbnNpdGlvbmFsRGVmYXVsdHMgZnJvbSAnLi4vZGVmYXVsdHMvdHJhbnNpdGlvbmFsLmpzJztcbmltcG9ydCB7IGdldENhdXNlU3RhY2tJbmRleCB9IGZyb20gJy4vQXhpb3NFcnJvci5qcyc7XG5cbmNvbnN0IHZhbGlkYXRvcnMgPSB2YWxpZGF0b3IudmFsaWRhdG9ycztcblxuLy8gUmVjb2duaXplIGhlYWRlciBtYXBzIHdpdGhvdXQgY29uc3VtaW5nIG9iamVjdHMgaW50ZW5kZWQgYXMgbGl0ZXJhbCB2YWx1ZXMuXG4vLyBBeGlvc0hlYWRlcnMgZnJvbSBvdGhlciBidWlsZHMgc2hhcmUgYSBicmFuZCBhbmQgaGVhZGVyLWNvbnRhaW5lciBpbnRlcmZhY2UsXG4vLyBidXQgbm90IGNvbnN0cnVjdG9yIGlkZW50aXR5LiBBIHRhZyBhbmQgdG9KU09OIGFsb25lIGNhbiBkZXNjcmliZSBhIGxpdGVyYWwuXG5jb25zdCBpc0hlYWRlcnNCdWNrZXQgPSAodmFsdWUpID0+IHtcbiAgaWYgKHZhbHVlID09IG51bGwgfHwgdXRpbHMuaXNQbGFpbk9iamVjdCh2YWx1ZSkgfHwgdmFsdWUgaW5zdGFuY2VvZiBBeGlvc0hlYWRlcnMpIHtcbiAgICByZXR1cm4gdHJ1ZTtcbiAgfVxuXG4gIHRyeSB7XG4gICAgcmV0dXJuIChcbiAgICAgIHV0aWxzLmlzT2JqZWN0KHZhbHVlKSAmJlxuICAgICAgdXRpbHMuZ2V0U2FmZVByb3AodmFsdWUsIFN5bWJvbC50b1N0cmluZ1RhZykgPT09ICdBeGlvc0hlYWRlcnMnICYmXG4gICAgICBbXG4gICAgICAgICd0b0pTT04nLFxuICAgICAgICAnc2V0JyxcbiAgICAgICAgJ2dldCcsXG4gICAgICAgICdoYXMnLFxuICAgICAgICAnZGVsZXRlJyxcbiAgICAgICAgJ2NsZWFyJyxcbiAgICAgICAgJ25vcm1hbGl6ZScsXG4gICAgICAgICdjb25jYXQnLFxuICAgICAgICAndG9TdHJpbmcnLFxuICAgICAgICBTeW1ib2wuaXRlcmF0b3IsXG4gICAgICBdLmV2ZXJ5KChtZXRob2QpID0+IHV0aWxzLmlzRnVuY3Rpb24odXRpbHMuZ2V0U2FmZVByb3AodmFsdWUsIG1ldGhvZCkpKVxuICAgICk7XG4gIH0gY2F0Y2ggKGUpIHtcbiAgICAvLyBBIGZhaWxlZCBvcHRpb25hbCBicmFuZCBwcm9iZSBtdXN0IG5vdCBwcmV2ZW50IGxpdGVyYWwgaGVhZGVyIHNlcmlhbGl6YXRpb24uXG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG59O1xuXG4vKipcbiAqIENyZWF0ZSBhIG5ldyBpbnN0YW5jZSBvZiBBeGlvc1xuICpcbiAqIEBwYXJhbSB7T2JqZWN0fSBpbnN0YW5jZUNvbmZpZyBUaGUgZGVmYXVsdCBjb25maWcgZm9yIHRoZSBpbnN0YW5jZVxuICpcbiAqIEByZXR1cm4ge0F4aW9zfSBBIG5ldyBpbnN0YW5jZSBvZiBBeGlvc1xuICovXG5jbGFzcyBBeGlvcyB7XG4gIGNvbnN0cnVjdG9yKGluc3RhbmNlQ29uZmlnKSB7XG4gICAgdGhpcy5kZWZhdWx0cyA9IGluc3RhbmNlQ29uZmlnIHx8IHt9O1xuICAgIHRoaXMuaW50ZXJjZXB0b3JzID0ge1xuICAgICAgcmVxdWVzdDogbmV3IEludGVyY2VwdG9yTWFuYWdlcigpLFxuICAgICAgcmVzcG9uc2U6IG5ldyBJbnRlcmNlcHRvck1hbmFnZXIoKSxcbiAgICB9O1xuICB9XG5cbiAgLyoqXG4gICAqIERpc3BhdGNoIGEgcmVxdWVzdFxuICAgKlxuICAgKiBAcGFyYW0ge1N0cmluZ3xPYmplY3R9IGNvbmZpZ09yVXJsIFRoZSBjb25maWcgc3BlY2lmaWMgZm9yIHRoaXMgcmVxdWVzdCAobWVyZ2VkIHdpdGggdGhpcy5kZWZhdWx0cylcbiAgICogQHBhcmFtIHs/T2JqZWN0fSBjb25maWdcbiAgICpcbiAgICogQHJldHVybnMge1Byb21pc2V9IFRoZSBQcm9taXNlIHRvIGJlIGZ1bGZpbGxlZFxuICAgKi9cbiAgYXN5bmMgcmVxdWVzdChjb25maWdPclVybCwgY29uZmlnKSB7XG4gICAgdHJ5IHtcbiAgICAgIHJldHVybiBhd2FpdCB0aGlzLl9yZXF1ZXN0KGNvbmZpZ09yVXJsLCBjb25maWcpO1xuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgaWYgKGVyciBpbnN0YW5jZW9mIEVycm9yKSB7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgbGV0IGR1bW15ID0ge307XG5cbiAgICAgICAgICBFcnJvci5jYXB0dXJlU3RhY2tUcmFjZSA/IEVycm9yLmNhcHR1cmVTdGFja1RyYWNlKGR1bW15KSA6IChkdW1teSA9IG5ldyBFcnJvcigpKTtcblxuICAgICAgICAgIGNvbnN0IGR1bW15U3RhY2sgPSBkdW1teS5zdGFjaztcbiAgICAgICAgICBsZXQgc3RhY2sgPSAnJztcblxuICAgICAgICAgIC8vIHNsaWNlIG9mZiB0aGUgRXJyb3I6IC4uLiBsaW5lXG4gICAgICAgICAgaWYgKHR5cGVvZiBkdW1teVN0YWNrID09PSAnc3RyaW5nJykge1xuICAgICAgICAgICAgY29uc3QgZmlyc3ROZXdsaW5lSW5kZXggPSBkdW1teVN0YWNrLmluZGV4T2YoJ1xcbicpO1xuXG4gICAgICAgICAgICBzdGFjayA9IGZpcnN0TmV3bGluZUluZGV4ID09PSAtMSA/ICcnIDogZHVtbXlTdGFjay5zbGljZShmaXJzdE5ld2xpbmVJbmRleCArIDEpO1xuICAgICAgICAgIH1cblxuICAgICAgICAgIGlmICghZXJyLnN0YWNrKSB7XG4gICAgICAgICAgICBlcnIuc3RhY2sgPSBzdGFjaztcbiAgICAgICAgICB9IGVsc2UgaWYgKHN0YWNrKSB7XG4gICAgICAgICAgICAvLyBNYXRjaCBhIGNvbW1vbiBzdWZmaXggYWZ0ZXIgdGhlIDIgdG9wIGZyYW1lcyB3aGVuIGF2YWlsYWJsZSxcbiAgICAgICAgICAgIC8vIG90aGVyd2lzZSBjb21wYXJlIHRoZSBmdWxsIHJlY29uc3RydWN0ZWQgc3RhY2suXG4gICAgICAgICAgICBjb25zdCBmaXJzdE5ld2xpbmVJbmRleCA9IHN0YWNrLmluZGV4T2YoJ1xcbicpO1xuICAgICAgICAgICAgY29uc3Qgc2Vjb25kTmV3bGluZUluZGV4ID1cbiAgICAgICAgICAgICAgZmlyc3ROZXdsaW5lSW5kZXggPT09IC0xID8gLTEgOiBzdGFjay5pbmRleE9mKCdcXG4nLCBmaXJzdE5ld2xpbmVJbmRleCArIDEpO1xuICAgICAgICAgICAgY29uc3QgZHVwbGljYXRlQ2hlY2tTdWZmaXggPVxuICAgICAgICAgICAgICBzZWNvbmROZXdsaW5lSW5kZXggPT09IC0xID8gc3RhY2sgOiBzdGFjay5zbGljZShzZWNvbmROZXdsaW5lSW5kZXggKyAxKTtcblxuICAgICAgICAgICAgLy8gYEF4aW9zRXJyb3IuZnJvbSgpYCBtYXkgaGF2ZSBhbHJlYWR5IGlubGluZWQgdGhlIHdyYXBwZWQgZXJyb3Inc1xuICAgICAgICAgICAgLy8gc3RhY2sgdW5kZXIgYSBgQ2F1c2VkIGJ5OmAgbWFya2VyLiBLZWVwIHRoZSByZWNvbnN0cnVjdGVkIGNhbGxlclxuICAgICAgICAgICAgLy8gZnJhbWVzIGFoZWFkIG9mIHRoYXQgbWFya2VyIHNvIHN0YWNrLW9ubHkgcmVwb3J0ZXJzIGRvIG5vdCByZWFkXG4gICAgICAgICAgICAvLyB0aGVtIGFzIHBhcnQgb2YgdGhlIGxvdy1sZXZlbCBjYXVzZS5cbiAgICAgICAgICAgIGNvbnN0IGN1cnJlbnRTdGFjayA9IFN0cmluZyhlcnIuc3RhY2spO1xuICAgICAgICAgICAgY29uc3QgY2F1c2VJbmRleCA9IGdldENhdXNlU3RhY2tJbmRleChlcnIsIGN1cnJlbnRTdGFjayk7XG4gICAgICAgICAgICBjb25zdCBzdGFja0hlYWQgPSBjYXVzZUluZGV4ID09PSAtMSA/IGN1cnJlbnRTdGFjayA6IGN1cnJlbnRTdGFjay5zbGljZSgwLCBjYXVzZUluZGV4KTtcbiAgICAgICAgICAgIGNvbnN0IGNhdXNlU2VjdGlvbiA9IGNhdXNlSW5kZXggPT09IC0xID8gJycgOiBjdXJyZW50U3RhY2suc2xpY2UoY2F1c2VJbmRleCk7XG5cbiAgICAgICAgICAgIGlmICghc3RhY2tIZWFkLmVuZHNXaXRoKGR1cGxpY2F0ZUNoZWNrU3VmZml4KSkge1xuICAgICAgICAgICAgICBlcnIuc3RhY2sgPSBzdGFja0hlYWQgKyAnXFxuJyArIHN0YWNrICsgY2F1c2VTZWN0aW9uO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICAgIC8vIElnbm9yZSBmYWlsdXJlcyBmcm9tIGN1c3RvbSBzdGFjayBob29rcyBvciB1bi13cml0YWJsZSBzdGFjayBwcm9wZXJ0aWVzLlxuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgIHRocm93IGVycjtcbiAgICB9XG4gIH1cblxuICBfcmVxdWVzdChjb25maWdPclVybCwgY29uZmlnKSB7XG4gICAgLyplc2xpbnQgbm8tcGFyYW0tcmVhc3NpZ246MCovXG4gICAgLy8gQWxsb3cgZm9yIGF4aW9zKCdleGFtcGxlL3VybCdbLCBjb25maWddKSBhIGxhIGZldGNoIEFQSVxuICAgIGlmICh0eXBlb2YgY29uZmlnT3JVcmwgPT09ICdzdHJpbmcnKSB7XG4gICAgICBjb25maWcgPSBjb25maWcgfHwge307XG4gICAgICBjb25maWcudXJsID0gY29uZmlnT3JVcmw7XG4gICAgfSBlbHNlIHtcbiAgICAgIGNvbmZpZyA9IGNvbmZpZ09yVXJsIHx8IHt9O1xuICAgIH1cblxuICAgIGNvbmZpZyA9IG1lcmdlQ29uZmlnKHRoaXMuZGVmYXVsdHMsIGNvbmZpZyk7XG5cbiAgICBjb25zdCB7IHRyYW5zaXRpb25hbCwgcGFyYW1zU2VyaWFsaXplciwgaGVhZGVycyB9ID0gY29uZmlnO1xuXG4gICAgaWYgKHRyYW5zaXRpb25hbCAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICB2YWxpZGF0b3IuYXNzZXJ0T3B0aW9ucyhcbiAgICAgICAgdHJhbnNpdGlvbmFsLFxuICAgICAgICB7XG4gICAgICAgICAgc2lsZW50SlNPTlBhcnNpbmc6IHZhbGlkYXRvcnMudHJhbnNpdGlvbmFsKHZhbGlkYXRvcnMuYm9vbGVhbiksXG4gICAgICAgICAgZm9yY2VkSlNPTlBhcnNpbmc6IHZhbGlkYXRvcnMudHJhbnNpdGlvbmFsKHZhbGlkYXRvcnMuYm9vbGVhbiksXG4gICAgICAgICAgY2xhcmlmeVRpbWVvdXRFcnJvcjogdmFsaWRhdG9ycy50cmFuc2l0aW9uYWwodmFsaWRhdG9ycy5ib29sZWFuKSxcbiAgICAgICAgICBsZWdhY3lJbnRlcmNlcHRvclJlcVJlc09yZGVyaW5nOiB2YWxpZGF0b3JzLnRyYW5zaXRpb25hbCh2YWxpZGF0b3JzLmJvb2xlYW4pLFxuICAgICAgICAgIGFkdmVydGlzZVpzdGRBY2NlcHRFbmNvZGluZzogdmFsaWRhdG9ycy50cmFuc2l0aW9uYWwodmFsaWRhdG9ycy5ib29sZWFuKSxcbiAgICAgICAgICB2YWxpZGF0ZVN0YXR1c1VuZGVmaW5lZFJlc29sdmVzOiB2YWxpZGF0b3JzLnRyYW5zaXRpb25hbCh2YWxpZGF0b3JzLmJvb2xlYW4pLFxuICAgICAgICAgIGVuY29kZUJhc2ljQXV0aFVzZXJuYW1lOiB2YWxpZGF0b3JzLnRyYW5zaXRpb25hbCh2YWxpZGF0b3JzLmJvb2xlYW4pLFxuICAgICAgICB9LFxuICAgICAgICBmYWxzZVxuICAgICAgKTtcbiAgICB9XG5cbiAgICBpZiAocGFyYW1zU2VyaWFsaXplciAhPSBudWxsKSB7XG4gICAgICBpZiAodXRpbHMuaXNGdW5jdGlvbihwYXJhbXNTZXJpYWxpemVyKSkge1xuICAgICAgICBjb25maWcucGFyYW1zU2VyaWFsaXplciA9IHtcbiAgICAgICAgICBzZXJpYWxpemU6IHBhcmFtc1NlcmlhbGl6ZXIsXG4gICAgICAgIH07XG4gICAgICB9IGVsc2Uge1xuICAgICAgICB2YWxpZGF0b3IuYXNzZXJ0T3B0aW9ucyhcbiAgICAgICAgICBwYXJhbXNTZXJpYWxpemVyLFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIGVuY29kZTogdmFsaWRhdG9ycy5mdW5jdGlvbixcbiAgICAgICAgICAgIHNlcmlhbGl6ZTogdmFsaWRhdG9ycy5mdW5jdGlvbixcbiAgICAgICAgICB9LFxuICAgICAgICAgIHRydWVcbiAgICAgICAgKTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICAvLyBTZXQgY29uZmlnLmFsbG93QWJzb2x1dGVVcmxzXG4gICAgaWYgKGNvbmZpZy5hbGxvd0Fic29sdXRlVXJscyAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAvLyBkbyBub3RoaW5nXG4gICAgfSBlbHNlIGlmIChcbiAgICAgIHV0aWxzLmhhc093blByb3AodGhpcy5kZWZhdWx0cywgJ2FsbG93QWJzb2x1dGVVcmxzJykgJiZcbiAgICAgIHRoaXMuZGVmYXVsdHMuYWxsb3dBYnNvbHV0ZVVybHMgIT09IHVuZGVmaW5lZFxuICAgICkge1xuICAgICAgY29uZmlnLmFsbG93QWJzb2x1dGVVcmxzID0gdGhpcy5kZWZhdWx0cy5hbGxvd0Fic29sdXRlVXJscztcbiAgICB9IGVsc2Uge1xuICAgICAgY29uZmlnLmFsbG93QWJzb2x1dGVVcmxzID0gdHJ1ZTtcbiAgICB9XG5cbiAgICB2YWxpZGF0b3IuYXNzZXJ0T3B0aW9ucyhcbiAgICAgIGNvbmZpZyxcbiAgICAgIHtcbiAgICAgICAgYmFzZVVybDogdmFsaWRhdG9ycy5zcGVsbGluZygnYmFzZVVSTCcpLFxuICAgICAgICB3aXRoWHNyZlRva2VuOiB2YWxpZGF0b3JzLnNwZWxsaW5nKCd3aXRoWFNSRlRva2VuJyksXG4gICAgICB9LFxuICAgICAgdHJ1ZVxuICAgICk7XG5cbiAgICAvLyBTZXQgY29uZmlnLm1ldGhvZFxuICAgIGNvbmZpZy5tZXRob2QgPSAoXG4gICAgICB1dGlscy5nZXRTYWZlUHJvcChjb25maWcsICdtZXRob2QnKSB8fFxuICAgICAgdXRpbHMuZ2V0U2FmZVByb3AodGhpcy5kZWZhdWx0cywgJ21ldGhvZCcpIHx8XG4gICAgICAnZ2V0J1xuICAgICkudG9Mb3dlckNhc2UoKTtcblxuICAgIC8vIEZsYXR0ZW4gaGVhZGVyIGRlZmF1bHRzIHdpdGhvdXQgY29uc3VtaW5nIGxpdGVyYWwgbWV0aG9kLW5hbWVkIGhlYWRlcnMuXG4gICAgY29uc3QgY29tbW9uSGVhZGVycyA9IHV0aWxzLmdldFNhZmVQcm9wKGhlYWRlcnMsICdjb21tb24nKTtcbiAgICBjb25zdCBtZXRob2RIZWFkZXJzID0gdXRpbHMuZ2V0U2FmZVByb3AoaGVhZGVycywgY29uZmlnLm1ldGhvZCk7XG4gICAgY29uc3QgY29udGV4dEhlYWRlcnMgPVxuICAgICAgaGVhZGVycyAmJlxuICAgICAgdXRpbHMubWVyZ2UoXG4gICAgICAgIGlzSGVhZGVyc0J1Y2tldChjb21tb25IZWFkZXJzKSA/IGNvbW1vbkhlYWRlcnMgOiB1bmRlZmluZWQsXG4gICAgICAgIGlzSGVhZGVyc0J1Y2tldChtZXRob2RIZWFkZXJzKSA/IG1ldGhvZEhlYWRlcnMgOiB1bmRlZmluZWRcbiAgICAgICk7XG5cbiAgICBoZWFkZXJzICYmXG4gICAgICB1dGlscy5mb3JFYWNoKG1ldGhvZExpc3QuY29uY2F0KCdjb21tb24nKSwgKG1ldGhvZCkgPT4ge1xuICAgICAgICBpZiAoaXNIZWFkZXJzQnVja2V0KHV0aWxzLmdldFNhZmVQcm9wKGhlYWRlcnMsIG1ldGhvZCkpKSB7XG4gICAgICAgICAgZGVsZXRlIGhlYWRlcnNbbWV0aG9kXTtcbiAgICAgICAgfVxuICAgICAgfSk7XG5cbiAgICBjb25maWcuaGVhZGVycyA9IEF4aW9zSGVhZGVycy5jb25jYXQoY29udGV4dEhlYWRlcnMsIGhlYWRlcnMpO1xuXG4gICAgLy8gZmlsdGVyIG91dCBza2lwcGVkIGludGVyY2VwdG9yc1xuICAgIGNvbnN0IHJlcXVlc3RJbnRlcmNlcHRvckNoYWluID0gW107XG4gICAgbGV0IHN5bmNocm9ub3VzUmVxdWVzdEludGVyY2VwdG9ycyA9IHRydWU7XG4gICAgdGhpcy5pbnRlcmNlcHRvcnMucmVxdWVzdC5mb3JFYWNoKGZ1bmN0aW9uIHVuc2hpZnRSZXF1ZXN0SW50ZXJjZXB0b3JzKGludGVyY2VwdG9yKSB7XG4gICAgICBpZiAodHlwZW9mIGludGVyY2VwdG9yLnJ1bldoZW4gPT09ICdmdW5jdGlvbicgJiYgaW50ZXJjZXB0b3IucnVuV2hlbihjb25maWcpID09PSBmYWxzZSkge1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG5cbiAgICAgIHN5bmNocm9ub3VzUmVxdWVzdEludGVyY2VwdG9ycyA9IHN5bmNocm9ub3VzUmVxdWVzdEludGVyY2VwdG9ycyAmJiBpbnRlcmNlcHRvci5zeW5jaHJvbm91cztcblxuICAgICAgY29uc3QgdHJhbnNpdGlvbmFsID0gY29uZmlnLnRyYW5zaXRpb25hbCB8fCB0cmFuc2l0aW9uYWxEZWZhdWx0cztcbiAgICAgIGNvbnN0IGxlZ2FjeUludGVyY2VwdG9yUmVxUmVzT3JkZXJpbmcgPVxuICAgICAgICB0cmFuc2l0aW9uYWwgJiYgdHJhbnNpdGlvbmFsLmxlZ2FjeUludGVyY2VwdG9yUmVxUmVzT3JkZXJpbmc7XG5cbiAgICAgIGlmIChsZWdhY3lJbnRlcmNlcHRvclJlcVJlc09yZGVyaW5nKSB7XG4gICAgICAgIHJlcXVlc3RJbnRlcmNlcHRvckNoYWluLnVuc2hpZnQoaW50ZXJjZXB0b3IuZnVsZmlsbGVkLCBpbnRlcmNlcHRvci5yZWplY3RlZCk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICByZXF1ZXN0SW50ZXJjZXB0b3JDaGFpbi5wdXNoKGludGVyY2VwdG9yLmZ1bGZpbGxlZCwgaW50ZXJjZXB0b3IucmVqZWN0ZWQpO1xuICAgICAgfVxuICAgIH0pO1xuXG4gICAgY29uc3QgcmVzcG9uc2VJbnRlcmNlcHRvckNoYWluID0gW107XG4gICAgdGhpcy5pbnRlcmNlcHRvcnMucmVzcG9uc2UuZm9yRWFjaChmdW5jdGlvbiBwdXNoUmVzcG9uc2VJbnRlcmNlcHRvcnMoaW50ZXJjZXB0b3IpIHtcbiAgICAgIHJlc3BvbnNlSW50ZXJjZXB0b3JDaGFpbi5wdXNoKGludGVyY2VwdG9yLmZ1bGZpbGxlZCwgaW50ZXJjZXB0b3IucmVqZWN0ZWQpO1xuICAgIH0pO1xuXG4gICAgbGV0IHByb21pc2U7XG4gICAgbGV0IGkgPSAwO1xuICAgIGxldCBsZW47XG5cbiAgICBpZiAoIXN5bmNocm9ub3VzUmVxdWVzdEludGVyY2VwdG9ycykge1xuICAgICAgY29uc3QgY2hhaW4gPSBbZGlzcGF0Y2hSZXF1ZXN0LmJpbmQodGhpcyksIHVuZGVmaW5lZF07XG4gICAgICBjaGFpbi51bnNoaWZ0KC4uLnJlcXVlc3RJbnRlcmNlcHRvckNoYWluKTtcbiAgICAgIGNoYWluLnB1c2goLi4ucmVzcG9uc2VJbnRlcmNlcHRvckNoYWluKTtcbiAgICAgIGxlbiA9IGNoYWluLmxlbmd0aDtcblxuICAgICAgcHJvbWlzZSA9IFByb21pc2UucmVzb2x2ZShjb25maWcpO1xuXG4gICAgICB3aGlsZSAoaSA8IGxlbikge1xuICAgICAgICBwcm9taXNlID0gcHJvbWlzZS50aGVuKGNoYWluW2krK10sIGNoYWluW2krK10pO1xuICAgICAgfVxuXG4gICAgICByZXR1cm4gcHJvbWlzZTtcbiAgICB9XG5cbiAgICBsZW4gPSByZXF1ZXN0SW50ZXJjZXB0b3JDaGFpbi5sZW5ndGg7XG5cbiAgICBsZXQgbmV3Q29uZmlnID0gY29uZmlnO1xuXG4gICAgd2hpbGUgKGkgPCBsZW4pIHtcbiAgICAgIGNvbnN0IG9uRnVsZmlsbGVkID0gcmVxdWVzdEludGVyY2VwdG9yQ2hhaW5baSsrXTtcbiAgICAgIGNvbnN0IG9uUmVqZWN0ZWQgPSByZXF1ZXN0SW50ZXJjZXB0b3JDaGFpbltpKytdO1xuICAgICAgdHJ5IHtcbiAgICAgICAgbmV3Q29uZmlnID0gb25GdWxmaWxsZWQgPyBvbkZ1bGZpbGxlZChuZXdDb25maWcpIDogbmV3Q29uZmlnO1xuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgaWYgKCFvblJlamVjdGVkKSB7XG4gICAgICAgICAgcHJvbWlzZSA9IFByb21pc2UucmVqZWN0KGVycm9yKTtcbiAgICAgICAgICBicmVhaztcbiAgICAgICAgfVxuXG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgY29uc3QgcmVqZWN0ZWRSZXN1bHQgPSBvblJlamVjdGVkLmNhbGwodGhpcywgZXJyb3IpO1xuXG4gICAgICAgICAgaWYgKHV0aWxzLmlzVGhlbmFibGUocmVqZWN0ZWRSZXN1bHQpKSB7XG4gICAgICAgICAgICBwcm9taXNlID0gUHJvbWlzZS5yZXNvbHZlKHJlamVjdGVkUmVzdWx0KS50aGVuKCgpID0+XG4gICAgICAgICAgICAgIGRpc3BhdGNoUmVxdWVzdC5jYWxsKHRoaXMsIG5ld0NvbmZpZylcbiAgICAgICAgICAgICk7XG4gICAgICAgICAgfVxuICAgICAgICB9IGNhdGNoIChyZWplY3RlZEVycm9yKSB7XG4gICAgICAgICAgcHJvbWlzZSA9IFByb21pc2UucmVqZWN0KHJlamVjdGVkRXJyb3IpO1xuICAgICAgICB9XG5cbiAgICAgICAgYnJlYWs7XG4gICAgICB9XG4gICAgfVxuXG4gICAgaWYgKCFwcm9taXNlKSB7XG4gICAgICB0cnkge1xuICAgICAgICBwcm9taXNlID0gZGlzcGF0Y2hSZXF1ZXN0LmNhbGwodGhpcywgbmV3Q29uZmlnKTtcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIHByb21pc2UgPSBQcm9taXNlLnJlamVjdChlcnJvcik7XG4gICAgICB9XG4gICAgfVxuXG4gICAgaSA9IDA7XG4gICAgbGVuID0gcmVzcG9uc2VJbnRlcmNlcHRvckNoYWluLmxlbmd0aDtcblxuICAgIHdoaWxlIChpIDwgbGVuKSB7XG4gICAgICBwcm9taXNlID0gcHJvbWlzZS50aGVuKHJlc3BvbnNlSW50ZXJjZXB0b3JDaGFpbltpKytdLCByZXNwb25zZUludGVyY2VwdG9yQ2hhaW5baSsrXSk7XG4gICAgfVxuXG4gICAgcmV0dXJuIHByb21pc2U7XG4gIH1cblxuICBnZXRVcmkoY29uZmlnKSB7XG4gICAgY29uZmlnID0gbWVyZ2VDb25maWcodGhpcy5kZWZhdWx0cywgY29uZmlnKTtcbiAgICBjb25zdCBmdWxsUGF0aCA9IGJ1aWxkRnVsbFBhdGgoY29uZmlnLmJhc2VVUkwsIGNvbmZpZy51cmwsIGNvbmZpZy5hbGxvd0Fic29sdXRlVXJscywgY29uZmlnKTtcbiAgICByZXR1cm4gYnVpbGRVUkwoZnVsbFBhdGgsIGNvbmZpZy5wYXJhbXMsIGNvbmZpZy5wYXJhbXNTZXJpYWxpemVyKTtcbiAgfVxufVxuXG4vLyBQcm92aWRlIGFsaWFzZXMgZm9yIHN1cHBvcnRlZCByZXF1ZXN0IG1ldGhvZHNcbnV0aWxzLmZvckVhY2goWydkZWxldGUnLCAnZ2V0JywgJ2hlYWQnLCAnb3B0aW9ucyddLCBmdW5jdGlvbiBmb3JFYWNoTWV0aG9kTm9EYXRhKG1ldGhvZCkge1xuICAvKmVzbGludCBmdW5jLW5hbWVzOjAqL1xuICBBeGlvcy5wcm90b3R5cGVbbWV0aG9kXSA9IGFzeW5jIGZ1bmN0aW9uICh1cmwsIGNvbmZpZykge1xuICAgIHJldHVybiB0aGlzLnJlcXVlc3QoXG4gICAgICBtZXJnZUNvbmZpZyhjb25maWcgfHwge30sIHtcbiAgICAgICAgbWV0aG9kLFxuICAgICAgICB1cmwsXG4gICAgICAgIGRhdGE6IGNvbmZpZyAmJiB1dGlscy5oYXNPd25Qcm9wKGNvbmZpZywgJ2RhdGEnKSA/IGNvbmZpZy5kYXRhIDogdW5kZWZpbmVkLFxuICAgICAgfSlcbiAgICApO1xuICB9O1xufSk7XG5cbnV0aWxzLmZvckVhY2goWydwb3N0JywgJ3B1dCcsICdwYXRjaCcsICdxdWVyeSddLCBmdW5jdGlvbiBmb3JFYWNoTWV0aG9kV2l0aERhdGEobWV0aG9kKSB7XG4gIGZ1bmN0aW9uIGdlbmVyYXRlSFRUUE1ldGhvZChpc0Zvcm0pIHtcbiAgICByZXR1cm4gYXN5bmMgZnVuY3Rpb24gaHR0cE1ldGhvZCh1cmwsIGRhdGEsIGNvbmZpZykge1xuICAgICAgcmV0dXJuIHRoaXMucmVxdWVzdChcbiAgICAgICAgbWVyZ2VDb25maWcoY29uZmlnIHx8IHt9LCB7XG4gICAgICAgICAgbWV0aG9kLFxuICAgICAgICAgIGhlYWRlcnM6IGlzRm9ybVxuICAgICAgICAgICAgPyB7XG4gICAgICAgICAgICAgICAgJ0NvbnRlbnQtVHlwZSc6ICdtdWx0aXBhcnQvZm9ybS1kYXRhJyxcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgOiB7fSxcbiAgICAgICAgICB1cmwsXG4gICAgICAgICAgZGF0YSxcbiAgICAgICAgfSlcbiAgICAgICk7XG4gICAgfTtcbiAgfVxuXG4gIEF4aW9zLnByb3RvdHlwZVttZXRob2RdID0gZ2VuZXJhdGVIVFRQTWV0aG9kKCk7XG5cbiAgLy8gUVVFUlkgaXMgYSBzYWZlL2lkZW1wb3RlbnQgcmVhZCBtZXRob2Q7IG11bHRpcGFydCBmb3JtIGJvZGllcyBkb24ndCBmaXRcbiAgLy8gaXRzIHNlbWFudGljcywgc28gbm8gcXVlcnlGb3JtIHNob3J0aGFuZCBpcyBnZW5lcmF0ZWQuXG4gIGlmIChtZXRob2QgIT09ICdxdWVyeScpIHtcbiAgICBBeGlvcy5wcm90b3R5cGVbbWV0aG9kICsgJ0Zvcm0nXSA9IGdlbmVyYXRlSFRUUE1ldGhvZCh0cnVlKTtcbiAgfVxufSk7XG5cbmV4cG9ydCBkZWZhdWx0IEF4aW9zO1xuIiwiJ3VzZSBzdHJpY3QnO1xuXG5pbXBvcnQgQ2FuY2VsZWRFcnJvciBmcm9tICcuL0NhbmNlbGVkRXJyb3IuanMnO1xuXG4vKipcbiAqIEEgYENhbmNlbFRva2VuYCBpcyBhbiBvYmplY3QgdGhhdCBjYW4gYmUgdXNlZCB0byByZXF1ZXN0IGNhbmNlbGxhdGlvbiBvZiBhbiBvcGVyYXRpb24uXG4gKlxuICogQHBhcmFtIHtGdW5jdGlvbn0gZXhlY3V0b3IgVGhlIGV4ZWN1dG9yIGZ1bmN0aW9uLlxuICpcbiAqIEByZXR1cm5zIHtDYW5jZWxUb2tlbn1cbiAqL1xuY2xhc3MgQ2FuY2VsVG9rZW4ge1xuICBjb25zdHJ1Y3RvcihleGVjdXRvcikge1xuICAgIGlmICh0eXBlb2YgZXhlY3V0b3IgIT09ICdmdW5jdGlvbicpIHtcbiAgICAgIHRocm93IG5ldyBUeXBlRXJyb3IoJ2V4ZWN1dG9yIG11c3QgYmUgYSBmdW5jdGlvbi4nKTtcbiAgICB9XG5cbiAgICBsZXQgcmVzb2x2ZVByb21pc2U7XG5cbiAgICB0aGlzLnByb21pc2UgPSBuZXcgUHJvbWlzZShmdW5jdGlvbiBwcm9taXNlRXhlY3V0b3IocmVzb2x2ZSkge1xuICAgICAgcmVzb2x2ZVByb21pc2UgPSByZXNvbHZlO1xuICAgIH0pO1xuXG4gICAgY29uc3QgdG9rZW4gPSB0aGlzO1xuXG4gICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIGZ1bmMtbmFtZXNcbiAgICB0aGlzLnByb21pc2UudGhlbigoY2FuY2VsKSA9PiB7XG4gICAgICBpZiAoIXRva2VuLl9saXN0ZW5lcnMpIHJldHVybjtcblxuICAgICAgbGV0IGkgPSB0b2tlbi5fbGlzdGVuZXJzLmxlbmd0aDtcblxuICAgICAgd2hpbGUgKGktLSA+IDApIHtcbiAgICAgICAgdG9rZW4uX2xpc3RlbmVyc1tpXShjYW5jZWwpO1xuICAgICAgfVxuICAgICAgdG9rZW4uX2xpc3RlbmVycyA9IG51bGw7XG4gICAgfSk7XG5cbiAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgZnVuYy1uYW1lc1xuICAgIHRoaXMucHJvbWlzZS50aGVuID0gKG9uZnVsZmlsbGVkKSA9PiB7XG4gICAgICBsZXQgX3Jlc29sdmU7XG4gICAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgZnVuYy1uYW1lc1xuICAgICAgY29uc3QgcHJvbWlzZSA9IG5ldyBQcm9taXNlKChyZXNvbHZlKSA9PiB7XG4gICAgICAgIHRva2VuLnN1YnNjcmliZShyZXNvbHZlKTtcbiAgICAgICAgX3Jlc29sdmUgPSByZXNvbHZlO1xuICAgICAgfSkudGhlbihvbmZ1bGZpbGxlZCk7XG5cbiAgICAgIHByb21pc2UuY2FuY2VsID0gZnVuY3Rpb24gcmVqZWN0KCkge1xuICAgICAgICB0b2tlbi51bnN1YnNjcmliZShfcmVzb2x2ZSk7XG4gICAgICB9O1xuXG4gICAgICByZXR1cm4gcHJvbWlzZTtcbiAgICB9O1xuXG4gICAgZXhlY3V0b3IoZnVuY3Rpb24gY2FuY2VsKG1lc3NhZ2UsIGNvbmZpZywgcmVxdWVzdCkge1xuICAgICAgaWYgKHRva2VuLnJlYXNvbikge1xuICAgICAgICAvLyBDYW5jZWxsYXRpb24gaGFzIGFscmVhZHkgYmVlbiByZXF1ZXN0ZWRcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuXG4gICAgICB0b2tlbi5yZWFzb24gPSBuZXcgQ2FuY2VsZWRFcnJvcihtZXNzYWdlLCBjb25maWcsIHJlcXVlc3QpO1xuICAgICAgcmVzb2x2ZVByb21pc2UodG9rZW4ucmVhc29uKTtcbiAgICB9KTtcbiAgfVxuXG4gIC8qKlxuICAgKiBUaHJvd3MgYSBgQ2FuY2VsZWRFcnJvcmAgaWYgY2FuY2VsbGF0aW9uIGhhcyBiZWVuIHJlcXVlc3RlZC5cbiAgICovXG4gIHRocm93SWZSZXF1ZXN0ZWQoKSB7XG4gICAgaWYgKHRoaXMucmVhc29uKSB7XG4gICAgICB0aHJvdyB0aGlzLnJlYXNvbjtcbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogU3Vic2NyaWJlIHRvIHRoZSBjYW5jZWwgc2lnbmFsXG4gICAqL1xuXG4gIHN1YnNjcmliZShsaXN0ZW5lcikge1xuICAgIGlmICh0aGlzLnJlYXNvbikge1xuICAgICAgbGlzdGVuZXIodGhpcy5yZWFzb24pO1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIGlmICh0aGlzLl9saXN0ZW5lcnMpIHtcbiAgICAgIHRoaXMuX2xpc3RlbmVycy5wdXNoKGxpc3RlbmVyKTtcbiAgICB9IGVsc2Uge1xuICAgICAgdGhpcy5fbGlzdGVuZXJzID0gW2xpc3RlbmVyXTtcbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogVW5zdWJzY3JpYmUgZnJvbSB0aGUgY2FuY2VsIHNpZ25hbFxuICAgKi9cblxuICB1bnN1YnNjcmliZShsaXN0ZW5lcikge1xuICAgIGlmICghdGhpcy5fbGlzdGVuZXJzKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGNvbnN0IGluZGV4ID0gdGhpcy5fbGlzdGVuZXJzLmluZGV4T2YobGlzdGVuZXIpO1xuICAgIGlmIChpbmRleCAhPT0gLTEpIHtcbiAgICAgIHRoaXMuX2xpc3RlbmVycy5zcGxpY2UoaW5kZXgsIDEpO1xuICAgIH1cbiAgfVxuXG4gIHRvQWJvcnRTaWduYWwoKSB7XG4gICAgY29uc3QgY29udHJvbGxlciA9IG5ldyBBYm9ydENvbnRyb2xsZXIoKTtcblxuICAgIGNvbnN0IGFib3J0ID0gKGVycikgPT4ge1xuICAgICAgY29udHJvbGxlci5hYm9ydChlcnIpO1xuICAgIH07XG5cbiAgICB0aGlzLnN1YnNjcmliZShhYm9ydCk7XG5cbiAgICBjb250cm9sbGVyLnNpZ25hbC51bnN1YnNjcmliZSA9ICgpID0+IHRoaXMudW5zdWJzY3JpYmUoYWJvcnQpO1xuXG4gICAgcmV0dXJuIGNvbnRyb2xsZXIuc2lnbmFsO1xuICB9XG5cbiAgLyoqXG4gICAqIFJldHVybnMgYW4gb2JqZWN0IHRoYXQgY29udGFpbnMgYSBuZXcgYENhbmNlbFRva2VuYCBhbmQgYSBmdW5jdGlvbiB0aGF0LCB3aGVuIGNhbGxlZCxcbiAgICogY2FuY2VscyB0aGUgYENhbmNlbFRva2VuYC5cbiAgICovXG4gIHN0YXRpYyBzb3VyY2UoKSB7XG4gICAgbGV0IGNhbmNlbDtcbiAgICBjb25zdCB0b2tlbiA9IG5ldyBDYW5jZWxUb2tlbihmdW5jdGlvbiBleGVjdXRvcihjKSB7XG4gICAgICBjYW5jZWwgPSBjO1xuICAgIH0pO1xuICAgIHJldHVybiB7XG4gICAgICB0b2tlbixcbiAgICAgIGNhbmNlbCxcbiAgICB9O1xuICB9XG59XG5cbmV4cG9ydCBkZWZhdWx0IENhbmNlbFRva2VuO1xuIiwiJ3VzZSBzdHJpY3QnO1xuXG4vKipcbiAqIFN5bnRhY3RpYyBzdWdhciBmb3IgaW52b2tpbmcgYSBmdW5jdGlvbiBhbmQgZXhwYW5kaW5nIGFuIGFycmF5IGZvciBhcmd1bWVudHMuXG4gKlxuICogQ29tbW9uIHVzZSBjYXNlIHdvdWxkIGJlIHRvIHVzZSBgRnVuY3Rpb24ucHJvdG90eXBlLmFwcGx5YC5cbiAqXG4gKiAgYGBganNcbiAqICBmdW5jdGlvbiBmKHgsIHksIHopIHt9XG4gKiAgY29uc3QgYXJncyA9IFsxLCAyLCAzXTtcbiAqICBmLmFwcGx5KG51bGwsIGFyZ3MpO1xuICogIGBgYFxuICpcbiAqIFdpdGggYHNwcmVhZGAgdGhpcyBleGFtcGxlIGNhbiBiZSByZS13cml0dGVuLlxuICpcbiAqICBgYGBqc1xuICogIHNwcmVhZChmdW5jdGlvbih4LCB5LCB6KSB7fSkoWzEsIDIsIDNdKTtcbiAqICBgYGBcbiAqXG4gKiBAcGFyYW0ge0Z1bmN0aW9ufSBjYWxsYmFja1xuICpcbiAqIEByZXR1cm5zIHtGdW5jdGlvbn1cbiAqL1xuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gc3ByZWFkKGNhbGxiYWNrKSB7XG4gIHJldHVybiBmdW5jdGlvbiB3cmFwKGFycikge1xuICAgIHJldHVybiBjYWxsYmFjay5hcHBseShudWxsLCBhcnIpO1xuICB9O1xufVxuIiwiJ3VzZSBzdHJpY3QnO1xuXG5pbXBvcnQgdXRpbHMgZnJvbSAnLi4vdXRpbHMuanMnO1xuXG4vKipcbiAqIERldGVybWluZXMgd2hldGhlciB0aGUgcGF5bG9hZCBpcyBhbiBlcnJvciB0aHJvd24gYnkgQXhpb3NcbiAqXG4gKiBAcGFyYW0geyp9IHBheWxvYWQgVGhlIHZhbHVlIHRvIHRlc3RcbiAqXG4gKiBAcmV0dXJucyB7Ym9vbGVhbn0gVHJ1ZSBpZiB0aGUgcGF5bG9hZCBpcyBhbiBlcnJvciB0aHJvd24gYnkgQXhpb3MsIG90aGVyd2lzZSBmYWxzZVxuICovXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBpc0F4aW9zRXJyb3IocGF5bG9hZCkge1xuICByZXR1cm4gdXRpbHMuaXNPYmplY3QocGF5bG9hZCkgJiYgcGF5bG9hZC5pc0F4aW9zRXJyb3IgPT09IHRydWU7XG59XG4iLCJjb25zdCBIdHRwU3RhdHVzQ29kZSA9IHtcbiAgQ29udGludWU6IDEwMCxcbiAgU3dpdGNoaW5nUHJvdG9jb2xzOiAxMDEsXG4gIFByb2Nlc3Npbmc6IDEwMixcbiAgRWFybHlIaW50czogMTAzLFxuICBPazogMjAwLFxuICBDcmVhdGVkOiAyMDEsXG4gIEFjY2VwdGVkOiAyMDIsXG4gIE5vbkF1dGhvcml0YXRpdmVJbmZvcm1hdGlvbjogMjAzLFxuICBOb0NvbnRlbnQ6IDIwNCxcbiAgUmVzZXRDb250ZW50OiAyMDUsXG4gIFBhcnRpYWxDb250ZW50OiAyMDYsXG4gIE11bHRpU3RhdHVzOiAyMDcsXG4gIEFscmVhZHlSZXBvcnRlZDogMjA4LFxuICBJbVVzZWQ6IDIyNixcbiAgTXVsdGlwbGVDaG9pY2VzOiAzMDAsXG4gIE1vdmVkUGVybWFuZW50bHk6IDMwMSxcbiAgRm91bmQ6IDMwMixcbiAgU2VlT3RoZXI6IDMwMyxcbiAgTm90TW9kaWZpZWQ6IDMwNCxcbiAgVXNlUHJveHk6IDMwNSxcbiAgVW51c2VkOiAzMDYsXG4gIFRlbXBvcmFyeVJlZGlyZWN0OiAzMDcsXG4gIFBlcm1hbmVudFJlZGlyZWN0OiAzMDgsXG4gIEJhZFJlcXVlc3Q6IDQwMCxcbiAgVW5hdXRob3JpemVkOiA0MDEsXG4gIFBheW1lbnRSZXF1aXJlZDogNDAyLFxuICBGb3JiaWRkZW46IDQwMyxcbiAgTm90Rm91bmQ6IDQwNCxcbiAgTWV0aG9kTm90QWxsb3dlZDogNDA1LFxuICBOb3RBY2NlcHRhYmxlOiA0MDYsXG4gIFByb3h5QXV0aGVudGljYXRpb25SZXF1aXJlZDogNDA3LFxuICBSZXF1ZXN0VGltZW91dDogNDA4LFxuICBDb25mbGljdDogNDA5LFxuICBHb25lOiA0MTAsXG4gIExlbmd0aFJlcXVpcmVkOiA0MTEsXG4gIFByZWNvbmRpdGlvbkZhaWxlZDogNDEyLFxuICAvKipcbiAgICogQGRlcHJlY2F0ZWQgVXNlIGBDb250ZW50VG9vTGFyZ2VgIGluc3RlYWQuXG4gICAqL1xuICBQYXlsb2FkVG9vTGFyZ2U6IDQxMyxcbiAgQ29udGVudFRvb0xhcmdlOiA0MTMsXG4gIFVyaVRvb0xvbmc6IDQxNCxcbiAgVW5zdXBwb3J0ZWRNZWRpYVR5cGU6IDQxNSxcbiAgUmFuZ2VOb3RTYXRpc2ZpYWJsZTogNDE2LFxuICBFeHBlY3RhdGlvbkZhaWxlZDogNDE3LFxuICBJbUFUZWFwb3Q6IDQxOCxcbiAgTWlzZGlyZWN0ZWRSZXF1ZXN0OiA0MjEsXG4gIC8qKlxuICAgKiBAZGVwcmVjYXRlZCBVc2UgYFVucHJvY2Vzc2FibGVDb250ZW50YCBpbnN0ZWFkLlxuICAgKi9cbiAgVW5wcm9jZXNzYWJsZUVudGl0eTogNDIyLFxuICBVbnByb2Nlc3NhYmxlQ29udGVudDogNDIyLFxuICBMb2NrZWQ6IDQyMyxcbiAgRmFpbGVkRGVwZW5kZW5jeTogNDI0LFxuICBUb29FYXJseTogNDI1LFxuICBVcGdyYWRlUmVxdWlyZWQ6IDQyNixcbiAgUHJlY29uZGl0aW9uUmVxdWlyZWQ6IDQyOCxcbiAgVG9vTWFueVJlcXVlc3RzOiA0MjksXG4gIFJlcXVlc3RIZWFkZXJGaWVsZHNUb29MYXJnZTogNDMxLFxuICBVbmF2YWlsYWJsZUZvckxlZ2FsUmVhc29uczogNDUxLFxuICBJbnRlcm5hbFNlcnZlckVycm9yOiA1MDAsXG4gIE5vdEltcGxlbWVudGVkOiA1MDEsXG4gIEJhZEdhdGV3YXk6IDUwMixcbiAgU2VydmljZVVuYXZhaWxhYmxlOiA1MDMsXG4gIEdhdGV3YXlUaW1lb3V0OiA1MDQsXG4gIEh0dHBWZXJzaW9uTm90U3VwcG9ydGVkOiA1MDUsXG4gIFZhcmlhbnRBbHNvTmVnb3RpYXRlczogNTA2LFxuICBJbnN1ZmZpY2llbnRTdG9yYWdlOiA1MDcsXG4gIExvb3BEZXRlY3RlZDogNTA4LFxuICBOb3RFeHRlbmRlZDogNTEwLFxuICBOZXR3b3JrQXV0aGVudGljYXRpb25SZXF1aXJlZDogNTExLFxuICBXZWJTZXJ2ZXJSZXR1cm5zQW5Vbmtub3duRXJyb3I6IDUyMCxcbiAgV2ViU2VydmVySXNEb3duOiA1MjEsXG4gIENvbm5lY3Rpb25UaW1lZE91dDogNTIyLFxuICBPcmlnaW5Jc1VucmVhY2hhYmxlOiA1MjMsXG4gIFRpbWVvdXRPY2N1cnJlZDogNTI0LFxuICBTc2xIYW5kc2hha2VGYWlsZWQ6IDUyNSxcbiAgSW52YWxpZFNzbENlcnRpZmljYXRlOiA1MjYsXG59O1xuXG5PYmplY3QuZW50cmllcyhIdHRwU3RhdHVzQ29kZSkuZm9yRWFjaCgoW2tleSwgdmFsdWVdKSA9PiB7XG4gIGlmIChIdHRwU3RhdHVzQ29kZVt2YWx1ZV0gPT09IHVuZGVmaW5lZCkge1xuICAgIEh0dHBTdGF0dXNDb2RlW3ZhbHVlXSA9IGtleTtcbiAgfVxufSk7XG5cbmV4cG9ydCBkZWZhdWx0IEh0dHBTdGF0dXNDb2RlO1xuIiwiJ3VzZSBzdHJpY3QnO1xuXG5pbXBvcnQgdXRpbHMgZnJvbSAnLi91dGlscy5qcyc7XG5pbXBvcnQgYmluZCBmcm9tICcuL2hlbHBlcnMvYmluZC5qcyc7XG5pbXBvcnQgQXhpb3MgZnJvbSAnLi9jb3JlL0F4aW9zLmpzJztcbmltcG9ydCBtZXJnZUNvbmZpZyBmcm9tICcuL2NvcmUvbWVyZ2VDb25maWcuanMnO1xuaW1wb3J0IGRlZmF1bHRzIGZyb20gJy4vZGVmYXVsdHMvaW5kZXguanMnO1xuaW1wb3J0IGZvcm1EYXRhVG9KU09OIGZyb20gJy4vaGVscGVycy9mb3JtRGF0YVRvSlNPTi5qcyc7XG5pbXBvcnQgQ2FuY2VsZWRFcnJvciBmcm9tICcuL2NhbmNlbC9DYW5jZWxlZEVycm9yLmpzJztcbmltcG9ydCBDYW5jZWxUb2tlbiBmcm9tICcuL2NhbmNlbC9DYW5jZWxUb2tlbi5qcyc7XG5pbXBvcnQgaXNDYW5jZWwgZnJvbSAnLi9jYW5jZWwvaXNDYW5jZWwuanMnO1xuaW1wb3J0IHsgVkVSU0lPTiB9IGZyb20gJy4vZW52L2RhdGEuanMnO1xuaW1wb3J0IHRvRm9ybURhdGEgZnJvbSAnLi9oZWxwZXJzL3RvRm9ybURhdGEuanMnO1xuaW1wb3J0IEF4aW9zRXJyb3IgZnJvbSAnLi9jb3JlL0F4aW9zRXJyb3IuanMnO1xuaW1wb3J0IHNwcmVhZCBmcm9tICcuL2hlbHBlcnMvc3ByZWFkLmpzJztcbmltcG9ydCBpc0F4aW9zRXJyb3IgZnJvbSAnLi9oZWxwZXJzL2lzQXhpb3NFcnJvci5qcyc7XG5pbXBvcnQgQXhpb3NIZWFkZXJzIGZyb20gJy4vY29yZS9BeGlvc0hlYWRlcnMuanMnO1xuaW1wb3J0IGFkYXB0ZXJzIGZyb20gJy4vYWRhcHRlcnMvYWRhcHRlcnMuanMnO1xuaW1wb3J0IEh0dHBTdGF0dXNDb2RlIGZyb20gJy4vaGVscGVycy9IdHRwU3RhdHVzQ29kZS5qcyc7XG5cbi8qKlxuICogQ3JlYXRlIGFuIGluc3RhbmNlIG9mIEF4aW9zXG4gKlxuICogQHBhcmFtIHtPYmplY3R9IGRlZmF1bHRDb25maWcgVGhlIGRlZmF1bHQgY29uZmlnIGZvciB0aGUgaW5zdGFuY2VcbiAqXG4gKiBAcmV0dXJucyB7QXhpb3N9IEEgbmV3IGluc3RhbmNlIG9mIEF4aW9zXG4gKi9cbmZ1bmN0aW9uIGNyZWF0ZUluc3RhbmNlKGRlZmF1bHRDb25maWcpIHtcbiAgY29uc3QgY29udGV4dCA9IG5ldyBBeGlvcyhkZWZhdWx0Q29uZmlnKTtcbiAgY29uc3QgaW5zdGFuY2UgPSBiaW5kKEF4aW9zLnByb3RvdHlwZS5yZXF1ZXN0LCBjb250ZXh0KTtcblxuICAvLyBDb3B5IGF4aW9zLnByb3RvdHlwZSB0byBpbnN0YW5jZVxuICB1dGlscy5leHRlbmQoaW5zdGFuY2UsIEF4aW9zLnByb3RvdHlwZSwgY29udGV4dCwgeyBhbGxPd25LZXlzOiB0cnVlIH0pO1xuXG4gIC8vIENvcHkgY29udGV4dCB0byBpbnN0YW5jZVxuICB1dGlscy5leHRlbmQoaW5zdGFuY2UsIGNvbnRleHQsIG51bGwsIHsgYWxsT3duS2V5czogdHJ1ZSB9KTtcblxuICAvLyBGYWN0b3J5IGZvciBjcmVhdGluZyBuZXcgaW5zdGFuY2VzXG4gIGluc3RhbmNlLmNyZWF0ZSA9IGZ1bmN0aW9uIGNyZWF0ZShpbnN0YW5jZUNvbmZpZykge1xuICAgIHJldHVybiBjcmVhdGVJbnN0YW5jZShtZXJnZUNvbmZpZyhkZWZhdWx0Q29uZmlnLCBpbnN0YW5jZUNvbmZpZykpO1xuICB9O1xuXG4gIHJldHVybiBpbnN0YW5jZTtcbn1cblxuLy8gQ3JlYXRlIHRoZSBkZWZhdWx0IGluc3RhbmNlIHRvIGJlIGV4cG9ydGVkXG5jb25zdCBheGlvcyA9IGNyZWF0ZUluc3RhbmNlKGRlZmF1bHRzKTtcblxuLy8gRXhwb3NlIEF4aW9zIGNsYXNzIHRvIGFsbG93IGNsYXNzIGluaGVyaXRhbmNlXG5heGlvcy5BeGlvcyA9IEF4aW9zO1xuXG4vLyBFeHBvc2UgQ2FuY2VsICYgQ2FuY2VsVG9rZW5cbmF4aW9zLkNhbmNlbGVkRXJyb3IgPSBDYW5jZWxlZEVycm9yO1xuYXhpb3MuQ2FuY2VsVG9rZW4gPSBDYW5jZWxUb2tlbjtcbmF4aW9zLmlzQ2FuY2VsID0gaXNDYW5jZWw7XG5heGlvcy5WRVJTSU9OID0gVkVSU0lPTjtcbmF4aW9zLnRvRm9ybURhdGEgPSB0b0Zvcm1EYXRhO1xuXG4vLyBFeHBvc2UgQXhpb3NFcnJvciBjbGFzc1xuYXhpb3MuQXhpb3NFcnJvciA9IEF4aW9zRXJyb3I7XG5cbi8vIGFsaWFzIGZvciBDYW5jZWxlZEVycm9yIGZvciBiYWNrd2FyZCBjb21wYXRpYmlsaXR5XG5heGlvcy5DYW5jZWwgPSBheGlvcy5DYW5jZWxlZEVycm9yO1xuXG4vLyBFeHBvc2UgYWxsL3NwcmVhZFxuYXhpb3MuYWxsID0gZnVuY3Rpb24gYWxsKHByb21pc2VzKSB7XG4gIHJldHVybiBQcm9taXNlLmFsbChwcm9taXNlcyk7XG59O1xuXG5heGlvcy5zcHJlYWQgPSBzcHJlYWQ7XG5cbi8vIEV4cG9zZSBpc0F4aW9zRXJyb3JcbmF4aW9zLmlzQXhpb3NFcnJvciA9IGlzQXhpb3NFcnJvcjtcblxuLy8gRXhwb3NlIG1lcmdlQ29uZmlnXG5heGlvcy5tZXJnZUNvbmZpZyA9IG1lcmdlQ29uZmlnO1xuXG5heGlvcy5BeGlvc0hlYWRlcnMgPSBBeGlvc0hlYWRlcnM7XG5cbmF4aW9zLmZvcm1Ub0pTT04gPSAodGhpbmcpID0+IGZvcm1EYXRhVG9KU09OKHV0aWxzLmlzSFRNTEZvcm0odGhpbmcpID8gbmV3IEZvcm1EYXRhKHRoaW5nKSA6IHRoaW5nKTtcblxuYXhpb3MuZ2V0QWRhcHRlciA9IGFkYXB0ZXJzLmdldEFkYXB0ZXI7XG5cbmF4aW9zLkh0dHBTdGF0dXNDb2RlID0gSHR0cFN0YXR1c0NvZGU7XG5cbmF4aW9zLmRlZmF1bHQgPSBheGlvcztcblxuLy8gdGhpcyBtb2R1bGUgc2hvdWxkIG9ubHkgaGF2ZSBhIGRlZmF1bHQgZXhwb3J0XG5leHBvcnQgZGVmYXVsdCBheGlvcztcbiIsImltcG9ydCBheGlvcyBmcm9tICcuL2xpYi9heGlvcy5qcyc7XG5cbi8vIFRoaXMgbW9kdWxlIGlzIGludGVuZGVkIHRvIHVud3JhcCBBeGlvcyBkZWZhdWx0IGV4cG9ydCBhcyBuYW1lZC5cbi8vIEtlZXAgdG9wLWxldmVsIGV4cG9ydCBzYW1lIHdpdGggc3RhdGljIHByb3BlcnRpZXNcbi8vIHNvIHRoYXQgaXQgY2FuIGtlZXAgc2FtZSB3aXRoIGVzIG1vZHVsZSBvciBjanNcbmNvbnN0IHtcbiAgQXhpb3MsXG4gIEF4aW9zRXJyb3IsXG4gIENhbmNlbGVkRXJyb3IsXG4gIGlzQ2FuY2VsLFxuICBDYW5jZWxUb2tlbixcbiAgVkVSU0lPTixcbiAgYWxsLFxuICBDYW5jZWwsXG4gIGlzQXhpb3NFcnJvcixcbiAgc3ByZWFkLFxuICB0b0Zvcm1EYXRhLFxuICBBeGlvc0hlYWRlcnMsXG4gIEh0dHBTdGF0dXNDb2RlLFxuICBmb3JtVG9KU09OLFxuICBnZXRBZGFwdGVyLFxuICBtZXJnZUNvbmZpZyxcbiAgY3JlYXRlLFxufSA9IGF4aW9zO1xuXG5leHBvcnQge1xuICBheGlvcyBhcyBkZWZhdWx0LFxuICBjcmVhdGUsXG4gIEF4aW9zLFxuICBBeGlvc0Vycm9yLFxuICBDYW5jZWxlZEVycm9yLFxuICBpc0NhbmNlbCxcbiAgQ2FuY2VsVG9rZW4sXG4gIFZFUlNJT04sXG4gIGFsbCxcbiAgQ2FuY2VsLFxuICBpc0F4aW9zRXJyb3IsXG4gIHNwcmVhZCxcbiAgdG9Gb3JtRGF0YSxcbiAgQXhpb3NIZWFkZXJzLFxuICBIdHRwU3RhdHVzQ29kZSxcbiAgZm9ybVRvSlNPTixcbiAgZ2V0QWRhcHRlcixcbiAgbWVyZ2VDb25maWcsXG59O1xuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7QUFTQSxTQUF3QixLQUFLLElBQUksU0FBUztDQUN4QyxPQUFPLFNBQVMsT0FBTztFQUNyQixPQUFPLEdBQUcsTUFBTSxTQUFTLFNBQVM7Q0FDcEM7QUFDRjs7QUNQQSxJQUFNLEVBQUUsYUFBYSxPQUFPO0FBQzVCLElBQU0sRUFBRSxtQkFBbUI7QUFDM0IsSUFBTSxFQUFFLFVBQVUsZ0JBQWdCO0FBR2xDLElBQU0sbUJBQ0gsRUFBRSxzQkFDRixLQUFLLFNBQ0osZUFBZSxLQUFLLEtBQUssSUFBSSxFQUFBLENBQy9CLE9BQU8sU0FBUztBQUVsQixJQUFNLHFCQUFxQixTQUN6QixPQUFPLFNBQVMsYUFDZixTQUFTLGVBQWUsU0FBUyxpQkFBaUIsU0FBUzs7Ozs7Ozs7Ozs7Ozs7O0FBZ0I5RCxJQUFNLHVCQUF1QixLQUFLLFdBQVcsV0FDM0MsUUFBUSxPQUFPLGFBQWMsQ0FBQyxVQUFVLGNBQWM7Ozs7Ozs7Ozs7O0FBWXhELElBQU0seUJBQXlCLFFBQVE7Q0FDckMsSUFBSSxDQUFDLE9BQU8sYUFBYSxHQUFHLEdBQzFCLE9BQU87Q0FHVCxNQUFNLFFBQVEsT0FBTyxvQkFBb0IsR0FBRztDQUU1QyxJQUFJLE9BQU8sdUJBQ1QsTUFBTSxLQUFLLEdBQUcsT0FBTyxzQkFBc0IsR0FBRyxDQUFDO0NBR2pELE9BQU8sTUFBTSxPQUFPLFNBQVM7RUFDM0IsSUFBSSxrQkFBa0IsSUFBSSxHQUN4QixPQUFPO0VBR1QsTUFBTSxhQUFhLE9BQU8seUJBQXlCLEtBQUssSUFBSTtFQUU1RCxPQUFPLENBQUMsQ0FBQyxjQUFjLFdBQVcsZ0JBQWdCLFdBQVcsYUFBYTtDQUM1RSxDQUFDO0FBQ0g7Ozs7Ozs7Ozs7Ozs7QUFjQSxJQUFNLDBCQUEwQixPQUFPLFNBQVM7Q0FDOUMsSUFBSSxNQUFNO0NBQ1YsTUFBTSxPQUFPLENBQUM7Q0FFZCxPQUFPLE9BQU8sTUFBTTtFQUNsQixJQUFJLEtBQUssUUFBUSxHQUFHLE1BQU0sSUFDeEIsT0FBTztFQUVULEtBQUssS0FBSyxHQUFHO0VBRWIsTUFBTSxZQUFZLGVBQWUsR0FBRztFQUVwQyxJQUFJLG9CQUFvQixLQUFLLFdBQVcsUUFBUSxLQUFLLEdBQ25ELE9BQU87RUFHVCxJQUFJLGVBQWUsS0FBSyxJQUFJLEdBQzFCLE9BQU87RUFFVCxNQUFNO0NBQ1I7Q0FDQSxPQUFPO0FBQ1Q7Ozs7Ozs7Ozs7OztBQWFBLElBQU0sZUFBZSxLQUFLLFNBQ3hCLE9BQU8sUUFBUSx1QkFBdUIsS0FBSyxJQUFJLElBQUksSUFBSSxRQUFRLEtBQUE7Ozs7Ozs7Ozs7OztBQWFqRSxJQUFNLG9CQUFvQixVQUFVO0NBQ2xDLElBQUksU0FBUyxRQUFTLE9BQU8sVUFBVSxZQUFZLE9BQU8sVUFBVSxZQUNsRSxPQUFPO0NBR1QsTUFBTSxrQkFBa0IsZUFBZSxLQUFLO0NBRTVDLElBQUksb0JBQW9CLFFBQVEsc0JBQXNCLEtBQUssR0FDekQsT0FBTztDQUdULE1BQU0sU0FBUyxPQUFPLE9BQU8sSUFBSTtDQUNqQyxNQUFNLFNBQVMsT0FBTyxPQUFPLElBQUk7Q0FDakMsTUFBTSxPQUFPLENBQUM7Q0FDZCxJQUFJLFVBQVU7Q0FFZCxPQUFPLFdBQVcsTUFBTTtFQUN0QixJQUFJLEtBQUssUUFBUSxPQUFPLE1BQU0sSUFDNUI7RUFHRixLQUFLLEtBQUssT0FBTztFQUVqQixNQUFNLFlBQVksWUFBWSxRQUFRLGtCQUFrQixlQUFlLE9BQU87RUFFOUUsSUFBSSxvQkFBb0IsU0FBUyxXQUFXLFlBQVksS0FBSyxHQUMzRDtFQUdGLE1BQU0sUUFBUSxPQUFPLG9CQUFvQixPQUFPO0VBRWhELElBQUksT0FBTyx1QkFDVCxNQUFNLEtBQUssR0FBRyxPQUFPLHNCQUFzQixPQUFPLENBQUM7RUFHckQsS0FBSyxNQUFNLFFBQVEsT0FBTztHQUN4QixJQUFJLGtCQUFrQixJQUFJLEdBQ3hCO0dBR0YsSUFBSSxDQUFDLGVBQWUsUUFBUSxJQUFJLEdBQUc7SUFDakMsT0FBTyxRQUFRLE1BQU07SUFDckIsT0FBTyxRQUFRO0dBQ2pCO0VBQ0Y7RUFFQSxVQUFVO0NBQ1o7Q0FFQSxPQUFPO0FBQ1Q7QUFFQSxJQUFNLFdBQVcsV0FBVyxVQUFVO0NBQ3BDLE1BQU0sTUFBTSxTQUFTLEtBQUssS0FBSztDQUMvQixPQUFPLE1BQU0sU0FBUyxNQUFNLE9BQU8sSUFBSSxNQUFNLEdBQUcsRUFBRSxDQUFDLENBQUMsWUFBWTtBQUNsRSxFQUFBLENBQUcsT0FBTyxPQUFPLElBQUksQ0FBQztBQUV0QixJQUFNLGNBQWMsU0FBUztDQUMzQixPQUFPLEtBQUssWUFBWTtDQUN4QixRQUFRLFVBQVUsT0FBTyxLQUFLLE1BQU07QUFDdEM7QUFFQSxJQUFNLGNBQWMsVUFBVSxVQUFVLE9BQU8sVUFBVTs7Ozs7Ozs7QUFTekQsSUFBTSxFQUFFLFlBQVk7Ozs7Ozs7O0FBU3BCLElBQU0sY0FBYyxXQUFXLFdBQVc7Ozs7Ozs7O0FBUzFDLFNBQVMsU0FBUyxLQUFLO0NBQ3JCLE9BQ0UsUUFBUSxRQUNSLENBQUMsWUFBWSxHQUFHLEtBQ2hCLElBQUksZ0JBQWdCLFFBQ3BCLENBQUMsWUFBWSxJQUFJLFdBQVcsS0FDNUJBLGFBQVcsSUFBSSxZQUFZLFFBQVEsS0FDbkMsSUFBSSxZQUFZLFNBQVMsR0FBRztBQUVoQzs7Ozs7Ozs7QUFTQSxJQUFNLGdCQUFnQixXQUFXLGFBQWE7Ozs7Ozs7O0FBUzlDLFNBQVMsa0JBQWtCLEtBQUs7Q0FDOUIsSUFBSTtDQUNKLElBQUksT0FBTyxnQkFBZ0IsZUFBZSxZQUFZLFFBQ3BELFNBQVMsWUFBWSxPQUFPLEdBQUc7TUFFL0IsU0FBUyxPQUFPLElBQUksVUFBVSxjQUFjLElBQUksTUFBTTtDQUV4RCxPQUFPO0FBQ1Q7Ozs7Ozs7O0FBU0EsSUFBTSxXQUFXLFdBQVcsUUFBUTs7Ozs7OztBQVFwQyxJQUFNQSxlQUFhLFdBQVcsVUFBVTs7Ozs7Ozs7QUFTeEMsSUFBTSxXQUFXLFdBQVcsUUFBUTs7Ozs7Ozs7QUFTcEMsSUFBTSxZQUFZLFVBQVUsVUFBVSxRQUFRLE9BQU8sVUFBVTs7Ozs7OztBQVEvRCxJQUFNLGFBQWEsVUFBVSxVQUFVLFFBQVEsVUFBVTs7Ozs7Ozs7QUFTekQsSUFBTSxpQkFBaUIsUUFBUTtDQUM3QixJQUFJLENBQUMsU0FBUyxHQUFHLEdBQ2YsT0FBTztDQUdULE1BQU0sWUFBWSxlQUFlLEdBQUc7Q0FDcEMsUUFDRyxjQUFjLFFBQVEsY0FBYyxPQUFPLGFBQWEsZUFBZSxTQUFTLE1BQU0sVUFVdEYsb0JBQW9CLEtBQUssV0FBVyxJQUFJLEtBQ3RDLENBQUMsZUFBZSxLQUFLLFdBQVcsS0FBSyxDQUFDLGVBQWUsS0FBSyxRQUFRO0FBRXpFOzs7Ozs7OztBQVNBLElBQU0saUJBQWlCLFFBQVE7Q0FFN0IsSUFBSSxDQUFDLFNBQVMsR0FBRyxLQUFLLFNBQVMsR0FBRyxHQUNoQyxPQUFPO0NBR1QsSUFBSTtFQUNGLE9BQU8sT0FBTyxLQUFLLEdBQUcsQ0FBQyxDQUFDLFdBQVcsS0FBSyxPQUFPLGVBQWUsR0FBRyxNQUFNLE9BQU87Q0FDaEYsU0FBUyxHQUFHO0VBRVYsT0FBTztDQUNUO0FBQ0Y7Ozs7Ozs7O0FBU0EsSUFBTSxTQUFTLFdBQVcsTUFBTTs7Ozs7Ozs7QUFTaEMsSUFBTSxTQUFTLFdBQVcsTUFBTTs7Ozs7Ozs7Ozs7O0FBYWhDLElBQU0scUJBQXFCLFVBQVU7Q0FDbkMsT0FBTyxDQUFDLEVBQUUsU0FBUyxPQUFPLE1BQU0sUUFBUTtBQUMxQzs7Ozs7Ozs7O0FBVUEsSUFBTSxpQkFBaUIsYUFBYSxZQUFZLE9BQU8sU0FBUyxhQUFhOzs7Ozs7OztBQVM3RSxJQUFNLFNBQVMsV0FBVyxNQUFNOzs7Ozs7OztBQVNoQyxJQUFNLGFBQWEsV0FBVyxVQUFVO0FBQ3hDLElBQU0sUUFBUSxXQUFXLEtBQUs7Ozs7Ozs7O0FBUzlCLElBQU0sWUFBWSxRQUFRLFNBQVMsR0FBRyxLQUFLQSxhQUFXLElBQUksSUFBSTs7Ozs7Ozs7QUFTOUQsU0FBUyxZQUFZO0NBQ25CLElBQUksT0FBTyxlQUFlLGFBQWEsT0FBTztDQUM5QyxJQUFJLE9BQU8sU0FBUyxhQUFhLE9BQU87Q0FDeEMsSUFBSSxPQUFPLFdBQVcsYUFBYSxPQUFPO0NBQzFDLElBQUksT0FBTyxXQUFXLGFBQWEsT0FBTztDQUMxQyxPQUFPLENBQUM7QUFDVjtBQUVBLElBQU0sSUFBSSxVQUFVO0FBQ3BCLElBQU0sZUFBZSxPQUFPLEVBQUUsYUFBYSxjQUFjLEVBQUUsV0FBVyxLQUFBO0FBRXRFLElBQU0sY0FBYyxVQUFVO0NBQzVCLElBQUksQ0FBQyxPQUFPLE9BQU87Q0FDbkIsSUFBSSxnQkFBZ0IsaUJBQWlCLGNBQWMsT0FBTztDQUUxRCxNQUFNLFFBQVEsZUFBZSxLQUFLO0NBQ2xDLElBQUksQ0FBQyxTQUFTLFVBQVUsT0FBTyxXQUFXLE9BQU87Q0FDakQsSUFBSSxDQUFDQSxhQUFXLE1BQU0sTUFBTSxHQUFHLE9BQU87Q0FDdEMsTUFBTSxPQUFPLE9BQU8sS0FBSztDQUN6QixPQUNFLFNBQVMsY0FFUixTQUFTLFlBQVlBLGFBQVcsTUFBTSxRQUFRLEtBQUssTUFBTSxTQUFTLE1BQU07QUFFN0U7Ozs7Ozs7O0FBU0EsSUFBTSxvQkFBb0IsV0FBVyxpQkFBaUI7QUFFdEQsSUFBTSxDQUFDLGtCQUFrQixXQUFXLFlBQVksYUFBYTtDQUMzRDtDQUNBO0NBQ0E7Q0FDQTtBQUNGLENBQUMsQ0FBQyxJQUFJLFVBQVU7Ozs7Ozs7O0FBU2hCLElBQU0sUUFBUSxRQUFRO0NBQ3BCLE9BQU8sSUFBSSxPQUFPLElBQUksS0FBSyxJQUFJLElBQUksUUFBUSxzQ0FBc0MsRUFBRTtBQUNyRjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFpQkEsU0FBUyxRQUFRLEtBQUssSUFBSSxFQUFFLGFBQWEsVUFBVSxDQUFDLEdBQUc7Q0FFckQsSUFBSSxRQUFRLFFBQVEsT0FBTyxRQUFRLGFBQ2pDO0NBR0YsSUFBSTtDQUNKLElBQUk7Q0FHSixJQUFJLE9BQU8sUUFBUSxVQUVqQixNQUFNLENBQUMsR0FBRztDQUdaLElBQUksUUFBUSxHQUFHLEdBRWIsS0FBSyxJQUFJLEdBQUcsSUFBSSxJQUFJLFFBQVEsSUFBSSxHQUFHLEtBQ2pDLEdBQUcsS0FBSyxNQUFNLElBQUksSUFBSSxHQUFHLEdBQUc7TUFFekI7RUFFTCxJQUFJLFNBQVMsR0FBRyxHQUNkO0VBSUYsTUFBTSxPQUFPLGFBQWEsT0FBTyxvQkFBb0IsR0FBRyxJQUFJLE9BQU8sS0FBSyxHQUFHO0VBQzNFLE1BQU0sTUFBTSxLQUFLO0VBQ2pCLElBQUk7RUFFSixLQUFLLElBQUksR0FBRyxJQUFJLEtBQUssS0FBSztHQUN4QixNQUFNLEtBQUs7R0FDWCxHQUFHLEtBQUssTUFBTSxJQUFJLE1BQU0sS0FBSyxHQUFHO0VBQ2xDO0NBQ0Y7QUFDRjs7Ozs7Ozs7O0FBVUEsU0FBUyxRQUFRLEtBQUssS0FBSztDQUN6QixJQUFJLFNBQVMsR0FBRyxHQUNkLE9BQU87Q0FHVCxNQUFNLElBQUksWUFBWTtDQUN0QixNQUFNLE9BQU8sT0FBTyxLQUFLLEdBQUc7Q0FDNUIsSUFBSSxJQUFJLEtBQUs7Q0FDYixJQUFJO0NBQ0osT0FBTyxNQUFNLEdBQUc7RUFDZCxPQUFPLEtBQUs7RUFDWixJQUFJLFFBQVEsS0FBSyxZQUFZLEdBQzNCLE9BQU87Q0FFWDtDQUNBLE9BQU87QUFDVDtBQUVBLElBQU0saUJBQWlCO0NBRXJCLElBQUksT0FBTyxlQUFlLGFBQWEsT0FBTztDQUM5QyxPQUFPLE9BQU8sU0FBUyxjQUFjLE9BQU8sT0FBTyxXQUFXLGNBQWMsU0FBUztBQUN2RixFQUFBLENBQUc7QUFFSCxJQUFNLG9CQUFvQixZQUFZLENBQUMsWUFBWSxPQUFPLEtBQUssWUFBWTs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQW9CM0UsU0FBUyxNQUFNLEdBQUcsTUFBTTtDQUN0QixNQUFNLEVBQUUsVUFBVSxrQkFBbUIsaUJBQWlCLElBQUksS0FBSyxRQUFTLENBQUM7Q0FDekUsTUFBTSxTQUFTLENBQUM7Q0FNaEIsTUFBTSxnQkFBZ0IsV0FBVyxPQUFPLE9BQU8sSUFBSSxJQUFJO0NBQ3ZELE1BQU0sZUFBZSxLQUFLLFFBQVE7RUFFaEMsSUFBSSxRQUFRLGVBQWUsUUFBUSxpQkFBaUIsUUFBUSxhQUMxRDtFQUdGLElBQUksWUFBWTtFQUNoQixJQUFJLGlCQUFpQixPQUFPLFFBQVEsVUFBVTtHQUM1QyxNQUFNLFdBQVcsSUFBSSxZQUFZO0dBQ2pDLE1BQU0sV0FBVyxjQUFjO0dBRy9CLElBQUksYUFBYSxLQUFBLEtBQWEsZUFBZSxRQUFRLFFBQVEsR0FDM0QsWUFBWTtRQUVaLGNBQWMsWUFBWTtFQUU5QjtFQUlBLE1BQU0sV0FBVyxlQUFlLFFBQVEsU0FBUyxJQUFJLE9BQU8sYUFBYSxLQUFBO0VBQ3pFLElBQUksY0FBYyxRQUFRLEtBQUssY0FBYyxHQUFHLEdBQzlDLE9BQU8sYUFBYSxNQUFNLFVBQVUsR0FBRztPQUNsQyxJQUFJLGNBQWMsR0FBRyxHQUMxQixPQUFPLGFBQWEsTUFBTSxDQUFDLEdBQUcsR0FBRztPQUM1QixJQUFJLFFBQVEsR0FBRyxHQUNwQixPQUFPLGFBQWEsSUFBSSxNQUFNO09BQ3pCLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxZQUFZLEdBQUcsR0FDM0MsT0FBTyxhQUFhO0NBRXhCO0NBRUEsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEtBQUssUUFBUSxJQUFJLEdBQUcsS0FBSztFQUMzQyxNQUFNLFNBQVMsS0FBSztFQUNwQixJQUFJLENBQUMsVUFBVSxTQUFTLE1BQU0sR0FDNUI7RUFHRixRQUFRLFFBQVEsV0FBVztFQUUzQixJQUFJLE9BQU8sV0FBVyxZQUFZLFFBQVEsTUFBTSxLQUFLLENBQUMsT0FBTyx1QkFDM0Q7RUFHRixNQUFNLFVBQVUsT0FBTyxzQkFBc0IsTUFBTTtFQUNuRCxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksUUFBUSxRQUFRLEtBQUs7R0FDdkMsTUFBTSxTQUFTLFFBQVE7R0FDdkIsSUFBSSxxQkFBcUIsS0FBSyxRQUFRLE1BQU0sR0FDMUMsWUFBWSxPQUFPLFNBQVMsTUFBTTtFQUV0QztDQUNGO0NBQ0EsT0FBTztBQUNUOzs7Ozs7Ozs7Ozs7QUFhQSxJQUFNLFVBQVUsR0FBRyxHQUFHLFNBQVMsRUFBRSxlQUFlLENBQUMsTUFBTTtDQUNyRCxRQUNFLElBQ0MsS0FBSyxRQUFRO0VBQ1osSUFBSSxXQUFXQSxhQUFXLEdBQUcsR0FDM0IsT0FBTyxlQUFlLEdBQUcsS0FBSztHQUc1QixXQUFXO0dBQ1gsT0FBTyxLQUFLLEtBQUssT0FBTztHQUN4QixVQUFVO0dBQ1YsWUFBWTtHQUNaLGNBQWM7RUFDaEIsQ0FBQztPQUVELE9BQU8sZUFBZSxHQUFHLEtBQUs7R0FDNUIsV0FBVztHQUNYLE9BQU87R0FDUCxVQUFVO0dBQ1YsWUFBWTtHQUNaLGNBQWM7RUFDaEIsQ0FBQztDQUVMLEdBQ0EsRUFBRSxXQUFXLENBQ2Y7Q0FDQSxPQUFPO0FBQ1Q7Ozs7Ozs7O0FBU0EsSUFBTSxZQUFZLFlBQVk7Q0FDNUIsSUFBSSxRQUFRLFdBQVcsQ0FBQyxNQUFNLE9BQzVCLFVBQVUsUUFBUSxNQUFNLENBQUM7Q0FFM0IsT0FBTztBQUNUOzs7Ozs7Ozs7O0FBV0EsSUFBTSxZQUFZLGFBQWEsa0JBQWtCLE9BQU8sZ0JBQWdCO0NBQ3RFLFlBQVksWUFBWSxPQUFPLE9BQU8saUJBQWlCLFdBQVcsV0FBVztDQUM3RSxPQUFPLGVBQWUsWUFBWSxXQUFXLGVBQWU7RUFDMUQsV0FBVztFQUNYLE9BQU87RUFDUCxVQUFVO0VBQ1YsWUFBWTtFQUNaLGNBQWM7Q0FDaEIsQ0FBQztDQUNELE9BQU8sZUFBZSxhQUFhLFNBQVM7RUFDMUMsV0FBVztFQUNYLE9BQU8saUJBQWlCO0NBQzFCLENBQUM7Q0FDRCxTQUFTLE9BQU8sT0FBTyxZQUFZLFdBQVcsS0FBSztBQUNyRDs7Ozs7Ozs7OztBQVdBLElBQU0sZ0JBQWdCLFdBQVcsU0FBUyxRQUFRLGVBQWU7Q0FDL0QsSUFBSTtDQUNKLElBQUk7Q0FDSixJQUFJO0NBQ0osTUFBTSxTQUFTLENBQUM7Q0FFaEIsVUFBVSxXQUFXLENBQUM7Q0FFdEIsSUFBSSxhQUFhLE1BQU0sT0FBTztDQUU5QixHQUFHO0VBQ0QsUUFBUSxPQUFPLG9CQUFvQixTQUFTO0VBQzVDLElBQUksTUFBTTtFQUNWLE9BQU8sTUFBTSxHQUFHO0dBQ2QsT0FBTyxNQUFNO0dBQ2IsS0FBSyxDQUFDLGNBQWMsV0FBVyxNQUFNLFdBQVcsT0FBTyxNQUFNLENBQUMsT0FBTyxPQUFPO0lBQzFFLFFBQVEsUUFBUSxVQUFVO0lBQzFCLE9BQU8sUUFBUTtHQUNqQjtFQUNGO0VBQ0EsWUFBWSxXQUFXLFNBQVMsZUFBZSxTQUFTO0NBQzFELFNBQVMsY0FBYyxDQUFDLFVBQVUsT0FBTyxXQUFXLE9BQU8sTUFBTSxjQUFjLE9BQU87Q0FFdEYsT0FBTztBQUNUOzs7Ozs7Ozs7O0FBV0EsSUFBTSxZQUFZLEtBQUssY0FBYyxhQUFhO0NBQ2hELE1BQU0sT0FBTyxHQUFHO0NBQ2hCLElBQUksYUFBYSxLQUFBLEtBQWEsV0FBVyxJQUFJLFFBQzNDLFdBQVcsSUFBSTtDQUVqQixZQUFZLGFBQWE7Q0FDekIsTUFBTSxZQUFZLElBQUksUUFBUSxjQUFjLFFBQVE7Q0FDcEQsT0FBTyxjQUFjLE1BQU0sY0FBYztBQUMzQzs7Ozs7Ozs7QUFTQSxJQUFNLFdBQVcsVUFBVTtDQUN6QixJQUFJLENBQUMsT0FBTyxPQUFPO0NBQ25CLElBQUksUUFBUSxLQUFLLEdBQUcsT0FBTztDQUMzQixJQUFJLElBQUksTUFBTTtDQUNkLElBQUksQ0FBQyxPQUFPLGNBQWMsQ0FBQyxLQUFLLElBQUksS0FBSyxJQUFJLFlBQVksT0FBTztDQUloRSxNQUFNLDBCQUFVLElBQUksSUFBSTtDQUN4QixNQUFNLHVCQUFPLElBQUksSUFBSTtDQUNyQixJQUFJLFNBQVM7Q0FFYixPQUFPLFVBQVUsUUFBUSxRQUFRLE9BQU8sR0FBRztFQUN6QyxJQUFJLEtBQUssSUFBSSxNQUFNLEdBQUcsT0FBTztFQUM3QixLQUFLLElBQUksTUFBTTtFQUVmLE1BQU0sWUFBWSxlQUFlLE1BQU07RUFDdkMsSUFBSSxvQkFBb0IsUUFBUSxXQUFXLFdBQVcsS0FBSyxHQUFHO0VBRTlELE9BQU8sb0JBQW9CLE1BQU0sQ0FBQyxDQUFDLFNBQVMsUUFBUTtHQUNsRCxNQUFNLFFBQVEsQ0FBQztHQUNmLElBQ0UsT0FBTyxVQUFVLEtBQUssS0FDdEIsU0FBUyxLQUNULFFBQVEsS0FDUixPQUFPLEtBQUssTUFBTSxPQUNsQixlQUFlLFFBQVEsR0FBRyxHQUUxQixRQUFRLElBQUksS0FBSztFQUVyQixDQUFDO0VBQ0QsU0FBUztDQUNYO0NBRUEsSUFBSSxRQUFRLFNBQVMsR0FBRyxPQUFPO0NBQy9CLE1BQU0sTUFBTSxJQUFJLE1BQU0sQ0FBQztDQUN2QixPQUFPLE1BQU0sR0FDWCxJQUFJLEtBQUssTUFBTTtDQUVqQixPQUFPO0FBQ1Q7Ozs7Ozs7OztBQVdBLElBQU0saUJBQWlCLGVBQWU7Q0FFcEMsUUFBUSxVQUFVO0VBQ2hCLE9BQU8sY0FBYyxpQkFBaUI7Q0FDeEM7QUFDRixFQUFBLENBQUcsT0FBTyxlQUFlLGVBQWUsZUFBZSxVQUFVLENBQUM7Ozs7Ozs7OztBQVVsRSxJQUFNLGdCQUFnQixLQUFLLE9BQU87Q0FHaEMsTUFBTSxhQUZZLE9BQU8sSUFBSSxVQUFBLENBRUQsS0FBSyxHQUFHO0NBRXBDLElBQUk7Q0FFSixRQUFRLFNBQVMsVUFBVSxLQUFLLE1BQU0sQ0FBQyxPQUFPLE1BQU07RUFDbEQsTUFBTSxPQUFPLE9BQU87RUFDcEIsR0FBRyxLQUFLLEtBQUssS0FBSyxJQUFJLEtBQUssRUFBRTtDQUMvQjtBQUNGOzs7Ozs7Ozs7QUFVQSxJQUFNLFlBQVksUUFBUSxRQUFRO0NBQ2hDLElBQUk7Q0FDSixNQUFNLE1BQU0sQ0FBQztDQUViLFFBQVEsVUFBVSxPQUFPLEtBQUssR0FBRyxPQUFPLE1BQ3RDLElBQUksS0FBSyxPQUFPO0NBR2xCLE9BQU87QUFDVDtBQUdBLElBQU0sYUFBYSxXQUFXLGlCQUFpQjtBQUUvQyxJQUFNLGVBQWUsUUFBUTtDQUMzQixPQUFPLElBQUksWUFBWSxDQUFDLENBQUMsUUFBUSx5QkFBeUIsU0FBUyxTQUFTLEdBQUcsSUFBSSxJQUFJO0VBQ3JGLE9BQU8sR0FBRyxZQUFZLElBQUk7Q0FDNUIsQ0FBQztBQUNIO0FBRUEsSUFBTSxFQUFFLHlCQUF5QixPQUFPOzs7Ozs7OztBQVN4QyxJQUFNLFdBQVcsV0FBVyxRQUFRO0FBRXBDLElBQU0scUJBQXFCLEtBQUssWUFBWTtDQUMxQyxNQUFNLGNBQWMsT0FBTywwQkFBMEIsR0FBRztDQUN4RCxNQUFNLHFCQUFxQixDQUFDO0NBRTVCLFFBQVEsY0FBYyxZQUFZLFNBQVM7RUFDekMsSUFBSTtFQUNKLEtBQUssTUFBTSxRQUFRLFlBQVksTUFBTSxHQUFHLE9BQU8sT0FDN0MsbUJBQW1CLFFBQVEsT0FBTztDQUV0QyxDQUFDO0NBRUQsT0FBTyxpQkFBaUIsS0FBSyxrQkFBa0I7QUFDakQ7Ozs7O0FBT0EsSUFBTSxpQkFBaUIsUUFBUTtDQUM3QixrQkFBa0IsTUFBTSxZQUFZLFNBQVM7RUFFM0MsSUFBSUEsYUFBVyxHQUFHLEtBQUs7R0FBQztHQUFhO0dBQVU7RUFBUSxDQUFDLENBQUMsU0FBUyxJQUFJLEdBQ3BFLE9BQU87RUFHVCxNQUFNLFFBQVEsSUFBSTtFQUVsQixJQUFJLENBQUNBLGFBQVcsS0FBSyxHQUFHO0VBRXhCLFdBQVcsYUFBYTtFQUV4QixJQUFJLGNBQWMsWUFBWTtHQUM1QixXQUFXLFdBQVc7R0FDdEI7RUFDRjtFQUVBLElBQUksQ0FBQyxXQUFXLEtBQ2QsV0FBVyxZQUFZO0dBQ3JCLE1BQU0sTUFBTSx1Q0FBdUMsT0FBTyxHQUFHO0VBQy9EO0NBRUosQ0FBQztBQUNIOzs7Ozs7Ozs7QUFVQSxJQUFNLGVBQWUsZUFBZSxjQUFjO0NBQ2hELE1BQU0sTUFBTSxDQUFDO0NBRWIsTUFBTSxVQUFVLFFBQVE7RUFDdEIsSUFBSSxTQUFTLFVBQVU7R0FDckIsSUFBSSxTQUFTO0VBQ2YsQ0FBQztDQUNIO0NBRUEsUUFBUSxhQUFhLElBQUksT0FBTyxhQUFhLElBQUksT0FBTyxPQUFPLGFBQWEsQ0FBQyxDQUFDLE1BQU0sU0FBUyxDQUFDO0NBRTlGLE9BQU87QUFDVDtBQUVBLElBQU0sYUFBYSxDQUFDO0FBRXBCLElBQU0sa0JBQWtCLE9BQU8saUJBQWlCO0NBQzlDLE9BQU8sU0FBUyxRQUFRLE9BQU8sU0FBVSxRQUFRLENBQUMsS0FBTSxJQUFJLFFBQVE7QUFDdEU7Ozs7Ozs7O0FBU0EsU0FBUyxvQkFBb0IsT0FBTztDQUNsQyxPQUFPLENBQUMsRUFDTixTQUNBQSxhQUFXLE1BQU0sTUFBTSxLQUN2QixNQUFNLGlCQUFpQixjQUN2QixNQUFNO0FBRVY7Ozs7Ozs7QUFRQSxJQUFNLGdCQUFnQixRQUFRO0NBQzVCLE1BQU0sMEJBQVUsSUFBSSxRQUFRO0NBRTVCLE1BQU0sU0FBUyxXQUFXO0VBQ3hCLElBQUksU0FBUyxNQUFNLEdBQUc7R0FDcEIsSUFBSSxRQUFRLElBQUksTUFBTSxHQUNwQjtHQUlGLElBQUksU0FBUyxNQUFNLEdBQ2pCLE9BQU87R0FHVCxJQUFJLEVBQUUsWUFBWSxTQUFTO0lBRXpCLFFBQVEsSUFBSSxNQUFNO0lBRWxCLElBQUk7SUFFSixJQUFJLE1BQU0sTUFBTSxHQUFHO0tBQ2pCLFNBQVMsQ0FBQztLQUNWLEtBQUssTUFBTSxTQUFTLFFBQVE7TUFDMUIsTUFBTSxlQUFlLE1BQU0sS0FBSztNQUNoQyxDQUFDLFlBQVksWUFBWSxLQUFLLE9BQU8sS0FBSyxZQUFZO0tBQ3hEO0lBQ0YsT0FBTztLQUNMLFNBQVMsUUFBUSxNQUFNLElBQUksQ0FBQyxJQUFJLENBQUM7S0FFakMsUUFBUSxTQUFTLE9BQU8sUUFBUTtNQUM5QixNQUFNLGVBQWUsTUFBTSxLQUFLO01BQ2hDLENBQUMsWUFBWSxZQUFZLE1BQU0sT0FBTyxPQUFPO0tBQy9DLENBQUM7SUFDSDtJQUVBLFFBQVEsT0FBTyxNQUFNO0lBRXJCLE9BQU87R0FDVDtFQUNGO0VBRUEsT0FBTztDQUNUO0NBRUEsT0FBTyxNQUFNLEdBQUc7QUFDbEI7Ozs7Ozs7QUFRQSxJQUFNLFlBQVksV0FBVyxlQUFlOzs7Ozs7O0FBUTVDLElBQU0sY0FBYyxVQUNsQixVQUNDLFNBQVMsS0FBSyxLQUFLQSxhQUFXLEtBQUssTUFDcENBLGFBQVcsTUFBTSxJQUFJLEtBQ3JCQSxhQUFXLE1BQU0sS0FBSzs7Ozs7Ozs7O0FBYXhCLElBQU0sa0JBQWtCLHVCQUF1Qix5QkFBeUI7Q0FDdEUsSUFBSSx1QkFDRixPQUFPO0NBR1QsT0FBTyx5QkFDRCxPQUFPLGNBQWM7RUFDckIsUUFBUSxpQkFDTixZQUNDLEVBQUUsUUFBUSxXQUFXO0dBQ3BCLElBQUksV0FBVyxXQUFXLFNBQVMsT0FDakMsVUFBVSxVQUFVLFVBQVUsTUFBTSxDQUFDLENBQUM7RUFFMUMsR0FDQSxLQUNGO0VBRUEsUUFBUSxPQUFPO0dBQ2IsVUFBVSxLQUFLLEVBQUU7R0FDakIsUUFBUSxZQUFZLE9BQU8sR0FBRztFQUNoQztDQUNGLEVBQUEsQ0FBRyxTQUFTLEtBQUssT0FBTyxLQUFLLENBQUMsQ0FBQyxLQUM5QixPQUFPLFdBQVcsRUFBRTtBQUMzQixFQUFBLENBQUcsT0FBTyxpQkFBaUIsWUFBWUEsYUFBVyxRQUFRLFdBQVcsQ0FBQzs7Ozs7OztBQVF0RSxJQUFNLE9BQ0osT0FBTyxtQkFBbUIsY0FDdEIsZUFBZSxLQUFLLE9BQU8sSUFDMUIsT0FBTyxZQUFZLGVBQWUsUUFBUSxZQUFhO0FBSTlELElBQU0sY0FBYyxVQUFVLFNBQVMsUUFBUUEsYUFBVyxNQUFNLFNBQVM7Ozs7Ozs7Ozs7OztBQWF6RSxJQUFNLGtCQUFrQixVQUN0QixTQUFTLFFBQVEsdUJBQXVCLE9BQU8sUUFBUSxLQUFLLFdBQVcsS0FBSztBQUU5RSxJQUFBLGdCQUFlO0NBQ2I7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQSxZQUFBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQSxZQUFZO0NBQ1o7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQSxRQUFRO0NBQ1I7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBLGNBQWM7Q0FDZDtDQUNBO0NBQ0E7QUFDRjs7QUMxcUNBLElBQU0sb0JBQW9CQyxjQUFNLFlBQVk7Q0FDMUM7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtBQUNGLENBQUM7Ozs7Ozs7Ozs7Ozs7OztBQWdCRCxJQUFBLHdCQUFnQixlQUFlO0NBRTdCLE1BQU0sU0FBUyxPQUFPLE9BQU8sSUFBSTtDQUNqQyxJQUFJO0NBQ0osSUFBSTtDQUNKLElBQUk7Q0FFSixjQUNFLFdBQVcsTUFBTSxJQUFJLENBQUMsQ0FBQyxRQUFRLFNBQVMsT0FBTyxNQUFNO0VBQ25ELElBQUksS0FBSyxRQUFRLEdBQUc7RUFDcEIsTUFBTSxLQUFLLFVBQVUsR0FBRyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxZQUFZO0VBQzlDLE1BQU0sS0FBSyxVQUFVLElBQUksQ0FBQyxDQUFDLENBQUMsS0FBSztFQUVqQyxNQUFNLFNBQVNBLGNBQU0sV0FBVyxRQUFRLEdBQUc7RUFFM0MsSUFBSSxDQUFDLE9BQVEsVUFBVUEsY0FBTSxXQUFXLG1CQUFtQixHQUFHLEdBQzVEO0VBR0YsSUFBSSxRQUFRLGNBQWM7R0FDeEIsSUFBSSxRQUNGLE9BQU8sSUFBSSxDQUFDLEtBQUssR0FBRztRQUVwQixPQUFPLE9BQU8sQ0FBQyxHQUFHO0VBRXRCLE9BQ0UsT0FBTyxPQUFPLFNBQVMsT0FBTyxPQUFPLE9BQU8sTUFBTTtDQUV0RCxDQUFDO0NBRUgsT0FBTztBQUNUOztBQ25FQSxTQUFTLGFBQWEsS0FBSztDQUN6QixJQUFJLFFBQVE7Q0FDWixJQUFJLE1BQU0sSUFBSTtDQUVkLE9BQU8sUUFBUSxLQUFLO0VBQ2xCLE1BQU0sT0FBTyxJQUFJLFdBQVcsS0FBSztFQUVqQyxJQUFJLFNBQVMsS0FBUSxTQUFTLElBQzVCO0VBR0YsU0FBUztDQUNYO0NBRUEsT0FBTyxNQUFNLE9BQU87RUFDbEIsTUFBTSxPQUFPLElBQUksV0FBVyxNQUFNLENBQUM7RUFFbkMsSUFBSSxTQUFTLEtBQVEsU0FBUyxJQUM1QjtFQUdGLE9BQU87Q0FDVDtDQUVBLE9BQU8sVUFBVSxLQUFLLFFBQVEsSUFBSSxTQUFTLE1BQU0sSUFBSSxNQUFNLE9BQU8sR0FBRztBQUN2RTtBQUlBLElBQU0scURBQXFDLElBQUksT0FBTyw0Q0FBNEMsR0FBRztBQUVyRyxJQUFNLHlEQUF5QyxJQUFJLE9BQU8sNkNBQTZDLEdBQUc7QUFFMUcsU0FBUyxjQUFjLE9BQU8sY0FBYztDQUMxQyxJQUFJQyxjQUFNLFFBQVEsS0FBSyxHQUNyQixPQUFPLE1BQU0sS0FBSyxTQUFTLGNBQWMsTUFBTSxZQUFZLENBQUM7Q0FHOUQsT0FBTyxhQUFhLE9BQU8sS0FBSyxDQUFDLENBQUMsUUFBUSxjQUFjLEVBQUUsQ0FBQztBQUM3RDtBQUVBLElBQWEsdUJBQXVCLFVBQ2xDLGNBQWMsT0FBTyxrQ0FBa0M7QUFFekQsSUFBYSxpQ0FBaUMsVUFDNUMsY0FBYyxPQUFPLHNDQUFzQztBQUU3RCxTQUFnQix5QkFBeUIsU0FBUztDQUNoRCxNQUFNLG9CQUFvQixPQUFPLE9BQU8sSUFBSTtDQUU1QyxjQUFNLFFBQVEsUUFBUSxPQUFPLElBQUksT0FBTyxXQUFXO0VBQ2pELGtCQUFrQixVQUFVLDhCQUE4QixLQUFLO0NBQ2pFLENBQUM7Q0FFRCxPQUFPO0FBQ1Q7O0FDckRBLElBQU1DLGVBQWEsT0FBTyxXQUFXO0FBRXJDLFNBQVMsZ0JBQWdCLFFBQVE7Q0FDL0IsT0FBTyxVQUFVLE9BQU8sTUFBTSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsWUFBWTtBQUNyRDtBQUVBLFNBQVMsZUFBZSxPQUFPO0NBQzdCLElBQUksVUFBVSxTQUFTLFNBQVMsTUFDOUIsT0FBTztDQUdULE9BQU9DLGNBQU0sUUFBUSxLQUFLLElBQUksTUFBTSxJQUFJLGNBQWMsSUFBSSxvQkFBb0IsT0FBTyxLQUFLLENBQUM7QUFDN0Y7QUFFQSxTQUFTLFlBQVksS0FBSztDQUN4QixNQUFNLFNBQVMsT0FBTyxPQUFPLElBQUk7Q0FDakMsTUFBTSxXQUFXO0NBQ2pCLElBQUk7Q0FFSixPQUFRLFFBQVEsU0FBUyxLQUFLLEdBQUcsR0FDL0IsT0FBTyxNQUFNLE1BQU0sTUFBTTtDQUczQixPQUFPO0FBQ1Q7QUFFQSxJQUFNLGtCQUFrQjtBQUV4QixTQUFTLFFBQVEsT0FBTztDQUN0QixJQUFJLFFBQVE7Q0FDWixJQUFJLE1BQU0sTUFBTTtDQUVoQixPQUFPLFFBQVEsS0FBSztFQUNsQixNQUFNLE9BQU8sTUFBTSxXQUFXLEtBQUs7RUFFbkMsSUFBSSxTQUFTLEtBQVEsU0FBUyxJQUM1QjtFQUdGLFNBQVM7Q0FDWDtDQUVBLE9BQU8sTUFBTSxPQUFPO0VBQ2xCLE1BQU0sT0FBTyxNQUFNLFdBQVcsTUFBTSxDQUFDO0VBRXJDLElBQUksU0FBUyxLQUFRLFNBQVMsSUFDNUI7RUFHRixPQUFPO0NBQ1Q7Q0FFQSxPQUFPLFVBQVUsS0FBSyxRQUFRLE1BQU0sU0FBUyxRQUFRLE1BQU0sTUFBTSxPQUFPLEdBQUc7QUFDN0U7QUFFQSxTQUFTLG1CQUFtQixPQUFPO0NBQ2pDLE1BQU0sT0FBTyxNQUFNLFNBQVM7Q0FFNUIsSUFBSSxPQUFPLEtBQUssTUFBTSxXQUFXLENBQUMsTUFBTSxNQUFRLE1BQU0sV0FBVyxJQUFJLE1BQU0sSUFDekUsT0FBTztDQUdULElBQUksVUFBVTtDQUVkLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxNQUFNLEtBQUs7RUFDN0IsTUFBTSxPQUFPLE1BQU0sV0FBVyxDQUFDO0VBRS9CLElBQUksU0FBUyxJQUNYLE9BQU87RUFHVCxJQUFJLFNBQVMsSUFBTTtHQUNqQixLQUFLO0dBRUwsSUFBSSxLQUFLLE1BQ1AsT0FBTztFQUVYO0VBRUEsV0FBVyxNQUFNO0NBQ25CO0NBRUEsT0FBTztBQUNUO0FBRUEsU0FBUyxnQkFBZ0IsT0FBTztDQUM5QixNQUFNLGFBQWEsT0FBTyxPQUFPLElBQUk7Q0FDckMsTUFBTSxNQUFNLE9BQU8sS0FBSztDQUN4QixJQUFJLFFBQVE7Q0FDWixJQUFJLFNBQVM7Q0FDYixJQUFJLFVBQVU7Q0FFZCxTQUFTLGVBQWUsS0FBSztFQUMzQixNQUFNLE9BQU8sUUFBUSxJQUFJLE1BQU0sT0FBTyxHQUFHLENBQUM7RUFDMUMsTUFBTSxTQUFTLEtBQUssUUFBUSxHQUFHO0VBRS9CLElBQUksU0FBUyxHQUNYO0VBR0YsTUFBTSxPQUFPLFFBQVEsS0FBSyxNQUFNLEdBQUcsTUFBTSxDQUFDO0VBRTFDLElBQUksQ0FBQyxnQkFBZ0IsS0FBSyxJQUFJLEdBQzVCO0VBR0YsTUFBTSxpQkFBaUIsS0FBSyxZQUFZO0VBRXhDLElBQ0UsbUJBQW1CLGVBQ25CLG1CQUFtQixpQkFDbkIsbUJBQW1CLGFBRW5CO0VBR0YsTUFBTSxpQkFBaUIsUUFBUSxLQUFLLE1BQU0sU0FBUyxDQUFDLENBQUM7RUFDckQsV0FBVyxrQkFBa0IsbUJBQW1CLGNBQWM7Q0FDaEU7Q0FFQSxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksSUFBSSxRQUFRLEtBQUs7RUFDbkMsTUFBTSxPQUFPLElBQUksV0FBVyxDQUFDO0VBRTdCLElBQUksUUFBUTtHQUNWLElBQUksU0FDRixVQUFVO1FBQ0wsSUFBSSxTQUFTLElBQ2xCLFVBQVU7UUFDTCxJQUFJLFNBQVMsSUFDbEIsU0FBUztFQUViLE9BQU8sSUFBSSxTQUFTLElBQ2xCLFNBQVM7T0FDSixJQUFJLFNBQVMsTUFBUSxTQUFTLElBQU07R0FDekMsZUFBZSxDQUFDO0dBQ2hCLFFBQVEsSUFBSTtFQUNkO0NBQ0Y7Q0FFQSxlQUFlLElBQUksTUFBTTtDQUV6QixPQUFPO0FBQ1Q7QUFFQSxJQUFNLHFCQUFxQixRQUFRLGlDQUFpQyxLQUFLLElBQUksS0FBSyxDQUFDO0FBV25GLElBQU0sb0JBQW9CO0FBRTFCLElBQU0sY0FBYyxTQUFVLFNBQVMsY0FBYyxvQkFBb0I7QUFFekUsU0FBUyxpQkFBaUIsU0FBUyxPQUFPLFFBQVEsUUFBUSxvQkFBb0I7Q0FDNUUsSUFBSUEsY0FBTSxXQUFXLE1BQU0sR0FDekIsT0FBTyxPQUFPLEtBQUssU0FBUyxPQUFPLE1BQU07Q0FHM0MsSUFBSSxvQkFDRixRQUFRO0NBR1YsSUFBSSxDQUFDQSxjQUFNLFNBQVMsS0FBSyxHQUFHO0NBRTVCLElBQUlBLGNBQU0sU0FBUyxNQUFNLEdBQ3ZCLE9BQU8sTUFBTSxRQUFRLE1BQU0sTUFBTTtDQUduQyxJQUFJQSxjQUFNLFNBQVMsTUFBTSxHQUN2QixPQUFPLE9BQU8sS0FBSyxLQUFLO0FBRTVCO0FBRUEsU0FBUyxhQUFhLFFBQVE7Q0FDNUIsT0FBTyxPQUNKLEtBQUssQ0FBQyxDQUNOLFlBQVksQ0FBQyxDQUNiLFFBQVEsb0JBQW9CLEdBQUcsTUFBTSxRQUFRO0VBQzVDLE9BQU8sS0FBSyxZQUFZLElBQUk7Q0FDOUIsQ0FBQztBQUNMO0FBRUEsU0FBUyxlQUFlLEtBQUssUUFBUTtDQUNuQyxNQUFNLGVBQWVBLGNBQU0sWUFBWSxNQUFNLE1BQU07Q0FFbkQ7RUFBQztFQUFPO0VBQU87Q0FBSyxDQUFDLENBQUMsU0FBUyxlQUFlO0VBQzVDLE9BQU8sZUFBZSxLQUFLLGFBQWEsY0FBYztHQUdwRCxXQUFXO0dBQ1gsT0FBTyxTQUFVLE1BQU0sTUFBTSxNQUFNO0lBQ2pDLE9BQU8sS0FBSyxXQUFXLENBQUMsS0FBSyxNQUFNLFFBQVEsTUFBTSxNQUFNLElBQUk7R0FDN0Q7R0FDQSxjQUFjO0VBQ2hCLENBQUM7Q0FDSCxDQUFDO0FBQ0g7QUFFQSxJQUFNQyxpQkFBTixNQUFtQjtDQUNqQixZQUFZLFNBQVM7RUFDbkIsV0FBVyxLQUFLLElBQUksT0FBTztDQUM3QjtDQUVBLElBQUksUUFBUSxnQkFBZ0IsU0FBUztFQUNuQyxNQUFNLE9BQU87RUFFYixTQUFTLFVBQVUsUUFBUSxTQUFTLFVBQVU7R0FDNUMsTUFBTSxVQUFVLGdCQUFnQixPQUFPO0dBRXZDLElBQUksQ0FBQyxTQUNIO0dBR0YsTUFBTSxNQUFNRCxjQUFNLFFBQVEsTUFBTSxPQUFPO0dBRXZDLElBQ0UsQ0FBQyxPQUNELEtBQUssU0FBUyxLQUFBLEtBQ2QsYUFBYSxRQUNaLGFBQWEsS0FBQSxLQUFhLEtBQUssU0FBUyxPQUV6QyxLQUFLLFdBQVcsT0FBTyxPQUFPLEtBQUssZUFBZSxNQUFNO0VBRTVEO0VBRUEsTUFBTSxjQUFjLFNBQVMsYUFDM0JBLGNBQU0sUUFBUSxVQUFVLFFBQVEsWUFBWSxVQUFVLFFBQVEsU0FBUyxRQUFRLENBQUM7RUFFbEYsSUFBSUEsY0FBTSxjQUFjLE1BQU0sS0FBSyxrQkFBa0IsS0FBSyxhQUN4RCxXQUFXLFFBQVEsY0FBYztPQUM1QixJQUFJQSxjQUFNLFNBQVMsTUFBTSxNQUFNLFNBQVMsT0FBTyxLQUFLLE1BQU0sQ0FBQyxrQkFBa0IsTUFBTSxHQUN4RixXQUFXRSxxQkFBYSxNQUFNLEdBQUcsY0FBYztPQUMxQyxJQUFJRixjQUFNLFNBQVMsTUFBTSxLQUFLQSxjQUFNLGVBQWUsTUFBTSxHQUFHO0dBQ2pFLElBQUksTUFBTSxPQUFPLE9BQU8sSUFBSSxHQUMxQixNQUNBO0dBQ0YsS0FBSyxNQUFNLFNBQVMsUUFBUTtJQUMxQixJQUFJLENBQUNBLGNBQU0sUUFBUSxLQUFLLEdBQ3RCLE1BQU0sSUFBSSxVQUFVLDhDQUE4QztJQUdwRSxNQUFNLE1BQU07SUFFWixJQUFJQSxjQUFNLFdBQVcsS0FBSyxHQUFHLEdBQUc7S0FDOUIsT0FBTyxJQUFJO0tBQ1gsSUFBSSxPQUFPQSxjQUFNLFFBQVEsSUFBSSxJQUFJLENBQUMsR0FBRyxNQUFNLE1BQU0sRUFBRSxJQUFJLENBQUMsTUFBTSxNQUFNLEVBQUU7SUFDeEUsT0FDRSxJQUFJLE9BQU8sTUFBTTtHQUVyQjtHQUVBLFdBQVcsS0FBSyxjQUFjO0VBQ2hDLE9BQ0UsVUFBVSxRQUFRLFVBQVUsZ0JBQWdCLFFBQVEsT0FBTztFQUc3RCxPQUFPO0NBQ1Q7Q0FFQSxJQUFJLFFBQVEsUUFBUTtFQUNsQixTQUFTLGdCQUFnQixNQUFNO0VBRS9CLElBQUksUUFBUTtHQUNWLE1BQU0sTUFBTUEsY0FBTSxRQUFRLE1BQU0sTUFBTTtHQUV0QyxJQUFJLEtBQUs7SUFDUCxNQUFNLFFBQVEsS0FBSztJQUVuQixJQUFJLENBQUMsUUFDSCxPQUFPO0lBR1QsSUFBSSxXQUFXLE1BQ2IsT0FBTyxZQUFZLEtBQUs7SUFHMUIsSUFBSUEsY0FBTSxXQUFXLE1BQU0sR0FDekIsT0FBTyxPQUFPLEtBQUssTUFBTSxPQUFPLEdBQUc7SUFHckMsSUFBSUEsY0FBTSxTQUFTLE1BQU0sR0FDdkIsT0FBTyxPQUFPLEtBQUssS0FBSztJQUcxQixNQUFNLElBQUksVUFBVSx3Q0FBd0M7R0FDOUQ7RUFDRjtDQUNGO0NBRUEsSUFBSSxRQUFRLFNBQVM7RUFDbkIsU0FBUyxnQkFBZ0IsTUFBTTtFQUUvQixJQUFJLFFBQVE7R0FDVixNQUFNLE1BQU1BLGNBQU0sUUFBUSxNQUFNLE1BQU07R0FFdEMsT0FBTyxDQUFDLEVBQ04sT0FDQSxLQUFLLFNBQVMsS0FBQSxNQUNiLENBQUMsV0FBVyxpQkFBaUIsTUFBTSxLQUFLLE1BQU0sS0FBSyxPQUFPO0VBRS9EO0VBRUEsT0FBTztDQUNUO0NBRUEsT0FBTyxRQUFRLFNBQVM7RUFDdEIsTUFBTSxPQUFPO0VBQ2IsSUFBSSxVQUFVO0VBRWQsU0FBUyxhQUFhLFNBQVM7R0FDN0IsVUFBVSxnQkFBZ0IsT0FBTztHQUVqQyxJQUFJLFNBQVM7SUFDWCxNQUFNLE1BQU1BLGNBQU0sUUFBUSxNQUFNLE9BQU87SUFFdkMsSUFBSSxRQUFRLENBQUMsV0FBVyxpQkFBaUIsTUFBTSxLQUFLLE1BQU0sS0FBSyxPQUFPLElBQUk7S0FDeEUsT0FBTyxLQUFLO0tBRVosVUFBVTtJQUNaO0dBQ0Y7RUFDRjtFQUVBLElBQUlBLGNBQU0sUUFBUSxNQUFNLEdBQ3RCLE9BQU8sUUFBUSxZQUFZO09BRTNCLGFBQWEsTUFBTTtFQUdyQixPQUFPO0NBQ1Q7Q0FFQSxNQUFNLFNBQVM7RUFDYixNQUFNLE9BQU8sT0FBTyxLQUFLLElBQUk7RUFDN0IsSUFBSSxJQUFJLEtBQUs7RUFDYixJQUFJLFVBQVU7RUFFZCxPQUFPLEtBQUs7R0FDVixNQUFNLE1BQU0sS0FBSztHQUNqQixJQUFJLENBQUMsV0FBVyxpQkFBaUIsTUFBTSxLQUFLLE1BQU0sS0FBSyxTQUFTLElBQUksR0FBRztJQUNyRSxPQUFPLEtBQUs7SUFDWixVQUFVO0dBQ1o7RUFDRjtFQUVBLE9BQU87Q0FDVDtDQUVBLFVBQVUsUUFBUTtFQUNoQixNQUFNLE9BQU87RUFDYixNQUFNLFVBQVUsT0FBTyxPQUFPLElBQUk7RUFFbEMsY0FBTSxRQUFRLE9BQU8sT0FBTyxXQUFXO0dBQ3JDLE1BQU0sTUFBTUEsY0FBTSxRQUFRLFNBQVMsTUFBTTtHQUV6QyxJQUFJLEtBQUs7SUFDUCxLQUFLLE9BQU8sZUFBZSxLQUFLO0lBQ2hDLE9BQU8sS0FBSztJQUNaO0dBQ0Y7R0FFQSxNQUFNLGFBQWEsV0FBVyxTQUFTLGFBQWEsTUFBTSxJQUFJLE9BQU8sTUFBTSxDQUFDLENBQUMsS0FBSyxDQUFDO0dBRW5GLElBQUksZUFBZSxRQUNqQixPQUFPLEtBQUs7R0FHZCxLQUFLLGNBQWMsZUFBZSxLQUFLO0dBRXZDLFFBQVEsY0FBYztFQUN4QixDQUFDO0VBRUQsT0FBTztDQUNUO0NBRUEsT0FBTyxHQUFHLFNBQVM7RUFDakIsT0FBTyxLQUFLLFlBQVksT0FBTyxNQUFNLEdBQUcsT0FBTztDQUNqRDtDQUVBLE9BQU8sV0FBVztFQUNoQixNQUFNLE1BQU0sT0FBTyxPQUFPLElBQUk7RUFFOUIsY0FBTSxRQUFRLE9BQU8sT0FBTyxXQUFXO0dBQ3JDLFNBQVMsUUFDUCxVQUFVLFVBQ1QsSUFBSSxVQUFVLGFBQWFBLGNBQU0sUUFBUSxLQUFLLElBQUksTUFBTSxLQUFLLElBQUksSUFBSTtFQUMxRSxDQUFDO0VBRUQsT0FBTztDQUNUO0NBRUEsQ0FBQyxPQUFPLFlBQVk7RUFDbEIsT0FBTyxPQUFPLFFBQVEsS0FBSyxPQUFPLENBQUMsQ0FBQyxDQUFDLE9BQU8sU0FBUyxDQUFDO0NBQ3hEO0NBRUEsV0FBVztFQUNULE9BQU8sT0FBTyxRQUFRLEtBQUssT0FBTyxDQUFDLENBQUMsQ0FDakMsS0FBSyxDQUFDLFFBQVEsV0FBVyxTQUFTLE9BQU8sS0FBSyxDQUFDLENBQy9DLEtBQUssSUFBSTtDQUNkO0NBRUEsZUFBZTtFQUNiLE1BQU0sUUFBUSxLQUFLLElBQUksWUFBWTtFQUNuQyxPQUFPQSxjQUFNLFFBQVEsS0FBSyxJQUFJLFFBQVEsU0FBUyxRQUFRLFVBQVUsUUFBUSxDQUFDLElBQUksQ0FBQyxLQUFLO0NBQ3RGO0NBRUEsS0FBSyxPQUFPLGVBQWU7RUFDekIsT0FBTztDQUNUO0NBRUEsT0FBTyxLQUFLLE9BQU87RUFDakIsT0FBTyxpQkFBaUIsT0FBTyxRQUFRLElBQUksS0FBSyxLQUFLO0NBQ3ZEO0NBRUEsT0FBTyxnQkFBZ0IsT0FBTztFQUM1QixPQUFPLGdCQUFnQixLQUFLO0NBQzlCO0NBRUEsT0FBTyxPQUFPLE9BQU8sR0FBRyxTQUFTO0VBQy9CLE1BQU0sV0FBVyxJQUFJLEtBQUssS0FBSztFQUUvQixRQUFRLFNBQVMsV0FBVyxTQUFTLElBQUksTUFBTSxDQUFDO0VBRWhELE9BQU87Q0FDVDtDQUVBLE9BQU8sU0FBUyxRQUFRO0VBUXRCLE1BQU0sYUFBWSxLQU5WRCxnQkFDTixLQUFLQSxnQkFDSCxFQUNFLFdBQVcsQ0FBQyxFQUNkLEVBQUEsQ0FFd0I7RUFDNUIsTUFBTSxZQUFZLEtBQUs7RUFFdkIsU0FBUyxlQUFlLFNBQVM7R0FDL0IsTUFBTSxVQUFVLGdCQUFnQixPQUFPO0dBRXZDLElBQUksQ0FBQyxVQUFVLFVBQVU7SUFDdkIsZUFBZSxXQUFXLE9BQU87SUFDakMsVUFBVSxXQUFXO0dBQ3ZCO0VBQ0Y7RUFFQSxjQUFNLFFBQVEsTUFBTSxJQUFJLE9BQU8sUUFBUSxjQUFjLElBQUksZUFBZSxNQUFNO0VBRTlFLE9BQU87Q0FDVDtBQUNGO0FBRUFFLGVBQWEsU0FBUztDQUNwQjtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7QUFDRixDQUFDO0FBR0RELGNBQU0sa0JBQWtCQyxlQUFhLFlBQVksRUFBRSxTQUFTLFFBQVE7Q0FDbEUsSUFBSSxTQUFTLElBQUksRUFBRSxDQUFDLFlBQVksSUFBSSxJQUFJLE1BQU0sQ0FBQztDQUMvQyxPQUFPO0VBQ0wsV0FBVztFQUNYLElBQUksYUFBYTtHQUNmLEtBQUssVUFBVTtFQUNqQjtDQUNGO0FBQ0YsQ0FBQztBQUVERCxjQUFNLGNBQWNDLGNBQVk7O0FDL2RoQyxJQUFhLFdBQVc7QUFFeEIsU0FBUyx3QkFBd0IsUUFBUTtDQUN2QyxJQUFJRSxjQUFNLFdBQVcsUUFBUSxRQUFRLEdBQ25DLE9BQU87Q0FHVCxJQUFJLFlBQVksT0FBTyxlQUFlLE1BQU07Q0FFNUMsT0FBTyxhQUFhLGNBQWMsT0FBTyxXQUFXO0VBQ2xELElBQUlBLGNBQU0sV0FBVyxXQUFXLFFBQVEsR0FDdEMsT0FBTztFQUdULFlBQVksT0FBTyxlQUFlLFNBQVM7Q0FDN0M7Q0FFQSxPQUFPO0FBQ1Q7QUFLQSxTQUFTLGFBQWEsUUFBUSxZQUFZO0NBQ3hDLE1BQU0sWUFBWSxJQUFJLElBQUksV0FBVyxLQUFLLE1BQU0sT0FBTyxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQztDQUN4RSxNQUFNLE9BQU8sQ0FBQztDQUVkLE1BQU0sU0FBUyxXQUFXO0VBQ3hCLElBQUksV0FBVyxRQUFRLE9BQU8sV0FBVyxVQUFVLE9BQU87RUFDMUQsSUFBSUEsY0FBTSxTQUFTLE1BQU0sR0FBRyxPQUFPO0VBQ25DLElBQUksS0FBSyxRQUFRLE1BQU0sTUFBTSxJQUFJLE9BQU8sS0FBQTtFQUV4QyxJQUFJLGtCQUFrQkMsZ0JBQ3BCLFNBQVMsT0FBTyxPQUFPO0VBR3pCLEtBQUssS0FBSyxNQUFNO0VBRWhCLElBQUk7RUFDSixJQUFJRCxjQUFNLFFBQVEsTUFBTSxHQUFHO0dBQ3pCLFNBQVMsQ0FBQztHQUNWLE9BQU8sU0FBUyxHQUFHLE1BQU07SUFDdkIsTUFBTSxlQUFlLE1BQU0sQ0FBQztJQUM1QixJQUFJLENBQUNBLGNBQU0sWUFBWSxZQUFZLEdBQ2pDLE9BQU8sS0FBSztHQUVoQixDQUFDO0VBQ0gsT0FBTztHQUNMLElBQUksQ0FBQ0EsY0FBTSxjQUFjLE1BQU0sS0FBSyx3QkFBd0IsTUFBTSxHQUFHO0lBQ25FLEtBQUssSUFBSTtJQUNULE9BQU87R0FDVDtHQUVBLFNBQVMsT0FBTyxPQUFPLElBQUk7R0FDM0IsS0FBSyxNQUFNLENBQUMsS0FBSyxVQUFVLE9BQU8sUUFBUSxNQUFNLEdBQUc7SUFDakQsTUFBTSxlQUFlLFVBQVUsSUFBSSxJQUFJLFlBQVksQ0FBQyxJQUFJLFdBQVcsTUFBTSxLQUFLO0lBQzlFLElBQUksQ0FBQ0EsY0FBTSxZQUFZLFlBQVksR0FDakMsT0FBTyxPQUFPO0dBRWxCO0VBQ0Y7RUFFQSxLQUFLLElBQUk7RUFDVCxPQUFPO0NBQ1Q7Q0FFQSxPQUFPLE1BQU0sTUFBTTtBQUNyQjtBQUVBLFNBQVNFLGtCQUFnQixPQUFPO0NBQzlCLElBQUk7RUFDRixPQUFPLE9BQU8sS0FBSztDQUNyQixTQUFTLEtBQUs7RUFDWixPQUFPO0NBQ1Q7QUFDRjtBQUVBLFNBQVMsc0JBQXNCLE9BQU87Q0FZcEMsT0FYZ0IsTUFBTSxPQUNuQixLQUFLLFVBQVU7RUFDZCxJQUFJO0dBQ0YsT0FBTyxTQUFTLE1BQU0sVUFBVUEsa0JBQWdCLE1BQU0sT0FBTyxJQUFJQSxrQkFBZ0IsS0FBSztFQUN4RixTQUFTLEtBQUs7R0FDWixPQUFPO0VBQ1Q7Q0FDRixDQUFDLENBQUMsQ0FDRCxPQUFPLE9BQU8sQ0FBQyxDQUNmLEtBQUssSUFFSyxLQUFLLE1BQU0sUUFBUTtBQUNsQztBQUlBLElBQWEsc0JBQXNCO0FBQ25DLElBQU0sY0FBYyxPQUFPLFlBQVk7QUFJdkMsU0FBZ0IsbUJBQW1CLE9BQU8sT0FBTztDQUMvQyxNQUFNLGFBQWFGLGNBQU0sV0FBVyxPQUFPLFdBQVcsS0FBSyxNQUFNO0NBRWpFLE9BQU8sY0FBYyxNQUFNLFNBQVMsVUFBVSxJQUFJLE1BQU0sU0FBUyxXQUFXLFNBQVM7QUFDdkY7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFvQkEsU0FBUyxpQkFBaUIsUUFBUSxRQUFRO0NBQ3hDLElBQUk7RUFDRixNQUFNLGNBQWMsVUFBVSxPQUFPO0VBRXJDLElBQUksT0FBTyxnQkFBZ0IsWUFBWSxDQUFDLGFBQ3RDO0VBR0YsTUFBTSxjQUFjLE9BQU87RUFFM0IsSUFBSSxPQUFPLGdCQUFnQixZQUFZLENBQUMsYUFDdEM7RUFLRixNQUFNLGFBQWEsc0JBQXNCO0VBQ3pDLE9BQU8sUUFBUSxjQUFjO0VBQzdCLE9BQU8sZUFBZSxRQUFRLGFBQWE7R0FBRSxXQUFXO0dBQU0sT0FBTztFQUFXLENBQUM7Q0FDbkYsU0FBUyxHQUFHLENBRVo7QUFDRjtBQUVBLElBQU1HLGVBQU4sTUFBTUEscUJBQW1CLE1BQU07Q0FDN0IsT0FBTyxLQUFLLE9BQU8sTUFBTSxRQUFRLFNBQVMsVUFBVSxhQUFhO0VBSS9ELElBQUksVUFBVSxNQUFNO0VBQ3BCLElBQUksQ0FBQyxXQUFXSCxjQUFNLFFBQVEsTUFBTSxNQUFNLEtBQUssTUFBTSxPQUFPLFFBQzFELFVBQVUsc0JBQXNCLEtBQUs7RUFHdkMsTUFBTSxhQUFhLElBQUlHLGFBQVcsU0FBUyxRQUFRLE1BQU0sTUFBTSxRQUFRLFNBQVMsUUFBUTtFQU94RixPQUFPLGVBQWUsWUFBWSxTQUFTO0dBQ3pDLFdBQVc7R0FDWCxPQUFPO0dBQ1AsVUFBVTtHQUNWLFlBQVk7R0FDWixjQUFjO0VBQ2hCLENBQUM7RUFDRCxXQUFXLE9BQU8sTUFBTTtFQUl4QixpQkFBaUIsWUFBWSxLQUFLO0VBR2xDLElBQUksTUFBTSxVQUFVLFFBQVEsV0FBVyxVQUFVLE1BQy9DLFdBQVcsU0FBUyxNQUFNO0VBRzVCLGVBQWUsT0FBTyxPQUFPLFlBQVksV0FBVztFQUNwRCxPQUFPO0NBQ1Q7Ozs7Ozs7Ozs7OztDQWFBLFlBQVksU0FBUyxNQUFNLFFBQVEsU0FBUyxVQUFVO0VBQ3BELE1BQU0sT0FBTztFQUtiLE9BQU8sZUFBZSxNQUFNLFdBQVc7R0FHckMsV0FBVztHQUNYLE9BQU87R0FDUCxZQUFZO0dBQ1osVUFBVTtHQUNWLGNBQWM7RUFDaEIsQ0FBQztFQUVELEtBQUssT0FBTztFQUNaLEtBQUssZUFBZTtFQUNwQixTQUFTLEtBQUssT0FBTztFQUNyQixXQUFXLEtBQUssU0FBUztFQUN6QixZQUFZLEtBQUssVUFBVTtFQUMzQixJQUFJLFVBQVU7R0FDWixLQUFLLFdBQVc7R0FDaEIsS0FBSyxTQUFTLFNBQVM7RUFDekI7Q0FDRjtDQUVBLFNBQVM7RUFLUCxNQUFNLFNBQVMsS0FBSztFQUNwQixNQUFNLGFBQWEsVUFBVUgsY0FBTSxXQUFXLFFBQVEsUUFBUSxJQUFJLE9BQU8sU0FBUyxLQUFBO0VBQ2xGLE1BQU0sbUJBQ0pBLGNBQU0sUUFBUSxVQUFVLEtBQUssV0FBVyxTQUFTLElBQzdDLGFBQWEsUUFBUSxVQUFVLElBQy9CQSxjQUFNLGFBQWEsTUFBTTtFQUUvQixPQUFPO0dBRUwsU0FBUyxLQUFLO0dBQ2QsTUFBTSxLQUFLO0dBRVgsYUFBYSxLQUFLO0dBQ2xCLFFBQVEsS0FBSztHQUViLFVBQVUsS0FBSztHQUNmLFlBQVksS0FBSztHQUNqQixjQUFjLEtBQUs7R0FDbkIsT0FBTyxLQUFLO0dBRVosUUFBUTtHQUNSLE1BQU0sS0FBSztHQUNYLFFBQVEsS0FBSztFQUNmO0NBQ0Y7QUFDRjtBQUdBLGFBQVcsdUJBQXVCO0FBQ2xDLGFBQVcsaUJBQWlCO0FBQzVCLGFBQVcsZUFBZTtBQUMxQixhQUFXLFlBQVk7QUFDdkIsYUFBVyxlQUFlO0FBQzFCLGFBQVcsY0FBYztBQUN6QixhQUFXLDRCQUE0QjtBQUN2QyxhQUFXLGlCQUFpQjtBQUM1QixhQUFXLG1CQUFtQjtBQUM5QixhQUFXLGtCQUFrQjtBQUM3QixhQUFXLGVBQWU7QUFDMUIsYUFBVyxrQkFBa0I7QUFDN0IsYUFBVyxrQkFBa0I7QUFDN0IsYUFBVywrQkFBK0I7Ozs7Ozs7O0FDaFExQyxTQUFTLFlBQVksT0FBTztDQUMxQixPQUFPSSxjQUFNLGNBQWMsS0FBSyxLQUFLQSxjQUFNLFFBQVEsS0FBSztBQUMxRDs7Ozs7Ozs7QUFTQSxTQUFTLGVBQWUsS0FBSztDQUMzQixPQUFPQSxjQUFNLFNBQVMsS0FBSyxJQUFJLElBQUksSUFBSSxNQUFNLEdBQUcsRUFBRSxJQUFJO0FBQ3hEOzs7Ozs7Ozs7O0FBV0EsU0FBUyxVQUFVLE1BQU0sS0FBSyxNQUFNO0NBQ2xDLElBQUksQ0FBQyxNQUFNLE9BQU87Q0FDbEIsT0FBTyxLQUNKLE9BQU8sR0FBRyxDQUFDLENBQ1gsSUFBSSxTQUFTLEtBQUssT0FBTyxHQUFHO0VBRTNCLFFBQVEsZUFBZSxLQUFLO0VBQzVCLE9BQU8sQ0FBQyxRQUFRLElBQUksTUFBTSxRQUFRLE1BQU07Q0FDMUMsQ0FBQyxDQUFDLENBQ0QsS0FBSyxPQUFPLE1BQU0sRUFBRTtBQUN6Qjs7Ozs7Ozs7QUFTQSxTQUFTLFlBQVksS0FBSztDQUN4QixPQUFPQSxjQUFNLFFBQVEsR0FBRyxLQUFLLENBQUMsSUFBSSxLQUFLLFdBQVc7QUFDcEQ7QUFFQSxJQUFNLGFBQWFBLGNBQU0sYUFBYUEsZUFBTyxDQUFDLEdBQUcsTUFBTSxTQUFTLE9BQU8sTUFBTTtDQUMzRSxPQUFPLFdBQVcsS0FBSyxJQUFJO0FBQzdCLENBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBeUJELFNBQVNDLGFBQVcsS0FBSyxVQUFVLFNBQVM7Q0FDMUMsSUFBSSxDQUFDRCxjQUFNLFNBQVMsR0FBRyxHQUNyQixNQUFNLElBQUksVUFBVSwwQkFBMEI7Q0FJaEQsV0FBVyxZQUFZLElBQXlCLFNBQVU7Q0FFMUQsTUFBTSxVQUFVLE1BQU0sYUFBYTtFQUNqQyxNQUFNLFFBQVFBLGNBQU0sWUFBWSxTQUFTLElBQUk7RUFDN0MsT0FBT0EsY0FBTSxZQUFZLEtBQUssSUFBSSxXQUFXO0NBQy9DO0NBRUEsTUFBTSxhQUFhLE9BQU8sY0FBYyxJQUFJO0NBRTVDLE1BQU0sVUFBVSxPQUFPLFNBQVMsS0FBSztDQUNyQyxNQUFNLE9BQU8sT0FBTyxRQUFRLEtBQUs7Q0FDakMsTUFBTSxVQUFVLE9BQU8sV0FBVyxLQUFLO0NBQ3ZDLE1BQU0sUUFBUSxPQUFPLE1BQU0sS0FBTSxPQUFPLFNBQVMsZUFBZTtDQUNoRSxNQUFNLFdBQVcsT0FBTyxZQUFBLEdBQXVDO0NBQy9ELE1BQU0sVUFBVSxTQUFTQSxjQUFNLG9CQUFvQixRQUFRO0NBQzNELE1BQU0sUUFBUSxDQUFDO0NBRWYsSUFBSSxDQUFDQSxjQUFNLFdBQVcsT0FBTyxHQUMzQixNQUFNLElBQUksVUFBVSw0QkFBNEI7Q0FHbEQsU0FBUyxhQUFhLE9BQU87RUFDM0IsSUFBSSxVQUFVLE1BQU0sT0FBTztFQUUzQixJQUFJQSxjQUFNLE9BQU8sS0FBSyxHQUNwQixPQUFPLE1BQU0sWUFBWTtFQUczQixJQUFJQSxjQUFNLFVBQVUsS0FBSyxHQUN2QixPQUFPLE1BQU0sU0FBUztFQUd4QixJQUFJLENBQUMsV0FBV0EsY0FBTSxPQUFPLEtBQUssR0FDaEMsTUFBTSxJQUFJRSxhQUFXLDhDQUE4QztFQUdyRSxJQUFJRixjQUFNLGNBQWMsS0FBSyxLQUFLQSxjQUFNLGFBQWEsS0FBSyxHQUFHO0dBQzNELElBQUksV0FBVyxPQUFPLFVBQVUsWUFDOUIsT0FBTyxJQUFJLE1BQU0sQ0FBQyxLQUFLLENBQUM7R0FLMUIsTUFBTSxJQUFJRSxhQUNSLGdEQUNBQSxhQUFXLGVBQ2I7RUFDRjtFQUVBLE9BQU87Q0FDVDtDQUVBLFNBQVMsd0JBQXdCLE9BQU87RUFDdEMsSUFBSSxRQUFRLFVBQ1YsTUFBTSxJQUFJQSxhQUNSLGtDQUFrQyxRQUFRLDBCQUEwQixVQUNwRUEsYUFBVyw0QkFDYjtDQUVKO0NBRUEsU0FBUyx3QkFBd0IsT0FBTyxPQUFPO0VBQzdDLElBQUksYUFBYSxVQUNmLE9BQU8sS0FBSyxVQUFVLEtBQUs7RUFHN0IsTUFBTSxZQUFZLENBQUM7RUFFbkIsT0FBTyxLQUFLLFVBQVUsT0FBTyxTQUFTLFdBQVcsTUFBTSxjQUFjO0dBQ25FLElBQUksQ0FBQ0YsY0FBTSxTQUFTLFlBQVksR0FDOUIsT0FBTztHQUdULE9BQU8sVUFBVSxVQUFVLFVBQVUsVUFBVSxTQUFTLE9BQU8sTUFDN0QsVUFBVSxJQUFJO0dBR2hCLFVBQVUsS0FBSyxZQUFZO0dBQzNCLHdCQUF3QixRQUFRLFVBQVUsU0FBUyxDQUFDO0dBRXBELE9BQU87RUFDVCxDQUFDO0NBQ0g7Ozs7Ozs7Ozs7O0NBWUEsU0FBUyxlQUFlLE9BQU8sS0FBSyxNQUFNO0VBQ3hDLElBQUksTUFBTTtFQUVWLElBQUlBLGNBQU0sY0FBYyxRQUFRLEtBQUtBLGNBQU0sa0JBQWtCLEtBQUssR0FBRztHQUNuRSxTQUFTLE9BQU8sVUFBVSxNQUFNLEtBQUssSUFBSSxHQUFHLGFBQWEsS0FBSyxDQUFDO0dBQy9ELE9BQU87RUFDVDtFQUVBLElBQUksU0FBUyxDQUFDLFFBQVEsT0FBTyxVQUFVLFVBQVU7R0FDL0MsSUFBSUEsY0FBTSxTQUFTLEtBQUssSUFBSSxHQUFHO0lBRTdCLE1BQU0sYUFBYSxNQUFNLElBQUksTUFBTSxHQUFHLEVBQUU7SUFFeEMsUUFBUSx3QkFBd0IsT0FBTyxDQUFDO0dBQzFDLE9BQU8sSUFDSkEsY0FBTSxRQUFRLEtBQUssS0FBSyxZQUFZLEtBQUssTUFDeENBLGNBQU0sV0FBVyxLQUFLLEtBQUtBLGNBQU0sU0FBUyxLQUFLLElBQUksT0FBTyxNQUFNQSxjQUFNLFFBQVEsS0FBSyxJQUNyRjtJQUVBLE1BQU0sZUFBZSxHQUFHO0lBRXhCLElBQUksUUFBUSxTQUFTLEtBQUssSUFBSSxPQUFPO0tBQ25DLEVBQUVBLGNBQU0sWUFBWSxFQUFFLEtBQUssT0FBTyxTQUNoQyxTQUFTLE9BRVAsWUFBWSxPQUNSLFVBQVUsQ0FBQyxHQUFHLEdBQUcsT0FBTyxJQUFJLElBQzVCLFlBQVksT0FDVixNQUNBLE1BQU0sTUFDWixhQUFhLEVBQUUsQ0FDakI7SUFDSixDQUFDO0lBQ0QsT0FBTztHQUNUO0VBQ0Y7RUFFQSxJQUFJLFlBQVksS0FBSyxHQUNuQixPQUFPO0VBR1QsU0FBUyxPQUFPLFVBQVUsTUFBTSxLQUFLLElBQUksR0FBRyxhQUFhLEtBQUssQ0FBQztFQUUvRCxPQUFPO0NBQ1Q7Q0FFQSxNQUFNLGlCQUFpQixPQUFPLE9BQU8sWUFBWTtFQUMvQztFQUNBO0VBQ0E7Q0FDRixDQUFDO0NBRUQsU0FBUyxNQUFNLE9BQU8sTUFBTSxRQUFRLEdBQUc7RUFDckMsSUFBSUEsY0FBTSxZQUFZLEtBQUssR0FBRztFQUU5Qix3QkFBd0IsS0FBSztFQUU3QixJQUFJLE1BQU0sUUFBUSxLQUFLLE1BQU0sSUFDM0IsTUFBTSxJQUFJLE1BQU0sb0NBQW9DLEtBQUssS0FBSyxHQUFHLENBQUM7RUFHcEUsTUFBTSxLQUFLLEtBQUs7RUFFaEIsY0FBTSxRQUFRLE9BQU8sU0FBUyxLQUFLLElBQUksS0FBSztHQUsxQyxLQUhFLEVBQUVBLGNBQU0sWUFBWSxFQUFFLEtBQUssT0FBTyxTQUNsQyxRQUFRLEtBQUssVUFBVSxJQUFJQSxjQUFNLFNBQVMsR0FBRyxJQUFJLElBQUksS0FBSyxJQUFJLEtBQUssTUFBTSxjQUFjLE9BRTFFLE1BQ2IsTUFBTSxJQUFJLE9BQU8sS0FBSyxPQUFPLEdBQUcsSUFBSSxDQUFDLEdBQUcsR0FBRyxRQUFRLENBQUM7RUFFeEQsQ0FBQztFQUVELE1BQU0sSUFBSTtDQUNaO0NBRUEsSUFBSSxDQUFDQSxjQUFNLFNBQVMsR0FBRyxHQUNyQixNQUFNLElBQUksVUFBVSx3QkFBd0I7Q0FHOUMsTUFBTSxHQUFHO0NBRVQsT0FBTztBQUNUOzs7Ozs7Ozs7O0FDeFFBLFNBQVNHLFNBQU8sS0FBSztDQUNuQixNQUFNLFVBQVU7RUFDZCxLQUFLO0VBQ0wsS0FBSztFQUNMLEtBQUs7RUFDTCxLQUFLO0VBQ0wsS0FBSztFQUNMLE9BQU87Q0FDVDtDQUNBLE9BQU8sbUJBQW1CLEdBQUcsQ0FBQyxDQUFDLFFBQVEsZ0JBQWdCLFNBQVMsU0FBUyxPQUFPO0VBQzlFLE9BQU8sUUFBUTtDQUNqQixDQUFDO0FBQ0g7Ozs7Ozs7OztBQVVBLFNBQVMscUJBQXFCLFFBQVEsU0FBUztDQUM3QyxLQUFLLFNBQVMsQ0FBQztDQUVmLFVBQVVDLGFBQVcsUUFBUSxNQUFNLE9BQU87QUFDNUM7QUFFQSxJQUFNLFlBQVkscUJBQXFCO0FBRXZDLFVBQVUsU0FBUyxTQUFTLE9BQU8sTUFBTSxPQUFPO0NBQzlDLEtBQUssT0FBTyxLQUFLLENBQUMsTUFBTSxLQUFLLENBQUM7QUFDaEM7QUFFQSxVQUFVLFdBQVcsU0FBUyxTQUFTLFNBQVM7Q0FDOUMsTUFBTSxVQUFVLFdBQ1gsVUFBVSxRQUFRLEtBQUssTUFBTSxPQUFPRCxRQUFNLElBQzNDQTtDQUVKLE9BQU8sS0FBSyxPQUNULElBQUksU0FBUyxLQUFLLE1BQU07RUFDdkIsT0FBTyxRQUFRLEtBQUssRUFBRSxJQUFJLE1BQU0sUUFBUSxLQUFLLEVBQUU7Q0FDakQsR0FBRyxFQUFFLENBQUMsQ0FDTCxLQUFLLEdBQUc7QUFDYjs7Ozs7Ozs7OztBQzNDQSxTQUFnQixPQUFPLEtBQUs7Q0FDMUIsT0FBTyxtQkFBbUIsR0FBRyxDQUFDLENBQzNCLFFBQVEsU0FBUyxHQUFHLENBQUMsQ0FDckIsUUFBUSxRQUFRLEdBQUcsQ0FBQyxDQUNwQixRQUFRLFNBQVMsR0FBRyxDQUFDLENBQ3JCLFFBQVEsUUFBUSxHQUFHO0FBQ3hCOzs7Ozs7Ozs7O0FBV0EsU0FBd0IsU0FBUyxLQUFLLFFBQVEsU0FBUztDQUNyRCxJQUFJLENBQUMsUUFDSCxPQUFPO0NBRVQsTUFBTSxPQUFPO0NBRWIsTUFBTSxXQUFXRSxjQUFNLFdBQVcsT0FBTyxJQUNyQyxFQUNFLFdBQVcsUUFDYixJQUNBO0NBS0osTUFBTSxVQUFVQSxjQUFNLFlBQVksVUFBVSxRQUFRLEtBQUs7Q0FDekQsTUFBTSxjQUFjQSxjQUFNLFlBQVksVUFBVSxXQUFXO0NBRTNELElBQUk7Q0FFSixJQUFJLGFBQ0YsbUJBQW1CLFlBQVksUUFBUSxRQUFRO01BRS9DLG1CQUFtQkEsY0FBTSxrQkFBa0IsTUFBTSxJQUM3QyxPQUFPLFNBQVMsSUFDaEIsSUFBSSxxQkFBcUIsUUFBUSxRQUFRLENBQUMsQ0FBQyxTQUFTLE9BQU87Q0FHakUsSUFBSSxrQkFBa0I7RUFDcEIsTUFBTSxnQkFBZ0IsSUFBSSxRQUFRLEdBQUc7RUFFckMsSUFBSSxrQkFBa0IsSUFDcEIsTUFBTSxJQUFJLE1BQU0sR0FBRyxhQUFhO0VBRWxDLFFBQVEsSUFBSSxRQUFRLEdBQUcsTUFBTSxLQUFLLE1BQU0sT0FBTztDQUNqRDtDQUVBLE9BQU87QUFDVDs7QUNoRUEsSUFBTSxhQUFhLE9BQU8sV0FBVztBQUtyQyxTQUFTLGNBQWMsVUFBVTtDQUMvQixPQUFPLFdBQVcsU0FBUyxTQUFTO0FBQ3RDO0FBRUEsU0FBUyxhQUFhLFVBQVU7Q0FDOUIsSUFBSSxDQUFDLFVBQ0g7Q0FHRixPQUFPLFNBQVMsVUFBVSxTQUFTLFNBQVMsU0FBUyxPQUFPLE1BQzFELFNBQVMsSUFBSTtBQUVqQjtBQUlBLFNBQVMsbUJBQW1CLElBQUk7Q0FDOUIsSUFBSSxPQUFPLE9BQU8sWUFBWSxPQUFPLE1BQU0sT0FBTyxPQUFPLEVBQUUsQ0FBQyxNQUFNLElBQ2hFLE9BQU8sT0FBTyxFQUFFO0NBR2xCLE9BQU87QUFDVDtBQUVBLFNBQVMsbUJBQW1CLFNBQVMsV0FBVztDQUM5QyxNQUFNLFdBQVcsUUFBUTtDQUN6QixNQUFNLFNBQVMsY0FBYyxRQUFRO0NBRXJDLElBQUksYUFBYSxVQUFVLGFBQWE7RUFDdEMsVUFBVSxjQUFjO0VBQ3hCLFVBQVUsZUFBZSxNQUFNO0NBQ2pDLE9BQU8sSUFBSSxXQUFXLFVBQVUsZ0JBQWdCO0VBQzlDLElBQUksQ0FBQyxRQUNILFVBQVUsZUFBZSxNQUFNO09BRS9CLFVBQVUsZUFBZSxRQUFRLFNBQVMsaUJBQWlCLE9BQU8sSUFBSTtHQUNwRSxJQUFJLFNBQVMsTUFBTSxXQUFXLE1BQU0sU0FDbEMsVUFBVSxlQUFlLE9BQU8sRUFBRTtFQUV0QyxDQUFDO0NBRUw7Q0FFQSxVQUFVLGlCQUFpQjtBQUM3QjtBQUVBLElBQU0scUJBQU4sTUFBeUI7Q0FDdkIsY0FBYztFQUNaLEtBQUssV0FBVyxDQUFDO0VBQ2pCLEtBQUssY0FBYztHQUNqQixhQUFhLEtBQUs7R0FDbEIsZ0JBQWdCLEtBQUssU0FBUztHQUM5QixnQ0FBZ0IsSUFBSSxJQUFJO0dBQ3hCLGdCQUFnQjtHQUNoQixRQUFRO0VBQ1Y7Q0FDRjs7Ozs7Ozs7OztDQVdBLElBQUksV0FBVyxVQUFVLFNBQVM7RUFDaEMsTUFBTSxVQUFVO0dBQ2Q7R0FDQTtHQUNBLGFBQWEsVUFBVSxRQUFRLGNBQWM7R0FDN0MsU0FBUyxVQUFVLFFBQVEsVUFBVTtFQUN2QztFQUNBLE1BQU0sWUFBWSxLQUFLO0VBRXZCLElBQUksS0FBSyxZQUFZLE1BQ25CLEtBQUssV0FBVyxDQUFDO0VBR25CLG1CQUFtQixNQUFNLFNBQVM7RUFFbEMsTUFBTSxLQUFLLFVBQVU7RUFFckIsS0FBSyxTQUFTLEtBQUssT0FBTztFQUMxQixVQUFVLGVBQWUsSUFBSSxJQUFJO0dBQy9CO0dBQ0EsT0FBTyxLQUFLLFNBQVMsU0FBUztFQUNoQyxDQUFDO0VBQ0QsVUFBVSxpQkFBaUIsS0FBSyxTQUFTO0VBRXpDLE9BQU87Q0FDVDs7Ozs7Ozs7Q0FTQSxNQUFNLElBQUk7RUFDUixNQUFNLFlBQVksS0FBSztFQUV2QixtQkFBbUIsTUFBTSxTQUFTO0VBRWxDLE1BQU0sWUFBWSxtQkFBbUIsRUFBRTtFQUN2QyxNQUFNLFFBQVEsVUFBVSxlQUFlLElBQUksU0FBUztFQUVwRCxJQUFJLE9BQU87R0FDVCxVQUFVLGVBQWUsT0FBTyxTQUFTO0dBR3pDLElBQUksS0FBSyxTQUFTLE1BQU0sV0FBVyxNQUFNLFNBQ3ZDO0dBR0YsS0FBSyxTQUFTLE1BQU0sU0FBUztHQUc3QixJQUFJLENBQUMsVUFBVSxnQkFBZ0I7SUFDN0IsYUFBYSxLQUFLLFFBQVE7SUFDMUIsVUFBVSxpQkFBaUIsS0FBSyxTQUFTO0dBQzNDO0VBQ0Y7Q0FDRjs7Ozs7O0NBT0EsUUFBUTtFQUNOLElBQUksS0FBSyxVQUFVO0dBQ2pCLEtBQUssV0FBVyxDQUFDO0dBQ2pCLG1CQUFtQixNQUFNLEtBQUssV0FBVztFQUMzQztDQUNGOzs7Ozs7Ozs7OztDQVlBLFFBQVEsSUFBSTtFQUNWLE1BQU0sWUFBWSxLQUFLO0VBRXZCLG1CQUFtQixNQUFNLFNBQVM7RUFFbEMsVUFBVTtFQUVWLElBQUk7R0FDRixjQUFNLFFBQVEsS0FBSyxVQUFVLFNBQVMsZUFBZSxHQUFHO0lBQ3RELElBQUksTUFBTSxNQUNSLEdBQUcsQ0FBQztHQUVSLENBQUM7RUFDSCxVQUFVO0dBQ1IsSUFBSSxDQUFDLEVBQUUsVUFBVSxnQkFBZ0I7SUFDL0IsbUJBQW1CLE1BQU0sU0FBUztJQUNsQyxhQUFhLEtBQUssUUFBUTtJQUMxQixVQUFVLGlCQUFpQixjQUFjLEtBQUssUUFBUTtHQUN4RDtFQUNGO0NBQ0Y7QUFDRjs7QUNqTEEsSUFBQSx1QkFBZTtDQUNiLG1CQUFtQjtDQUNuQixtQkFBbUI7Q0FDbkIscUJBQXFCO0NBQ3JCLGlDQUFpQztDQUNqQyw2QkFBNkI7Q0FDN0IsaUNBQWlDO0NBQ2pDLHlCQUF5QjtBQUMzQjs7QUlOQSxJQUFBLGtCQUFlO0NBQ2IsV0FBVztDQUNYLFNBQVM7RUFDUCxpQkhKVyxPQUFPLG9CQUFvQixjQUFjLGtCQUFrQjtFR0t0RSxVRk5XLE9BQU8sYUFBYSxjQUFjLFdBQVc7RUVPeEQsTURQVyxPQUFPLFNBQVMsY0FBYyxPQUFPO0NDUWxEO0NBQ0EsV0FBVztFQUFDO0VBQVE7RUFBUztFQUFRO0VBQVE7RUFBTztDQUFNO0FBQzVEOzs7Ozs7Ozs7QUNaQSxJQUFNLGdCQUFnQixPQUFPLFdBQVcsZUFBZSxPQUFPLGFBQWE7QUFFM0UsSUFBTSxhQUFjLE9BQU8sY0FBYyxZQUFZLGFBQWMsS0FBQTs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBbUJuRSxJQUFNLHdCQUNKLGtCQUNDLENBQUMsY0FBYztDQUFDO0NBQWU7Q0FBZ0I7QUFBSSxDQUFDLENBQUMsUUFBUSxXQUFXLE9BQU8sSUFBSTs7Ozs7Ozs7OztBQVd0RixJQUFNLHdDQUF3QztDQUM1QyxPQUNFLE9BQU8sc0JBQXNCLGVBRTdCLGdCQUFnQixxQkFDaEIsT0FBTyxLQUFLLGtCQUFrQjtBQUVsQyxFQUFBLENBQUc7QUFFSCxJQUFNLFNBQVUsaUJBQWlCLE9BQU8sU0FBUyxRQUFTOztBQ3hDMUQsSUFBQSxtQkFBZTtDQUNiLEdBQUdDO0NBQ0gsR0FBR0M7QUFDTDs7QUNBQSxTQUF3QixpQkFBaUIsTUFBTSxTQUFTO0NBQ3RELE9BQU9DLGFBQVcsTUFBTSxJQUFJQyxpQkFBUyxRQUFRLGdCQUFnQixHQUFHO0VBQzlELFNBQVMsU0FBVSxPQUFPLEtBQUssTUFBTSxTQUFTO0dBQzVDLElBQUlBLGlCQUFTLFVBQVVDLGNBQU0sU0FBUyxLQUFLLEdBQUc7SUFDNUMsS0FBSyxPQUFPLEtBQUssTUFBTSxTQUFTLFFBQVEsQ0FBQztJQUN6QyxPQUFPO0dBQ1Q7R0FFQSxPQUFPLFFBQVEsZUFBZSxNQUFNLE1BQU0sU0FBUztFQUNyRDtFQUNBLEdBQUc7Q0FDTCxDQUFDO0FBQ0g7O0FDWkEsSUFBTSxZQUFBO0FBRU4sU0FBUyxxQkFBcUIsT0FBTztDQUNuQyxJQUFJLFFBQVEsV0FDVixNQUFNLElBQUlDLGFBQ1IsMENBQTBDLFFBQVEsMEJBQTBCLFdBQzVFQSxhQUFXLDRCQUNiO0FBRUo7Ozs7Ozs7O0FBU0EsU0FBUyxjQUFjLE1BQU07Q0FXM0IsTUFBTSxPQUFPLENBQUM7Q0FDZCxNQUFNLFVBQVU7Q0FDaEIsSUFBSTtDQUVKLFFBQVEsUUFBUSxRQUFRLEtBQUssSUFBSSxPQUFPLE1BQU07RUFDNUMscUJBQXFCLEtBQUssTUFBTTtFQUNoQyxLQUFLLEtBQUssTUFBTSxPQUFPLE9BQU8sS0FBSyxNQUFNLE1BQU0sTUFBTSxFQUFFO0NBQ3pEO0NBRUEsT0FBTztBQUNUOzs7Ozs7OztBQVNBLFNBQVMsY0FBYyxLQUFLO0NBQzFCLE1BQU0sTUFBTSxDQUFDO0NBQ2IsTUFBTSxPQUFPLE9BQU8sS0FBSyxHQUFHO0NBQzVCLElBQUk7Q0FDSixNQUFNLE1BQU0sS0FBSztDQUNqQixJQUFJO0NBQ0osS0FBSyxJQUFJLEdBQUcsSUFBSSxLQUFLLEtBQUs7RUFDeEIsTUFBTSxLQUFLO0VBQ1gsSUFBSSxPQUFPLElBQUk7Q0FDakI7Q0FDQSxPQUFPO0FBQ1Q7QUFFQSxTQUFTLGVBQWUsT0FBTztDQUM3QixJQUFJLENBQUNDLGNBQU0sUUFBUSxLQUFLLEdBQUcsT0FBTztDQUVsQyxNQUFNLE9BQU8sT0FBTyxLQUFLLEtBQUs7Q0FDOUIsT0FBTyxLQUFLLFdBQVcsTUFBTSxVQUFVLEtBQUssTUFBTSxLQUFLLFVBQVUsUUFBUSxPQUFPLEtBQUssQ0FBQyxJQUNsRixjQUFjLEtBQUssSUFDbkI7QUFDTjtBQUVBLFNBQVMsZ0JBQWdCLEtBQUs7Q0FDNUIsTUFBTSxVQUFVLENBQUMsR0FBRztDQUNwQixPQUFPLFFBQVEsUUFBUTtFQUNyQixNQUFNLFNBQVMsUUFBUSxJQUFJO0VBQzNCLE9BQU8sS0FBSyxNQUFNLENBQUMsQ0FBQyxTQUFTLFFBQVE7R0FDbkMsTUFBTSxRQUFTLE9BQU8sT0FBTyxlQUFlLE9BQU8sSUFBSTtHQUN2RCxJQUFJQSxjQUFNLFFBQVEsS0FBSyxLQUFLQSxjQUFNLGNBQWMsS0FBSyxHQUNuRCxRQUFRLEtBQUssS0FBSztFQUV0QixDQUFDO0NBQ0g7Q0FDQSxPQUFPO0FBQ1Q7Ozs7Ozs7O0FBU0EsU0FBUyxlQUFlLFVBQVU7Q0FDaEMsU0FBUyxVQUFVLE1BQU0sT0FBTyxRQUFRLE9BQU87RUFDN0MscUJBQXFCLEtBQUs7RUFFMUIsSUFBSSxPQUFPLEtBQUs7RUFFaEIsSUFBSSxTQUFTLGFBQWEsT0FBTztFQUVqQyxNQUFNLGVBQWUsT0FBTyxTQUFTLENBQUMsSUFBSTtFQUMxQyxNQUFNLFNBQVMsU0FBUyxLQUFLO0VBQzdCLE9BQU8sQ0FBQyxRQUFRQSxjQUFNLFFBQVEsTUFBTSxJQUFJLE9BQU8sU0FBUztFQUV4RCxJQUFJLFFBQVE7R0FDVixJQUFJQSxjQUFNLFdBQVcsUUFBUSxJQUFJLEdBQUc7SUFDbEMsT0FBTyxRQUFRLGVBQWUsT0FBTyxLQUFLO0lBQzFDLE9BQU8sUUFBUUEsY0FBTSxRQUFRLE9BQU8sS0FBSyxJQUNyQyxPQUFPLEtBQUssQ0FBQyxPQUFPLEtBQUssSUFDekIsQ0FBQyxPQUFPLE9BQU8sS0FBSztHQUMxQixPQUNFLE9BQU8sUUFBUTtHQUdqQixPQUFPLENBQUM7RUFDVjtFQUVBLElBQUksQ0FBQ0EsY0FBTSxXQUFXLFFBQVEsSUFBSSxLQUFLLENBQUNBLGNBQU0sU0FBUyxPQUFPLEtBQUssR0FDakUsT0FBTyxRQUFRLENBQUM7RUFLbEIsSUFGZSxVQUFVLE1BQU0sT0FBTyxPQUFPLE9BQU8sS0FFM0MsS0FBS0EsY0FBTSxRQUFRLE9BQU8sS0FBSyxHQUN0QyxPQUFPLFFBQVEsY0FBYyxPQUFPLEtBQUs7RUFHM0MsT0FBTyxDQUFDO0NBQ1Y7Q0FFQSxJQUFJQSxjQUFNLFdBQVcsUUFBUSxLQUFLQSxjQUFNLFdBQVcsU0FBUyxPQUFPLEdBQUc7RUFDcEUsTUFBTSxNQUFNLENBQUM7RUFFYixjQUFNLGFBQWEsV0FBVyxNQUFNLFVBQVU7R0FDNUMsVUFBVSxjQUFjLElBQUksR0FBRyxPQUFPLEtBQUssQ0FBQztFQUM5QyxDQUFDO0VBRUQsT0FBTyxnQkFBZ0IsR0FBRztDQUM1QjtDQUVBLE9BQU87QUFDVDs7QUNoSkEsSUFBTSxhQUFhLE9BQU8sT0FBTztDQUMvQjtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0FBQ0YsQ0FBQzs7QUNIRCxJQUFNLE9BQU8sS0FBSyxRQUFTLE9BQU8sUUFBUUMsY0FBTSxXQUFXLEtBQUssR0FBRyxJQUFJLElBQUksT0FBTyxLQUFBOzs7Ozs7Ozs7OztBQVlsRixTQUFTLGdCQUFnQixVQUFVLFFBQVEsU0FBUztDQUNsRCxJQUFJQSxjQUFNLFNBQVMsUUFBUSxHQUN6QixJQUFJO0VBQ0YsQ0FBQyxVQUFVLEtBQUssTUFBQSxDQUFPLFFBQVE7RUFDL0IsT0FBT0EsY0FBTSxLQUFLLFFBQVE7Q0FDNUIsU0FBUyxHQUFHO0VBQ1YsSUFBSSxFQUFFLFNBQVMsZUFDYixNQUFNO0NBRVY7Q0FHRixRQUFRLFdBQVcsS0FBSyxVQUFBLENBQVcsUUFBUTtBQUM3QztBQUVBLElBQU0sV0FBVztDQUNmLGNBQWNDO0NBRWQsU0FBUztFQUFDO0VBQU87RUFBUTtDQUFPO0NBRWhDLGtCQUFrQixDQUNoQixTQUFTLGlCQUFpQixNQUFNLFNBQVM7RUFDdkMsTUFBTSxjQUFjLFFBQVEsZUFBZSxLQUFLO0VBQ2hELE1BQU0scUJBQXFCLFlBQVksUUFBUSxrQkFBa0IsSUFBSTtFQUNyRSxNQUFNLGtCQUFrQkQsY0FBTSxTQUFTLElBQUk7RUFFM0MsSUFBSSxtQkFBbUJBLGNBQU0sV0FBVyxJQUFJLEdBQzFDLE9BQU8sSUFBSSxTQUFTLElBQUk7RUFLMUIsSUFGbUJBLGNBQU0sV0FBVyxJQUV2QixHQUNYLE9BQU8scUJBQXFCLEtBQUssVUFBVSxlQUFlLElBQUksQ0FBQyxJQUFJO0VBR3JFLElBQ0VBLGNBQU0sY0FBYyxJQUFJLEtBQ3hCQSxjQUFNLFNBQVMsSUFBSSxLQUNuQkEsY0FBTSxTQUFTLElBQUksS0FDbkJBLGNBQU0sT0FBTyxJQUFJLEtBQ2pCQSxjQUFNLE9BQU8sSUFBSSxLQUNqQkEsY0FBTSxpQkFBaUIsSUFBSSxHQUUzQixPQUFPO0VBRVQsSUFBSUEsY0FBTSxrQkFBa0IsSUFBSSxHQUM5QixPQUFPLEtBQUs7RUFFZCxJQUFJQSxjQUFNLGtCQUFrQixJQUFJLEdBQUc7R0FDakMsUUFBUSxlQUFlLG1EQUFtRCxLQUFLO0dBQy9FLE9BQU8sS0FBSyxTQUFTO0VBQ3ZCO0VBRUEsSUFBSTtFQUVKLElBQUksaUJBQWlCO0dBQ25CLE1BQU0saUJBQWlCLElBQUksTUFBTSxnQkFBZ0I7R0FDakQsSUFBSSxZQUFZLFFBQVEsbUNBQW1DLElBQUksSUFDN0QsT0FBTyxpQkFBaUIsTUFBTSxjQUFjLENBQUMsQ0FBQyxTQUFTO0dBR3pELEtBQ0csYUFBYUEsY0FBTSxXQUFXLElBQUksTUFDbkMsWUFBWSxRQUFRLHFCQUFxQixJQUFJLElBQzdDO0lBQ0EsTUFBTSxNQUFNLElBQUksTUFBTSxLQUFLO0lBQzNCLE1BQU0sWUFBWSxPQUFPLElBQUk7SUFFN0IsT0FBT0UsYUFDTCxhQUFhLEVBQUUsV0FBVyxLQUFLLElBQUksTUFDbkMsYUFBYSxJQUFJLFVBQVUsR0FDM0IsY0FDRjtHQUNGO0VBQ0Y7RUFFQSxJQUFJLG1CQUFtQixvQkFBb0I7R0FDekMsUUFBUSxlQUFlLG9CQUFvQixLQUFLO0dBQ2hELE9BQU8sZ0JBQWdCLElBQUk7RUFDN0I7RUFFQSxPQUFPO0NBQ1QsQ0FDRjtDQUVBLG1CQUFtQixDQUNqQixTQUFTLGtCQUFrQixNQUFNO0VBQy9CLE1BQU0sZUFBZSxJQUFJLE1BQU0sY0FBYyxLQUFLLFNBQVM7RUFDM0QsTUFBTSxvQkFBb0IsZ0JBQWdCLGFBQWE7RUFDdkQsTUFBTSxlQUFlLElBQUksTUFBTSxjQUFjO0VBQzdDLE1BQU0sZ0JBQWdCLGlCQUFpQjtFQUV2QyxJQUFJRixjQUFNLFdBQVcsSUFBSSxLQUFLQSxjQUFNLGlCQUFpQixJQUFJLEdBQ3ZELE9BQU87RUFHVCxJQUNFLFFBQ0FBLGNBQU0sU0FBUyxJQUFJLE1BQ2pCLHFCQUFxQixDQUFDLGdCQUFpQixnQkFDekM7R0FFQSxNQUFNLG9CQUFvQixFQURBLGdCQUFnQixhQUFhLHNCQUNQO0dBRWhELElBQUk7SUFDRixPQUFPLEtBQUssTUFBTSxNQUFNLElBQUksTUFBTSxjQUFjLENBQUM7R0FDbkQsU0FBUyxHQUFHO0lBQ1YsSUFBSSxtQkFBbUI7S0FDckIsSUFBSSxFQUFFLFNBQVMsZUFDYixNQUFNRyxhQUFXLEtBQUssR0FBR0EsYUFBVyxrQkFBa0IsTUFBTSxNQUFNLElBQUksTUFBTSxVQUFVLENBQUM7S0FFekYsTUFBTTtJQUNSO0dBQ0Y7RUFDRjtFQUVBLE9BQU87Q0FDVCxDQUNGOzs7OztDQU1BLFNBQVM7Q0FFVCxnQkFBZ0I7Q0FDaEIsZ0JBQWdCO0NBRWhCLGtCQUFrQjtDQUNsQixlQUFlO0NBRWYsS0FBSztFQUNILFVBQVVDLGlCQUFTLFFBQVE7RUFDM0IsTUFBTUEsaUJBQVMsUUFBUTtDQUN6QjtDQUVBLGdCQUFnQixTQUFTLGVBQWUsUUFBUTtFQUM5QyxPQUFPLFVBQVUsT0FBTyxTQUFTO0NBQ25DO0NBRUEsU0FBUyxFQUNQLFFBQVE7RUFDTixRQUFRO0VBQ1IsZ0JBQWdCLEtBQUE7Q0FDbEIsRUFDRjtBQUNGO0FBRUFKLGNBQU0sUUFBUSxhQUFhLFdBQVc7Q0FDcEMsU0FBUyxRQUFRLFVBQVUsQ0FBQztBQUM5QixDQUFDOzs7Ozs7Ozs7O0FDaktELFNBQXdCLGNBQWMsS0FBSyxVQUFVO0NBQ25ELE1BQU0sU0FBUyxRQUFRO0NBQ3ZCLE1BQU0sVUFBVSxZQUFZO0NBQzVCLE1BQU0sVUFBVUssZUFBYSxLQUFLLFFBQVEsT0FBTztDQUNqRCxJQUFJLE9BQU8sUUFBUTtDQUVuQixjQUFNLFFBQVEsS0FBSyxTQUFTLFVBQVUsSUFBSTtFQUN4QyxPQUFPLEdBQUcsS0FBSyxRQUFRLE1BQU0sUUFBUSxVQUFVLEdBQUcsV0FBVyxTQUFTLFNBQVMsS0FBQSxDQUFTO0NBQzFGLENBQUM7Q0FFRCxRQUFRLFVBQVU7Q0FFbEIsT0FBTztBQUNUOztBQ3pCQSxTQUF3QkMsV0FBUyxPQUFPO0NBQ3RDLE9BQU8sQ0FBQyxFQUFFLFNBQVMsTUFBTTtBQUMzQjs7QUNBQSxJQUFNQyxrQkFBTixjQUE0QkMsYUFBVzs7Ozs7Ozs7OztDQVVyQyxZQUFZLFNBQVMsUUFBUSxTQUFTO0VBQ3BDLE1BQU0sV0FBVyxPQUFPLGFBQWEsU0FBU0EsYUFBVyxjQUFjLFFBQVEsT0FBTztFQUN0RixLQUFLLE9BQU87RUFDWixLQUFLLGFBQWE7Q0FDcEI7QUFDRjs7Ozs7Ozs7Ozs7QUNOQSxTQUF3QixPQUFPLFNBQVMsUUFBUSxVQUFVO0NBQ3hELE1BQU0saUJBQWlCLFNBQVMsT0FBTztDQUN2QyxJQUFJLENBQUMsU0FBUyxVQUFVLENBQUMsa0JBQWtCLGVBQWUsU0FBUyxNQUFNLEdBQ3ZFLFFBQVEsUUFBUTtNQUVoQixPQUFPLElBQUlDLGFBQ1QscUNBQXFDLFNBQVMsUUFDOUMsU0FBUyxVQUFVLE9BQU8sU0FBUyxTQUFTLE1BQU1BLGFBQVcsa0JBQWtCQSxhQUFXLGtCQUMxRixTQUFTLFFBQ1QsU0FBUyxTQUNULFFBQ0YsQ0FBQztBQUVMOztBQ3hCQSxJQUFNLDZCQUE2Qjs7Ozs7Ozs7QUFTbkMsU0FBd0IsNkJBQTZCLEtBQUs7Q0FDeEQsSUFBSSxPQUFPLFFBQVEsVUFDakIsT0FBTztDQUdULElBQUksUUFBUTtDQUVaLE9BQU8sUUFBUSxJQUFJLFVBQVUsSUFBSSxXQUFXLEtBQUssS0FBSyxJQUNwRDtDQUdGLE9BQU8sSUFBSSxNQUFNLEtBQUssQ0FBQyxDQUFDLFFBQVEsNEJBQTRCLEVBQUU7QUFDaEU7O0FDckJBLFNBQXdCLGNBQWMsS0FBSztDQUN6QyxNQUFNLFFBQVEsNEJBQTRCLEtBQUssR0FBRztDQUNsRCxPQUFRLFNBQVMsTUFBTSxFQUFFLENBQUMsWUFBWSxLQUFNO0FBQzlDOztBQ0ZBLElBQU0scUJBQXFCLFVBQVU7Q0FDbkMsSUFBSTtFQUNGLE9BQU8sbUJBQW1CLEtBQUs7Q0FDakMsU0FBUyxHQUFHO0VBQ1YsT0FBTztDQUNUO0FBQ0Y7QUFFQSxJQUFBLGtCQUFlQyxpQkFBUyx3QkFFcEI7Q0FDRSxNQUFNLE1BQU0sT0FBTyxTQUFTLE1BQU0sUUFBUSxRQUFRLFVBQVU7RUFDMUQsSUFBSSxPQUFPLGFBQWEsYUFBYTtFQUVyQyxNQUFNLFNBQVMsQ0FBQyxHQUFHLEtBQUssR0FBRyxtQkFBbUIsS0FBSyxHQUFHO0VBRXRELElBQUlDLGNBQU0sU0FBUyxPQUFPLEdBQ3hCLE9BQU8sS0FBSyxXQUFXLElBQUksS0FBSyxPQUFPLENBQUMsQ0FBQyxZQUFZLEdBQUc7RUFFMUQsSUFBSUEsY0FBTSxTQUFTLElBQUksR0FDckIsT0FBTyxLQUFLLFFBQVEsTUFBTTtFQUU1QixJQUFJQSxjQUFNLFNBQVMsTUFBTSxHQUN2QixPQUFPLEtBQUssVUFBVSxRQUFRO0VBRWhDLElBQUksV0FBVyxNQUNiLE9BQU8sS0FBSyxRQUFRO0VBRXRCLElBQUlBLGNBQU0sU0FBUyxRQUFRLEdBQ3pCLE9BQU8sS0FBSyxZQUFZLFVBQVU7RUFHcEMsU0FBUyxTQUFTLE9BQU8sS0FBSyxJQUFJO0NBQ3BDO0NBRUEsS0FBSyxNQUFNO0VBQ1QsSUFBSSxPQUFPLGFBQWEsYUFBYSxPQUFPO0VBQzVDLE1BQU0sZUFBZSxTQUFTO0VBQzlCLElBQUksQ0FBQyxjQUFjLE9BQU87RUFNMUIsTUFBTSxVQUFVLGFBQWEsTUFBTSxHQUFHO0VBQ3RDLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxRQUFRLFFBQVEsS0FBSztHQUN2QyxNQUFNLFNBQVMsUUFBUSxFQUFFLENBQUMsUUFBUSxRQUFRLEVBQUU7R0FDNUMsTUFBTSxLQUFLLE9BQU8sUUFBUSxHQUFHO0dBQzdCLElBQUksT0FBTyxNQUFNLE9BQU8sTUFBTSxHQUFHLEVBQUUsTUFBTSxNQUN2QyxPQUFPLGtCQUFrQixPQUFPLE1BQU0sS0FBSyxDQUFDLENBQUM7RUFFakQ7RUFDQSxPQUFPO0NBQ1Q7Q0FFQSxNQUFNLFVBQVUsTUFBTTtFQUNwQixJQUFJO0dBQ0YsTUFBTSxRQUFRLE9BQU8sV0FBVyxlQUFlLE9BQU87R0FDdEQsSUFBSSxTQUFTQSxjQUFNLFdBQVcsTUFBTSxHQUFHLEdBQUc7SUFDeEMsTUFBTSxTQUFTLE1BQU0sTUFBTSxJQUFJLElBQUk7SUFFbkMsT0FBTyxTQUFTLGtCQUFrQixPQUFPLEtBQUssSUFBSTtHQUNwRDtFQUNGLFNBQVMsR0FBRyxDQUVaO0VBRUEsT0FBTyxLQUFLLEtBQUssSUFBSTtDQUN2QjtDQUVBLE9BQU8sTUFBTTtFQUNYLEtBQUssTUFBTSxNQUFNLElBQUksS0FBSyxJQUFJLElBQUksT0FBVSxHQUFHO0NBQ2pEO0FBQ0YsSUFFQTtDQUNFLFFBQVEsQ0FBQztDQUNULE9BQU87RUFDTCxPQUFPO0NBQ1Q7Q0FDQSxNQUFNLFlBQVk7RUFDaEIsT0FBTztDQUNUO0NBQ0EsU0FBUyxDQUFDO0FBQ1o7Ozs7Ozs7O0FDL0VKLFNBQVMsWUFBWSxjQUFjLEtBQUs7Q0FDdEMsZUFBZSxnQkFBZ0I7Q0FDL0IsTUFBTSxRQUFRLElBQUksTUFBTSxZQUFZO0NBQ3BDLE1BQU0sYUFBYSxJQUFJLE1BQU0sWUFBWTtDQUN6QyxJQUFJLE9BQU87Q0FDWCxJQUFJLE9BQU87Q0FDWCxJQUFJO0NBRUosTUFBTSxRQUFRLEtBQUEsSUFBWSxNQUFNO0NBRWhDLE9BQU8sU0FBUyxLQUFLLGFBQWE7RUFDaEMsTUFBTSxNQUFNLEtBQUssSUFBSTtFQUVyQixNQUFNLFlBQVksV0FBVztFQUU3QixJQUFJLENBQUMsZUFDSCxnQkFBZ0I7RUFHbEIsTUFBTSxRQUFRO0VBQ2QsV0FBVyxRQUFRO0VBRW5CLElBQUksSUFBSTtFQUNSLElBQUksYUFBYTtFQUVqQixPQUFPLE1BQU0sTUFBTTtHQUNqQixjQUFjLE1BQU07R0FDcEIsSUFBSSxJQUFJO0VBQ1Y7RUFFQSxRQUFRLE9BQU8sS0FBSztFQUVwQixJQUFJLFNBQVMsTUFDWCxRQUFRLE9BQU8sS0FBSztFQUd0QixJQUFJLE1BQU0sZ0JBQWdCLEtBQ3hCO0VBR0YsTUFBTSxTQUFTLGFBQWEsTUFBTTtFQUVsQyxPQUFPLFNBQVMsS0FBSyxNQUFPLGFBQWEsTUFBUSxNQUFNLElBQUksS0FBQTtDQUM3RDtBQUNGOzs7Ozs7OztBQzlDQSxTQUFTLFNBQVMsSUFBSSxNQUFNO0NBQzFCLElBQUksWUFBWTtDQUNoQixJQUFJLFlBQVksTUFBTztDQUN2QixJQUFJO0NBQ0osSUFBSTtDQUVKLE1BQU0sVUFBVSxNQUFNLE1BQU0sS0FBSyxJQUFJLE1BQU07RUFDekMsWUFBWTtFQUNaLFdBQVc7RUFDWCxJQUFJLE9BQU87R0FDVCxhQUFhLEtBQUs7R0FDbEIsUUFBUTtFQUNWO0VBQ0EsR0FBRyxHQUFHLElBQUk7Q0FDWjtDQUVBLE1BQU0sYUFBYSxHQUFHLFNBQVM7RUFDN0IsTUFBTSxNQUFNLEtBQUssSUFBSTtFQUNyQixNQUFNLFNBQVMsTUFBTTtFQUNyQixJQUFJLFVBQVUsV0FDWixPQUFPLE1BQU0sR0FBRztPQUNYO0dBQ0wsV0FBVztHQUNYLElBQUksQ0FBQyxPQUNILFFBQVEsaUJBQWlCO0lBQ3ZCLFFBQVE7SUFDUixPQUFPLFFBQVE7R0FDakIsR0FBRyxZQUFZLE1BQU07RUFFekI7Q0FDRjtDQUVBLE1BQU0sY0FBYyxZQUFZLE9BQU8sUUFBUTtDQUMvQyxNQUFNLGFBQWEsR0FBRyxTQUFTLE9BQU8sSUFBSTtDQUUxQyxPQUFPO0VBQUM7RUFBVztFQUFPO0NBQVM7QUFDckM7O0FDdENBLElBQWEsd0JBQXdCLFVBQVUsa0JBQWtCLE9BQU8sTUFBTTtDQUM1RSxJQUFJLGdCQUFnQjtDQUNwQixNQUFNLGVBQWUsWUFBWSxJQUFJLEdBQUc7Q0FFeEMsT0FBTyxVQUFVLE1BQU07RUFDckIsSUFBSSxDQUFDLEtBQUssQ0FBQ0MsY0FBTSxTQUFTLEVBQUUsTUFBTSxHQUNoQztFQUVGLE1BQU0sWUFBWSxFQUFFO0VBQ3BCLE1BQU0sUUFBUSxFQUFFLG1CQUFtQixFQUFFLFFBQVEsS0FBQTtFQUM3QyxNQUFNLFNBQVMsS0FBSyxJQUFJLEdBQUcsU0FBUyxPQUFPLEtBQUssSUFBSSxXQUFXLEtBQUssSUFBSSxTQUFTO0VBQ2pGLE1BQU0sZ0JBQWdCLEtBQUssSUFBSSxHQUFHLFNBQVMsYUFBYTtFQUN4RCxNQUFNLE9BQU8sYUFBYSxhQUFhO0VBRXZDLGdCQUFnQixLQUFLLElBQUksZUFBZSxNQUFNO0VBYzlDLFNBQVM7R0FYUDtHQUNBO0dBQ0EsVUFBVSxRQUFRLFNBQVMsUUFBUSxLQUFBO0dBQ25DLE9BQU87R0FDUCxNQUFNLE9BQU8sT0FBTyxLQUFBO0dBQ3BCLFdBQVcsUUFBUSxTQUFTLFFBQVEsVUFBVSxPQUFPLEtBQUE7R0FDckQsT0FBTztHQUNQLGtCQUFrQixTQUFTO0lBQzFCLG1CQUFtQixhQUFhLFdBQVc7RUFHbEMsQ0FBQztDQUNmLEdBQUcsSUFBSTtBQUNUO0FBRUEsSUFBYSwwQkFBMEIsT0FBTyxjQUFjO0NBQzFELE1BQU0sbUJBQW1CLFNBQVM7Q0FFbEMsT0FBTyxFQUNKLFdBQ0MsVUFBVSxFQUFFLENBQUM7RUFDWDtFQUNBO0VBQ0E7Q0FDRixDQUFDLEdBQ0gsVUFBVSxFQUNaO0FBQ0Y7QUFFQSxJQUFhLGtCQUNWLElBQUksWUFBWUEsY0FBTSxVQUN0QixHQUFHLFNBQ0YsZ0JBQWdCLEdBQUcsR0FBRyxJQUFJLENBQUM7O0FDbkQvQixJQUFBLDBCQUFlQyxpQkFBUywwQkFDbEIsWUFBWSxRQUFRO0NBQ3BCLE1BQU0sSUFBSSxJQUFJLEtBQUssU0FBUyxXQUFXQSxpQkFBUyxNQUFNO0NBRXRELE9BQ0UsT0FBTyxhQUFhLElBQUksWUFBWSxPQUFPLFNBQVMsSUFBSSxRQUFRLE9BQU8sU0FBUyxJQUFJO0FBRXhGLEVBQUEsQ0FBRyxJQUFJLElBQUlBLGlCQUFTLE1BQU0sQ0FBQyxVQUNyQjs7Ozs7Ozs7O0FDRFYsU0FBd0IsY0FBYyxLQUFLO0NBSXpDLElBQUksT0FBTyxRQUFRLFVBQ2pCLE9BQU87Q0FHVCxPQUFPLDhCQUE4QixLQUFLLEdBQUc7QUFDL0M7Ozs7Ozs7Ozs7QUNSQSxTQUF3QixZQUFZLFNBQVMsYUFBYTtDQUN4RCxJQUFJLENBQUMsYUFDSCxPQUFPO0NBR1QsSUFBSSxNQUFNLFFBQVE7Q0FFbEIsT0FBTyxNQUFNLEtBQUssUUFBUSxXQUFXLE1BQU0sQ0FBQyxNQUFNLElBQ2hEO0NBR0YsT0FBTyxRQUFRLE1BQU0sR0FBRyxHQUFHLElBQUksTUFBTSxZQUFZLFFBQVEsUUFBUSxFQUFFO0FBQ3JFOztBQ2ZBLElBQU0sd0JBQXdCO0FBVTlCLFNBQVMsZUFBZSxVQUFVO0NBQ2hDLElBQUksQ0FBQyxVQUNILE9BQU87Q0FHVCxPQUFPLFNBQVMsUUFBUSwwQkFBMEIsT0FBTyxXQUFXLGdCQUFnQixPQUFPO0VBQ3pGLE9BQU8sR0FBRyxZQUFZLGdCQUFnQjtDQUN4QyxDQUFDO0FBQ0g7QUFFQSxTQUFTLHdCQUF3QixLQUFLO0NBQ3BDLE1BQU0sY0FBYyxJQUFJLFFBQVEsOEJBQThCLEtBQUssU0FBUyxFQUFFO0NBQzlFLE1BQU0sZ0JBQWdCLFlBQVksUUFBUSxHQUFHO0NBRzdDLE1BQU0sOEJBREosa0JBQWtCLEtBQUssY0FBYyxZQUFZLE1BQU0sR0FBRyxhQUFhLEVBQUEsQ0FDbkIsUUFDcEQseUJBQ0EsS0FBSyxVQUNQO0NBRUEsSUFBSSxrQkFBa0IsSUFDcEIsT0FBTztDQUdULE9BQU8sR0FBRywyQkFBMkIsR0FBRyxlQUFlLFlBQVksTUFBTSxnQkFBZ0IsQ0FBQyxDQUFDO0FBQzdGO0FBRUEsU0FBUywyQkFBMkIsS0FBSyxRQUFRO0NBQy9DLElBQUksT0FBTyxRQUFRLFVBQVU7RUFDM0IsTUFBTSxnQkFBZ0IsNkJBQTZCLEdBQUc7RUFDdEQsSUFBSSxzQkFBc0IsS0FBSyxhQUFhLEdBQzFDLE1BQU0sSUFBSUMsYUFDUixlQUFlLEtBQUssVUFBVSx3QkFBd0IsYUFBYSxDQUFDLEVBQUUsZ0NBQ3RFQSxhQUFXLGlCQUNYLE1BQ0Y7Q0FFSjtBQUNGOzs7Ozs7Ozs7OztBQVlBLFNBQXdCLGNBQWMsU0FBUyxjQUFjLG1CQUFtQixRQUFRO0NBQ3RGLDJCQUEyQixjQUFjLE1BQU07Q0FDL0MsSUFBSSxnQkFBZ0IsQ0FBQyxjQUFjLFlBQVk7Q0FDL0MsSUFBSSxZQUFZLGlCQUFpQixzQkFBc0IsUUFBUTtFQUM3RCwyQkFBMkIsU0FBUyxNQUFNO0VBQzFDLE9BQU8sWUFBWSxTQUFTLFlBQVk7Q0FDMUM7Q0FDQSxPQUFPO0FBQ1Q7O0FDdEVBLFNBQXdCLG9CQUFvQixRQUFRO0NBQ2xELE1BQU0sVUFBVSxDQUFDLEVBQUUsT0FBTyxPQUFPLENBQUM7Q0FDbEMsTUFBTSx5QkFBUyxJQUFJLFFBQVE7Q0FDM0IsTUFBTSwwQkFBVSxJQUFJLFFBQVE7Q0FFNUIsT0FBTyxRQUFRLFFBQVE7RUFDckIsTUFBTSxFQUFFLE9BQU8sU0FBUyxRQUFRLElBQUk7RUFDcEMsSUFBSSxDQUFDQyxjQUFNLGNBQWMsS0FBSyxLQUFLLENBQUNBLGNBQU0sUUFBUSxLQUFLLEdBQUc7RUFDMUQsSUFBSSxNQUFNO0dBQ1IsT0FBTyxPQUFPLEtBQUs7R0FDbkI7RUFDRjtFQUNBLElBQUksT0FBTyxJQUFJLEtBQUssR0FDbEIsTUFBTSxJQUFJQyxhQUNSLHlDQUNBQSxhQUFXLG9CQUNiO0VBRUYsSUFBSSxRQUFRLElBQUksS0FBSyxHQUFHO0VBQ3hCLFFBQVEsSUFBSSxLQUFLO0VBQ2pCLE9BQU8sSUFBSSxLQUFLO0VBQ2hCLFFBQVEsS0FBSztHQUFFO0dBQU8sTUFBTTtFQUFLLENBQUM7RUFFbEMsTUFBTSxPQUFPLE9BQU8sS0FBSyxLQUFLO0VBQzlCLElBQUksT0FBTyx5QkFBeUIsT0FBTywwQkFDekMsT0FBTyxzQkFBc0IsS0FBSyxDQUFDLENBQUMsU0FBUyxRQUFRO0dBQ25ELE1BQU0sYUFBYSxPQUFPLHlCQUF5QixPQUFPLEdBQUc7R0FDN0QsSUFBSSxjQUFjLFdBQVcsWUFBWSxLQUFLLEtBQUssR0FBRztFQUN4RCxDQUFDO0VBSUgsS0FBSyxTQUFTLFFBQVE7R0FDcEIsSUFBSSxRQUFRLGVBQWUsUUFBUSxpQkFBaUIsUUFBUSxhQUFhO0lBQ3ZFLE1BQU0sYUFBYSxPQUFPLHlCQUF5QixPQUFPLEdBQUc7SUFDN0QsSUFBSSxjQUFjRCxjQUFNLFdBQVcsWUFBWSxPQUFPLEdBQ3BELFFBQVEsS0FBSyxFQUFFLE9BQU8sV0FBVyxNQUFNLENBQUM7R0FFNUMsT0FDRSxRQUFRLEtBQUssRUFBRSxPQUFPLE1BQU0sS0FBSyxDQUFDO0VBRXRDLENBQUM7Q0FDSDtBQUNGOztBQzFDQSxJQUFNLG1CQUFtQixVQUFXLGlCQUFpQkUsaUJBQWUsRUFBRSxHQUFHLE1BQU0sSUFBSTtBQUVuRixJQUFNLHFCQUFxQixVQUFVO0NBQ25DLElBQUksT0FBTyx5QkFBeUIsT0FBTywwQkFDekMsT0FBTyxPQUFPLEtBQUssS0FBSyxDQUFDLENBQUMsT0FDeEIsT0FBTyxzQkFBc0IsS0FBSyxDQUFDLENBQUMsUUFBUSxXQUFXO0VBQ3JELE1BQU0sYUFBYSxPQUFPLHlCQUF5QixPQUFPLE1BQU07RUFDaEUsT0FBTyxjQUFjLFdBQVc7Q0FDbEMsQ0FBQyxDQUNIO0NBRUYsT0FBTyxPQUFPLEtBQUssS0FBSztBQUMxQjtBQUlBLFNBQVMsWUFBWSxHQUFHLEdBQUc7Q0FDekIsTUFBTSxVQUFVLENBQUM7Q0FDakIsTUFBTSx5QkFBUyxJQUFJLFFBQVE7Q0FDM0IsTUFBTSxRQUFRLENBQUM7Q0FFZixTQUFTLEtBQUssUUFBUSxRQUFRO0VBQzVCLElBQUksQ0FBQ0MsY0FBTSxjQUFjLE1BQU0sR0FDN0IsT0FBT0EsY0FBTSxRQUFRLE1BQU0sSUFBSSxPQUFPLE1BQU0sSUFBSTtFQUdsRCxNQUFNLE9BQU9BLGNBQU0sY0FBYyxNQUFNLElBQUksU0FBUztFQUNwRCxJQUFJLFFBQVEsT0FBTyxJQUFJLE1BQU07RUFDN0IsSUFBSSxDQUFDLE9BQU87R0FDVix3QkFBUSxJQUFJLFFBQVE7R0FDcEIsT0FBTyxJQUFJLFFBQVEsS0FBSztFQUMxQjtFQUNBLElBQUksTUFBTSxJQUFJLElBQUksR0FBRyxPQUFPLE1BQU0sSUFBSSxJQUFJO0VBRTFDLE1BQU0sU0FBUyxDQUFDO0VBQ2hCLE1BQU0sSUFBSSxNQUFNLE1BQU07RUFDdEIsUUFBUSxLQUFLO0dBQUU7R0FBTTtHQUFRO0VBQU8sQ0FBQztFQUNyQyxPQUFPO0NBQ1Q7Q0FFQSxNQUFNLFNBQVNBLGNBQU0sWUFBWSxDQUFDLElBQUksS0FBSyxLQUFBLEdBQVcsQ0FBQyxJQUFJLEtBQUssR0FBRyxDQUFDO0NBQ3BFLE9BQU8sUUFBUSxRQUFRO0VBQ3JCLE1BQU0sRUFBRSxNQUFNLFFBQVEsUUFBUSxXQUFXLFFBQVEsSUFBSTtFQUNyRCxNQUFNLFdBQVcsSUFBSSxJQUFJLGtCQUFrQixJQUFJLENBQUM7RUFDaEQsTUFBTSxhQUFhLElBQUksSUFBSSxrQkFBa0IsTUFBTSxDQUFDO0VBR3BELGlCQUFBLElBRmlCLElBQUksQ0FBQyxHQUFHLFVBQVUsR0FBRyxVQUFVLENBRTdDLEVBQUEsQ0FBRSxTQUFTLFFBQVE7R0FDcEIsSUFBSSxRQUFRLGVBQWUsUUFBUSxpQkFBaUIsUUFBUSxhQUFhO0dBQ3pFLE1BQU0sWUFBWSxXQUFXLElBQUksR0FBRztHQUNwQyxNQUFNLFFBQVEsWUFBWSxPQUFPLE9BQU8sS0FBQTtHQUN4QyxNQUFNLFlBQ0gsQ0FBQyxhQUFhQSxjQUFNLGNBQWMsS0FBSyxNQUFNLFNBQVMsSUFBSSxHQUFHLElBQUksS0FBSyxPQUFPLEtBQUE7R0FDaEYsT0FBTyxPQUFPLFlBQVksS0FBSyxVQUFVLEtBQUssSUFBSSxLQUFLLEtBQUEsR0FBVyxRQUFRO0VBQzVFLENBQUM7Q0FDSDtDQUVBLG9CQUFvQixNQUFNO0NBQzFCLE9BQU87QUFDVDtBQUVBLFNBQVMsZUFBZSxRQUFRLFFBQVEsTUFBTSxVQUFVO0NBQ3RELElBQUlBLGNBQU0sY0FBYyxNQUFNLEtBQUtBLGNBQU0sY0FBYyxNQUFNLEdBQzNELE9BQU9BLGNBQU0sTUFBTSxLQUFLLEVBQUUsU0FBUyxHQUFHLFFBQVEsTUFBTTtNQUMvQyxJQUFJQSxjQUFNLGNBQWMsTUFBTSxHQUNuQyxPQUFPQSxjQUFNLE1BQU0sQ0FBQyxHQUFHLE1BQU07TUFDeEIsSUFBSUEsY0FBTSxRQUFRLE1BQU0sR0FDN0IsT0FBTyxPQUFPLE1BQU07Q0FFdEIsT0FBTztBQUNUO0FBRUEsU0FBUyxvQkFBb0IsR0FBRyxHQUFHLE1BQU0sVUFBVTtDQUNqRCxJQUFJLENBQUNBLGNBQU0sWUFBWSxDQUFDLEdBQ3RCLE9BQU8sZUFBZSxHQUFHLEdBQUcsTUFBTSxRQUFRO01BQ3JDLElBQUksQ0FBQ0EsY0FBTSxZQUFZLENBQUMsR0FDN0IsT0FBTyxlQUFlLEtBQUEsR0FBVyxHQUFHLE1BQU0sUUFBUTtBQUV0RDtBQUdBLFNBQVMsaUJBQWlCLEdBQUcsR0FBRztDQUM5QixJQUFJLENBQUNBLGNBQU0sWUFBWSxDQUFDLEdBQ3RCLE9BQU8sZUFBZSxLQUFBLEdBQVcsQ0FBQztBQUV0QztBQUdBLFNBQVMsaUJBQWlCLEdBQUcsR0FBRztDQUM5QixJQUFJLENBQUNBLGNBQU0sWUFBWSxDQUFDLEdBQ3RCLE9BQU8sZUFBZSxLQUFBLEdBQVcsQ0FBQztNQUM3QixJQUFJLENBQUNBLGNBQU0sWUFBWSxDQUFDLEdBQzdCLE9BQU8sZUFBZSxLQUFBLEdBQVcsQ0FBQztBQUV0QztBQUVBLFNBQVMsNEJBQTRCLFNBQVMsU0FBUyxNQUFNO0NBQzNELE1BQU0sZ0JBQWdCQSxjQUFNLFdBQVcsU0FBUyxjQUFjLElBQzFELFFBQVEsZUFDUixLQUFBO0NBRUosSUFBSSxDQUFDQSxjQUFNLFlBQVksYUFBYSxHQUFHO0VBQ3JDLElBQUlBLGNBQU0sY0FBYyxhQUFhLEdBQy9CQTtPQUFBQSxjQUFNLFdBQVcsZUFBZSxJQUFJLEdBQ3RDLE9BQU8sY0FBYztFQUFBLE9BR3ZCO0NBRUo7Q0FFQSxNQUFNLGdCQUFnQkEsY0FBTSxXQUFXLFNBQVMsY0FBYyxJQUMxRCxRQUFRLGVBQ1IsS0FBQTtDQUVKLElBQUlBLGNBQU0sY0FBYyxhQUFhLEtBQUtBLGNBQU0sV0FBVyxlQUFlLElBQUksR0FDNUUsT0FBTyxjQUFjO0FBSXpCO0FBR0EsU0FBUyxnQkFBZ0IsR0FBRyxHQUFHLE1BQU0sU0FBUyxTQUFTO0NBQ3JELElBQUlBLGNBQU0sV0FBVyxTQUFTLElBQUksR0FDaEMsT0FBTyxlQUFlLEdBQUcsQ0FBQztNQUNyQixJQUFJQSxjQUFNLFdBQVcsU0FBUyxJQUFJLEdBQ3ZDLE9BQU8sZUFBZSxLQUFBLEdBQVcsQ0FBQztBQUV0QztBQUVBLFNBQVMsYUFBYSxHQUFHLEdBQUcsTUFBTTtDQUNoQyxPQUFPLG9CQUFvQixnQkFBZ0IsQ0FBQyxHQUFHLGdCQUFnQixDQUFDLEdBQUcsTUFBTSxJQUFJO0FBQy9FO0FBS0EsSUFBTSwyQkFBMkIsT0FBTyxPQUFPO0NBQzdDLFdBQVc7Q0FDWCxPQUFPLE9BQU8sVUFBVTtDQUN4QixZQUFZO0NBQ1osVUFBVTtDQUNWLGNBQWM7QUFDaEIsQ0FBQztBQUtELElBQU0sV0FBVztDQUNmLEtBQUs7Q0FDTCxRQUFRO0NBQ1IsTUFBTTtDQUNOLFNBQVM7Q0FDVCxrQkFBa0I7Q0FDbEIsbUJBQW1CO0NBQ25CLFFBQVE7Q0FDUixrQkFBa0I7Q0FDbEIsU0FBUztDQUNULHFCQUFxQjtDQUNyQixpQkFBaUI7Q0FDakIsZUFBZTtDQUNmLFNBQVM7Q0FDVCxjQUFjO0NBQ2QsZ0JBQWdCO0NBQ2hCLGdCQUFnQjtDQUNoQixrQkFBa0I7Q0FDbEIsb0JBQW9CO0NBQ3BCLFlBQVk7Q0FDWixrQkFBa0I7Q0FDbEIsZUFBZTtDQUNmLGdCQUFnQjtDQUNoQixXQUFXO0NBQ1gsV0FBVztDQUNYLFlBQVk7Q0FDWixhQUFhO0NBQ2IsWUFBWTtDQUNaLG9CQUFvQjtDQUNwQixrQkFBa0I7Q0FDbEIsZ0JBQWdCO0NBQ2hCLFNBQVM7QUFDWDs7Ozs7Ozs7OztBQVdBLFNBQXdCQyxjQUFZLFNBQVMsU0FBUztDQUVwRCxVQUFVLFdBQVcsQ0FBQztDQUN0QixVQUFVLFdBQVcsQ0FBQztDQU10QixNQUFNLFNBQVMsT0FBTyxPQUFPLElBQUk7Q0FDakMsT0FBTyxlQUFlLFFBQVEsa0JBQWtCLHdCQUF3QjtDQUV4RSxNQUFNLE9BQU8sa0JBQWtCO0VBQUUsR0FBRztFQUFTLEdBQUc7Q0FBUSxDQUFDO0NBRXpELEtBQUssSUFBSSxJQUFJLEdBQUcsTUFBTSxLQUFLLFFBQVEsSUFBSSxLQUFLLEtBQUs7RUFDL0MsTUFBTSxPQUFPLEtBQUs7RUFDbEIsSUFBSSxTQUFTLGVBQWUsU0FBUyxpQkFBaUIsU0FBUyxhQUFhO0VBQzVFLE1BQU0sUUFBUUQsY0FBTSxXQUFXLFVBQVUsSUFBSSxJQUFJLFNBQVMsUUFBUTtFQUNsRSxNQUFNLElBQUlBLGNBQU0sV0FBVyxTQUFTLElBQUksSUFBSSxRQUFRLFFBQVEsS0FBQTtFQUM1RCxNQUFNLElBQUlBLGNBQU0sV0FBVyxTQUFTLElBQUksSUFBSSxRQUFRLFFBQVEsS0FBQTtFQUM1RCxNQUFNLGNBQ0osVUFBVSxrQkFBa0IsTUFBTSxHQUFHLEdBQUcsTUFBTSxTQUFTLE9BQU8sSUFBSSxNQUFNLEdBQUcsR0FBRyxJQUFJO0VBQ3BGLGNBQU8sWUFBWSxXQUFXLEtBQUssVUFBVSxvQkFBcUIsT0FBTyxRQUFRO0NBQ25GO0NBRUEsSUFDRUEsY0FBTSxXQUFXLFNBQVMsZ0JBQWdCLEtBQzFDQSxjQUFNLFlBQVksUUFBUSxjQUFjLEtBQ3hDLDRCQUE0QixTQUFTLFNBQVMsaUNBQWlDLE1BQU0sT0FDckY7RUFDQSxJQUFJQSxjQUFNLFdBQVcsU0FBUyxnQkFBZ0IsR0FDNUMsT0FBTyxpQkFBaUIsZUFBZSxLQUFBLEdBQVcsUUFBUSxjQUFjO09BRXhFLE9BQU8sT0FBTztDQUVsQjtDQUVBLE9BQU87QUFDVDs7QUMxT0EsSUFBTSw0QkFBNEIsQ0FBQyxnQkFBZ0IsZ0JBQWdCOzs7Ozs7Ozs7Ozs7QUFhbkUsU0FBd0IsbUJBQW1CLFNBQVMsYUFBYSxRQUFRO0NBQ3ZFLElBQUksV0FBVyxnQkFBZ0I7RUFDN0IsUUFBUSxJQUFJLFdBQVc7RUFDdkI7Q0FDRjtDQUVBLE9BQU8sUUFBUSxlQUFlLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLEtBQUssU0FBUztFQUN4RCxJQUFJLDBCQUEwQixTQUFTLElBQUksWUFBWSxDQUFDLEdBQ3RELFFBQVEsSUFBSSxLQUFLLEdBQUc7Q0FFeEIsQ0FBQztBQUNIOzs7Ozs7Ozs7O0FDUEEsSUFBTUUsZ0JBQWMsUUFDbEIsbUJBQW1CLEdBQUcsQ0FBQyxDQUFDLFFBQVEscUJBQXFCLEdBQUcsUUFDdEQsT0FBTyxhQUFhLFNBQVMsS0FBSyxFQUFFLENBQUMsQ0FDdkM7QUFFRixJQUFNLGNBQWMsU0FBU0MsZ0JBQVEsS0FBSyxJQUFJO0FBRTlDLFNBQVMsY0FBYyxRQUFRLGlCQUFpQixZQUFZO0NBQzFELE1BQU0sWUFBWUMsY0FBWSxDQUFDLEdBQUcsTUFBTTtDQUl4QyxNQUFNLE9BQU8sUUFBU0MsY0FBTSxXQUFXLFdBQVcsR0FBRyxJQUFJLFVBQVUsT0FBTyxLQUFBO0NBRTFFLE1BQU0sT0FBTyxJQUFJLE1BQU07Q0FDdkIsSUFBSSxnQkFBZ0IsSUFBSSxlQUFlO0NBQ3ZDLE1BQU0saUJBQWlCLElBQUksZ0JBQWdCO0NBQzNDLE1BQU0saUJBQWlCLElBQUksZ0JBQWdCO0NBQzNDLElBQUksVUFBVSxJQUFJLFNBQVM7Q0FDM0IsTUFBTSxPQUFPLElBQUksTUFBTTtDQUN2QixNQUFNLFVBQVUsSUFBSSxTQUFTO0NBQzdCLE1BQU0sb0JBQW9CLElBQUksbUJBQW1CO0NBQ2pELE1BQU0sTUFBTSxJQUFJLEtBQUs7Q0FFckIsVUFBVSxVQUFVLFVBQVVDLGVBQWEsS0FBSyxPQUFPO0NBRXZELFVBQVUsTUFBTSxTQUNkLGNBQWMsU0FBUyxLQUFLLG1CQUFtQixTQUFTLEdBQ3hELElBQUksUUFBUSxHQUNaLElBQUksa0JBQWtCLENBQ3hCO0NBR0EsSUFBSSxNQUFNO0VBQ1IsTUFBTSxXQUFXRCxjQUFNLFlBQVksTUFBTSxVQUFVLEtBQUs7RUFDeEQsTUFBTSxXQUFXQSxjQUFNLFlBQVksTUFBTSxVQUFVLEtBQUs7RUFDeEQsTUFBTSxlQUFlLElBQUksY0FBYztFQUN2QyxNQUFNLGlCQUNKLGdCQUNBQSxjQUFNLFdBQVcsY0FBYyx5QkFBeUIsS0FDeEQsYUFBYSw0QkFBNEI7RUFFM0MsSUFBSTtHQUNGLFFBQVEsSUFDTixpQkFFQSxXQUNFLE1BQ0csaUJBQWlCSCxhQUFXLFFBQVEsSUFBSSxZQUN2QyxPQUNDLFdBQVdBLGFBQVcsUUFBUSxJQUFJLEdBQ3ZDLENBQ0o7RUFDRixTQUFTLEdBQUc7R0FDVixNQUFNSyxhQUFXLEtBQUssR0FBR0EsYUFBVyxzQkFBc0IsTUFBTTtFQUNsRTtDQUNGO0NBRUEsSUFBSUYsY0FBTSxXQUFXLElBQUksR0FBRztFQUMxQixNQUFNLGFBQWFBLGNBQU0sWUFBWSxNQUFNLFlBQVk7RUFFdkQsSUFDRUcsaUJBQVMseUJBQ1RBLGlCQUFTLGtDQUNUSCxjQUFNLGNBQWMsSUFBSSxHQUV4QixRQUFRLGVBQWUsS0FBQSxDQUFTO09BQzNCLElBQUlBLGNBQU0sV0FBVyxVQUFVLEdBRXBDLG1CQUFtQixTQUFTLFdBQVcsS0FBSyxJQUFJLEdBQUcsSUFBSSxzQkFBc0IsQ0FBQztDQUVsRjtDQU1BLElBQUlHLGlCQUFTLHVCQUF1QjtFQUNsQyxJQUFJSCxjQUFNLFdBQVcsYUFBYSxHQUNoQyxnQkFBZ0IsY0FBYyxTQUFTO0VBU3pDLElBRkUsa0JBQWtCLFFBQVMsaUJBQWlCLFFBQVFJLHdCQUFnQixVQUFVLEdBQUcsR0FFL0Q7R0FDbEIsTUFBTSxZQUFZLGtCQUFrQixrQkFBa0IsZUFBZSxjQUFjO0dBRW5GLElBQUksV0FDRixRQUFRLElBQUksZ0JBQWdCLFNBQVM7RUFFekM7Q0FDRjtDQUVBLE9BQU87QUFDVDtBQ3JHQSxJQUFBLGNBRjhCLE9BQU8sbUJBQW1CLGVBR3RELFNBQVUsUUFBUTtDQUNoQixPQUFPLElBQUksUUFBUSxTQUFTLG1CQUFtQixTQUFTLFFBQVE7RUFDOUQsSUFBSTtFQUNKLElBQUk7R0FDRixNQUFNLFFBQ0pDLGlCQUFTLHlCQUF5QixPQUFPLFdBQVcsZUFBZSxPQUFPO0dBQzVFLGVBQWUsU0FBU0MsY0FBTSxXQUFXLE1BQU0sR0FBRztFQUNwRCxTQUFTLEdBQUcsQ0FFWjtFQUNBLElBQUk7RUFDSixNQUFNLFVBQVUsY0FDZCxRQUNBLGdCQUNLLFNBQVM7R0FDUixpQkFBaUI7R0FDakIsT0FBTztFQUNULElBQ0EsS0FBQSxDQUNOO0VBQ0EsSUFBSSxjQUFjLFFBQVE7RUFDMUIsTUFBTSxpQkFBaUJDLGVBQWEsS0FBSyxRQUFRLE9BQU8sQ0FBQyxDQUFDLFVBQVU7RUFDcEUsSUFBSSxFQUFFLGNBQWMsa0JBQWtCLHVCQUF1QjtFQUM3RCxJQUFJO0VBQ0osSUFBSTtFQUNKLElBQUksaUJBQWlCO0VBQ3JCLElBQUksYUFBYSxlQUFlO0VBRWhDLFNBQVMsT0FBTztHQUNkLGFBQWEsU0FBUztHQUd0QixJQUFJO0lBQ0YsZUFBZSxZQUFZO0dBQzdCLFNBQVMsS0FBSztJQUNaLGlCQUFpQjtLQUNmLE1BQU07SUFDUixDQUFDO0dBQ0g7R0FDQSxJQUFJO0lBQ0YsaUJBQWlCLGNBQWM7R0FDakMsU0FBUyxLQUFLO0lBQ1osaUJBQWlCO0tBQ2YsTUFBTTtJQUNSLENBQUM7R0FDSDtHQUlBLElBQUksU0FBUztJQUNYLHFCQUFxQixRQUFRLG9CQUFvQixZQUFZLGlCQUFpQjtJQUM5RSxJQUFJLFFBQVEsUUFBUTtLQUNsQixtQkFBbUIsUUFBUSxPQUFPLG9CQUFvQixZQUFZLGVBQWU7S0FDakYsZUFBZSxRQUFRLE9BQU8sb0JBQW9CLFdBQVcsV0FBVztJQUMxRTtHQUNGO0dBRUEsUUFBUSxlQUFlLFFBQVEsWUFBWSxZQUFZLFVBQVU7R0FFakUsUUFBUSxVQUFVLFFBQVEsT0FBTyxvQkFBb0IsU0FBUyxVQUFVO0VBQzFFO0VBRUEsSUFBSSxVQUFVLElBQUksZUFBZTtFQUVqQyxRQUFRLEtBQUssUUFBUSxPQUFPLFlBQVksR0FBRyxRQUFRLEtBQUssSUFBSTtFQUc1RCxRQUFRLFVBQVUsUUFBUTtFQUUxQixTQUFTLFVBQVUsT0FBTztHQUN4QixJQUFJLENBQUMsU0FDSDtHQVdGLElBQ0UsUUFBUSxXQUFXLE1BQ2xCLGNBQWMsNkJBQTZCLFFBQVEsR0FBRyxDQUFDLEtBQ3RELGNBQWNGLGlCQUFTLE1BQU0sT0FBTyxVQUN0QyxFQUFFLFFBQVEsZUFBZSxRQUFRLFlBQVksV0FBVyxPQUFPLElBQy9EO0lBQ0EsT0FBTyxJQUFJRyxhQUFXLG1CQUFtQkEsYUFBVyxjQUFjLFFBQVEsT0FBTyxDQUFDO0lBQ2xGLEtBQUs7SUFHTCxVQUFVO0lBQ1Y7R0FDRjtHQU9BLElBQUk7SUFDRixJQUFJLE9BQ0YsMEJBQTBCLHVCQUF1QixLQUFLO1NBRXRELGlCQUFpQixjQUFjO0dBRW5DLFNBQVMsS0FBSztJQUNaLGlCQUFpQjtLQUNmLE1BQU07SUFDUixDQUFDO0dBQ0g7R0FHQSxJQUFJLENBQUMsU0FDSDtHQUlGLE1BQU0sa0JBQWtCRCxlQUFhLEtBQ25DLDJCQUEyQixXQUFXLFFBQVEsc0JBQXNCLENBQ3RFO0dBY0EsT0FDRSxTQUFTLFNBQVMsT0FBTztJQUN2QixRQUFRLEtBQUs7SUFDYixLQUFLO0dBQ1AsR0FDQSxTQUFTLFFBQVEsS0FBSztJQUNwQixPQUFPLEdBQUc7SUFDVixLQUFLO0dBQ1AsR0FDQTtJQWpCQSxNQUpBLENBQUMsZ0JBQWdCLGlCQUFpQixVQUFVLGlCQUFpQixTQUN6RCxRQUFRLGVBQ1IsUUFBUTtJQUdaLFFBQVEsUUFBUTtJQUNoQixZQUFZLFFBQVE7SUFDcEIsU0FBUztJQUNUO0lBQ0E7R0FZQSxDQUNGO0dBR0EsVUFBVTtFQUNaO0VBRUEsSUFBSSxlQUFlLFNBRWpCLFFBQVEsWUFBWTtPQUdwQixRQUFRLHFCQUFxQixTQUFTLGFBQWE7R0FDakQsSUFBSSxDQUFDLFdBQVcsUUFBUSxlQUFlLEdBQ3JDO0dBT0YsSUFDRSxRQUFRLFdBQVcsS0FDbkIsRUFBRSxRQUFRLGVBQWUsUUFBUSxZQUFZLFdBQVcsT0FBTyxJQUUvRDtHQUlGLFdBQVcsU0FBUztFQUN0QjtFQUlGLFFBQVEsVUFBVSxTQUFTLGNBQWM7R0FDdkMsSUFBSSxDQUFDLFNBQ0g7R0FHRixPQUFPLElBQUlDLGFBQVcsbUJBQW1CQSxhQUFXLGNBQWMsUUFBUSxPQUFPLENBQUM7R0FDbEYsS0FBSztHQUdMLFVBQVU7RUFDWjtFQUdBLFFBQVEsVUFBVSxTQUFTLFlBQVksT0FBTztHQUs1QyxNQUFNLE1BQU0sSUFBSUEsYUFESixTQUFTLE1BQU0sVUFBVSxNQUFNLFVBQVUsaUJBQ3JCQSxhQUFXLGFBQWEsUUFBUSxPQUFPO0dBRXZFLElBQUksUUFBUSxTQUFTO0dBQ3JCLE9BQU8sR0FBRztHQUNWLEtBQUs7R0FDTCxVQUFVO0VBQ1o7RUFHQSxRQUFRLFlBQVksU0FBUyxnQkFBZ0I7R0FDM0MsSUFBSSxDQUFDLFNBQVM7R0FDZCxJQUFJLHNCQUFzQixRQUFRLFVBQzlCLGdCQUFnQixRQUFRLFVBQVUsZ0JBQ2xDO0dBQ0osTUFBTSxlQUFlLFFBQVEsZ0JBQWdCQztHQUM3QyxJQUFJLFFBQVEscUJBQ1Ysc0JBQXNCLFFBQVE7R0FFaEMsT0FDRSxJQUFJRCxhQUNGLHFCQUNBLGFBQWEsc0JBQXNCQSxhQUFXLFlBQVlBLGFBQVcsY0FDckUsUUFDQSxPQUNGLENBQ0Y7R0FDQSxLQUFLO0dBR0wsVUFBVTtFQUNaO0VBR0EsZ0JBQWdCLEtBQUEsS0FBYSxlQUFlLGVBQWUsSUFBSTtFQUcvRCxJQUFJLENBQUNGLGNBQU0sWUFBWSxRQUFRLGVBQWUsR0FDNUMsUUFBUSxrQkFBa0IsQ0FBQyxDQUFDLFFBQVE7RUFJdEMsSUFBSSxnQkFBZ0IsaUJBQWlCLFFBQ25DLFFBQVEsZUFBZSxRQUFRO0VBSWpDLElBQUksb0JBQW9CO0dBQ3RCLENBQUMsbUJBQW1CLGVBQWUsMEJBQTBCLHFCQUMzRCxvQkFDQSxJQUNGO0dBQ0EsUUFBUSxpQkFBaUIsWUFBWSxpQkFBaUI7RUFDeEQ7RUFHQSxJQUFJLG9CQUFvQixRQUFRLFFBQVE7R0FDdEMsQ0FBQyxpQkFBaUIsZUFBZSxxQkFBcUIsZ0JBQWdCO0dBRXRFLFFBQVEsT0FBTyxpQkFBaUIsWUFBWSxlQUFlO0dBRTNELFFBQVEsT0FBTyxpQkFBaUIsV0FBVyxXQUFXO0VBQ3hEO0VBRUEsSUFBSSxRQUFRLGVBQWUsUUFBUSxRQUFRO0dBR3pDLGNBQWMsV0FBVztJQUN2QixJQUFJLENBQUMsU0FDSDtJQUVGLE9BQU8sQ0FBQyxVQUFVLE9BQU8sT0FBTyxJQUFJSSxnQkFBYyxNQUFNLFFBQVEsT0FBTyxJQUFJLE1BQU07SUFDakYsTUFBTSxNQUFNO0lBQ1osS0FBSztJQUNMLFVBQVU7SUFDVixJQUFJLE1BQU07R0FDWjtHQUVBLFFBQVEsZUFBZSxRQUFRLFlBQVksVUFBVSxVQUFVO0dBQy9ELElBQUksQ0FBQyxTQUFTO0dBQ2QsSUFBSSxRQUFRLFFBQ1YsUUFBUSxPQUFPLFVBQ1gsV0FBVyxJQUNYLFFBQVEsT0FBTyxpQkFBaUIsU0FBUyxVQUFVO0VBRTNEO0VBRUEsSUFBSSxDQUFDLFNBQVM7RUFFZCxNQUFNLFdBQVcsY0FBYyxRQUFRLEdBQUc7RUFFMUMsSUFBSSxZQUFZLENBQUNMLGlCQUFTLFVBQVUsU0FBUyxRQUFRLEdBQUc7R0FDdEQsT0FDRSxJQUFJRyxhQUNGLDBCQUEwQixXQUFXLEtBQ3JDQSxhQUFXLGlCQUNYLE1BQ0YsQ0FDRjtHQUNBLEtBQUs7R0FDTDtFQUNGO0VBRUEsTUFBTSxvQkFBb0I7R0FDeEIsSUFBSSxDQUFDLFNBQVM7R0FHZCxJQUFJLHNCQUFzQixTQUN4QixjQUFNLFFBQ0oseUJBQXlCLGNBQWMsR0FDdkMsU0FBUyxpQkFBaUIsS0FBSyxLQUFLO0lBQ2xDLFFBQVEsaUJBQWlCLEtBQUssR0FBRztHQUNuQyxDQUNGO0dBRUYsUUFBUSxLQUFLLGVBQWUsSUFBSTtFQUNsQztFQUVBLElBQUksZ0JBQWdCO0dBR2xCLE1BQU0sTUFDSixPQUFPLGdCQUFnQixlQUFlRixjQUFNLFdBQVcsWUFBWSxHQUFHLFVBQzVELFlBQVksSUFBSSxJQUN0QixLQUFLO0dBQ1gsTUFBTSxXQUFXLFFBQVEsVUFBVSxJQUFJLElBQUksSUFBSSxPQUFPLFFBQVEsT0FBTyxJQUFJLEtBQUE7R0FDekUsTUFBTSx1QkFBdUI7SUFDM0IsSUFBSSxDQUFDLFNBQVM7SUFDZCxNQUFNLE1BQU07SUFDWixJQUFJLFVBQVU7SUFDZCxJQUFJLE1BQU07R0FDWjtHQUNBLElBQUksYUFBYSxLQUFBLEdBQVc7SUFDMUIsTUFBTSx3QkFBd0I7S0FDNUIsTUFBTSxZQUFZLFdBQVcsSUFBSTtLQUNqQyxJQUFJLFlBQVksR0FFZCxZQUFZLFdBQVcsaUJBQWlCLEtBQUssSUFBSSxXQUFXLFVBQVUsQ0FBQztVQUV2RSxlQUFlO0lBRW5CO0lBQ0EsZ0JBQWdCO0dBQ2xCO0dBRUEsZ0JBQ0csVUFBVSxjQUFjLENBQUMsQ0FDekIsTUFBTSxVQUFVO0lBQ2YsSUFBSSxDQUFDLFNBQVM7SUFFZCxJQUFJLGFBQWEsS0FBQSxLQUFhLElBQUksS0FBSyxVQUFVO0tBQy9DLGVBQWU7S0FDZjtJQUNGO0lBQ0EsSUFBSSxPQUFPO0tBQ1QsTUFBTSxhQUNKQSxjQUFNLFdBQVcsU0FBUyxnQkFBZ0IsS0FBSyxRQUFRO0tBQ3pELGVBQWUsSUFBSSxZQUFZLEtBQUs7SUFDdEM7SUFDQSxZQUFZO0dBQ2QsQ0FBQyxDQUFDLENBQ0QsT0FBTyxVQUFVO0lBQ2hCLElBQUksQ0FBQyxTQUFTO0lBQ2QsT0FBT0UsYUFBVyxLQUFLLE9BQU8sTUFBTSxRQUFRLE9BQU8sQ0FBQztJQUNwRCxLQUFLO0lBQ0wsVUFBVTtHQUNaLENBQUM7RUFDTCxPQUNFLFlBQVk7Q0FFaEIsQ0FBQztBQUNIOztBQzNYRixJQUFNLGtCQUFrQixTQUFTLFlBQVk7Q0FDM0MsVUFBVSxVQUFVLFFBQVEsT0FBTyxPQUFPLElBQUksQ0FBQztDQUUvQyxJQUFJLENBQUMsV0FBVyxDQUFDLFFBQVEsUUFDdkI7Q0FHRixNQUFNLGFBQWEsSUFBSSxnQkFBZ0I7Q0FFdkMsSUFBSSxVQUFVO0NBRWQsTUFBTSxVQUFVLFNBQVUsUUFBUTtFQUNoQyxJQUFJLENBQUMsU0FBUztHQUNaLFVBQVU7R0FDVixZQUFZO0dBQ1osTUFBTSxNQUFNLGtCQUFrQixRQUFRLFNBQVMsS0FBSztHQUNwRCxXQUFXLE1BQ1QsZUFBZUcsZUFDWCxNQUNBLElBQUlDLGdCQUFjLGVBQWUsUUFBUSxJQUFJLFVBQVUsR0FBRyxDQUNoRTtFQUNGO0NBQ0Y7Q0FFQSxJQUFJLFFBQ0YsV0FDQSxpQkFBaUI7RUFDZixRQUFRO0VBQ1IsUUFBUSxJQUFJRCxhQUFXLGNBQWMsUUFBUSxjQUFjQSxhQUFXLFNBQVMsQ0FBQztDQUNsRixHQUFHLE9BQU87Q0FFWixNQUFNLG9CQUFvQjtFQUN4QixJQUFJLENBQUMsU0FDSDtFQUVGLFNBQVMsYUFBYSxLQUFLO0VBQzNCLFFBQVE7RUFDUixRQUFRLFNBQVMsV0FBVztHQUMxQixNQUFNLG9CQUFvQkUsY0FBTSxZQUFZLFFBQVEsYUFBYTtHQUNqRSxjQUFNLFdBQVcsaUJBQWlCLElBQzlCLGtCQUFrQixLQUFLLFFBQVEsT0FBTyxJQUN0QyxPQUFPLG9CQUFvQixTQUFTLE9BQU87RUFDakQsQ0FBQztFQUNELFVBQVU7Q0FDWjtDQUVBLFFBQVEsU0FBUyxXQUFXO0VBQzFCLElBQUksU0FDRjtFQUdGLElBQUksT0FBTyxTQUFTO0dBQ2xCLFFBQVEsS0FBSyxNQUFNO0dBQ25CO0VBQ0Y7RUFFQSxPQUFPLGlCQUFpQixTQUFTLFNBQVMsRUFBRSxNQUFNLEtBQUssQ0FBQztDQUMxRCxDQUFDO0NBRUQsTUFBTSxFQUFFLFdBQVc7Q0FFbkIsT0FBTyxvQkFBb0JBLGNBQU0sS0FBSyxXQUFXO0NBRWpELE9BQU87QUFDVDs7QUNwRUEsSUFBYSxjQUFjLFdBQVcsT0FBTyxXQUFXO0NBQ3RELElBQUksTUFBTSxNQUFNO0NBRWhCLElBQUksQ0FBQyxhQUFhLE1BQU0sV0FBVztFQUNqQyxNQUFNO0VBQ047Q0FDRjtDQUVBLElBQUksTUFBTTtDQUNWLElBQUk7Q0FFSixPQUFPLE1BQU0sS0FBSztFQUNoQixNQUFNLE1BQU07RUFDWixNQUFNLE1BQU0sTUFBTSxLQUFLLEdBQUc7RUFDMUIsTUFBTTtDQUNSO0FBQ0Y7QUFFQSxJQUFhLFlBQVksaUJBQWlCLFVBQVUsV0FBVztDQUM3RCxXQUFXLE1BQU0sU0FBUyxXQUFXLFFBQVEsR0FDM0MsT0FBTyxZQUFZLE9BQU8sU0FBUztBQUV2QztBQUVBLElBQU0sYUFBYSxpQkFBaUIsUUFBUTtDQUMxQyxJQUFJLE9BQU8sT0FBTyxnQkFBZ0I7RUFDaEMsT0FBTztFQUNQO0NBQ0Y7Q0FFQSxNQUFNLFNBQVMsT0FBTyxVQUFVO0NBQ2hDLElBQUk7RUFDRixTQUFTO0dBQ1AsTUFBTSxFQUFFLE1BQU0sVUFBVSxNQUFNLE9BQU8sS0FBSztHQUMxQyxJQUFJLE1BQ0Y7R0FFRixNQUFNO0VBQ1I7Q0FDRixVQUFVO0VBQ1IsTUFBTSxPQUFPLE9BQU87Q0FDdEI7QUFDRjtBQUVBLElBQWEsZUFBZSxRQUFRLFdBQVcsWUFBWSxhQUFhO0NBQ3RFLE1BQU0sV0FBVyxVQUFVLFFBQVEsU0FBUztDQUU1QyxJQUFJLFFBQVE7Q0FDWixJQUFJO0NBQ0osSUFBSSxhQUFhLE1BQU07RUFDckIsSUFBSSxDQUFDLE1BQU07R0FDVCxPQUFPO0dBQ1AsWUFBWSxTQUFTLENBQUM7RUFDeEI7Q0FDRjtDQUVBLE9BQU8sSUFBSSxlQUNUO0VBQ0UsTUFBTSxLQUFLLFlBQVk7R0FDckIsSUFBSTtJQUNGLE1BQU0sRUFBRSxNQUFNLFVBQVUsTUFBTSxTQUFTLEtBQUs7SUFFNUMsSUFBSSxNQUFNO0tBQ1IsVUFBVTtLQUNWLFdBQVcsTUFBTTtLQUNqQjtJQUNGO0lBRUEsSUFBSSxNQUFNLE1BQU07SUFDaEIsSUFBSSxZQUVGLFdBQVcsU0FEaUIsR0FDTjtJQUV4QixXQUFXLFFBQVEsSUFBSSxXQUFXLEtBQUssQ0FBQztHQUMxQyxTQUFTLEtBQUs7SUFDWixVQUFVLEdBQUc7SUFDYixNQUFNO0dBQ1I7RUFDRjtFQUNBLE9BQU8sUUFBUTtHQUNiLFVBQVUsTUFBTTtHQUNoQixPQUFPLFNBQVMsT0FBTztFQUN6QjtDQUNGLEdBQ0EsRUFDRSxlQUFlLEVBQ2pCLENBQ0Y7QUFDRjs7QUN0RkEsSUFBTSxPQUFPO0FBQ2IsSUFBTSxrQkFBa0IsVUFBVSxPQUFPLEtBQUssQ0FBQyxDQUFDLFFBQVEsZUFBZSxJQUFJO0FBQzNFLElBQU0sY0FBYyxVQUNsQixPQUFPLEtBQUssQ0FBQyxDQUFDLFFBQVEsYUFBYSxTQUNqQyxTQUFTLE9BQU8sUUFBUSxTQUFTLE9BQU8sUUFBUSxLQUNsRDtBQUlGLElBQU0sZUFBZSxPQUFPLGNBQWM7Q0FDeEMsSUFBSSxTQUFTO0NBQ2IsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLE1BQU0sUUFBUSxLQUFLO0VBQ3JDLE1BQU0sT0FBTyxNQUFNLFdBQVcsQ0FBQztFQUMvQixJQUFJLGNBQWMsU0FBUyxNQUFNLFNBQVMsS0FBSztHQUM3QyxJQUFJLFNBQVMsTUFBTSxNQUFNLFdBQVcsSUFBSSxDQUFDLE1BQU0sSUFBSTtHQUNuRCxVQUFVO0VBQ1osT0FBTyxJQUFJLE9BQU8sS0FDaEI7T0FDSyxJQUFJLE9BQU8sTUFDaEIsVUFBVTtPQUNMLElBQ0wsUUFBUSxTQUNSLFFBQVEsU0FDUixNQUFNLFdBQVcsSUFBSSxDQUFDLEtBQUssU0FDM0IsTUFBTSxXQUFXLElBQUksQ0FBQyxLQUFLLE9BQzNCO0dBQ0EsVUFBVTtHQUNWO0VBQ0YsT0FDRSxVQUFVO0NBRWQ7Q0FDQSxPQUFPO0FBQ1Q7QUFHQSxJQUFhLGdCQUFiLGNBQW1DLFVBQVU7Q0FDM0MsWUFBWSxTQUFTLFFBQVE7RUFDM0IsTUFBTSxPQUFPO0VBQ2IsS0FBSyxPQUFPO0VBQ1osS0FBSyxTQUFTO0NBQ2hCO0FBQ0Y7QUFHQSxTQUF3QixlQUFlLE1BQU0sTUFBTSxPQUFPLFlBQVksVUFBVTtDQUM5RSxJQUFJLENBQUNDLGNBQU0sV0FBVyxJQUFJLEdBQ3hCLE1BQU0sSUFBSSxjQUFjLHlCQUF5QixNQUFNO0NBR3pELElBQ0UsQ0FBQ0EsY0FBTSxTQUFTLFFBQVEsS0FDeEIsQ0FBQyxtQ0FBbUMsS0FBSyxRQUFRLEtBQ2pELEtBQUssS0FBSyxRQUFRLEdBRWxCLE1BQU0sSUFBSSxjQUFjLDhCQUE4QixVQUFVO0NBRWxFLE1BQU0sU0FBUyxPQUFPLFdBQVc7Q0FDakMsSUFBSSxTQUFTLE9BQU87Q0FDcEIsTUFBTSxRQUFRLENBQUM7Q0FDZixNQUFNLGVBQWUsVUFBVTtFQUM3QixJQUFJLFNBQVMsUUFBUSxPQUFPLE1BQU0sV0FBVztDQUMvQztDQUNBLFlBQVksQ0FBQztDQUViLEtBQUssTUFBTSxDQUFDLE1BQU0sVUFBVSxNQUFNO0VBQ2hDLE1BQU0sV0FBV0EsY0FBTSxTQUFTLEtBQUs7RUFDckMsTUFBTSxjQUFjLFdBQVcsWUFBWSxPQUFPLElBQUksSUFBSSxNQUFNO0VBQ2hFLElBQUksQ0FBQyxPQUFPLFNBQVMsV0FBVyxLQUFLLGNBQWMsR0FDakQsTUFBTSxJQUFJLGNBQWMsa0NBQWtDLE1BQU07RUFHbEUsWUFDRSxjQUNFLFlBQVksTUFBTSxJQUFJLEtBQ3JCLENBQUMsWUFBWSxNQUFNLE9BQU8sWUFBWSxNQUFNLE1BQU0sS0FBSyxJQUFJLE1BQzNELENBQUMsWUFBWSxNQUFNLE9BQU8sWUFBWSxNQUFNLE1BQU0sS0FBSyxJQUFJLEVBQ2hFO0VBRUEsSUFBSSxTQUNGLE9BQ0EsV0FDQSxnREFFQSxXQUFXLGVBQWUsSUFBSSxDQUFDLElBQy9CO0VBQ0YsSUFBSSxDQUFDLFVBQ0gsVUFDRSxrQkFDQSxXQUFXQSxjQUFNLFNBQVMsTUFBTSxJQUFJLElBQUksTUFBTSxPQUFPLE1BQU0sSUFDM0QseUJBR0EsT0FBTyxNQUFNLFFBQVEsMEJBQTBCLENBQUMsQ0FBQyxRQUFRLFdBQVcsRUFBRTtFQUUxRSxVQUFVO0VBQ1YsTUFBTSxhQUFhLFlBQVksUUFBUSxLQUFLLElBQUksY0FBYztFQUM5RCxZQUFZLFVBQVU7RUFDdEIsVUFBVTtFQUNWLE1BQU0sS0FBSztHQUFFO0dBQVE7R0FBTztFQUFTLENBQUM7Q0FDeEM7Q0FJQSxNQUFNLFlBQVksQ0FBQztDQUNuQixLQUFLLE1BQU0sUUFBUSxPQUNqQixVQUFVLEtBQUssS0FBSyxRQUFRLEtBQUssV0FBVyxlQUFlLEtBQUssS0FBSyxJQUFJLEtBQUssT0FBTyxJQUFJO0NBRTNGLFVBQVUsS0FBSyxNQUFNO0NBQ3JCLE9BQU8sSUFBSSxLQUFLLFdBQVcsRUFBRSxNQUFNLG1DQUFtQyxTQUFTLENBQUM7QUFDbEY7O0FDM0dBLFNBQXdCLG9CQUFvQixNQUFNLE1BQU0sT0FBTyxZQUFZLFVBQVU7Q0FFbkYsSUFBSSxDQUFDQyxjQUFNLFdBQVcsSUFBSSxHQUN4QixNQUFNLElBQUlDLGFBQVcseUJBQXlCQSxhQUFXLGVBQWU7Q0FHMUUsSUFBSSxhQUFhLEtBQUEsR0FBVztFQUMxQixJQUFJRCxjQUFNLFdBQVdFLGlCQUFTLGNBQWMsR0FDMUMsV0FBVyxXQUFXQSxpQkFBUyxlQUFlLElBQUksa0JBQWtCO09BQy9EO0dBQ0wsTUFBTSxTQUFTRixjQUFNLE9BQU87R0FDNUIsSUFBSSxDQUFDLFVBQVUsQ0FBQ0EsY0FBTSxXQUFXLE9BQU8sZUFBZSxHQUNyRCxNQUFNLElBQUlDLGFBQVcsMkNBQTJDQSxhQUFXLGVBQWU7R0FFNUYsTUFBTSx5QkFBUyxJQUFJLFdBQVcsRUFBRTtHQUNoQyxPQUFPLGdCQUFnQixNQUFNO0dBQzdCLFdBQ0UsV0FBVyxNQUFNLEtBQUssU0FBUyxXQUFXLE1BQU0sTUFBTSxTQUFTLEVBQUUsRUFBQSxDQUFHLE1BQU0sRUFBRSxDQUFDLENBQUMsQ0FBQyxLQUFLLEVBQUU7RUFDMUY7Q0FDRjtDQUVBLElBQUk7RUFDRixPQUFPLGVBQWUsTUFBTSxNQUFNLE9BQU8sWUFBWSxRQUFRO0NBQy9ELFNBQVMsT0FBTztFQUNkLElBQUksaUJBQWlCLGVBQWU7R0FDbEMsTUFBTSxPQUNKLE1BQU0sV0FBVyxhQUFhQSxhQUFXLHVCQUF1QkEsYUFBVztHQUM3RSxNQUFNLElBQUlBLGFBQVcsTUFBTSxTQUFTLElBQUk7RUFDMUM7RUFDQSxNQUFNO0NBQ1I7QUFDRjs7Ozs7Ozs7O0FDN0JBLElBQU0sY0FBYyxhQUNqQixZQUFZLE1BQU0sWUFBWSxNQUM5QixZQUFZLE1BQU0sWUFBWSxNQUM5QixZQUFZLE1BQU0sWUFBWTtBQUVqQyxJQUFNLHdCQUF3QixLQUFLLEdBQUcsUUFDcEMsSUFBSSxJQUFJLE9BQU8sV0FBVyxJQUFJLFdBQVcsSUFBSSxDQUFDLENBQUMsS0FBSyxXQUFXLElBQUksV0FBVyxJQUFJLENBQUMsQ0FBQztBQUV0RixJQUFNLFlBQVksYUFBYyxZQUFZLEtBQUssV0FBVyxNQUFNLFdBQVcsT0FBUTtBQUVyRixJQUFNLGdCQUFnQixhQUNuQixZQUFZLE1BQU0sWUFBWSxNQUM5QixZQUFZLE1BQU0sWUFBWSxPQUM5QixZQUFZLE1BQU0sWUFBWSxNQUMvQixhQUFhLE1BQ2IsYUFBYSxNQUNiLGFBQWEsTUFDYixhQUFhO0FBRWYsSUFBTSxzQkFBc0IsYUFDMUIsYUFBYSxLQUFLLGFBQWEsTUFBTSxhQUFhLE1BQU0sYUFBYSxNQUFNLGFBQWE7QUFFMUYsSUFBTSxlQUFlLGdCQUFnQjtDQUNuQyxNQUFNLFNBQVMsS0FBSyxNQUFNLGNBQWMsQ0FBQztDQUN6QyxNQUFNLFlBQVksY0FBYztDQUNoQyxPQUFPLFNBQVMsS0FBSyxjQUFjLElBQUksSUFBSSxjQUFjLElBQUksSUFBSTtBQUNuRTtBQUlBLElBQU0sa0NBQWtDLFNBQVM7Q0FDL0MsTUFBTSxNQUFNLEtBQUs7Q0FDakIsSUFBSSxVQUFVO0NBRWQsSUFBSSxNQUFNLEtBQUssS0FBSyxXQUFXLE1BQU0sQ0FBQyxNQUFNLElBQWM7RUFDeEQ7RUFFQSxJQUFJLE1BQU0sS0FBSyxLQUFLLFdBQVcsTUFBTSxDQUFDLE1BQU0sSUFDMUM7Q0FFSjtDQUVBLE9BQU8sS0FBSyxPQUFRLE1BQU0sV0FBVyxJQUFLLENBQUM7QUFDN0M7QUEyQkEsSUFBTSxxQ0FBcUMsU0FBUztDQUNsRCxNQUFNLE1BQU0sS0FBSztDQUNqQixJQUFJLGNBQWM7Q0FDbEIsSUFBSSxVQUFVO0NBQ2QsSUFBSSxVQUFVO0NBRWQsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEtBQUssS0FBSztFQUM1QixJQUFJLE9BQU8sS0FBSyxXQUFXLENBQUM7RUFFNUIsSUFBSSxTQUFTLE1BQWdCLHFCQUFxQixNQUFNLEdBQUcsR0FBRyxHQUFHO0dBQy9ELE9BQU8sU0FBUyxLQUFLLFdBQVcsSUFBSSxDQUFDLENBQUMsSUFBSSxLQUFLLFNBQVMsS0FBSyxXQUFXLElBQUksQ0FBQyxDQUFDO0dBQzlFLEtBQUs7RUFDUDtFQUVBLElBQUksbUJBQW1CLElBQUksR0FDekI7RUFHRixJQUFJLFNBQVMsSUFBYztHQUN6QjtHQUNBO0VBQ0Y7RUFFQSxJQUFJLENBQUMsYUFBYSxJQUFJLEtBQUssVUFBVSxHQUFHO0dBQ3RDLFVBQVU7R0FDVjtFQUNGO0VBRUE7Q0FDRjtDQUlBLElBQ0UsV0FDQSxVQUFVLEtBQ1QsVUFBVSxNQUFNLGNBQWMsV0FBVyxNQUFNLEtBQ2hELGNBQWMsTUFBTSxHQUVwQixPQUFPLCtCQUErQixJQUFJO0NBRzVDLE9BQU8sWUFBWSxXQUFXO0FBQ2hDO0FBRUEsSUFBTSx3QkFBd0IsS0FBSyxnQkFBZ0Isa0JBQWtCO0NBQ25FLElBQUksQ0FBQyxPQUFPLE9BQU8sUUFBUSxVQUFVLE9BQU87Q0FDNUMsSUFBSSxDQUFDLFVBQVUsS0FBSyxHQUFHLEdBQUcsT0FBTztDQUVqQyxNQUFNLFFBQVEsSUFBSSxRQUFRLEdBQUc7Q0FDN0IsSUFBSSxRQUFRLEdBQUcsT0FBTztDQUV0QixNQUFNLE9BQU8sSUFBSSxNQUFNLEdBQUcsS0FBSztDQUMvQixNQUFNLE9BQU8sSUFBSSxNQUFNLFFBQVEsQ0FBQztDQUdoQyxJQUZpQixjQUFjLEtBQUssSUFFekIsR0FDVCxPQUFPLGVBQWUsSUFBSTtDQU81QixJQUFJLFFBQVE7Q0FDWixLQUFLLElBQUksSUFBSSxHQUFHLE1BQU0sS0FBSyxRQUFRLElBQUksS0FBSyxLQUFLO0VBQy9DLE1BQU0sSUFBSSxLQUFLLFdBQVcsQ0FBQztFQUMzQixJQUFJLE1BQU0sTUFBZ0IscUJBQXFCLE1BQU0sR0FBRyxHQUFHLEdBQUc7R0FDNUQsU0FBUztHQUNULEtBQUs7RUFDUCxPQUFPLElBQUksSUFBSSxLQUNiLFNBQVM7T0FDSixJQUFJLElBQUksTUFDYixTQUFTO09BQ0osSUFBSSxLQUFLLFNBQVUsS0FBSyxTQUFVLElBQUksSUFBSSxLQUFLO0dBQ3BELE1BQU0sT0FBTyxLQUFLLFdBQVcsSUFBSSxDQUFDO0dBQ2xDLElBQUksUUFBUSxTQUFVLFFBQVEsT0FBUTtJQUNwQyxTQUFTO0lBQ1Q7R0FDRixPQUNFLFNBQVM7RUFFYixPQUNFLFNBQVM7Q0FFYjtDQUNBLE9BQU87QUFDVDs7Ozs7OztBQVFBLFNBQXdCLDRCQUE0QixLQUFLO0NBRXZELE1BQU0sZ0JBQWdCLE9BQU8sUUFBUSxXQUFXLElBQUksUUFBUSxHQUFHLElBQUk7Q0FFbkUsT0FBTyxxQkFDTCxrQkFBa0IsS0FBSyxNQUFNLElBQUksTUFBTSxHQUFHLGFBQWEsR0FDdkQsbUNBQ0EseUJBQ0Y7QUFDRjs7QUNyTEEsSUFBYUUsWUFBVTs7QUNrQnZCLElBQU0scUJBQXFCO0FBRTNCLElBQU0sMEJBQTBCO0NBQzlCLE9BQU87Q0FDUCxVQUFVO0NBQ1YsVUFBVTtDQUNWLGdCQUFnQjtDQUNoQixNQUFNO0NBQ04sV0FBVztDQUNYLFdBQVc7Q0FDWCxVQUFVO0NBQ1YsUUFBUTtBQUNWO0FBRUEsSUFBTSxFQUFFLGVBQWVDOzs7Ozs7Ozs7QUFVdkIsSUFBTSxjQUFjLFFBQ2xCLG1CQUFtQixHQUFHLENBQUMsQ0FBQyxRQUFRLHFCQUFxQixHQUFHLFFBQ3RELE9BQU8sYUFBYSxTQUFTLEtBQUssRUFBRSxDQUFDLENBQ3ZDO0FBTUYsSUFBTSwwQkFBMEIsVUFBVTtDQUN4QyxJQUFJLENBQUNBLGNBQU0sU0FBUyxLQUFLLEdBQ3ZCLE9BQU87Q0FHVCxJQUFJO0VBQ0YsT0FBTyxtQkFBbUIsS0FBSztDQUNqQyxTQUFTLE9BQU87RUFDZCxPQUFPO0NBQ1Q7QUFDRjtBQUVBLElBQU0sUUFBUSxJQUFJLEdBQUcsU0FBUztDQUM1QixJQUFJO0VBQ0YsT0FBTyxDQUFDLENBQUMsR0FBRyxHQUFHLElBQUk7Q0FDckIsU0FBUyxHQUFHO0VBQ1YsT0FBTztDQUNUO0FBQ0Y7QUFFQSxJQUFNLDRCQUE0QixRQUFRO0NBQ3hDLE1BQU0sZ0JBQWdCLElBQUksUUFBUSxLQUFLO0NBQ3ZDLElBQUksYUFBYTtDQUNqQixJQUFJLGtCQUFrQixJQUNwQixhQUFhLFdBQVcsTUFBTSxnQkFBZ0IsQ0FBQztDQUVqRCxPQUFPLFdBQVcsU0FBUyxHQUFHLEtBQUssV0FBVyxTQUFTLEdBQUc7QUFDNUQ7QUFFQSxJQUFNLFdBQVcsUUFBUTtDQUN2QixNQUFNLGVBQ0pBLGNBQU0sV0FBVyxLQUFBLEtBQWFBLGNBQU0sV0FBVyxPQUFPQSxjQUFNLFNBQVM7Q0FDdkUsTUFBTSxFQUFFLGdCQUFnQixnQkFBZ0I7Q0FFeEMsTUFBTUEsY0FBTSxNQUFNLEtBQ2hCLEVBQ0UsZUFBZSxLQUNqQixHQUNBO0VBQ0UsU0FBUyxhQUFhO0VBQ3RCLFVBQVUsYUFBYTtFQUN2QixNQUFNLGFBQWE7Q0FDckIsR0FDQSxHQUNGO0NBRUEsTUFBTSxXQUFXQSxjQUFNLFdBQVcsS0FBSyxPQUFPLElBQUksSUFBSSxRQUFRLEtBQUE7Q0FDOUQsTUFBTSxFQUFFLFNBQVMsVUFBVSxTQUFTO0NBQ3BDLE1BQU0sbUJBQW1CLFdBQVcsV0FBVyxRQUFRLElBQUksT0FBTyxVQUFVO0NBQzVFLE1BQU0scUJBQXFCLFdBQVcsT0FBTztDQUM3QyxNQUFNLHNCQUFzQixXQUFXLFFBQVE7Q0FFL0MsSUFBSSxDQUFDLGtCQUNILE9BQU87Q0FHVCxNQUFNLDRCQUE0QixvQkFBb0IsV0FBVyxjQUFjO0NBRS9FLE1BQU0sYUFDSixxQkFDQyxPQUFPLGdCQUFnQixlQUVqQixhQUFhLFFBQ1osUUFBUSxPQUFPLEdBQUcsRUFBQSxDQUNwQixJQUFJLFlBQVksQ0FBQyxJQUNuQixPQUFPLFFBQVEsSUFBSSxXQUFXLE1BQU0sSUFBSSxRQUFRLEdBQUcsQ0FBQyxDQUFDLFlBQVksQ0FBQztDQUV4RSxNQUFNLHdCQUNKLHNCQUNBLDZCQUNBLFdBQVc7RUFDVCxJQUFJLGlCQUFpQjtFQUVyQixNQUFNLFVBQVUsSUFBSSxRQUFRQyxpQkFBUyxRQUFRO0dBQzNDLE1BQU0sSUFBSSxlQUFlO0dBQ3pCLFFBQVE7R0FDUixJQUFJLFNBQVM7SUFDWCxpQkFBaUI7SUFDakIsT0FBTztHQUNUO0VBQ0YsQ0FBQztFQUVELE1BQU0saUJBQWlCLFFBQVEsUUFBUSxJQUFJLGNBQWM7RUFFekQsSUFBSSxRQUFRLFFBQVEsTUFDbEIsUUFBUSxLQUFLLE9BQU87RUFHdEIsT0FBTyxrQkFBa0IsQ0FBQztDQUM1QixDQUFDO0NBRUgsTUFBTSx5QkFDSix1QkFDQSw2QkFDQSxXQUFXRCxjQUFNLGlCQUFpQixJQUFJLFNBQVMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDO0NBSTFELE1BQU0sa0JBQWtCLE9BQU8sT0FBTyxPQUFPLE9BQU8sSUFBSSxHQUFHLHVCQUF1QjtDQUVsRixJQUFJLHNCQUFzQixDQUFDLFdBQVcsSUFBSSxRQUFRQyxpQkFBUyxRQUFRLGVBQWUsQ0FBQyxHQUFHO0VBQ3BGLE9BQU8sZ0JBQWdCO0VBSXZCLElBQUksQ0FBQyxXQUFXLElBQUksUUFBUUEsaUJBQVMsUUFBUSxlQUFlLENBQUMsR0FDM0QsZ0JBQWdCLFFBQVEsd0JBQXdCO0NBRXBEO0NBRUEsTUFBTSxZQUFZLEVBQ2hCLFFBQVEsNEJBQTRCLFFBQVEsSUFBSSxNQUNsRDtDQUVBLDJCQUNTO0VBQ0w7R0FBQztHQUFRO0dBQWU7R0FBUTtHQUFZO0VBQVEsQ0FBQyxDQUFDLFNBQVMsU0FBUztHQUN0RSxDQUFDLFVBQVUsVUFDUixVQUFVLFNBQVMsS0FBSyxXQUFXO0lBQ2xDLElBQUksU0FBUyxPQUFPLElBQUk7SUFFeEIsSUFBSSxRQUNGLE9BQU8sT0FBTyxLQUFLLEdBQUc7SUFHeEIsTUFBTSxJQUFJQyxhQUNSLGtCQUFrQixLQUFLLHFCQUN2QkEsYUFBVyxpQkFDWCxNQUNGO0dBQ0Y7RUFDSixDQUFDO0NBQ0gsRUFBQSxDQUFHO0NBRUwsTUFBTSxnQkFBZ0IsT0FBTyxTQUFTO0VBQ3BDLElBQUksUUFBUSxNQUNWLE9BQU87RUFHVCxJQUFJRixjQUFNLE9BQU8sSUFBSSxHQUNuQixPQUFPLEtBQUs7RUFHZCxJQUFJQSxjQUFNLGtCQUFrQixJQUFJLEtBQUtBLGNBQU0sY0FBYyxJQUFJLEdBQzNELE9BQU8sS0FBSztFQUdkLElBQUlBLGNBQU0sa0JBQWtCLElBQUksR0FDOUIsT0FBTyxPQUFPO0VBR2hCLElBQUlBLGNBQU0sU0FBUyxJQUFJLEdBQ3JCLFFBQVEsTUFBTSxXQUFXLElBQUksRUFBQSxDQUFHO0NBRXBDO0NBRUEsTUFBTSxvQkFBb0IsT0FBTyxTQUFTLFNBQVM7RUFDakQsTUFBTSxTQUFTQSxjQUFNLGVBQWUsUUFBUSxpQkFBaUIsQ0FBQztFQUU5RCxPQUFPLFVBQVUsT0FBTyxjQUFjLElBQUksSUFBSTtDQUNoRDtDQUVBLE9BQU8sT0FBTyxXQUFXO0VBQ3ZCLElBQUksRUFDRixLQUNBLFFBQ0EsTUFDQSxRQUNBLGFBQ0EsU0FDQSxvQkFDQSxrQkFDQSxjQUNBLFNBQ0Esa0JBQWtCLGVBQ2xCLGNBQ0Esa0JBQ0EsZUFDQSxpQkFDRSxjQUFjLE1BQU07RUFFeEIsTUFBTSxzQkFBc0JBLGNBQU0sU0FBUyxnQkFBZ0IsS0FBSyxtQkFBbUI7RUFDbkYsTUFBTSxtQkFBbUJBLGNBQU0sU0FBUyxhQUFhLEtBQUssZ0JBQWdCO0VBQzFFLE1BQU0sT0FBTyxRQUFTQSxjQUFNLFdBQVcsUUFBUSxHQUFHLElBQUksT0FBTyxPQUFPLEtBQUE7RUFFcEUsSUFBSSxTQUFTLFlBQVk7RUFFekIsZUFBZSxnQkFBZ0IsZUFBZSxHQUFBLENBQUksWUFBWSxJQUFJO0VBRWxFLElBQUksaUJBQWlCLGVBQ25CLENBQUMsUUFBUSxlQUFlLFlBQVksY0FBYyxDQUFDLEdBQ25ELE9BQ0Y7RUFFQSxJQUFJLFVBQVU7RUFFZCxNQUFNLGNBQ0osa0JBQ0EsZUFBZSxzQkFDUjtHQUNMLGVBQWUsWUFBWTtFQUM3QjtFQUVGLElBQUk7RUFNSixJQUFJLG1CQUFtQjtFQUN2QixJQUFJLHVCQUF1QjtFQUUzQixNQUFNLDJCQUNKLElBQUlFLGFBQ0YsZ0RBQ0FBLGFBQVcsaUJBQ1gsUUFDQSxPQUNGO0VBRUYsSUFBSTtHQUVGLElBQUksT0FBTyxLQUFBO0dBQ1gsTUFBTSxhQUFhLElBQUksTUFBTTtHQUU3QixJQUFJLFlBR0YsT0FBTztJQUNMLFVBSGVGLGNBQU0sWUFBWSxZQUFZLFVBQVUsS0FBSztJQUk1RCxVQUhlQSxjQUFNLFlBQVksWUFBWSxVQUFVLEtBQUs7R0FJOUQ7R0FHRixJQUFJO0dBQ0osSUFBSSx5QkFBeUIsR0FBRyxHQUFHO0lBQ2pDLFlBQVksSUFBSSxJQUFJLEtBQUtDLGlCQUFTLE1BQU07SUFFeEMsSUFBSSxDQUFDLFNBQVMsVUFBVSxZQUFZLFVBQVUsV0FHNUMsT0FBTztLQUNMLFVBSGtCLHVCQUF1QixVQUFVLFFBRy9CO0tBQ3BCLFVBSGtCLHVCQUF1QixVQUFVLFFBRy9CO0lBQ3RCO0lBR0YsSUFBSSxVQUFVLFlBQVksVUFBVSxVQUFVO0tBQzVDLFVBQVUsV0FBVztLQUNyQixVQUFVLFdBQVc7S0FDckIsTUFBTSxVQUFVO0lBQ2xCO0dBQ0Y7R0FFQSxJQUFJLE1BQU07SUFDUixRQUFRLE9BQU8sZUFBZTtJQUM5QixRQUFRLElBQ04saUJBQ0EsV0FBVyxLQUFLLFlBQVksS0FBSyxZQUFZLE1BQU0sT0FBTyxLQUFLLFlBQVksR0FBRyxDQUFDLENBQ2pGO0dBQ0Y7R0FLQSxJQUFJLHVCQUF1QixhQUFhLFVBQVUsYUFBYSxTQUMzQztRQUFBLDRCQUE0QixVQUFVLElBQzVDLElBQUksa0JBQ2QsTUFBTSxJQUFJQyxhQUNSLDhCQUE4QixtQkFBbUIsYUFDakRBLGFBQVcsa0JBQ1gsUUFDQSxPQUNGO0dBQUE7R0FJSixNQUFNLGtCQUNKRixjQUFNLG9CQUFvQixJQUFJLEtBQUtHLGVBQWEsS0FBSyxJQUFJLFNBQVMsQ0FBQyxDQUFDLENBQUMsZUFBZTtHQUN0RixJQUFJO0dBQ0osSUFDRUgsY0FBTSxTQUFTLGVBQWUsS0FDOUIsbUNBQW1DLEtBQUssZ0JBQWdCLEtBQUssQ0FBQyxHQUM5RDtJQUNBLE1BQU0sYUFBYUcsZUFBYSxnQkFBZ0IsZUFBZTtJQUMvRCxJQUFJSCxjQUFNLFdBQVcsWUFBWSxVQUFVLEdBQUcsZUFBZSxXQUFXO0dBQzFFO0dBRUEsSUFDRUEsY0FBTSxvQkFBb0IsSUFBSSxLQUM5QixXQUFXLFNBQ1gsV0FBVyxXQUNWLG9CQUNFLG9CQUFvQix5QkFDckIsaUJBQWlCLEtBQUEsSUFDbkI7SUFDQSxPQUFPLG9CQUNMLE1BQ0EsTUFDQSxtQkFBbUIsZ0JBQWdCLFVBQ25DLG9CQUNBLFlBQ0Y7SUFHQSxRQUFRLGVBQWUsaUJBQWlCLEtBQUEsSUFBWSxLQUFLLE9BQU8sZUFBZTtJQUMvRSx1QkFBdUIsS0FBSztHQUM5QjtHQU9BLElBQUksb0JBQW9CLFdBQVcsU0FBUyxXQUFXLFFBQVE7SUFDN0QsTUFBTSxpQkFBaUIsTUFBTSxjQUFjLElBQUk7SUFDL0MsSUFBSSxPQUFPLG1CQUFtQixZQUFZLFNBQVMsY0FBYyxHQUFHO0tBQ2xFLHVCQUF1QjtLQUN2QixJQUFJLGlCQUFpQixlQUNuQixNQUFNLG1CQUFtQjtJQUU3QjtHQUNGO0dBSUEsTUFBTSx3QkFDSixxQkFBcUJBLGNBQU0saUJBQWlCLElBQUksS0FBS0EsY0FBTSxTQUFTLElBQUk7R0FFMUUsTUFBTSxzQkFBc0IsUUFBUSxZQUFZLFVBQzlDLFlBQ0UsUUFDQSxxQkFDQyxnQkFBZ0I7SUFDZixJQUFJLG9CQUFvQixjQUFjLGVBQ3BDLE1BQU8sbUJBQW1CLG1CQUFtQjtJQUUvQyxjQUFjLFdBQVcsV0FBVztHQUN0QyxHQUNBLEtBQ0Y7R0FFRixJQUNFLHlCQUNBLFdBQVcsU0FDWCxXQUFXLFdBQ1Ysb0JBQW9CLHdCQUNyQjtJQUNBLHVCQUNFLHdCQUF3QixPQUNwQixNQUFNLGtCQUFrQixTQUFTLElBQUksSUFDckM7SUFJTixJQUFJLHlCQUF5QixLQUFLLHVCQUF1QjtLQUN2RCxJQUFJLFdBQVcsSUFBSSxRQUFRLEtBQUs7TUFDOUIsUUFBUTtNQUNSLE1BQU07TUFDTixRQUFRO0tBQ1YsQ0FBQztLQUVELElBQUk7S0FFSixJQUNFQSxjQUFNLFdBQVcsSUFBSSxNQUNwQixvQkFBb0IsU0FBUyxRQUFRLElBQUksY0FBYyxJQUV4RCxRQUFRLGVBQWUsaUJBQWlCO0tBRzFDLElBQUksU0FBUyxNQUFNO01BQ2pCLE1BQU0sQ0FBQyxZQUFZLFNBQ2hCLG9CQUNDLHVCQUNFLHNCQUNBLHFCQUFxQixlQUFlLGdCQUFnQixDQUFDLENBQ3ZELEtBQ0YsQ0FBQztNQUVILE9BQU8sbUJBQW1CLFNBQVMsTUFBTSxZQUFZLEtBQUs7S0FDNUQ7SUFDRjtHQUNGLE9BQU8sSUFDTCx5QkFDQSxDQUFDLHNCQUNELDZCQUNBLFdBQVcsU0FDWCxXQUFXLFFBRVgsT0FBTyxtQkFBbUIsSUFBSTtRQUN6QixJQUNMLHlCQUNBLHNCQUNBLENBQUMseUJBQ0QsV0FBVyxTQUNYLFdBQVcsUUFFWCxNQUFNLElBQUlFLGFBQ1IsK0VBQ0FBLGFBQVcsaUJBQ1gsUUFDQSxPQUNGO0dBR0YsSUFBSSxDQUFDRixjQUFNLFNBQVMsZUFBZSxHQUNqQyxrQkFBa0Isa0JBQWtCLFlBQVk7R0FLbEQsTUFBTSx5QkFBeUIsc0JBQXNCLGlCQUFpQixRQUFRO0dBSTlFLElBQUlBLGNBQU0sV0FBVyxJQUFJLEdBQUc7SUFDMUIsTUFBTSxjQUFjLFFBQVEsZUFBZTtJQUMzQyxJQUNFLGVBQ0EseUJBQXlCLEtBQUssV0FBVyxLQUN6QyxDQUFDLGFBQWEsS0FBSyxXQUFXLEdBRTlCLFFBQVEsT0FBTyxjQUFjO0dBRWpDO0dBR0EsUUFBUSxJQUFJLGNBQWMsV0FBV0ksV0FBUyxLQUFLO0dBRW5ELE1BQU0sbUJBQ0osZ0JBQWdCLE9BQU8sZUFBZSxPQUFPLE9BQU8sT0FBTyxPQUFPLElBQUksR0FBRyxZQUFZO0dBRXZGLElBQUksa0JBQWtCO0lBR3BCLE9BQU8saUJBQWlCO0lBQ3hCLE9BQU8saUJBQWlCO0lBQ3hCLE9BQU8saUJBQWlCO0lBQ3hCLE9BQU8saUJBQWlCO0lBQ3hCLE9BQU8saUJBQWlCO0lBQ3hCLE9BQU8saUJBQWlCO0dBQzFCO0dBRUEsTUFBTSxrQkFBa0IsT0FBTyxPQUFPLE9BQU8sT0FBTyxJQUFJLEdBQUcsa0JBQWtCO0lBQzNFLFFBQVE7SUFDUixRQUFRLE9BQU8sWUFBWTtJQUMzQixTQUFTLHlCQUF5QixRQUFRLFVBQVUsQ0FBQztJQUNyRCxNQUFNO0lBQ04sUUFBUTtJQUNSLGFBQWEseUJBQXlCLGtCQUFrQixLQUFBO0dBQzFELENBQUM7R0FFRCxJQUFJLG9CQUFvQjtJQUN0QixjQUFNLFFBQVEsa0JBQWtCLE9BQU8sUUFBUTtLQUM3QyxJQUFJLGdCQUFnQixTQUFTLEtBQUEsR0FDM0IsZ0JBQWdCLE9BQU87SUFFM0IsQ0FBQztJQUVELElBQUksZ0JBQWdCLFdBQVcsS0FBQSxHQUM3QixnQkFBZ0IsU0FBUztJQUczQixJQUFJLGdCQUFnQixTQUFTLEtBQUEsR0FDM0IsZ0JBQWdCLE9BQU87R0FFM0I7R0FFQSxJQUFJLGlCQUFpQixHQUFHO0lBQ3RCLGdCQUFnQixXQUFXO0lBRTNCLElBQUksa0JBQ0YsaUJBQWlCLFdBQVc7R0FFaEM7R0FFQSxVQUFVLHNCQUFzQixJQUFJLFFBQVEsS0FBSyxlQUFlO0dBRWhFLElBQUksV0FBVyxPQUFPLHFCQUNsQixPQUFPLFNBQVMsZ0JBQWdCLElBQ2hDLE9BQU8sS0FBSyxlQUFlO0dBRS9CLE1BQU0sa0JBQWtCRCxlQUFhLEtBQUssU0FBUyxPQUFPO0dBSTFELElBQUkscUJBQXFCO0lBQ3ZCLE1BQU0saUJBQWlCSCxjQUFNLGVBQWUsZ0JBQWdCLGlCQUFpQixDQUFDO0lBQzlFLElBQUksa0JBQWtCLFFBQVEsaUJBQWlCLGtCQUM3QyxNQUFNLElBQUlFLGFBQ1IsOEJBQThCLG1CQUFtQixhQUNqREEsYUFBVyxrQkFDWCxRQUNBLE9BQ0Y7R0FFSjtHQUVBLE1BQU0sbUJBQ0osMkJBQTJCLGlCQUFpQixZQUFZLGlCQUFpQjtHQUUzRSxJQUNFLDBCQUNBLFNBQVMsU0FDUixzQkFBc0IsdUJBQXdCLG9CQUFvQixjQUNuRTtJQUNBLE1BQU0sVUFBVSxDQUFDO0lBRWpCO0tBQUM7S0FBVTtLQUFjO0lBQVMsQ0FBQyxDQUFDLFNBQVMsU0FBUztLQUNwRCxRQUFRLFFBQVEsU0FBUztJQUMzQixDQUFDO0lBRUQsTUFBTSx3QkFBd0JGLGNBQU0sZUFBZSxnQkFBZ0IsaUJBQWlCLENBQUM7SUFFckYsTUFBTSxDQUFDLFlBQVksU0FDaEIsc0JBQ0MsdUJBQ0UsdUJBQ0EscUJBQXFCLGVBQWUsa0JBQWtCLEdBQUcsSUFBSSxDQUMvRCxLQUNGLENBQUM7SUFFSCxJQUFJLFlBQVk7SUFDaEIsTUFBTSxtQkFBbUIsZ0JBQWdCO0tBQ3ZDLElBQUkscUJBQXFCO01BQ3ZCLFlBQVk7TUFDWixJQUFJLFlBQVksa0JBQ2QsTUFBTyx1QkFBdUIsSUFBSUUsYUFDaEMsOEJBQThCLG1CQUFtQixhQUNqREEsYUFBVyxrQkFDWCxRQUNBLE9BQ0Y7S0FFSjtLQUNBLGNBQWMsV0FBVyxXQUFXO0lBQ3RDO0lBRUEsV0FBVyxJQUFJLFNBQ2IsWUFBWSxTQUFTLE1BQU0sb0JBQW9CLHVCQUF1QjtLQUNwRSxTQUFTLE1BQU07S0FDZixlQUFlLFlBQVk7SUFDN0IsQ0FBQyxHQUNELE9BQ0Y7R0FDRjtHQUVBLGVBQWUsZ0JBQWdCO0dBRS9CLElBQUksZUFBZSxNQUFNLFVBQVVGLGNBQU0sUUFBUSxXQUFXLFlBQVksS0FBSyxPQUFPLENBQ2xGLFVBQ0EsTUFDRjtHQUtBLElBQUksdUJBQXVCLENBQUMsMEJBQTBCLENBQUMsa0JBQWtCO0lBQ3ZFLElBQUk7SUFDSixJQUFJLGdCQUFnQixNQUFNO0tBQ3hCLElBQUksT0FBTyxhQUFhLGVBQWUsVUFDckMsbUJBQW1CLGFBQWE7VUFDM0IsSUFBSSxPQUFPLGFBQWEsU0FBUyxVQUN0QyxtQkFBbUIsYUFBYTtVQUMzQixJQUFJLE9BQU8saUJBQWlCLFVBQ2pDLG1CQUNFLE9BQU8sZ0JBQWdCLGFBQ25CLElBQUksWUFBWSxDQUFDLENBQUMsT0FBTyxZQUFZLENBQUMsQ0FBQyxhQUN2QyxhQUFhO0lBRXZCO0lBQ0EsSUFBSSxPQUFPLHFCQUFxQixZQUFZLG1CQUFtQixrQkFDN0QsTUFBTSxJQUFJRSxhQUNSLDhCQUE4QixtQkFBbUIsYUFDakRBLGFBQVcsa0JBQ1gsUUFDQSxPQUNGO0dBRUo7R0FFQSxDQUFDLG9CQUFvQixlQUFlLFlBQVk7R0FFaEQsT0FBTyxNQUFNLElBQUksU0FBUyxTQUFTLFdBQVc7SUFDNUMsT0FBTyxTQUFTLFFBQVE7S0FDdEIsTUFBTTtLQUNOLFNBQVNDLGVBQWEsS0FBSyxTQUFTLE9BQU87S0FDM0MsUUFBUSxTQUFTO0tBQ2pCLFlBQVksU0FBUztLQUNyQjtLQUNBO0lBQ0YsQ0FBQztHQUNILENBQUM7RUFDSCxTQUFTLEtBQUs7R0FDWixlQUFlLFlBQVk7R0FLM0IsSUFBSSxrQkFBa0IsZUFBZSxXQUFXLGVBQWUsa0JBQWtCRCxjQUFZO0lBQzNGLE1BQU0sZ0JBQWdCLGVBQWU7SUFDckMsY0FBYyxTQUFTO0lBQ3ZCLFlBQVksY0FBYyxVQUFVO0lBQ3BDLElBQUksUUFBUSxlQUdWLE9BQU8sZUFBZSxlQUFlLFNBQVM7S0FDNUMsV0FBVztLQUNYLE9BQU87S0FDUCxVQUFVO0tBQ1YsWUFBWTtLQUNaLGNBQWM7SUFDaEIsQ0FBQztJQUVILE1BQU07R0FDUjtHQU9BLElBQUksa0JBQWtCO0lBQ3BCLFdBQVcsQ0FBQyxpQkFBaUIsWUFBWSxpQkFBaUIsVUFBVTtJQUNwRSxNQUFNO0dBQ1I7R0FFQSxJQUFJLHNCQUNGLE1BQU07R0FLUixJQUFJLGVBQWVBLGNBQVk7SUFDN0IsV0FBVyxDQUFDLElBQUksWUFBWSxJQUFJLFVBQVU7SUFDMUMsTUFBTTtHQUNSO0dBRUEsSUFBSSxPQUFPLElBQUksU0FBUyxlQUFlLHFCQUFxQixLQUFLLElBQUksT0FBTyxHQUFHO0lBQzdFLE1BQU0sZUFBZSxJQUFJQSxhQUN2QixpQkFDQUEsYUFBVyxhQUNYLFFBQ0EsU0FDQSxPQUFPLElBQUksUUFDYjtJQUdBLE9BQU8sZUFBZSxjQUFjLFNBQVM7S0FDM0MsV0FBVztLQUNYLE9BQU8sSUFBSSxTQUFTO0tBQ3BCLFVBQVU7S0FDVixZQUFZO0tBQ1osY0FBYztJQUNoQixDQUFDO0lBQ0QsTUFBTTtHQUNSO0dBRUEsTUFBTUEsYUFBVyxLQUFLLEtBQUssT0FBTyxJQUFJLE1BQU0sUUFBUSxTQUFTLE9BQU8sSUFBSSxRQUFRO0VBQ2xGO0NBQ0Y7QUFDRjtBQUVBLElBQU0sNEJBQVksSUFBSSxJQUFJO0FBRTFCLElBQWEsWUFBWSxXQUFXO0NBQ2xDLE1BQU0sTUFBTSxPQUFPLE9BQU8sSUFBSTtDQUM5QixNQUFNLGdCQUFnQixVQUFVRixjQUFNLFdBQVcsUUFBUSxLQUFLLEtBQUssT0FBTztDQUMxRTtFQUFDO0VBQVM7RUFBVztFQUFZO0NBQU0sQ0FBQyxDQUFDLFNBQVMsUUFBUTtFQUN4RCxJQUFJLGlCQUFpQkEsY0FBTSxXQUFXLGVBQWUsR0FBRyxHQUN0RCxJQUFJLE9BQU8sY0FBYztDQUU3QixDQUFDO0NBQ0QsTUFBTSxFQUFFLE9BQU8sU0FBUyxVQUFVLFNBQVM7Q0FDM0MsTUFBTSxRQUFRO0VBQUM7RUFBUztFQUFVO0VBQU87Q0FBSTtDQUU3QyxJQUNFLElBRFEsTUFBTSxRQUVkLE1BQ0EsUUFDQSxNQUFNO0NBRVIsT0FBTyxLQUFLO0VBQ1YsT0FBTyxNQUFNO0VBQ2IsU0FBUyxJQUFJLElBQUksSUFBSTtFQUVyQixXQUFXLEtBQUEsS0FBYSxJQUFJLElBQUksTUFBTyxTQUFTLG9CQUFJLElBQUksSUFBSSxJQUFJLFFBQVEsR0FBRyxDQUFFO0VBRTdFLE1BQU07Q0FDUjtDQUVBLE9BQU87QUFDVDtBQUVnQixTQUFTOzs7Ozs7Ozs7OztBQzN0QnpCLElBQU0sZ0JBQWdCO0NBQ3BCLE1BQUE7Q0FDQSxLQUFLSztDQUNMLE9BQU8sRUFDTCxLQUFLQyxTQUNQO0FBQ0Y7QUFHQUMsY0FBTSxRQUFRLGdCQUFnQixJQUFJLFVBQVU7Q0FDMUMsSUFBSSxJQUFJO0VBQ04sSUFBSTtHQUdGLE9BQU8sZUFBZSxJQUFJLFFBQVE7SUFBRSxXQUFXO0lBQU07R0FBTSxDQUFDO0VBQzlELFNBQVMsR0FBRyxDQUVaO0VBQ0EsT0FBTyxlQUFlLElBQUksZUFBZTtHQUFFLFdBQVc7R0FBTTtFQUFNLENBQUM7Q0FDckU7QUFDRixDQUFDOzs7Ozs7O0FBUUQsSUFBTSxnQkFBZ0IsV0FBVyxLQUFLOzs7Ozs7O0FBUXRDLElBQU0sb0JBQW9CLFlBQ3hCQSxjQUFNLFdBQVcsT0FBTyxLQUFLLFlBQVksUUFBUSxZQUFZOzs7Ozs7Ozs7OztBQVkvRCxTQUFTQyxhQUFXLFVBQVUsUUFBUTtDQUNwQyxXQUFXRCxjQUFNLFFBQVEsUUFBUSxJQUFJLFdBQVcsQ0FBQyxRQUFRO0NBRXpELE1BQU0sRUFBRSxXQUFXO0NBQ25CLElBQUk7Q0FDSixJQUFJO0NBRUosTUFBTSxrQkFBa0IsQ0FBQztDQUV6QixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksUUFBUSxLQUFLO0VBQy9CLGdCQUFnQixTQUFTO0VBQ3pCLElBQUk7RUFFSixVQUFVO0VBRVYsSUFBSSxDQUFDLGlCQUFpQixhQUFhLEdBQUc7R0FDcEMsVUFBVSxlQUFlLEtBQUssT0FBTyxhQUFhLEVBQUEsQ0FBRyxZQUFZO0dBRWpFLElBQUksWUFBWSxLQUFBLEdBQ2QsTUFBTSxJQUFJRSxhQUFXLG9CQUFvQixHQUFHLEVBQUU7RUFFbEQ7RUFFQSxJQUFJLFlBQVlGLGNBQU0sV0FBVyxPQUFPLE1BQU0sVUFBVSxRQUFRLElBQUksTUFBTSxLQUN4RTtFQUdGLGdCQUFnQixNQUFNLE1BQU0sS0FBSztDQUNuQztDQUVBLElBQUksQ0FBQyxTQUFTO0VBQ1osTUFBTSxVQUFVLE9BQU8sUUFBUSxlQUFlLENBQUMsQ0FBQyxLQUM3QyxDQUFDLElBQUksV0FDSixXQUFXLEdBQUcsTUFDYixVQUFVLFFBQVEsd0NBQXdDLGdDQUMvRDtFQVFBLE1BQU0sSUFBSUUsYUFDUiwyREFQTSxTQUNKLFFBQVEsU0FBUyxJQUNmLGNBQWMsUUFBUSxJQUFJLFlBQVksQ0FBQyxDQUFDLEtBQUssSUFBSSxJQUNqRCxNQUFNLGFBQWEsUUFBUSxFQUFFLElBQy9CLDRCQUlGQSxhQUFXLGVBQ2I7Q0FDRjtDQUVBLE9BQU87QUFDVDs7OztBQUtBLElBQUEsbUJBQWU7Ozs7O0NBS2IsWUFBQTs7Ozs7Q0FNQSxVQUFVO0FBQ1o7Ozs7Ozs7OztBQ2xIQSxTQUFTLDZCQUE2QixRQUFRO0NBQzVDLElBQUksT0FBTyxhQUNULE9BQU8sWUFBWSxpQkFBaUI7Q0FHdEMsSUFBSSxPQUFPLFVBQVUsT0FBTyxPQUFPLFNBQ2pDLE1BQU0sSUFBSUMsZ0JBQWMsTUFBTSxNQUFNO0FBRXhDOzs7Ozs7Ozs7OztBQVlBLFNBQVMsZUFBZTtDQUN0QixPQUFPLE9BQU8sZ0JBQWdCLGVBQWVDLGNBQU0sV0FBVyxZQUFZLEdBQUcsVUFDbkUsWUFBWSxJQUFJLElBQ3RCLEtBQUs7QUFDWDs7Ozs7Ozs7Ozs7O0FBYUEsU0FBUyxhQUFhLEtBQUssT0FBTztDQUNoQyxPQUFPLEtBQUssSUFBSSxHQUFHLEtBQUssTUFBTSxJQUFJLElBQUksS0FBSyxDQUFDO0FBQzlDOzs7Ozs7OztBQVNBLFNBQXdCLGdCQUFnQixTQUFTO0NBSS9DLE1BQU0sU0FBU0EsY0FBTSxpQkFBaUIsT0FBTztDQUU3Qyw2QkFBNkIsTUFBTTtDQUVuQyxPQUFPLFVBQVVDLGVBQWEsS0FBS0QsY0FBTSxZQUFZLFFBQVEsU0FBUyxDQUFDO0NBR3ZFLE9BQU8sT0FBTyxjQUFjLEtBQUssUUFBUSxPQUFPLGdCQUFnQjtDQUVoRSxJQUFJO0VBQUM7RUFBUTtFQUFPO0NBQU8sQ0FBQyxDQUFDLFFBQVEsT0FBTyxNQUFNLE1BQU0sSUFDdEQsT0FBTyxRQUFRLGVBQWUscUNBQXFDLEtBQUs7Q0FHMUUsTUFBTSxVQUFVRSxpQkFBUyxXQUFXLE9BQU8sV0FBVyxTQUFTLFNBQVMsTUFBTTtDQUU5RSxNQUFNLE1BQU0sYUFBYTtDQUN6QixNQUFNLFFBQVEsSUFBSTtDQUVsQixPQUFPLFFBQVEsTUFBTSxDQUFDLENBQUMsS0FDckIsU0FBUyxvQkFBb0IsVUFBVTtFQUNyQyw2QkFBNkIsTUFBTTtFQUVuQyxTQUFTLFdBQVcsYUFBYSxLQUFLLEtBQUs7RUFLM0MsT0FBTyxXQUFXO0VBQ2xCLElBQUk7R0FDRixTQUFTLE9BQU8sY0FBYyxLQUFLLFFBQVEsT0FBTyxtQkFBbUIsUUFBUTtFQUMvRSxVQUFVO0dBQ1IsT0FBTyxPQUFPO0VBQ2hCO0VBRUEsU0FBUyxVQUFVRCxlQUFhLEtBQUssU0FBUyxPQUFPO0VBRXJELE9BQU87Q0FDVCxHQUNBLFNBQVMsbUJBQW1CLFFBQVE7RUFDbEMsSUFBSSxDQUFDRSxXQUFTLE1BQU0sR0FBRztHQUNyQiw2QkFBNkIsTUFBTTtHQUduQyxJQUFJLFVBQVUsT0FBTyxVQUFVO0lBQzdCLE9BQU8sU0FBUyxXQUFXLGFBQWEsS0FBSyxLQUFLO0lBQ2xELE9BQU8sV0FBVyxPQUFPO0lBQ3pCLElBQUk7S0FDRixPQUFPLFNBQVMsT0FBTyxjQUFjLEtBQ25DLFFBQ0EsT0FBTyxtQkFDUCxPQUFPLFFBQ1Q7SUFDRixVQUFVO0tBQ1IsT0FBTyxPQUFPO0lBQ2hCO0lBQ0EsT0FBTyxTQUFTLFVBQVVGLGVBQWEsS0FBSyxPQUFPLFNBQVMsT0FBTztHQUNyRTtFQUNGO0VBRUEsT0FBTyxRQUFRLE9BQU8sTUFBTTtDQUM5QixDQUNGO0FBQ0Y7O0FDOUhBLElBQU1HLGVBQWEsQ0FBQztBQUdwQjtDQUFDO0NBQVU7Q0FBVztDQUFVO0NBQVk7Q0FBVTtBQUFRLENBQUMsQ0FBQyxTQUFTLE1BQU0sTUFBTTtDQUNuRixhQUFXLFFBQVEsU0FBUyxVQUFVLE9BQU87RUFDM0MsT0FBTyxPQUFPLFVBQVUsUUFBUSxPQUFPLElBQUksSUFBSSxPQUFPLE9BQU87Q0FDL0Q7QUFDRixDQUFDO0FBRUQsSUFBTSxxQkFBcUIsQ0FBQzs7Ozs7Ozs7OztBQVc1QixhQUFXLGVBQWUsU0FBUyxhQUFhLFdBQVcsU0FBUyxTQUFTO0NBQzNFLFNBQVMsY0FBYyxLQUFLLE1BQU07RUFDaEMsT0FDRSxhQUNBQyxZQUNBLDRCQUNBLE1BQ0EsTUFDQSxRQUNDLFVBQVUsT0FBTyxVQUFVO0NBRWhDO0NBR0EsUUFBUSxPQUFPLEtBQUssU0FBUztFQUMzQixJQUFJLGNBQWMsT0FDaEIsTUFBTSxJQUFJQyxhQUNSLGNBQWMsS0FBSyx1QkFBdUIsVUFBVSxTQUFTLFVBQVUsR0FBRyxHQUMxRUEsYUFBVyxjQUNiO0VBR0YsSUFBSSxXQUFXLENBQUMsbUJBQW1CLE1BQU07R0FDdkMsbUJBQW1CLE9BQU87R0FFMUIsUUFBUSxLQUNOLGNBQ0UsS0FDQSxpQ0FBaUMsVUFBVSx5Q0FDN0MsQ0FDRjtFQUNGO0VBRUEsT0FBTyxZQUFZLFVBQVUsT0FBTyxLQUFLLElBQUksSUFBSTtDQUNuRDtBQUNGO0FBRUEsYUFBVyxXQUFXLFNBQVMsU0FBUyxpQkFBaUI7Q0FDdkQsUUFBUSxPQUFPLFFBQVE7RUFFckIsUUFBUSxLQUFLLEdBQUcsSUFBSSw4QkFBOEIsaUJBQWlCO0VBQ25FLE9BQU87Q0FDVDtBQUNGOzs7Ozs7Ozs7O0FBWUEsU0FBUyxjQUFjLFNBQVMsUUFBUSxjQUFjO0NBQ3BELElBQUksT0FBTyxZQUFZLFlBQVksWUFBWSxNQUM3QyxNQUFNLElBQUlBLGFBQVcsNkJBQTZCQSxhQUFXLG9CQUFvQjtDQUVuRixNQUFNLE9BQU8sT0FBTyxLQUFLLE9BQU87Q0FDaEMsSUFBSSxJQUFJLEtBQUs7Q0FDYixPQUFPLE1BQU0sR0FBRztFQUNkLE1BQU0sTUFBTSxLQUFLO0VBR2pCLE1BQU0sWUFBWSxPQUFPLFVBQVUsZUFBZSxLQUFLLFFBQVEsR0FBRyxJQUFJLE9BQU8sT0FBTyxLQUFBO0VBQ3BGLElBQUksV0FBVztHQUNiLE1BQU0sUUFBUSxRQUFRO0dBQ3RCLE1BQU0sU0FBUyxVQUFVLEtBQUEsS0FBYSxVQUFVLE9BQU8sS0FBSyxPQUFPO0dBQ25FLElBQUksV0FBVyxNQUNiLE1BQU0sSUFBSUEsYUFDUixZQUFZLE1BQU0sY0FBYyxRQUNoQ0EsYUFBVyxvQkFDYjtHQUVGO0VBQ0Y7RUFDQSxJQUFJLGlCQUFpQixNQUNuQixNQUFNLElBQUlBLGFBQVcsb0JBQW9CLEtBQUtBLGFBQVcsY0FBYztDQUUzRTtBQUNGO0FBRUEsSUFBQSxvQkFBZTtDQUNiO0NBQ0EsWUFBQTtBQUNGOztBQ2pHQSxJQUFNLGFBQWFDLGtCQUFVO0FBSzdCLElBQU0sbUJBQW1CLFVBQVU7Q0FDakMsSUFBSSxTQUFTLFFBQVFDLGNBQU0sY0FBYyxLQUFLLEtBQUssaUJBQWlCQyxnQkFDbEUsT0FBTztDQUdULElBQUk7RUFDRixPQUNFRCxjQUFNLFNBQVMsS0FBSyxLQUNwQkEsY0FBTSxZQUFZLE9BQU8sT0FBTyxXQUFXLE1BQU0sa0JBQ2pEO0dBQ0U7R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0EsT0FBTztFQUNULENBQUMsQ0FBQyxPQUFPLFdBQVdBLGNBQU0sV0FBV0EsY0FBTSxZQUFZLE9BQU8sTUFBTSxDQUFDLENBQUM7Q0FFMUUsU0FBUyxHQUFHO0VBRVYsT0FBTztDQUNUO0FBQ0Y7Ozs7Ozs7O0FBU0EsSUFBTUUsVUFBTixNQUFZO0NBQ1YsWUFBWSxnQkFBZ0I7RUFDMUIsS0FBSyxXQUFXLGtCQUFrQixDQUFDO0VBQ25DLEtBQUssZUFBZTtHQUNsQixTQUFTLElBQUksbUJBQW1CO0dBQ2hDLFVBQVUsSUFBSSxtQkFBbUI7RUFDbkM7Q0FDRjs7Ozs7Ozs7O0NBVUEsTUFBTSxRQUFRLGFBQWEsUUFBUTtFQUNqQyxJQUFJO0dBQ0YsT0FBTyxNQUFNLEtBQUssU0FBUyxhQUFhLE1BQU07RUFDaEQsU0FBUyxLQUFLO0dBQ1osSUFBSSxlQUFlLE9BQ2pCLElBQUk7SUFDRixJQUFJLFFBQVEsQ0FBQztJQUViLE1BQU0sb0JBQW9CLE1BQU0sa0JBQWtCLEtBQUssSUFBSyx3QkFBUSxJQUFJLE1BQU07SUFFOUUsTUFBTSxhQUFhLE1BQU07SUFDekIsSUFBSSxRQUFRO0lBR1osSUFBSSxPQUFPLGVBQWUsVUFBVTtLQUNsQyxNQUFNLG9CQUFvQixXQUFXLFFBQVEsSUFBSTtLQUVqRCxRQUFRLHNCQUFzQixLQUFLLEtBQUssV0FBVyxNQUFNLG9CQUFvQixDQUFDO0lBQ2hGO0lBRUEsSUFBSSxDQUFDLElBQUksT0FDUCxJQUFJLFFBQVE7U0FDUCxJQUFJLE9BQU87S0FHaEIsTUFBTSxvQkFBb0IsTUFBTSxRQUFRLElBQUk7S0FDNUMsTUFBTSxxQkFDSixzQkFBc0IsS0FBSyxLQUFLLE1BQU0sUUFBUSxNQUFNLG9CQUFvQixDQUFDO0tBQzNFLE1BQU0sdUJBQ0osdUJBQXVCLEtBQUssUUFBUSxNQUFNLE1BQU0scUJBQXFCLENBQUM7S0FNeEUsTUFBTSxlQUFlLE9BQU8sSUFBSSxLQUFLO0tBQ3JDLE1BQU0sYUFBYSxtQkFBbUIsS0FBSyxZQUFZO0tBQ3ZELE1BQU0sWUFBWSxlQUFlLEtBQUssZUFBZSxhQUFhLE1BQU0sR0FBRyxVQUFVO0tBQ3JGLE1BQU0sZUFBZSxlQUFlLEtBQUssS0FBSyxhQUFhLE1BQU0sVUFBVTtLQUUzRSxJQUFJLENBQUMsVUFBVSxTQUFTLG9CQUFvQixHQUMxQyxJQUFJLFFBQVEsWUFBWSxPQUFPLFFBQVE7SUFFM0M7R0FDRixTQUFTLEdBQUcsQ0FFWjtHQUdGLE1BQU07RUFDUjtDQUNGO0NBRUEsU0FBUyxhQUFhLFFBQVE7RUFHNUIsSUFBSSxPQUFPLGdCQUFnQixVQUFVO0dBQ25DLFNBQVMsVUFBVSxDQUFDO0dBQ3BCLE9BQU8sTUFBTTtFQUNmLE9BQ0UsU0FBUyxlQUFlLENBQUM7RUFHM0IsU0FBU0MsY0FBWSxLQUFLLFVBQVUsTUFBTTtFQUUxQyxNQUFNLEVBQUUsY0FBYyxrQkFBa0IsWUFBWTtFQUVwRCxJQUFJLGlCQUFpQixLQUFBLEdBQ25CLGtCQUFVLGNBQ1IsY0FDQTtHQUNFLG1CQUFtQixXQUFXLGFBQWEsV0FBVyxPQUFPO0dBQzdELG1CQUFtQixXQUFXLGFBQWEsV0FBVyxPQUFPO0dBQzdELHFCQUFxQixXQUFXLGFBQWEsV0FBVyxPQUFPO0dBQy9ELGlDQUFpQyxXQUFXLGFBQWEsV0FBVyxPQUFPO0dBQzNFLDZCQUE2QixXQUFXLGFBQWEsV0FBVyxPQUFPO0dBQ3ZFLGlDQUFpQyxXQUFXLGFBQWEsV0FBVyxPQUFPO0dBQzNFLHlCQUF5QixXQUFXLGFBQWEsV0FBVyxPQUFPO0VBQ3JFLEdBQ0EsS0FDRjtFQUdGLElBQUksb0JBQW9CLE1BQU07R0FDNUIsSUFBSUgsY0FBTSxXQUFXLGdCQUFnQixHQUNuQyxPQUFPLG1CQUFtQixFQUN4QixXQUFXLGlCQUNiO1FBRUEsa0JBQVUsY0FDUixrQkFDQTtJQUNFLFFBQVEsV0FBVztJQUNuQixXQUFXLFdBQVc7R0FDeEIsR0FDQSxJQUNGO0VBRUo7RUFHQSxJQUFJLE9BQU8sc0JBQXNCLEtBQUEsR0FBVyxDQUU1QyxPQUFPLElBQ0xBLGNBQU0sV0FBVyxLQUFLLFVBQVUsbUJBQW1CLEtBQ25ELEtBQUssU0FBUyxzQkFBc0IsS0FBQSxHQUVwQyxPQUFPLG9CQUFvQixLQUFLLFNBQVM7T0FFekMsT0FBTyxvQkFBb0I7RUFHN0Isa0JBQVUsY0FDUixRQUNBO0dBQ0UsU0FBUyxXQUFXLFNBQVMsU0FBUztHQUN0QyxlQUFlLFdBQVcsU0FBUyxlQUFlO0VBQ3BELEdBQ0EsSUFDRjtFQUdBLE9BQU8sVUFDTEEsY0FBTSxZQUFZLFFBQVEsUUFBUSxLQUNsQ0EsY0FBTSxZQUFZLEtBQUssVUFBVSxRQUFRLEtBQ3pDLE1BQUEsQ0FDQSxZQUFZO0VBR2QsTUFBTSxnQkFBZ0JBLGNBQU0sWUFBWSxTQUFTLFFBQVE7RUFDekQsTUFBTSxnQkFBZ0JBLGNBQU0sWUFBWSxTQUFTLE9BQU8sTUFBTTtFQUM5RCxNQUFNLGlCQUNKLFdBQ0FBLGNBQU0sTUFDSixnQkFBZ0IsYUFBYSxJQUFJLGdCQUFnQixLQUFBLEdBQ2pELGdCQUFnQixhQUFhLElBQUksZ0JBQWdCLEtBQUEsQ0FDbkQ7RUFFRixXQUNFQSxjQUFNLFFBQVEsV0FBVyxPQUFPLFFBQVEsSUFBSSxXQUFXO0dBQ3JELElBQUksZ0JBQWdCQSxjQUFNLFlBQVksU0FBUyxNQUFNLENBQUMsR0FDcEQsT0FBTyxRQUFRO0VBRW5CLENBQUM7RUFFSCxPQUFPLFVBQVVDLGVBQWEsT0FBTyxnQkFBZ0IsT0FBTztFQUc1RCxNQUFNLDBCQUEwQixDQUFDO0VBQ2pDLElBQUksaUNBQWlDO0VBQ3JDLEtBQUssYUFBYSxRQUFRLFFBQVEsU0FBUywyQkFBMkIsYUFBYTtHQUNqRixJQUFJLE9BQU8sWUFBWSxZQUFZLGNBQWMsWUFBWSxRQUFRLE1BQU0sTUFBTSxPQUMvRTtHQUdGLGlDQUFpQyxrQ0FBa0MsWUFBWTtHQUUvRSxNQUFNLGVBQWUsT0FBTyxnQkFBZ0JHO0dBSTVDLElBRkUsZ0JBQWdCLGFBQWEsaUNBRzdCLHdCQUF3QixRQUFRLFlBQVksV0FBVyxZQUFZLFFBQVE7UUFFM0Usd0JBQXdCLEtBQUssWUFBWSxXQUFXLFlBQVksUUFBUTtFQUU1RSxDQUFDO0VBRUQsTUFBTSwyQkFBMkIsQ0FBQztFQUNsQyxLQUFLLGFBQWEsU0FBUyxRQUFRLFNBQVMseUJBQXlCLGFBQWE7R0FDaEYseUJBQXlCLEtBQUssWUFBWSxXQUFXLFlBQVksUUFBUTtFQUMzRSxDQUFDO0VBRUQsSUFBSTtFQUNKLElBQUksSUFBSTtFQUNSLElBQUk7RUFFSixJQUFJLENBQUMsZ0NBQWdDO0dBQ25DLE1BQU0sUUFBUSxDQUFDLGdCQUFnQixLQUFLLElBQUksR0FBRyxLQUFBLENBQVM7R0FDcEQsTUFBTSxRQUFRLEdBQUcsdUJBQXVCO0dBQ3hDLE1BQU0sS0FBSyxHQUFHLHdCQUF3QjtHQUN0QyxNQUFNLE1BQU07R0FFWixVQUFVLFFBQVEsUUFBUSxNQUFNO0dBRWhDLE9BQU8sSUFBSSxLQUNULFVBQVUsUUFBUSxLQUFLLE1BQU0sTUFBTSxNQUFNLElBQUk7R0FHL0MsT0FBTztFQUNUO0VBRUEsTUFBTSx3QkFBd0I7RUFFOUIsSUFBSSxZQUFZO0VBRWhCLE9BQU8sSUFBSSxLQUFLO0dBQ2QsTUFBTSxjQUFjLHdCQUF3QjtHQUM1QyxNQUFNLGFBQWEsd0JBQXdCO0dBQzNDLElBQUk7SUFDRixZQUFZLGNBQWMsWUFBWSxTQUFTLElBQUk7R0FDckQsU0FBUyxPQUFPO0lBQ2QsSUFBSSxDQUFDLFlBQVk7S0FDZixVQUFVLFFBQVEsT0FBTyxLQUFLO0tBQzlCO0lBQ0Y7SUFFQSxJQUFJO0tBQ0YsTUFBTSxpQkFBaUIsV0FBVyxLQUFLLE1BQU0sS0FBSztLQUVsRCxJQUFJSixjQUFNLFdBQVcsY0FBYyxHQUNqQyxVQUFVLFFBQVEsUUFBUSxjQUFjLENBQUMsQ0FBQyxXQUN4QyxnQkFBZ0IsS0FBSyxNQUFNLFNBQVMsQ0FDdEM7SUFFSixTQUFTLGVBQWU7S0FDdEIsVUFBVSxRQUFRLE9BQU8sYUFBYTtJQUN4QztJQUVBO0dBQ0Y7RUFDRjtFQUVBLElBQUksQ0FBQyxTQUNILElBQUk7R0FDRixVQUFVLGdCQUFnQixLQUFLLE1BQU0sU0FBUztFQUNoRCxTQUFTLE9BQU87R0FDZCxVQUFVLFFBQVEsT0FBTyxLQUFLO0VBQ2hDO0VBR0YsSUFBSTtFQUNKLE1BQU0seUJBQXlCO0VBRS9CLE9BQU8sSUFBSSxLQUNULFVBQVUsUUFBUSxLQUFLLHlCQUF5QixNQUFNLHlCQUF5QixJQUFJO0VBR3JGLE9BQU87Q0FDVDtDQUVBLE9BQU8sUUFBUTtFQUNiLFNBQVNHLGNBQVksS0FBSyxVQUFVLE1BQU07RUFFMUMsT0FBTyxTQURVLGNBQWMsT0FBTyxTQUFTLE9BQU8sS0FBSyxPQUFPLG1CQUFtQixNQUNyRSxHQUFVLE9BQU8sUUFBUSxPQUFPLGdCQUFnQjtDQUNsRTtBQUNGO0FBR0FILGNBQU0sUUFBUTtDQUFDO0NBQVU7Q0FBTztDQUFRO0FBQVMsR0FBRyxTQUFTLG9CQUFvQixRQUFRO0NBRXZGLFFBQU0sVUFBVSxVQUFVLGVBQWdCLEtBQUssUUFBUTtFQUNyRCxPQUFPLEtBQUssUUFDVkcsY0FBWSxVQUFVLENBQUMsR0FBRztHQUN4QjtHQUNBO0dBQ0EsTUFBTSxVQUFVSCxjQUFNLFdBQVcsUUFBUSxNQUFNLElBQUksT0FBTyxPQUFPLEtBQUE7RUFDbkUsQ0FBQyxDQUNIO0NBQ0Y7QUFDRixDQUFDO0FBRURBLGNBQU0sUUFBUTtDQUFDO0NBQVE7Q0FBTztDQUFTO0FBQU8sR0FBRyxTQUFTLHNCQUFzQixRQUFRO0NBQ3RGLFNBQVMsbUJBQW1CLFFBQVE7RUFDbEMsT0FBTyxlQUFlLFdBQVcsS0FBSyxNQUFNLFFBQVE7R0FDbEQsT0FBTyxLQUFLLFFBQ1ZHLGNBQVksVUFBVSxDQUFDLEdBQUc7SUFDeEI7SUFDQSxTQUFTLFNBQ0wsRUFDRSxnQkFBZ0Isc0JBQ2xCLElBQ0EsQ0FBQztJQUNMO0lBQ0E7R0FDRixDQUFDLENBQ0g7RUFDRjtDQUNGO0NBRUEsUUFBTSxVQUFVLFVBQVUsbUJBQW1CO0NBSTdDLElBQUksV0FBVyxTQUNiLFFBQU0sVUFBVSxTQUFTLFVBQVUsbUJBQW1CLElBQUk7QUFFOUQsQ0FBQzs7Ozs7Ozs7O0FDM1ZELElBQU1FLGdCQUFOLE1BQU1BLGNBQVk7Q0FDaEIsWUFBWSxVQUFVO0VBQ3BCLElBQUksT0FBTyxhQUFhLFlBQ3RCLE1BQU0sSUFBSSxVQUFVLDhCQUE4QjtFQUdwRCxJQUFJO0VBRUosS0FBSyxVQUFVLElBQUksUUFBUSxTQUFTLGdCQUFnQixTQUFTO0dBQzNELGlCQUFpQjtFQUNuQixDQUFDO0VBRUQsTUFBTSxRQUFRO0VBR2QsS0FBSyxRQUFRLE1BQU0sV0FBVztHQUM1QixJQUFJLENBQUMsTUFBTSxZQUFZO0dBRXZCLElBQUksSUFBSSxNQUFNLFdBQVc7R0FFekIsT0FBTyxNQUFNLEdBQ1gsTUFBTSxXQUFXLEVBQUUsQ0FBQyxNQUFNO0dBRTVCLE1BQU0sYUFBYTtFQUNyQixDQUFDO0VBR0QsS0FBSyxRQUFRLFFBQVEsZ0JBQWdCO0dBQ25DLElBQUk7R0FFSixNQUFNLFVBQVUsSUFBSSxTQUFTLFlBQVk7SUFDdkMsTUFBTSxVQUFVLE9BQU87SUFDdkIsV0FBVztHQUNiLENBQUMsQ0FBQyxDQUFDLEtBQUssV0FBVztHQUVuQixRQUFRLFNBQVMsU0FBUyxTQUFTO0lBQ2pDLE1BQU0sWUFBWSxRQUFRO0dBQzVCO0dBRUEsT0FBTztFQUNUO0VBRUEsU0FBUyxTQUFTLE9BQU8sU0FBUyxRQUFRLFNBQVM7R0FDakQsSUFBSSxNQUFNLFFBRVI7R0FHRixNQUFNLFNBQVMsSUFBSUMsZ0JBQWMsU0FBUyxRQUFRLE9BQU87R0FDekQsZUFBZSxNQUFNLE1BQU07RUFDN0IsQ0FBQztDQUNIOzs7O0NBS0EsbUJBQW1CO0VBQ2pCLElBQUksS0FBSyxRQUNQLE1BQU0sS0FBSztDQUVmOzs7O0NBTUEsVUFBVSxVQUFVO0VBQ2xCLElBQUksS0FBSyxRQUFRO0dBQ2YsU0FBUyxLQUFLLE1BQU07R0FDcEI7RUFDRjtFQUVBLElBQUksS0FBSyxZQUNQLEtBQUssV0FBVyxLQUFLLFFBQVE7T0FFN0IsS0FBSyxhQUFhLENBQUMsUUFBUTtDQUUvQjs7OztDQU1BLFlBQVksVUFBVTtFQUNwQixJQUFJLENBQUMsS0FBSyxZQUNSO0VBRUYsTUFBTSxRQUFRLEtBQUssV0FBVyxRQUFRLFFBQVE7RUFDOUMsSUFBSSxVQUFVLElBQ1osS0FBSyxXQUFXLE9BQU8sT0FBTyxDQUFDO0NBRW5DO0NBRUEsZ0JBQWdCO0VBQ2QsTUFBTSxhQUFhLElBQUksZ0JBQWdCO0VBRXZDLE1BQU0sU0FBUyxRQUFRO0dBQ3JCLFdBQVcsTUFBTSxHQUFHO0VBQ3RCO0VBRUEsS0FBSyxVQUFVLEtBQUs7RUFFcEIsV0FBVyxPQUFPLG9CQUFvQixLQUFLLFlBQVksS0FBSztFQUU1RCxPQUFPLFdBQVc7Q0FDcEI7Ozs7O0NBTUEsT0FBTyxTQUFTO0VBQ2QsSUFBSTtFQUlKLE9BQU87R0FDTCxPQUFBLElBSmdCRCxjQUFZLFNBQVMsU0FBUyxHQUFHO0lBQ2pELFNBQVM7R0FDWCxDQUVNO0dBQ0o7RUFDRjtDQUNGO0FBQ0Y7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDN0dBLFNBQXdCRSxTQUFPLFVBQVU7Q0FDdkMsT0FBTyxTQUFTLEtBQUssS0FBSztFQUN4QixPQUFPLFNBQVMsTUFBTSxNQUFNLEdBQUc7Q0FDakM7QUFDRjs7Ozs7Ozs7O0FDaEJBLFNBQXdCQyxlQUFhLFNBQVM7Q0FDNUMsT0FBT0MsY0FBTSxTQUFTLE9BQU8sS0FBSyxRQUFRLGlCQUFpQjtBQUM3RDs7QUNiQSxJQUFNQyxtQkFBaUI7Q0FDckIsVUFBVTtDQUNWLG9CQUFvQjtDQUNwQixZQUFZO0NBQ1osWUFBWTtDQUNaLElBQUk7Q0FDSixTQUFTO0NBQ1QsVUFBVTtDQUNWLDZCQUE2QjtDQUM3QixXQUFXO0NBQ1gsY0FBYztDQUNkLGdCQUFnQjtDQUNoQixhQUFhO0NBQ2IsaUJBQWlCO0NBQ2pCLFFBQVE7Q0FDUixpQkFBaUI7Q0FDakIsa0JBQWtCO0NBQ2xCLE9BQU87Q0FDUCxVQUFVO0NBQ1YsYUFBYTtDQUNiLFVBQVU7Q0FDVixRQUFRO0NBQ1IsbUJBQW1CO0NBQ25CLG1CQUFtQjtDQUNuQixZQUFZO0NBQ1osY0FBYztDQUNkLGlCQUFpQjtDQUNqQixXQUFXO0NBQ1gsVUFBVTtDQUNWLGtCQUFrQjtDQUNsQixlQUFlO0NBQ2YsNkJBQTZCO0NBQzdCLGdCQUFnQjtDQUNoQixVQUFVO0NBQ1YsTUFBTTtDQUNOLGdCQUFnQjtDQUNoQixvQkFBb0I7Ozs7Q0FJcEIsaUJBQWlCO0NBQ2pCLGlCQUFpQjtDQUNqQixZQUFZO0NBQ1osc0JBQXNCO0NBQ3RCLHFCQUFxQjtDQUNyQixtQkFBbUI7Q0FDbkIsV0FBVztDQUNYLG9CQUFvQjs7OztDQUlwQixxQkFBcUI7Q0FDckIsc0JBQXNCO0NBQ3RCLFFBQVE7Q0FDUixrQkFBa0I7Q0FDbEIsVUFBVTtDQUNWLGlCQUFpQjtDQUNqQixzQkFBc0I7Q0FDdEIsaUJBQWlCO0NBQ2pCLDZCQUE2QjtDQUM3Qiw0QkFBNEI7Q0FDNUIscUJBQXFCO0NBQ3JCLGdCQUFnQjtDQUNoQixZQUFZO0NBQ1osb0JBQW9CO0NBQ3BCLGdCQUFnQjtDQUNoQix5QkFBeUI7Q0FDekIsdUJBQXVCO0NBQ3ZCLHFCQUFxQjtDQUNyQixjQUFjO0NBQ2QsYUFBYTtDQUNiLCtCQUErQjtDQUMvQixnQ0FBZ0M7Q0FDaEMsaUJBQWlCO0NBQ2pCLG9CQUFvQjtDQUNwQixxQkFBcUI7Q0FDckIsaUJBQWlCO0NBQ2pCLG9CQUFvQjtDQUNwQix1QkFBdUI7QUFDekI7QUFFQSxPQUFPLFFBQVFBLGdCQUFjLENBQUMsQ0FBQyxTQUFTLENBQUMsS0FBSyxXQUFXO0NBQ3ZELElBQUlBLGlCQUFlLFdBQVcsS0FBQSxHQUM1QixpQkFBZSxTQUFTO0FBRTVCLENBQUM7Ozs7Ozs7OztBQzFERCxTQUFTLGVBQWUsZUFBZTtDQUNyQyxNQUFNLFVBQVUsSUFBSUMsUUFBTSxhQUFhO0NBQ3ZDLE1BQU0sV0FBVyxLQUFLQSxRQUFNLFVBQVUsU0FBUyxPQUFPO0NBR3RELGNBQU0sT0FBTyxVQUFVQSxRQUFNLFdBQVcsU0FBUyxFQUFFLFlBQVksS0FBSyxDQUFDO0NBR3JFLGNBQU0sT0FBTyxVQUFVLFNBQVMsTUFBTSxFQUFFLFlBQVksS0FBSyxDQUFDO0NBRzFELFNBQVMsU0FBUyxTQUFTLE9BQU8sZ0JBQWdCO0VBQ2hELE9BQU8sZUFBZUMsY0FBWSxlQUFlLGNBQWMsQ0FBQztDQUNsRTtDQUVBLE9BQU87QUFDVDtBQUdBLElBQU0sUUFBUSxlQUFlLFFBQVE7QUFHckMsTUFBTSxRQUFRRDtBQUdkLE1BQU0sZ0JBQWdCRTtBQUN0QixNQUFNLGNBQWNDO0FBQ3BCLE1BQU0sV0FBV0M7QUFDakIsTUFBTSxVQUFVQztBQUNoQixNQUFNLGFBQWFDO0FBR25CLE1BQU0sYUFBYUM7QUFHbkIsTUFBTSxTQUFTLE1BQU07QUFHckIsTUFBTSxNQUFNLFNBQVMsSUFBSSxVQUFVO0NBQ2pDLE9BQU8sUUFBUSxJQUFJLFFBQVE7QUFDN0I7QUFFQSxNQUFNLFNBQVNDO0FBR2YsTUFBTSxlQUFlQztBQUdyQixNQUFNLGNBQWNSO0FBRXBCLE1BQU0sZUFBZVM7QUFFckIsTUFBTSxjQUFjLFVBQVUsZUFBZUMsY0FBTSxXQUFXLEtBQUssSUFBSSxJQUFJLFNBQVMsS0FBSyxJQUFJLEtBQUs7QUFFbEcsTUFBTSxhQUFhQyxpQkFBUztBQUU1QixNQUFNLGlCQUFpQkM7QUFFdkIsTUFBTSxVQUFVOztBQ2hGaEIsSUFBTSxFQUNKLE9BQ0EsWUFDQSxlQUNBLFVBQ0EsYUFDQSxTQUNBLEtBQ0EsUUFDQSxjQUNBLFFBQ0EsWUFDQSxjQUNBLGdCQUNBLFlBQ0EsWUFDQSxhQUNBLFdBQ0UiLCJ4X2dvb2dsZV9pZ25vcmVMaXN0IjpbMCwxLDIsMyw0LDUsNiw3LDgsOSwxMCwxMSwxMiwxMywxNCwxNSwxNiwxNywxOCwxOSwyMCwyMSwyMiwyMywyNCwyNSwyNiwyNywyOCwyOSwzMCwzMSwzMiwzMywzNCwzNSwzNiwzNywzOCwzOSw0MCw0MSw0Miw0Myw0NCw0NSw0Niw0Nyw0OCw0OSw1MCw1MSw1Miw1Myw1NCw1NSw1Nl19