import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/fiscalizacao/ChecklistDinamico.tsx");const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];/**
* Componente de Checklist Sanitário Dinâmico (JSONB)
* Permite avaliação por blocos: C (Conforme), NC (Não Conforme) e NA (Não se Aplica),
* com campo retrátil de observação para cada item.
*/
import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=0fd2848a";
import { Check, ChevronDown, ChevronUp, Minus, X } from "/node_modules/.vite/deps/lucide-react.js?v=0fd2848a";
var _jsxFileName = "E:/Projetos VSCODE/visa_braunas/src/components/fiscalizacao/ChecklistDinamico.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=0fd2848a";
var _s = $RefreshSig$();
const CHECKLIST_SECOES = [
	{
		titulo: "1. Estrutura Física & Saneamento",
		itens: [
			{
				id: "est_01_pisos_paredes",
				enunciado: "Pisos, paredes e tetos íntegros, laváveis e sem umidade ou rachaduras."
			},
			{
				id: "est_02_agua_potavel",
				enunciado: "Abastecimento contínuo de água tratada e canalizada em todas as áreas."
			},
			{
				id: "est_03_reservatorio",
				enunciado: "Reservatório de água vedado e com higienização comprovada nos últimos 6 meses."
			},
			{
				id: "est_04_telas_protecao",
				enunciado: "Janelas e aberturas da área de produção providas de telas milimétricas removíveis."
			},
			{
				id: "est_05_sanitarios",
				enunciado: "Instalações sanitárias separadas por sexo, higienizadas e sem comunicação direta com a manipulação."
			}
		]
	},
	{
		titulo: "2. Higiene Pessoal & Boas Práticas",
		itens: [
			{
				id: "hig_01_uniformes_epi",
				enunciado: "Manipuladores com uniformes claros, cabelos protegidos e sem adornos pessoais."
			},
			{
				id: "hig_02_aso_vigente",
				enunciado: "Atestados de Saúde Ocupacional (ASO) dos funcionários válidos e arquivados no local."
			},
			{
				id: "hig_03_capacitacao",
				enunciado: "Comprovantes de treinamento em Boas Práticas de Manipulação de Alimentos/Serviços."
			},
			{
				id: "hig_04_lavagem_maos",
				enunciado: "Lavatórios exclusivos para higienização das mãos com sabonete bactericida e papel toalha."
			}
		]
	},
	{
		titulo: "3. Equipamentos, Refrigeração & Segurança",
		itens: [
			{
				id: "eqp_01_temperatura",
				enunciado: "Equipamentos de refrigeração e congelamento em temperatura adequada e aferida."
			},
			{
				id: "eqp_02_manutencao",
				enunciado: "Equipamentos e bancadas de inox limpos, sem acúmulo de sujidades ou pontos de oxidação."
			},
			{
				id: "eqp_03_pragas_vetores",
				enunciado: "Certificado de desinsetização e desratização emitido por empresa especializada licenciada."
			},
			{
				id: "eqp_04_vapt_seguranca",
				enunciado: "Maquinários com proteção mecânica (NR-12), ventilação e iluminação adequadas ao trabalhador."
			}
		]
	},
	{
		titulo: "4. Documentação Regulamentar & Licenciamento",
		itens: [
			{
				id: "doc_01_alvara_anterior",
				enunciado: "Alvará Sanitário anterior ou protocolo afixado em local visível ao público."
			},
			{
				id: "doc_02_responsavel_tecnico",
				enunciado: "Certificado de Regularidade Técnica (CRT/ART) do Responsável Técnico (quando exigido)."
			},
			{
				id: "doc_03_pops_manuais",
				enunciado: "Manual de Boas Práticas e Procedimentos Operacionais Padronizados (POPs) disponíveis."
			}
		]
	}
];
export const ChecklistDinamico = ({ value = {}, onChange, readOnly = false }) => {
	_s();
	const [observacoesExpandidas, setObservacoesExpandidas] = useState({});
	const handleStatusChange = (itemId, status) => {
		if (readOnly) return;
		const atual = value[itemId] || { status: "NA" };
		const atualizado = {
			...value,
			[itemId]: {
				...atual,
				status
			}
		};
		// Abre o campo de observação automaticamente se marcar Não Conforme (NC)
		if (status === "NC") {
			setObservacoesExpandidas((prev) => ({
				...prev,
				[itemId]: true
			}));
		}
		onChange(atualizado);
	};
	const handleObservacaoChange = (itemId, observacao) => {
		if (readOnly) return;
		const atual = value[itemId] || { status: "NA" };
		onChange({
			...value,
			[itemId]: {
				...atual,
				observacao
			}
		});
	};
	const toggleObservacao = (itemId) => {
		setObservacoesExpandidas((prev) => ({
			...prev,
			[itemId]: !prev[itemId]
		}));
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "space-y-6",
		children: [/* @__PURE__ */ _jsxDEV("div", {
			className: "flex items-center justify-between pb-2 border-b border-slate-100 dark:border-slate-800",
			children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
				className: "text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider block",
				children: "Checklist de Avaliação Sanitária de Campo"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 160,
				columnNumber: 11
			}, this), /* @__PURE__ */ _jsxDEV("p", {
				className: "text-[11px] text-slate-500 dark:text-slate-400",
				children: [
					"Assinale os itens avaliados: ",
					/* @__PURE__ */ _jsxDEV("strong", { children: "C" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 164,
						columnNumber: 42
					}, this),
					" (Conforme), ",
					/* @__PURE__ */ _jsxDEV("strong", { children: "NC" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 164,
						columnNumber: 73
					}, this),
					" (Não Conforme) ou ",
					/* @__PURE__ */ _jsxDEV("strong", { children: "NA" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 164,
						columnNumber: 111
					}, this),
					" (Não se Aplica)."
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 163,
				columnNumber: 11
			}, this)] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 159,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("div", {
				className: "flex items-center gap-2 text-[10px] font-semibold",
				children: [
					/* @__PURE__ */ _jsxDEV("span", {
						className: "px-2 py-0.5 rounded bg-emerald-50 text-emerald-700 border border-emerald-200",
						children: "C: Conforme"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 169,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("span", {
						className: "px-2 py-0.5 rounded bg-rose-50 text-rose-700 border border-rose-200",
						children: "NC: Não Conforme"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 172,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("span", {
						className: "px-2 py-0.5 rounded bg-slate-100 text-slate-600 border border-slate-200",
						children: "NA: Não se Aplica"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 175,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 168,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 158,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "space-y-6",
			children: CHECKLIST_SECOES.map((secao) => /* @__PURE__ */ _jsxDEV("div", {
				className: "border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden shadow-2xs",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "bg-slate-50 dark:bg-slate-800/80 px-4 py-2.5 border-b border-slate-200 dark:border-slate-800 text-xs font-bold text-slate-800 dark:text-slate-200",
					children: secao.titulo
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 187,
					columnNumber: 13
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "divide-y divide-slate-100 dark:divide-slate-800 text-xs",
					children: secao.itens.map((item) => {
						const itemResposta = value[item.id] || { status: "NA" };
						const isObsOpen = Boolean(observacoesExpandidas[item.id] || itemResposta.observacao);
						return /* @__PURE__ */ _jsxDEV("div", {
							className: "p-3.5 space-y-2 hover:bg-slate-50/40 dark:hover:bg-slate-800/20",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "flex flex-col sm:flex-row sm:items-center justify-between gap-3",
								children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "text-slate-700 dark:text-slate-300 font-medium leading-snug",
									children: item.enunciado
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 201,
									columnNumber: 23
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center gap-1.5 shrink-0",
									children: [
										/* @__PURE__ */ _jsxDEV("button", {
											type: "button",
											disabled: readOnly,
											onClick: () => handleStatusChange(item.id, "C"),
											className: `px-2.5 py-1 text-xs font-bold rounded-md border transition-colors flex items-center gap-1 ${itemResposta.status === "C" ? "bg-emerald-600 text-white border-emerald-600 shadow-xs" : "bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-400 border-slate-300 dark:border-slate-700 hover:border-emerald-500"}`,
											children: [/* @__PURE__ */ _jsxDEV(Check, { className: "w-3 h-3" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 217,
												columnNumber: 27
											}, this), /* @__PURE__ */ _jsxDEV("span", { children: "C" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 218,
												columnNumber: 27
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 207,
											columnNumber: 25
										}, this),
										/* @__PURE__ */ _jsxDEV("button", {
											type: "button",
											disabled: readOnly,
											onClick: () => handleStatusChange(item.id, "NC"),
											className: `px-2.5 py-1 text-xs font-bold rounded-md border transition-colors flex items-center gap-1 ${itemResposta.status === "NC" ? "bg-rose-600 text-white border-rose-600 shadow-xs" : "bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-400 border-slate-300 dark:border-slate-700 hover:border-rose-500"}`,
											children: [/* @__PURE__ */ _jsxDEV(X, { className: "w-3 h-3" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 231,
												columnNumber: 27
											}, this), /* @__PURE__ */ _jsxDEV("span", { children: "NC" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 232,
												columnNumber: 27
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 221,
											columnNumber: 25
										}, this),
										/* @__PURE__ */ _jsxDEV("button", {
											type: "button",
											disabled: readOnly,
											onClick: () => handleStatusChange(item.id, "NA"),
											className: `px-2.5 py-1 text-xs font-bold rounded-md border transition-colors flex items-center gap-1 ${itemResposta.status === "NA" ? "bg-slate-600 text-white border-slate-600 shadow-xs" : "bg-white dark:bg-slate-900 text-slate-500 dark:text-slate-400 border-slate-300 dark:border-slate-700 hover:border-slate-500"}`,
											children: [/* @__PURE__ */ _jsxDEV(Minus, { className: "w-3 h-3" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 245,
												columnNumber: 27
											}, this), /* @__PURE__ */ _jsxDEV("span", { children: "NA" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 246,
												columnNumber: 27
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 235,
											columnNumber: 25
										}, this),
										/* @__PURE__ */ _jsxDEV("button", {
											type: "button",
											onClick: () => toggleObservacao(item.id),
											className: "p-1 text-slate-400 hover:text-slate-600 ml-1 rounded",
											title: "Adicionar ou visualizar irregularidade/observação",
											children: isObsOpen ? /* @__PURE__ */ _jsxDEV(ChevronUp, { className: "w-4 h-4" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 256,
												columnNumber: 29
											}, this) : /* @__PURE__ */ _jsxDEV(ChevronDown, { className: "w-4 h-4" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 258,
												columnNumber: 29
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 249,
											columnNumber: 25
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 206,
									columnNumber: 23
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 200,
								columnNumber: 21
							}, this), isObsOpen && /* @__PURE__ */ _jsxDEV("div", {
								className: "pt-2",
								children: /* @__PURE__ */ _jsxDEV("textarea", {
									rows: 2,
									disabled: readOnly,
									value: itemResposta.observacao || "",
									onChange: (e) => handleObservacaoChange(item.id, e.target.value),
									placeholder: "Descreva a irregularidade constatada ou exigência específica para este item...",
									className: "w-full p-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-xs text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-1 focus:ring-teal-500"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 267,
									columnNumber: 25
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 266,
								columnNumber: 23
							}, this)]
						}, item.id, true, {
							fileName: _jsxFileName,
							lineNumber: 199,
							columnNumber: 19
						}, this);
					})
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 191,
					columnNumber: 13
				}, this)]
			}, secao.titulo, true, {
				fileName: _jsxFileName,
				lineNumber: 183,
				columnNumber: 11
			}, this))
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 181,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 157,
		columnNumber: 5
	}, this);
};
_s(ChecklistDinamico, "R/DvXf8kJembpFcRwG/4b6j8V2I=");
_c = ChecklistDinamico;
export default ChecklistDinamico;
var _c;
$RefreshReg$(_c, "ChecklistDinamico");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/fiscalizacao/ChecklistDinamico.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("E:/Projetos VSCODE/visa_braunas/src/components/fiscalizacao/ChecklistDinamico.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("E:/Projetos VSCODE/visa_braunas/src/components/fiscalizacao/ChecklistDinamico.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "E:/Projetos VSCODE/visa_braunas/src/components/fiscalizacao/ChecklistDinamico.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7Ozs7QUFNQSxPQUFPLFNBQVMsZ0JBQWdCO0FBQ2hDLFNBQVMsT0FBTyxhQUFhLFdBQXFCLE9BQU8sU0FBUzs7OztBQWFsRSxNQUFNLG1CQUF3QztDQUM1QztFQUNFLFFBQVE7RUFDUixPQUFPO0dBQ0w7SUFDRSxJQUFJO0lBQ0osV0FBVztHQUNiO0dBQ0E7SUFDRSxJQUFJO0lBQ0osV0FBVztHQUNiO0dBQ0E7SUFDRSxJQUFJO0lBQ0osV0FBVztHQUNiO0dBQ0E7SUFDRSxJQUFJO0lBQ0osV0FBVztHQUNiO0dBQ0E7SUFDRSxJQUFJO0lBQ0osV0FBVztHQUNiO0VBQ0Y7Q0FDRjtDQUNBO0VBQ0UsUUFBUTtFQUNSLE9BQU87R0FDTDtJQUNFLElBQUk7SUFDSixXQUFXO0dBQ2I7R0FDQTtJQUNFLElBQUk7SUFDSixXQUFXO0dBQ2I7R0FDQTtJQUNFLElBQUk7SUFDSixXQUFXO0dBQ2I7R0FDQTtJQUNFLElBQUk7SUFDSixXQUFXO0dBQ2I7RUFDRjtDQUNGO0NBQ0E7RUFDRSxRQUFRO0VBQ1IsT0FBTztHQUNMO0lBQ0UsSUFBSTtJQUNKLFdBQVc7R0FDYjtHQUNBO0lBQ0UsSUFBSTtJQUNKLFdBQVc7R0FDYjtHQUNBO0lBQ0UsSUFBSTtJQUNKLFdBQVc7R0FDYjtHQUNBO0lBQ0UsSUFBSTtJQUNKLFdBQVc7R0FDYjtFQUNGO0NBQ0Y7Q0FDQTtFQUNFLFFBQVE7RUFDUixPQUFPO0dBQ0w7SUFDRSxJQUFJO0lBQ0osV0FBVztHQUNiO0dBQ0E7SUFDRSxJQUFJO0lBQ0osV0FBVztHQUNiO0dBQ0E7SUFDRSxJQUFJO0lBQ0osV0FBVztHQUNiO0VBQ0Y7Q0FDRjtBQUNGO0FBUUEsT0FBTyxNQUFNLHFCQUF1RCxFQUNsRSxRQUFRLENBQUMsR0FDVCxVQUNBLFdBQVcsWUFDUDs7Q0FDSixNQUFNLENBQUMsdUJBQXVCLDRCQUE0QixTQUFrQyxDQUFDLENBQUM7Q0FFOUYsTUFBTSxzQkFBc0IsUUFBZ0IsV0FBZ0M7RUFDMUUsSUFBSSxVQUFVO0VBQ2QsTUFBTSxRQUFRLE1BQU0sV0FBVyxFQUFFLFFBQVEsS0FBSztFQUM5QyxNQUFNLGFBQWlDO0dBQ3JDLEdBQUc7SUFDRixTQUFTO0lBQ1IsR0FBRztJQUNIO0dBQ0Y7RUFDRjs7RUFHQSxJQUFJLFdBQVcsTUFBTTtHQUNuQiwwQkFBMEIsVUFBVTtJQUFFLEdBQUc7S0FBTyxTQUFTO0dBQUssRUFBRTtFQUNsRTtFQUVBLFNBQVMsVUFBVTtDQUNyQjtDQUVBLE1BQU0sMEJBQTBCLFFBQWdCLGVBQXVCO0VBQ3JFLElBQUksVUFBVTtFQUNkLE1BQU0sUUFBUSxNQUFNLFdBQVcsRUFBRSxRQUFRLEtBQUs7RUFDOUMsU0FBUztHQUNQLEdBQUc7SUFDRixTQUFTO0lBQ1IsR0FBRztJQUNIO0dBQ0Y7RUFDRixDQUFDO0NBQ0g7Q0FFQSxNQUFNLG9CQUFvQixXQUFtQjtFQUMzQywwQkFBMEIsVUFBVTtHQUFFLEdBQUc7SUFBTyxTQUFTLENBQUMsS0FBSztFQUFRLEVBQUU7Q0FDM0U7Q0FFQSxPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQWYsQ0FDRSx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmLENBQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFFBQUQ7SUFBTSxXQUFVO2NBQWtGO0dBRTVGOzs7O2FBQ04sd0JBQUMsS0FBRDtJQUFHLFdBQVU7Y0FBYjtLQUE4RDtLQUMvQix3QkFBQyxVQUFELFlBQVEsSUFBUzs7Ozs7S0FBQztLQUFhLHdCQUFDLFVBQUQsWUFBUSxLQUFVOzs7OztLQUFDO0tBQW1CLHdCQUFDLFVBQUQsWUFBUSxLQUFVOzs7OztLQUFDO0lBQ3BIOzs7OztXQUNBOzs7O2FBRUwsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZjtLQUNFLHdCQUFDLFFBQUQ7TUFBTSxXQUFVO2dCQUErRTtLQUV6Rjs7Ozs7S0FDTix3QkFBQyxRQUFEO01BQU0sV0FBVTtnQkFBc0U7S0FFaEY7Ozs7O0tBQ04sd0JBQUMsUUFBRDtNQUFNLFdBQVU7Z0JBQTBFO0tBRXBGOzs7OztJQUNIOzs7OztXQUNGOzs7OztZQUVMLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQ1osaUJBQWlCLEtBQUssVUFDckIsd0JBQUMsT0FBRDtJQUVFLFdBQVU7Y0FGWixDQUlFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQ1osTUFBTTtJQUNKOzs7O2NBRUwsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFDWixNQUFNLE1BQU0sS0FBSyxTQUFTO01BQ3pCLE1BQU0sZUFBZSxNQUFNLEtBQUssT0FBTyxFQUFFLFFBQVEsS0FBSztNQUN0RCxNQUFNLFlBQVksUUFDaEIsc0JBQXNCLEtBQUssT0FBTyxhQUFhLFVBQ2pEO01BRUEsT0FDRSx3QkFBQyxPQUFEO09BQW1CLFdBQVU7aUJBQTdCLENBQ0Usd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFDYixLQUFLO1FBQ0Y7Ozs7a0JBR04sd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWY7VUFDRSx3QkFBQyxVQUFEO1dBQ0UsTUFBSztXQUNMLFVBQVU7V0FDVixlQUFlLG1CQUFtQixLQUFLLElBQUksR0FBRztXQUM5QyxXQUFXLDZGQUNULGFBQWEsV0FBVyxNQUNwQiwyREFDQTtxQkFQUixDQVVFLHdCQUFDLE9BQUQsRUFBTyxXQUFVLFVBQVc7Ozs7cUJBQzVCLHdCQUFDLFFBQUQsWUFBTSxJQUFPOzs7O21CQUNQOzs7Ozs7VUFFUix3QkFBQyxVQUFEO1dBQ0UsTUFBSztXQUNMLFVBQVU7V0FDVixlQUFlLG1CQUFtQixLQUFLLElBQUksSUFBSTtXQUMvQyxXQUFXLDZGQUNULGFBQWEsV0FBVyxPQUNwQixxREFDQTtxQkFQUixDQVVFLHdCQUFDLEdBQUQsRUFBRyxXQUFVLFVBQVc7Ozs7cUJBQ3hCLHdCQUFDLFFBQUQsWUFBTSxLQUFROzs7O21CQUNSOzs7Ozs7VUFFUix3QkFBQyxVQUFEO1dBQ0UsTUFBSztXQUNMLFVBQVU7V0FDVixlQUFlLG1CQUFtQixLQUFLLElBQUksSUFBSTtXQUMvQyxXQUFXLDZGQUNULGFBQWEsV0FBVyxPQUNwQix1REFDQTtxQkFQUixDQVVFLHdCQUFDLE9BQUQsRUFBTyxXQUFVLFVBQVc7Ozs7cUJBQzVCLHdCQUFDLFFBQUQsWUFBTSxLQUFROzs7O21CQUNSOzs7Ozs7VUFFUix3QkFBQyxVQUFEO1dBQ0UsTUFBSztXQUNMLGVBQWUsaUJBQWlCLEtBQUssRUFBRTtXQUN2QyxXQUFVO1dBQ1YsT0FBTTtxQkFFTCxZQUNDLHdCQUFDLFdBQUQsRUFBVyxXQUFVLFVBQVc7Ozs7c0JBRWhDLHdCQUFDLGFBQUQsRUFBYSxXQUFVLFVBQVc7Ozs7O1VBRTlCOzs7OztTQUNMOzs7OztnQkFDRjs7Ozs7aUJBR0osYUFDQyx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFDYix3QkFBQyxZQUFEO1NBQ0UsTUFBTTtTQUNOLFVBQVU7U0FDVixPQUFPLGFBQWEsY0FBYztTQUNsQyxXQUFXLE1BQ1QsdUJBQXVCLEtBQUssSUFBSSxFQUFFLE9BQU8sS0FBSztTQUVoRCxhQUFZO1NBQ1osV0FBVTtRQUNYOzs7OztPQUNFOzs7O2VBRUo7U0FoRkssS0FBSzs7OzthQWdGVjtLQUVULENBQUM7SUFDRTs7OztZQUNGO01BbkdFLE1BQU07Ozs7VUFtR1IsQ0FDTjtFQUNFOzs7O1VBQ0Y7Ozs7OztBQUVUOzs7QUFFQSxlQUFlIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkNoZWNrbGlzdERpbmFtaWNvLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyIvKipcclxuICogQ29tcG9uZW50ZSBkZSBDaGVja2xpc3QgU2FuaXTDoXJpbyBEaW7Dom1pY28gKEpTT05CKVxyXG4gKiBQZXJtaXRlIGF2YWxpYcOnw6NvIHBvciBibG9jb3M6IEMgKENvbmZvcm1lKSwgTkMgKE7Do28gQ29uZm9ybWUpIGUgTkEgKE7Do28gc2UgQXBsaWNhKSxcclxuICogY29tIGNhbXBvIHJldHLDoXRpbCBkZSBvYnNlcnZhw6fDo28gcGFyYSBjYWRhIGl0ZW0uXHJcbiAqL1xyXG5cclxuaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7IENoZWNrLCBDaGV2cm9uRG93biwgQ2hldnJvblVwLCBGaWxlVGV4dCwgTWludXMsIFggfSBmcm9tIFwibHVjaWRlLXJlYWN0XCI7XHJcbmltcG9ydCB7IENoZWNrbGlzdFJlc3Bvc3RhcywgU3RhdHVzSXRlbUNoZWNrbGlzdCB9IGZyb20gXCIuLi8uLi90eXBlcy9maXNjYWxpemFjYW9cIjtcclxuXHJcbmludGVyZmFjZSBDaGVja2xpc3RJdGVtRGVmIHtcclxuICBpZDogc3RyaW5nO1xyXG4gIGVudW5jaWFkbzogc3RyaW5nO1xyXG59XHJcblxyXG5pbnRlcmZhY2UgQ2hlY2tsaXN0U2VjYW9EZWYge1xyXG4gIHRpdHVsbzogc3RyaW5nO1xyXG4gIGl0ZW5zOiBDaGVja2xpc3RJdGVtRGVmW107XHJcbn1cclxuXHJcbmNvbnN0IENIRUNLTElTVF9TRUNPRVM6IENoZWNrbGlzdFNlY2FvRGVmW10gPSBbXHJcbiAge1xyXG4gICAgdGl0dWxvOiBcIjEuIEVzdHJ1dHVyYSBGw61zaWNhICYgU2FuZWFtZW50b1wiLFxyXG4gICAgaXRlbnM6IFtcclxuICAgICAge1xyXG4gICAgICAgIGlkOiBcImVzdF8wMV9waXNvc19wYXJlZGVzXCIsXHJcbiAgICAgICAgZW51bmNpYWRvOiBcIlBpc29zLCBwYXJlZGVzIGUgdGV0b3Mgw61udGVncm9zLCBsYXbDoXZlaXMgZSBzZW0gdW1pZGFkZSBvdSByYWNoYWR1cmFzLlwiLFxyXG4gICAgICB9LFxyXG4gICAgICB7XHJcbiAgICAgICAgaWQ6IFwiZXN0XzAyX2FndWFfcG90YXZlbFwiLFxyXG4gICAgICAgIGVudW5jaWFkbzogXCJBYmFzdGVjaW1lbnRvIGNvbnTDrW51byBkZSDDoWd1YSB0cmF0YWRhIGUgY2FuYWxpemFkYSBlbSB0b2RhcyBhcyDDoXJlYXMuXCIsXHJcbiAgICAgIH0sXHJcbiAgICAgIHtcclxuICAgICAgICBpZDogXCJlc3RfMDNfcmVzZXJ2YXRvcmlvXCIsXHJcbiAgICAgICAgZW51bmNpYWRvOiBcIlJlc2VydmF0w7NyaW8gZGUgw6FndWEgdmVkYWRvIGUgY29tIGhpZ2llbml6YcOnw6NvIGNvbXByb3ZhZGEgbm9zIMO6bHRpbW9zIDYgbWVzZXMuXCIsXHJcbiAgICAgIH0sXHJcbiAgICAgIHtcclxuICAgICAgICBpZDogXCJlc3RfMDRfdGVsYXNfcHJvdGVjYW9cIixcclxuICAgICAgICBlbnVuY2lhZG86IFwiSmFuZWxhcyBlIGFiZXJ0dXJhcyBkYSDDoXJlYSBkZSBwcm9kdcOnw6NvIHByb3ZpZGFzIGRlIHRlbGFzIG1pbGltw6l0cmljYXMgcmVtb3bDrXZlaXMuXCIsXHJcbiAgICAgIH0sXHJcbiAgICAgIHtcclxuICAgICAgICBpZDogXCJlc3RfMDVfc2FuaXRhcmlvc1wiLFxyXG4gICAgICAgIGVudW5jaWFkbzogXCJJbnN0YWxhw6fDtWVzIHNhbml0w6FyaWFzIHNlcGFyYWRhcyBwb3Igc2V4bywgaGlnaWVuaXphZGFzIGUgc2VtIGNvbXVuaWNhw6fDo28gZGlyZXRhIGNvbSBhIG1hbmlwdWxhw6fDo28uXCIsXHJcbiAgICAgIH0sXHJcbiAgICBdLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgdGl0dWxvOiBcIjIuIEhpZ2llbmUgUGVzc29hbCAmIEJvYXMgUHLDoXRpY2FzXCIsXHJcbiAgICBpdGVuczogW1xyXG4gICAgICB7XHJcbiAgICAgICAgaWQ6IFwiaGlnXzAxX3VuaWZvcm1lc19lcGlcIixcclxuICAgICAgICBlbnVuY2lhZG86IFwiTWFuaXB1bGFkb3JlcyBjb20gdW5pZm9ybWVzIGNsYXJvcywgY2FiZWxvcyBwcm90ZWdpZG9zIGUgc2VtIGFkb3Jub3MgcGVzc29haXMuXCIsXHJcbiAgICAgIH0sXHJcbiAgICAgIHtcclxuICAgICAgICBpZDogXCJoaWdfMDJfYXNvX3ZpZ2VudGVcIixcclxuICAgICAgICBlbnVuY2lhZG86IFwiQXRlc3RhZG9zIGRlIFNhw7pkZSBPY3VwYWNpb25hbCAoQVNPKSBkb3MgZnVuY2lvbsOhcmlvcyB2w6FsaWRvcyBlIGFycXVpdmFkb3Mgbm8gbG9jYWwuXCIsXHJcbiAgICAgIH0sXHJcbiAgICAgIHtcclxuICAgICAgICBpZDogXCJoaWdfMDNfY2FwYWNpdGFjYW9cIixcclxuICAgICAgICBlbnVuY2lhZG86IFwiQ29tcHJvdmFudGVzIGRlIHRyZWluYW1lbnRvIGVtIEJvYXMgUHLDoXRpY2FzIGRlIE1hbmlwdWxhw6fDo28gZGUgQWxpbWVudG9zL1NlcnZpw6dvcy5cIixcclxuICAgICAgfSxcclxuICAgICAge1xyXG4gICAgICAgIGlkOiBcImhpZ18wNF9sYXZhZ2VtX21hb3NcIixcclxuICAgICAgICBlbnVuY2lhZG86IFwiTGF2YXTDs3Jpb3MgZXhjbHVzaXZvcyBwYXJhIGhpZ2llbml6YcOnw6NvIGRhcyBtw6NvcyBjb20gc2Fib25ldGUgYmFjdGVyaWNpZGEgZSBwYXBlbCB0b2FsaGEuXCIsXHJcbiAgICAgIH0sXHJcbiAgICBdLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgdGl0dWxvOiBcIjMuIEVxdWlwYW1lbnRvcywgUmVmcmlnZXJhw6fDo28gJiBTZWd1cmFuw6dhXCIsXHJcbiAgICBpdGVuczogW1xyXG4gICAgICB7XHJcbiAgICAgICAgaWQ6IFwiZXFwXzAxX3RlbXBlcmF0dXJhXCIsXHJcbiAgICAgICAgZW51bmNpYWRvOiBcIkVxdWlwYW1lbnRvcyBkZSByZWZyaWdlcmHDp8OjbyBlIGNvbmdlbGFtZW50byBlbSB0ZW1wZXJhdHVyYSBhZGVxdWFkYSBlIGFmZXJpZGEuXCIsXHJcbiAgICAgIH0sXHJcbiAgICAgIHtcclxuICAgICAgICBpZDogXCJlcXBfMDJfbWFudXRlbmNhb1wiLFxyXG4gICAgICAgIGVudW5jaWFkbzogXCJFcXVpcGFtZW50b3MgZSBiYW5jYWRhcyBkZSBpbm94IGxpbXBvcywgc2VtIGFjw7ptdWxvIGRlIHN1amlkYWRlcyBvdSBwb250b3MgZGUgb3hpZGHDp8Ojby5cIixcclxuICAgICAgfSxcclxuICAgICAge1xyXG4gICAgICAgIGlkOiBcImVxcF8wM19wcmFnYXNfdmV0b3Jlc1wiLFxyXG4gICAgICAgIGVudW5jaWFkbzogXCJDZXJ0aWZpY2FkbyBkZSBkZXNpbnNldGl6YcOnw6NvIGUgZGVzcmF0aXphw6fDo28gZW1pdGlkbyBwb3IgZW1wcmVzYSBlc3BlY2lhbGl6YWRhIGxpY2VuY2lhZGEuXCIsXHJcbiAgICAgIH0sXHJcbiAgICAgIHtcclxuICAgICAgICBpZDogXCJlcXBfMDRfdmFwdF9zZWd1cmFuY2FcIixcclxuICAgICAgICBlbnVuY2lhZG86IFwiTWFxdWluw6FyaW9zIGNvbSBwcm90ZcOnw6NvIG1lY8OibmljYSAoTlItMTIpLCB2ZW50aWxhw6fDo28gZSBpbHVtaW5hw6fDo28gYWRlcXVhZGFzIGFvIHRyYWJhbGhhZG9yLlwiLFxyXG4gICAgICB9LFxyXG4gICAgXSxcclxuICB9LFxyXG4gIHtcclxuICAgIHRpdHVsbzogXCI0LiBEb2N1bWVudGHDp8OjbyBSZWd1bGFtZW50YXIgJiBMaWNlbmNpYW1lbnRvXCIsXHJcbiAgICBpdGVuczogW1xyXG4gICAgICB7XHJcbiAgICAgICAgaWQ6IFwiZG9jXzAxX2FsdmFyYV9hbnRlcmlvclwiLFxyXG4gICAgICAgIGVudW5jaWFkbzogXCJBbHZhcsOhIFNhbml0w6FyaW8gYW50ZXJpb3Igb3UgcHJvdG9jb2xvIGFmaXhhZG8gZW0gbG9jYWwgdmlzw612ZWwgYW8gcMO6YmxpY28uXCIsXHJcbiAgICAgIH0sXHJcbiAgICAgIHtcclxuICAgICAgICBpZDogXCJkb2NfMDJfcmVzcG9uc2F2ZWxfdGVjbmljb1wiLFxyXG4gICAgICAgIGVudW5jaWFkbzogXCJDZXJ0aWZpY2FkbyBkZSBSZWd1bGFyaWRhZGUgVMOpY25pY2EgKENSVC9BUlQpIGRvIFJlc3BvbnPDoXZlbCBUw6ljbmljbyAocXVhbmRvIGV4aWdpZG8pLlwiLFxyXG4gICAgICB9LFxyXG4gICAgICB7XHJcbiAgICAgICAgaWQ6IFwiZG9jXzAzX3BvcHNfbWFudWFpc1wiLFxyXG4gICAgICAgIGVudW5jaWFkbzogXCJNYW51YWwgZGUgQm9hcyBQcsOhdGljYXMgZSBQcm9jZWRpbWVudG9zIE9wZXJhY2lvbmFpcyBQYWRyb25pemFkb3MgKFBPUHMpIGRpc3BvbsOtdmVpcy5cIixcclxuICAgICAgfSxcclxuICAgIF0sXHJcbiAgfSxcclxuXTtcclxuXHJcbmludGVyZmFjZSBDaGVja2xpc3REaW5hbWljb1Byb3BzIHtcclxuICB2YWx1ZTogQ2hlY2tsaXN0UmVzcG9zdGFzO1xyXG4gIG9uQ2hhbmdlOiAocmVzcG9zdGFzOiBDaGVja2xpc3RSZXNwb3N0YXMpID0+IHZvaWQ7XHJcbiAgcmVhZE9ubHk/OiBib29sZWFuO1xyXG59XHJcblxyXG5leHBvcnQgY29uc3QgQ2hlY2tsaXN0RGluYW1pY286IFJlYWN0LkZDPENoZWNrbGlzdERpbmFtaWNvUHJvcHM+ID0gKHtcclxuICB2YWx1ZSA9IHt9LFxyXG4gIG9uQ2hhbmdlLFxyXG4gIHJlYWRPbmx5ID0gZmFsc2UsXHJcbn0pID0+IHtcclxuICBjb25zdCBbb2JzZXJ2YWNvZXNFeHBhbmRpZGFzLCBzZXRPYnNlcnZhY29lc0V4cGFuZGlkYXNdID0gdXNlU3RhdGU8UmVjb3JkPHN0cmluZywgYm9vbGVhbj4+KHt9KTtcclxuXHJcbiAgY29uc3QgaGFuZGxlU3RhdHVzQ2hhbmdlID0gKGl0ZW1JZDogc3RyaW5nLCBzdGF0dXM6IFN0YXR1c0l0ZW1DaGVja2xpc3QpID0+IHtcclxuICAgIGlmIChyZWFkT25seSkgcmV0dXJuO1xyXG4gICAgY29uc3QgYXR1YWwgPSB2YWx1ZVtpdGVtSWRdIHx8IHsgc3RhdHVzOiBcIk5BXCIgfTtcclxuICAgIGNvbnN0IGF0dWFsaXphZG86IENoZWNrbGlzdFJlc3Bvc3RhcyA9IHtcclxuICAgICAgLi4udmFsdWUsXHJcbiAgICAgIFtpdGVtSWRdOiB7XHJcbiAgICAgICAgLi4uYXR1YWwsXHJcbiAgICAgICAgc3RhdHVzLFxyXG4gICAgICB9LFxyXG4gICAgfTtcclxuXHJcbiAgICAvLyBBYnJlIG8gY2FtcG8gZGUgb2JzZXJ2YcOnw6NvIGF1dG9tYXRpY2FtZW50ZSBzZSBtYXJjYXIgTsOjbyBDb25mb3JtZSAoTkMpXHJcbiAgICBpZiAoc3RhdHVzID09PSBcIk5DXCIpIHtcclxuICAgICAgc2V0T2JzZXJ2YWNvZXNFeHBhbmRpZGFzKChwcmV2KSA9PiAoeyAuLi5wcmV2LCBbaXRlbUlkXTogdHJ1ZSB9KSk7XHJcbiAgICB9XHJcblxyXG4gICAgb25DaGFuZ2UoYXR1YWxpemFkbyk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlT2JzZXJ2YWNhb0NoYW5nZSA9IChpdGVtSWQ6IHN0cmluZywgb2JzZXJ2YWNhbzogc3RyaW5nKSA9PiB7XHJcbiAgICBpZiAocmVhZE9ubHkpIHJldHVybjtcclxuICAgIGNvbnN0IGF0dWFsID0gdmFsdWVbaXRlbUlkXSB8fCB7IHN0YXR1czogXCJOQVwiIH07XHJcbiAgICBvbkNoYW5nZSh7XHJcbiAgICAgIC4uLnZhbHVlLFxyXG4gICAgICBbaXRlbUlkXToge1xyXG4gICAgICAgIC4uLmF0dWFsLFxyXG4gICAgICAgIG9ic2VydmFjYW8sXHJcbiAgICAgIH0sXHJcbiAgICB9KTtcclxuICB9O1xyXG5cclxuICBjb25zdCB0b2dnbGVPYnNlcnZhY2FvID0gKGl0ZW1JZDogc3RyaW5nKSA9PiB7XHJcbiAgICBzZXRPYnNlcnZhY29lc0V4cGFuZGlkYXMoKHByZXYpID0+ICh7IC4uLnByZXYsIFtpdGVtSWRdOiAhcHJldltpdGVtSWRdIH0pKTtcclxuICB9O1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTZcIj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gcGItMiBib3JkZXItYiBib3JkZXItc2xhdGUtMTAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMFwiPlxyXG4gICAgICAgIDxkaXY+XHJcbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGUgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIGJsb2NrXCI+XHJcbiAgICAgICAgICAgIENoZWNrbGlzdCBkZSBBdmFsaWHDp8OjbyBTYW5pdMOhcmlhIGRlIENhbXBvXHJcbiAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LXNsYXRlLTUwMCBkYXJrOnRleHQtc2xhdGUtNDAwXCI+XHJcbiAgICAgICAgICAgIEFzc2luYWxlIG9zIGl0ZW5zIGF2YWxpYWRvczogPHN0cm9uZz5DPC9zdHJvbmc+IChDb25mb3JtZSksIDxzdHJvbmc+TkM8L3N0cm9uZz4gKE7Do28gQ29uZm9ybWUpIG91IDxzdHJvbmc+TkE8L3N0cm9uZz4gKE7Do28gc2UgQXBsaWNhKS5cclxuICAgICAgICAgIDwvcD5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiB0ZXh0LVsxMHB4XSBmb250LXNlbWlib2xkXCI+XHJcbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJweC0yIHB5LTAuNSByb3VuZGVkIGJnLWVtZXJhbGQtNTAgdGV4dC1lbWVyYWxkLTcwMCBib3JkZXIgYm9yZGVyLWVtZXJhbGQtMjAwXCI+XHJcbiAgICAgICAgICAgIEM6IENvbmZvcm1lXHJcbiAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJweC0yIHB5LTAuNSByb3VuZGVkIGJnLXJvc2UtNTAgdGV4dC1yb3NlLTcwMCBib3JkZXIgYm9yZGVyLXJvc2UtMjAwXCI+XHJcbiAgICAgICAgICAgIE5DOiBOw6NvIENvbmZvcm1lXHJcbiAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJweC0yIHB5LTAuNSByb3VuZGVkIGJnLXNsYXRlLTEwMCB0ZXh0LXNsYXRlLTYwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMFwiPlxyXG4gICAgICAgICAgICBOQTogTsOjbyBzZSBBcGxpY2FcclxuICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNlwiPlxyXG4gICAgICAgIHtDSEVDS0xJU1RfU0VDT0VTLm1hcCgoc2VjYW8pID0+IChcclxuICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAga2V5PXtzZWNhby50aXR1bG99XHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLXhsIG92ZXJmbG93LWhpZGRlbiBzaGFkb3ctMnhzXCJcclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zbGF0ZS01MCBkYXJrOmJnLXNsYXRlLTgwMC84MCBweC00IHB5LTIuNSBib3JkZXItYiBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCB0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTgwMCBkYXJrOnRleHQtc2xhdGUtMjAwXCI+XHJcbiAgICAgICAgICAgICAge3NlY2FvLnRpdHVsb31cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImRpdmlkZS15IGRpdmlkZS1zbGF0ZS0xMDAgZGFyazpkaXZpZGUtc2xhdGUtODAwIHRleHQteHNcIj5cclxuICAgICAgICAgICAgICB7c2VjYW8uaXRlbnMubWFwKChpdGVtKSA9PiB7XHJcbiAgICAgICAgICAgICAgICBjb25zdCBpdGVtUmVzcG9zdGEgPSB2YWx1ZVtpdGVtLmlkXSB8fCB7IHN0YXR1czogXCJOQVwiIH07XHJcbiAgICAgICAgICAgICAgICBjb25zdCBpc09ic09wZW4gPSBCb29sZWFuKFxyXG4gICAgICAgICAgICAgICAgICBvYnNlcnZhY29lc0V4cGFuZGlkYXNbaXRlbS5pZF0gfHwgaXRlbVJlc3Bvc3RhLm9ic2VydmFjYW9cclxuICAgICAgICAgICAgICAgICk7XHJcblxyXG4gICAgICAgICAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgICAgICAgICAgPGRpdiBrZXk9e2l0ZW0uaWR9IGNsYXNzTmFtZT1cInAtMy41IHNwYWNlLXktMiBob3ZlcjpiZy1zbGF0ZS01MC80MCBkYXJrOmhvdmVyOmJnLXNsYXRlLTgwMC8yMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBzbTpmbGV4LXJvdyBzbTppdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC0zXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMzAwIGZvbnQtbWVkaXVtIGxlYWRpbmctc251Z1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7aXRlbS5lbnVuY2lhZG99XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgey8qIEJvdMO1ZXMgQyAvIE5DIC8gTkEgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgc2hyaW5rLTBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtyZWFkT25seX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVTdGF0dXNDaGFuZ2UoaXRlbS5pZCwgXCJDXCIpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHB4LTIuNSBweS0xIHRleHQteHMgZm9udC1ib2xkIHJvdW5kZWQtbWQgYm9yZGVyIHRyYW5zaXRpb24tY29sb3JzIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xICR7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtUmVzcG9zdGEuc3RhdHVzID09PSBcIkNcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IFwiYmctZW1lcmFsZC02MDAgdGV4dC13aGl0ZSBib3JkZXItZW1lcmFsZC02MDAgc2hhZG93LXhzXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBcImJnLXdoaXRlIGRhcms6Ymctc2xhdGUtOTAwIHRleHQtc2xhdGUtNjAwIGRhcms6dGV4dC1zbGF0ZS00MDAgYm9yZGVyLXNsYXRlLTMwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgaG92ZXI6Ym9yZGVyLWVtZXJhbGQtNTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB9YH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxDaGVjayBjbGFzc05hbWU9XCJ3LTMgaC0zXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5DPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17cmVhZE9ubHl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlU3RhdHVzQ2hhbmdlKGl0ZW0uaWQsIFwiTkNcIil9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHgtMi41IHB5LTEgdGV4dC14cyBmb250LWJvbGQgcm91bmRlZC1tZCBib3JkZXIgdHJhbnNpdGlvbi1jb2xvcnMgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgJHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW1SZXNwb3N0YS5zdGF0dXMgPT09IFwiTkNcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IFwiYmctcm9zZS02MDAgdGV4dC13aGl0ZSBib3JkZXItcm9zZS02MDAgc2hhZG93LXhzXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBcImJnLXdoaXRlIGRhcms6Ymctc2xhdGUtOTAwIHRleHQtc2xhdGUtNjAwIGRhcms6dGV4dC1zbGF0ZS00MDAgYm9yZGVyLXNsYXRlLTMwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgaG92ZXI6Ym9yZGVyLXJvc2UtNTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB9YH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxYIGNsYXNzTmFtZT1cInctMyBoLTNcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPk5DPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17cmVhZE9ubHl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlU3RhdHVzQ2hhbmdlKGl0ZW0uaWQsIFwiTkFcIil9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHgtMi41IHB5LTEgdGV4dC14cyBmb250LWJvbGQgcm91bmRlZC1tZCBib3JkZXIgdHJhbnNpdGlvbi1jb2xvcnMgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgJHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW1SZXNwb3N0YS5zdGF0dXMgPT09IFwiTkFcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IFwiYmctc2xhdGUtNjAwIHRleHQtd2hpdGUgYm9yZGVyLXNsYXRlLTYwMCBzaGFkb3cteHNcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IFwiYmctd2hpdGUgZGFyazpiZy1zbGF0ZS05MDAgdGV4dC1zbGF0ZS01MDAgZGFyazp0ZXh0LXNsYXRlLTQwMCBib3JkZXItc2xhdGUtMzAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCBob3Zlcjpib3JkZXItc2xhdGUtNTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB9YH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxNaW51cyBjbGFzc05hbWU9XCJ3LTMgaC0zXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5OQTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gdG9nZ2xlT2JzZXJ2YWNhbyhpdGVtLmlkKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTEgdGV4dC1zbGF0ZS00MDAgaG92ZXI6dGV4dC1zbGF0ZS02MDAgbWwtMSByb3VuZGVkXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB0aXRsZT1cIkFkaWNpb25hciBvdSB2aXN1YWxpemFyIGlycmVndWxhcmlkYWRlL29ic2VydmHDp8Ojb1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7aXNPYnNPcGVuID8gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPENoZXZyb25VcCBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPENoZXZyb25Eb3duIGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHsvKiBDYW1wbyBkZSBvYnNlcnZhw6fDo28gcmV0csOhdGlsICovfVxyXG4gICAgICAgICAgICAgICAgICAgIHtpc09ic09wZW4gJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwdC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDx0ZXh0YXJlYVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHJvd3M9ezJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e3JlYWRPbmx5fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtpdGVtUmVzcG9zdGEub2JzZXJ2YWNhbyB8fCBcIlwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZU9ic2VydmFjYW9DaGFuZ2UoaXRlbS5pZCwgZS50YXJnZXQudmFsdWUpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRGVzY3JldmEgYSBpcnJlZ3VsYXJpZGFkZSBjb25zdGF0YWRhIG91IGV4aWfDqm5jaWEgZXNwZWPDrWZpY2EgcGFyYSBlc3RlIGl0ZW0uLi5cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBwLTIgYmctc2xhdGUtNTAgZGFyazpiZy1zbGF0ZS04MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQtbGcgdGV4dC14cyB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGUgcGxhY2Vob2xkZXItc2xhdGUtNDAwIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTEgZm9jdXM6cmluZy10ZWFsLTUwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgICAgfSl9XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgKSl9XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IENoZWNrbGlzdERpbmFtaWNvO1xyXG4iXX0=