import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ouvidoria/GravidadeBadge.tsx");const React = __vite__cjsImport0_react;const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];/**
* Badge de Classificação de Risco e Gravidade Sanitária da Denúncia
* Inclui animação visual com pulso para casos urgentes (risco iminente à saúde pública).
*/
import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=0fd2848a";
import { AlertCircle, AlertOctagon, AlertTriangle, ShieldCheck } from "/node_modules/.vite/deps/lucide-react.js?v=0fd2848a";
var _jsxFileName = "E:/Projetos VSCODE/visa_braunas/src/components/ouvidoria/GravidadeBadge.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=0fd2848a";
export const GravidadeBadge = ({ gravidade, className = "", showIcon = true }) => {
	const normalizada = (gravidade || "media").toLowerCase().trim();
	switch (normalizada) {
		case "urgente": return /* @__PURE__ */ _jsxDEV("span", {
			className: `inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-black uppercase tracking-wider bg-rose-600 text-white shadow-xs animate-pulse border border-rose-700 ${className}`,
			title: "Gravidade Urgente: Risco iminente à saúde pública (surtos, intoxicações graves, perecíveis em escolas)",
			children: [showIcon && /* @__PURE__ */ _jsxDEV(AlertOctagon, { className: "w-3.5 h-3.5" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 30,
				columnNumber: 24
			}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Urgente" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 31,
				columnNumber: 11
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 26,
			columnNumber: 9
		}, this);
		case "alta": return /* @__PURE__ */ _jsxDEV("span", {
			className: `inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-bold uppercase tracking-wider bg-orange-100 text-orange-900 dark:bg-orange-950/80 dark:text-orange-200 border border-orange-300 dark:border-orange-800 ${className}`,
			title: "Gravidade Alta: Medicamentos clandestinos, carnes sem inspeção, estabelecimentos de alto risco",
			children: [showIcon && /* @__PURE__ */ _jsxDEV(AlertTriangle, { className: "w-3 h-3 text-orange-600" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 41,
				columnNumber: 24
			}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Alta" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 42,
				columnNumber: 11
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 37,
			columnNumber: 9
		}, this);
		case "media": return /* @__PURE__ */ _jsxDEV("span", {
			className: `inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-semibold uppercase tracking-wider bg-amber-50 text-amber-800 dark:bg-amber-950/60 dark:text-amber-300 border border-amber-200 dark:border-amber-800 ${className}`,
			title: "Gravidade Média: Irregularidades higiênicas em comércio de alimentos, falta de alvará",
			children: [showIcon && /* @__PURE__ */ _jsxDEV(AlertCircle, { className: "w-3 h-3 text-amber-600" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 52,
				columnNumber: 24
			}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Média" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 53,
				columnNumber: 11
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 48,
			columnNumber: 9
		}, this);
		case "baixa":
		default: return /* @__PURE__ */ _jsxDEV("span", {
			className: `inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-medium uppercase tracking-wider bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300 border border-slate-200 dark:border-slate-700 ${className}`,
			title: "Gravidade Baixa: Questões estruturais secundárias, informativas",
			children: [showIcon && /* @__PURE__ */ _jsxDEV(ShieldCheck, { className: "w-3 h-3 text-slate-500" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 64,
				columnNumber: 24
			}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Baixa" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 65,
				columnNumber: 11
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 60,
			columnNumber: 9
		}, this);
	}
};
_c = GravidadeBadge;
export default GravidadeBadge;
var _c;
$RefreshReg$(_c, "GravidadeBadge");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/ouvidoria/GravidadeBadge.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("E:/Projetos VSCODE/visa_braunas/src/components/ouvidoria/GravidadeBadge.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("E:/Projetos VSCODE/visa_braunas/src/components/ouvidoria/GravidadeBadge.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "E:/Projetos VSCODE/visa_braunas/src/components/ouvidoria/GravidadeBadge.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7OztBQUtBLE9BQU8sV0FBVztBQUNsQixTQUFTLGFBQWEsY0FBYyxlQUFlLG1CQUFtQjs7O0FBU3RFLE9BQU8sTUFBTSxrQkFBaUQsRUFDNUQsV0FDQSxZQUFZLElBQ1osV0FBVyxXQUNQO0NBQ0osTUFBTSxlQUFlLGFBQWEsUUFBTyxDQUFFLFlBQVksQ0FBQyxDQUFDLEtBQUs7Q0FFOUQsUUFBUSxhQUFSO0VBQ0UsS0FBSyxXQUNILE9BQ0Usd0JBQUMsUUFBRDtHQUNFLFdBQVcscUxBQXFMO0dBQ2hNLE9BQU07YUFGUixDQUlHLFlBQVksd0JBQUMsY0FBRCxFQUFjLFdBQVUsY0FBZTs7OzthQUNwRCx3QkFBQyxRQUFELFlBQU0sVUFBYTs7OztXQUNmOzs7Ozs7RUFHVixLQUFLLFFBQ0gsT0FDRSx3QkFBQyxRQUFEO0dBQ0UsV0FBVyx1T0FBdU87R0FDbFAsT0FBTTthQUZSLENBSUcsWUFBWSx3QkFBQyxlQUFELEVBQWUsV0FBVSwwQkFBMkI7Ozs7YUFDakUsd0JBQUMsUUFBRCxZQUFNLE9BQVU7Ozs7V0FDWjs7Ozs7O0VBR1YsS0FBSyxTQUNILE9BQ0Usd0JBQUMsUUFBRDtHQUNFLFdBQVcsb09BQW9PO0dBQy9PLE9BQU07YUFGUixDQUlHLFlBQVksd0JBQUMsYUFBRCxFQUFhLFdBQVUseUJBQTBCOzs7O2FBQzlELHdCQUFDLFFBQUQsWUFBTSxRQUFXOzs7O1dBQ2I7Ozs7OztFQUdWLEtBQUs7RUFDTCxTQUNFLE9BQ0Usd0JBQUMsUUFBRDtHQUNFLFdBQVcsZ09BQWdPO0dBQzNPLE9BQU07YUFGUixDQUlHLFlBQVksd0JBQUMsYUFBRCxFQUFhLFdBQVUseUJBQTBCOzs7O2FBQzlELHdCQUFDLFFBQUQsWUFBTSxRQUFXOzs7O1dBQ2I7Ozs7OztDQUVaO0FBQ0Y7O0FBRUEsZUFBZSIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJHcmF2aWRhZGVCYWRnZS50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiLyoqXHJcbiAqIEJhZGdlIGRlIENsYXNzaWZpY2HDp8OjbyBkZSBSaXNjbyBlIEdyYXZpZGFkZSBTYW5pdMOhcmlhIGRhIERlbsO6bmNpYVxyXG4gKiBJbmNsdWkgYW5pbWHDp8OjbyB2aXN1YWwgY29tIHB1bHNvIHBhcmEgY2Fzb3MgdXJnZW50ZXMgKHJpc2NvIGltaW5lbnRlIMOgIHNhw7pkZSBww7pibGljYSkuXHJcbiAqL1xyXG5cclxuaW1wb3J0IFJlYWN0IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgeyBBbGVydENpcmNsZSwgQWxlcnRPY3RhZ29uLCBBbGVydFRyaWFuZ2xlLCBTaGllbGRDaGVjayB9IGZyb20gXCJsdWNpZGUtcmVhY3RcIjtcclxuaW1wb3J0IHsgR3JhdmlkYWRlRGVudW5jaWEgfSBmcm9tIFwiLi4vLi4vdHlwZXMvb3V2aWRvcmlhXCI7XHJcblxyXG5pbnRlcmZhY2UgR3JhdmlkYWRlQmFkZ2VQcm9wcyB7XHJcbiAgZ3JhdmlkYWRlOiBHcmF2aWRhZGVEZW51bmNpYSB8IHN0cmluZztcclxuICBjbGFzc05hbWU/OiBzdHJpbmc7XHJcbiAgc2hvd0ljb24/OiBib29sZWFuO1xyXG59XHJcblxyXG5leHBvcnQgY29uc3QgR3JhdmlkYWRlQmFkZ2U6IFJlYWN0LkZDPEdyYXZpZGFkZUJhZGdlUHJvcHM+ID0gKHtcclxuICBncmF2aWRhZGUsXHJcbiAgY2xhc3NOYW1lID0gXCJcIixcclxuICBzaG93SWNvbiA9IHRydWUsXHJcbn0pID0+IHtcclxuICBjb25zdCBub3JtYWxpemFkYSA9IChncmF2aWRhZGUgfHwgXCJtZWRpYVwiKS50b0xvd2VyQ2FzZSgpLnRyaW0oKTtcclxuXHJcbiAgc3dpdGNoIChub3JtYWxpemFkYSkge1xyXG4gICAgY2FzZSBcInVyZ2VudGVcIjpcclxuICAgICAgcmV0dXJuIChcclxuICAgICAgICA8c3BhblxyXG4gICAgICAgICAgY2xhc3NOYW1lPXtgaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgcHgtMi41IHB5LTAuNSByb3VuZGVkLWZ1bGwgdGV4dC1bMTFweF0gZm9udC1ibGFjayB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgYmctcm9zZS02MDAgdGV4dC13aGl0ZSBzaGFkb3cteHMgYW5pbWF0ZS1wdWxzZSBib3JkZXIgYm9yZGVyLXJvc2UtNzAwICR7Y2xhc3NOYW1lfWB9XHJcbiAgICAgICAgICB0aXRsZT1cIkdyYXZpZGFkZSBVcmdlbnRlOiBSaXNjbyBpbWluZW50ZSDDoCBzYcO6ZGUgcMO6YmxpY2EgKHN1cnRvcywgaW50b3hpY2HDp8O1ZXMgZ3JhdmVzLCBwZXJlY8OtdmVpcyBlbSBlc2NvbGFzKVwiXHJcbiAgICAgICAgPlxyXG4gICAgICAgICAge3Nob3dJY29uICYmIDxBbGVydE9jdGFnb24gY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPn1cclxuICAgICAgICAgIDxzcGFuPlVyZ2VudGU8L3NwYW4+XHJcbiAgICAgICAgPC9zcGFuPlxyXG4gICAgICApO1xyXG5cclxuICAgIGNhc2UgXCJhbHRhXCI6XHJcbiAgICAgIHJldHVybiAoXHJcbiAgICAgICAgPHNwYW5cclxuICAgICAgICAgIGNsYXNzTmFtZT17YGlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHB4LTIuNSBweS0wLjUgcm91bmRlZC1mdWxsIHRleHQtWzExcHhdIGZvbnQtYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgYmctb3JhbmdlLTEwMCB0ZXh0LW9yYW5nZS05MDAgZGFyazpiZy1vcmFuZ2UtOTUwLzgwIGRhcms6dGV4dC1vcmFuZ2UtMjAwIGJvcmRlciBib3JkZXItb3JhbmdlLTMwMCBkYXJrOmJvcmRlci1vcmFuZ2UtODAwICR7Y2xhc3NOYW1lfWB9XHJcbiAgICAgICAgICB0aXRsZT1cIkdyYXZpZGFkZSBBbHRhOiBNZWRpY2FtZW50b3MgY2xhbmRlc3Rpbm9zLCBjYXJuZXMgc2VtIGluc3Blw6fDo28sIGVzdGFiZWxlY2ltZW50b3MgZGUgYWx0byByaXNjb1wiXHJcbiAgICAgICAgPlxyXG4gICAgICAgICAge3Nob3dJY29uICYmIDxBbGVydFRyaWFuZ2xlIGNsYXNzTmFtZT1cInctMyBoLTMgdGV4dC1vcmFuZ2UtNjAwXCIgLz59XHJcbiAgICAgICAgICA8c3Bhbj5BbHRhPC9zcGFuPlxyXG4gICAgICAgIDwvc3Bhbj5cclxuICAgICAgKTtcclxuXHJcbiAgICBjYXNlIFwibWVkaWFcIjpcclxuICAgICAgcmV0dXJuIChcclxuICAgICAgICA8c3BhblxyXG4gICAgICAgICAgY2xhc3NOYW1lPXtgaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgcHgtMi41IHB5LTAuNSByb3VuZGVkLWZ1bGwgdGV4dC1bMTFweF0gZm9udC1zZW1pYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgYmctYW1iZXItNTAgdGV4dC1hbWJlci04MDAgZGFyazpiZy1hbWJlci05NTAvNjAgZGFyazp0ZXh0LWFtYmVyLTMwMCBib3JkZXIgYm9yZGVyLWFtYmVyLTIwMCBkYXJrOmJvcmRlci1hbWJlci04MDAgJHtjbGFzc05hbWV9YH1cclxuICAgICAgICAgIHRpdGxlPVwiR3JhdmlkYWRlIE3DqWRpYTogSXJyZWd1bGFyaWRhZGVzIGhpZ2nDqm5pY2FzIGVtIGNvbcOpcmNpbyBkZSBhbGltZW50b3MsIGZhbHRhIGRlIGFsdmFyw6FcIlxyXG4gICAgICAgID5cclxuICAgICAgICAgIHtzaG93SWNvbiAmJiA8QWxlcnRDaXJjbGUgY2xhc3NOYW1lPVwidy0zIGgtMyB0ZXh0LWFtYmVyLTYwMFwiIC8+fVxyXG4gICAgICAgICAgPHNwYW4+TcOpZGlhPC9zcGFuPlxyXG4gICAgICAgIDwvc3Bhbj5cclxuICAgICAgKTtcclxuXHJcbiAgICBjYXNlIFwiYmFpeGFcIjpcclxuICAgIGRlZmF1bHQ6XHJcbiAgICAgIHJldHVybiAoXHJcbiAgICAgICAgPHNwYW5cclxuICAgICAgICAgIGNsYXNzTmFtZT17YGlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHB4LTIuNSBweS0wLjUgcm91bmRlZC1mdWxsIHRleHQtWzExcHhdIGZvbnQtbWVkaXVtIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciBiZy1zbGF0ZS0xMDAgdGV4dC1zbGF0ZS03MDAgZGFyazpiZy1zbGF0ZS04MDAgZGFyazp0ZXh0LXNsYXRlLTMwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgJHtjbGFzc05hbWV9YH1cclxuICAgICAgICAgIHRpdGxlPVwiR3JhdmlkYWRlIEJhaXhhOiBRdWVzdMO1ZXMgZXN0cnV0dXJhaXMgc2VjdW5kw6FyaWFzLCBpbmZvcm1hdGl2YXNcIlxyXG4gICAgICAgID5cclxuICAgICAgICAgIHtzaG93SWNvbiAmJiA8U2hpZWxkQ2hlY2sgY2xhc3NOYW1lPVwidy0zIGgtMyB0ZXh0LXNsYXRlLTUwMFwiIC8+fVxyXG4gICAgICAgICAgPHNwYW4+QmFpeGE8L3NwYW4+XHJcbiAgICAgICAgPC9zcGFuPlxyXG4gICAgICApO1xyXG4gIH1cclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IEdyYXZpZGFkZUJhZGdlO1xyXG4iXX0=