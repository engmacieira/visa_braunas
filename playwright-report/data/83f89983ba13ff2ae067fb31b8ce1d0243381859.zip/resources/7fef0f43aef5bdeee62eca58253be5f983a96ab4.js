import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/ouvidoria/DenunciasListPage.tsx");const React = __vite__cjsImport0_react; const useMemo = __vite__cjsImport0_react["useMemo"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport7_react_jsxDevRuntime["jsxDEV"];/**
* Painel Operacional de Ouvidoria Sanitária e Fila de Triagem de Denúncias
* Rota: /ouvidoria
* Matriz visual de priorização por gravidade, busca textual e ações rápidas.
*/
import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=0fd2848a";
import { Link, useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=0fd2848a";
import { AlertOctagon, CheckCircle2, Clock, ExternalLink, Eye, Filter, Flame, Hourglass, Inbox, Plus, RefreshCw, Search, Shield } from "/node_modules/.vite/deps/lucide-react.js?v=0fd2848a";
import { ROUTES } from "/src/config/routes.config.ts";
import { useDenunciasList, useFilaTrabalhoDenuncias } from "/src/hooks/useOuvidoria.ts";
import { GravidadeBadge } from "/src/components/ouvidoria/GravidadeBadge.tsx";
import { StatusDenunciaBadge } from "/src/components/ouvidoria/StatusDenunciaBadge.tsx";
var _jsxFileName = "E:/Projetos VSCODE/visa_braunas/src/pages/ouvidoria/DenunciasListPage.tsx";
import __vite__cjsImport7_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=0fd2848a";
var _s = $RefreshSig$();
export const DenunciasListPage = () => {
	_s();
	const navigate = useNavigate();
	const [tabAtiva, setTabAtiva] = useState("triagem");
	const [busca, setBusca] = useState("");
	const [filtroGravidade, setFiltroGravidade] = useState("");
	// Consulta da lista com filtros do TanStack Query v5
	const statusParam = tabAtiva === "triagem" ? "recebida" : tabAtiva === "apuracao" ? "em_apuracao_fiscal" : "";
	const gravidadeParam = tabAtiva === "urgentes" ? "urgente" : filtroGravidade || "";
	const { data: denunciasData, isLoading, isRefetching, refetch } = useDenunciasList({
		status: statusParam || undefined,
		gravidade: gravidadeParam || undefined,
		limit: 100
	});
	const { data: filaTrabalho = [] } = useFilaTrabalhoDenuncias(0, 100);
	const denuncias = denunciasData?.items || denunciasData?.itens || [];
	// Contadores para métricas
	const totalUrgentes = useMemo(() => {
		return denuncias.filter((d) => d.gravidade === "urgente" && d.status !== "arquivada" && d.status !== "procedente").length;
	}, [denuncias]);
	const totalEmApuracao = useMemo(() => {
		return denuncias.filter((d) => d.status === "em_apuracao_fiscal").length;
	}, [denuncias]);
	// Filtragem local por texto
	const denunciasFiltradas = useMemo(() => {
		if (!busca.trim()) return denuncias;
		const termo = busca.toLowerCase();
		return denuncias.filter((d) => d.numero_protocolo.toLowerCase().includes(termo) || d.local_denunciado_identificacao.toLowerCase().includes(termo) || d.bairro && d.bairro.toLowerCase().includes(termo) || d.logradouro && d.logradouro.toLowerCase().includes(termo));
	}, [denuncias, busca]);
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-xs",
				children: [/* @__PURE__ */ _jsxDEV("div", { children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-2 text-teal-600 dark:text-teal-400 mb-1",
						children: /* @__PURE__ */ _jsxDEV("span", {
							className: "text-[11px] font-bold uppercase tracking-wider bg-teal-50 dark:bg-teal-950/40 px-2 py-0.5 rounded border border-teal-200 dark:border-teal-800",
							children: "Ouvidoria & Vigilância Ativa"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 109,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 108,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("h1", {
						className: "text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2",
						children: "Gestão de Denúncias Sanitárias"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 113,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("p", {
						className: "text-xs text-slate-500 dark:text-slate-400 mt-1 max-w-2xl",
						children: "Triagem operacional, priorização por risco à saúde pública, apuração de campo e garantia de sigilo legal ao cidadão."
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 116,
						columnNumber: 11
					}, this)
				] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 107,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "flex flex-wrap items-center gap-2.5",
					children: [/* @__PURE__ */ _jsxDEV(Link, {
						to: ROUTES.PUBLIC.DENUNCIA_CIDADA,
						target: "_blank",
						className: "px-3 py-2 text-xs font-semibold text-slate-700 dark:text-slate-200 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-700 shadow-2xs flex items-center gap-1.5 transition-colors",
						children: [/* @__PURE__ */ _jsxDEV("span", { children: "Canal do Cidadão" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 127,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV(ExternalLink, { className: "w-3.5 h-3.5 opacity-60" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 128,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 122,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV(Link, {
						to: ROUTES.OUVIDORIA.NOVA,
						className: "px-4 py-2 text-xs font-bold text-white bg-teal-600 hover:bg-teal-700 rounded-xl shadow-xs flex items-center gap-2 transition-colors",
						children: [/* @__PURE__ */ _jsxDEV(Plus, { className: "w-4 h-4" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 135,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Registrar Denúncia Interna" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 136,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 131,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 121,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 106,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 shadow-2xs",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center justify-between",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-xs font-semibold text-slate-500 dark:text-slate-400",
								children: "Pendentes de Triagem"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 146,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV(Hourglass, { className: "w-4 h-4 text-amber-500" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 149,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 145,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "mt-2 flex items-baseline gap-2",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-2xl font-bold text-slate-900 dark:text-white",
								children: filaTrabalho.length
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 152,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "text-[11px] text-slate-400",
								children: "em aberto"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 155,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 151,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 144,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "bg-white dark:bg-slate-900 border border-rose-200 dark:border-rose-900/60 rounded-xl p-4 shadow-2xs",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center justify-between",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-xs font-semibold text-rose-700 dark:text-rose-400 flex items-center gap-1",
								children: [/* @__PURE__ */ _jsxDEV("span", { className: "w-2 h-2 rounded-full bg-rose-600 animate-ping inline-block" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 163,
									columnNumber: 15
								}, this), "Gravidade Urgente"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 162,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV(AlertOctagon, { className: "w-4 h-4 text-rose-600" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 166,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 161,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "mt-2 flex items-baseline gap-2",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-2xl font-black text-rose-600",
								children: totalUrgentes
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 169,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "text-[11px] font-bold text-rose-600 bg-rose-50 px-1.5 py-0.5 rounded border border-rose-200",
								children: "risco iminente"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 172,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 168,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 160,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 shadow-2xs",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center justify-between",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-xs font-semibold text-slate-500 dark:text-slate-400",
								children: "Em Apuração Fiscal"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 181,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV(Clock, { className: "w-4 h-4 text-indigo-500" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 184,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 180,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "mt-2 flex items-baseline gap-2",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-2xl font-bold text-indigo-600 dark:text-indigo-400",
								children: totalEmApuracao
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 187,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "text-[11px] text-slate-400",
								children: "vistorias em curso"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 190,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 186,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 179,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 shadow-2xs",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center justify-between",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-xs font-semibold text-slate-500 dark:text-slate-400",
								children: "Total Registradas"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 197,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV(CheckCircle2, { className: "w-4 h-4 text-teal-600" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 200,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 196,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "mt-2 flex items-baseline gap-2",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-2xl font-bold text-slate-900 dark:text-white",
								children: denunciasData?.total ?? 0
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 203,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "text-[11px] text-slate-400",
								children: "manifestações"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 206,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 202,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 195,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 142,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-xs overflow-hidden",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "border-b border-slate-200 dark:border-slate-800 px-6 pt-3 flex items-center justify-between gap-4 overflow-x-auto",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-6",
							children: [
								/* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => setTabAtiva("triagem"),
									className: `pb-3 text-xs font-bold border-b-2 transition-colors whitespace-nowrap flex items-center gap-1.5 ${tabAtiva === "triagem" ? "border-teal-600 text-teal-600 dark:text-teal-400" : "border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-300"}`,
									children: [/* @__PURE__ */ _jsxDEV(Inbox, { className: "w-3.5 h-3.5" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 225,
										columnNumber: 15
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Fila de Triagem (Recebidas)" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 226,
										columnNumber: 15
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 216,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => setTabAtiva("urgentes"),
									className: `pb-3 text-xs font-bold border-b-2 transition-colors whitespace-nowrap flex items-center gap-1.5 ${tabAtiva === "urgentes" ? "border-rose-600 text-rose-600" : "border-transparent text-slate-500 hover:text-rose-600"}`,
									children: [
										/* @__PURE__ */ _jsxDEV(Flame, { className: "w-3.5 h-3.5 text-rose-600" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 238,
											columnNumber: 15
										}, this),
										/* @__PURE__ */ _jsxDEV("span", { children: "Urgentes" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 239,
											columnNumber: 15
										}, this),
										totalUrgentes > 0 && /* @__PURE__ */ _jsxDEV("span", {
											className: "px-1.5 py-0.2 rounded-full text-[10px] font-bold bg-rose-600 text-white",
											children: totalUrgentes
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 241,
											columnNumber: 17
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 229,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => setTabAtiva("apuracao"),
									className: `pb-3 text-xs font-bold border-b-2 transition-colors whitespace-nowrap ${tabAtiva === "apuracao" ? "border-teal-600 text-teal-600 dark:text-teal-400" : "border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-300"}`,
									children: "Em Apuração Fiscal"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 247,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => setTabAtiva("todas"),
									className: `pb-3 text-xs font-bold border-b-2 transition-colors whitespace-nowrap ${tabAtiva === "todas" ? "border-teal-600 text-teal-600 dark:text-teal-400" : "border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-300"}`,
									children: "Todas as Denúncias"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 259,
									columnNumber: 13
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 215,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							onClick: () => refetch(),
							disabled: isRefetching,
							className: "p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-300 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 mb-2 transition-colors",
							title: "Atualizar lista",
							children: /* @__PURE__ */ _jsxDEV(RefreshCw, { className: `w-4 h-4 ${isRefetching ? "animate-spin text-teal-600" : ""}` }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 279,
								columnNumber: 13
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 272,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 214,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "p-4 bg-slate-50/50 dark:bg-slate-800/40 border-b border-slate-200 dark:border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "relative flex-1 max-w-md",
							children: [/* @__PURE__ */ _jsxDEV(Search, { className: "w-4 h-4 text-slate-400 absolute left-3 top-2.5" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 288,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								type: "text",
								placeholder: "Buscar por protocolo (ex: DEN-2026), local ou bairro...",
								value: busca,
								onChange: (e) => setBusca(e.target.value),
								className: "w-full pl-9 pr-4 py-2 text-xs bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-teal-500"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 289,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 287,
							columnNumber: 11
						}, this), tabAtiva !== "urgentes" && /* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ _jsxDEV(Filter, { className: "w-3.5 h-3.5 text-slate-400" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 300,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("select", {
								value: filtroGravidade,
								onChange: (e) => setFiltroGravidade(e.target.value),
								className: "px-3 py-1.5 text-xs bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-700 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-teal-500",
								children: [
									/* @__PURE__ */ _jsxDEV("option", {
										value: "",
										children: "Todas as Gravidades"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 306,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("option", {
										value: "urgente",
										children: "Urgente (Risco Iminente)"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 307,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("option", {
										value: "alta",
										children: "Alta"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 308,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("option", {
										value: "media",
										children: "Média"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 309,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("option", {
										value: "baixa",
										children: "Baixa"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 310,
										columnNumber: 17
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 301,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 299,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 286,
						columnNumber: 9
					}, this),
					isLoading ? /* @__PURE__ */ _jsxDEV("div", {
						className: "p-16 text-center text-slate-400 text-xs flex flex-col items-center justify-center",
						children: [/* @__PURE__ */ _jsxDEV("div", { className: "w-6 h-6 border-2 border-teal-500 border-t-transparent rounded-full animate-spin mb-3" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 319,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Consultando registros de denúncias..." }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 320,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 318,
						columnNumber: 11
					}, this) : denunciasFiltradas.length === 0 ? /* @__PURE__ */ _jsxDEV("div", {
						className: "p-12 text-center text-slate-500 dark:text-slate-400 space-y-3",
						children: [
							/* @__PURE__ */ _jsxDEV(Shield, { className: "w-10 h-10 text-slate-300 dark:text-slate-700 mx-auto" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 324,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("p", {
								className: "text-xs font-semibold text-slate-700 dark:text-slate-300",
								children: "Nenhuma denúncia sanitária encontrada para os critérios selecionados."
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 325,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("p", {
								className: "text-[11px] text-slate-400 max-w-sm mx-auto",
								children: "Utilize o botão \"Registrar Denúncia Interna\" para cadastrar atendimentos presenciais ou por telefone."
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 328,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 323,
						columnNumber: 11
					}, this) : /* @__PURE__ */ _jsxDEV("div", {
						className: "overflow-x-auto",
						children: /* @__PURE__ */ _jsxDEV("table", {
							className: "w-full text-left text-xs border-collapse",
							children: [/* @__PURE__ */ _jsxDEV("thead", {
								className: "bg-slate-50/80 dark:bg-slate-800/60 border-b border-slate-200 dark:border-slate-800 text-slate-500 dark:text-slate-400 font-semibold uppercase tracking-wider",
								children: /* @__PURE__ */ _jsxDEV("tr", { children: [
									/* @__PURE__ */ _jsxDEV("th", {
										className: "py-3.5 px-4",
										children: "Protocolo"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 337,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("th", {
										className: "py-3.5 px-4",
										children: "Gravidade"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 338,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("th", {
										className: "py-3.5 px-4",
										children: "Local / Estabelecimento Denunciado"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 339,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("th", {
										className: "py-3.5 px-4",
										children: "Bairro / Endereço"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 340,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("th", {
										className: "py-3.5 px-4",
										children: "Data Recebimento"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 341,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("th", {
										className: "py-3.5 px-4",
										children: "Status"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 342,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("th", {
										className: "py-3.5 px-4 text-right",
										children: "Ações"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 343,
										columnNumber: 19
									}, this)
								] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 336,
									columnNumber: 17
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 335,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("tbody", {
								className: "divide-y divide-slate-100 dark:divide-slate-800",
								children: denunciasFiltradas.map((item) => {
									return /* @__PURE__ */ _jsxDEV("tr", {
										className: "hover:bg-slate-50/60 dark:hover:bg-slate-800/40 transition-colors",
										children: [
											/* @__PURE__ */ _jsxDEV("td", {
												className: "py-3.5 px-4",
												children: /* @__PURE__ */ _jsxDEV("div", {
													className: "flex flex-col",
													children: [/* @__PURE__ */ _jsxDEV("span", {
														className: "font-mono font-bold text-slate-900 dark:text-white",
														children: item.numero_protocolo
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 356,
														columnNumber: 27
													}, this), /* @__PURE__ */ _jsxDEV("span", {
														className: "text-[10px] text-slate-400 capitalize",
														children: ["Canal: ", item.origem.replace(/_/g, " ")]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 359,
														columnNumber: 27
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 355,
													columnNumber: 25
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 354,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("td", {
												className: "py-3.5 px-4",
												children: /* @__PURE__ */ _jsxDEV(GravidadeBadge, { gravidade: item.gravidade }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 367,
													columnNumber: 25
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 366,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("td", {
												className: "py-3.5 px-4",
												children: /* @__PURE__ */ _jsxDEV("div", {
													className: "flex flex-col max-w-xs",
													children: [/* @__PURE__ */ _jsxDEV("span", {
														className: "font-bold text-slate-800 dark:text-slate-200 truncate",
														children: item.local_denunciado_identificacao
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 373,
														columnNumber: 27
													}, this), item.denunciante_anonimo ? /* @__PURE__ */ _jsxDEV("span", {
														className: "text-[10px] text-slate-400 flex items-center gap-1",
														children: /* @__PURE__ */ _jsxDEV("span", { children: "• Denúncia Anônima" }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 378,
															columnNumber: 31
														}, this)
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 377,
														columnNumber: 29
													}, this) : /* @__PURE__ */ _jsxDEV("span", {
														className: "text-[10px] text-teal-600 dark:text-teal-400 flex items-center gap-1 font-medium",
														children: /* @__PURE__ */ _jsxDEV("span", { children: "• Cidadão Identificado" }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 382,
															columnNumber: 31
														}, this)
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 381,
														columnNumber: 29
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 372,
													columnNumber: 25
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 371,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("td", {
												className: "py-3.5 px-4 text-slate-600 dark:text-slate-300",
												children: item.bairro || item.logradouro || "Não especificado"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 389,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("td", {
												className: "py-3.5 px-4 text-slate-600 dark:text-slate-300",
												children: new Date(item.data_recebimento).toLocaleDateString("pt-BR", {
													day: "2-digit",
													month: "2-digit",
													year: "numeric",
													hour: "2-digit",
													minute: "2-digit"
												})
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 394,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("td", {
												className: "py-3.5 px-4",
												children: /* @__PURE__ */ _jsxDEV(StatusDenunciaBadge, { status: item.status }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 406,
													columnNumber: 25
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 405,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("td", {
												className: "py-3.5 px-4 text-right",
												children: /* @__PURE__ */ _jsxDEV(Link, {
													to: ROUTES.OUVIDORIA.DETALHE(item.id),
													className: "px-3 py-1.5 text-xs font-bold text-teal-700 dark:text-teal-300 bg-teal-50 dark:bg-teal-950/40 border border-teal-200 dark:border-teal-800 rounded-lg hover:bg-teal-100/60 shadow-2xs transition-colors inline-flex items-center gap-1.5",
													children: [/* @__PURE__ */ _jsxDEV(Eye, { className: "w-3.5 h-3.5" }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 415,
														columnNumber: 27
													}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Triar / Detalhes" }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 416,
														columnNumber: 27
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 411,
													columnNumber: 25
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 410,
												columnNumber: 23
											}, this)
										]
									}, item.id, true, {
										fileName: _jsxFileName,
										lineNumber: 349,
										columnNumber: 21
									}, this);
								})
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 346,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 334,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 333,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 212,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 104,
		columnNumber: 5
	}, this);
};
_s(DenunciasListPage, "3TqIAI2KRy359w5ZCZ7fSQWHaHY=", false, function() {
	return [
		useNavigate,
		useDenunciasList,
		useFilaTrabalhoDenuncias
	];
});
_c = DenunciasListPage;
export default DenunciasListPage;
var _c;
$RefreshReg$(_c, "DenunciasListPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/ouvidoria/DenunciasListPage.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("E:/Projetos VSCODE/visa_braunas/src/pages/ouvidoria/DenunciasListPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("E:/Projetos VSCODE/visa_braunas/src/pages/ouvidoria/DenunciasListPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "E:/Projetos VSCODE/visa_braunas/src/pages/ouvidoria/DenunciasListPage.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7Ozs7QUFNQSxPQUFPLFNBQVMsU0FBUyxnQkFBZ0I7QUFDekMsU0FBUyxNQUFNLG1CQUFtQjtBQUNsQyxTQUNFLGNBSUEsY0FDQSxPQUNBLGNBQ0EsS0FFQSxRQUNBLE9BQ0EsV0FDQSxPQUNBLE1BQ0EsV0FDQSxRQUNBLGNBR0s7QUFDUCxTQUFTLGNBQWM7QUFDdkIsU0FBUyxrQkFBa0IsZ0NBQWdDO0FBRTNELFNBQVMsc0JBQXNCO0FBQy9CLFNBQVMsMkJBQTJCOzs7O0FBU3BDLE9BQU8sTUFBTSwwQkFBb0M7O0NBQy9DLE1BQU0sV0FBVyxZQUFZO0NBQzdCLE1BQU0sQ0FBQyxVQUFVLGVBQWUsU0FBdUIsU0FBUztDQUNoRSxNQUFNLENBQUMsT0FBTyxZQUFZLFNBQVMsRUFBRTtDQUNyQyxNQUFNLENBQUMsaUJBQWlCLHNCQUFzQixTQUFpQyxFQUFFOztDQUdqRixNQUFNLGNBQ0osYUFBYSxZQUNULGFBQ0EsYUFBYSxhQUNiLHVCQUNBO0NBRU4sTUFBTSxpQkFDSixhQUFhLGFBQ1QsWUFDQSxtQkFBbUI7Q0FFekIsTUFBTSxFQUNKLE1BQU0sZUFDTixXQUNBLGNBQ0EsWUFDRSxpQkFBaUI7RUFDbkIsUUFBUSxlQUFlO0VBQ3ZCLFdBQVcsa0JBQWtCO0VBQzdCLE9BQU87Q0FDVCxDQUFDO0NBRUQsTUFBTSxFQUFFLE1BQU0sZUFBZSxDQUFDLE1BQU0seUJBQXlCLEdBQUcsR0FBRztDQUVuRSxNQUFNLFlBQ0osZUFBZSxTQUNkLGVBQXVHLFNBQ3hHLENBQUM7O0NBR0gsTUFBTSxnQkFBZ0IsY0FBYztFQUNsQyxPQUFPLFVBQVUsUUFBUSxNQUFNLEVBQUUsY0FBYyxhQUFhLEVBQUUsV0FBVyxlQUFlLEVBQUUsV0FBVyxZQUFZLENBQUMsQ0FBQztDQUNySCxHQUFHLENBQUMsU0FBUyxDQUFDO0NBRWQsTUFBTSxrQkFBa0IsY0FBYztFQUNwQyxPQUFPLFVBQVUsUUFBUSxNQUFNLEVBQUUsV0FBVyxvQkFBb0IsQ0FBQyxDQUFDO0NBQ3BFLEdBQUcsQ0FBQyxTQUFTLENBQUM7O0NBR2QsTUFBTSxxQkFBcUIsY0FBYztFQUN2QyxJQUFJLENBQUMsTUFBTSxLQUFLLEdBQUcsT0FBTztFQUUxQixNQUFNLFFBQVEsTUFBTSxZQUFZO0VBQ2hDLE9BQU8sVUFBVSxRQUNkLE1BQ0MsRUFBRSxpQkFBaUIsWUFBWSxDQUFDLENBQUMsU0FBUyxLQUFLLEtBQy9DLEVBQUUsK0JBQStCLFlBQVksQ0FBQyxDQUFDLFNBQVMsS0FBSyxLQUM1RCxFQUFFLFVBQVUsRUFBRSxPQUFPLFlBQVksQ0FBQyxDQUFDLFNBQVMsS0FBSyxLQUNqRCxFQUFFLGNBQWMsRUFBRSxXQUFXLFlBQVksQ0FBQyxDQUFDLFNBQVMsS0FBSyxDQUM5RDtDQUNGLEdBQUcsQ0FBQyxXQUFXLEtBQUssQ0FBQztDQUVyQixPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQWY7R0FFRSx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsT0FBRDtLQUNFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUNiLHdCQUFDLFFBQUQ7T0FBTSxXQUFVO2lCQUFnSjtNQUUxSjs7Ozs7S0FDSDs7Ozs7S0FDTCx3QkFBQyxNQUFEO01BQUksV0FBVTtnQkFBMkU7S0FFckY7Ozs7O0tBQ0osd0JBQUMsS0FBRDtNQUFHLFdBQVU7Z0JBQTREO0tBRXRFOzs7OztJQUNBOzs7O2NBRUwsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLE1BQUQ7TUFDRSxJQUFJLE9BQU8sT0FBTztNQUNsQixRQUFPO01BQ1AsV0FBVTtnQkFIWixDQUtFLHdCQUFDLFFBQUQsWUFBTSxtQkFBc0I7Ozs7Z0JBQzVCLHdCQUFDLGNBQUQsRUFBYyxXQUFVLHlCQUEwQjs7OztjQUM5Qzs7Ozs7ZUFFTix3QkFBQyxNQUFEO01BQ0UsSUFBSSxPQUFPLFVBQVU7TUFDckIsV0FBVTtnQkFGWixDQUlFLHdCQUFDLE1BQUQsRUFBTSxXQUFVLFVBQVc7Ozs7Z0JBQzNCLHdCQUFDLFFBQUQsWUFBTSw2QkFBZ0M7Ozs7Y0FDbEM7Ozs7O2FBQ0g7Ozs7O1lBQ0Y7Ozs7OztHQUdMLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWY7S0FFRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQTJEO09BRXJFOzs7O2lCQUNOLHdCQUFDLFdBQUQsRUFBVyxXQUFVLHlCQUEwQjs7OztlQUM1Qzs7Ozs7Z0JBQ0wsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFDYixhQUFhO09BQ1Y7Ozs7aUJBQ04sd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQTZCO09BQWU7Ozs7ZUFDekQ7Ozs7O2NBQ0Y7Ozs7OztLQUdMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBaEIsQ0FDRSx3QkFBQyxRQUFELEVBQU0sV0FBVSw2REFBOEQ7Ozs7a0JBQUMsbUJBRTNFOzs7OztpQkFDTix3QkFBQyxjQUFELEVBQWMsV0FBVSx3QkFBeUI7Ozs7ZUFDOUM7Ozs7O2dCQUNMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQ2I7T0FDRzs7OztpQkFDTix3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBOEY7T0FFeEc7Ozs7ZUFDSDs7Ozs7Y0FDRjs7Ozs7O0tBR0wsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUEyRDtPQUVyRTs7OztpQkFDTix3QkFBQyxPQUFELEVBQU8sV0FBVSwwQkFBMkI7Ozs7ZUFDekM7Ozs7O2dCQUNMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQ2I7T0FDRzs7OztpQkFDTix3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBNkI7T0FBd0I7Ozs7ZUFDbEU7Ozs7O2NBQ0Y7Ozs7OztLQUdMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBMkQ7T0FFckU7Ozs7aUJBQ04sd0JBQUMsY0FBRCxFQUFjLFdBQVUsd0JBQXlCOzs7O2VBQzlDOzs7OztnQkFDTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUNiLGVBQWUsU0FBUztPQUNyQjs7OztpQkFDTix3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBNkI7T0FBbUI7Ozs7ZUFDN0Q7Ozs7O2NBQ0Y7Ozs7OztJQUNGOzs7Ozs7R0FHTCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmO0tBRUUsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZjtRQUNFLHdCQUFDLFVBQUQ7U0FDRSxNQUFLO1NBQ0wsZUFBZSxZQUFZLFNBQVM7U0FDcEMsV0FBVyxtR0FDVCxhQUFhLFlBQ1QscURBQ0E7bUJBTlIsQ0FTRSx3QkFBQyxPQUFELEVBQU8sV0FBVSxjQUFlOzs7O21CQUNoQyx3QkFBQyxRQUFELFlBQU0sOEJBQWlDOzs7O2lCQUNqQzs7Ozs7O1FBRVIsd0JBQUMsVUFBRDtTQUNFLE1BQUs7U0FDTCxlQUFlLFlBQVksVUFBVTtTQUNyQyxXQUFXLG1HQUNULGFBQWEsYUFDVCxrQ0FDQTttQkFOUjtVQVNFLHdCQUFDLE9BQUQsRUFBTyxXQUFVLDRCQUE2Qjs7Ozs7VUFDOUMsd0JBQUMsUUFBRCxZQUFNLFdBQWM7Ozs7O1VBQ25CLGdCQUFnQixLQUNmLHdCQUFDLFFBQUQ7V0FBTSxXQUFVO3FCQUNiO1VBQ0c7Ozs7O1NBRUY7Ozs7OztRQUVSLHdCQUFDLFVBQUQ7U0FDRSxNQUFLO1NBQ0wsZUFBZSxZQUFZLFVBQVU7U0FDckMsV0FBVyx5RUFDVCxhQUFhLGFBQ1QscURBQ0E7bUJBRVA7UUFFTzs7Ozs7UUFFUix3QkFBQyxVQUFEO1NBQ0UsTUFBSztTQUNMLGVBQWUsWUFBWSxPQUFPO1NBQ2xDLFdBQVcseUVBQ1QsYUFBYSxVQUNULHFEQUNBO21CQUVQO1FBRU87Ozs7O09BQ0w7Ozs7O2dCQUVMLHdCQUFDLFVBQUQ7T0FDRSxNQUFLO09BQ0wsZUFBZSxRQUFRO09BQ3ZCLFVBQVU7T0FDVixXQUFVO09BQ1YsT0FBTTtpQkFFTix3QkFBQyxXQUFELEVBQ0UsV0FBVyxXQUFXLGVBQWUsK0JBQStCLEtBQ3JFOzs7OztNQUNLOzs7O2NBQ0w7Ozs7OztLQUdMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxRQUFELEVBQVEsV0FBVSxpREFBa0Q7Ozs7aUJBQ3BFLHdCQUFDLFNBQUQ7UUFDRSxNQUFLO1FBQ0wsYUFBWTtRQUNaLE9BQU87UUFDUCxXQUFXLE1BQU0sU0FBUyxFQUFFLE9BQU8sS0FBSztRQUN4QyxXQUFVO09BQ1g7Ozs7ZUFDRTs7Ozs7Z0JBRUosYUFBYSxjQUNaLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsUUFBRCxFQUFRLFdBQVUsNkJBQThCOzs7O2lCQUNoRCx3QkFBQyxVQUFEO1FBQ0UsT0FBTztRQUNQLFdBQVcsTUFBTSxtQkFBbUIsRUFBRSxPQUFPLEtBQVk7UUFDekQsV0FBVTtrQkFIWjtTQUtFLHdCQUFDLFVBQUQ7VUFBUSxPQUFNO29CQUFHO1NBQTJCOzs7OztTQUM1Qyx3QkFBQyxVQUFEO1VBQVEsT0FBTTtvQkFBVTtTQUFnQzs7Ozs7U0FDeEQsd0JBQUMsVUFBRDtVQUFRLE9BQU07b0JBQU87U0FBWTs7Ozs7U0FDakMsd0JBQUMsVUFBRDtVQUFRLE9BQU07b0JBQVE7U0FBYTs7Ozs7U0FDbkMsd0JBQUMsVUFBRDtVQUFRLE9BQU07b0JBQVE7U0FBYTs7Ozs7UUFDN0I7Ozs7O2VBQ0w7Ozs7O2NBRUo7Ozs7OztLQUdKLFlBQ0Msd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxPQUFELEVBQUssV0FBVSx1RkFBd0Y7Ozs7Z0JBQ3ZHLHdCQUFDLFFBQUQsWUFBTSx3Q0FBMkM7Ozs7Y0FDOUM7Ozs7O2dCQUNILG1CQUFtQixXQUFXLElBQ2hDLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmO09BQ0Usd0JBQUMsUUFBRCxFQUFRLFdBQVUsdURBQXdEOzs7OztPQUMxRSx3QkFBQyxLQUFEO1FBQUcsV0FBVTtrQkFBMkQ7T0FFckU7Ozs7O09BQ0gsd0JBQUMsS0FBRDtRQUFHLFdBQVU7a0JBQThDO09BRXhEOzs7OztNQUNBOzs7OztnQkFFTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFDYix3QkFBQyxTQUFEO09BQU8sV0FBVTtpQkFBakIsQ0FDRSx3QkFBQyxTQUFEO1FBQU8sV0FBVTtrQkFDZix3QkFBQyxNQUFEO1NBQ0Usd0JBQUMsTUFBRDtVQUFJLFdBQVU7b0JBQWM7U0FBYTs7Ozs7U0FDekMsd0JBQUMsTUFBRDtVQUFJLFdBQVU7b0JBQWM7U0FBYTs7Ozs7U0FDekMsd0JBQUMsTUFBRDtVQUFJLFdBQVU7b0JBQWM7U0FBc0M7Ozs7O1NBQ2xFLHdCQUFDLE1BQUQ7VUFBSSxXQUFVO29CQUFjO1NBQXFCOzs7OztTQUNqRCx3QkFBQyxNQUFEO1VBQUksV0FBVTtvQkFBYztTQUFvQjs7Ozs7U0FDaEQsd0JBQUMsTUFBRDtVQUFJLFdBQVU7b0JBQWM7U0FBVTs7Ozs7U0FDdEMsd0JBQUMsTUFBRDtVQUFJLFdBQVU7b0JBQXlCO1NBQVM7Ozs7O1FBQzlDOzs7OztPQUNDOzs7O2lCQUNQLHdCQUFDLFNBQUQ7UUFBTyxXQUFVO2tCQUNkLG1CQUFtQixLQUFLLFNBQVM7U0FDaEMsT0FDRSx3QkFBQyxNQUFEO1VBRUUsV0FBVTtvQkFGWjtXQUtFLHdCQUFDLE1BQUQ7WUFBSSxXQUFVO3NCQUNaLHdCQUFDLE9BQUQ7YUFBSyxXQUFVO3VCQUFmLENBQ0Usd0JBQUMsUUFBRDtjQUFNLFdBQVU7d0JBQ2IsS0FBSzthQUNGOzs7O3VCQUNOLHdCQUFDLFFBQUQ7Y0FBTSxXQUFVO3dCQUFoQixDQUF3RCxXQUM5QyxLQUFLLE9BQU8sUUFBUSxNQUFNLEdBQUcsQ0FDakM7Ozs7O3FCQUNIOzs7Ozs7V0FDSDs7Ozs7V0FHSix3QkFBQyxNQUFEO1lBQUksV0FBVTtzQkFDWix3QkFBQyxnQkFBRCxFQUFnQixXQUFXLEtBQUssVUFBWTs7Ozs7V0FDMUM7Ozs7O1dBR0osd0JBQUMsTUFBRDtZQUFJLFdBQVU7c0JBQ1osd0JBQUMsT0FBRDthQUFLLFdBQVU7dUJBQWYsQ0FDRSx3QkFBQyxRQUFEO2NBQU0sV0FBVTt3QkFDYixLQUFLO2FBQ0Y7Ozs7dUJBQ0wsS0FBSyxzQkFDSix3QkFBQyxRQUFEO2NBQU0sV0FBVTt3QkFDZCx3QkFBQyxRQUFELFlBQU0scUJBQXdCOzs7OzthQUMxQjs7Ozt3QkFFTix3QkFBQyxRQUFEO2NBQU0sV0FBVTt3QkFDZCx3QkFBQyxRQUFELFlBQU0seUJBQTRCOzs7OzthQUM5Qjs7OztxQkFFTDs7Ozs7O1dBQ0g7Ozs7O1dBR0osd0JBQUMsTUFBRDtZQUFJLFdBQVU7c0JBQ1gsS0FBSyxVQUFVLEtBQUssY0FBYztXQUNqQzs7Ozs7V0FHSix3QkFBQyxNQUFEO1lBQUksV0FBVTtzQkFDWCxJQUFJLEtBQUssS0FBSyxnQkFBZ0IsQ0FBQyxDQUFDLG1CQUFtQixTQUFTO2FBQzNELEtBQUs7YUFDTCxPQUFPO2FBQ1AsTUFBTTthQUNOLE1BQU07YUFDTixRQUFRO1lBQ1YsQ0FBQztXQUNDOzs7OztXQUdKLHdCQUFDLE1BQUQ7WUFBSSxXQUFVO3NCQUNaLHdCQUFDLHFCQUFELEVBQXFCLFFBQVEsS0FBSyxPQUFTOzs7OztXQUN6Qzs7Ozs7V0FHSix3QkFBQyxNQUFEO1lBQUksV0FBVTtzQkFDWix3QkFBQyxNQUFEO2FBQ0UsSUFBSSxPQUFPLFVBQVUsUUFBUSxLQUFLLEVBQUU7YUFDcEMsV0FBVTt1QkFGWixDQUlFLHdCQUFDLEtBQUQsRUFBSyxXQUFVLGNBQWU7Ozs7dUJBQzlCLHdCQUFDLFFBQUQsWUFBTSxtQkFBc0I7Ozs7cUJBQ3hCOzs7Ozs7V0FDSjs7Ozs7VUFDRjtZQXJFRyxLQUFLOzs7O2dCQXFFUjtRQUVSLENBQUM7T0FDSTs7OztlQUNGOzs7Ozs7S0FDSjs7Ozs7SUFFSjs7Ozs7O0VBQ0Y7Ozs7OztBQUVUOzs7Ozs7Ozs7QUFFQSxlQUFlIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkRlbnVuY2lhc0xpc3RQYWdlLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyIvKipcclxuICogUGFpbmVsIE9wZXJhY2lvbmFsIGRlIE91dmlkb3JpYSBTYW5pdMOhcmlhIGUgRmlsYSBkZSBUcmlhZ2VtIGRlIERlbsO6bmNpYXNcclxuICogUm90YTogL291dmlkb3JpYVxyXG4gKiBNYXRyaXogdmlzdWFsIGRlIHByaW9yaXphw6fDo28gcG9yIGdyYXZpZGFkZSwgYnVzY2EgdGV4dHVhbCBlIGHDp8O1ZXMgcsOhcGlkYXMuXHJcbiAqL1xyXG5cclxuaW1wb3J0IFJlYWN0LCB7IHVzZU1lbW8sIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7IExpbmssIHVzZU5hdmlnYXRlIH0gZnJvbSBcInJlYWN0LXJvdXRlci1kb21cIjtcclxuaW1wb3J0IHtcclxuICBBbGVydE9jdGFnb24sXHJcbiAgQWxlcnRUcmlhbmdsZSxcclxuICBCdWlsZGluZzIsXHJcbiAgQ2FsZW5kYXIsXHJcbiAgQ2hlY2tDaXJjbGUyLFxyXG4gIENsb2NrLFxyXG4gIEV4dGVybmFsTGluayxcclxuICBFeWUsXHJcbiAgRmlsZVNlYXJjaCxcclxuICBGaWx0ZXIsXHJcbiAgRmxhbWUsXHJcbiAgSG91cmdsYXNzLFxyXG4gIEluYm94LFxyXG4gIFBsdXMsXHJcbiAgUmVmcmVzaEN3LFxyXG4gIFNlYXJjaCxcclxuICBTaGllbGQsXHJcbiAgU2hpZWxkQWxlcnQsXHJcbiAgVXNlcixcclxufSBmcm9tIFwibHVjaWRlLXJlYWN0XCI7XHJcbmltcG9ydCB7IFJPVVRFUyB9IGZyb20gXCIuLi8uLi9jb25maWcvcm91dGVzLmNvbmZpZ1wiO1xyXG5pbXBvcnQgeyB1c2VEZW51bmNpYXNMaXN0LCB1c2VGaWxhVHJhYmFsaG9EZW51bmNpYXMgfSBmcm9tIFwiLi4vLi4vaG9va3MvdXNlT3V2aWRvcmlhXCI7XHJcbmltcG9ydCB7IEdyYXZpZGFkZURlbnVuY2lhLCBTdGF0dXNEZW51bmNpYSB9IGZyb20gXCIuLi8uLi90eXBlcy9vdXZpZG9yaWFcIjtcclxuaW1wb3J0IHsgR3JhdmlkYWRlQmFkZ2UgfSBmcm9tIFwiLi4vLi4vY29tcG9uZW50cy9vdXZpZG9yaWEvR3JhdmlkYWRlQmFkZ2VcIjtcclxuaW1wb3J0IHsgU3RhdHVzRGVudW5jaWFCYWRnZSB9IGZyb20gXCIuLi8uLi9jb21wb25lbnRzL291dmlkb3JpYS9TdGF0dXNEZW51bmNpYUJhZGdlXCI7XHJcblxyXG50eXBlIFRhYk91dmlkb3JpYSA9XHJcbiAgfCBcInRyaWFnZW1cIlxyXG4gIHwgXCJ0b2Rhc1wiXHJcbiAgfCBcInVyZ2VudGVzXCJcclxuICB8IFwiYXB1cmFjYW9cIlxyXG4gIHwgXCJjb25jbHVpZGFzXCI7XHJcblxyXG5leHBvcnQgY29uc3QgRGVudW5jaWFzTGlzdFBhZ2U6IFJlYWN0LkZDID0gKCkgPT4ge1xyXG4gIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKTtcclxuICBjb25zdCBbdGFiQXRpdmEsIHNldFRhYkF0aXZhXSA9IHVzZVN0YXRlPFRhYk91dmlkb3JpYT4oXCJ0cmlhZ2VtXCIpO1xyXG4gIGNvbnN0IFtidXNjYSwgc2V0QnVzY2FdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW2ZpbHRyb0dyYXZpZGFkZSwgc2V0RmlsdHJvR3JhdmlkYWRlXSA9IHVzZVN0YXRlPEdyYXZpZGFkZURlbnVuY2lhIHwgXCJcIj4oXCJcIik7XHJcblxyXG4gIC8vIENvbnN1bHRhIGRhIGxpc3RhIGNvbSBmaWx0cm9zIGRvIFRhblN0YWNrIFF1ZXJ5IHY1XHJcbiAgY29uc3Qgc3RhdHVzUGFyYW06IFN0YXR1c0RlbnVuY2lhIHwgXCJcIiA9XHJcbiAgICB0YWJBdGl2YSA9PT0gXCJ0cmlhZ2VtXCJcclxuICAgICAgPyBcInJlY2ViaWRhXCJcclxuICAgICAgOiB0YWJBdGl2YSA9PT0gXCJhcHVyYWNhb1wiXHJcbiAgICAgID8gXCJlbV9hcHVyYWNhb19maXNjYWxcIlxyXG4gICAgICA6IFwiXCI7XHJcblxyXG4gIGNvbnN0IGdyYXZpZGFkZVBhcmFtOiBHcmF2aWRhZGVEZW51bmNpYSB8IFwiXCIgPVxyXG4gICAgdGFiQXRpdmEgPT09IFwidXJnZW50ZXNcIlxyXG4gICAgICA/IFwidXJnZW50ZVwiXHJcbiAgICAgIDogZmlsdHJvR3JhdmlkYWRlIHx8IFwiXCI7XHJcblxyXG4gIGNvbnN0IHtcclxuICAgIGRhdGE6IGRlbnVuY2lhc0RhdGEsXHJcbiAgICBpc0xvYWRpbmcsXHJcbiAgICBpc1JlZmV0Y2hpbmcsXHJcbiAgICByZWZldGNoLFxyXG4gIH0gPSB1c2VEZW51bmNpYXNMaXN0KHtcclxuICAgIHN0YXR1czogc3RhdHVzUGFyYW0gfHwgdW5kZWZpbmVkLFxyXG4gICAgZ3JhdmlkYWRlOiBncmF2aWRhZGVQYXJhbSB8fCB1bmRlZmluZWQsXHJcbiAgICBsaW1pdDogMTAwLFxyXG4gIH0pO1xyXG5cclxuICBjb25zdCB7IGRhdGE6IGZpbGFUcmFiYWxobyA9IFtdIH0gPSB1c2VGaWxhVHJhYmFsaG9EZW51bmNpYXMoMCwgMTAwKTtcclxuXHJcbiAgY29uc3QgZGVudW5jaWFzID1cclxuICAgIGRlbnVuY2lhc0RhdGE/Lml0ZW1zIHx8XHJcbiAgICAoZGVudW5jaWFzRGF0YSBhcyB7IGl0ZW5zPzogdHlwZW9mIGRlbnVuY2lhc0RhdGEgZXh0ZW5kcyB7IGl0ZW1zOiBpbmZlciBUIH0gPyBUIDogbmV2ZXIgfSB8IHVuZGVmaW5lZCk/Lml0ZW5zIHx8XHJcbiAgICBbXTtcclxuXHJcbiAgLy8gQ29udGFkb3JlcyBwYXJhIG3DqXRyaWNhc1xyXG4gIGNvbnN0IHRvdGFsVXJnZW50ZXMgPSB1c2VNZW1vKCgpID0+IHtcclxuICAgIHJldHVybiBkZW51bmNpYXMuZmlsdGVyKChkKSA9PiBkLmdyYXZpZGFkZSA9PT0gXCJ1cmdlbnRlXCIgJiYgZC5zdGF0dXMgIT09IFwiYXJxdWl2YWRhXCIgJiYgZC5zdGF0dXMgIT09IFwicHJvY2VkZW50ZVwiKS5sZW5ndGg7XHJcbiAgfSwgW2RlbnVuY2lhc10pO1xyXG5cclxuICBjb25zdCB0b3RhbEVtQXB1cmFjYW8gPSB1c2VNZW1vKCgpID0+IHtcclxuICAgIHJldHVybiBkZW51bmNpYXMuZmlsdGVyKChkKSA9PiBkLnN0YXR1cyA9PT0gXCJlbV9hcHVyYWNhb19maXNjYWxcIikubGVuZ3RoO1xyXG4gIH0sIFtkZW51bmNpYXNdKTtcclxuXHJcbiAgLy8gRmlsdHJhZ2VtIGxvY2FsIHBvciB0ZXh0b1xyXG4gIGNvbnN0IGRlbnVuY2lhc0ZpbHRyYWRhcyA9IHVzZU1lbW8oKCkgPT4ge1xyXG4gICAgaWYgKCFidXNjYS50cmltKCkpIHJldHVybiBkZW51bmNpYXM7XHJcblxyXG4gICAgY29uc3QgdGVybW8gPSBidXNjYS50b0xvd2VyQ2FzZSgpO1xyXG4gICAgcmV0dXJuIGRlbnVuY2lhcy5maWx0ZXIoXHJcbiAgICAgIChkKSA9PlxyXG4gICAgICAgIGQubnVtZXJvX3Byb3RvY29sby50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKHRlcm1vKSB8fFxyXG4gICAgICAgIGQubG9jYWxfZGVudW5jaWFkb19pZGVudGlmaWNhY2FvLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXModGVybW8pIHx8XHJcbiAgICAgICAgKGQuYmFpcnJvICYmIGQuYmFpcnJvLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXModGVybW8pKSB8fFxyXG4gICAgICAgIChkLmxvZ3JhZG91cm8gJiYgZC5sb2dyYWRvdXJvLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXModGVybW8pKVxyXG4gICAgKTtcclxuICB9LCBbZGVudW5jaWFzLCBidXNjYV0pO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTZcIj5cclxuICAgICAgey8qIENhYmXDp2FsaG8gKi99XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBtZDpmbGV4LXJvdyBtZDppdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC00IGJnLXdoaXRlIGRhcms6Ymctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLTJ4bCBwLTYgc2hhZG93LXhzXCI+XHJcbiAgICAgICAgPGRpdj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdGV4dC10ZWFsLTYwMCBkYXJrOnRleHQtdGVhbC00MDAgbWItMVwiPlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSBmb250LWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIGJnLXRlYWwtNTAgZGFyazpiZy10ZWFsLTk1MC80MCBweC0yIHB5LTAuNSByb3VuZGVkIGJvcmRlciBib3JkZXItdGVhbC0yMDAgZGFyazpib3JkZXItdGVhbC04MDBcIj5cclxuICAgICAgICAgICAgICBPdXZpZG9yaWEgJiBWaWdpbMOibmNpYSBBdGl2YVxyXG4gICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGUgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgR2VzdMOjbyBkZSBEZW7Dum5jaWFzIFNhbml0w6FyaWFzXHJcbiAgICAgICAgICA8L2gxPlxyXG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTUwMCBkYXJrOnRleHQtc2xhdGUtNDAwIG10LTEgbWF4LXctMnhsXCI+XHJcbiAgICAgICAgICAgIFRyaWFnZW0gb3BlcmFjaW9uYWwsIHByaW9yaXphw6fDo28gcG9yIHJpc2NvIMOgIHNhw7pkZSBww7pibGljYSwgYXB1cmHDp8OjbyBkZSBjYW1wbyBlIGdhcmFudGlhIGRlIHNpZ2lsbyBsZWdhbCBhbyBjaWRhZMOjby5cclxuICAgICAgICAgIDwvcD5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBpdGVtcy1jZW50ZXIgZ2FwLTIuNVwiPlxyXG4gICAgICAgICAgPExpbmtcclxuICAgICAgICAgICAgdG89e1JPVVRFUy5QVUJMSUMuREVOVU5DSUFfQ0lEQURBfVxyXG4gICAgICAgICAgICB0YXJnZXQ9XCJfYmxhbmtcIlxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJweC0zIHB5LTIgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0yMDAgYmctc2xhdGUtNTAgZGFyazpiZy1zbGF0ZS04MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQteGwgaG92ZXI6Ymctc2xhdGUtMTAwIGRhcms6aG92ZXI6Ymctc2xhdGUtNzAwIHNoYWRvdy0yeHMgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSB0cmFuc2l0aW9uLWNvbG9yc1wiXHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIDxzcGFuPkNhbmFsIGRvIENpZGFkw6NvPC9zcGFuPlxyXG4gICAgICAgICAgICA8RXh0ZXJuYWxMaW5rIGNsYXNzTmFtZT1cInctMy41IGgtMy41IG9wYWNpdHktNjBcIiAvPlxyXG4gICAgICAgICAgPC9MaW5rPlxyXG5cclxuICAgICAgICAgIDxMaW5rXHJcbiAgICAgICAgICAgIHRvPXtST1VURVMuT1VWSURPUklBLk5PVkF9XHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTQgcHktMiB0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXdoaXRlIGJnLXRlYWwtNjAwIGhvdmVyOmJnLXRlYWwtNzAwIHJvdW5kZWQteGwgc2hhZG93LXhzIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRyYW5zaXRpb24tY29sb3JzXCJcclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgPFBsdXMgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+XHJcbiAgICAgICAgICAgIDxzcGFuPlJlZ2lzdHJhciBEZW7Dum5jaWEgSW50ZXJuYTwvc3Bhbj5cclxuICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICB7LyogQ2FyZHMgZGUgTcOpdHJpY2FzIE9wZXJhY2lvbmFpcyAqL31cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIHNtOmdyaWQtY29scy0yIGxnOmdyaWQtY29scy00IGdhcC00XCI+XHJcbiAgICAgICAgey8qIENhcmQgMTogRmlsYSBkZSBUcmlhZ2VtICovfVxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGFyazpiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtODAwIHJvdW5kZWQteGwgcC00IHNoYWRvdy0yeHNcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTUwMCBkYXJrOnRleHQtc2xhdGUtNDAwXCI+XHJcbiAgICAgICAgICAgICAgUGVuZGVudGVzIGRlIFRyaWFnZW1cclxuICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICA8SG91cmdsYXNzIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1hbWJlci01MDBcIiAvPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTIgZmxleCBpdGVtcy1iYXNlbGluZSBnYXAtMlwiPlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGQgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlXCI+XHJcbiAgICAgICAgICAgICAge2ZpbGFUcmFiYWxoby5sZW5ndGh9XHJcbiAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1zbGF0ZS00MDBcIj5lbSBhYmVydG88L3NwYW4+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgey8qIENhcmQgMjogVXJnZW50ZXMgKGNvbSBwdWxzbykgKi99XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXJvc2UtMjAwIGRhcms6Ym9yZGVyLXJvc2UtOTAwLzYwIHJvdW5kZWQteGwgcC00IHNoYWRvdy0yeHNcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXJvc2UtNzAwIGRhcms6dGV4dC1yb3NlLTQwMCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMVwiPlxyXG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInctMiBoLTIgcm91bmRlZC1mdWxsIGJnLXJvc2UtNjAwIGFuaW1hdGUtcGluZyBpbmxpbmUtYmxvY2tcIiAvPlxyXG4gICAgICAgICAgICAgIEdyYXZpZGFkZSBVcmdlbnRlXHJcbiAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgPEFsZXJ0T2N0YWdvbiBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtcm9zZS02MDBcIiAvPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTIgZmxleCBpdGVtcy1iYXNlbGluZSBnYXAtMlwiPlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJsYWNrIHRleHQtcm9zZS02MDBcIj5cclxuICAgICAgICAgICAgICB7dG90YWxVcmdlbnRlc31cclxuICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSBmb250LWJvbGQgdGV4dC1yb3NlLTYwMCBiZy1yb3NlLTUwIHB4LTEuNSBweS0wLjUgcm91bmRlZCBib3JkZXIgYm9yZGVyLXJvc2UtMjAwXCI+XHJcbiAgICAgICAgICAgICAgcmlzY28gaW1pbmVudGVcclxuICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIHsvKiBDYXJkIDM6IEVtIEFwdXJhw6fDo28gRmlzY2FsICovfVxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGFyazpiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtODAwIHJvdW5kZWQteGwgcC00IHNoYWRvdy0yeHNcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTUwMCBkYXJrOnRleHQtc2xhdGUtNDAwXCI+XHJcbiAgICAgICAgICAgICAgRW0gQXB1cmHDp8OjbyBGaXNjYWxcclxuICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICA8Q2xvY2sgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LWluZGlnby01MDBcIiAvPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTIgZmxleCBpdGVtcy1iYXNlbGluZSBnYXAtMlwiPlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGQgdGV4dC1pbmRpZ28tNjAwIGRhcms6dGV4dC1pbmRpZ28tNDAwXCI+XHJcbiAgICAgICAgICAgICAge3RvdGFsRW1BcHVyYWNhb31cclxuICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LXNsYXRlLTQwMFwiPnZpc3RvcmlhcyBlbSBjdXJzbzwvc3Bhbj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICB7LyogQ2FyZCA0OiBDb25jbHXDrWRhcyAqL31cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIGRhcms6Ymctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLXhsIHAtNCBzaGFkb3ctMnhzXCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS01MDAgZGFyazp0ZXh0LXNsYXRlLTQwMFwiPlxyXG4gICAgICAgICAgICAgIFRvdGFsIFJlZ2lzdHJhZGFzXHJcbiAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgPENoZWNrQ2lyY2xlMiBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtdGVhbC02MDBcIiAvPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTIgZmxleCBpdGVtcy1iYXNlbGluZSBnYXAtMlwiPlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGQgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlXCI+XHJcbiAgICAgICAgICAgICAge2RlbnVuY2lhc0RhdGE/LnRvdGFsID8/IDB9XHJcbiAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1zbGF0ZS00MDBcIj5tYW5pZmVzdGHDp8O1ZXM8L3NwYW4+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICB7LyogQ2FpeGEgY29tIEFiYXMgZSBMaXN0YSAqL31cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC0yeGwgc2hhZG93LXhzIG92ZXJmbG93LWhpZGRlblwiPlxyXG4gICAgICAgIHsvKiBBYmFzICovfVxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgcHgtNiBwdC0zIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtNCBvdmVyZmxvdy14LWF1dG9cIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTZcIj5cclxuICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFRhYkF0aXZhKFwidHJpYWdlbVwiKX1cclxuICAgICAgICAgICAgICBjbGFzc05hbWU9e2BwYi0zIHRleHQteHMgZm9udC1ib2xkIGJvcmRlci1iLTIgdHJhbnNpdGlvbi1jb2xvcnMgd2hpdGVzcGFjZS1ub3dyYXAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSAke1xyXG4gICAgICAgICAgICAgICAgdGFiQXRpdmEgPT09IFwidHJpYWdlbVwiXHJcbiAgICAgICAgICAgICAgICAgID8gXCJib3JkZXItdGVhbC02MDAgdGV4dC10ZWFsLTYwMCBkYXJrOnRleHQtdGVhbC00MDBcIlxyXG4gICAgICAgICAgICAgICAgICA6IFwiYm9yZGVyLXRyYW5zcGFyZW50IHRleHQtc2xhdGUtNTAwIGhvdmVyOnRleHQtc2xhdGUtODAwIGRhcms6aG92ZXI6dGV4dC1zbGF0ZS0zMDBcIlxyXG4gICAgICAgICAgICAgIH1gfVxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgPEluYm94IGNsYXNzTmFtZT1cInctMy41IGgtMy41XCIgLz5cclxuICAgICAgICAgICAgICA8c3Bhbj5GaWxhIGRlIFRyaWFnZW0gKFJlY2ViaWRhcyk8L3NwYW4+XHJcbiAgICAgICAgICAgIDwvYnV0dG9uPlxyXG5cclxuICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFRhYkF0aXZhKFwidXJnZW50ZXNcIil9XHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcGItMyB0ZXh0LXhzIGZvbnQtYm9sZCBib3JkZXItYi0yIHRyYW5zaXRpb24tY29sb3JzIHdoaXRlc3BhY2Utbm93cmFwIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgJHtcclxuICAgICAgICAgICAgICAgIHRhYkF0aXZhID09PSBcInVyZ2VudGVzXCJcclxuICAgICAgICAgICAgICAgICAgPyBcImJvcmRlci1yb3NlLTYwMCB0ZXh0LXJvc2UtNjAwXCJcclxuICAgICAgICAgICAgICAgICAgOiBcImJvcmRlci10cmFuc3BhcmVudCB0ZXh0LXNsYXRlLTUwMCBob3Zlcjp0ZXh0LXJvc2UtNjAwXCJcclxuICAgICAgICAgICAgICB9YH1cclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIDxGbGFtZSBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNSB0ZXh0LXJvc2UtNjAwXCIgLz5cclxuICAgICAgICAgICAgICA8c3Bhbj5VcmdlbnRlczwvc3Bhbj5cclxuICAgICAgICAgICAgICB7dG90YWxVcmdlbnRlcyA+IDAgJiYgKFxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicHgtMS41IHB5LTAuMiByb3VuZGVkLWZ1bGwgdGV4dC1bMTBweF0gZm9udC1ib2xkIGJnLXJvc2UtNjAwIHRleHQtd2hpdGVcIj5cclxuICAgICAgICAgICAgICAgICAge3RvdGFsVXJnZW50ZXN9XHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgPC9idXR0b24+XHJcblxyXG4gICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0VGFiQXRpdmEoXCJhcHVyYWNhb1wiKX1cclxuICAgICAgICAgICAgICBjbGFzc05hbWU9e2BwYi0zIHRleHQteHMgZm9udC1ib2xkIGJvcmRlci1iLTIgdHJhbnNpdGlvbi1jb2xvcnMgd2hpdGVzcGFjZS1ub3dyYXAgJHtcclxuICAgICAgICAgICAgICAgIHRhYkF0aXZhID09PSBcImFwdXJhY2FvXCJcclxuICAgICAgICAgICAgICAgICAgPyBcImJvcmRlci10ZWFsLTYwMCB0ZXh0LXRlYWwtNjAwIGRhcms6dGV4dC10ZWFsLTQwMFwiXHJcbiAgICAgICAgICAgICAgICAgIDogXCJib3JkZXItdHJhbnNwYXJlbnQgdGV4dC1zbGF0ZS01MDAgaG92ZXI6dGV4dC1zbGF0ZS04MDAgZGFyazpob3Zlcjp0ZXh0LXNsYXRlLTMwMFwiXHJcbiAgICAgICAgICAgICAgfWB9XHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICBFbSBBcHVyYcOnw6NvIEZpc2NhbFxyXG4gICAgICAgICAgICA8L2J1dHRvbj5cclxuXHJcbiAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRUYWJBdGl2YShcInRvZGFzXCIpfVxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT17YHBiLTMgdGV4dC14cyBmb250LWJvbGQgYm9yZGVyLWItMiB0cmFuc2l0aW9uLWNvbG9ycyB3aGl0ZXNwYWNlLW5vd3JhcCAke1xyXG4gICAgICAgICAgICAgICAgdGFiQXRpdmEgPT09IFwidG9kYXNcIlxyXG4gICAgICAgICAgICAgICAgICA/IFwiYm9yZGVyLXRlYWwtNjAwIHRleHQtdGVhbC02MDAgZGFyazp0ZXh0LXRlYWwtNDAwXCJcclxuICAgICAgICAgICAgICAgICAgOiBcImJvcmRlci10cmFuc3BhcmVudCB0ZXh0LXNsYXRlLTUwMCBob3Zlcjp0ZXh0LXNsYXRlLTgwMCBkYXJrOmhvdmVyOnRleHQtc2xhdGUtMzAwXCJcclxuICAgICAgICAgICAgICB9YH1cclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIFRvZGFzIGFzIERlbsO6bmNpYXNcclxuICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiByZWZldGNoKCl9XHJcbiAgICAgICAgICAgIGRpc2FibGVkPXtpc1JlZmV0Y2hpbmd9XHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMS41IHRleHQtc2xhdGUtNDAwIGhvdmVyOnRleHQtc2xhdGUtNjAwIGRhcms6aG92ZXI6dGV4dC1zbGF0ZS0zMDAgcm91bmRlZC1sZyBob3ZlcjpiZy1zbGF0ZS0xMDAgZGFyazpob3ZlcjpiZy1zbGF0ZS04MDAgbWItMiB0cmFuc2l0aW9uLWNvbG9yc1wiXHJcbiAgICAgICAgICAgIHRpdGxlPVwiQXR1YWxpemFyIGxpc3RhXCJcclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgPFJlZnJlc2hDd1xyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT17YHctNCBoLTQgJHtpc1JlZmV0Y2hpbmcgPyBcImFuaW1hdGUtc3BpbiB0ZXh0LXRlYWwtNjAwXCIgOiBcIlwifWB9XHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgey8qIExpbmhhIGRlIEJ1c2NhIGUgRmlsdHJvcyAqL31cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNCBiZy1zbGF0ZS01MC81MCBkYXJrOmJnLXNsYXRlLTgwMC80MCBib3JkZXItYiBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCBmbGV4IGZsZXgtY29sIHNtOmZsZXgtcm93IHNtOml0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTNcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgZmxleC0xIG1heC13LW1kXCI+XHJcbiAgICAgICAgICAgIDxTZWFyY2ggY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LXNsYXRlLTQwMCBhYnNvbHV0ZSBsZWZ0LTMgdG9wLTIuNVwiIC8+XHJcbiAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkJ1c2NhciBwb3IgcHJvdG9jb2xvIChleDogREVOLTIwMjYpLCBsb2NhbCBvdSBiYWlycm8uLi5cIlxyXG4gICAgICAgICAgICAgIHZhbHVlPXtidXNjYX1cclxuICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEJ1c2NhKGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcGwtOSBwci00IHB5LTIgdGV4dC14cyBiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC14bCB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGUgcGxhY2Vob2xkZXItc2xhdGUtNDAwIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy10ZWFsLTUwMFwiXHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICB7dGFiQXRpdmEgIT09IFwidXJnZW50ZXNcIiAmJiAoXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICA8RmlsdGVyIGNsYXNzTmFtZT1cInctMy41IGgtMy41IHRleHQtc2xhdGUtNDAwXCIgLz5cclxuICAgICAgICAgICAgICA8c2VsZWN0XHJcbiAgICAgICAgICAgICAgICB2YWx1ZT17ZmlsdHJvR3JhdmlkYWRlfVxyXG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRGaWx0cm9HcmF2aWRhZGUoZS50YXJnZXQudmFsdWUgYXMgYW55KX1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTMgcHktMS41IHRleHQteHMgYmctd2hpdGUgZGFyazpiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQteGwgdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTIwMCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctdGVhbC01MDBcIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJcIj5Ub2RhcyBhcyBHcmF2aWRhZGVzPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwidXJnZW50ZVwiPlVyZ2VudGUgKFJpc2NvIEltaW5lbnRlKTwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cImFsdGFcIj5BbHRhPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwibWVkaWFcIj5Nw6lkaWE8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJiYWl4YVwiPkJhaXhhPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgPC9zZWxlY3Q+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgKX1cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgey8qIFRhYmVsYSBkZSBEZW7Dum5jaWFzICovfVxyXG4gICAgICAgIHtpc0xvYWRpbmcgPyAoXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMTYgdGV4dC1jZW50ZXIgdGV4dC1zbGF0ZS00MDAgdGV4dC14cyBmbGV4IGZsZXgtY29sIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlclwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctNiBoLTYgYm9yZGVyLTIgYm9yZGVyLXRlYWwtNTAwIGJvcmRlci10LXRyYW5zcGFyZW50IHJvdW5kZWQtZnVsbCBhbmltYXRlLXNwaW4gbWItM1wiIC8+XHJcbiAgICAgICAgICAgIDxzcGFuPkNvbnN1bHRhbmRvIHJlZ2lzdHJvcyBkZSBkZW7Dum5jaWFzLi4uPC9zcGFuPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgKSA6IGRlbnVuY2lhc0ZpbHRyYWRhcy5sZW5ndGggPT09IDAgPyAoXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMTIgdGV4dC1jZW50ZXIgdGV4dC1zbGF0ZS01MDAgZGFyazp0ZXh0LXNsYXRlLTQwMCBzcGFjZS15LTNcIj5cclxuICAgICAgICAgICAgPFNoaWVsZCBjbGFzc05hbWU9XCJ3LTEwIGgtMTAgdGV4dC1zbGF0ZS0zMDAgZGFyazp0ZXh0LXNsYXRlLTcwMCBteC1hdXRvXCIgLz5cclxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0zMDBcIj5cclxuICAgICAgICAgICAgICBOZW5odW1hIGRlbsO6bmNpYSBzYW5pdMOhcmlhIGVuY29udHJhZGEgcGFyYSBvcyBjcml0w6lyaW9zIHNlbGVjaW9uYWRvcy5cclxuICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LXNsYXRlLTQwMCBtYXgtdy1zbSBteC1hdXRvXCI+XHJcbiAgICAgICAgICAgICAgVXRpbGl6ZSBvIGJvdMOjbyBcIlJlZ2lzdHJhciBEZW7Dum5jaWEgSW50ZXJuYVwiIHBhcmEgY2FkYXN0cmFyIGF0ZW5kaW1lbnRvcyBwcmVzZW5jaWFpcyBvdSBwb3IgdGVsZWZvbmUuXHJcbiAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICkgOiAoXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm92ZXJmbG93LXgtYXV0b1wiPlxyXG4gICAgICAgICAgICA8dGFibGUgY2xhc3NOYW1lPVwidy1mdWxsIHRleHQtbGVmdCB0ZXh0LXhzIGJvcmRlci1jb2xsYXBzZVwiPlxyXG4gICAgICAgICAgICAgIDx0aGVhZCBjbGFzc05hbWU9XCJiZy1zbGF0ZS01MC84MCBkYXJrOmJnLXNsYXRlLTgwMC82MCBib3JkZXItYiBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCB0ZXh0LXNsYXRlLTUwMCBkYXJrOnRleHQtc2xhdGUtNDAwIGZvbnQtc2VtaWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCI+XHJcbiAgICAgICAgICAgICAgICA8dHI+XHJcbiAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0zLjUgcHgtNFwiPlByb3RvY29sbzwvdGg+XHJcbiAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0zLjUgcHgtNFwiPkdyYXZpZGFkZTwvdGg+XHJcbiAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0zLjUgcHgtNFwiPkxvY2FsIC8gRXN0YWJlbGVjaW1lbnRvIERlbnVuY2lhZG88L3RoPlxyXG4gICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMy41IHB4LTRcIj5CYWlycm8gLyBFbmRlcmXDp288L3RoPlxyXG4gICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMy41IHB4LTRcIj5EYXRhIFJlY2ViaW1lbnRvPC90aD5cclxuICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB5LTMuNSBweC00XCI+U3RhdHVzPC90aD5cclxuICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB5LTMuNSBweC00IHRleHQtcmlnaHRcIj5Bw6fDtWVzPC90aD5cclxuICAgICAgICAgICAgICAgIDwvdHI+XHJcbiAgICAgICAgICAgICAgPC90aGVhZD5cclxuICAgICAgICAgICAgICA8dGJvZHkgY2xhc3NOYW1lPVwiZGl2aWRlLXkgZGl2aWRlLXNsYXRlLTEwMCBkYXJrOmRpdmlkZS1zbGF0ZS04MDBcIj5cclxuICAgICAgICAgICAgICAgIHtkZW51bmNpYXNGaWx0cmFkYXMubWFwKChpdGVtKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPHRyXHJcbiAgICAgICAgICAgICAgICAgICAgICBrZXk9e2l0ZW0uaWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJob3ZlcjpiZy1zbGF0ZS01MC82MCBkYXJrOmhvdmVyOmJnLXNsYXRlLTgwMC80MCB0cmFuc2l0aW9uLWNvbG9yc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgey8qIFByb3RvY29sbyAqL31cclxuICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS0zLjUgcHgtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2xcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1vbm8gZm9udC1ib2xkIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2l0ZW0ubnVtZXJvX3Byb3RvY29sb31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1zbGF0ZS00MDAgY2FwaXRhbGl6ZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgQ2FuYWw6IHtpdGVtLm9yaWdlbS5yZXBsYWNlKC9fL2csIFwiIFwiKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC90ZD5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICB7LyogR3JhdmlkYWRlIGNvbSBkZXN0YXF1ZSAqL31cclxuICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS0zLjUgcHgtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8R3JhdmlkYWRlQmFkZ2UgZ3JhdmlkYWRlPXtpdGVtLmdyYXZpZGFkZX0gLz5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgey8qIExvY2FsIERlbnVuY2lhZG8gKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMy41IHB4LTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIG1heC13LXhzXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtc2xhdGUtODAwIGRhcms6dGV4dC1zbGF0ZS0yMDAgdHJ1bmNhdGVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpdGVtLmxvY2FsX2RlbnVuY2lhZG9faWRlbnRpZmljYWNhb31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge2l0ZW0uZGVudW5jaWFudGVfYW5vbmltbyA/IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtc2xhdGUtNDAwIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPuKAoiBEZW7Dum5jaWEgQW7DtG5pbWE8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtdGVhbC02MDAgZGFyazp0ZXh0LXRlYWwtNDAwIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xIGZvbnQtbWVkaXVtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPuKAoiBDaWRhZMOjbyBJZGVudGlmaWNhZG88L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgIHsvKiBCYWlycm8gLyBFbmRlcmXDp28gKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMy41IHB4LTQgdGV4dC1zbGF0ZS02MDAgZGFyazp0ZXh0LXNsYXRlLTMwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7aXRlbS5iYWlycm8gfHwgaXRlbS5sb2dyYWRvdXJvIHx8IFwiTsOjbyBlc3BlY2lmaWNhZG9cIn1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgey8qIERhdGEgUmVjZWJpbWVudG8gKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMy41IHB4LTQgdGV4dC1zbGF0ZS02MDAgZGFyazp0ZXh0LXNsYXRlLTMwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7bmV3IERhdGUoaXRlbS5kYXRhX3JlY2ViaW1lbnRvKS50b0xvY2FsZURhdGVTdHJpbmcoXCJwdC1CUlwiLCB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZGF5OiBcIjItZGlnaXRcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBtb250aDogXCIyLWRpZ2l0XCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgeWVhcjogXCJudW1lcmljXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgaG91cjogXCIyLWRpZ2l0XCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbWludXRlOiBcIjItZGlnaXRcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgIHsvKiBTdGF0dXMgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMy41IHB4LTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPFN0YXR1c0RlbnVuY2lhQmFkZ2Ugc3RhdHVzPXtpdGVtLnN0YXR1c30gLz5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgey8qIEHDp8O1ZXMgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMy41IHB4LTQgdGV4dC1yaWdodFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8TGlua1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHRvPXtST1VURVMuT1VWSURPUklBLkRFVEFMSEUoaXRlbS5pZCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtMyBweS0xLjUgdGV4dC14cyBmb250LWJvbGQgdGV4dC10ZWFsLTcwMCBkYXJrOnRleHQtdGVhbC0zMDAgYmctdGVhbC01MCBkYXJrOmJnLXRlYWwtOTUwLzQwIGJvcmRlciBib3JkZXItdGVhbC0yMDAgZGFyazpib3JkZXItdGVhbC04MDAgcm91bmRlZC1sZyBob3ZlcjpiZy10ZWFsLTEwMC82MCBzaGFkb3ctMnhzIHRyYW5zaXRpb24tY29sb3JzIGlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxFeWUgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPlRyaWFyIC8gRGV0YWxoZXM8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgPC90cj5cclxuICAgICAgICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgICAgIH0pfVxyXG4gICAgICAgICAgICAgIDwvdGJvZHk+XHJcbiAgICAgICAgICAgIDwvdGFibGU+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICApfVxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBEZW51bmNpYXNMaXN0UGFnZTtcclxuIl19