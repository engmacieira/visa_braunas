/**
* Utilitários Universais de Formatação e Sanitização de Dados (DRY)
* Padroniza a formatação de documentos (CPF/CNPJ), CEP, telefones, moeda e datas.
*/
/**
* Remove qualquer caractere não numérico
*/
export function stripFormatacao(valor) {
	if (!valor) return "";
	return valor.replace(/\D/g, "");
}
/**
* Formata número de CNPJ: 00.000.000/0000-00
*/
export function formatCnpj(cnpj) {
	const limpo = stripFormatacao(cnpj);
	if (!limpo) return "";
	if (limpo.length !== 14) return cnpj || "";
	return limpo.replace(/^(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})$/, "$1.$2.$3/$4-$5");
}
/**
* Formata número de CPF: 000.000.000-00
*/
export function formatCpf(cpf) {
	const limpo = stripFormatacao(cpf);
	if (!limpo) return "";
	if (limpo.length !== 11) return cpf || "";
	return limpo.replace(/^(\d{3})(\d{3})(\d{3})(\d{2})$/, "$1.$2.$3-$4");
}
/**
* Formata documento universal (CPF ou CNPJ automaticamente com base no tamanho)
*/
export function formatCpfCnpj(doc) {
	const limpo = stripFormatacao(doc);
	if (!limpo) return "";
	if (limpo.length === 11) return formatCpf(limpo);
	if (limpo.length === 14) return formatCnpj(limpo);
	return doc || "";
}
/**
* Formata CEP: 00000-000
*/
export function formatCep(cep) {
	const limpo = stripFormatacao(cep);
	if (!limpo) return "";
	if (limpo.length !== 8) return cep || "";
	return limpo.replace(/^(\d{5})(\d{3})$/, "$1-$2");
}
/**
* Formata telefone com DDD: (00) 0000-0000 ou (00) 00000-0000
*/
export function formatTelefone(tel) {
	const limpo = stripFormatacao(tel);
	if (!limpo) return "";
	if (limpo.length === 10) {
		return limpo.replace(/^(\d{2})(\d{4})(\d{4})$/, "($1) $2-$3");
	}
	if (limpo.length === 11) {
		return limpo.replace(/^(\d{2})(\d{5})(\d{4})$/, "($1) $2-$3");
	}
	return tel || "";
}
/**
* Formata valores monetários em Real Brasileiro: R$ 1.250,00
*/
export function formatMoeda(valor) {
	if (typeof valor !== "number" || isNaN(valor)) return "R$ 0,00";
	return new Intl.NumberFormat("pt-BR", {
		style: "currency",
		currency: "BRL"
	}).format(valor);
}
/**
* Formata percentual padrão: 82,5%
*/
export function formatPorcentagem(valor, decimais = 1) {
	if (typeof valor !== "number" || isNaN(valor)) return "0%";
	return `${valor.toLocaleString("pt-BR", {
		minimumFractionDigits: decimais,
		maximumFractionDigits: decimais
	})}%`;
}
/**
* Formata data no padrão brasileiro: DD/MM/AAAA
*/
export function formatData(data) {
	if (!data) return "-";
	try {
		const d = typeof data === "string" ? new Date(data) : data;
		if (isNaN(d.getTime())) return String(data);
		// Se veio string no formato YYYY-MM-DD pura, evitar deslocamento de fuso UTC
		if (typeof data === "string" && /^\d{4}-\d{2}-\d{2}$/.test(data)) {
			const [ano, mes, dia] = data.split("-");
			return `${dia}/${mes}/${ano}`;
		}
		return d.toLocaleDateString("pt-BR", {
			day: "2-digit",
			month: "2-digit",
			year: "numeric"
		});
	} catch {
		return String(data);
	}
}
/**
* Formata data e hora no padrão brasileiro: DD/MM/AAAA às HH:mm
*/
export function formatDataHora(data) {
	if (!data) return "-";
	try {
		const d = typeof data === "string" ? new Date(data) : data;
		if (isNaN(d.getTime())) return String(data);
		const dataParte = d.toLocaleDateString("pt-BR", {
			day: "2-digit",
			month: "2-digit",
			year: "numeric"
		});
		const horaParte = d.toLocaleTimeString("pt-BR", {
			hour: "2-digit",
			minute: "2-digit"
		});
		return `${dataParte} às ${horaParte}`;
	} catch {
		return String(data);
	}
}
/**
* Formata data por extenso: 06 de novembro de 2026
*/
export function formatDataExtenso(data) {
	if (!data) return "-";
	try {
		const d = typeof data === "string" ? new Date(data) : data;
		if (isNaN(d.getTime())) return String(data);
		return d.toLocaleDateString("pt-BR", {
			day: "2-digit",
			month: "long",
			year: "numeric"
		});
	} catch {
		return String(data);
	}
}
/**
* Sanitiza e padroniza números de protocolo oficial
*/
export function formatNumeroProtocolo(prot) {
	if (!prot) return "";
	return prot.trim().toUpperCase();
}

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7Ozs7OztBQVFBLE9BQU8sU0FBUyxnQkFBZ0IsT0FBK0I7Q0FDN0QsSUFBSSxDQUFDLE9BQU8sT0FBTztDQUNuQixPQUFPLE1BQU0sUUFBUSxPQUFPLEVBQUU7QUFDaEM7Ozs7QUFLQSxPQUFPLFNBQVMsV0FBVyxNQUE4QjtDQUN2RCxNQUFNLFFBQVEsZ0JBQWdCLElBQUk7Q0FDbEMsSUFBSSxDQUFDLE9BQU8sT0FBTztDQUNuQixJQUFJLE1BQU0sV0FBVyxJQUFJLE9BQU8sUUFBUTtDQUV4QyxPQUFPLE1BQU0sUUFBUSx5Q0FBeUMsZ0JBQWdCO0FBQ2hGOzs7O0FBS0EsT0FBTyxTQUFTLFVBQVUsS0FBNkI7Q0FDckQsTUFBTSxRQUFRLGdCQUFnQixHQUFHO0NBQ2pDLElBQUksQ0FBQyxPQUFPLE9BQU87Q0FDbkIsSUFBSSxNQUFNLFdBQVcsSUFBSSxPQUFPLE9BQU87Q0FFdkMsT0FBTyxNQUFNLFFBQVEsa0NBQWtDLGFBQWE7QUFDdEU7Ozs7QUFLQSxPQUFPLFNBQVMsY0FBYyxLQUE2QjtDQUN6RCxNQUFNLFFBQVEsZ0JBQWdCLEdBQUc7Q0FDakMsSUFBSSxDQUFDLE9BQU8sT0FBTztDQUNuQixJQUFJLE1BQU0sV0FBVyxJQUFJLE9BQU8sVUFBVSxLQUFLO0NBQy9DLElBQUksTUFBTSxXQUFXLElBQUksT0FBTyxXQUFXLEtBQUs7Q0FDaEQsT0FBTyxPQUFPO0FBQ2hCOzs7O0FBS0EsT0FBTyxTQUFTLFVBQVUsS0FBNkI7Q0FDckQsTUFBTSxRQUFRLGdCQUFnQixHQUFHO0NBQ2pDLElBQUksQ0FBQyxPQUFPLE9BQU87Q0FDbkIsSUFBSSxNQUFNLFdBQVcsR0FBRyxPQUFPLE9BQU87Q0FFdEMsT0FBTyxNQUFNLFFBQVEsb0JBQW9CLE9BQU87QUFDbEQ7Ozs7QUFLQSxPQUFPLFNBQVMsZUFBZSxLQUE2QjtDQUMxRCxNQUFNLFFBQVEsZ0JBQWdCLEdBQUc7Q0FDakMsSUFBSSxDQUFDLE9BQU8sT0FBTztDQUVuQixJQUFJLE1BQU0sV0FBVyxJQUFJO0VBQ3ZCLE9BQU8sTUFBTSxRQUFRLDJCQUEyQixZQUFZO0NBQzlEO0NBQ0EsSUFBSSxNQUFNLFdBQVcsSUFBSTtFQUN2QixPQUFPLE1BQU0sUUFBUSwyQkFBMkIsWUFBWTtDQUM5RDtDQUVBLE9BQU8sT0FBTztBQUNoQjs7OztBQUtBLE9BQU8sU0FBUyxZQUFZLE9BQStCO0NBQ3pELElBQUksT0FBTyxVQUFVLFlBQVksTUFBTSxLQUFLLEdBQUcsT0FBTztDQUV0RCxPQUFPLElBQUksS0FBSyxhQUFhLFNBQVM7RUFDcEMsT0FBTztFQUNQLFVBQVU7Q0FDWixDQUFDLENBQUMsQ0FBQyxPQUFPLEtBQUs7QUFDakI7Ozs7QUFLQSxPQUFPLFNBQVMsa0JBQWtCLE9BQXVCLFdBQW1CLEdBQVc7Q0FDckYsSUFBSSxPQUFPLFVBQVUsWUFBWSxNQUFNLEtBQUssR0FBRyxPQUFPO0NBRXRELE9BQU8sR0FBRyxNQUFNLGVBQWUsU0FBUztFQUN0Qyx1QkFBdUI7RUFDdkIsdUJBQXVCO0NBQ3pCLENBQUMsRUFBRTtBQUNMOzs7O0FBS0EsT0FBTyxTQUFTLFdBQVcsTUFBcUM7Q0FDOUQsSUFBSSxDQUFDLE1BQU0sT0FBTztDQUVsQixJQUFJO0VBQ0YsTUFBTSxJQUFJLE9BQU8sU0FBUyxXQUFXLElBQUksS0FBSyxJQUFJLElBQUk7RUFDdEQsSUFBSSxNQUFNLEVBQUUsUUFBUSxDQUFDLEdBQUcsT0FBTyxPQUFPLElBQUk7O0VBRzFDLElBQUksT0FBTyxTQUFTLFlBQVksc0JBQXNCLEtBQUssSUFBSSxHQUFHO0dBQ2hFLE1BQU0sQ0FBQyxLQUFLLEtBQUssT0FBTyxLQUFLLE1BQU0sR0FBRztHQUN0QyxPQUFPLEdBQUcsSUFBSSxHQUFHLElBQUksR0FBRztFQUMxQjtFQUVBLE9BQU8sRUFBRSxtQkFBbUIsU0FBUztHQUNuQyxLQUFLO0dBQ0wsT0FBTztHQUNQLE1BQU07RUFDUixDQUFDO0NBQ0gsUUFBUTtFQUNOLE9BQU8sT0FBTyxJQUFJO0NBQ3BCO0FBQ0Y7Ozs7QUFLQSxPQUFPLFNBQVMsZUFBZSxNQUFxQztDQUNsRSxJQUFJLENBQUMsTUFBTSxPQUFPO0NBRWxCLElBQUk7RUFDRixNQUFNLElBQUksT0FBTyxTQUFTLFdBQVcsSUFBSSxLQUFLLElBQUksSUFBSTtFQUN0RCxJQUFJLE1BQU0sRUFBRSxRQUFRLENBQUMsR0FBRyxPQUFPLE9BQU8sSUFBSTtFQUUxQyxNQUFNLFlBQVksRUFBRSxtQkFBbUIsU0FBUztHQUM5QyxLQUFLO0dBQ0wsT0FBTztHQUNQLE1BQU07RUFDUixDQUFDO0VBRUQsTUFBTSxZQUFZLEVBQUUsbUJBQW1CLFNBQVM7R0FDOUMsTUFBTTtHQUNOLFFBQVE7RUFDVixDQUFDO0VBRUQsT0FBTyxHQUFHLFVBQVUsTUFBTTtDQUM1QixRQUFRO0VBQ04sT0FBTyxPQUFPLElBQUk7Q0FDcEI7QUFDRjs7OztBQUtBLE9BQU8sU0FBUyxrQkFBa0IsTUFBcUM7Q0FDckUsSUFBSSxDQUFDLE1BQU0sT0FBTztDQUVsQixJQUFJO0VBQ0YsTUFBTSxJQUFJLE9BQU8sU0FBUyxXQUFXLElBQUksS0FBSyxJQUFJLElBQUk7RUFDdEQsSUFBSSxNQUFNLEVBQUUsUUFBUSxDQUFDLEdBQUcsT0FBTyxPQUFPLElBQUk7RUFFMUMsT0FBTyxFQUFFLG1CQUFtQixTQUFTO0dBQ25DLEtBQUs7R0FDTCxPQUFPO0dBQ1AsTUFBTTtFQUNSLENBQUM7Q0FDSCxRQUFRO0VBQ04sT0FBTyxPQUFPLElBQUk7Q0FDcEI7QUFDRjs7OztBQUtBLE9BQU8sU0FBUyxzQkFBc0IsTUFBOEI7Q0FDbEUsSUFBSSxDQUFDLE1BQU0sT0FBTztDQUNsQixPQUFPLEtBQUssS0FBSyxDQUFDLENBQUMsWUFBWTtBQUNqQyIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJmb3JtYXR0ZXJzLnRzIl0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbIi8qKlxyXG4gKiBVdGlsaXTDoXJpb3MgVW5pdmVyc2FpcyBkZSBGb3JtYXRhw6fDo28gZSBTYW5pdGl6YcOnw6NvIGRlIERhZG9zIChEUlkpXHJcbiAqIFBhZHJvbml6YSBhIGZvcm1hdGHDp8OjbyBkZSBkb2N1bWVudG9zIChDUEYvQ05QSiksIENFUCwgdGVsZWZvbmVzLCBtb2VkYSBlIGRhdGFzLlxyXG4gKi9cclxuXHJcbi8qKlxyXG4gKiBSZW1vdmUgcXVhbHF1ZXIgY2FyYWN0ZXJlIG7Do28gbnVtw6lyaWNvXHJcbiAqL1xyXG5leHBvcnQgZnVuY3Rpb24gc3RyaXBGb3JtYXRhY2FvKHZhbG9yPzogc3RyaW5nIHwgbnVsbCk6IHN0cmluZyB7XHJcbiAgaWYgKCF2YWxvcikgcmV0dXJuIFwiXCI7XHJcbiAgcmV0dXJuIHZhbG9yLnJlcGxhY2UoL1xcRC9nLCBcIlwiKTtcclxufVxyXG5cclxuLyoqXHJcbiAqIEZvcm1hdGEgbsO6bWVybyBkZSBDTlBKOiAwMC4wMDAuMDAwLzAwMDAtMDBcclxuICovXHJcbmV4cG9ydCBmdW5jdGlvbiBmb3JtYXRDbnBqKGNucGo/OiBzdHJpbmcgfCBudWxsKTogc3RyaW5nIHtcclxuICBjb25zdCBsaW1wbyA9IHN0cmlwRm9ybWF0YWNhbyhjbnBqKTtcclxuICBpZiAoIWxpbXBvKSByZXR1cm4gXCJcIjtcclxuICBpZiAobGltcG8ubGVuZ3RoICE9PSAxNCkgcmV0dXJuIGNucGogfHwgXCJcIjtcclxuXHJcbiAgcmV0dXJuIGxpbXBvLnJlcGxhY2UoL14oXFxkezJ9KShcXGR7M30pKFxcZHszfSkoXFxkezR9KShcXGR7Mn0pJC8sIFwiJDEuJDIuJDMvJDQtJDVcIik7XHJcbn1cclxuXHJcbi8qKlxyXG4gKiBGb3JtYXRhIG7Dum1lcm8gZGUgQ1BGOiAwMDAuMDAwLjAwMC0wMFxyXG4gKi9cclxuZXhwb3J0IGZ1bmN0aW9uIGZvcm1hdENwZihjcGY/OiBzdHJpbmcgfCBudWxsKTogc3RyaW5nIHtcclxuICBjb25zdCBsaW1wbyA9IHN0cmlwRm9ybWF0YWNhbyhjcGYpO1xyXG4gIGlmICghbGltcG8pIHJldHVybiBcIlwiO1xyXG4gIGlmIChsaW1wby5sZW5ndGggIT09IDExKSByZXR1cm4gY3BmIHx8IFwiXCI7XHJcblxyXG4gIHJldHVybiBsaW1wby5yZXBsYWNlKC9eKFxcZHszfSkoXFxkezN9KShcXGR7M30pKFxcZHsyfSkkLywgXCIkMS4kMi4kMy0kNFwiKTtcclxufVxyXG5cclxuLyoqXHJcbiAqIEZvcm1hdGEgZG9jdW1lbnRvIHVuaXZlcnNhbCAoQ1BGIG91IENOUEogYXV0b21hdGljYW1lbnRlIGNvbSBiYXNlIG5vIHRhbWFuaG8pXHJcbiAqL1xyXG5leHBvcnQgZnVuY3Rpb24gZm9ybWF0Q3BmQ25waihkb2M/OiBzdHJpbmcgfCBudWxsKTogc3RyaW5nIHtcclxuICBjb25zdCBsaW1wbyA9IHN0cmlwRm9ybWF0YWNhbyhkb2MpO1xyXG4gIGlmICghbGltcG8pIHJldHVybiBcIlwiO1xyXG4gIGlmIChsaW1wby5sZW5ndGggPT09IDExKSByZXR1cm4gZm9ybWF0Q3BmKGxpbXBvKTtcclxuICBpZiAobGltcG8ubGVuZ3RoID09PSAxNCkgcmV0dXJuIGZvcm1hdENucGoobGltcG8pO1xyXG4gIHJldHVybiBkb2MgfHwgXCJcIjtcclxufVxyXG5cclxuLyoqXHJcbiAqIEZvcm1hdGEgQ0VQOiAwMDAwMC0wMDBcclxuICovXHJcbmV4cG9ydCBmdW5jdGlvbiBmb3JtYXRDZXAoY2VwPzogc3RyaW5nIHwgbnVsbCk6IHN0cmluZyB7XHJcbiAgY29uc3QgbGltcG8gPSBzdHJpcEZvcm1hdGFjYW8oY2VwKTtcclxuICBpZiAoIWxpbXBvKSByZXR1cm4gXCJcIjtcclxuICBpZiAobGltcG8ubGVuZ3RoICE9PSA4KSByZXR1cm4gY2VwIHx8IFwiXCI7XHJcblxyXG4gIHJldHVybiBsaW1wby5yZXBsYWNlKC9eKFxcZHs1fSkoXFxkezN9KSQvLCBcIiQxLSQyXCIpO1xyXG59XHJcblxyXG4vKipcclxuICogRm9ybWF0YSB0ZWxlZm9uZSBjb20gREREOiAoMDApIDAwMDAtMDAwMCBvdSAoMDApIDAwMDAwLTAwMDBcclxuICovXHJcbmV4cG9ydCBmdW5jdGlvbiBmb3JtYXRUZWxlZm9uZSh0ZWw/OiBzdHJpbmcgfCBudWxsKTogc3RyaW5nIHtcclxuICBjb25zdCBsaW1wbyA9IHN0cmlwRm9ybWF0YWNhbyh0ZWwpO1xyXG4gIGlmICghbGltcG8pIHJldHVybiBcIlwiO1xyXG5cclxuICBpZiAobGltcG8ubGVuZ3RoID09PSAxMCkge1xyXG4gICAgcmV0dXJuIGxpbXBvLnJlcGxhY2UoL14oXFxkezJ9KShcXGR7NH0pKFxcZHs0fSkkLywgXCIoJDEpICQyLSQzXCIpO1xyXG4gIH1cclxuICBpZiAobGltcG8ubGVuZ3RoID09PSAxMSkge1xyXG4gICAgcmV0dXJuIGxpbXBvLnJlcGxhY2UoL14oXFxkezJ9KShcXGR7NX0pKFxcZHs0fSkkLywgXCIoJDEpICQyLSQzXCIpO1xyXG4gIH1cclxuXHJcbiAgcmV0dXJuIHRlbCB8fCBcIlwiO1xyXG59XHJcblxyXG4vKipcclxuICogRm9ybWF0YSB2YWxvcmVzIG1vbmV0w6FyaW9zIGVtIFJlYWwgQnJhc2lsZWlybzogUiQgMS4yNTAsMDBcclxuICovXHJcbmV4cG9ydCBmdW5jdGlvbiBmb3JtYXRNb2VkYSh2YWxvcj86IG51bWJlciB8IG51bGwpOiBzdHJpbmcge1xyXG4gIGlmICh0eXBlb2YgdmFsb3IgIT09IFwibnVtYmVyXCIgfHwgaXNOYU4odmFsb3IpKSByZXR1cm4gXCJSJCAwLDAwXCI7XHJcblxyXG4gIHJldHVybiBuZXcgSW50bC5OdW1iZXJGb3JtYXQoXCJwdC1CUlwiLCB7XHJcbiAgICBzdHlsZTogXCJjdXJyZW5jeVwiLFxyXG4gICAgY3VycmVuY3k6IFwiQlJMXCIsXHJcbiAgfSkuZm9ybWF0KHZhbG9yKTtcclxufVxyXG5cclxuLyoqXHJcbiAqIEZvcm1hdGEgcGVyY2VudHVhbCBwYWRyw6NvOiA4Miw1JVxyXG4gKi9cclxuZXhwb3J0IGZ1bmN0aW9uIGZvcm1hdFBvcmNlbnRhZ2VtKHZhbG9yPzogbnVtYmVyIHwgbnVsbCwgZGVjaW1haXM6IG51bWJlciA9IDEpOiBzdHJpbmcge1xyXG4gIGlmICh0eXBlb2YgdmFsb3IgIT09IFwibnVtYmVyXCIgfHwgaXNOYU4odmFsb3IpKSByZXR1cm4gXCIwJVwiO1xyXG5cclxuICByZXR1cm4gYCR7dmFsb3IudG9Mb2NhbGVTdHJpbmcoXCJwdC1CUlwiLCB7XHJcbiAgICBtaW5pbXVtRnJhY3Rpb25EaWdpdHM6IGRlY2ltYWlzLFxyXG4gICAgbWF4aW11bUZyYWN0aW9uRGlnaXRzOiBkZWNpbWFpcyxcclxuICB9KX0lYDtcclxufVxyXG5cclxuLyoqXHJcbiAqIEZvcm1hdGEgZGF0YSBubyBwYWRyw6NvIGJyYXNpbGVpcm86IEREL01NL0FBQUFcclxuICovXHJcbmV4cG9ydCBmdW5jdGlvbiBmb3JtYXREYXRhKGRhdGE/OiBzdHJpbmcgfCBEYXRlIHwgbnVsbCk6IHN0cmluZyB7XHJcbiAgaWYgKCFkYXRhKSByZXR1cm4gXCItXCI7XHJcblxyXG4gIHRyeSB7XHJcbiAgICBjb25zdCBkID0gdHlwZW9mIGRhdGEgPT09IFwic3RyaW5nXCIgPyBuZXcgRGF0ZShkYXRhKSA6IGRhdGE7XHJcbiAgICBpZiAoaXNOYU4oZC5nZXRUaW1lKCkpKSByZXR1cm4gU3RyaW5nKGRhdGEpO1xyXG5cclxuICAgIC8vIFNlIHZlaW8gc3RyaW5nIG5vIGZvcm1hdG8gWVlZWS1NTS1ERCBwdXJhLCBldml0YXIgZGVzbG9jYW1lbnRvIGRlIGZ1c28gVVRDXHJcbiAgICBpZiAodHlwZW9mIGRhdGEgPT09IFwic3RyaW5nXCIgJiYgL15cXGR7NH0tXFxkezJ9LVxcZHsyfSQvLnRlc3QoZGF0YSkpIHtcclxuICAgICAgY29uc3QgW2FubywgbWVzLCBkaWFdID0gZGF0YS5zcGxpdChcIi1cIik7XHJcbiAgICAgIHJldHVybiBgJHtkaWF9LyR7bWVzfS8ke2Fub31gO1xyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiBkLnRvTG9jYWxlRGF0ZVN0cmluZyhcInB0LUJSXCIsIHtcclxuICAgICAgZGF5OiBcIjItZGlnaXRcIixcclxuICAgICAgbW9udGg6IFwiMi1kaWdpdFwiLFxyXG4gICAgICB5ZWFyOiBcIm51bWVyaWNcIixcclxuICAgIH0pO1xyXG4gIH0gY2F0Y2gge1xyXG4gICAgcmV0dXJuIFN0cmluZyhkYXRhKTtcclxuICB9XHJcbn1cclxuXHJcbi8qKlxyXG4gKiBGb3JtYXRhIGRhdGEgZSBob3JhIG5vIHBhZHLDo28gYnJhc2lsZWlybzogREQvTU0vQUFBQSDDoHMgSEg6bW1cclxuICovXHJcbmV4cG9ydCBmdW5jdGlvbiBmb3JtYXREYXRhSG9yYShkYXRhPzogc3RyaW5nIHwgRGF0ZSB8IG51bGwpOiBzdHJpbmcge1xyXG4gIGlmICghZGF0YSkgcmV0dXJuIFwiLVwiO1xyXG5cclxuICB0cnkge1xyXG4gICAgY29uc3QgZCA9IHR5cGVvZiBkYXRhID09PSBcInN0cmluZ1wiID8gbmV3IERhdGUoZGF0YSkgOiBkYXRhO1xyXG4gICAgaWYgKGlzTmFOKGQuZ2V0VGltZSgpKSkgcmV0dXJuIFN0cmluZyhkYXRhKTtcclxuXHJcbiAgICBjb25zdCBkYXRhUGFydGUgPSBkLnRvTG9jYWxlRGF0ZVN0cmluZyhcInB0LUJSXCIsIHtcclxuICAgICAgZGF5OiBcIjItZGlnaXRcIixcclxuICAgICAgbW9udGg6IFwiMi1kaWdpdFwiLFxyXG4gICAgICB5ZWFyOiBcIm51bWVyaWNcIixcclxuICAgIH0pO1xyXG5cclxuICAgIGNvbnN0IGhvcmFQYXJ0ZSA9IGQudG9Mb2NhbGVUaW1lU3RyaW5nKFwicHQtQlJcIiwge1xyXG4gICAgICBob3VyOiBcIjItZGlnaXRcIixcclxuICAgICAgbWludXRlOiBcIjItZGlnaXRcIixcclxuICAgIH0pO1xyXG5cclxuICAgIHJldHVybiBgJHtkYXRhUGFydGV9IMOgcyAke2hvcmFQYXJ0ZX1gO1xyXG4gIH0gY2F0Y2gge1xyXG4gICAgcmV0dXJuIFN0cmluZyhkYXRhKTtcclxuICB9XHJcbn1cclxuXHJcbi8qKlxyXG4gKiBGb3JtYXRhIGRhdGEgcG9yIGV4dGVuc286IDA2IGRlIG5vdmVtYnJvIGRlIDIwMjZcclxuICovXHJcbmV4cG9ydCBmdW5jdGlvbiBmb3JtYXREYXRhRXh0ZW5zbyhkYXRhPzogc3RyaW5nIHwgRGF0ZSB8IG51bGwpOiBzdHJpbmcge1xyXG4gIGlmICghZGF0YSkgcmV0dXJuIFwiLVwiO1xyXG5cclxuICB0cnkge1xyXG4gICAgY29uc3QgZCA9IHR5cGVvZiBkYXRhID09PSBcInN0cmluZ1wiID8gbmV3IERhdGUoZGF0YSkgOiBkYXRhO1xyXG4gICAgaWYgKGlzTmFOKGQuZ2V0VGltZSgpKSkgcmV0dXJuIFN0cmluZyhkYXRhKTtcclxuXHJcbiAgICByZXR1cm4gZC50b0xvY2FsZURhdGVTdHJpbmcoXCJwdC1CUlwiLCB7XHJcbiAgICAgIGRheTogXCIyLWRpZ2l0XCIsXHJcbiAgICAgIG1vbnRoOiBcImxvbmdcIixcclxuICAgICAgeWVhcjogXCJudW1lcmljXCIsXHJcbiAgICB9KTtcclxuICB9IGNhdGNoIHtcclxuICAgIHJldHVybiBTdHJpbmcoZGF0YSk7XHJcbiAgfVxyXG59XHJcblxyXG4vKipcclxuICogU2FuaXRpemEgZSBwYWRyb25pemEgbsO6bWVyb3MgZGUgcHJvdG9jb2xvIG9maWNpYWxcclxuICovXHJcbmV4cG9ydCBmdW5jdGlvbiBmb3JtYXROdW1lcm9Qcm90b2NvbG8ocHJvdD86IHN0cmluZyB8IG51bGwpOiBzdHJpbmcge1xyXG4gIGlmICghcHJvdCkgcmV0dXJuIFwiXCI7XHJcbiAgcmV0dXJuIHByb3QudHJpbSgpLnRvVXBwZXJDYXNlKCk7XHJcbn1cclxuIl19