import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/fiscalizacao/StatusInspecaoBadge.tsx");const React = __vite__cjsImport0_react;const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];/**
* Componente Badge para Status da Inspeção Fiscal
* agendada | em_andamento | concluida | cancelada
*/
import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=0fd2848a";
import { Calendar, CheckCircle2, Clock, XCircle } from "/node_modules/.vite/deps/lucide-react.js?v=0fd2848a";
var _jsxFileName = "E:/Projetos VSCODE/visa_braunas/src/components/fiscalizacao/StatusInspecaoBadge.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=0fd2848a";
const STATUS_CONFIG = {
	agendada: {
		label: "Agendada",
		bg: "bg-blue-50 dark:bg-blue-950/40",
		text: "text-blue-700 dark:text-blue-300",
		border: "border-blue-200 dark:border-blue-800",
		icon: Calendar
	},
	em_andamento: {
		label: "Em Andamento",
		bg: "bg-amber-50 dark:bg-amber-950/40",
		text: "text-amber-700 dark:text-amber-300",
		border: "border-amber-200 dark:border-amber-800",
		icon: Clock
	},
	concluida: {
		label: "Concluída",
		bg: "bg-emerald-50 dark:bg-emerald-950/40",
		text: "text-emerald-700 dark:text-emerald-300",
		border: "border-emerald-200 dark:border-emerald-800",
		icon: CheckCircle2
	},
	cancelada: {
		label: "Cancelada",
		bg: "bg-slate-100 dark:bg-slate-800",
		text: "text-slate-600 dark:text-slate-400",
		border: "border-slate-200 dark:border-slate-700",
		icon: XCircle
	}
};
export const StatusInspecaoBadge = ({ status, size = "sm" }) => {
	const config = STATUS_CONFIG[status] || {
		label: status,
		bg: "bg-slate-100",
		text: "text-slate-700",
		border: "border-slate-200",
		icon: Clock
	};
	const Icon = config.icon;
	const sizeClasses = size === "sm" ? "text-[11px] px-2 py-0.5 gap-1 font-medium" : "text-xs px-2.5 py-1 gap-1.5 font-semibold";
	return /* @__PURE__ */ _jsxDEV("span", {
		className: `inline-flex items-center rounded-md border ${config.bg} ${config.text} ${config.border} ${sizeClasses} whitespace-nowrap`,
		children: [/* @__PURE__ */ _jsxDEV(Icon, { className: "w-3 h-3 shrink-0" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 71,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("span", { children: config.label }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 72,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 68,
		columnNumber: 5
	}, this);
};
_c = StatusInspecaoBadge;
export default StatusInspecaoBadge;
var _c;
$RefreshReg$(_c, "StatusInspecaoBadge");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/fiscalizacao/StatusInspecaoBadge.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("E:/Projetos VSCODE/visa_braunas/src/components/fiscalizacao/StatusInspecaoBadge.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("E:/Projetos VSCODE/visa_braunas/src/components/fiscalizacao/StatusInspecaoBadge.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "E:/Projetos VSCODE/visa_braunas/src/components/fiscalizacao/StatusInspecaoBadge.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7OztBQUtBLE9BQU8sV0FBVztBQUNsQixTQUFTLFVBQVUsY0FBYyxPQUFPLGVBQWU7OztBQVF2RCxNQUFNLGdCQUdGO0NBQ0YsVUFBVTtFQUNSLE9BQU87RUFDUCxJQUFJO0VBQ0osTUFBTTtFQUNOLFFBQVE7RUFDUixNQUFNO0NBQ1I7Q0FDQSxjQUFjO0VBQ1osT0FBTztFQUNQLElBQUk7RUFDSixNQUFNO0VBQ04sUUFBUTtFQUNSLE1BQU07Q0FDUjtDQUNBLFdBQVc7RUFDVCxPQUFPO0VBQ1AsSUFBSTtFQUNKLE1BQU07RUFDTixRQUFRO0VBQ1IsTUFBTTtDQUNSO0NBQ0EsV0FBVztFQUNULE9BQU87RUFDUCxJQUFJO0VBQ0osTUFBTTtFQUNOLFFBQVE7RUFDUixNQUFNO0NBQ1I7QUFDRjtBQUVBLE9BQU8sTUFBTSx1QkFBMkQsRUFDdEUsUUFDQSxPQUFPLFdBQ0g7Q0FDSixNQUFNLFNBQVMsY0FBYyxXQUFXO0VBQ3RDLE9BQU87RUFDUCxJQUFJO0VBQ0osTUFBTTtFQUNOLFFBQVE7RUFDUixNQUFNO0NBQ1I7Q0FFQSxNQUFNLE9BQU8sT0FBTztDQUNwQixNQUFNLGNBQ0osU0FBUyxPQUNMLDhDQUNBO0NBRU4sT0FDRSx3QkFBQyxRQUFEO0VBQ0UsV0FBVyw4Q0FBOEMsT0FBTyxHQUFHLEdBQUcsT0FBTyxLQUFLLEdBQUcsT0FBTyxPQUFPLEdBQUcsWUFBWTtZQURwSCxDQUdFLHdCQUFDLE1BQUQsRUFBTSxXQUFVLG1CQUFvQjs7OztZQUNwQyx3QkFBQyxRQUFELFlBQU8sT0FBTyxNQUFZOzs7O1VBQ3RCOzs7Ozs7QUFFVjs7QUFFQSxlQUFlIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIlN0YXR1c0luc3BlY2FvQmFkZ2UudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbIi8qKlxyXG4gKiBDb21wb25lbnRlIEJhZGdlIHBhcmEgU3RhdHVzIGRhIEluc3Blw6fDo28gRmlzY2FsXHJcbiAqIGFnZW5kYWRhIHwgZW1fYW5kYW1lbnRvIHwgY29uY2x1aWRhIHwgY2FuY2VsYWRhXHJcbiAqL1xyXG5cclxuaW1wb3J0IFJlYWN0IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgeyBDYWxlbmRhciwgQ2hlY2tDaXJjbGUyLCBDbG9jaywgWENpcmNsZSB9IGZyb20gXCJsdWNpZGUtcmVhY3RcIjtcclxuaW1wb3J0IHsgU3RhdHVzSW5zcGVjYW8gfSBmcm9tIFwiLi4vLi4vdHlwZXMvZmlzY2FsaXphY2FvXCI7XHJcblxyXG5pbnRlcmZhY2UgU3RhdHVzSW5zcGVjYW9CYWRnZVByb3BzIHtcclxuICBzdGF0dXM6IFN0YXR1c0luc3BlY2FvIHwgc3RyaW5nO1xyXG4gIHNpemU/OiBcInNtXCIgfCBcIm1kXCI7XHJcbn1cclxuXHJcbmNvbnN0IFNUQVRVU19DT05GSUc6IFJlY29yZDxcclxuICBzdHJpbmcsXHJcbiAgeyBsYWJlbDogc3RyaW5nOyBiZzogc3RyaW5nOyB0ZXh0OiBzdHJpbmc7IGJvcmRlcjogc3RyaW5nOyBpY29uOiBSZWFjdC5Db21wb25lbnRUeXBlPHsgY2xhc3NOYW1lPzogc3RyaW5nIH0+IH1cclxuPiA9IHtcclxuICBhZ2VuZGFkYToge1xyXG4gICAgbGFiZWw6IFwiQWdlbmRhZGFcIixcclxuICAgIGJnOiBcImJnLWJsdWUtNTAgZGFyazpiZy1ibHVlLTk1MC80MFwiLFxyXG4gICAgdGV4dDogXCJ0ZXh0LWJsdWUtNzAwIGRhcms6dGV4dC1ibHVlLTMwMFwiLFxyXG4gICAgYm9yZGVyOiBcImJvcmRlci1ibHVlLTIwMCBkYXJrOmJvcmRlci1ibHVlLTgwMFwiLFxyXG4gICAgaWNvbjogQ2FsZW5kYXIsXHJcbiAgfSxcclxuICBlbV9hbmRhbWVudG86IHtcclxuICAgIGxhYmVsOiBcIkVtIEFuZGFtZW50b1wiLFxyXG4gICAgYmc6IFwiYmctYW1iZXItNTAgZGFyazpiZy1hbWJlci05NTAvNDBcIixcclxuICAgIHRleHQ6IFwidGV4dC1hbWJlci03MDAgZGFyazp0ZXh0LWFtYmVyLTMwMFwiLFxyXG4gICAgYm9yZGVyOiBcImJvcmRlci1hbWJlci0yMDAgZGFyazpib3JkZXItYW1iZXItODAwXCIsXHJcbiAgICBpY29uOiBDbG9jayxcclxuICB9LFxyXG4gIGNvbmNsdWlkYToge1xyXG4gICAgbGFiZWw6IFwiQ29uY2x1w61kYVwiLFxyXG4gICAgYmc6IFwiYmctZW1lcmFsZC01MCBkYXJrOmJnLWVtZXJhbGQtOTUwLzQwXCIsXHJcbiAgICB0ZXh0OiBcInRleHQtZW1lcmFsZC03MDAgZGFyazp0ZXh0LWVtZXJhbGQtMzAwXCIsXHJcbiAgICBib3JkZXI6IFwiYm9yZGVyLWVtZXJhbGQtMjAwIGRhcms6Ym9yZGVyLWVtZXJhbGQtODAwXCIsXHJcbiAgICBpY29uOiBDaGVja0NpcmNsZTIsXHJcbiAgfSxcclxuICBjYW5jZWxhZGE6IHtcclxuICAgIGxhYmVsOiBcIkNhbmNlbGFkYVwiLFxyXG4gICAgYmc6IFwiYmctc2xhdGUtMTAwIGRhcms6Ymctc2xhdGUtODAwXCIsXHJcbiAgICB0ZXh0OiBcInRleHQtc2xhdGUtNjAwIGRhcms6dGV4dC1zbGF0ZS00MDBcIixcclxuICAgIGJvcmRlcjogXCJib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMFwiLFxyXG4gICAgaWNvbjogWENpcmNsZSxcclxuICB9LFxyXG59O1xyXG5cclxuZXhwb3J0IGNvbnN0IFN0YXR1c0luc3BlY2FvQmFkZ2U6IFJlYWN0LkZDPFN0YXR1c0luc3BlY2FvQmFkZ2VQcm9wcz4gPSAoe1xyXG4gIHN0YXR1cyxcclxuICBzaXplID0gXCJzbVwiLFxyXG59KSA9PiB7XHJcbiAgY29uc3QgY29uZmlnID0gU1RBVFVTX0NPTkZJR1tzdGF0dXNdIHx8IHtcclxuICAgIGxhYmVsOiBzdGF0dXMsXHJcbiAgICBiZzogXCJiZy1zbGF0ZS0xMDBcIixcclxuICAgIHRleHQ6IFwidGV4dC1zbGF0ZS03MDBcIixcclxuICAgIGJvcmRlcjogXCJib3JkZXItc2xhdGUtMjAwXCIsXHJcbiAgICBpY29uOiBDbG9jayxcclxuICB9O1xyXG5cclxuICBjb25zdCBJY29uID0gY29uZmlnLmljb247XHJcbiAgY29uc3Qgc2l6ZUNsYXNzZXMgPVxyXG4gICAgc2l6ZSA9PT0gXCJzbVwiXHJcbiAgICAgID8gXCJ0ZXh0LVsxMXB4XSBweC0yIHB5LTAuNSBnYXAtMSBmb250LW1lZGl1bVwiXHJcbiAgICAgIDogXCJ0ZXh0LXhzIHB4LTIuNSBweS0xIGdhcC0xLjUgZm9udC1zZW1pYm9sZFwiO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPHNwYW5cclxuICAgICAgY2xhc3NOYW1lPXtgaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIHJvdW5kZWQtbWQgYm9yZGVyICR7Y29uZmlnLmJnfSAke2NvbmZpZy50ZXh0fSAke2NvbmZpZy5ib3JkZXJ9ICR7c2l6ZUNsYXNzZXN9IHdoaXRlc3BhY2Utbm93cmFwYH1cclxuICAgID5cclxuICAgICAgPEljb24gY2xhc3NOYW1lPVwidy0zIGgtMyBzaHJpbmstMFwiIC8+XHJcbiAgICAgIDxzcGFuPntjb25maWcubGFiZWx9PC9zcGFuPlxyXG4gICAgPC9zcGFuPlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBTdGF0dXNJbnNwZWNhb0JhZGdlO1xyXG4iXX0=