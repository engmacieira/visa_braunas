import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/ouvidoria/DenunciaDetailPage.tsx");const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport10_react_jsxDevRuntime["jsxDEV"];/**
* Ficha de Detalhamento da Denúncia Sanitária e Gestão de Despacho
* Rota: /ouvidoria/:id
* Apresenta narrativa dos fatos, proteção de sigilo, evidências e ações fiscais.
*/
import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=0fd2848a";
import { Link, useNavigate, useParams } from "/node_modules/.vite/deps/react-router-dom.js?v=0fd2848a";
import { AlertTriangle, Archive, ArrowLeft, Building2, CheckCircle2, ClipboardCheck, ExternalLink, FileText, Image as ImageIcon, MapPin, Send } from "/node_modules/.vite/deps/lucide-react.js?v=0fd2848a";
import { ROUTES } from "/src/config/routes.config.ts";
import { useDenunciaDetalhe } from "/src/hooks/useOuvidoria.ts";
import { GravidadeBadge } from "/src/components/ouvidoria/GravidadeBadge.tsx";
import { StatusDenunciaBadge } from "/src/components/ouvidoria/StatusDenunciaBadge.tsx";
import { DenuncianteCard } from "/src/components/ouvidoria/DenuncianteCard.tsx";
import { ModalDespachoFiscal } from "/src/components/ouvidoria/ModalDespachoFiscal.tsx";
import { ModalArquivamento } from "/src/components/ouvidoria/ModalArquivamento.tsx";
var _jsxFileName = "E:/Projetos VSCODE/visa_braunas/src/pages/ouvidoria/DenunciaDetailPage.tsx";
import __vite__cjsImport10_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=0fd2848a";
var _s = $RefreshSig$();
export const DenunciaDetailPage = () => {
	_s();
	const { id } = useParams();
	const navigate = useNavigate();
	const { data: denuncia, isLoading, isError, refetch } = useDenunciaDetalhe(id);
	const [modalDespachoAberta, setModalDespachoAberta] = useState(false);
	const [modalArquivamentoAberta, setModalArquivamentoAberta] = useState(false);
	if (isLoading) {
		return /* @__PURE__ */ _jsxDEV("div", {
			className: "p-16 text-center text-slate-400 text-xs flex flex-col items-center justify-center",
			children: [/* @__PURE__ */ _jsxDEV("div", { className: "w-6 h-6 border-2 border-teal-500 border-t-transparent rounded-full animate-spin mb-3" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 51,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Carregando processo de denúncia sanitária..." }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 52,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 50,
			columnNumber: 7
		}, this);
	}
	if (isError || !denuncia) {
		return /* @__PURE__ */ _jsxDEV("div", {
			className: "p-8 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl text-center space-y-4 max-w-xl mx-auto mt-8",
			children: [
				/* @__PURE__ */ _jsxDEV(AlertTriangle, { className: "w-10 h-10 text-rose-500 mx-auto" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 60,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("h2", {
					className: "text-sm font-bold text-slate-900 dark:text-white",
					children: "Denúncia não encontrada ou indisponível"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 61,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("p", {
					className: "text-xs text-slate-500",
					children: "Não foi possível localizar o registro desta denúncia sanitária."
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 64,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV(Link, {
					to: ROUTES.OUVIDORIA.LIST,
					className: "inline-flex items-center gap-1.5 px-4 py-2 text-xs font-bold text-teal-700 bg-teal-50 rounded-xl border border-teal-200 hover:bg-teal-100",
					children: [/* @__PURE__ */ _jsxDEV(ArrowLeft, { className: "w-3.5 h-3.5" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 71,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Voltar para a Fila" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 72,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 67,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 59,
			columnNumber: 7
		}, this);
	}
	const estab = denuncia.estabelecimento;
	const isConcluida = denuncia.status === "arquivada" || denuncia.status === "procedente" || denuncia.status === "improcedente" || denuncia.status === "concluida";
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "space-y-6 max-w-5xl mx-auto pb-12",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex items-center justify-between",
				children: [/* @__PURE__ */ _jsxDEV(Link, {
					to: ROUTES.OUVIDORIA.LIST,
					className: "inline-flex items-center gap-2 text-xs font-semibold text-slate-600 dark:text-slate-300 hover:text-teal-600 dark:hover:text-teal-400 transition-colors",
					children: [/* @__PURE__ */ _jsxDEV(ArrowLeft, { className: "w-4 h-4" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 93,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Voltar para Gestão de Denúncias" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 94,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 89,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ _jsxDEV(GravidadeBadge, { gravidade: denuncia.gravidade }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 98,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV(StatusDenunciaBadge, { status: denuncia.status }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 99,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 97,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 88,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-xs space-y-4",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100 dark:border-slate-800",
						children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-2 text-[11px] font-bold text-teal-600 dark:text-teal-400 uppercase tracking-wider",
							children: [
								/* @__PURE__ */ _jsxDEV("span", { children: "Ouvidoria Sanitária" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 108,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("span", { children: "•" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 109,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("span", {
									className: "capitalize",
									children: ["Canal: ", denuncia.origem.replace(/_/g, " ")]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 110,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 107,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("h1", {
							className: "text-xl font-bold text-slate-900 dark:text-white mt-0.5",
							children: ["Protocolo: ", denuncia.numero_protocolo]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 114,
							columnNumber: 13
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 106,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "text-right",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-[10px] text-slate-400 uppercase font-semibold block",
								children: "Data de Recebimento"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 120,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "text-xs font-medium text-slate-700 dark:text-slate-300",
								children: new Date(denuncia.data_recebimento).toLocaleString("pt-BR")
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 123,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 119,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 105,
						columnNumber: 9
					}, this),
					denuncia.despacho_coordenacao && /* @__PURE__ */ _jsxDEV("div", {
						className: "p-4 bg-indigo-50/70 dark:bg-indigo-950/30 border border-indigo-200 dark:border-indigo-800 rounded-xl text-xs space-y-1",
						children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "text-[10px] uppercase font-bold text-indigo-900 dark:text-indigo-300 block flex items-center gap-1.5",
							children: [/* @__PURE__ */ _jsxDEV(ClipboardCheck, { className: "w-3.5 h-3.5" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 133,
								columnNumber: 15
							}, this), "Despacho & Encaminhamento da Coordenação:"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 132,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("p", {
							className: "text-indigo-950 dark:text-indigo-200 leading-relaxed font-medium",
							children: denuncia.despacho_coordenacao
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 136,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 131,
						columnNumber: 11
					}, this),
					denuncia.conclusao_apuracao && /* @__PURE__ */ _jsxDEV("div", {
						className: "p-4 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-xl text-xs space-y-1",
						children: [
							/* @__PURE__ */ _jsxDEV("span", {
								className: "text-[10px] uppercase font-bold text-slate-700 dark:text-slate-300 block flex items-center gap-1.5",
								children: [/* @__PURE__ */ _jsxDEV(CheckCircle2, { className: "w-3.5 h-3.5 text-emerald-600" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 146,
									columnNumber: 15
								}, this), "Conclusão da Apuração:"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 145,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("p", {
								className: "text-slate-800 dark:text-slate-200 leading-relaxed",
								children: denuncia.conclusao_apuracao
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 149,
								columnNumber: 13
							}, this),
							denuncia.resposta_ao_denunciante && /* @__PURE__ */ _jsxDEV("div", {
								className: "mt-2 pt-2 border-t border-slate-200 dark:border-slate-700",
								children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "text-[10px] uppercase font-bold text-slate-400 block",
									children: "Resposta Disponibilizada ao Cidadão:"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 154,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("p", {
									className: "text-slate-600 dark:text-slate-400 italic text-[11px] mt-0.5",
									children: [
										"\"",
										denuncia.resposta_ao_denunciante,
										"\""
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 157,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 153,
								columnNumber: 15
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 144,
						columnNumber: 11
					}, this),
					!isConcluida && /* @__PURE__ */ _jsxDEV("div", {
						className: "flex flex-wrap items-center gap-2.5 pt-2 border-t border-slate-100 dark:border-slate-800",
						children: [/* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							onClick: () => setModalDespachoAberta(true),
							className: "px-4 py-2 text-xs font-bold text-white bg-teal-600 hover:bg-teal-700 rounded-xl shadow-xs inline-flex items-center gap-1.5 transition-colors",
							children: [/* @__PURE__ */ _jsxDEV(Send, { className: "w-3.5 h-3.5" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 173,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Despachar para Fiscalização" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 174,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 168,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							onClick: () => setModalArquivamentoAberta(true),
							className: "px-3.5 py-2 text-xs font-bold text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-xl transition-colors inline-flex items-center gap-1.5",
							children: [/* @__PURE__ */ _jsxDEV(Archive, { className: "w-3.5 h-3.5" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 182,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Concluir / Arquivar" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 183,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 177,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 167,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 104,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-xs space-y-3",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-2 pb-2 border-b border-slate-100 dark:border-slate-800",
					children: [/* @__PURE__ */ _jsxDEV(FileText, { className: "w-4 h-4 text-teal-600" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 192,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("h2", {
						className: "text-xs font-bold uppercase tracking-wider text-slate-900 dark:text-white",
						children: "Relato Minucioso dos Fatos Denunciados"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 193,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 191,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("p", {
					className: "text-xs text-slate-800 dark:text-slate-200 leading-relaxed whitespace-pre-line bg-slate-50/50 dark:bg-slate-800/30 p-4 rounded-xl border border-slate-100 dark:border-slate-800",
					children: denuncia.relato_denuncia || "Nenhum texto de relato detalhado informado."
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 198,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 190,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-xs space-y-4",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center justify-between pb-2 border-b border-slate-100 dark:border-slate-800",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ _jsxDEV(Building2, { className: "w-4 h-4 text-teal-600" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 207,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("h2", {
								className: "text-xs font-bold uppercase tracking-wider text-slate-900 dark:text-white",
								children: "Local ou Estabelecimento Alvo da Denúncia"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 208,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 206,
							columnNumber: 11
						}, this), estab && /* @__PURE__ */ _jsxDEV(Link, {
							to: ROUTES.ESTABELECIMENTOS.DETALHE(estab.id),
							target: "_blank",
							className: "text-xs font-semibold text-teal-600 dark:text-teal-400 hover:underline flex items-center gap-1",
							children: [/* @__PURE__ */ _jsxDEV("span", { children: "Ver Prontuário do Estabelecimento" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 218,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV(ExternalLink, { className: "w-3 h-3" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 219,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 213,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 205,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs",
						children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "text-slate-400 text-[10px] uppercase font-semibold block",
							children: "Identificação Declarada pelo Denunciante"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 226,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("p", {
							className: "font-bold text-slate-900 dark:text-white text-sm",
							children: denuncia.local_denunciado_identificacao
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 229,
							columnNumber: 13
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 225,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "text-slate-400 text-[10px] uppercase font-semibold block",
							children: "Bairro / Região"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 235,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("p", {
							className: "font-medium text-slate-800 dark:text-slate-200",
							children: denuncia.bairro || "Não informado"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 238,
							columnNumber: 13
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 234,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 224,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "text-xs text-slate-600 dark:text-slate-300 pt-2 border-t border-slate-100 dark:border-slate-800 flex items-start gap-1.5",
						children: [/* @__PURE__ */ _jsxDEV(MapPin, { className: "w-3.5 h-3.5 text-slate-400 shrink-0 mt-0.5" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 245,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: [
							/* @__PURE__ */ _jsxDEV("strong", { children: "Endereço Indicado:" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 247,
								columnNumber: 13
							}, this),
							" ",
							denuncia.logradouro || "Logradouro não informado",
							denuncia.numero ? `, Nº ${denuncia.numero}` : "",
							" ",
							denuncia.ponto_referencia && `(Ref: ${denuncia.ponto_referencia})`
						] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 246,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 244,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 204,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "space-y-2",
				children: [/* @__PURE__ */ _jsxDEV("span", {
					className: "text-xs font-bold uppercase tracking-wider text-slate-500 block px-1",
					children: "Identificação & Regras de Sigilo Legal"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 256,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV(DenuncianteCard, {
					denuncianteAnonimo: denuncia.denunciante_anonimo,
					nome: denuncia.denunciante_nome,
					telefone: denuncia.denunciante_telefone,
					email: denuncia.denunciante_email
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 259,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 255,
				columnNumber: 7
			}, this),
			denuncia.url_anexos_evidencias && denuncia.url_anexos_evidencias.length > 0 && /* @__PURE__ */ _jsxDEV("div", {
				className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-xs space-y-3",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-2 pb-2 border-b border-slate-100 dark:border-slate-800",
					children: [/* @__PURE__ */ _jsxDEV(ImageIcon, { className: "w-4 h-4 text-teal-600" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 271,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("h2", {
						className: "text-xs font-bold uppercase tracking-wider text-slate-900 dark:text-white",
						children: "Anexos & Evidências Submetidas"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 272,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 270,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3",
					children: denuncia.url_anexos_evidencias.map((anexo, idx) => /* @__PURE__ */ _jsxDEV("a", {
						href: anexo.url,
						target: "_blank",
						rel: "noreferrer",
						className: "p-3 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl flex items-center justify-between text-xs hover:border-teal-500 transition-colors",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-2 truncate",
							children: [/* @__PURE__ */ _jsxDEV(FileText, { className: "w-4 h-4 text-teal-600 shrink-0" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 287,
								columnNumber: 19
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "font-medium text-slate-800 dark:text-slate-200 truncate",
								children: anexo.nome || `Evidência ${idx + 1}`
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 288,
								columnNumber: 19
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 286,
							columnNumber: 17
						}, this), /* @__PURE__ */ _jsxDEV(ExternalLink, { className: "w-3.5 h-3.5 text-slate-400 shrink-0" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 292,
							columnNumber: 17
						}, this)]
					}, idx, true, {
						fileName: _jsxFileName,
						lineNumber: 279,
						columnNumber: 15
					}, this))
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 277,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 269,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV(ModalDespachoFiscal, {
				isOpen: modalDespachoAberta,
				onClose: () => setModalDespachoAberta(false),
				denunciaId: denuncia.id,
				protocolo: denuncia.numero_protocolo,
				gravidadeAtual: denuncia.gravidade,
				onSucesso: () => refetch()
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 300,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(ModalArquivamento, {
				isOpen: modalArquivamentoAberta,
				onClose: () => setModalArquivamentoAberta(false),
				denunciaId: denuncia.id,
				protocolo: denuncia.numero_protocolo,
				onSucesso: () => refetch()
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 309,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 86,
		columnNumber: 5
	}, this);
};
_s(DenunciaDetailPage, "ed23OzofZpVZaJj5HpapcIbjg24=", false, function() {
	return [
		useParams,
		useNavigate,
		useDenunciaDetalhe
	];
});
_c = DenunciaDetailPage;
export default DenunciaDetailPage;
var _c;
$RefreshReg$(_c, "DenunciaDetailPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/ouvidoria/DenunciaDetailPage.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("E:/Projetos VSCODE/visa_braunas/src/pages/ouvidoria/DenunciaDetailPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("E:/Projetos VSCODE/visa_braunas/src/pages/ouvidoria/DenunciaDetailPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "E:/Projetos VSCODE/visa_braunas/src/pages/ouvidoria/DenunciaDetailPage.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7Ozs7QUFNQSxPQUFPLFNBQVMsZ0JBQWdCO0FBQ2hDLFNBQVMsTUFBTSxhQUFhLGlCQUFpQjtBQUM3QyxTQUVFLGVBQ0EsU0FDQSxXQUNBLFdBRUEsY0FDQSxnQkFFQSxjQUdBLFVBQ0EsU0FBUyxXQUNULFFBQ0EsWUFLSztBQUNQLFNBQVMsY0FBYztBQUN2QixTQUFTLDBCQUEwQjtBQUNuQyxTQUFTLHNCQUFzQjtBQUMvQixTQUFTLDJCQUEyQjtBQUNwQyxTQUFTLHVCQUF1QjtBQUNoQyxTQUFTLDJCQUEyQjtBQUNwQyxTQUFTLHlCQUF5Qjs7OztBQUVsQyxPQUFPLE1BQU0sMkJBQXFDOztDQUNoRCxNQUFNLEVBQUUsT0FBTyxVQUEwQjtDQUN6QyxNQUFNLFdBQVcsWUFBWTtDQUU3QixNQUFNLEVBQUUsTUFBTSxVQUFVLFdBQVcsU0FBUyxZQUFZLG1CQUFtQixFQUFFO0NBRTdFLE1BQU0sQ0FBQyxxQkFBcUIsMEJBQTBCLFNBQVMsS0FBSztDQUNwRSxNQUFNLENBQUMseUJBQXlCLDhCQUE4QixTQUFTLEtBQUs7Q0FFNUUsSUFBSSxXQUFXO0VBQ2IsT0FDRSx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmLENBQ0Usd0JBQUMsT0FBRCxFQUFLLFdBQVUsdUZBQXdGOzs7O2FBQ3ZHLHdCQUFDLFFBQUQsWUFBTSwrQ0FBa0Q7Ozs7V0FDckQ7Ozs7OztDQUVUO0NBRUEsSUFBSSxXQUFXLENBQUMsVUFBVTtFQUN4QixPQUNFLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWY7SUFDRSx3QkFBQyxlQUFELEVBQWUsV0FBVSxrQ0FBbUM7Ozs7O0lBQzVELHdCQUFDLE1BQUQ7S0FBSSxXQUFVO2VBQW1EO0lBRTdEOzs7OztJQUNKLHdCQUFDLEtBQUQ7S0FBRyxXQUFVO2VBQXlCO0lBRW5DOzs7OztJQUNILHdCQUFDLE1BQUQ7S0FDRSxJQUFJLE9BQU8sVUFBVTtLQUNyQixXQUFVO2VBRlosQ0FJRSx3QkFBQyxXQUFELEVBQVcsV0FBVSxjQUFlOzs7O2VBQ3BDLHdCQUFDLFFBQUQsWUFBTSxxQkFBd0I7Ozs7YUFDMUI7Ozs7OztHQUNIOzs7Ozs7Q0FFVDtDQUVBLE1BQU0sUUFBUSxTQUFTO0NBQ3ZCLE1BQU0sY0FDSixTQUFTLFdBQVcsZUFDcEIsU0FBUyxXQUFXLGdCQUNwQixTQUFTLFdBQVcsa0JBQ3BCLFNBQVMsV0FBVztDQUV0QixPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQWY7R0FFRSx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsTUFBRDtLQUNFLElBQUksT0FBTyxVQUFVO0tBQ3JCLFdBQVU7ZUFGWixDQUlFLHdCQUFDLFdBQUQsRUFBVyxXQUFVLFVBQVc7Ozs7ZUFDaEMsd0JBQUMsUUFBRCxZQUFNLGtDQUFxQzs7OzthQUN2Qzs7Ozs7Y0FFTix3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsZ0JBQUQsRUFBZ0IsV0FBVyxTQUFTLFVBQVk7Ozs7ZUFDaEQsd0JBQUMscUJBQUQsRUFBcUIsUUFBUSxTQUFTLE9BQVM7Ozs7YUFDNUM7Ozs7O1lBQ0Y7Ozs7OztHQUdMLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWY7S0FDRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZjtRQUNFLHdCQUFDLFFBQUQsWUFBTSxzQkFBeUI7Ozs7O1FBQy9CLHdCQUFDLFFBQUQsWUFBTSxJQUFPOzs7OztRQUNiLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUFoQixDQUE2QixXQUNuQixTQUFTLE9BQU8sUUFBUSxNQUFNLEdBQUcsQ0FDckM7Ozs7OztPQUNIOzs7OztnQkFDTCx3QkFBQyxNQUFEO09BQUksV0FBVTtpQkFBZCxDQUF3RSxlQUMxRCxTQUFTLGdCQUNuQjs7Ozs7Y0FDRDs7OztnQkFFTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUEyRDtPQUVyRTs7OztpQkFDTix3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFDYixJQUFJLEtBQUssU0FBUyxnQkFBZ0IsQ0FBQyxDQUFDLGVBQWUsT0FBTztPQUN2RDs7OztlQUNIOzs7OztjQUNGOzs7Ozs7S0FHSixTQUFTLHdCQUNSLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsUUFBRDtPQUFNLFdBQVU7aUJBQWhCLENBQ0Usd0JBQUMsZ0JBQUQsRUFBZ0IsV0FBVSxjQUFlOzs7O2lCQUFDLDJDQUV0Qzs7Ozs7Z0JBQ04sd0JBQUMsS0FBRDtPQUFHLFdBQVU7aUJBQ1YsU0FBUztNQUNUOzs7O2NBQ0E7Ozs7OztLQUlOLFNBQVMsc0JBQ1Isd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWY7T0FDRSx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBaEIsQ0FDRSx3QkFBQyxjQUFELEVBQWMsV0FBVSwrQkFBZ0M7Ozs7a0JBQUMsd0JBRXJEOzs7Ozs7T0FDTix3QkFBQyxLQUFEO1FBQUcsV0FBVTtrQkFDVixTQUFTO09BQ1Q7Ozs7O09BQ0YsU0FBUywyQkFDUix3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUF1RDtRQUVqRTs7OztrQkFDTix3QkFBQyxLQUFEO1NBQUcsV0FBVTttQkFBYjtVQUE0RTtVQUN4RSxTQUFTO1VBQXdCO1NBQ2xDOzs7OztnQkFDQTs7Ozs7O01BRUo7Ozs7OztLQUlOLENBQUMsZUFDQSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLFVBQUQ7T0FDRSxNQUFLO09BQ0wsZUFBZSx1QkFBdUIsSUFBSTtPQUMxQyxXQUFVO2lCQUhaLENBS0Usd0JBQUMsTUFBRCxFQUFNLFdBQVUsY0FBZTs7OztpQkFDL0Isd0JBQUMsUUFBRCxZQUFNLDhCQUFpQzs7OztlQUNqQzs7Ozs7Z0JBRVIsd0JBQUMsVUFBRDtPQUNFLE1BQUs7T0FDTCxlQUFlLDJCQUEyQixJQUFJO09BQzlDLFdBQVU7aUJBSFosQ0FLRSx3QkFBQyxTQUFELEVBQVMsV0FBVSxjQUFlOzs7O2lCQUNsQyx3QkFBQyxRQUFELFlBQU0sc0JBQXlCOzs7O2VBQ3pCOzs7OztjQUNMOzs7Ozs7SUFFSjs7Ozs7O0dBR0wsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxVQUFELEVBQVUsV0FBVSx3QkFBeUI7Ozs7ZUFDN0Msd0JBQUMsTUFBRDtNQUFJLFdBQVU7Z0JBQTRFO0tBRXRGOzs7O2FBQ0Q7Ozs7O2NBRUwsd0JBQUMsS0FBRDtLQUFHLFdBQVU7ZUFDVixTQUFTLG1CQUFtQjtJQUM1Qjs7OztZQUNBOzs7Ozs7R0FHTCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmO0tBQ0Usd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLFdBQUQsRUFBVyxXQUFVLHdCQUF5Qjs7OztpQkFDOUMsd0JBQUMsTUFBRDtRQUFJLFdBQVU7a0JBQTRFO09BRXRGOzs7O2VBQ0Q7Ozs7O2dCQUNKLFNBQ0Msd0JBQUMsTUFBRDtPQUNFLElBQUksT0FBTyxpQkFBaUIsUUFBUSxNQUFNLEVBQUU7T0FDNUMsUUFBTztPQUNQLFdBQVU7aUJBSFosQ0FLRSx3QkFBQyxRQUFELFlBQU0sb0NBQXVDOzs7O2lCQUM3Qyx3QkFBQyxjQUFELEVBQWMsV0FBVSxVQUFXOzs7O2VBQy9COzs7OztjQUVMOzs7Ozs7S0FFTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxRQUFEO09BQU0sV0FBVTtpQkFBMkQ7TUFFckU7Ozs7Z0JBQ04sd0JBQUMsS0FBRDtPQUFHLFdBQVU7aUJBQ1YsU0FBUztNQUNUOzs7O2NBQ0E7Ozs7Z0JBRUwsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFFBQUQ7T0FBTSxXQUFVO2lCQUEyRDtNQUVyRTs7OztnQkFDTix3QkFBQyxLQUFEO09BQUcsV0FBVTtpQkFDVixTQUFTLFVBQVU7TUFDbkI7Ozs7Y0FDQTs7OztjQUNGOzs7Ozs7S0FFTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLFFBQUQsRUFBUSxXQUFVLDZDQUE4Qzs7OztnQkFDaEUsd0JBQUMsUUFBRDtPQUNFLHdCQUFDLFVBQUQsWUFBUSxxQkFBMEI7Ozs7O09BQUM7T0FBRSxTQUFTLGNBQWM7T0FDM0QsU0FBUyxTQUFTLFFBQVEsU0FBUyxXQUFXO09BQUk7T0FDbEQsU0FBUyxvQkFBb0IsU0FBUyxTQUFTLGlCQUFpQjtNQUM3RDs7OztjQUNIOzs7Ozs7SUFDRjs7Ozs7O0dBR0wsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLFFBQUQ7S0FBTSxXQUFVO2VBQXVFO0lBRWpGOzs7O2NBQ04sd0JBQUMsaUJBQUQ7S0FDRSxvQkFBb0IsU0FBUztLQUM3QixNQUFNLFNBQVM7S0FDZixVQUFVLFNBQVM7S0FDbkIsT0FBTyxTQUFTO0lBQ2pCOzs7O1lBQ0U7Ozs7OztHQUdKLFNBQVMseUJBQXlCLFNBQVMsc0JBQXNCLFNBQVMsS0FDekUsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxXQUFELEVBQVcsV0FBVSx3QkFBeUI7Ozs7ZUFDOUMsd0JBQUMsTUFBRDtNQUFJLFdBQVU7Z0JBQTRFO0tBRXRGOzs7O2FBQ0Q7Ozs7O2NBRUwsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFDWixTQUFTLHNCQUFzQixLQUFLLE9BQU8sUUFDMUMsd0JBQUMsS0FBRDtNQUVFLE1BQU0sTUFBTTtNQUNaLFFBQU87TUFDUCxLQUFJO01BQ0osV0FBVTtnQkFMWixDQU9FLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsVUFBRCxFQUFVLFdBQVUsaUNBQWtDOzs7O2lCQUN0RCx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFDYixNQUFNLFFBQVEsYUFBYSxNQUFNO09BQzlCOzs7O2VBQ0g7Ozs7O2dCQUNMLHdCQUFDLGNBQUQsRUFBYyxXQUFVLHNDQUF1Qzs7OztjQUM5RDtRQWJJOzs7O1lBYUosQ0FDSjtJQUNFOzs7O1lBQ0Y7Ozs7OztHQUlQLHdCQUFDLHFCQUFEO0lBQ0UsUUFBUTtJQUNSLGVBQWUsdUJBQXVCLEtBQUs7SUFDM0MsWUFBWSxTQUFTO0lBQ3JCLFdBQVcsU0FBUztJQUNwQixnQkFBZ0IsU0FBUztJQUN6QixpQkFBaUIsUUFBUTtHQUMxQjs7Ozs7R0FFRCx3QkFBQyxtQkFBRDtJQUNFLFFBQVE7SUFDUixlQUFlLDJCQUEyQixLQUFLO0lBQy9DLFlBQVksU0FBUztJQUNyQixXQUFXLFNBQVM7SUFDcEIsaUJBQWlCLFFBQVE7R0FDMUI7Ozs7O0VBQ0U7Ozs7OztBQUVUOzs7Ozs7Ozs7QUFFQSxlQUFlIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkRlbnVuY2lhRGV0YWlsUGFnZS50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiLyoqXHJcbiAqIEZpY2hhIGRlIERldGFsaGFtZW50byBkYSBEZW7Dum5jaWEgU2FuaXTDoXJpYSBlIEdlc3TDo28gZGUgRGVzcGFjaG9cclxuICogUm90YTogL291dmlkb3JpYS86aWRcclxuICogQXByZXNlbnRhIG5hcnJhdGl2YSBkb3MgZmF0b3MsIHByb3Rlw6fDo28gZGUgc2lnaWxvLCBldmlkw6puY2lhcyBlIGHDp8O1ZXMgZmlzY2Fpcy5cclxuICovXHJcblxyXG5pbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHsgTGluaywgdXNlTmF2aWdhdGUsIHVzZVBhcmFtcyB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCI7XHJcbmltcG9ydCB7XHJcbiAgQWxlcnRDaXJjbGUsXHJcbiAgQWxlcnRUcmlhbmdsZSxcclxuICBBcmNoaXZlLFxyXG4gIEFycm93TGVmdCxcclxuICBCdWlsZGluZzIsXHJcbiAgQ2FsZW5kYXIsXHJcbiAgQ2hlY2tDaXJjbGUyLFxyXG4gIENsaXBib2FyZENoZWNrLFxyXG4gIENsb2NrLFxyXG4gIEV4dGVybmFsTGluayxcclxuICBFeWUsXHJcbiAgRmlsZVNlYXJjaCxcclxuICBGaWxlVGV4dCxcclxuICBJbWFnZSBhcyBJbWFnZUljb24sXHJcbiAgTWFwUGluLFxyXG4gIFNlbmQsXHJcbiAgU2hpZWxkLFxyXG4gIFNoaWVsZEFsZXJ0LFxyXG4gIFVzZXJDaGVjayxcclxuICBYQ2lyY2xlLFxyXG59IGZyb20gXCJsdWNpZGUtcmVhY3RcIjtcclxuaW1wb3J0IHsgUk9VVEVTIH0gZnJvbSBcIi4uLy4uL2NvbmZpZy9yb3V0ZXMuY29uZmlnXCI7XHJcbmltcG9ydCB7IHVzZURlbnVuY2lhRGV0YWxoZSB9IGZyb20gXCIuLi8uLi9ob29rcy91c2VPdXZpZG9yaWFcIjtcclxuaW1wb3J0IHsgR3JhdmlkYWRlQmFkZ2UgfSBmcm9tIFwiLi4vLi4vY29tcG9uZW50cy9vdXZpZG9yaWEvR3JhdmlkYWRlQmFkZ2VcIjtcclxuaW1wb3J0IHsgU3RhdHVzRGVudW5jaWFCYWRnZSB9IGZyb20gXCIuLi8uLi9jb21wb25lbnRzL291dmlkb3JpYS9TdGF0dXNEZW51bmNpYUJhZGdlXCI7XHJcbmltcG9ydCB7IERlbnVuY2lhbnRlQ2FyZCB9IGZyb20gXCIuLi8uLi9jb21wb25lbnRzL291dmlkb3JpYS9EZW51bmNpYW50ZUNhcmRcIjtcclxuaW1wb3J0IHsgTW9kYWxEZXNwYWNob0Zpc2NhbCB9IGZyb20gXCIuLi8uLi9jb21wb25lbnRzL291dmlkb3JpYS9Nb2RhbERlc3BhY2hvRmlzY2FsXCI7XHJcbmltcG9ydCB7IE1vZGFsQXJxdWl2YW1lbnRvIH0gZnJvbSBcIi4uLy4uL2NvbXBvbmVudHMvb3V2aWRvcmlhL01vZGFsQXJxdWl2YW1lbnRvXCI7XHJcblxyXG5leHBvcnQgY29uc3QgRGVudW5jaWFEZXRhaWxQYWdlOiBSZWFjdC5GQyA9ICgpID0+IHtcclxuICBjb25zdCB7IGlkIH0gPSB1c2VQYXJhbXM8eyBpZDogc3RyaW5nIH0+KCk7XHJcbiAgY29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpO1xyXG5cclxuICBjb25zdCB7IGRhdGE6IGRlbnVuY2lhLCBpc0xvYWRpbmcsIGlzRXJyb3IsIHJlZmV0Y2ggfSA9IHVzZURlbnVuY2lhRGV0YWxoZShpZCk7XHJcblxyXG4gIGNvbnN0IFttb2RhbERlc3BhY2hvQWJlcnRhLCBzZXRNb2RhbERlc3BhY2hvQWJlcnRhXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbbW9kYWxBcnF1aXZhbWVudG9BYmVydGEsIHNldE1vZGFsQXJxdWl2YW1lbnRvQWJlcnRhXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuXHJcbiAgaWYgKGlzTG9hZGluZykge1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTE2IHRleHQtY2VudGVyIHRleHQtc2xhdGUtNDAwIHRleHQteHMgZmxleCBmbGV4LWNvbCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXJcIj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctNiBoLTYgYm9yZGVyLTIgYm9yZGVyLXRlYWwtNTAwIGJvcmRlci10LXRyYW5zcGFyZW50IHJvdW5kZWQtZnVsbCBhbmltYXRlLXNwaW4gbWItM1wiIC8+XHJcbiAgICAgICAgPHNwYW4+Q2FycmVnYW5kbyBwcm9jZXNzbyBkZSBkZW7Dum5jaWEgc2FuaXTDoXJpYS4uLjwvc3Bhbj5cclxuICAgICAgPC9kaXY+XHJcbiAgICApO1xyXG4gIH1cclxuXHJcbiAgaWYgKGlzRXJyb3IgfHwgIWRlbnVuY2lhKSB7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtOCBiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC0yeGwgdGV4dC1jZW50ZXIgc3BhY2UteS00IG1heC13LXhsIG14LWF1dG8gbXQtOFwiPlxyXG4gICAgICAgIDxBbGVydFRyaWFuZ2xlIGNsYXNzTmFtZT1cInctMTAgaC0xMCB0ZXh0LXJvc2UtNTAwIG14LWF1dG9cIiAvPlxyXG4gICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGVcIj5cclxuICAgICAgICAgIERlbsO6bmNpYSBuw6NvIGVuY29udHJhZGEgb3UgaW5kaXNwb27DrXZlbFxyXG4gICAgICAgIDwvaDI+XHJcbiAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTUwMFwiPlxyXG4gICAgICAgICAgTsOjbyBmb2kgcG9zc8OtdmVsIGxvY2FsaXphciBvIHJlZ2lzdHJvIGRlc3RhIGRlbsO6bmNpYSBzYW5pdMOhcmlhLlxyXG4gICAgICAgIDwvcD5cclxuICAgICAgICA8TGlua1xyXG4gICAgICAgICAgdG89e1JPVVRFUy5PVVZJRE9SSUEuTElTVH1cclxuICAgICAgICAgIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHB4LTQgcHktMiB0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXRlYWwtNzAwIGJnLXRlYWwtNTAgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXRlYWwtMjAwIGhvdmVyOmJnLXRlYWwtMTAwXCJcclxuICAgICAgICA+XHJcbiAgICAgICAgICA8QXJyb3dMZWZ0IGNsYXNzTmFtZT1cInctMy41IGgtMy41XCIgLz5cclxuICAgICAgICAgIDxzcGFuPlZvbHRhciBwYXJhIGEgRmlsYTwvc3Bhbj5cclxuICAgICAgICA8L0xpbms+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgKTtcclxuICB9XHJcblxyXG4gIGNvbnN0IGVzdGFiID0gZGVudW5jaWEuZXN0YWJlbGVjaW1lbnRvO1xyXG4gIGNvbnN0IGlzQ29uY2x1aWRhID1cclxuICAgIGRlbnVuY2lhLnN0YXR1cyA9PT0gXCJhcnF1aXZhZGFcIiB8fFxyXG4gICAgZGVudW5jaWEuc3RhdHVzID09PSBcInByb2NlZGVudGVcIiB8fFxyXG4gICAgZGVudW5jaWEuc3RhdHVzID09PSBcImltcHJvY2VkZW50ZVwiIHx8XHJcbiAgICBkZW51bmNpYS5zdGF0dXMgPT09IFwiY29uY2x1aWRhXCI7XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNiBtYXgtdy01eGwgbXgtYXV0byBwYi0xMlwiPlxyXG4gICAgICB7LyogQmFycmEgZGUgTmF2ZWdhw6fDo28gU3VwZXJpb3IgKi99XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XHJcbiAgICAgICAgPExpbmtcclxuICAgICAgICAgIHRvPXtST1VURVMuT1VWSURPUklBLkxJU1R9XHJcbiAgICAgICAgICBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNjAwIGRhcms6dGV4dC1zbGF0ZS0zMDAgaG92ZXI6dGV4dC10ZWFsLTYwMCBkYXJrOmhvdmVyOnRleHQtdGVhbC00MDAgdHJhbnNpdGlvbi1jb2xvcnNcIlxyXG4gICAgICAgID5cclxuICAgICAgICAgIDxBcnJvd0xlZnQgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+XHJcbiAgICAgICAgICA8c3Bhbj5Wb2x0YXIgcGFyYSBHZXN0w6NvIGRlIERlbsO6bmNpYXM8L3NwYW4+XHJcbiAgICAgICAgPC9MaW5rPlxyXG5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICA8R3JhdmlkYWRlQmFkZ2UgZ3JhdmlkYWRlPXtkZW51bmNpYS5ncmF2aWRhZGV9IC8+XHJcbiAgICAgICAgICA8U3RhdHVzRGVudW5jaWFCYWRnZSBzdGF0dXM9e2RlbnVuY2lhLnN0YXR1c30gLz5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICB7LyogQ2FiZcOnYWxobyBkbyBQcm9jZXNzbyBkZSBPdXZpZG9yaWEgKi99XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGFyazpiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtODAwIHJvdW5kZWQtMnhsIHAtNiBzaGFkb3cteHMgc3BhY2UteS00XCI+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIHNtOmZsZXgtcm93IHNtOml0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTQgcGItNCBib3JkZXItYiBib3JkZXItc2xhdGUtMTAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMFwiPlxyXG4gICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiB0ZXh0LVsxMXB4XSBmb250LWJvbGQgdGV4dC10ZWFsLTYwMCBkYXJrOnRleHQtdGVhbC00MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCI+XHJcbiAgICAgICAgICAgICAgPHNwYW4+T3V2aWRvcmlhIFNhbml0w6FyaWE8L3NwYW4+XHJcbiAgICAgICAgICAgICAgPHNwYW4+4oCiPC9zcGFuPlxyXG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImNhcGl0YWxpemVcIj5cclxuICAgICAgICAgICAgICAgIENhbmFsOiB7ZGVudW5jaWEub3JpZ2VtLnJlcGxhY2UoL18vZywgXCIgXCIpfVxyXG4gICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGUgbXQtMC41XCI+XHJcbiAgICAgICAgICAgICAgUHJvdG9jb2xvOiB7ZGVudW5jaWEubnVtZXJvX3Byb3RvY29sb31cclxuICAgICAgICAgICAgPC9oMT5cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1yaWdodFwiPlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LXNsYXRlLTQwMCB1cHBlcmNhc2UgZm9udC1zZW1pYm9sZCBibG9ja1wiPlxyXG4gICAgICAgICAgICAgIERhdGEgZGUgUmVjZWJpbWVudG9cclxuICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0zMDBcIj5cclxuICAgICAgICAgICAgICB7bmV3IERhdGUoZGVudW5jaWEuZGF0YV9yZWNlYmltZW50bykudG9Mb2NhbGVTdHJpbmcoXCJwdC1CUlwiKX1cclxuICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIHsvKiBEZXNwYWNobyBBdHVhbCBkYSBDb29yZGVuYcOnw6NvIChzZSBob3V2ZXIpICovfVxyXG4gICAgICAgIHtkZW51bmNpYS5kZXNwYWNob19jb29yZGVuYWNhbyAmJiAoXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNCBiZy1pbmRpZ28tNTAvNzAgZGFyazpiZy1pbmRpZ28tOTUwLzMwIGJvcmRlciBib3JkZXItaW5kaWdvLTIwMCBkYXJrOmJvcmRlci1pbmRpZ28tODAwIHJvdW5kZWQteGwgdGV4dC14cyBzcGFjZS15LTFcIj5cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdXBwZXJjYXNlIGZvbnQtYm9sZCB0ZXh0LWluZGlnby05MDAgZGFyazp0ZXh0LWluZGlnby0zMDAgYmxvY2sgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNVwiPlxyXG4gICAgICAgICAgICAgIDxDbGlwYm9hcmRDaGVjayBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNVwiIC8+XHJcbiAgICAgICAgICAgICAgRGVzcGFjaG8gJiBFbmNhbWluaGFtZW50byBkYSBDb29yZGVuYcOnw6NvOlxyXG4gICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtaW5kaWdvLTk1MCBkYXJrOnRleHQtaW5kaWdvLTIwMCBsZWFkaW5nLXJlbGF4ZWQgZm9udC1tZWRpdW1cIj5cclxuICAgICAgICAgICAgICB7ZGVudW5jaWEuZGVzcGFjaG9fY29vcmRlbmFjYW99XHJcbiAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICl9XHJcblxyXG4gICAgICAgIHsvKiBDb25jbHVzw6NvIGRhIEFwdXJhw6fDo28gKHNlIGVuY2VycmFkYSkgKi99XHJcbiAgICAgICAge2RlbnVuY2lhLmNvbmNsdXNhb19hcHVyYWNhbyAmJiAoXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNCBiZy1zbGF0ZS01MCBkYXJrOmJnLXNsYXRlLTgwMC82MCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC14bCB0ZXh0LXhzIHNwYWNlLXktMVwiPlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB1cHBlcmNhc2UgZm9udC1ib2xkIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0zMDAgYmxvY2sgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNVwiPlxyXG4gICAgICAgICAgICAgIDxDaGVja0NpcmNsZTIgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjUgdGV4dC1lbWVyYWxkLTYwMFwiIC8+XHJcbiAgICAgICAgICAgICAgQ29uY2x1c8OjbyBkYSBBcHVyYcOnw6NvOlxyXG4gICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtODAwIGRhcms6dGV4dC1zbGF0ZS0yMDAgbGVhZGluZy1yZWxheGVkXCI+XHJcbiAgICAgICAgICAgICAge2RlbnVuY2lhLmNvbmNsdXNhb19hcHVyYWNhb31cclxuICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICB7ZGVudW5jaWEucmVzcG9zdGFfYW9fZGVudW5jaWFudGUgJiYgKFxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMiBwdC0yIGJvcmRlci10IGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtNzAwXCI+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB1cHBlcmNhc2UgZm9udC1ib2xkIHRleHQtc2xhdGUtNDAwIGJsb2NrXCI+XHJcbiAgICAgICAgICAgICAgICAgIFJlc3Bvc3RhIERpc3BvbmliaWxpemFkYSBhbyBDaWRhZMOjbzpcclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNjAwIGRhcms6dGV4dC1zbGF0ZS00MDAgaXRhbGljIHRleHQtWzExcHhdIG10LTAuNVwiPlxyXG4gICAgICAgICAgICAgICAgICBcIntkZW51bmNpYS5yZXNwb3N0YV9hb19kZW51bmNpYW50ZX1cIlxyXG4gICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICApfVxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgKX1cclxuXHJcbiAgICAgICAgey8qIEJhcnJhIGRlIEHDp8O1ZXMgUsOhcGlkYXMgKi99XHJcbiAgICAgICAgeyFpc0NvbmNsdWlkYSAmJiAoXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGl0ZW1zLWNlbnRlciBnYXAtMi41IHB0LTIgYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTEwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDBcIj5cclxuICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldE1vZGFsRGVzcGFjaG9BYmVydGEodHJ1ZSl9XHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNCBweS0yIHRleHQteHMgZm9udC1ib2xkIHRleHQtd2hpdGUgYmctdGVhbC02MDAgaG92ZXI6YmctdGVhbC03MDAgcm91bmRlZC14bCBzaGFkb3cteHMgaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgdHJhbnNpdGlvbi1jb2xvcnNcIlxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgPFNlbmQgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPlxyXG4gICAgICAgICAgICAgIDxzcGFuPkRlc3BhY2hhciBwYXJhIEZpc2NhbGl6YcOnw6NvPC9zcGFuPlxyXG4gICAgICAgICAgICA8L2J1dHRvbj5cclxuXHJcbiAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRNb2RhbEFycXVpdmFtZW50b0FiZXJ0YSh0cnVlKX1cclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC0zLjUgcHktMiB0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMjAwIGJnLXNsYXRlLTEwMCBkYXJrOmJnLXNsYXRlLTgwMCBob3ZlcjpiZy1zbGF0ZS0yMDAgZGFyazpob3ZlcjpiZy1zbGF0ZS03MDAgcm91bmRlZC14bCB0cmFuc2l0aW9uLWNvbG9ycyBpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNVwiXHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICA8QXJjaGl2ZSBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNVwiIC8+XHJcbiAgICAgICAgICAgICAgPHNwYW4+Q29uY2x1aXIgLyBBcnF1aXZhcjwvc3Bhbj5cclxuICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICApfVxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIHsvKiBSZWxhdG8gTWludWNpb3NvIGRvcyBGYXRvcyAqL31cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC0yeGwgcC02IHNoYWRvdy14cyBzcGFjZS15LTNcIj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHBiLTIgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTEwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDBcIj5cclxuICAgICAgICAgIDxGaWxlVGV4dCBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtdGVhbC02MDBcIiAvPlxyXG4gICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGVcIj5cclxuICAgICAgICAgICAgUmVsYXRvIE1pbnVjaW9zbyBkb3MgRmF0b3MgRGVudW5jaWFkb3NcclxuICAgICAgICAgIDwvaDI+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS04MDAgZGFyazp0ZXh0LXNsYXRlLTIwMCBsZWFkaW5nLXJlbGF4ZWQgd2hpdGVzcGFjZS1wcmUtbGluZSBiZy1zbGF0ZS01MC81MCBkYXJrOmJnLXNsYXRlLTgwMC8zMCBwLTQgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXNsYXRlLTEwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDBcIj5cclxuICAgICAgICAgIHtkZW51bmNpYS5yZWxhdG9fZGVudW5jaWEgfHwgXCJOZW5odW0gdGV4dG8gZGUgcmVsYXRvIGRldGFsaGFkbyBpbmZvcm1hZG8uXCJ9XHJcbiAgICAgICAgPC9wPlxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIHsvKiBMb2NhbCAvIEVzdGFiZWxlY2ltZW50byBEZW51bmNpYWRvICovfVxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIGRhcms6Ymctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLTJ4bCBwLTYgc2hhZG93LXhzIHNwYWNlLXktNFwiPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHBiLTIgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTEwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDBcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgPEJ1aWxkaW5nMiBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtdGVhbC02MDBcIiAvPlxyXG4gICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZVwiPlxyXG4gICAgICAgICAgICAgIExvY2FsIG91IEVzdGFiZWxlY2ltZW50byBBbHZvIGRhIERlbsO6bmNpYVxyXG4gICAgICAgICAgICA8L2gyPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICB7ZXN0YWIgJiYgKFxyXG4gICAgICAgICAgICA8TGlua1xyXG4gICAgICAgICAgICAgIHRvPXtST1VURVMuRVNUQUJFTEVDSU1FTlRPUy5ERVRBTEhFKGVzdGFiLmlkKX1cclxuICAgICAgICAgICAgICB0YXJnZXQ9XCJfYmxhbmtcIlxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXRlYWwtNjAwIGRhcms6dGV4dC10ZWFsLTQwMCBob3Zlcjp1bmRlcmxpbmUgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTFcIlxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgPHNwYW4+VmVyIFByb250dcOhcmlvIGRvIEVzdGFiZWxlY2ltZW50bzwvc3Bhbj5cclxuICAgICAgICAgICAgICA8RXh0ZXJuYWxMaW5rIGNsYXNzTmFtZT1cInctMyBoLTNcIiAvPlxyXG4gICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICApfVxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgc206Z3JpZC1jb2xzLTIgZ2FwLTQgdGV4dC14c1wiPlxyXG4gICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDAgdGV4dC1bMTBweF0gdXBwZXJjYXNlIGZvbnQtc2VtaWJvbGQgYmxvY2tcIj5cclxuICAgICAgICAgICAgICBJZGVudGlmaWNhw6fDo28gRGVjbGFyYWRhIHBlbG8gRGVudW5jaWFudGVcclxuICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlIHRleHQtc21cIj5cclxuICAgICAgICAgICAgICB7ZGVudW5jaWEubG9jYWxfZGVudW5jaWFkb19pZGVudGlmaWNhY2FvfVxyXG4gICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMCB0ZXh0LVsxMHB4XSB1cHBlcmNhc2UgZm9udC1zZW1pYm9sZCBibG9ja1wiPlxyXG4gICAgICAgICAgICAgIEJhaXJybyAvIFJlZ2nDo29cclxuICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJmb250LW1lZGl1bSB0ZXh0LXNsYXRlLTgwMCBkYXJrOnRleHQtc2xhdGUtMjAwXCI+XHJcbiAgICAgICAgICAgICAge2RlbnVuY2lhLmJhaXJybyB8fCBcIk7Do28gaW5mb3JtYWRvXCJ9XHJcbiAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS02MDAgZGFyazp0ZXh0LXNsYXRlLTMwMCBwdC0yIGJvcmRlci10IGJvcmRlci1zbGF0ZS0xMDAgZGFyazpib3JkZXItc2xhdGUtODAwIGZsZXggaXRlbXMtc3RhcnQgZ2FwLTEuNVwiPlxyXG4gICAgICAgICAgPE1hcFBpbiBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNSB0ZXh0LXNsYXRlLTQwMCBzaHJpbmstMCBtdC0wLjVcIiAvPlxyXG4gICAgICAgICAgPHNwYW4+XHJcbiAgICAgICAgICAgIDxzdHJvbmc+RW5kZXJlw6dvIEluZGljYWRvOjwvc3Ryb25nPiB7ZGVudW5jaWEubG9ncmFkb3VybyB8fCBcIkxvZ3JhZG91cm8gbsOjbyBpbmZvcm1hZG9cIn1cclxuICAgICAgICAgICAge2RlbnVuY2lhLm51bWVybyA/IGAsIE7CuiAke2RlbnVuY2lhLm51bWVyb31gIDogXCJcIn17XCIgXCJ9XHJcbiAgICAgICAgICAgIHtkZW51bmNpYS5wb250b19yZWZlcmVuY2lhICYmIGAoUmVmOiAke2RlbnVuY2lhLnBvbnRvX3JlZmVyZW5jaWF9KWB9XHJcbiAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgey8qIEF1dG9yaWEgZSBQcm90ZcOnw6NvIGRlIFNpZ2lsbyAqL31cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTJcIj5cclxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1zbGF0ZS01MDAgYmxvY2sgcHgtMVwiPlxyXG4gICAgICAgICAgSWRlbnRpZmljYcOnw6NvICYgUmVncmFzIGRlIFNpZ2lsbyBMZWdhbFxyXG4gICAgICAgIDwvc3Bhbj5cclxuICAgICAgICA8RGVudW5jaWFudGVDYXJkXHJcbiAgICAgICAgICBkZW51bmNpYW50ZUFub25pbW89e2RlbnVuY2lhLmRlbnVuY2lhbnRlX2Fub25pbW99XHJcbiAgICAgICAgICBub21lPXtkZW51bmNpYS5kZW51bmNpYW50ZV9ub21lfVxyXG4gICAgICAgICAgdGVsZWZvbmU9e2RlbnVuY2lhLmRlbnVuY2lhbnRlX3RlbGVmb25lfVxyXG4gICAgICAgICAgZW1haWw9e2RlbnVuY2lhLmRlbnVuY2lhbnRlX2VtYWlsfVxyXG4gICAgICAgIC8+XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgey8qIEV2aWTDqm5jaWFzIEZvdG9ncsOhZmljYXMgZSBBbmV4b3MgKi99XHJcbiAgICAgIHtkZW51bmNpYS51cmxfYW5leG9zX2V2aWRlbmNpYXMgJiYgZGVudW5jaWEudXJsX2FuZXhvc19ldmlkZW5jaWFzLmxlbmd0aCA+IDAgJiYgKFxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGFyazpiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtODAwIHJvdW5kZWQtMnhsIHAtNiBzaGFkb3cteHMgc3BhY2UteS0zXCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHBiLTIgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTEwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDBcIj5cclxuICAgICAgICAgICAgPEltYWdlSWNvbiBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtdGVhbC02MDBcIiAvPlxyXG4gICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZVwiPlxyXG4gICAgICAgICAgICAgIEFuZXhvcyAmIEV2aWTDqm5jaWFzIFN1Ym1ldGlkYXNcclxuICAgICAgICAgICAgPC9oMj5cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBzbTpncmlkLWNvbHMtMiBtZDpncmlkLWNvbHMtMyBnYXAtM1wiPlxyXG4gICAgICAgICAgICB7ZGVudW5jaWEudXJsX2FuZXhvc19ldmlkZW5jaWFzLm1hcCgoYW5leG8sIGlkeCkgPT4gKFxyXG4gICAgICAgICAgICAgIDxhXHJcbiAgICAgICAgICAgICAgICBrZXk9e2lkeH1cclxuICAgICAgICAgICAgICAgIGhyZWY9e2FuZXhvLnVybH1cclxuICAgICAgICAgICAgICAgIHRhcmdldD1cIl9ibGFua1wiXHJcbiAgICAgICAgICAgICAgICByZWw9XCJub3JlZmVycmVyXCJcclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMyBiZy1zbGF0ZS01MCBkYXJrOmJnLXNsYXRlLTgwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC14bCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gdGV4dC14cyBob3Zlcjpib3JkZXItdGVhbC01MDAgdHJhbnNpdGlvbi1jb2xvcnNcIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdHJ1bmNhdGVcIj5cclxuICAgICAgICAgICAgICAgICAgPEZpbGVUZXh0IGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC10ZWFsLTYwMCBzaHJpbmstMFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtIHRleHQtc2xhdGUtODAwIGRhcms6dGV4dC1zbGF0ZS0yMDAgdHJ1bmNhdGVcIj5cclxuICAgICAgICAgICAgICAgICAgICB7YW5leG8ubm9tZSB8fCBgRXZpZMOqbmNpYSAke2lkeCArIDF9YH1cclxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8RXh0ZXJuYWxMaW5rIGNsYXNzTmFtZT1cInctMy41IGgtMy41IHRleHQtc2xhdGUtNDAwIHNocmluay0wXCIgLz5cclxuICAgICAgICAgICAgICA8L2E+XHJcbiAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICl9XHJcblxyXG4gICAgICB7LyogTW9kYWlzIGRlIEHDp8OjbyAqL31cclxuICAgICAgPE1vZGFsRGVzcGFjaG9GaXNjYWxcclxuICAgICAgICBpc09wZW49e21vZGFsRGVzcGFjaG9BYmVydGF9XHJcbiAgICAgICAgb25DbG9zZT17KCkgPT4gc2V0TW9kYWxEZXNwYWNob0FiZXJ0YShmYWxzZSl9XHJcbiAgICAgICAgZGVudW5jaWFJZD17ZGVudW5jaWEuaWR9XHJcbiAgICAgICAgcHJvdG9jb2xvPXtkZW51bmNpYS5udW1lcm9fcHJvdG9jb2xvfVxyXG4gICAgICAgIGdyYXZpZGFkZUF0dWFsPXtkZW51bmNpYS5ncmF2aWRhZGV9XHJcbiAgICAgICAgb25TdWNlc3NvPXsoKSA9PiByZWZldGNoKCl9XHJcbiAgICAgIC8+XHJcblxyXG4gICAgICA8TW9kYWxBcnF1aXZhbWVudG9cclxuICAgICAgICBpc09wZW49e21vZGFsQXJxdWl2YW1lbnRvQWJlcnRhfVxyXG4gICAgICAgIG9uQ2xvc2U9eygpID0+IHNldE1vZGFsQXJxdWl2YW1lbnRvQWJlcnRhKGZhbHNlKX1cclxuICAgICAgICBkZW51bmNpYUlkPXtkZW51bmNpYS5pZH1cclxuICAgICAgICBwcm90b2NvbG89e2RlbnVuY2lhLm51bWVyb19wcm90b2NvbG99XHJcbiAgICAgICAgb25TdWNlc3NvPXsoKSA9PiByZWZldGNoKCl9XHJcbiAgICAgIC8+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgRGVudW5jaWFEZXRhaWxQYWdlO1xyXG4iXX0=