import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.tsx");const React = __vite__cjsImport0_react;const _jsxDEV = __vite__cjsImport28_react_jsxDevRuntime["jsxDEV"];/**
* Ponto de Entrada da Aplicação VigiMinas (App.tsx)
* Provedores centrais:
* 1. TanStack Query (QueryClientProvider v5) com cache inteligente
* 2. Provedor de Autenticação JWT e RBAC (AuthProvider)
* 3. Roteamento Declarativo Seguro (BrowserRouter, Routes, ProtectedRoute, AppLayout)
*/
import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=0fd2848a";
import { BrowserRouter, Navigate, Route, Routes } from "/node_modules/.vite/deps/react-router-dom.js?v=0fd2848a";
import { QueryClient, QueryClientProvider } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=0fd2848a";
import { ProtectedRoute } from "/src/components/ProtectedRoute.tsx";
import { ErrorBoundary, GlobalLoadingIndicator } from "/src/components/common/index.ts";
import { APP_CONFIG } from "/src/config/app.config.ts";
import { ROUTES } from "/src/config/routes.config.ts";
import { AuthProvider } from "/src/contexts/AuthContext.tsx";
import { AppLayout } from "/src/layouts/AppLayout.tsx";
import { DashboardPage } from "/src/pages/DashboardPage.tsx";
import { EstabelecimentosListPage } from "/src/pages/estabelecimentos/EstabelecimentosListPage.tsx";
import { EstabelecimentoDetailPage } from "/src/pages/estabelecimentos/EstabelecimentoDetailPage.tsx";
import { EstabelecimentoFormPage } from "/src/pages/estabelecimentos/EstabelecimentoFormPage.tsx";
import { InspecoesListPage } from "/src/pages/fiscalizacao/InspecoesListPage.tsx";
import { LaudoInspecaoFormPage } from "/src/pages/fiscalizacao/LaudoInspecaoFormPage.tsx";
import { PainelPrazosPage } from "/src/pages/fiscalizacao/PainelPrazosPage.tsx";
import { DashboardIndicadoresPage } from "/src/pages/indicadores/DashboardIndicadoresPage.tsx";
import { RelatorioSusPage } from "/src/pages/indicadores/RelatorioSusPage.tsx";
import { LicenciamentoPage } from "/src/pages/LicenciamentoPage.tsx";
import { RequerimentoDetailPage } from "/src/pages/licenciamento/RequerimentoDetailPage.tsx";
import { AlvaraViewPage } from "/src/pages/licenciamento/AlvaraViewPage.tsx";
import { ValidarAlvaraPublicPage } from "/src/pages/public/ValidarAlvaraPublicPage.tsx";
import { DenunciaPublicaPage } from "/src/pages/public/DenunciaPublicaPage.tsx";
import { LoginPage } from "/src/pages/LoginPage.tsx";
import { DenunciasListPage } from "/src/pages/ouvidoria/DenunciasListPage.tsx";
import { DenunciaDetailPage } from "/src/pages/ouvidoria/DenunciaDetailPage.tsx";
import { RegistrarDenunciaInternaPage } from "/src/pages/ouvidoria/RegistrarDenunciaInternaPage.tsx";
import { UsuariosPage } from "/src/pages/UsuariosPage.tsx";
var _jsxFileName = "E:/Projetos VSCODE/visa_braunas/src/App.tsx";
import __vite__cjsImport28_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=0fd2848a";
// Instância do QueryClient com configurações sensatas da Single Source of Truth
const queryClient = new QueryClient({ defaultOptions: { queries: {
	staleTime: APP_CONFIG.queryClient.defaultStaleTime,
	gcTime: APP_CONFIG.queryClient.defaultGcTime,
	refetchOnWindowFocus: APP_CONFIG.queryClient.refetchOnWindowFocus,
	retry: 1
} } });
export default function App() {
	return /* @__PURE__ */ _jsxDEV(ErrorBoundary, { children: /* @__PURE__ */ _jsxDEV(QueryClientProvider, {
		client: queryClient,
		children: /* @__PURE__ */ _jsxDEV(AuthProvider, { children: /* @__PURE__ */ _jsxDEV(BrowserRouter, { children: [/* @__PURE__ */ _jsxDEV(GlobalLoadingIndicator, {}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 57,
			columnNumber: 13
		}, this), /* @__PURE__ */ _jsxDEV(Routes, { children: [
			/* @__PURE__ */ _jsxDEV(Route, {
				path: ROUTES.AUTH.LOGIN,
				element: /* @__PURE__ */ _jsxDEV(LoginPage, {}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 61,
					columnNumber: 56
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 61,
				columnNumber: 15
			}, this),
			/* @__PURE__ */ _jsxDEV(Route, {
				path: ROUTES.PUBLIC.VALIDAR_ALVARA_PATH,
				element: /* @__PURE__ */ _jsxDEV(ValidarAlvaraPublicPage, {}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 64,
					columnNumber: 72
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 64,
				columnNumber: 15
			}, this),
			/* @__PURE__ */ _jsxDEV(Route, {
				path: ROUTES.PUBLIC.VALIDAR_ALVARA_BASE_PATH,
				element: /* @__PURE__ */ _jsxDEV(ValidarAlvaraPublicPage, {}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 65,
					columnNumber: 77
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 65,
				columnNumber: 15
			}, this),
			/* @__PURE__ */ _jsxDEV(Route, {
				path: ROUTES.PUBLIC.DENUNCIA_CIDADA_PATH,
				element: /* @__PURE__ */ _jsxDEV(DenunciaPublicaPage, {}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 68,
					columnNumber: 73
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 68,
				columnNumber: 15
			}, this),
			/* @__PURE__ */ _jsxDEV(Route, {
				element: /* @__PURE__ */ _jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ _jsxDEV(AppLayout, {}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 74,
					columnNumber: 21
				}, this) }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 73,
					columnNumber: 19
				}, this),
				children: [
					/* @__PURE__ */ _jsxDEV(Route, {
						index: true,
						element: /* @__PURE__ */ _jsxDEV(DashboardPage, {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 78,
							columnNumber: 39
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 78,
						columnNumber: 17
					}, this),
					/* @__PURE__ */ _jsxDEV(Route, {
						path: ROUTES.DASHBOARD_ALIAS.replace(/^\//, ""),
						element: /* @__PURE__ */ _jsxDEV(DashboardPage, {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 79,
							columnNumber: 82
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 79,
						columnNumber: 17
					}, this),
					/* @__PURE__ */ _jsxDEV(Route, {
						path: ROUTES.ESTABELECIMENTOS.LIST_PATH,
						element: /* @__PURE__ */ _jsxDEV(EstabelecimentosListPage, {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 82,
							columnNumber: 28
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 80,
						columnNumber: 17
					}, this),
					/* @__PURE__ */ _jsxDEV(Route, {
						path: ROUTES.ESTABELECIMENTOS.NOVO_PATH,
						element: /* @__PURE__ */ _jsxDEV(EstabelecimentoFormPage, {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 86,
							columnNumber: 28
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 84,
						columnNumber: 17
					}, this),
					/* @__PURE__ */ _jsxDEV(Route, {
						path: ROUTES.ESTABELECIMENTOS.DETALHE_PATH,
						element: /* @__PURE__ */ _jsxDEV(EstabelecimentoDetailPage, {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 90,
							columnNumber: 28
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 88,
						columnNumber: 17
					}, this),
					/* @__PURE__ */ _jsxDEV(Route, {
						path: ROUTES.ESTABELECIMENTOS.EDITAR_PATH,
						element: /* @__PURE__ */ _jsxDEV(EstabelecimentoFormPage, {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 94,
							columnNumber: 28
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 92,
						columnNumber: 17
					}, this),
					/* @__PURE__ */ _jsxDEV(Route, {
						path: ROUTES.INSPECOES.LIST_PATH,
						element: /* @__PURE__ */ _jsxDEV(ProtectedRoute, {
							allowedRoles: [
								"admin_master",
								"coordenador",
								"fiscal_tecnico"
							],
							children: /* @__PURE__ */ _jsxDEV(InspecoesListPage, {}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 106,
								columnNumber: 23
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 99,
							columnNumber: 21
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 96,
						columnNumber: 17
					}, this),
					/* @__PURE__ */ _jsxDEV(Route, {
						path: ROUTES.INSPECOES.LAUDO_PATH,
						element: /* @__PURE__ */ _jsxDEV(ProtectedRoute, {
							allowedRoles: [
								"admin_master",
								"coordenador",
								"fiscal_tecnico"
							],
							children: /* @__PURE__ */ _jsxDEV(LaudoInspecaoFormPage, {}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 120,
								columnNumber: 23
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 113,
							columnNumber: 21
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 110,
						columnNumber: 17
					}, this),
					/* @__PURE__ */ _jsxDEV(Route, {
						path: ROUTES.INSPECOES.PRAZOS_PATH,
						element: /* @__PURE__ */ _jsxDEV(ProtectedRoute, {
							allowedRoles: [
								"admin_master",
								"coordenador",
								"fiscal_tecnico"
							],
							children: /* @__PURE__ */ _jsxDEV(PainelPrazosPage, {}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 134,
								columnNumber: 23
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 127,
							columnNumber: 21
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 124,
						columnNumber: 17
					}, this),
					/* @__PURE__ */ _jsxDEV(Route, {
						path: ROUTES.LICENCIAMENTO.LIST_PATH,
						element: /* @__PURE__ */ _jsxDEV(LicenciamentoPage, {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 140,
							columnNumber: 28
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 138,
						columnNumber: 17
					}, this),
					/* @__PURE__ */ _jsxDEV(Route, {
						path: ROUTES.LICENCIAMENTO.REQUERIMENTOS_PATH,
						element: /* @__PURE__ */ _jsxDEV(LicenciamentoPage, {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 144,
							columnNumber: 28
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 142,
						columnNumber: 17
					}, this),
					/* @__PURE__ */ _jsxDEV(Route, {
						path: ROUTES.LICENCIAMENTO.REQUERIMENTO_DETALHE_PATH,
						element: /* @__PURE__ */ _jsxDEV(RequerimentoDetailPage, {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 148,
							columnNumber: 28
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 146,
						columnNumber: 17
					}, this),
					/* @__PURE__ */ _jsxDEV(Route, {
						path: ROUTES.LICENCIAMENTO.ALVARA_PATH,
						element: /* @__PURE__ */ _jsxDEV(AlvaraViewPage, {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 152,
							columnNumber: 28
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 150,
						columnNumber: 17
					}, this),
					/* @__PURE__ */ _jsxDEV(Route, {
						path: ROUTES.OUVIDORIA.LIST_PATH,
						element: /* @__PURE__ */ _jsxDEV(DenunciasListPage, {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 154,
							columnNumber: 67
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 154,
						columnNumber: 17
					}, this),
					/* @__PURE__ */ _jsxDEV(Route, {
						path: ROUTES.OUVIDORIA.NOVA_PATH,
						element: /* @__PURE__ */ _jsxDEV(RegistrarDenunciaInternaPage, {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 157,
							columnNumber: 28
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 155,
						columnNumber: 17
					}, this),
					/* @__PURE__ */ _jsxDEV(Route, {
						path: ROUTES.OUVIDORIA.DETALHE_PATH,
						element: /* @__PURE__ */ _jsxDEV(DenunciaDetailPage, {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 161,
							columnNumber: 28
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 159,
						columnNumber: 17
					}, this),
					/* @__PURE__ */ _jsxDEV(Route, {
						path: ROUTES.INDICADORES.DASHBOARD_PATH,
						element: /* @__PURE__ */ _jsxDEV(ProtectedRoute, {
							allowedRoles: [
								"admin_master",
								"coordenador",
								"fiscal_tecnico"
							],
							children: /* @__PURE__ */ _jsxDEV(DashboardIndicadoresPage, {}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 173,
								columnNumber: 23
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 166,
							columnNumber: 21
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 163,
						columnNumber: 17
					}, this),
					/* @__PURE__ */ _jsxDEV(Route, {
						path: ROUTES.RELATORIOS.SUS_PATH,
						element: /* @__PURE__ */ _jsxDEV(ProtectedRoute, {
							allowedRoles: ["admin_master", "coordenador"],
							children: /* @__PURE__ */ _jsxDEV(RelatorioSusPage, {}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 183,
								columnNumber: 23
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 180,
							columnNumber: 21
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 177,
						columnNumber: 17
					}, this),
					/* @__PURE__ */ _jsxDEV(Route, {
						path: ROUTES.RELATORIOS.SUS_ANO_PATH,
						element: /* @__PURE__ */ _jsxDEV(ProtectedRoute, {
							allowedRoles: ["admin_master", "coordenador"],
							children: /* @__PURE__ */ _jsxDEV(RelatorioSusPage, {}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 193,
								columnNumber: 23
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 190,
							columnNumber: 21
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 187,
						columnNumber: 17
					}, this),
					/* @__PURE__ */ _jsxDEV(Route, {
						path: ROUTES.USUARIOS.LIST_PATH,
						element: /* @__PURE__ */ _jsxDEV(ProtectedRoute, {
							allowedRoles: ["admin_master", "coordenador"],
							children: /* @__PURE__ */ _jsxDEV(UsuariosPage, {}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 204,
								columnNumber: 23
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 201,
							columnNumber: 21
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 198,
						columnNumber: 17
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 71,
				columnNumber: 15
			}, this),
			/* @__PURE__ */ _jsxDEV(Route, {
				path: "*",
				element: /* @__PURE__ */ _jsxDEV(Navigate, {
					to: ROUTES.DASHBOARD,
					replace: true
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 211,
					columnNumber: 40
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 211,
				columnNumber: 15
			}, this)
		] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 59,
			columnNumber: 13
		}, this)] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 55,
			columnNumber: 11
		}, this) }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 54,
			columnNumber: 9
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 53,
		columnNumber: 7
	}, this) }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 52,
		columnNumber: 5
	}, this);
}
_c = App;
var _c;
$RefreshReg$(_c, "App");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/App.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("E:/Projetos VSCODE/visa_braunas/src/App.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("E:/Projetos VSCODE/visa_braunas/src/App.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "E:/Projetos VSCODE/visa_braunas/src/App.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7Ozs7OztBQVFBLE9BQU8sV0FBVztBQUNsQixTQUFTLGVBQWUsVUFBVSxPQUFPLGNBQWM7QUFDdkQsU0FBUyxhQUFhLDJCQUEyQjtBQUNqRCxTQUFTLHNCQUFzQjtBQUMvQixTQUFTLGVBQWUsOEJBQThCO0FBQ3RELFNBQVMsa0JBQWtCO0FBQzNCLFNBQVMsY0FBYztBQUN2QixTQUFTLG9CQUFvQjtBQUM3QixTQUFTLGlCQUFpQjtBQUMxQixTQUFTLHFCQUFxQjtBQUM5QixTQUFTLGdDQUFnQztBQUN6QyxTQUFTLGlDQUFpQztBQUMxQyxTQUFTLCtCQUErQjtBQUN4QyxTQUFTLHlCQUF5QjtBQUNsQyxTQUFTLDZCQUE2QjtBQUN0QyxTQUFTLHdCQUF3QjtBQUNqQyxTQUFTLGdDQUFnQztBQUN6QyxTQUFTLHdCQUF3QjtBQUNqQyxTQUFTLHlCQUF5QjtBQUNsQyxTQUFTLDhCQUE4QjtBQUN2QyxTQUFTLHNCQUFzQjtBQUMvQixTQUFTLCtCQUErQjtBQUN4QyxTQUFTLDJCQUEyQjtBQUNwQyxTQUFTLGlCQUFpQjtBQUMxQixTQUFTLHlCQUF5QjtBQUNsQyxTQUFTLDBCQUEwQjtBQUNuQyxTQUFTLG9DQUFvQztBQUM3QyxTQUFTLG9CQUFvQjs7OztBQUc3QixNQUFNLGNBQWMsSUFBSSxZQUFZLEVBQ2xDLGdCQUFnQixFQUNkLFNBQVM7Q0FDUCxXQUFXLFdBQVcsWUFBWTtDQUNsQyxRQUFRLFdBQVcsWUFBWTtDQUMvQixzQkFBc0IsV0FBVyxZQUFZO0NBQzdDLE9BQU87QUFDVCxFQUNGLEVBQ0YsQ0FBQztBQUVELGVBQWUsU0FBUyxNQUFNO0NBQzVCLE9BQ0Usd0JBQUMsZUFBRCxZQUNFLHdCQUFDLHFCQUFEO0VBQXFCLFFBQVE7WUFDM0Isd0JBQUMsY0FBRCxZQUNFLHdCQUFDLGVBQUQsYUFFRSx3QkFBQyx3QkFBRCxDQUF5Qjs7OztZQUV6Qix3QkFBQyxRQUFEO0dBRUUsd0JBQUMsT0FBRDtJQUFPLE1BQU0sT0FBTyxLQUFLO0lBQU8sU0FBUyx3QkFBQyxXQUFELENBQVk7Ozs7O0dBQUk7Ozs7O0dBR3pELHdCQUFDLE9BQUQ7SUFBTyxNQUFNLE9BQU8sT0FBTztJQUFxQixTQUFTLHdCQUFDLHlCQUFELENBQTBCOzs7OztHQUFJOzs7OztHQUN2Rix3QkFBQyxPQUFEO0lBQU8sTUFBTSxPQUFPLE9BQU87SUFBMEIsU0FBUyx3QkFBQyx5QkFBRCxDQUEwQjs7Ozs7R0FBSTs7Ozs7R0FHNUYsd0JBQUMsT0FBRDtJQUFPLE1BQU0sT0FBTyxPQUFPO0lBQXNCLFNBQVMsd0JBQUMscUJBQUQsQ0FBc0I7Ozs7O0dBQUk7Ozs7O0dBR3BGLHdCQUFDLE9BQUQ7SUFDRSxTQUNFLHdCQUFDLGdCQUFELFlBQ0Usd0JBQUMsV0FBRCxDQUFZOzs7O2FBQ0U7Ozs7O2NBSnBCO0tBT0Usd0JBQUMsT0FBRDtNQUFPO01BQU0sU0FBUyx3QkFBQyxlQUFELENBQWdCOzs7OztLQUFJOzs7OztLQUMxQyx3QkFBQyxPQUFEO01BQU8sTUFBTSxPQUFPLGdCQUFnQixRQUFRLE9BQU8sRUFBRTtNQUFHLFNBQVMsd0JBQUMsZUFBRCxDQUFnQjs7Ozs7S0FBSTs7Ozs7S0FDckYsd0JBQUMsT0FBRDtNQUNFLE1BQU0sT0FBTyxpQkFBaUI7TUFDOUIsU0FBUyx3QkFBQywwQkFBRCxDQUEyQjs7Ozs7S0FDckM7Ozs7O0tBQ0Qsd0JBQUMsT0FBRDtNQUNFLE1BQU0sT0FBTyxpQkFBaUI7TUFDOUIsU0FBUyx3QkFBQyx5QkFBRCxDQUEwQjs7Ozs7S0FDcEM7Ozs7O0tBQ0Qsd0JBQUMsT0FBRDtNQUNFLE1BQU0sT0FBTyxpQkFBaUI7TUFDOUIsU0FBUyx3QkFBQywyQkFBRCxDQUE0Qjs7Ozs7S0FDdEM7Ozs7O0tBQ0Qsd0JBQUMsT0FBRDtNQUNFLE1BQU0sT0FBTyxpQkFBaUI7TUFDOUIsU0FBUyx3QkFBQyx5QkFBRCxDQUEwQjs7Ozs7S0FDcEM7Ozs7O0tBQ0Qsd0JBQUMsT0FBRDtNQUNFLE1BQU0sT0FBTyxVQUFVO01BQ3ZCLFNBQ0Usd0JBQUMsZ0JBQUQ7T0FDRSxjQUFjO1FBQ1o7UUFDQTtRQUNBO09BQ0Y7aUJBRUEsd0JBQUMsbUJBQUQsQ0FBb0I7Ozs7O01BQ047Ozs7O0tBRW5COzs7OztLQUNELHdCQUFDLE9BQUQ7TUFDRSxNQUFNLE9BQU8sVUFBVTtNQUN2QixTQUNFLHdCQUFDLGdCQUFEO09BQ0UsY0FBYztRQUNaO1FBQ0E7UUFDQTtPQUNGO2lCQUVBLHdCQUFDLHVCQUFELENBQXdCOzs7OztNQUNWOzs7OztLQUVuQjs7Ozs7S0FDRCx3QkFBQyxPQUFEO01BQ0UsTUFBTSxPQUFPLFVBQVU7TUFDdkIsU0FDRSx3QkFBQyxnQkFBRDtPQUNFLGNBQWM7UUFDWjtRQUNBO1FBQ0E7T0FDRjtpQkFFQSx3QkFBQyxrQkFBRCxDQUFtQjs7Ozs7TUFDTDs7Ozs7S0FFbkI7Ozs7O0tBQ0Qsd0JBQUMsT0FBRDtNQUNFLE1BQU0sT0FBTyxjQUFjO01BQzNCLFNBQVMsd0JBQUMsbUJBQUQsQ0FBb0I7Ozs7O0tBQzlCOzs7OztLQUNELHdCQUFDLE9BQUQ7TUFDRSxNQUFNLE9BQU8sY0FBYztNQUMzQixTQUFTLHdCQUFDLG1CQUFELENBQW9COzs7OztLQUM5Qjs7Ozs7S0FDRCx3QkFBQyxPQUFEO01BQ0UsTUFBTSxPQUFPLGNBQWM7TUFDM0IsU0FBUyx3QkFBQyx3QkFBRCxDQUF5Qjs7Ozs7S0FDbkM7Ozs7O0tBQ0Qsd0JBQUMsT0FBRDtNQUNFLE1BQU0sT0FBTyxjQUFjO01BQzNCLFNBQVMsd0JBQUMsZ0JBQUQsQ0FBaUI7Ozs7O0tBQzNCOzs7OztLQUNELHdCQUFDLE9BQUQ7TUFBTyxNQUFNLE9BQU8sVUFBVTtNQUFXLFNBQVMsd0JBQUMsbUJBQUQsQ0FBb0I7Ozs7O0tBQUk7Ozs7O0tBQzFFLHdCQUFDLE9BQUQ7TUFDRSxNQUFNLE9BQU8sVUFBVTtNQUN2QixTQUFTLHdCQUFDLDhCQUFELENBQStCOzs7OztLQUN6Qzs7Ozs7S0FDRCx3QkFBQyxPQUFEO01BQ0UsTUFBTSxPQUFPLFVBQVU7TUFDdkIsU0FBUyx3QkFBQyxvQkFBRCxDQUFxQjs7Ozs7S0FDL0I7Ozs7O0tBQ0Qsd0JBQUMsT0FBRDtNQUNFLE1BQU0sT0FBTyxZQUFZO01BQ3pCLFNBQ0Usd0JBQUMsZ0JBQUQ7T0FDRSxjQUFjO1FBQ1o7UUFDQTtRQUNBO09BQ0Y7aUJBRUEsd0JBQUMsMEJBQUQsQ0FBMkI7Ozs7O01BQ2I7Ozs7O0tBRW5COzs7OztLQUNELHdCQUFDLE9BQUQ7TUFDRSxNQUFNLE9BQU8sV0FBVztNQUN4QixTQUNFLHdCQUFDLGdCQUFEO09BQ0UsY0FBYyxDQUFDLGdCQUFnQixhQUFhO2lCQUU1Qyx3QkFBQyxrQkFBRCxDQUFtQjs7Ozs7TUFDTDs7Ozs7S0FFbkI7Ozs7O0tBQ0Qsd0JBQUMsT0FBRDtNQUNFLE1BQU0sT0FBTyxXQUFXO01BQ3hCLFNBQ0Usd0JBQUMsZ0JBQUQ7T0FDRSxjQUFjLENBQUMsZ0JBQWdCLGFBQWE7aUJBRTVDLHdCQUFDLGtCQUFELENBQW1COzs7OztNQUNMOzs7OztLQUVuQjs7Ozs7S0FFRCx3QkFBQyxPQUFEO01BQ0UsTUFBTSxPQUFPLFNBQVM7TUFDdEIsU0FDRSx3QkFBQyxnQkFBRDtPQUNFLGNBQWMsQ0FBQyxnQkFBZ0IsYUFBYTtpQkFFNUMsd0JBQUMsY0FBRCxDQUFlOzs7OztNQUNEOzs7OztLQUVuQjs7Ozs7SUFDSTs7Ozs7O0dBR1Asd0JBQUMsT0FBRDtJQUFPLE1BQUs7SUFBSSxTQUFTLHdCQUFDLFVBQUQ7S0FBVSxJQUFJLE9BQU87S0FBVztJQUFTOzs7OztHQUFJOzs7OztFQUNoRTs7OztVQUNLOzs7O1dBQ0g7Ozs7O0NBQ0s7Ozs7VUFDUjs7Ozs7QUFFbkIiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiQXBwLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyIvKipcclxuICogUG9udG8gZGUgRW50cmFkYSBkYSBBcGxpY2HDp8OjbyBWaWdpTWluYXMgKEFwcC50c3gpXHJcbiAqIFByb3ZlZG9yZXMgY2VudHJhaXM6XHJcbiAqIDEuIFRhblN0YWNrIFF1ZXJ5IChRdWVyeUNsaWVudFByb3ZpZGVyIHY1KSBjb20gY2FjaGUgaW50ZWxpZ2VudGVcclxuICogMi4gUHJvdmVkb3IgZGUgQXV0ZW50aWNhw6fDo28gSldUIGUgUkJBQyAoQXV0aFByb3ZpZGVyKVxyXG4gKiAzLiBSb3RlYW1lbnRvIERlY2xhcmF0aXZvIFNlZ3VybyAoQnJvd3NlclJvdXRlciwgUm91dGVzLCBQcm90ZWN0ZWRSb3V0ZSwgQXBwTGF5b3V0KVxyXG4gKi9cclxuXHJcbmltcG9ydCBSZWFjdCBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHsgQnJvd3NlclJvdXRlciwgTmF2aWdhdGUsIFJvdXRlLCBSb3V0ZXMgfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xyXG5pbXBvcnQgeyBRdWVyeUNsaWVudCwgUXVlcnlDbGllbnRQcm92aWRlciB9IGZyb20gXCJAdGFuc3RhY2svcmVhY3QtcXVlcnlcIjtcclxuaW1wb3J0IHsgUHJvdGVjdGVkUm91dGUgfSBmcm9tIFwiLi9jb21wb25lbnRzL1Byb3RlY3RlZFJvdXRlXCI7XHJcbmltcG9ydCB7IEVycm9yQm91bmRhcnksIEdsb2JhbExvYWRpbmdJbmRpY2F0b3IgfSBmcm9tIFwiLi9jb21wb25lbnRzL2NvbW1vblwiO1xyXG5pbXBvcnQgeyBBUFBfQ09ORklHIH0gZnJvbSBcIi4vY29uZmlnL2FwcC5jb25maWdcIjtcclxuaW1wb3J0IHsgUk9VVEVTIH0gZnJvbSBcIi4vY29uZmlnL3JvdXRlcy5jb25maWdcIjtcclxuaW1wb3J0IHsgQXV0aFByb3ZpZGVyIH0gZnJvbSBcIi4vY29udGV4dHMvQXV0aENvbnRleHRcIjtcclxuaW1wb3J0IHsgQXBwTGF5b3V0IH0gZnJvbSBcIi4vbGF5b3V0cy9BcHBMYXlvdXRcIjtcclxuaW1wb3J0IHsgRGFzaGJvYXJkUGFnZSB9IGZyb20gXCIuL3BhZ2VzL0Rhc2hib2FyZFBhZ2VcIjtcclxuaW1wb3J0IHsgRXN0YWJlbGVjaW1lbnRvc0xpc3RQYWdlIH0gZnJvbSBcIi4vcGFnZXMvZXN0YWJlbGVjaW1lbnRvcy9Fc3RhYmVsZWNpbWVudG9zTGlzdFBhZ2VcIjtcclxuaW1wb3J0IHsgRXN0YWJlbGVjaW1lbnRvRGV0YWlsUGFnZSB9IGZyb20gXCIuL3BhZ2VzL2VzdGFiZWxlY2ltZW50b3MvRXN0YWJlbGVjaW1lbnRvRGV0YWlsUGFnZVwiO1xyXG5pbXBvcnQgeyBFc3RhYmVsZWNpbWVudG9Gb3JtUGFnZSB9IGZyb20gXCIuL3BhZ2VzL2VzdGFiZWxlY2ltZW50b3MvRXN0YWJlbGVjaW1lbnRvRm9ybVBhZ2VcIjtcclxuaW1wb3J0IHsgSW5zcGVjb2VzTGlzdFBhZ2UgfSBmcm9tIFwiLi9wYWdlcy9maXNjYWxpemFjYW8vSW5zcGVjb2VzTGlzdFBhZ2VcIjtcclxuaW1wb3J0IHsgTGF1ZG9JbnNwZWNhb0Zvcm1QYWdlIH0gZnJvbSBcIi4vcGFnZXMvZmlzY2FsaXphY2FvL0xhdWRvSW5zcGVjYW9Gb3JtUGFnZVwiO1xyXG5pbXBvcnQgeyBQYWluZWxQcmF6b3NQYWdlIH0gZnJvbSBcIi4vcGFnZXMvZmlzY2FsaXphY2FvL1BhaW5lbFByYXpvc1BhZ2VcIjtcclxuaW1wb3J0IHsgRGFzaGJvYXJkSW5kaWNhZG9yZXNQYWdlIH0gZnJvbSBcIi4vcGFnZXMvaW5kaWNhZG9yZXMvRGFzaGJvYXJkSW5kaWNhZG9yZXNQYWdlXCI7XHJcbmltcG9ydCB7IFJlbGF0b3Jpb1N1c1BhZ2UgfSBmcm9tIFwiLi9wYWdlcy9pbmRpY2Fkb3Jlcy9SZWxhdG9yaW9TdXNQYWdlXCI7XHJcbmltcG9ydCB7IExpY2VuY2lhbWVudG9QYWdlIH0gZnJvbSBcIi4vcGFnZXMvTGljZW5jaWFtZW50b1BhZ2VcIjtcclxuaW1wb3J0IHsgUmVxdWVyaW1lbnRvRGV0YWlsUGFnZSB9IGZyb20gXCIuL3BhZ2VzL2xpY2VuY2lhbWVudG8vUmVxdWVyaW1lbnRvRGV0YWlsUGFnZVwiO1xyXG5pbXBvcnQgeyBBbHZhcmFWaWV3UGFnZSB9IGZyb20gXCIuL3BhZ2VzL2xpY2VuY2lhbWVudG8vQWx2YXJhVmlld1BhZ2VcIjtcclxuaW1wb3J0IHsgVmFsaWRhckFsdmFyYVB1YmxpY1BhZ2UgfSBmcm9tIFwiLi9wYWdlcy9wdWJsaWMvVmFsaWRhckFsdmFyYVB1YmxpY1BhZ2VcIjtcclxuaW1wb3J0IHsgRGVudW5jaWFQdWJsaWNhUGFnZSB9IGZyb20gXCIuL3BhZ2VzL3B1YmxpYy9EZW51bmNpYVB1YmxpY2FQYWdlXCI7XHJcbmltcG9ydCB7IExvZ2luUGFnZSB9IGZyb20gXCIuL3BhZ2VzL0xvZ2luUGFnZVwiO1xyXG5pbXBvcnQgeyBEZW51bmNpYXNMaXN0UGFnZSB9IGZyb20gXCIuL3BhZ2VzL291dmlkb3JpYS9EZW51bmNpYXNMaXN0UGFnZVwiO1xyXG5pbXBvcnQgeyBEZW51bmNpYURldGFpbFBhZ2UgfSBmcm9tIFwiLi9wYWdlcy9vdXZpZG9yaWEvRGVudW5jaWFEZXRhaWxQYWdlXCI7XHJcbmltcG9ydCB7IFJlZ2lzdHJhckRlbnVuY2lhSW50ZXJuYVBhZ2UgfSBmcm9tIFwiLi9wYWdlcy9vdXZpZG9yaWEvUmVnaXN0cmFyRGVudW5jaWFJbnRlcm5hUGFnZVwiO1xyXG5pbXBvcnQgeyBVc3Vhcmlvc1BhZ2UgfSBmcm9tIFwiLi9wYWdlcy9Vc3Vhcmlvc1BhZ2VcIjtcclxuXHJcbi8vIEluc3TDom5jaWEgZG8gUXVlcnlDbGllbnQgY29tIGNvbmZpZ3VyYcOnw7VlcyBzZW5zYXRhcyBkYSBTaW5nbGUgU291cmNlIG9mIFRydXRoXHJcbmNvbnN0IHF1ZXJ5Q2xpZW50ID0gbmV3IFF1ZXJ5Q2xpZW50KHtcclxuICBkZWZhdWx0T3B0aW9uczoge1xyXG4gICAgcXVlcmllczoge1xyXG4gICAgICBzdGFsZVRpbWU6IEFQUF9DT05GSUcucXVlcnlDbGllbnQuZGVmYXVsdFN0YWxlVGltZSxcclxuICAgICAgZ2NUaW1lOiBBUFBfQ09ORklHLnF1ZXJ5Q2xpZW50LmRlZmF1bHRHY1RpbWUsXHJcbiAgICAgIHJlZmV0Y2hPbldpbmRvd0ZvY3VzOiBBUFBfQ09ORklHLnF1ZXJ5Q2xpZW50LnJlZmV0Y2hPbldpbmRvd0ZvY3VzLFxyXG4gICAgICByZXRyeTogMSxcclxuICAgIH0sXHJcbiAgfSxcclxufSk7XHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBBcHAoKSB7XHJcbiAgcmV0dXJuIChcclxuICAgIDxFcnJvckJvdW5kYXJ5PlxyXG4gICAgICA8UXVlcnlDbGllbnRQcm92aWRlciBjbGllbnQ9e3F1ZXJ5Q2xpZW50fT5cclxuICAgICAgICA8QXV0aFByb3ZpZGVyPlxyXG4gICAgICAgICAgPEJyb3dzZXJSb3V0ZXI+XHJcbiAgICAgICAgICAgIHsvKiBJbmRpY2Fkb3IgR2xvYmFsIGRlIENhcnJlZ2FtZW50byBIVFRQIChBeGlvcyAvIFRhblN0YWNrIFF1ZXJ5KSAqL31cclxuICAgICAgICAgICAgPEdsb2JhbExvYWRpbmdJbmRpY2F0b3IgLz5cclxuXHJcbiAgICAgICAgICAgIDxSb3V0ZXM+XHJcbiAgICAgICAgICAgICAgey8qIFJvdGEgUMO6YmxpY2EgZGUgQXV0ZW50aWNhw6fDo28gKi99XHJcbiAgICAgICAgICAgICAgPFJvdXRlIHBhdGg9e1JPVVRFUy5BVVRILkxPR0lOfSBlbGVtZW50PXs8TG9naW5QYWdlIC8+fSAvPlxyXG5cclxuICAgICAgICAgICAgICB7LyogUm90YSBQw7pibGljYSBkZSBWYWxpZGHDp8OjbyBkZSBBdXRlbnRpY2lkYWRlIGRvIEFsdmFyw6EgKFFSIENvZGUpICovfVxyXG4gICAgICAgICAgICAgIDxSb3V0ZSBwYXRoPXtST1VURVMuUFVCTElDLlZBTElEQVJfQUxWQVJBX1BBVEh9IGVsZW1lbnQ9ezxWYWxpZGFyQWx2YXJhUHVibGljUGFnZSAvPn0gLz5cclxuICAgICAgICAgICAgICA8Um91dGUgcGF0aD17Uk9VVEVTLlBVQkxJQy5WQUxJREFSX0FMVkFSQV9CQVNFX1BBVEh9IGVsZW1lbnQ9ezxWYWxpZGFyQWx2YXJhUHVibGljUGFnZSAvPn0gLz5cclxuXHJcbiAgICAgICAgICAgICAgey8qIFJvdGEgUMO6YmxpY2EgZG8gQ2FuYWwgQ2lkYWTDo28gKFJlZ2lzdHJvIGUgQ29uc3VsdGEgZGUgRGVuw7puY2lhcyBTYW5pdMOhcmlhcykgKi99XHJcbiAgICAgICAgICAgICAgPFJvdXRlIHBhdGg9e1JPVVRFUy5QVUJMSUMuREVOVU5DSUFfQ0lEQURBX1BBVEh9IGVsZW1lbnQ9ezxEZW51bmNpYVB1YmxpY2FQYWdlIC8+fSAvPlxyXG5cclxuICAgICAgICAgICAgICB7LyogUm90YXMgUHJvdGVnaWRhcyBzb2IgbyBTaGVsbCBPcGVyYWNpb25hbCAoQXBwTGF5b3V0KSAqL31cclxuICAgICAgICAgICAgICA8Um91dGVcclxuICAgICAgICAgICAgICAgIGVsZW1lbnQ9e1xyXG4gICAgICAgICAgICAgICAgICA8UHJvdGVjdGVkUm91dGU+XHJcbiAgICAgICAgICAgICAgICAgICAgPEFwcExheW91dCAvPlxyXG4gICAgICAgICAgICAgICAgICA8L1Byb3RlY3RlZFJvdXRlPlxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIDxSb3V0ZSBpbmRleCBlbGVtZW50PXs8RGFzaGJvYXJkUGFnZSAvPn0gLz5cclxuICAgICAgICAgICAgICAgIDxSb3V0ZSBwYXRoPXtST1VURVMuREFTSEJPQVJEX0FMSUFTLnJlcGxhY2UoL15cXC8vLCBcIlwiKX0gZWxlbWVudD17PERhc2hib2FyZFBhZ2UgLz59IC8+XHJcbiAgICAgICAgICAgICAgICA8Um91dGVcclxuICAgICAgICAgICAgICAgICAgcGF0aD17Uk9VVEVTLkVTVEFCRUxFQ0lNRU5UT1MuTElTVF9QQVRIfVxyXG4gICAgICAgICAgICAgICAgICBlbGVtZW50PXs8RXN0YWJlbGVjaW1lbnRvc0xpc3RQYWdlIC8+fVxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDxSb3V0ZVxyXG4gICAgICAgICAgICAgICAgICBwYXRoPXtST1VURVMuRVNUQUJFTEVDSU1FTlRPUy5OT1ZPX1BBVEh9XHJcbiAgICAgICAgICAgICAgICAgIGVsZW1lbnQ9ezxFc3RhYmVsZWNpbWVudG9Gb3JtUGFnZSAvPn1cclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICA8Um91dGVcclxuICAgICAgICAgICAgICAgICAgcGF0aD17Uk9VVEVTLkVTVEFCRUxFQ0lNRU5UT1MuREVUQUxIRV9QQVRIfVxyXG4gICAgICAgICAgICAgICAgICBlbGVtZW50PXs8RXN0YWJlbGVjaW1lbnRvRGV0YWlsUGFnZSAvPn1cclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICA8Um91dGVcclxuICAgICAgICAgICAgICAgICAgcGF0aD17Uk9VVEVTLkVTVEFCRUxFQ0lNRU5UT1MuRURJVEFSX1BBVEh9XHJcbiAgICAgICAgICAgICAgICAgIGVsZW1lbnQ9ezxFc3RhYmVsZWNpbWVudG9Gb3JtUGFnZSAvPn1cclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICA8Um91dGVcclxuICAgICAgICAgICAgICAgICAgcGF0aD17Uk9VVEVTLklOU1BFQ09FUy5MSVNUX1BBVEh9XHJcbiAgICAgICAgICAgICAgICAgIGVsZW1lbnQ9e1xyXG4gICAgICAgICAgICAgICAgICAgIDxQcm90ZWN0ZWRSb3V0ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgYWxsb3dlZFJvbGVzPXtbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFwiYWRtaW5fbWFzdGVyXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFwiY29vcmRlbmFkb3JcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgXCJmaXNjYWxfdGVjbmljb1wiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgXX1cclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8SW5zcGVjb2VzTGlzdFBhZ2UgLz5cclxuICAgICAgICAgICAgICAgICAgICA8L1Byb3RlY3RlZFJvdXRlPlxyXG4gICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPFJvdXRlXHJcbiAgICAgICAgICAgICAgICAgIHBhdGg9e1JPVVRFUy5JTlNQRUNPRVMuTEFVRE9fUEFUSH1cclxuICAgICAgICAgICAgICAgICAgZWxlbWVudD17XHJcbiAgICAgICAgICAgICAgICAgICAgPFByb3RlY3RlZFJvdXRlXHJcbiAgICAgICAgICAgICAgICAgICAgICBhbGxvd2VkUm9sZXM9e1tcclxuICAgICAgICAgICAgICAgICAgICAgICAgXCJhZG1pbl9tYXN0ZXJcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgXCJjb29yZGVuYWRvclwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBcImZpc2NhbF90ZWNuaWNvXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICBdfVxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIDxMYXVkb0luc3BlY2FvRm9ybVBhZ2UgLz5cclxuICAgICAgICAgICAgICAgICAgICA8L1Byb3RlY3RlZFJvdXRlPlxyXG4gICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPFJvdXRlXHJcbiAgICAgICAgICAgICAgICAgIHBhdGg9e1JPVVRFUy5JTlNQRUNPRVMuUFJBWk9TX1BBVEh9XHJcbiAgICAgICAgICAgICAgICAgIGVsZW1lbnQ9e1xyXG4gICAgICAgICAgICAgICAgICAgIDxQcm90ZWN0ZWRSb3V0ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgYWxsb3dlZFJvbGVzPXtbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFwiYWRtaW5fbWFzdGVyXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFwiY29vcmRlbmFkb3JcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgXCJmaXNjYWxfdGVjbmljb1wiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgXX1cclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8UGFpbmVsUHJhem9zUGFnZSAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvUHJvdGVjdGVkUm91dGU+XHJcbiAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICA8Um91dGVcclxuICAgICAgICAgICAgICAgICAgcGF0aD17Uk9VVEVTLkxJQ0VOQ0lBTUVOVE8uTElTVF9QQVRIfVxyXG4gICAgICAgICAgICAgICAgICBlbGVtZW50PXs8TGljZW5jaWFtZW50b1BhZ2UgLz59XHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPFJvdXRlXHJcbiAgICAgICAgICAgICAgICAgIHBhdGg9e1JPVVRFUy5MSUNFTkNJQU1FTlRPLlJFUVVFUklNRU5UT1NfUEFUSH1cclxuICAgICAgICAgICAgICAgICAgZWxlbWVudD17PExpY2VuY2lhbWVudG9QYWdlIC8+fVxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDxSb3V0ZVxyXG4gICAgICAgICAgICAgICAgICBwYXRoPXtST1VURVMuTElDRU5DSUFNRU5UTy5SRVFVRVJJTUVOVE9fREVUQUxIRV9QQVRIfVxyXG4gICAgICAgICAgICAgICAgICBlbGVtZW50PXs8UmVxdWVyaW1lbnRvRGV0YWlsUGFnZSAvPn1cclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICA8Um91dGVcclxuICAgICAgICAgICAgICAgICAgcGF0aD17Uk9VVEVTLkxJQ0VOQ0lBTUVOVE8uQUxWQVJBX1BBVEh9XHJcbiAgICAgICAgICAgICAgICAgIGVsZW1lbnQ9ezxBbHZhcmFWaWV3UGFnZSAvPn1cclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICA8Um91dGUgcGF0aD17Uk9VVEVTLk9VVklET1JJQS5MSVNUX1BBVEh9IGVsZW1lbnQ9ezxEZW51bmNpYXNMaXN0UGFnZSAvPn0gLz5cclxuICAgICAgICAgICAgICAgIDxSb3V0ZVxyXG4gICAgICAgICAgICAgICAgICBwYXRoPXtST1VURVMuT1VWSURPUklBLk5PVkFfUEFUSH1cclxuICAgICAgICAgICAgICAgICAgZWxlbWVudD17PFJlZ2lzdHJhckRlbnVuY2lhSW50ZXJuYVBhZ2UgLz59XHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPFJvdXRlXHJcbiAgICAgICAgICAgICAgICAgIHBhdGg9e1JPVVRFUy5PVVZJRE9SSUEuREVUQUxIRV9QQVRIfVxyXG4gICAgICAgICAgICAgICAgICBlbGVtZW50PXs8RGVudW5jaWFEZXRhaWxQYWdlIC8+fVxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDxSb3V0ZVxyXG4gICAgICAgICAgICAgICAgICBwYXRoPXtST1VURVMuSU5ESUNBRE9SRVMuREFTSEJPQVJEX1BBVEh9XHJcbiAgICAgICAgICAgICAgICAgIGVsZW1lbnQ9e1xyXG4gICAgICAgICAgICAgICAgICAgIDxQcm90ZWN0ZWRSb3V0ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgYWxsb3dlZFJvbGVzPXtbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFwiYWRtaW5fbWFzdGVyXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFwiY29vcmRlbmFkb3JcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgXCJmaXNjYWxfdGVjbmljb1wiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgXX1cclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8RGFzaGJvYXJkSW5kaWNhZG9yZXNQYWdlIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9Qcm90ZWN0ZWRSb3V0ZT5cclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDxSb3V0ZVxyXG4gICAgICAgICAgICAgICAgICBwYXRoPXtST1VURVMuUkVMQVRPUklPUy5TVVNfUEFUSH1cclxuICAgICAgICAgICAgICAgICAgZWxlbWVudD17XHJcbiAgICAgICAgICAgICAgICAgICAgPFByb3RlY3RlZFJvdXRlXHJcbiAgICAgICAgICAgICAgICAgICAgICBhbGxvd2VkUm9sZXM9e1tcImFkbWluX21hc3RlclwiLCBcImNvb3JkZW5hZG9yXCJdfVxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIDxSZWxhdG9yaW9TdXNQYWdlIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9Qcm90ZWN0ZWRSb3V0ZT5cclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDxSb3V0ZVxyXG4gICAgICAgICAgICAgICAgICBwYXRoPXtST1VURVMuUkVMQVRPUklPUy5TVVNfQU5PX1BBVEh9XHJcbiAgICAgICAgICAgICAgICAgIGVsZW1lbnQ9e1xyXG4gICAgICAgICAgICAgICAgICAgIDxQcm90ZWN0ZWRSb3V0ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgYWxsb3dlZFJvbGVzPXtbXCJhZG1pbl9tYXN0ZXJcIiwgXCJjb29yZGVuYWRvclwiXX1cclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8UmVsYXRvcmlvU3VzUGFnZSAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvUHJvdGVjdGVkUm91dGU+XHJcbiAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIC8+XHJcblxyXG4gICAgICAgICAgICAgICAgPFJvdXRlXHJcbiAgICAgICAgICAgICAgICAgIHBhdGg9e1JPVVRFUy5VU1VBUklPUy5MSVNUX1BBVEh9XHJcbiAgICAgICAgICAgICAgICAgIGVsZW1lbnQ9e1xyXG4gICAgICAgICAgICAgICAgICAgIDxQcm90ZWN0ZWRSb3V0ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgYWxsb3dlZFJvbGVzPXtbXCJhZG1pbl9tYXN0ZXJcIiwgXCJjb29yZGVuYWRvclwiXX1cclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8VXN1YXJpb3NQYWdlIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9Qcm90ZWN0ZWRSb3V0ZT5cclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICA8L1JvdXRlPlxyXG5cclxuICAgICAgICAgICAgICB7LyogUm90YSBkZSBGYWxsYmFjayBwYXJhIHJlZGlyZWNpb25hciBjYW1pbmhvcyBuw6NvIHJlY29uaGVjaWRvcyAqL31cclxuICAgICAgICAgICAgICA8Um91dGUgcGF0aD1cIipcIiBlbGVtZW50PXs8TmF2aWdhdGUgdG89e1JPVVRFUy5EQVNIQk9BUkR9IHJlcGxhY2UgLz59IC8+XHJcbiAgICAgICAgICAgIDwvUm91dGVzPlxyXG4gICAgICAgICAgPC9Ccm93c2VyUm91dGVyPlxyXG4gICAgICAgIDwvQXV0aFByb3ZpZGVyPlxyXG4gICAgICA8L1F1ZXJ5Q2xpZW50UHJvdmlkZXI+XHJcbiAgICA8L0Vycm9yQm91bmRhcnk+XHJcbiAgKTtcclxufVxyXG4iXX0=