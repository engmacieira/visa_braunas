import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/public/ValidarAlvaraPublicPage.tsx");const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport7_react_jsxDevRuntime["jsxDEV"];/**
* Página Pública de Validação e Consulta de Autenticidade de Alvará Sanitário
* Rota: /validar-alvara/:codigo
* Acessada por cidadãos e fiscais ao escanear o QR Code impresso no documento oficial.
* Não exige autenticação JWT.
*/
import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=0fd2848a";
import { useParams, useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=0fd2848a";
import { AlertTriangle, Building2, Calendar, CheckCircle2, Clock, QrCode, Search, Shield, ShieldAlert, XCircle } from "/node_modules/.vite/deps/lucide-react.js?v=0fd2848a";
import { APP_CONFIG } from "/src/config/app.config.ts";
import { ROUTES } from "/src/config/routes.config.ts";
import { useValidarAlvaraPublico } from "/src/hooks/useLicenciamento.ts";
import { RiscoBadge } from "/src/components/estabelecimentos/RiscoBadge.tsx";
var _jsxFileName = "E:/Projetos VSCODE/visa_braunas/src/pages/public/ValidarAlvaraPublicPage.tsx";
import __vite__cjsImport7_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=0fd2848a";
var _s = $RefreshSig$();
export const ValidarAlvaraPublicPage = () => {
	_s();
	const { codigo } = useParams();
	const navigate = useNavigate();
	const [inputCodigo, setInputCodigo] = useState(codigo || "");
	const { data: alvara, isLoading, isError, error, refetch } = useValidarAlvaraPublico(codigo);
	const handleBuscarNovoCodigo = (e) => {
		e.preventDefault();
		if (inputCodigo.trim()) {
			navigate(ROUTES.PUBLIC.VALIDAR_ALVARA(encodeURIComponent(inputCodigo.trim().toUpperCase())));
		}
	};
	const estab = alvara?.estabelecimento;
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col justify-between antialiased selection:bg-teal-500 selection:text-white",
		children: [
			/* @__PURE__ */ _jsxDEV("header", {
				className: "bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 shadow-2xs",
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: "max-w-3xl mx-auto px-4 py-4 flex items-center justify-between gap-3",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "w-10 h-10 rounded-xl bg-teal-600 text-white flex items-center justify-center font-bold shadow-xs",
							children: /* @__PURE__ */ _jsxDEV(Shield, { className: "w-5 h-5 text-white" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 61,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 60,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "text-[10px] font-bold text-slate-400 uppercase tracking-wider block",
							children: "Validação Oficial de Documentos"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 64,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("h1", {
							className: "text-sm font-bold text-slate-900 dark:text-white leading-tight",
							children: [
								"Vigilância Sanitária • ",
								APP_CONFIG.municipio,
								" / ",
								APP_CONFIG.uf
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 67,
							columnNumber: 15
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 63,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 59,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "hidden sm:flex items-center gap-1.5 text-xs text-slate-500 font-medium bg-slate-100 dark:bg-slate-800 px-2.5 py-1 rounded-lg",
						children: [/* @__PURE__ */ _jsxDEV(QrCode, { className: "w-3.5 h-3.5 text-teal-600" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 74,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Consulta Pública QR Code" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 75,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 73,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 58,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 57,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("main", {
				className: "max-w-2xl w-full mx-auto px-4 py-8 space-y-6",
				children: [
					/* @__PURE__ */ _jsxDEV("form", {
						onSubmit: handleBuscarNovoCodigo,
						className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-2.5 shadow-2xs flex items-center gap-2",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "relative flex-1",
							children: [/* @__PURE__ */ _jsxDEV(Search, { className: "w-4 h-4 text-slate-400 absolute left-3 top-2.5" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 88,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								type: "text",
								placeholder: "Digite o código de autenticidade (ex: A8B2C4D1-2026)...",
								value: inputCodigo,
								onChange: (e) => setInputCodigo(e.target.value.toUpperCase()),
								className: "w-full pl-9 pr-3 py-1.5 text-xs bg-transparent border-0 text-slate-900 dark:text-white placeholder-slate-400 font-mono focus:outline-none focus:ring-0 uppercase"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 89,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 87,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							type: "submit",
							className: "px-4 py-1.5 text-xs font-bold text-white bg-teal-600 hover:bg-teal-700 rounded-xl shadow-xs transition-colors shrink-0",
							children: "Consultar"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 97,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 83,
						columnNumber: 9
					}, this),
					isLoading && /* @__PURE__ */ _jsxDEV("div", {
						className: "p-16 text-center text-slate-400 text-xs flex flex-col items-center justify-center bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-xs",
						children: [
							/* @__PURE__ */ _jsxDEV("div", { className: "w-8 h-8 border-3 border-teal-500 border-t-transparent rounded-full animate-spin mb-3" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 108,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("span", {
								className: "font-semibold text-slate-700 dark:text-slate-300",
								children: "Validando autenticidade no banco de dados sanitário..."
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 109,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("span", {
								className: "text-[11px] text-slate-400 mt-1",
								children: ["Código verificado: ", codigo]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 112,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 107,
						columnNumber: 11
					}, this),
					!isLoading && (isError || !alvara) && /* @__PURE__ */ _jsxDEV("div", {
						className: "bg-white dark:bg-slate-900 border-2 border-rose-300 dark:border-rose-900/60 rounded-2xl p-6 sm:p-8 shadow-sm space-y-5 text-center",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "w-16 h-16 rounded-full bg-rose-50 dark:bg-rose-950/60 text-rose-600 border border-rose-200 dark:border-rose-800 flex items-center justify-center mx-auto",
								children: /* @__PURE__ */ _jsxDEV(XCircle, { className: "w-10 h-10" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 122,
									columnNumber: 15
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 121,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "space-y-1.5",
								children: [
									/* @__PURE__ */ _jsxDEV("span", {
										className: "inline-block px-3 py-1 text-[11px] font-bold rounded-full bg-rose-100 text-rose-800 dark:bg-rose-950/80 dark:text-rose-200 uppercase tracking-wider",
										children: "Documento Não Autêntico / Inválido"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 126,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("h2", {
										className: "text-lg font-black text-slate-900 dark:text-white",
										children: "Alvará Sanitário Não Localizado"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 129,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("p", {
										className: "text-xs text-slate-600 dark:text-slate-400 max-w-md mx-auto",
										children: [
											"O código de autenticidade informado (",
											/* @__PURE__ */ _jsxDEV("strong", { children: codigo || "---" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 133,
												columnNumber: 54
											}, this),
											") não consta nos registros oficiais da Vigilância Sanitária de ",
											APP_CONFIG.municipio,
											"/MG ou foi cancelado."
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 132,
										columnNumber: 15
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 125,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "p-4 bg-rose-50/60 dark:bg-rose-950/30 border border-rose-200 dark:border-rose-800/80 rounded-xl text-left text-xs text-rose-900 dark:text-rose-200 space-y-1",
								children: [/* @__PURE__ */ _jsxDEV("p", {
									className: "font-bold flex items-center gap-1.5",
									children: [/* @__PURE__ */ _jsxDEV(AlertTriangle, { className: "w-4 h-4 text-rose-600" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 139,
										columnNumber: 17
									}, this), "Atenção ao Cidadão e ao Consumidor:"]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 138,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("p", {
									className: "text-[11px] leading-relaxed text-rose-800 dark:text-rose-300",
									children: "Documentos impressos que não puderem ser validados neste portal oficial podem configurar falsificação ou exercício irregular de atividade econômica. Em caso de dúvidas, denuncie à Ouvidoria da Vigilância Sanitária."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 142,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 137,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 120,
						columnNumber: 11
					}, this),
					!isLoading && alvara && /* @__PURE__ */ _jsxDEV("div", {
						className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-sm overflow-hidden",
						children: [alvara.valido ? /* @__PURE__ */ _jsxDEV("div", {
							className: "p-6 bg-emerald-600 text-white text-center space-y-1",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "w-12 h-12 rounded-full bg-white/20 flex items-center justify-center mx-auto mb-2 backdrop-blur-xs",
									children: /* @__PURE__ */ _jsxDEV(CheckCircle2, { className: "w-8 h-8 text-white" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 156,
										columnNumber: 19
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 155,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("span", {
									className: "text-[11px] font-bold uppercase tracking-widest bg-white/20 px-3 py-0.5 rounded-full inline-block",
									children: "Documento Autêntico e Regular"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 158,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("h2", {
									className: "text-xl font-black tracking-wide",
									children: "ALVARÁ SANITÁRIO VÁLIDO"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 161,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("p", {
									className: "text-xs text-emerald-100",
									children: [
										"Emitido pela ",
										APP_CONFIG.prefeitura,
										" / ",
										APP_CONFIG.uf
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 164,
									columnNumber: 17
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 154,
							columnNumber: 15
						}, this) : /* @__PURE__ */ _jsxDEV("div", {
							className: "p-6 bg-rose-600 text-white text-center space-y-1",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "w-12 h-12 rounded-full bg-white/20 flex items-center justify-center mx-auto mb-2 backdrop-blur-xs",
									children: /* @__PURE__ */ _jsxDEV(ShieldAlert, { className: "w-8 h-8 text-white" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 171,
										columnNumber: 19
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 170,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("span", {
									className: "text-[11px] font-bold uppercase tracking-widest bg-white/20 px-3 py-0.5 rounded-full inline-block",
									children: "Situação Irregular"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 173,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("h2", {
									className: "text-xl font-black tracking-wide",
									children: "ALVARÁ SANITÁRIO VENCIDO / SUSPENSO"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 176,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("p", {
									className: "text-xs text-rose-100",
									children: alvara.motivo_status || "Validade expirada ou documento revogado"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 179,
									columnNumber: 17
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 169,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "p-6 space-y-6",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "grid grid-cols-1 sm:grid-cols-2 gap-4 pb-4 border-b border-slate-100 dark:border-slate-800",
									children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-[10px] text-slate-400 uppercase font-bold block",
										children: "Número do Alvará"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 190,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: "text-base font-black text-slate-900 dark:text-white",
										children: alvara.numero_formatado || `${alvara.numero_alvara}/${alvara.exercicio}`
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 193,
										columnNumber: 19
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 189,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-[10px] text-slate-400 uppercase font-bold block",
										children: "Código de Autenticidade"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 199,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: "text-base font-mono font-bold text-teal-700 dark:text-teal-400",
										children: alvara.codigo_autenticidade
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 202,
										columnNumber: 19
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 198,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 188,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "space-y-3",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center justify-between",
										children: [/* @__PURE__ */ _jsxDEV("span", {
											className: "text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5",
											children: [/* @__PURE__ */ _jsxDEV(Building2, { className: "w-3.5 h-3.5 text-teal-600" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 212,
												columnNumber: 21
											}, this), "Estabelecimento Licenciado"]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 211,
											columnNumber: 19
										}, this), estab?.nivel_risco && /* @__PURE__ */ _jsxDEV(RiscoBadge, { risco: estab.nivel_risco }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 215,
											columnNumber: 42
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 210,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "p-4 bg-slate-50 dark:bg-slate-800/50 rounded-xl space-y-2 text-xs",
										children: [
											/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
												className: "text-[10px] text-slate-400 uppercase font-semibold block",
												children: "Razão Social"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 220,
												columnNumber: 21
											}, this), /* @__PURE__ */ _jsxDEV("p", {
												className: "text-sm font-bold text-slate-900 dark:text-white",
												children: estab?.razao_social || "Estabelecimento Regular"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 221,
												columnNumber: 21
											}, this)] }, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 219,
												columnNumber: 19
											}, this),
											estab?.nome_fantasia && /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
												className: "text-[10px] text-slate-400 uppercase font-semibold block",
												children: "Nome Fantasia"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 228,
												columnNumber: 23
											}, this), /* @__PURE__ */ _jsxDEV("p", {
												className: "font-medium text-slate-800 dark:text-slate-200",
												children: estab.nome_fantasia
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 229,
												columnNumber: 23
											}, this)] }, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 227,
												columnNumber: 21
											}, this),
											/* @__PURE__ */ _jsxDEV("div", {
												className: "grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1 border-t border-slate-200/60 dark:border-slate-700/60",
												children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
													className: "text-[10px] text-slate-400 uppercase font-semibold block",
													children: "CNPJ / CPF"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 237,
													columnNumber: 23
												}, this), /* @__PURE__ */ _jsxDEV("p", {
													className: "font-mono font-medium text-slate-800 dark:text-slate-200",
													children: estab?.cnpj_cpf || "---"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 238,
													columnNumber: 23
												}, this)] }, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 236,
													columnNumber: 21
												}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
													className: "text-[10px] text-slate-400 uppercase font-semibold block",
													children: "Inscrição Municipal"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 244,
													columnNumber: 23
												}, this), /* @__PURE__ */ _jsxDEV("p", {
													className: "font-mono text-slate-700 dark:text-slate-300",
													children: estab?.inscricao_municipal || "Isento / Não Consta"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 245,
													columnNumber: 23
												}, this)] }, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 243,
													columnNumber: 21
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 235,
												columnNumber: 19
											}, this),
											/* @__PURE__ */ _jsxDEV("div", {
												className: "pt-1",
												children: [/* @__PURE__ */ _jsxDEV("span", {
													className: "text-[10px] text-slate-400 uppercase font-semibold block",
													children: "Endereço Autorizado"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 252,
													columnNumber: 21
												}, this), /* @__PURE__ */ _jsxDEV("p", {
													className: "text-slate-700 dark:text-slate-300 leading-snug",
													children: [
														estab?.logradouro || "Logradouro",
														", ",
														estab?.numero || "S/N",
														" ",
														estab?.complemento && `(${estab.complemento})`,
														" -",
														" ",
														estab?.bairro || "Centro",
														", ",
														estab?.municipio || APP_CONFIG.municipio,
														"/",
														estab?.uf || APP_CONFIG.uf
													]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 253,
													columnNumber: 21
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 251,
												columnNumber: 19
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 218,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 209,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "grid grid-cols-1 sm:grid-cols-2 gap-4",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "p-3 bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800 rounded-xl text-xs space-y-1",
										children: [/* @__PURE__ */ _jsxDEV("span", {
											className: "text-slate-400 text-[10px] uppercase font-bold block flex items-center gap-1",
											children: [/* @__PURE__ */ _jsxDEV(Calendar, { className: "w-3.5 h-3.5 text-teal-600" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 266,
												columnNumber: 21
											}, this), "Data de Emissão"]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 265,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("p", {
											className: "text-sm font-bold text-slate-900 dark:text-white",
											children: new Date(alvara.data_emissao).toLocaleDateString("pt-BR", { timeZone: "UTC" })
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 269,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 264,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: `p-3 border rounded-xl text-xs space-y-1 ${alvara.valido ? "bg-emerald-50 dark:bg-emerald-950/30 border-emerald-200 dark:border-emerald-800 text-emerald-950 dark:text-emerald-200" : "bg-rose-50 dark:bg-rose-950/30 border-rose-200 dark:border-rose-800 text-rose-950 dark:text-rose-200"}`,
										children: [
											/* @__PURE__ */ _jsxDEV("span", {
												className: "text-[10px] uppercase font-bold block flex items-center gap-1",
												children: [/* @__PURE__ */ _jsxDEV(Clock, { className: "w-3.5 h-3.5" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 282,
													columnNumber: 21
												}, this), "Data Limite de Validade"]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 281,
												columnNumber: 19
											}, this),
											/* @__PURE__ */ _jsxDEV("p", {
												className: "text-sm font-black",
												children: new Date(alvara.data_vencimento).toLocaleDateString("pt-BR", { timeZone: "UTC" })
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 285,
												columnNumber: 19
											}, this),
											alvara.dias_restantes_validade !== undefined && /* @__PURE__ */ _jsxDEV("span", {
												className: "text-[10px] font-semibold block",
												children: alvara.dias_restantes_validade >= 0 ? `Vigente por mais ${alvara.dias_restantes_validade} dia(s)` : `Vencido há ${Math.abs(alvara.dias_restantes_validade)} dia(s)`
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 289,
												columnNumber: 21
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 274,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 263,
									columnNumber: 15
								}, this),
								alvara.condicionantes_restricoes && /* @__PURE__ */ _jsxDEV("div", {
									className: "p-3 bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800 rounded-xl text-xs text-amber-900 dark:text-amber-200 space-y-1",
									children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-[10px] font-bold uppercase tracking-wider text-amber-800 dark:text-amber-300 block",
										children: "Condicionantes / Restrições Especiais:"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 301,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("p", {
										className: "text-[11px] leading-relaxed",
										children: alvara.condicionantes_restricoes
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 304,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 300,
									columnNumber: 17
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 186,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 151,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 81,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("footer", {
				className: "bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800 py-6 text-center text-xs text-slate-500",
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: "max-w-2xl mx-auto px-4 space-y-1",
					children: [
						/* @__PURE__ */ _jsxDEV("p", {
							className: "font-semibold text-slate-700 dark:text-slate-300",
							children: [
								APP_CONFIG.prefeitura,
								" • ",
								APP_CONFIG.secretaria
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 317,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("p", {
							className: "text-[11px] text-slate-400",
							children: [
								APP_CONFIG.orgao,
								" • Sistema ",
								APP_CONFIG.nome
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 320,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("p", {
							className: "text-[10px] text-slate-400 pt-2",
							children: [
								"Consulta pública em conformidade com o princípio da publicidade administrativa e Código Sanitário do ",
								APP_CONFIG.estadoExtenso,
								"."
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 323,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 316,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 315,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 55,
		columnNumber: 5
	}, this);
};
_s(ValidarAlvaraPublicPage, "rTLgwPyQXYt0rpnM2OFmBHQrITs=", false, function() {
	return [
		useParams,
		useNavigate,
		useValidarAlvaraPublico
	];
});
_c = ValidarAlvaraPublicPage;
export default ValidarAlvaraPublicPage;
var _c;
$RefreshReg$(_c, "ValidarAlvaraPublicPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/public/ValidarAlvaraPublicPage.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("E:/Projetos VSCODE/visa_braunas/src/pages/public/ValidarAlvaraPublicPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("E:/Projetos VSCODE/visa_braunas/src/pages/public/ValidarAlvaraPublicPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "E:/Projetos VSCODE/visa_braunas/src/pages/public/ValidarAlvaraPublicPage.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7Ozs7O0FBT0EsT0FBTyxTQUFTLGdCQUFnQjtBQUNoQyxTQUFTLFdBQVcsbUJBQW1CO0FBQ3ZDLFNBRUUsZUFFQSxXQUNBLFVBQ0EsY0FDQSxPQUVBLFFBQ0EsUUFDQSxRQUNBLGFBRUEsZUFDSztBQUNQLFNBQVMsa0JBQWtCO0FBQzNCLFNBQVMsY0FBYztBQUN2QixTQUFTLCtCQUErQjtBQUN4QyxTQUFTLGtCQUFrQjs7OztBQUUzQixPQUFPLE1BQU0sZ0NBQTBDOztDQUNyRCxNQUFNLEVBQUUsV0FBVyxVQUE4QjtDQUNqRCxNQUFNLFdBQVcsWUFBWTtDQUU3QixNQUFNLENBQUMsYUFBYSxrQkFBa0IsU0FBUyxVQUFVLEVBQUU7Q0FFM0QsTUFBTSxFQUNKLE1BQU0sUUFDTixXQUNBLFNBQ0EsT0FDQSxZQUNFLHdCQUF3QixNQUFNO0NBRWxDLE1BQU0sMEJBQTBCLE1BQXVCO0VBQ3JELEVBQUUsZUFBZTtFQUNqQixJQUFJLFlBQVksS0FBSyxHQUFHO0dBQ3RCLFNBQVMsT0FBTyxPQUFPLGVBQWUsbUJBQW1CLFlBQVksS0FBSyxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQztFQUM3RjtDQUNGO0NBRUEsTUFBTSxRQUFRLFFBQVE7Q0FFdEIsT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUFmO0dBRUUsd0JBQUMsVUFBRDtJQUFRLFdBQVU7Y0FDaEIsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQ2Isd0JBQUMsUUFBRCxFQUFRLFdBQVUscUJBQXNCOzs7OztNQUNyQzs7OztnQkFDTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsUUFBRDtPQUFNLFdBQVU7aUJBQXNFO01BRWhGOzs7O2dCQUNOLHdCQUFDLE1BQUQ7T0FBSSxXQUFVO2lCQUFkO1FBQStFO1FBQ3JELFdBQVc7UUFBVTtRQUFJLFdBQVc7T0FDMUQ7Ozs7O2NBQ0Q7Ozs7Y0FDRjs7Ozs7ZUFFTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLFFBQUQsRUFBUSxXQUFVLDRCQUE2Qjs7OztnQkFDL0Msd0JBQUMsUUFBRCxZQUFNLDJCQUE4Qjs7OztjQUNqQzs7Ozs7YUFDRjs7Ozs7O0dBQ0M7Ozs7O0dBR1Isd0JBQUMsUUFBRDtJQUFNLFdBQVU7Y0FBaEI7S0FFRSx3QkFBQyxRQUFEO01BQ0UsVUFBVTtNQUNWLFdBQVU7Z0JBRlosQ0FJRSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLFFBQUQsRUFBUSxXQUFVLGlEQUFrRDs7OztpQkFDcEUsd0JBQUMsU0FBRDtRQUNFLE1BQUs7UUFDTCxhQUFZO1FBQ1osT0FBTztRQUNQLFdBQVcsTUFBTSxlQUFlLEVBQUUsT0FBTyxNQUFNLFlBQVksQ0FBQztRQUM1RCxXQUFVO09BQ1g7Ozs7ZUFDRTs7Ozs7Z0JBQ0wsd0JBQUMsVUFBRDtPQUNFLE1BQUs7T0FDTCxXQUFVO2lCQUNYO01BRU87Ozs7Y0FDSjs7Ozs7O0tBR0wsYUFDQyx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZjtPQUNFLHdCQUFDLE9BQUQsRUFBSyxXQUFVLHVGQUF3Rjs7Ozs7T0FDdkcsd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQW1EO09BRTdEOzs7OztPQUNOLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUFoQixDQUFrRCx1QkFDNUIsTUFDaEI7Ozs7OztNQUNIOzs7Ozs7S0FJTixDQUFDLGNBQWMsV0FBVyxDQUFDLFdBQzFCLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmO09BQ0Usd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQ2Isd0JBQUMsU0FBRCxFQUFTLFdBQVUsWUFBYTs7Ozs7T0FDN0I7Ozs7O09BRUwsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWY7U0FDRSx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBc0o7U0FFaEs7Ozs7O1NBQ04sd0JBQUMsTUFBRDtVQUFJLFdBQVU7b0JBQW9EO1NBRTlEOzs7OztTQUNKLHdCQUFDLEtBQUQ7VUFBRyxXQUFVO29CQUFiO1dBQTJFO1dBQ3BDLHdCQUFDLFVBQUQsWUFBUyxVQUFVLE1BQWM7Ozs7O1dBQUM7V0FBZ0UsV0FBVztXQUFVO1VBQzNKOzs7Ozs7UUFDQTs7Ozs7O09BRUwsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxLQUFEO1NBQUcsV0FBVTttQkFBYixDQUNFLHdCQUFDLGVBQUQsRUFBZSxXQUFVLHdCQUF5Qjs7OzttQkFBQyxxQ0FFbEQ7Ozs7O2tCQUNILHdCQUFDLEtBQUQ7U0FBRyxXQUFVO21CQUErRDtRQUV6RTs7OztnQkFDQTs7Ozs7O01BQ0Y7Ozs7OztLQUlOLENBQUMsYUFBYSxVQUNiLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBRUcsT0FBTyxTQUNOLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmO1FBQ0Usd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQ2Isd0JBQUMsY0FBRCxFQUFjLFdBQVUscUJBQXNCOzs7OztRQUMzQzs7Ozs7UUFDTCx3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFBb0c7UUFFOUc7Ozs7O1FBQ04sd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQW1DO1FBRTdDOzs7OztRQUNKLHdCQUFDLEtBQUQ7U0FBRyxXQUFVO21CQUFiO1VBQXdDO1VBQ3hCLFdBQVc7VUFBVztVQUFJLFdBQVc7U0FDbEQ7Ozs7OztPQUNBOzs7OztpQkFFTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZjtRQUNFLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUNiLHdCQUFDLGFBQUQsRUFBYSxXQUFVLHFCQUFzQjs7Ozs7UUFDMUM7Ozs7O1FBQ0wsd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQW9HO1FBRTlHOzs7OztRQUNOLHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUFtQztRQUU3Qzs7Ozs7UUFDSix3QkFBQyxLQUFEO1NBQUcsV0FBVTttQkFDVixPQUFPLGlCQUFpQjtRQUN4Qjs7Ozs7T0FDQTs7Ozs7Z0JBSVAsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWY7UUFFRSx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBdUQ7U0FFakU7Ozs7bUJBQ04sd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQ2IsT0FBTyxvQkFBb0IsR0FBRyxPQUFPLGNBQWMsR0FBRyxPQUFPO1NBQzFEOzs7O2lCQUNIOzs7O21CQUVMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBdUQ7U0FFakU7Ozs7bUJBQ04sd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQ2IsT0FBTztTQUNKOzs7O2lCQUNIOzs7O2lCQUNGOzs7Ozs7UUFHTCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmLENBQ0Usd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQWhCLENBQ0Usd0JBQUMsV0FBRCxFQUFXLFdBQVUsNEJBQTZCOzs7O3FCQUFDLDRCQUUvQzs7Ozs7b0JBQ0wsT0FBTyxlQUFlLHdCQUFDLFlBQUQsRUFBWSxPQUFPLE1BQU0sWUFBYzs7OztrQkFDM0Q7Ozs7O21CQUVMLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmO1dBQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFFBQUQ7WUFBTSxXQUFVO3NCQUEyRDtXQUFrQjs7OztxQkFDN0Ysd0JBQUMsS0FBRDtZQUFHLFdBQVU7c0JBQ1YsT0FBTyxnQkFBZ0I7V0FDdkI7Ozs7bUJBQ0E7Ozs7O1dBRUosT0FBTyxpQkFDTix3QkFBQyxPQUFELGFBQ0Usd0JBQUMsUUFBRDtZQUFNLFdBQVU7c0JBQTJEO1dBQW1COzs7O3FCQUM5Rix3QkFBQyxLQUFEO1lBQUcsV0FBVTtzQkFDVixNQUFNO1dBQ047Ozs7bUJBQ0E7Ozs7O1dBR1Asd0JBQUMsT0FBRDtZQUFLLFdBQVU7c0JBQWYsQ0FDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsUUFBRDthQUFNLFdBQVU7dUJBQTJEO1lBQWdCOzs7O3NCQUMzRix3QkFBQyxLQUFEO2FBQUcsV0FBVTt1QkFDVixPQUFPLFlBQVk7WUFDbkI7Ozs7b0JBQ0E7Ozs7c0JBRUwsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFFBQUQ7YUFBTSxXQUFVO3VCQUEyRDtZQUF5Qjs7OztzQkFDcEcsd0JBQUMsS0FBRDthQUFHLFdBQVU7dUJBQ1YsT0FBTyx1QkFBdUI7WUFDOUI7Ozs7b0JBQ0E7Ozs7b0JBQ0Y7Ozs7OztXQUVMLHdCQUFDLE9BQUQ7WUFBSyxXQUFVO3NCQUFmLENBQ0Usd0JBQUMsUUFBRDthQUFNLFdBQVU7dUJBQTJEO1lBQXlCOzs7O3NCQUNwRyx3QkFBQyxLQUFEO2FBQUcsV0FBVTt1QkFBYjtjQUNHLE9BQU8sY0FBYztjQUFhO2NBQUcsT0FBTyxVQUFVO2NBQU87Y0FDN0QsT0FBTyxlQUFlLElBQUksTUFBTSxZQUFZO2NBQUc7Y0FBRztjQUNsRCxPQUFPLFVBQVU7Y0FBUztjQUFHLE9BQU8sYUFBYSxXQUFXO2NBQVU7Y0FBRSxPQUFPLE1BQU0sV0FBVzthQUNoRzs7Ozs7b0JBQ0E7Ozs7OztVQUNGOzs7OztpQkFDRjs7Ozs7O1FBR0wsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDRSx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNFLHdCQUFDLFFBQUQ7V0FBTSxXQUFVO3FCQUFoQixDQUNFLHdCQUFDLFVBQUQsRUFBVSxXQUFVLDRCQUE2Qjs7OztxQkFBQyxpQkFFOUM7Ozs7O29CQUNOLHdCQUFDLEtBQUQ7V0FBRyxXQUFVO3FCQUNWLElBQUksS0FBSyxPQUFPLFlBQVksQ0FBQyxDQUFDLG1CQUFtQixTQUFTLEVBQUUsVUFBVSxNQUFNLENBQUM7VUFDN0U7Ozs7a0JBQ0E7Ozs7O21CQUVMLHdCQUFDLE9BQUQ7VUFDRSxXQUFXLDJDQUNULE9BQU8sU0FDSCwySEFDQTtvQkFKUjtXQU9FLHdCQUFDLFFBQUQ7WUFBTSxXQUFVO3NCQUFoQixDQUNFLHdCQUFDLE9BQUQsRUFBTyxXQUFVLGNBQWU7Ozs7c0JBQUMseUJBRTdCOzs7Ozs7V0FDTix3QkFBQyxLQUFEO1lBQUcsV0FBVTtzQkFDVixJQUFJLEtBQUssT0FBTyxlQUFlLENBQUMsQ0FBQyxtQkFBbUIsU0FBUyxFQUFFLFVBQVUsTUFBTSxDQUFDO1dBQ2hGOzs7OztXQUNGLE9BQU8sNEJBQTRCLGFBQ2xDLHdCQUFDLFFBQUQ7WUFBTSxXQUFVO3NCQUNiLE9BQU8sMkJBQTJCLElBQy9CLG9CQUFvQixPQUFPLHdCQUF3QixXQUNuRCxjQUFjLEtBQUssSUFBSSxPQUFPLHVCQUF1QixFQUFFO1dBQ3ZEOzs7OztVQUVMOzs7OztpQkFDRjs7Ozs7O1FBR0osT0FBTyw2QkFDTix3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUEwRjtTQUVwRzs7OzttQkFDTix3QkFBQyxLQUFEO1VBQUcsV0FBVTtvQkFDVixPQUFPO1NBQ1A7Ozs7aUJBQ0E7Ozs7OztPQUVKOzs7OztjQUNGOzs7Ozs7SUFFSDs7Ozs7O0dBR04sd0JBQUMsVUFBRDtJQUFRLFdBQVU7Y0FDaEIsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZjtNQUNFLHdCQUFDLEtBQUQ7T0FBRyxXQUFVO2lCQUFiO1FBQ0csV0FBVztRQUFXO1FBQUksV0FBVztPQUNyQzs7Ozs7O01BQ0gsd0JBQUMsS0FBRDtPQUFHLFdBQVU7aUJBQWI7UUFDRyxXQUFXO1FBQU07UUFBWSxXQUFXO09BQ3hDOzs7Ozs7TUFDSCx3QkFBQyxLQUFEO09BQUcsV0FBVTtpQkFBYjtRQUErQztRQUN5RCxXQUFXO1FBQWM7T0FDOUg7Ozs7OztLQUNBOzs7Ozs7R0FDQzs7Ozs7RUFDTDs7Ozs7O0FBRVQ7Ozs7Ozs7OztBQUVBLGVBQWUiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiVmFsaWRhckFsdmFyYVB1YmxpY1BhZ2UudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbIi8qKlxyXG4gKiBQw6FnaW5hIFDDumJsaWNhIGRlIFZhbGlkYcOnw6NvIGUgQ29uc3VsdGEgZGUgQXV0ZW50aWNpZGFkZSBkZSBBbHZhcsOhIFNhbml0w6FyaW9cclxuICogUm90YTogL3ZhbGlkYXItYWx2YXJhLzpjb2RpZ29cclxuICogQWNlc3NhZGEgcG9yIGNpZGFkw6NvcyBlIGZpc2NhaXMgYW8gZXNjYW5lYXIgbyBRUiBDb2RlIGltcHJlc3NvIG5vIGRvY3VtZW50byBvZmljaWFsLlxyXG4gKiBOw6NvIGV4aWdlIGF1dGVudGljYcOnw6NvIEpXVC5cclxuICovXHJcblxyXG5pbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHsgdXNlUGFyYW1zLCB1c2VOYXZpZ2F0ZSB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCI7XHJcbmltcG9ydCB7XHJcbiAgQWxlcnRDaXJjbGUsXHJcbiAgQWxlcnRUcmlhbmdsZSxcclxuICBBd2FyZCxcclxuICBCdWlsZGluZzIsXHJcbiAgQ2FsZW5kYXIsXHJcbiAgQ2hlY2tDaXJjbGUyLFxyXG4gIENsb2NrLFxyXG4gIE1hcFBpbixcclxuICBRckNvZGUsXHJcbiAgU2VhcmNoLFxyXG4gIFNoaWVsZCxcclxuICBTaGllbGRBbGVydCxcclxuICBTaGllbGRDaGVjayxcclxuICBYQ2lyY2xlLFxyXG59IGZyb20gXCJsdWNpZGUtcmVhY3RcIjtcclxuaW1wb3J0IHsgQVBQX0NPTkZJRyB9IGZyb20gXCIuLi8uLi9jb25maWcvYXBwLmNvbmZpZ1wiO1xyXG5pbXBvcnQgeyBST1VURVMgfSBmcm9tIFwiLi4vLi4vY29uZmlnL3JvdXRlcy5jb25maWdcIjtcclxuaW1wb3J0IHsgdXNlVmFsaWRhckFsdmFyYVB1YmxpY28gfSBmcm9tIFwiLi4vLi4vaG9va3MvdXNlTGljZW5jaWFtZW50b1wiO1xyXG5pbXBvcnQgeyBSaXNjb0JhZGdlIH0gZnJvbSBcIi4uLy4uL2NvbXBvbmVudHMvZXN0YWJlbGVjaW1lbnRvcy9SaXNjb0JhZGdlXCI7XHJcblxyXG5leHBvcnQgY29uc3QgVmFsaWRhckFsdmFyYVB1YmxpY1BhZ2U6IFJlYWN0LkZDID0gKCkgPT4ge1xyXG4gIGNvbnN0IHsgY29kaWdvIH0gPSB1c2VQYXJhbXM8eyBjb2RpZ286IHN0cmluZyB9PigpO1xyXG4gIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKTtcclxuXHJcbiAgY29uc3QgW2lucHV0Q29kaWdvLCBzZXRJbnB1dENvZGlnb10gPSB1c2VTdGF0ZShjb2RpZ28gfHwgXCJcIik7XHJcblxyXG4gIGNvbnN0IHtcclxuICAgIGRhdGE6IGFsdmFyYSxcclxuICAgIGlzTG9hZGluZyxcclxuICAgIGlzRXJyb3IsXHJcbiAgICBlcnJvcixcclxuICAgIHJlZmV0Y2gsXHJcbiAgfSA9IHVzZVZhbGlkYXJBbHZhcmFQdWJsaWNvKGNvZGlnbyk7XHJcblxyXG4gIGNvbnN0IGhhbmRsZUJ1c2Nhck5vdm9Db2RpZ28gPSAoZTogUmVhY3QuRm9ybUV2ZW50KSA9PiB7XHJcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XHJcbiAgICBpZiAoaW5wdXRDb2RpZ28udHJpbSgpKSB7XHJcbiAgICAgIG5hdmlnYXRlKFJPVVRFUy5QVUJMSUMuVkFMSURBUl9BTFZBUkEoZW5jb2RlVVJJQ29tcG9uZW50KGlucHV0Q29kaWdvLnRyaW0oKS50b1VwcGVyQ2FzZSgpKSkpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGVzdGFiID0gYWx2YXJhPy5lc3RhYmVsZWNpbWVudG87XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cIm1pbi1oLXNjcmVlbiBiZy1zbGF0ZS01MCBkYXJrOmJnLXNsYXRlLTk1MCB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtc2xhdGUtMTAwIGZsZXggZmxleC1jb2wganVzdGlmeS1iZXR3ZWVuIGFudGlhbGlhc2VkIHNlbGVjdGlvbjpiZy10ZWFsLTUwMCBzZWxlY3Rpb246dGV4dC13aGl0ZVwiPlxyXG4gICAgICB7LyogVG9wbyBJbnN0aXR1Y2lvbmFsIGRlIEbDqSBQw7pibGljYSAqL31cclxuICAgICAgPGhlYWRlciBjbGFzc05hbWU9XCJiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTkwMCBib3JkZXItYiBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCBzaGFkb3ctMnhzXCI+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYXgtdy0zeGwgbXgtYXV0byBweC00IHB5LTQgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC0zXCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zXCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xMCBoLTEwIHJvdW5kZWQteGwgYmctdGVhbC02MDAgdGV4dC13aGl0ZSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBmb250LWJvbGQgc2hhZG93LXhzXCI+XHJcbiAgICAgICAgICAgICAgPFNoaWVsZCBjbGFzc05hbWU9XCJ3LTUgaC01IHRleHQtd2hpdGVcIiAvPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSBmb250LWJvbGQgdGV4dC1zbGF0ZS00MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIGJsb2NrXCI+XHJcbiAgICAgICAgICAgICAgICBWYWxpZGHDp8OjbyBPZmljaWFsIGRlIERvY3VtZW50b3NcclxuICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1ib2xkIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZSBsZWFkaW5nLXRpZ2h0XCI+XHJcbiAgICAgICAgICAgICAgICBWaWdpbMOibmNpYSBTYW5pdMOhcmlhIOKAoiB7QVBQX0NPTkZJRy5tdW5pY2lwaW99IC8ge0FQUF9DT05GSUcudWZ9XHJcbiAgICAgICAgICAgICAgPC9oMT5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImhpZGRlbiBzbTpmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHRleHQteHMgdGV4dC1zbGF0ZS01MDAgZm9udC1tZWRpdW0gYmctc2xhdGUtMTAwIGRhcms6Ymctc2xhdGUtODAwIHB4LTIuNSBweS0xIHJvdW5kZWQtbGdcIj5cclxuICAgICAgICAgICAgPFFyQ29kZSBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNSB0ZXh0LXRlYWwtNjAwXCIgLz5cclxuICAgICAgICAgICAgPHNwYW4+Q29uc3VsdGEgUMO6YmxpY2EgUVIgQ29kZTwvc3Bhbj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2hlYWRlcj5cclxuXHJcbiAgICAgIHsvKiBDb250ZcO6ZG8gUHJpbmNpcGFsICovfVxyXG4gICAgICA8bWFpbiBjbGFzc05hbWU9XCJtYXgtdy0yeGwgdy1mdWxsIG14LWF1dG8gcHgtNCBweS04IHNwYWNlLXktNlwiPlxyXG4gICAgICAgIHsvKiBCYXJyYSBkZSBDb25zdWx0YSBNYW51YWwgZGUgQ8OzZGlnbyAqL31cclxuICAgICAgICA8Zm9ybVxyXG4gICAgICAgICAgb25TdWJtaXQ9e2hhbmRsZUJ1c2Nhck5vdm9Db2RpZ299XHJcbiAgICAgICAgICBjbGFzc05hbWU9XCJiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC0yeGwgcC0yLjUgc2hhZG93LTJ4cyBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiXHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBmbGV4LTFcIj5cclxuICAgICAgICAgICAgPFNlYXJjaCBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtc2xhdGUtNDAwIGFic29sdXRlIGxlZnQtMyB0b3AtMi41XCIgLz5cclxuICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRGlnaXRlIG8gY8OzZGlnbyBkZSBhdXRlbnRpY2lkYWRlIChleDogQThCMkM0RDEtMjAyNikuLi5cIlxyXG4gICAgICAgICAgICAgIHZhbHVlPXtpbnB1dENvZGlnb31cclxuICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldElucHV0Q29kaWdvKGUudGFyZ2V0LnZhbHVlLnRvVXBwZXJDYXNlKCkpfVxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBwbC05IHByLTMgcHktMS41IHRleHQteHMgYmctdHJhbnNwYXJlbnQgYm9yZGVyLTAgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlIHBsYWNlaG9sZGVyLXNsYXRlLTQwMCBmb250LW1vbm8gZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMCB1cHBlcmNhc2VcIlxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJweC00IHB5LTEuNSB0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXdoaXRlIGJnLXRlYWwtNjAwIGhvdmVyOmJnLXRlYWwtNzAwIHJvdW5kZWQteGwgc2hhZG93LXhzIHRyYW5zaXRpb24tY29sb3JzIHNocmluay0wXCJcclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgQ29uc3VsdGFyXHJcbiAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICA8L2Zvcm0+XHJcblxyXG4gICAgICAgIHsvKiBFc3RhZG86IENhcnJlZ2FuZG8gKi99XHJcbiAgICAgICAge2lzTG9hZGluZyAmJiAoXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMTYgdGV4dC1jZW50ZXIgdGV4dC1zbGF0ZS00MDAgdGV4dC14cyBmbGV4IGZsZXgtY29sIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC0yeGwgc2hhZG93LXhzXCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy04IGgtOCBib3JkZXItMyBib3JkZXItdGVhbC01MDAgYm9yZGVyLXQtdHJhbnNwYXJlbnQgcm91bmRlZC1mdWxsIGFuaW1hdGUtc3BpbiBtYi0zXCIgLz5cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMzAwXCI+XHJcbiAgICAgICAgICAgICAgVmFsaWRhbmRvIGF1dGVudGljaWRhZGUgbm8gYmFuY28gZGUgZGFkb3Mgc2FuaXTDoXJpby4uLlxyXG4gICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtc2xhdGUtNDAwIG10LTFcIj5cclxuICAgICAgICAgICAgICBDw7NkaWdvIHZlcmlmaWNhZG86IHtjb2RpZ299XHJcbiAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICl9XHJcblxyXG4gICAgICAgIHsvKiBFc3RhZG86IERvY3VtZW50byBJbnbDoWxpZG8gb3UgTsOjbyBMb2NhbGl6YWRvICg0MDQpICovfVxyXG4gICAgICAgIHshaXNMb2FkaW5nICYmIChpc0Vycm9yIHx8ICFhbHZhcmEpICYmIChcclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGFyazpiZy1zbGF0ZS05MDAgYm9yZGVyLTIgYm9yZGVyLXJvc2UtMzAwIGRhcms6Ym9yZGVyLXJvc2UtOTAwLzYwIHJvdW5kZWQtMnhsIHAtNiBzbTpwLTggc2hhZG93LXNtIHNwYWNlLXktNSB0ZXh0LWNlbnRlclwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTYgaC0xNiByb3VuZGVkLWZ1bGwgYmctcm9zZS01MCBkYXJrOmJnLXJvc2UtOTUwLzYwIHRleHQtcm9zZS02MDAgYm9yZGVyIGJvcmRlci1yb3NlLTIwMCBkYXJrOmJvcmRlci1yb3NlLTgwMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBteC1hdXRvXCI+XHJcbiAgICAgICAgICAgICAgPFhDaXJjbGUgY2xhc3NOYW1lPVwidy0xMCBoLTEwXCIgLz5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMS41XCI+XHJcbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiaW5saW5lLWJsb2NrIHB4LTMgcHktMSB0ZXh0LVsxMXB4XSBmb250LWJvbGQgcm91bmRlZC1mdWxsIGJnLXJvc2UtMTAwIHRleHQtcm9zZS04MDAgZGFyazpiZy1yb3NlLTk1MC84MCBkYXJrOnRleHQtcm9zZS0yMDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCI+XHJcbiAgICAgICAgICAgICAgICBEb2N1bWVudG8gTsOjbyBBdXTDqm50aWNvIC8gSW52w6FsaWRvXHJcbiAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtYmxhY2sgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlXCI+XHJcbiAgICAgICAgICAgICAgICBBbHZhcsOhIFNhbml0w6FyaW8gTsOjbyBMb2NhbGl6YWRvXHJcbiAgICAgICAgICAgICAgPC9oMj5cclxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNjAwIGRhcms6dGV4dC1zbGF0ZS00MDAgbWF4LXctbWQgbXgtYXV0b1wiPlxyXG4gICAgICAgICAgICAgICAgTyBjw7NkaWdvIGRlIGF1dGVudGljaWRhZGUgaW5mb3JtYWRvICg8c3Ryb25nPntjb2RpZ28gfHwgXCItLS1cIn08L3N0cm9uZz4pIG7Do28gY29uc3RhIG5vcyByZWdpc3Ryb3Mgb2ZpY2lhaXMgZGEgVmlnaWzDom5jaWEgU2FuaXTDoXJpYSBkZSB7QVBQX0NPTkZJRy5tdW5pY2lwaW99L01HIG91IGZvaSBjYW5jZWxhZG8uXHJcbiAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC00IGJnLXJvc2UtNTAvNjAgZGFyazpiZy1yb3NlLTk1MC8zMCBib3JkZXIgYm9yZGVyLXJvc2UtMjAwIGRhcms6Ym9yZGVyLXJvc2UtODAwLzgwIHJvdW5kZWQteGwgdGV4dC1sZWZ0IHRleHQteHMgdGV4dC1yb3NlLTkwMCBkYXJrOnRleHQtcm9zZS0yMDAgc3BhY2UteS0xXCI+XHJcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwiZm9udC1ib2xkIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjVcIj5cclxuICAgICAgICAgICAgICAgIDxBbGVydFRyaWFuZ2xlIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1yb3NlLTYwMFwiIC8+XHJcbiAgICAgICAgICAgICAgICBBdGVuw6fDo28gYW8gQ2lkYWTDo28gZSBhbyBDb25zdW1pZG9yOlxyXG4gICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSBsZWFkaW5nLXJlbGF4ZWQgdGV4dC1yb3NlLTgwMCBkYXJrOnRleHQtcm9zZS0zMDBcIj5cclxuICAgICAgICAgICAgICAgIERvY3VtZW50b3MgaW1wcmVzc29zIHF1ZSBuw6NvIHB1ZGVyZW0gc2VyIHZhbGlkYWRvcyBuZXN0ZSBwb3J0YWwgb2ZpY2lhbCBwb2RlbSBjb25maWd1cmFyIGZhbHNpZmljYcOnw6NvIG91IGV4ZXJjw61jaW8gaXJyZWd1bGFyIGRlIGF0aXZpZGFkZSBlY29uw7RtaWNhLiBFbSBjYXNvIGRlIGTDunZpZGFzLCBkZW51bmNpZSDDoCBPdXZpZG9yaWEgZGEgVmlnaWzDom5jaWEgU2FuaXTDoXJpYS5cclxuICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgKX1cclxuXHJcbiAgICAgICAgey8qIEVzdGFkbzogRG9jdW1lbnRvIFbDoWxpZG8gb3UgVmVuY2lkbyBFbmNvbnRyYWRvICovfVxyXG4gICAgICAgIHshaXNMb2FkaW5nICYmIGFsdmFyYSAmJiAoXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIGRhcms6Ymctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLTJ4bCBzaGFkb3ctc20gb3ZlcmZsb3ctaGlkZGVuXCI+XHJcbiAgICAgICAgICAgIHsvKiBCYW5uZXIgZGUgU3RhdHVzIEp1csOtZGljbyAqL31cclxuICAgICAgICAgICAge2FsdmFyYS52YWxpZG8gPyAoXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTYgYmctZW1lcmFsZC02MDAgdGV4dC13aGl0ZSB0ZXh0LWNlbnRlciBzcGFjZS15LTFcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xMiBoLTEyIHJvdW5kZWQtZnVsbCBiZy13aGl0ZS8yMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBteC1hdXRvIG1iLTIgYmFja2Ryb3AtYmx1ci14c1wiPlxyXG4gICAgICAgICAgICAgICAgICA8Q2hlY2tDaXJjbGUyIGNsYXNzTmFtZT1cInctOCBoLTggdGV4dC13aGl0ZVwiIC8+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIGZvbnQtYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXN0IGJnLXdoaXRlLzIwIHB4LTMgcHktMC41IHJvdW5kZWQtZnVsbCBpbmxpbmUtYmxvY2tcIj5cclxuICAgICAgICAgICAgICAgICAgRG9jdW1lbnRvIEF1dMOqbnRpY28gZSBSZWd1bGFyXHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC14bCBmb250LWJsYWNrIHRyYWNraW5nLXdpZGVcIj5cclxuICAgICAgICAgICAgICAgICAgQUxWQVLDgSBTQU5JVMOBUklPIFbDgUxJRE9cclxuICAgICAgICAgICAgICAgIDwvaDI+XHJcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZW1lcmFsZC0xMDBcIj5cclxuICAgICAgICAgICAgICAgICAgRW1pdGlkbyBwZWxhIHtBUFBfQ09ORklHLnByZWZlaXR1cmF9IC8ge0FQUF9DT05GSUcudWZ9XHJcbiAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTYgYmctcm9zZS02MDAgdGV4dC13aGl0ZSB0ZXh0LWNlbnRlciBzcGFjZS15LTFcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xMiBoLTEyIHJvdW5kZWQtZnVsbCBiZy13aGl0ZS8yMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBteC1hdXRvIG1iLTIgYmFja2Ryb3AtYmx1ci14c1wiPlxyXG4gICAgICAgICAgICAgICAgICA8U2hpZWxkQWxlcnQgY2xhc3NOYW1lPVwidy04IGgtOCB0ZXh0LXdoaXRlXCIgLz5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gZm9udC1ib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlc3QgYmctd2hpdGUvMjAgcHgtMyBweS0wLjUgcm91bmRlZC1mdWxsIGlubGluZS1ibG9ja1wiPlxyXG4gICAgICAgICAgICAgICAgICBTaXR1YcOnw6NvIElycmVndWxhclxyXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1ibGFjayB0cmFja2luZy13aWRlXCI+XHJcbiAgICAgICAgICAgICAgICAgIEFMVkFSw4EgU0FOSVTDgVJJTyBWRU5DSURPIC8gU1VTUEVOU09cclxuICAgICAgICAgICAgICAgIDwvaDI+XHJcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtcm9zZS0xMDBcIj5cclxuICAgICAgICAgICAgICAgICAge2FsdmFyYS5tb3Rpdm9fc3RhdHVzIHx8IFwiVmFsaWRhZGUgZXhwaXJhZGEgb3UgZG9jdW1lbnRvIHJldm9nYWRvXCJ9XHJcbiAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICB7LyogRGFkb3MgQ2VudHJhaXMgZG8gQWx2YXLDoSAqL31cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTYgc3BhY2UteS02XCI+XHJcbiAgICAgICAgICAgICAgey8qIElkZW50aWZpY2HDp8OjbyBPZmljaWFsICovfVxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBzbTpncmlkLWNvbHMtMiBnYXAtNCBwYi00IGJvcmRlci1iIGJvcmRlci1zbGF0ZS0xMDAgZGFyazpib3JkZXItc2xhdGUtODAwXCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LXNsYXRlLTQwMCB1cHBlcmNhc2UgZm9udC1ib2xkIGJsb2NrXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgTsO6bWVybyBkbyBBbHZhcsOhXHJcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1iYXNlIGZvbnQtYmxhY2sgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge2FsdmFyYS5udW1lcm9fZm9ybWF0YWRvIHx8IGAke2FsdmFyYS5udW1lcm9fYWx2YXJhfS8ke2FsdmFyYS5leGVyY2ljaW99YH1cclxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1zbGF0ZS00MDAgdXBwZXJjYXNlIGZvbnQtYm9sZCBibG9ja1wiPlxyXG4gICAgICAgICAgICAgICAgICAgIEPDs2RpZ28gZGUgQXV0ZW50aWNpZGFkZVxyXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtYmFzZSBmb250LW1vbm8gZm9udC1ib2xkIHRleHQtdGVhbC03MDAgZGFyazp0ZXh0LXRlYWwtNDAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge2FsdmFyYS5jb2RpZ29fYXV0ZW50aWNpZGFkZX1cclxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIHsvKiBFbXByZXNhIC8gQmVuZWZpY2nDoXJpbyAqL31cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktM1wiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtc2xhdGUtNDAwIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjVcIj5cclxuICAgICAgICAgICAgICAgICAgICA8QnVpbGRpbmcyIGNsYXNzTmFtZT1cInctMy41IGgtMy41IHRleHQtdGVhbC02MDBcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgIEVzdGFiZWxlY2ltZW50byBMaWNlbmNpYWRvXHJcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAge2VzdGFiPy5uaXZlbF9yaXNjbyAmJiA8UmlzY29CYWRnZSByaXNjbz17ZXN0YWIubml2ZWxfcmlzY299IC8+fVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTQgYmctc2xhdGUtNTAgZGFyazpiZy1zbGF0ZS04MDAvNTAgcm91bmRlZC14bCBzcGFjZS15LTIgdGV4dC14c1wiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtc2xhdGUtNDAwIHVwcGVyY2FzZSBmb250LXNlbWlib2xkIGJsb2NrXCI+UmF6w6NvIFNvY2lhbDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtlc3RhYj8ucmF6YW9fc29jaWFsIHx8IFwiRXN0YWJlbGVjaW1lbnRvIFJlZ3VsYXJcIn1cclxuICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAge2VzdGFiPy5ub21lX2ZhbnRhc2lhICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1zbGF0ZS00MDAgdXBwZXJjYXNlIGZvbnQtc2VtaWJvbGQgYmxvY2tcIj5Ob21lIEZhbnRhc2lhPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwiZm9udC1tZWRpdW0gdGV4dC1zbGF0ZS04MDAgZGFyazp0ZXh0LXNsYXRlLTIwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7ZXN0YWIubm9tZV9mYW50YXNpYX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBzbTpncmlkLWNvbHMtMiBnYXAtMiBwdC0xIGJvcmRlci10IGJvcmRlci1zbGF0ZS0yMDAvNjAgZGFyazpib3JkZXItc2xhdGUtNzAwLzYwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtc2xhdGUtNDAwIHVwcGVyY2FzZSBmb250LXNlbWlib2xkIGJsb2NrXCI+Q05QSiAvIENQRjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImZvbnQtbW9ubyBmb250LW1lZGl1bSB0ZXh0LXNsYXRlLTgwMCBkYXJrOnRleHQtc2xhdGUtMjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtlc3RhYj8uY25wal9jcGYgfHwgXCItLS1cIn1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtc2xhdGUtNDAwIHVwcGVyY2FzZSBmb250LXNlbWlib2xkIGJsb2NrXCI+SW5zY3Jpw6fDo28gTXVuaWNpcGFsPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwiZm9udC1tb25vIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0zMDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2VzdGFiPy5pbnNjcmljYW9fbXVuaWNpcGFsIHx8IFwiSXNlbnRvIC8gTsOjbyBDb25zdGFcIn1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB0LTFcIj5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LXNsYXRlLTQwMCB1cHBlcmNhc2UgZm9udC1zZW1pYm9sZCBibG9ja1wiPkVuZGVyZcOnbyBBdXRvcml6YWRvPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0zMDAgbGVhZGluZy1zbnVnXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7ZXN0YWI/LmxvZ3JhZG91cm8gfHwgXCJMb2dyYWRvdXJvXCJ9LCB7ZXN0YWI/Lm51bWVybyB8fCBcIlMvTlwifXtcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgICAgIHtlc3RhYj8uY29tcGxlbWVudG8gJiYgYCgke2VzdGFiLmNvbXBsZW1lbnRvfSlgfSAte1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICAgICAge2VzdGFiPy5iYWlycm8gfHwgXCJDZW50cm9cIn0sIHtlc3RhYj8ubXVuaWNpcGlvIHx8IEFQUF9DT05GSUcubXVuaWNpcGlvfS97ZXN0YWI/LnVmIHx8IEFQUF9DT05GSUcudWZ9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICB7LyogUHJhem9zIGRlIFZhbGlkYWRlICovfVxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBzbTpncmlkLWNvbHMtMiBnYXAtNFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTMgYmctc2xhdGUtNTAgZGFyazpiZy1zbGF0ZS04MDAvNDAgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtODAwIHJvdW5kZWQteGwgdGV4dC14cyBzcGFjZS15LTFcIj5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDAgdGV4dC1bMTBweF0gdXBwZXJjYXNlIGZvbnQtYm9sZCBibG9jayBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxDYWxlbmRhciBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNSB0ZXh0LXRlYWwtNjAwXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICBEYXRhIGRlIEVtaXNzw6NvXHJcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LWJvbGQgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge25ldyBEYXRlKGFsdmFyYS5kYXRhX2VtaXNzYW8pLnRvTG9jYWxlRGF0ZVN0cmluZyhcInB0LUJSXCIsIHsgdGltZVpvbmU6IFwiVVRDXCIgfSl9XHJcbiAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcC0zIGJvcmRlciByb3VuZGVkLXhsIHRleHQteHMgc3BhY2UteS0xICR7XHJcbiAgICAgICAgICAgICAgICAgICAgYWx2YXJhLnZhbGlkb1xyXG4gICAgICAgICAgICAgICAgICAgICAgPyBcImJnLWVtZXJhbGQtNTAgZGFyazpiZy1lbWVyYWxkLTk1MC8zMCBib3JkZXItZW1lcmFsZC0yMDAgZGFyazpib3JkZXItZW1lcmFsZC04MDAgdGV4dC1lbWVyYWxkLTk1MCBkYXJrOnRleHQtZW1lcmFsZC0yMDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgOiBcImJnLXJvc2UtNTAgZGFyazpiZy1yb3NlLTk1MC8zMCBib3JkZXItcm9zZS0yMDAgZGFyazpib3JkZXItcm9zZS04MDAgdGV4dC1yb3NlLTk1MCBkYXJrOnRleHQtcm9zZS0yMDBcIlxyXG4gICAgICAgICAgICAgICAgICB9YH1cclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdXBwZXJjYXNlIGZvbnQtYm9sZCBibG9jayBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxDbG9jayBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNVwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgRGF0YSBMaW1pdGUgZGUgVmFsaWRhZGVcclxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtYmxhY2tcIj5cclxuICAgICAgICAgICAgICAgICAgICB7bmV3IERhdGUoYWx2YXJhLmRhdGFfdmVuY2ltZW50bykudG9Mb2NhbGVEYXRlU3RyaW5nKFwicHQtQlJcIiwgeyB0aW1lWm9uZTogXCJVVENcIiB9KX1cclxuICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICB7YWx2YXJhLmRpYXNfcmVzdGFudGVzX3ZhbGlkYWRlICE9PSB1bmRlZmluZWQgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIGZvbnQtc2VtaWJvbGQgYmxvY2tcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHthbHZhcmEuZGlhc19yZXN0YW50ZXNfdmFsaWRhZGUgPj0gMFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA/IGBWaWdlbnRlIHBvciBtYWlzICR7YWx2YXJhLmRpYXNfcmVzdGFudGVzX3ZhbGlkYWRlfSBkaWEocylgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDogYFZlbmNpZG8gaMOhICR7TWF0aC5hYnMoYWx2YXJhLmRpYXNfcmVzdGFudGVzX3ZhbGlkYWRlKX0gZGlhKHMpYH1cclxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgey8qIENvbmRpY2lvbmFudGVzIChzZSBob3V2ZXIpICovfVxyXG4gICAgICAgICAgICAgIHthbHZhcmEuY29uZGljaW9uYW50ZXNfcmVzdHJpY29lcyAmJiAoXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMyBiZy1hbWJlci01MCBkYXJrOmJnLWFtYmVyLTk1MC8zMCBib3JkZXIgYm9yZGVyLWFtYmVyLTIwMCBkYXJrOmJvcmRlci1hbWJlci04MDAgcm91bmRlZC14bCB0ZXh0LXhzIHRleHQtYW1iZXItOTAwIGRhcms6dGV4dC1hbWJlci0yMDAgc3BhY2UteS0xXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIGZvbnQtYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1hbWJlci04MDAgZGFyazp0ZXh0LWFtYmVyLTMwMCBibG9ja1wiPlxyXG4gICAgICAgICAgICAgICAgICAgIENvbmRpY2lvbmFudGVzIC8gUmVzdHJpw6fDtWVzIEVzcGVjaWFpczpcclxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSBsZWFkaW5nLXJlbGF4ZWRcIj5cclxuICAgICAgICAgICAgICAgICAgICB7YWx2YXJhLmNvbmRpY2lvbmFudGVzX3Jlc3RyaWNvZXN9XHJcbiAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgKX1cclxuICAgICAgPC9tYWluPlxyXG5cclxuICAgICAgey8qIFJvZGFww6kgSW5zdGl0dWNpb25hbCAqL31cclxuICAgICAgPGZvb3RlciBjbGFzc05hbWU9XCJiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTkwMCBib3JkZXItdCBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCBweS02IHRleHQtY2VudGVyIHRleHQteHMgdGV4dC1zbGF0ZS01MDBcIj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1heC13LTJ4bCBteC1hdXRvIHB4LTQgc3BhY2UteS0xXCI+XHJcbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0zMDBcIj5cclxuICAgICAgICAgICAge0FQUF9DT05GSUcucHJlZmVpdHVyYX0g4oCiIHtBUFBfQ09ORklHLnNlY3JldGFyaWF9XHJcbiAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LXNsYXRlLTQwMFwiPlxyXG4gICAgICAgICAgICB7QVBQX0NPTkZJRy5vcmdhb30g4oCiIFNpc3RlbWEge0FQUF9DT05GSUcubm9tZX1cclxuICAgICAgICAgIDwvcD5cclxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtc2xhdGUtNDAwIHB0LTJcIj5cclxuICAgICAgICAgICAgQ29uc3VsdGEgcMO6YmxpY2EgZW0gY29uZm9ybWlkYWRlIGNvbSBvIHByaW5jw61waW8gZGEgcHVibGljaWRhZGUgYWRtaW5pc3RyYXRpdmEgZSBDw7NkaWdvIFNhbml0w6FyaW8gZG8ge0FQUF9DT05GSUcuZXN0YWRvRXh0ZW5zb30uXHJcbiAgICAgICAgICA8L3A+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZm9vdGVyPlxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IFZhbGlkYXJBbHZhcmFQdWJsaWNQYWdlO1xyXG4iXX0=