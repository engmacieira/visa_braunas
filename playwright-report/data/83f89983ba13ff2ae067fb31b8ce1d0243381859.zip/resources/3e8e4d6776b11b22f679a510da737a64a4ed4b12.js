import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/fiscalizacao/PainelPrazosPage.tsx");const React = __vite__cjsImport0_react; const useMemo = __vite__cjsImport0_react["useMemo"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport6_react_jsxDevRuntime["jsxDEV"];/**
* Painel Operacional de Prazos e Notificações Sanitárias Pendentes
* Rota: /fiscalizacao/prazos
* Monitora contagem regressiva de prazos legais concedidos a estabelecimentos,
* com categorização por gravidade e atalho para abertura de Reinspeção Fiscal.
*/
import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=0fd2848a";
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=0fd2848a";
import { AlertCircle, AlertTriangle, ArrowLeft, Calendar, CheckCircle2, Clock, FileText, RefreshCw, RotateCcw, Search, UserCheck } from "/node_modules/.vite/deps/lucide-react.js?v=0fd2848a";
import { ROUTES } from "/src/config/routes.config.ts";
import { useNotificacoesPendentes } from "/src/hooks/useFiscalizacao.ts";
import { AgendarInspecaoModal } from "/src/components/fiscalizacao/AgendarInspecaoModal.tsx";
var _jsxFileName = "E:/Projetos VSCODE/visa_braunas/src/pages/fiscalizacao/PainelPrazosPage.tsx";
import __vite__cjsImport6_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=0fd2848a";
var _s = $RefreshSig$();
export const PainelPrazosPage = () => {
	_s();
	const [filtroPrazo, setFiltroPrazo] = useState("todos");
	const [busca, setBusca] = useState("");
	const [reinspecaoAlvo, setReinspecaoAlvo] = useState(null);
	const { data: notificacoes = [], isLoading, isRefetching, refetch } = useNotificacoesPendentes(60);
	// Classificação por severidade
	const { vencidas, alertas7dias, regulares } = useMemo(() => {
		const v = [];
		const a = [];
		const r = [];
		notificacoes.forEach((item) => {
			if (item.dias_restantes < 0) {
				v.push(item);
			} else if (item.dias_restantes <= 7) {
				a.push(item);
			} else {
				r.push(item);
			}
		});
		return {
			vencidas: v,
			alertas7dias: a,
			regulares: r
		};
	}, [notificacoes]);
	// Lista filtrada
	const notificacoesExibidas = useMemo(() => {
		let base = notificacoes;
		if (filtroPrazo === "vencidos") base = vencidas;
		else if (filtroPrazo === "alerta_7_dias") base = alertas7dias;
		else if (filtroPrazo === "regulares") base = regulares;
		if (!busca) return base;
		const termo = busca.toLowerCase();
		return base.filter((n) => n.numero_termo.toLowerCase().includes(termo) || n.razao_social.toLowerCase().includes(termo) || n.nome_fantasia && n.nome_fantasia.toLowerCase().includes(termo) || n.fiscal_responsavel.toLowerCase().includes(termo));
	}, [
		notificacoes,
		vencidas,
		alertas7dias,
		regulares,
		filtroPrazo,
		busca
	]);
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-xs",
				children: [/* @__PURE__ */ _jsxDEV("div", { children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-2 mb-1",
						children: /* @__PURE__ */ _jsxDEV(Link, {
							to: ROUTES.INSPECOES.LIST,
							className: "inline-flex items-center gap-1.5 text-xs font-semibold text-slate-500 hover:text-teal-600 transition-colors",
							children: [/* @__PURE__ */ _jsxDEV(ArrowLeft, { className: "w-3.5 h-3.5" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 96,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Voltar para Inspeções" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 97,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 92,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 91,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("h1", {
						className: "text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2",
						children: [/* @__PURE__ */ _jsxDEV(Clock, { className: "w-5 h-5 text-amber-500" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 101,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Painel de Prazos & Notificações Sanitárias" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 102,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 100,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("p", {
						className: "text-xs text-slate-500 dark:text-slate-400 mt-1 max-w-2xl",
						children: "Monitoramento de contagem regressiva para regularização de estabelecimentos notificados em autos fiscais."
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 104,
						columnNumber: 11
					}, this)
				] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 90,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					onClick: () => refetch(),
					disabled: isRefetching,
					className: "px-3 py-1.5 text-xs font-semibold text-slate-700 dark:text-slate-200 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors flex items-center gap-1.5 shadow-2xs self-start sm:self-center",
					children: [/* @__PURE__ */ _jsxDEV(RefreshCw, { className: `w-3.5 h-3.5 ${isRefetching ? "animate-spin text-teal-600" : ""}` }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 115,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Atualizar Prazos" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 118,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 109,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 89,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4",
				children: [
					/* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						onClick: () => setFiltroPrazo("todos"),
						className: `text-left p-4 rounded-xl border transition-all ${filtroPrazo === "todos" ? "bg-slate-900 text-white border-slate-900 shadow-xs dark:bg-slate-800" : "bg-white dark:bg-slate-900 text-slate-900 dark:text-white border-slate-200 dark:border-slate-800 hover:border-slate-300"}`,
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center justify-between",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-xs font-semibold opacity-80",
								children: "Total Notificadas"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 135,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV(FileText, { className: "w-4 h-4 opacity-70" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 138,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 134,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "mt-2 flex items-baseline gap-2",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-2xl font-bold",
								children: notificacoes.length
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 141,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "text-[11px] opacity-70",
								children: "processos"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 142,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 140,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 125,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						onClick: () => setFiltroPrazo("vencidos"),
						className: `text-left p-4 rounded-xl border transition-all ${filtroPrazo === "vencidos" ? "bg-rose-600 text-white border-rose-600 shadow-xs" : "bg-rose-50/70 dark:bg-rose-950/20 text-rose-900 dark:text-rose-200 border-rose-200 dark:border-rose-900/40 hover:border-rose-300"}`,
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center justify-between",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-xs font-semibold",
								children: "Prazos Vencidos"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 157,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV(AlertCircle, { className: "w-4 h-4 text-rose-600" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 158,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 156,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "mt-2 flex items-baseline gap-2",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-2xl font-bold text-rose-700 dark:text-rose-400",
								children: vencidas.length
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 161,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "text-[11px] font-semibold text-rose-600 dark:text-rose-400",
								children: "urgente"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 164,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 160,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 147,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						onClick: () => setFiltroPrazo("alerta_7_dias"),
						className: `text-left p-4 rounded-xl border transition-all ${filtroPrazo === "alerta_7_dias" ? "bg-amber-600 text-white border-amber-600 shadow-xs" : "bg-amber-50/70 dark:bg-amber-950/20 text-amber-900 dark:text-amber-200 border-amber-200 dark:border-amber-900/40 hover:border-amber-300"}`,
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center justify-between",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-xs font-semibold",
								children: "Vencem em até 7 dias"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 181,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV(AlertTriangle, { className: "w-4 h-4 text-amber-600" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 182,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 180,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "mt-2 flex items-baseline gap-2",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-2xl font-bold text-amber-700 dark:text-amber-400",
								children: alertas7dias.length
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 185,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "text-[11px] text-amber-600 dark:text-amber-400 font-medium",
								children: "atenção"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 188,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 184,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 171,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						onClick: () => setFiltroPrazo("regulares"),
						className: `text-left p-4 rounded-xl border transition-all ${filtroPrazo === "regulares" ? "bg-emerald-600 text-white border-emerald-600 shadow-xs" : "bg-emerald-50/70 dark:bg-emerald-950/20 text-emerald-900 dark:text-emerald-200 border-emerald-200 dark:border-emerald-900/40 hover:border-emerald-300"}`,
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center justify-between",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-xs font-semibold",
								children: "No Prazo (> 7 dias)"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 205,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV(CheckCircle2, { className: "w-4 h-4 text-emerald-600" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 206,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 204,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "mt-2 flex items-baseline gap-2",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-2xl font-bold text-emerald-700 dark:text-emerald-400",
								children: regulares.length
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 209,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "text-[11px] text-emerald-600 dark:text-emerald-400",
								children: "acompanhando"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 212,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 208,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 195,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 123,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-xs overflow-hidden",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "p-4 bg-slate-50/50 dark:bg-slate-800/40 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between gap-4",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "relative flex-1 max-w-md",
						children: [/* @__PURE__ */ _jsxDEV(Search, { className: "w-4 h-4 text-slate-400 absolute left-3 top-2.5" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 223,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("input", {
							type: "text",
							placeholder: "Buscar por termo fiscal, razão social ou fiscal...",
							value: busca,
							onChange: (e) => setBusca(e.target.value),
							className: "w-full pl-9 pr-4 py-2 text-xs bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-amber-500"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 224,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 222,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "text-xs text-slate-500 font-medium",
						children: [
							"Exibindo ",
							/* @__PURE__ */ _jsxDEV("strong", { children: notificacoesExibidas.length }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 234,
								columnNumber: 22
							}, this),
							" de",
							" ",
							notificacoes.length,
							" notificações"
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 233,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 221,
					columnNumber: 9
				}, this), isLoading ? /* @__PURE__ */ _jsxDEV("div", {
					className: "p-16 text-center text-slate-400 text-xs flex flex-col items-center justify-center",
					children: [/* @__PURE__ */ _jsxDEV("div", { className: "w-6 h-6 border-2 border-amber-500 border-t-transparent rounded-full animate-spin mb-3" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 242,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Consultando prazos de notificações sanitárias..." }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 243,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 241,
					columnNumber: 11
				}, this) : notificacoesExibidas.length === 0 ? /* @__PURE__ */ _jsxDEV("div", {
					className: "p-12 text-center text-slate-500 dark:text-slate-400 space-y-2",
					children: [
						/* @__PURE__ */ _jsxDEV(CheckCircle2, { className: "w-10 h-10 text-emerald-500 mx-auto" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 247,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("p", {
							className: "text-xs font-bold text-slate-800 dark:text-slate-200",
							children: "Nenhuma notificação sanitária pendente para este filtro."
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 248,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("p", {
							className: "text-[11px] text-slate-400",
							children: "Todos os prazos legais estão devidamente sanados ou sem pendências registradas."
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 251,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 246,
					columnNumber: 11
				}, this) : /* @__PURE__ */ _jsxDEV("div", {
					className: "overflow-x-auto",
					children: /* @__PURE__ */ _jsxDEV("table", {
						className: "w-full text-left text-xs border-collapse",
						children: [/* @__PURE__ */ _jsxDEV("thead", {
							className: "bg-slate-50/80 dark:bg-slate-800/60 border-b border-slate-200 dark:border-slate-800 text-slate-500 dark:text-slate-400 font-semibold uppercase tracking-wider",
							children: /* @__PURE__ */ _jsxDEV("tr", { children: [
								/* @__PURE__ */ _jsxDEV("th", {
									className: "py-3.5 px-4",
									children: "Contagem / Alerta"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 260,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("th", {
									className: "py-3.5 px-4",
									children: "Termo Fiscal"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 261,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("th", {
									className: "py-3.5 px-4",
									children: "Estabelecimento Notificado"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 262,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("th", {
									className: "py-3.5 px-4",
									children: "Data Limite"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 263,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("th", {
									className: "py-3.5 px-4",
									children: "Fiscal Responsável"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 264,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("th", {
									className: "py-3.5 px-4 text-right",
									children: "Ações Operacionais"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 265,
									columnNumber: 19
								}, this)
							] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 259,
								columnNumber: 17
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 258,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("tbody", {
							className: "divide-y divide-slate-100 dark:divide-slate-800",
							children: notificacoesExibidas.map((item) => {
								const isVencida = item.dias_restantes < 0;
								const isAlerta = item.dias_restantes >= 0 && item.dias_restantes <= 7;
								return /* @__PURE__ */ _jsxDEV("tr", {
									className: "hover:bg-slate-50/60 dark:hover:bg-slate-800/40 transition-colors",
									children: [
										/* @__PURE__ */ _jsxDEV("td", {
											className: "py-3.5 px-4",
											children: isVencida ? /* @__PURE__ */ _jsxDEV("div", {
												className: "inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-bold bg-rose-100 dark:bg-rose-950/60 text-rose-800 dark:text-rose-300 border border-rose-300 dark:border-rose-800",
												children: [/* @__PURE__ */ _jsxDEV(AlertCircle, { className: "w-3.5 h-3.5 text-rose-600" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 282,
													columnNumber: 29
												}, this), /* @__PURE__ */ _jsxDEV("span", { children: [
													"VENCIDO HÁ ",
													Math.abs(item.dias_restantes),
													" DIA(S)"
												] }, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 283,
													columnNumber: 29
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 281,
												columnNumber: 27
											}, this) : isAlerta ? /* @__PURE__ */ _jsxDEV("div", {
												className: "inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-bold bg-amber-100 dark:bg-amber-950/60 text-amber-800 dark:text-amber-300 border border-amber-300 dark:border-amber-800",
												children: [/* @__PURE__ */ _jsxDEV(Clock, { className: "w-3.5 h-3.5 text-amber-600" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 289,
													columnNumber: 29
												}, this), /* @__PURE__ */ _jsxDEV("span", { children: item.dias_restantes === 0 ? "VENCE HOJE" : `RESTA(M) ${item.dias_restantes} DIA(S)` }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 290,
													columnNumber: 29
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 288,
												columnNumber: 27
											}, this) : /* @__PURE__ */ _jsxDEV("div", {
												className: "inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-medium bg-emerald-100 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-800",
												children: [/* @__PURE__ */ _jsxDEV(CheckCircle2, { className: "w-3.5 h-3.5 text-emerald-600" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 298,
													columnNumber: 29
												}, this), /* @__PURE__ */ _jsxDEV("span", { children: [item.dias_restantes, " dias restantes"] }, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 299,
													columnNumber: 29
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 297,
												columnNumber: 27
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 279,
											columnNumber: 23
										}, this),
										/* @__PURE__ */ _jsxDEV("td", {
											className: "py-3.5 px-4 font-mono font-bold text-slate-900 dark:text-white",
											children: item.numero_termo
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 305,
											columnNumber: 23
										}, this),
										/* @__PURE__ */ _jsxDEV("td", {
											className: "py-3.5 px-4",
											children: /* @__PURE__ */ _jsxDEV("div", {
												className: "flex flex-col",
												children: [/* @__PURE__ */ _jsxDEV(Link, {
													to: ROUTES.ESTABELECIMENTOS.DETALHE(item.estabelecimento_id),
													className: "font-bold text-slate-800 dark:text-slate-200 hover:text-teal-600 dark:hover:text-teal-400 transition-colors",
													children: item.razao_social
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 312,
													columnNumber: 27
												}, this), item.nome_fantasia && /* @__PURE__ */ _jsxDEV("span", {
													className: "text-[10px] text-slate-400",
													children: item.nome_fantasia
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 319,
													columnNumber: 29
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 311,
												columnNumber: 25
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 310,
											columnNumber: 23
										}, this),
										/* @__PURE__ */ _jsxDEV("td", {
											className: "py-3.5 px-4",
											children: /* @__PURE__ */ _jsxDEV("div", {
												className: "flex items-center gap-1 text-slate-700 dark:text-slate-300 font-semibold",
												children: [/* @__PURE__ */ _jsxDEV(Calendar, { className: "w-3.5 h-3.5 text-slate-400" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 329,
													columnNumber: 27
												}, this), /* @__PURE__ */ _jsxDEV("span", { children: new Date(item.data_limite_adequacao).toLocaleDateString("pt-BR") }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 330,
													columnNumber: 27
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 328,
												columnNumber: 25
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 327,
											columnNumber: 23
										}, this),
										/* @__PURE__ */ _jsxDEV("td", {
											className: "py-3.5 px-4",
											children: /* @__PURE__ */ _jsxDEV("div", {
												className: "flex items-center gap-1.5 text-slate-600 dark:text-slate-300",
												children: [/* @__PURE__ */ _jsxDEV(UserCheck, { className: "w-3.5 h-3.5 text-slate-400" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 341,
													columnNumber: 27
												}, this), /* @__PURE__ */ _jsxDEV("span", { children: item.fiscal_responsavel }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 342,
													columnNumber: 27
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 340,
												columnNumber: 25
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 339,
											columnNumber: 23
										}, this),
										/* @__PURE__ */ _jsxDEV("td", {
											className: "py-3.5 px-4 text-right",
											children: /* @__PURE__ */ _jsxDEV("div", {
												className: "flex items-center justify-end gap-2",
												children: [/* @__PURE__ */ _jsxDEV(Link, {
													to: ROUTES.INSPECOES.LAUDO(item.inspecao_id),
													className: "p-1.5 text-slate-500 hover:text-teal-600 dark:text-slate-400 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors",
													title: "Visualizar laudo e termo original",
													children: /* @__PURE__ */ _jsxDEV(FileText, { className: "w-4 h-4" }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 354,
														columnNumber: 29
													}, this)
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 349,
													columnNumber: 27
												}, this), /* @__PURE__ */ _jsxDEV("button", {
													type: "button",
													onClick: () => setReinspecaoAlvo({
														estabelecimentoId: item.estabelecimento_id,
														termo: item.numero_termo
													}),
													className: "px-3 py-1.5 text-xs font-bold text-teal-700 dark:text-teal-300 bg-teal-50 dark:bg-teal-950/40 border border-teal-200 dark:border-teal-800 rounded-lg hover:bg-teal-100/60 shadow-2xs transition-colors inline-flex items-center gap-1.5",
													children: [/* @__PURE__ */ _jsxDEV(RotateCcw, { className: "w-3.5 h-3.5" }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 367,
														columnNumber: 29
													}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Agendar Reinspeção" }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 368,
														columnNumber: 29
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 357,
													columnNumber: 27
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 348,
												columnNumber: 25
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 347,
											columnNumber: 23
										}, this)
									]
								}, item.inspecao_id, true, {
									fileName: _jsxFileName,
									lineNumber: 274,
									columnNumber: 21
								}, this);
							})
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 268,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 257,
						columnNumber: 13
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 256,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 220,
				columnNumber: 7
			}, this),
			reinspecaoAlvo && /* @__PURE__ */ _jsxDEV(AgendarInspecaoModal, {
				isOpen: Boolean(reinspecaoAlvo),
				onClose: () => setReinspecaoAlvo(null),
				estabelecimentoIdPreDefinido: reinspecaoAlvo.estabelecimentoId,
				motivoPreDefinido: "reinspecao"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 383,
				columnNumber: 9
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 87,
		columnNumber: 5
	}, this);
};
_s(PainelPrazosPage, "U/miWyvWYMj9TbSlCGuDaHz5oqE=", false, function() {
	return [useNotificacoesPendentes];
});
_c = PainelPrazosPage;
export default PainelPrazosPage;
var _c;
$RefreshReg$(_c, "PainelPrazosPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/fiscalizacao/PainelPrazosPage.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("E:/Projetos VSCODE/visa_braunas/src/pages/fiscalizacao/PainelPrazosPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("E:/Projetos VSCODE/visa_braunas/src/pages/fiscalizacao/PainelPrazosPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "E:/Projetos VSCODE/visa_braunas/src/pages/fiscalizacao/PainelPrazosPage.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7Ozs7O0FBT0EsT0FBTyxTQUFTLFNBQVMsZ0JBQWdCO0FBQ3pDLFNBQVMsWUFBWTtBQUNyQixTQUNFLGFBQ0EsZUFDQSxXQUVBLFVBQ0EsY0FDQSxPQUVBLFVBRUEsV0FDQSxXQUNBLFFBQ0EsaUJBQ0s7QUFDUCxTQUFTLGNBQWM7QUFDdkIsU0FBUyxnQ0FBZ0M7QUFFekMsU0FBUyw0QkFBNEI7Ozs7QUFJckMsT0FBTyxNQUFNLHlCQUFtQzs7Q0FDOUMsTUFBTSxDQUFDLGFBQWEsa0JBQWtCLFNBQXNCLE9BQU87Q0FDbkUsTUFBTSxDQUFDLE9BQU8sWUFBWSxTQUFTLEVBQUU7Q0FDckMsTUFBTSxDQUFDLGdCQUFnQixxQkFBcUIsU0FHbEMsSUFBSTtDQUVkLE1BQU0sRUFDSixNQUFNLGVBQWUsQ0FBQyxHQUN0QixXQUNBLGNBQ0EsWUFDRSx5QkFBeUIsRUFBRTs7Q0FHL0IsTUFBTSxFQUFFLFVBQVUsY0FBYyxjQUFjLGNBQWM7RUFDMUQsTUFBTSxJQUE4QixDQUFDO0VBQ3JDLE1BQU0sSUFBOEIsQ0FBQztFQUNyQyxNQUFNLElBQThCLENBQUM7RUFFckMsYUFBYSxTQUFTLFNBQVM7R0FDN0IsSUFBSSxLQUFLLGlCQUFpQixHQUFHO0lBQzNCLEVBQUUsS0FBSyxJQUFJO0dBQ2IsT0FBTyxJQUFJLEtBQUssa0JBQWtCLEdBQUc7SUFDbkMsRUFBRSxLQUFLLElBQUk7R0FDYixPQUFPO0lBQ0wsRUFBRSxLQUFLLElBQUk7R0FDYjtFQUNGLENBQUM7RUFFRCxPQUFPO0dBQUUsVUFBVTtHQUFHLGNBQWM7R0FBRyxXQUFXO0VBQUU7Q0FDdEQsR0FBRyxDQUFDLFlBQVksQ0FBQzs7Q0FHakIsTUFBTSx1QkFBdUIsY0FBYztFQUN6QyxJQUFJLE9BQU87RUFDWCxJQUFJLGdCQUFnQixZQUFZLE9BQU87T0FDbEMsSUFBSSxnQkFBZ0IsaUJBQWlCLE9BQU87T0FDNUMsSUFBSSxnQkFBZ0IsYUFBYSxPQUFPO0VBRTdDLElBQUksQ0FBQyxPQUFPLE9BQU87RUFFbkIsTUFBTSxRQUFRLE1BQU0sWUFBWTtFQUNoQyxPQUFPLEtBQUssUUFDVCxNQUNDLEVBQUUsYUFBYSxZQUFZLENBQUMsQ0FBQyxTQUFTLEtBQUssS0FDM0MsRUFBRSxhQUFhLFlBQVksQ0FBQyxDQUFDLFNBQVMsS0FBSyxLQUMxQyxFQUFFLGlCQUFpQixFQUFFLGNBQWMsWUFBWSxDQUFDLENBQUMsU0FBUyxLQUFLLEtBQ2hFLEVBQUUsbUJBQW1CLFlBQVksQ0FBQyxDQUFDLFNBQVMsS0FBSyxDQUNyRDtDQUNGLEdBQUc7RUFBQztFQUFjO0VBQVU7RUFBYztFQUFXO0VBQWE7Q0FBSyxDQUFDO0NBRXhFLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBZjtHQUVFLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxPQUFEO0tBQ0Usd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQ2Isd0JBQUMsTUFBRDtPQUNFLElBQUksT0FBTyxVQUFVO09BQ3JCLFdBQVU7aUJBRlosQ0FJRSx3QkFBQyxXQUFELEVBQVcsV0FBVSxjQUFlOzs7O2lCQUNwQyx3QkFBQyxRQUFELFlBQU0sd0JBQTJCOzs7O2VBQzdCOzs7Ozs7S0FDSDs7Ozs7S0FDTCx3QkFBQyxNQUFEO01BQUksV0FBVTtnQkFBZCxDQUNFLHdCQUFDLE9BQUQsRUFBTyxXQUFVLHlCQUEwQjs7OztnQkFDM0Msd0JBQUMsUUFBRCxZQUFNLDZDQUFnRDs7OztjQUNwRDs7Ozs7O0tBQ0osd0JBQUMsS0FBRDtNQUFHLFdBQVU7Z0JBQTREO0tBRXRFOzs7OztJQUNBOzs7O2NBRUwsd0JBQUMsVUFBRDtLQUNFLE1BQUs7S0FDTCxlQUFlLFFBQVE7S0FDdkIsVUFBVTtLQUNWLFdBQVU7ZUFKWixDQU1FLHdCQUFDLFdBQUQsRUFDRSxXQUFXLGVBQWUsZUFBZSwrQkFBK0IsS0FDekU7Ozs7ZUFDRCx3QkFBQyxRQUFELFlBQU0sbUJBQXNCOzs7O2FBQ3RCOzs7OztZQUNMOzs7Ozs7R0FHTCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmO0tBRUUsd0JBQUMsVUFBRDtNQUNFLE1BQUs7TUFDTCxlQUFlLGVBQWUsT0FBTztNQUNyQyxXQUFXLGtEQUNULGdCQUFnQixVQUNaLHlFQUNBO2dCQU5SLENBU0Usd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBbUM7T0FFN0M7Ozs7aUJBQ04sd0JBQUMsVUFBRCxFQUFVLFdBQVUscUJBQXNCOzs7O2VBQ3ZDOzs7OztnQkFDTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUFzQixhQUFhO09BQWE7Ozs7aUJBQ2hFLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUF5QjtPQUFlOzs7O2VBQ3JEOzs7OztjQUNDOzs7Ozs7S0FHUix3QkFBQyxVQUFEO01BQ0UsTUFBSztNQUNMLGVBQWUsZUFBZSxVQUFVO01BQ3hDLFdBQVcsa0RBQ1QsZ0JBQWdCLGFBQ1oscURBQ0E7Z0JBTlIsQ0FTRSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUF3QjtPQUFxQjs7OztpQkFDN0Qsd0JBQUMsYUFBRCxFQUFhLFdBQVUsd0JBQXlCOzs7O2VBQzdDOzs7OztnQkFDTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUNiLFNBQVM7T0FDTjs7OztpQkFDTix3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBNkQ7T0FFdkU7Ozs7ZUFDSDs7Ozs7Y0FDQzs7Ozs7O0tBR1Isd0JBQUMsVUFBRDtNQUNFLE1BQUs7TUFDTCxlQUFlLGVBQWUsZUFBZTtNQUM3QyxXQUFXLGtEQUNULGdCQUFnQixrQkFDWix1REFDQTtnQkFOUixDQVNFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQXdCO09BQTBCOzs7O2lCQUNsRSx3QkFBQyxlQUFELEVBQWUsV0FBVSx5QkFBMEI7Ozs7ZUFDaEQ7Ozs7O2dCQUNMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQ2IsYUFBYTtPQUNWOzs7O2lCQUNOLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUE2RDtPQUV2RTs7OztlQUNIOzs7OztjQUNDOzs7Ozs7S0FHUix3QkFBQyxVQUFEO01BQ0UsTUFBSztNQUNMLGVBQWUsZUFBZSxXQUFXO01BQ3pDLFdBQVcsa0RBQ1QsZ0JBQWdCLGNBQ1osMkRBQ0E7Z0JBTlIsQ0FTRSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUF3QjtPQUE0Qjs7OztpQkFDcEUsd0JBQUMsY0FBRCxFQUFjLFdBQVUsMkJBQTRCOzs7O2VBQ2pEOzs7OztnQkFDTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUNiLFVBQVU7T0FDUDs7OztpQkFDTix3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBcUQ7T0FFL0Q7Ozs7ZUFDSDs7Ozs7Y0FDQzs7Ozs7O0lBQ0w7Ozs7OztHQUdMLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxRQUFELEVBQVEsV0FBVSxpREFBa0Q7Ozs7Z0JBQ3BFLHdCQUFDLFNBQUQ7T0FDRSxNQUFLO09BQ0wsYUFBWTtPQUNaLE9BQU87T0FDUCxXQUFXLE1BQU0sU0FBUyxFQUFFLE9BQU8sS0FBSztPQUN4QyxXQUFVO01BQ1g7Ozs7Y0FDRTs7Ozs7ZUFFTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZjtPQUFvRDtPQUN6Qyx3QkFBQyxVQUFELFlBQVMscUJBQXFCLE9BQWU7Ozs7O09BQUM7T0FBSTtPQUMxRCxhQUFhO09BQU87TUFDbEI7Ozs7O2FBQ0Y7Ozs7O2NBR0osWUFDQyx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsT0FBRCxFQUFLLFdBQVUsd0ZBQXlGOzs7O2VBQ3hHLHdCQUFDLFFBQUQsWUFBTSxtREFBc0Q7Ozs7YUFDekQ7Ozs7O2VBQ0gscUJBQXFCLFdBQVcsSUFDbEMsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZjtNQUNFLHdCQUFDLGNBQUQsRUFBYyxXQUFVLHFDQUFzQzs7Ozs7TUFDOUQsd0JBQUMsS0FBRDtPQUFHLFdBQVU7aUJBQXVEO01BRWpFOzs7OztNQUNILHdCQUFDLEtBQUQ7T0FBRyxXQUFVO2lCQUE2QjtNQUV2Qzs7Ozs7S0FDQTs7Ozs7ZUFFTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUNiLHdCQUFDLFNBQUQ7TUFBTyxXQUFVO2dCQUFqQixDQUNFLHdCQUFDLFNBQUQ7T0FBTyxXQUFVO2lCQUNmLHdCQUFDLE1BQUQ7UUFDRSx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFBYztRQUFxQjs7Ozs7UUFDakQsd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQWM7UUFBZ0I7Ozs7O1FBQzVDLHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUFjO1FBQThCOzs7OztRQUMxRCx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFBYztRQUFlOzs7OztRQUMzQyx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFBYztRQUFzQjs7Ozs7UUFDbEQsd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQXlCO1FBQXNCOzs7OztPQUMzRDs7Ozs7TUFDQzs7OztnQkFDUCx3QkFBQyxTQUFEO09BQU8sV0FBVTtpQkFDZCxxQkFBcUIsS0FBSyxTQUFTO1FBQ2xDLE1BQU0sWUFBWSxLQUFLLGlCQUFpQjtRQUN4QyxNQUFNLFdBQVcsS0FBSyxrQkFBa0IsS0FBSyxLQUFLLGtCQUFrQjtRQUVwRSxPQUNFLHdCQUFDLE1BQUQ7U0FFRSxXQUFVO21CQUZaO1VBS0Usd0JBQUMsTUFBRDtXQUFJLFdBQVU7cUJBQ1gsWUFDQyx3QkFBQyxPQUFEO1lBQUssV0FBVTtzQkFBZixDQUNFLHdCQUFDLGFBQUQsRUFBYSxXQUFVLDRCQUE2Qjs7OztzQkFDcEQsd0JBQUMsUUFBRDthQUFNO2FBQ1EsS0FBSyxJQUFJLEtBQUssY0FBYzthQUFFO1lBQ3RDOzs7O29CQUNIOzs7OztzQkFDSCxXQUNGLHdCQUFDLE9BQUQ7WUFBSyxXQUFVO3NCQUFmLENBQ0Usd0JBQUMsT0FBRCxFQUFPLFdBQVUsNkJBQThCOzs7O3NCQUMvQyx3QkFBQyxRQUFELFlBQ0csS0FBSyxtQkFBbUIsSUFDckIsZUFDQSxZQUFZLEtBQUssZUFBZSxTQUNoQzs7OztvQkFDSDs7Ozs7c0JBRUwsd0JBQUMsT0FBRDtZQUFLLFdBQVU7c0JBQWYsQ0FDRSx3QkFBQyxjQUFELEVBQWMsV0FBVSwrQkFBZ0M7Ozs7c0JBQ3hELHdCQUFDLFFBQUQsYUFBTyxLQUFLLGdCQUFlLGlCQUFxQjs7OztvQkFDN0M7Ozs7OztVQUVMOzs7OztVQUdKLHdCQUFDLE1BQUQ7V0FBSSxXQUFVO3FCQUNYLEtBQUs7VUFDSjs7Ozs7VUFHSix3QkFBQyxNQUFEO1dBQUksV0FBVTtxQkFDWix3QkFBQyxPQUFEO1lBQUssV0FBVTtzQkFBZixDQUNFLHdCQUFDLE1BQUQ7YUFDRSxJQUFJLE9BQU8saUJBQWlCLFFBQVEsS0FBSyxrQkFBa0I7YUFDM0QsV0FBVTt1QkFFVCxLQUFLO1lBQ0Y7Ozs7c0JBQ0wsS0FBSyxpQkFDSix3QkFBQyxRQUFEO2FBQU0sV0FBVTt1QkFDYixLQUFLO1lBQ0Y7Ozs7b0JBRUw7Ozs7OztVQUNIOzs7OztVQUdKLHdCQUFDLE1BQUQ7V0FBSSxXQUFVO3FCQUNaLHdCQUFDLE9BQUQ7WUFBSyxXQUFVO3NCQUFmLENBQ0Usd0JBQUMsVUFBRCxFQUFVLFdBQVUsNkJBQThCOzs7O3NCQUNsRCx3QkFBQyxRQUFELFlBQ0csSUFBSSxLQUFLLEtBQUsscUJBQXFCLENBQUMsQ0FBQyxtQkFDcEMsT0FDRixFQUNJOzs7O29CQUNIOzs7Ozs7VUFDSDs7Ozs7VUFHSix3QkFBQyxNQUFEO1dBQUksV0FBVTtxQkFDWix3QkFBQyxPQUFEO1lBQUssV0FBVTtzQkFBZixDQUNFLHdCQUFDLFdBQUQsRUFBVyxXQUFVLDZCQUE4Qjs7OztzQkFDbkQsd0JBQUMsUUFBRCxZQUFPLEtBQUssbUJBQXlCOzs7O29CQUNsQzs7Ozs7O1VBQ0g7Ozs7O1VBR0osd0JBQUMsTUFBRDtXQUFJLFdBQVU7cUJBQ1osd0JBQUMsT0FBRDtZQUFLLFdBQVU7c0JBQWYsQ0FDRSx3QkFBQyxNQUFEO2FBQ0UsSUFBSSxPQUFPLFVBQVUsTUFBTSxLQUFLLFdBQVc7YUFDM0MsV0FBVTthQUNWLE9BQU07dUJBRU4sd0JBQUMsVUFBRCxFQUFVLFdBQVUsVUFBVzs7Ozs7WUFDM0I7Ozs7c0JBRU4sd0JBQUMsVUFBRDthQUNFLE1BQUs7YUFDTCxlQUNFLGtCQUFrQjtjQUNoQixtQkFBbUIsS0FBSztjQUN4QixPQUFPLEtBQUs7YUFDZCxDQUFDO2FBRUgsV0FBVTt1QkFSWixDQVVFLHdCQUFDLFdBQUQsRUFBVyxXQUFVLGNBQWU7Ozs7dUJBQ3BDLHdCQUFDLFFBQUQsWUFBTSxxQkFBd0I7Ozs7cUJBQ3hCOzs7OztvQkFDTDs7Ozs7O1VBQ0g7Ozs7O1NBQ0Y7V0FqR0csS0FBSzs7OztlQWlHUjtPQUVSLENBQUM7TUFDSTs7OztjQUNGOzs7Ozs7SUFDSjs7OztZQUVKOzs7Ozs7R0FHSixrQkFDQyx3QkFBQyxzQkFBRDtJQUNFLFFBQVEsUUFBUSxjQUFjO0lBQzlCLGVBQWUsa0JBQWtCLElBQUk7SUFDckMsOEJBQThCLGVBQWU7SUFDN0MsbUJBQWtCO0dBQ25COzs7OztFQUVBOzs7Ozs7QUFFVDs7Ozs7QUFFQSxlQUFlIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIlBhaW5lbFByYXpvc1BhZ2UudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbIi8qKlxyXG4gKiBQYWluZWwgT3BlcmFjaW9uYWwgZGUgUHJhem9zIGUgTm90aWZpY2HDp8O1ZXMgU2FuaXTDoXJpYXMgUGVuZGVudGVzXHJcbiAqIFJvdGE6IC9maXNjYWxpemFjYW8vcHJhem9zXHJcbiAqIE1vbml0b3JhIGNvbnRhZ2VtIHJlZ3Jlc3NpdmEgZGUgcHJhem9zIGxlZ2FpcyBjb25jZWRpZG9zIGEgZXN0YWJlbGVjaW1lbnRvcyxcclxuICogY29tIGNhdGVnb3JpemHDp8OjbyBwb3IgZ3JhdmlkYWRlIGUgYXRhbGhvIHBhcmEgYWJlcnR1cmEgZGUgUmVpbnNwZcOnw6NvIEZpc2NhbC5cclxuICovXHJcblxyXG5pbXBvcnQgUmVhY3QsIHsgdXNlTWVtbywgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHsgTGluayB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCI7XHJcbmltcG9ydCB7XHJcbiAgQWxlcnRDaXJjbGUsXHJcbiAgQWxlcnRUcmlhbmdsZSxcclxuICBBcnJvd0xlZnQsXHJcbiAgQnVpbGRpbmcyLFxyXG4gIENhbGVuZGFyLFxyXG4gIENoZWNrQ2lyY2xlMixcclxuICBDbG9jayxcclxuICBFeHRlcm5hbExpbmssXHJcbiAgRmlsZVRleHQsXHJcbiAgRmlsdGVyLFxyXG4gIFJlZnJlc2hDdyxcclxuICBSb3RhdGVDY3csXHJcbiAgU2VhcmNoLFxyXG4gIFVzZXJDaGVjayxcclxufSBmcm9tIFwibHVjaWRlLXJlYWN0XCI7XHJcbmltcG9ydCB7IFJPVVRFUyB9IGZyb20gXCIuLi8uLi9jb25maWcvcm91dGVzLmNvbmZpZ1wiO1xyXG5pbXBvcnQgeyB1c2VOb3RpZmljYWNvZXNQZW5kZW50ZXMgfSBmcm9tIFwiLi4vLi4vaG9va3MvdXNlRmlzY2FsaXphY2FvXCI7XHJcbmltcG9ydCB7IE5vdGlmaWNhY2FvUHJhem9BbGVydGEgfSBmcm9tIFwiLi4vLi4vdHlwZXMvZmlzY2FsaXphY2FvXCI7XHJcbmltcG9ydCB7IEFnZW5kYXJJbnNwZWNhb01vZGFsIH0gZnJvbSBcIi4uLy4uL2NvbXBvbmVudHMvZmlzY2FsaXphY2FvL0FnZW5kYXJJbnNwZWNhb01vZGFsXCI7XHJcblxyXG50eXBlIEZpbHRyb1ByYXpvID0gXCJ0b2Rvc1wiIHwgXCJ2ZW5jaWRvc1wiIHwgXCJhbGVydGFfN19kaWFzXCIgfCBcInJlZ3VsYXJlc1wiO1xyXG5cclxuZXhwb3J0IGNvbnN0IFBhaW5lbFByYXpvc1BhZ2U6IFJlYWN0LkZDID0gKCkgPT4ge1xyXG4gIGNvbnN0IFtmaWx0cm9QcmF6bywgc2V0RmlsdHJvUHJhem9dID0gdXNlU3RhdGU8RmlsdHJvUHJhem8+KFwidG9kb3NcIik7XHJcbiAgY29uc3QgW2J1c2NhLCBzZXRCdXNjYV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbcmVpbnNwZWNhb0Fsdm8sIHNldFJlaW5zcGVjYW9BbHZvXSA9IHVzZVN0YXRlPHtcclxuICAgIGVzdGFiZWxlY2ltZW50b0lkOiBzdHJpbmc7XHJcbiAgICB0ZXJtbzogc3RyaW5nO1xyXG4gIH0gfCBudWxsPihudWxsKTtcclxuXHJcbiAgY29uc3Qge1xyXG4gICAgZGF0YTogbm90aWZpY2Fjb2VzID0gW10sXHJcbiAgICBpc0xvYWRpbmcsXHJcbiAgICBpc1JlZmV0Y2hpbmcsXHJcbiAgICByZWZldGNoLFxyXG4gIH0gPSB1c2VOb3RpZmljYWNvZXNQZW5kZW50ZXMoNjApO1xyXG5cclxuICAvLyBDbGFzc2lmaWNhw6fDo28gcG9yIHNldmVyaWRhZGVcclxuICBjb25zdCB7IHZlbmNpZGFzLCBhbGVydGFzN2RpYXMsIHJlZ3VsYXJlcyB9ID0gdXNlTWVtbygoKSA9PiB7XHJcbiAgICBjb25zdCB2OiBOb3RpZmljYWNhb1ByYXpvQWxlcnRhW10gPSBbXTtcclxuICAgIGNvbnN0IGE6IE5vdGlmaWNhY2FvUHJhem9BbGVydGFbXSA9IFtdO1xyXG4gICAgY29uc3QgcjogTm90aWZpY2FjYW9QcmF6b0FsZXJ0YVtdID0gW107XHJcblxyXG4gICAgbm90aWZpY2Fjb2VzLmZvckVhY2goKGl0ZW0pID0+IHtcclxuICAgICAgaWYgKGl0ZW0uZGlhc19yZXN0YW50ZXMgPCAwKSB7XHJcbiAgICAgICAgdi5wdXNoKGl0ZW0pO1xyXG4gICAgICB9IGVsc2UgaWYgKGl0ZW0uZGlhc19yZXN0YW50ZXMgPD0gNykge1xyXG4gICAgICAgIGEucHVzaChpdGVtKTtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICByLnB1c2goaXRlbSk7XHJcbiAgICAgIH1cclxuICAgIH0pO1xyXG5cclxuICAgIHJldHVybiB7IHZlbmNpZGFzOiB2LCBhbGVydGFzN2RpYXM6IGEsIHJlZ3VsYXJlczogciB9O1xyXG4gIH0sIFtub3RpZmljYWNvZXNdKTtcclxuXHJcbiAgLy8gTGlzdGEgZmlsdHJhZGFcclxuICBjb25zdCBub3RpZmljYWNvZXNFeGliaWRhcyA9IHVzZU1lbW8oKCkgPT4ge1xyXG4gICAgbGV0IGJhc2UgPSBub3RpZmljYWNvZXM7XHJcbiAgICBpZiAoZmlsdHJvUHJhem8gPT09IFwidmVuY2lkb3NcIikgYmFzZSA9IHZlbmNpZGFzO1xyXG4gICAgZWxzZSBpZiAoZmlsdHJvUHJhem8gPT09IFwiYWxlcnRhXzdfZGlhc1wiKSBiYXNlID0gYWxlcnRhczdkaWFzO1xyXG4gICAgZWxzZSBpZiAoZmlsdHJvUHJhem8gPT09IFwicmVndWxhcmVzXCIpIGJhc2UgPSByZWd1bGFyZXM7XHJcblxyXG4gICAgaWYgKCFidXNjYSkgcmV0dXJuIGJhc2U7XHJcblxyXG4gICAgY29uc3QgdGVybW8gPSBidXNjYS50b0xvd2VyQ2FzZSgpO1xyXG4gICAgcmV0dXJuIGJhc2UuZmlsdGVyKFxyXG4gICAgICAobikgPT5cclxuICAgICAgICBuLm51bWVyb190ZXJtby50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKHRlcm1vKSB8fFxyXG4gICAgICAgIG4ucmF6YW9fc29jaWFsLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXModGVybW8pIHx8XHJcbiAgICAgICAgKG4ubm9tZV9mYW50YXNpYSAmJiBuLm5vbWVfZmFudGFzaWEudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyh0ZXJtbykpIHx8XHJcbiAgICAgICAgbi5maXNjYWxfcmVzcG9uc2F2ZWwudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyh0ZXJtbylcclxuICAgICk7XHJcbiAgfSwgW25vdGlmaWNhY29lcywgdmVuY2lkYXMsIGFsZXJ0YXM3ZGlhcywgcmVndWxhcmVzLCBmaWx0cm9QcmF6bywgYnVzY2FdKTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS02XCI+XHJcbiAgICAgIHsvKiBDYWJlw6dhbGhvICovfVxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgc206ZmxleC1yb3cgc206aXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtNCBiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC0yeGwgcC02IHNoYWRvdy14c1wiPlxyXG4gICAgICAgIDxkaXY+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIG1iLTFcIj5cclxuICAgICAgICAgICAgPExpbmtcclxuICAgICAgICAgICAgICB0bz17Uk9VVEVTLklOU1BFQ09FUy5MSVNUfVxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTUwMCBob3Zlcjp0ZXh0LXRlYWwtNjAwIHRyYW5zaXRpb24tY29sb3JzXCJcclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIDxBcnJvd0xlZnQgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPlxyXG4gICAgICAgICAgICAgIDxzcGFuPlZvbHRhciBwYXJhIEluc3Blw6fDtWVzPC9zcGFuPlxyXG4gICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGUgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgPENsb2NrIGNsYXNzTmFtZT1cInctNSBoLTUgdGV4dC1hbWJlci01MDBcIiAvPlxyXG4gICAgICAgICAgICA8c3Bhbj5QYWluZWwgZGUgUHJhem9zICYgTm90aWZpY2HDp8O1ZXMgU2FuaXTDoXJpYXM8L3NwYW4+XHJcbiAgICAgICAgICA8L2gxPlxyXG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTUwMCBkYXJrOnRleHQtc2xhdGUtNDAwIG10LTEgbWF4LXctMnhsXCI+XHJcbiAgICAgICAgICAgIE1vbml0b3JhbWVudG8gZGUgY29udGFnZW0gcmVncmVzc2l2YSBwYXJhIHJlZ3VsYXJpemHDp8OjbyBkZSBlc3RhYmVsZWNpbWVudG9zIG5vdGlmaWNhZG9zIGVtIGF1dG9zIGZpc2NhaXMuXHJcbiAgICAgICAgICA8L3A+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIDxidXR0b25cclxuICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgb25DbGljaz17KCkgPT4gcmVmZXRjaCgpfVxyXG4gICAgICAgICAgZGlzYWJsZWQ9e2lzUmVmZXRjaGluZ31cclxuICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTMgcHktMS41IHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMjAwIGJnLXNsYXRlLTUwIGRhcms6Ymctc2xhdGUtODAwIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCByb3VuZGVkLXhsIGhvdmVyOmJnLXNsYXRlLTEwMCBkYXJrOmhvdmVyOmJnLXNsYXRlLTcwMCB0cmFuc2l0aW9uLWNvbG9ycyBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHNoYWRvdy0yeHMgc2VsZi1zdGFydCBzbTpzZWxmLWNlbnRlclwiXHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgPFJlZnJlc2hDd1xyXG4gICAgICAgICAgICBjbGFzc05hbWU9e2B3LTMuNSBoLTMuNSAke2lzUmVmZXRjaGluZyA/IFwiYW5pbWF0ZS1zcGluIHRleHQtdGVhbC02MDBcIiA6IFwiXCJ9YH1cclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgICA8c3Bhbj5BdHVhbGl6YXIgUHJhem9zPC9zcGFuPlxyXG4gICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIHsvKiBDYXJkcyBkZSBNw6l0cmljYXMgZGUgUHJhem9zICovfVxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgc206Z3JpZC1jb2xzLTIgbGc6Z3JpZC1jb2xzLTQgZ2FwLTRcIj5cclxuICAgICAgICB7LyogVG9kYXMgKi99XHJcbiAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRGaWx0cm9QcmF6byhcInRvZG9zXCIpfVxyXG4gICAgICAgICAgY2xhc3NOYW1lPXtgdGV4dC1sZWZ0IHAtNCByb3VuZGVkLXhsIGJvcmRlciB0cmFuc2l0aW9uLWFsbCAke1xyXG4gICAgICAgICAgICBmaWx0cm9QcmF6byA9PT0gXCJ0b2Rvc1wiXHJcbiAgICAgICAgICAgICAgPyBcImJnLXNsYXRlLTkwMCB0ZXh0LXdoaXRlIGJvcmRlci1zbGF0ZS05MDAgc2hhZG93LXhzIGRhcms6Ymctc2xhdGUtODAwXCJcclxuICAgICAgICAgICAgICA6IFwiYmctd2hpdGUgZGFyazpiZy1zbGF0ZS05MDAgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtODAwIGhvdmVyOmJvcmRlci1zbGF0ZS0zMDBcIlxyXG4gICAgICAgICAgfWB9XHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIG9wYWNpdHktODBcIj5cclxuICAgICAgICAgICAgICBUb3RhbCBOb3RpZmljYWRhc1xyXG4gICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgIDxGaWxlVGV4dCBjbGFzc05hbWU9XCJ3LTQgaC00IG9wYWNpdHktNzBcIiAvPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTIgZmxleCBpdGVtcy1iYXNlbGluZSBnYXAtMlwiPlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGRcIj57bm90aWZpY2Fjb2VzLmxlbmd0aH08L3NwYW4+XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIG9wYWNpdHktNzBcIj5wcm9jZXNzb3M8L3NwYW4+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2J1dHRvbj5cclxuXHJcbiAgICAgICAgey8qIFZlbmNpZGFzICovfVxyXG4gICAgICAgIDxidXR0b25cclxuICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0RmlsdHJvUHJhem8oXCJ2ZW5jaWRvc1wiKX1cclxuICAgICAgICAgIGNsYXNzTmFtZT17YHRleHQtbGVmdCBwLTQgcm91bmRlZC14bCBib3JkZXIgdHJhbnNpdGlvbi1hbGwgJHtcclxuICAgICAgICAgICAgZmlsdHJvUHJhem8gPT09IFwidmVuY2lkb3NcIlxyXG4gICAgICAgICAgICAgID8gXCJiZy1yb3NlLTYwMCB0ZXh0LXdoaXRlIGJvcmRlci1yb3NlLTYwMCBzaGFkb3cteHNcIlxyXG4gICAgICAgICAgICAgIDogXCJiZy1yb3NlLTUwLzcwIGRhcms6Ymctcm9zZS05NTAvMjAgdGV4dC1yb3NlLTkwMCBkYXJrOnRleHQtcm9zZS0yMDAgYm9yZGVyLXJvc2UtMjAwIGRhcms6Ym9yZGVyLXJvc2UtOTAwLzQwIGhvdmVyOmJvcmRlci1yb3NlLTMwMFwiXHJcbiAgICAgICAgICB9YH1cclxuICAgICAgICA+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGRcIj5QcmF6b3MgVmVuY2lkb3M8L3NwYW4+XHJcbiAgICAgICAgICAgIDxBbGVydENpcmNsZSBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtcm9zZS02MDBcIiAvPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTIgZmxleCBpdGVtcy1iYXNlbGluZSBnYXAtMlwiPlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGQgdGV4dC1yb3NlLTcwMCBkYXJrOnRleHQtcm9zZS00MDBcIj5cclxuICAgICAgICAgICAgICB7dmVuY2lkYXMubGVuZ3RofVxyXG4gICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1yb3NlLTYwMCBkYXJrOnRleHQtcm9zZS00MDBcIj5cclxuICAgICAgICAgICAgICB1cmdlbnRlXHJcbiAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvYnV0dG9uPlxyXG5cclxuICAgICAgICB7LyogQWxlcnRhIDw9IDcgZGlhcyAqL31cclxuICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEZpbHRyb1ByYXpvKFwiYWxlcnRhXzdfZGlhc1wiKX1cclxuICAgICAgICAgIGNsYXNzTmFtZT17YHRleHQtbGVmdCBwLTQgcm91bmRlZC14bCBib3JkZXIgdHJhbnNpdGlvbi1hbGwgJHtcclxuICAgICAgICAgICAgZmlsdHJvUHJhem8gPT09IFwiYWxlcnRhXzdfZGlhc1wiXHJcbiAgICAgICAgICAgICAgPyBcImJnLWFtYmVyLTYwMCB0ZXh0LXdoaXRlIGJvcmRlci1hbWJlci02MDAgc2hhZG93LXhzXCJcclxuICAgICAgICAgICAgICA6IFwiYmctYW1iZXItNTAvNzAgZGFyazpiZy1hbWJlci05NTAvMjAgdGV4dC1hbWJlci05MDAgZGFyazp0ZXh0LWFtYmVyLTIwMCBib3JkZXItYW1iZXItMjAwIGRhcms6Ym9yZGVyLWFtYmVyLTkwMC80MCBob3Zlcjpib3JkZXItYW1iZXItMzAwXCJcclxuICAgICAgICAgIH1gfVxyXG4gICAgICAgID5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1zZW1pYm9sZFwiPlZlbmNlbSBlbSBhdMOpIDcgZGlhczwvc3Bhbj5cclxuICAgICAgICAgICAgPEFsZXJ0VHJpYW5nbGUgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LWFtYmVyLTYwMFwiIC8+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMiBmbGV4IGl0ZW1zLWJhc2VsaW5lIGdhcC0yXCI+XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LWFtYmVyLTcwMCBkYXJrOnRleHQtYW1iZXItNDAwXCI+XHJcbiAgICAgICAgICAgICAge2FsZXJ0YXM3ZGlhcy5sZW5ndGh9XHJcbiAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1hbWJlci02MDAgZGFyazp0ZXh0LWFtYmVyLTQwMCBmb250LW1lZGl1bVwiPlxyXG4gICAgICAgICAgICAgIGF0ZW7Dp8Ojb1xyXG4gICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2J1dHRvbj5cclxuXHJcbiAgICAgICAgey8qIFJlZ3VsYXJlcyA+IDcgZGlhcyAqL31cclxuICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEZpbHRyb1ByYXpvKFwicmVndWxhcmVzXCIpfVxyXG4gICAgICAgICAgY2xhc3NOYW1lPXtgdGV4dC1sZWZ0IHAtNCByb3VuZGVkLXhsIGJvcmRlciB0cmFuc2l0aW9uLWFsbCAke1xyXG4gICAgICAgICAgICBmaWx0cm9QcmF6byA9PT0gXCJyZWd1bGFyZXNcIlxyXG4gICAgICAgICAgICAgID8gXCJiZy1lbWVyYWxkLTYwMCB0ZXh0LXdoaXRlIGJvcmRlci1lbWVyYWxkLTYwMCBzaGFkb3cteHNcIlxyXG4gICAgICAgICAgICAgIDogXCJiZy1lbWVyYWxkLTUwLzcwIGRhcms6YmctZW1lcmFsZC05NTAvMjAgdGV4dC1lbWVyYWxkLTkwMCBkYXJrOnRleHQtZW1lcmFsZC0yMDAgYm9yZGVyLWVtZXJhbGQtMjAwIGRhcms6Ym9yZGVyLWVtZXJhbGQtOTAwLzQwIGhvdmVyOmJvcmRlci1lbWVyYWxkLTMwMFwiXHJcbiAgICAgICAgICB9YH1cclxuICAgICAgICA+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGRcIj5ObyBQcmF6byAoJmd0OyA3IGRpYXMpPC9zcGFuPlxyXG4gICAgICAgICAgICA8Q2hlY2tDaXJjbGUyIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1lbWVyYWxkLTYwMFwiIC8+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMiBmbGV4IGl0ZW1zLWJhc2VsaW5lIGdhcC0yXCI+XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LWVtZXJhbGQtNzAwIGRhcms6dGV4dC1lbWVyYWxkLTQwMFwiPlxyXG4gICAgICAgICAgICAgIHtyZWd1bGFyZXMubGVuZ3RofVxyXG4gICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtZW1lcmFsZC02MDAgZGFyazp0ZXh0LWVtZXJhbGQtNDAwXCI+XHJcbiAgICAgICAgICAgICAgYWNvbXBhbmhhbmRvXHJcbiAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIHsvKiBDYWl4YSBkZSBCdXNjYSBlIFRhYmVsYSAqL31cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC0yeGwgc2hhZG93LXhzIG92ZXJmbG93LWhpZGRlblwiPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC00IGJnLXNsYXRlLTUwLzUwIGRhcms6Ymctc2xhdGUtODAwLzQwIGJvcmRlci1iIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtODAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtNFwiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBmbGV4LTEgbWF4LXctbWRcIj5cclxuICAgICAgICAgICAgPFNlYXJjaCBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtc2xhdGUtNDAwIGFic29sdXRlIGxlZnQtMyB0b3AtMi41XCIgLz5cclxuICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiQnVzY2FyIHBvciB0ZXJtbyBmaXNjYWwsIHJhesOjbyBzb2NpYWwgb3UgZmlzY2FsLi4uXCJcclxuICAgICAgICAgICAgICB2YWx1ZT17YnVzY2F9XHJcbiAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRCdXNjYShlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHBsLTkgcHItNCBweS0yIHRleHQteHMgYmctd2hpdGUgZGFyazpiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQteGwgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlIHBsYWNlaG9sZGVyLXNsYXRlLTQwMCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctYW1iZXItNTAwXCJcclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTUwMCBmb250LW1lZGl1bVwiPlxyXG4gICAgICAgICAgICBFeGliaW5kbyA8c3Ryb25nPntub3RpZmljYWNvZXNFeGliaWRhcy5sZW5ndGh9PC9zdHJvbmc+IGRle1wiIFwifVxyXG4gICAgICAgICAgICB7bm90aWZpY2Fjb2VzLmxlbmd0aH0gbm90aWZpY2HDp8O1ZXNcclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICB7LyogVGFiZWxhIGRlIE5vdGlmaWNhw6fDtWVzICovfVxyXG4gICAgICAgIHtpc0xvYWRpbmcgPyAoXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMTYgdGV4dC1jZW50ZXIgdGV4dC1zbGF0ZS00MDAgdGV4dC14cyBmbGV4IGZsZXgtY29sIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlclwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctNiBoLTYgYm9yZGVyLTIgYm9yZGVyLWFtYmVyLTUwMCBib3JkZXItdC10cmFuc3BhcmVudCByb3VuZGVkLWZ1bGwgYW5pbWF0ZS1zcGluIG1iLTNcIiAvPlxyXG4gICAgICAgICAgICA8c3Bhbj5Db25zdWx0YW5kbyBwcmF6b3MgZGUgbm90aWZpY2HDp8O1ZXMgc2FuaXTDoXJpYXMuLi48L3NwYW4+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICApIDogbm90aWZpY2Fjb2VzRXhpYmlkYXMubGVuZ3RoID09PSAwID8gKFxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTEyIHRleHQtY2VudGVyIHRleHQtc2xhdGUtNTAwIGRhcms6dGV4dC1zbGF0ZS00MDAgc3BhY2UteS0yXCI+XHJcbiAgICAgICAgICAgIDxDaGVja0NpcmNsZTIgY2xhc3NOYW1lPVwidy0xMCBoLTEwIHRleHQtZW1lcmFsZC01MDAgbXgtYXV0b1wiIC8+XHJcbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHRleHQtc2xhdGUtODAwIGRhcms6dGV4dC1zbGF0ZS0yMDBcIj5cclxuICAgICAgICAgICAgICBOZW5odW1hIG5vdGlmaWNhw6fDo28gc2FuaXTDoXJpYSBwZW5kZW50ZSBwYXJhIGVzdGUgZmlsdHJvLlxyXG4gICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtc2xhdGUtNDAwXCI+XHJcbiAgICAgICAgICAgICAgVG9kb3Mgb3MgcHJhem9zIGxlZ2FpcyBlc3TDo28gZGV2aWRhbWVudGUgc2FuYWRvcyBvdSBzZW0gcGVuZMOqbmNpYXMgcmVnaXN0cmFkYXMuXHJcbiAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICkgOiAoXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm92ZXJmbG93LXgtYXV0b1wiPlxyXG4gICAgICAgICAgICA8dGFibGUgY2xhc3NOYW1lPVwidy1mdWxsIHRleHQtbGVmdCB0ZXh0LXhzIGJvcmRlci1jb2xsYXBzZVwiPlxyXG4gICAgICAgICAgICAgIDx0aGVhZCBjbGFzc05hbWU9XCJiZy1zbGF0ZS01MC84MCBkYXJrOmJnLXNsYXRlLTgwMC82MCBib3JkZXItYiBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCB0ZXh0LXNsYXRlLTUwMCBkYXJrOnRleHQtc2xhdGUtNDAwIGZvbnQtc2VtaWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCI+XHJcbiAgICAgICAgICAgICAgICA8dHI+XHJcbiAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0zLjUgcHgtNFwiPkNvbnRhZ2VtIC8gQWxlcnRhPC90aD5cclxuICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB5LTMuNSBweC00XCI+VGVybW8gRmlzY2FsPC90aD5cclxuICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB5LTMuNSBweC00XCI+RXN0YWJlbGVjaW1lbnRvIE5vdGlmaWNhZG88L3RoPlxyXG4gICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMy41IHB4LTRcIj5EYXRhIExpbWl0ZTwvdGg+XHJcbiAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0zLjUgcHgtNFwiPkZpc2NhbCBSZXNwb25zw6F2ZWw8L3RoPlxyXG4gICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMy41IHB4LTQgdGV4dC1yaWdodFwiPkHDp8O1ZXMgT3BlcmFjaW9uYWlzPC90aD5cclxuICAgICAgICAgICAgICAgIDwvdHI+XHJcbiAgICAgICAgICAgICAgPC90aGVhZD5cclxuICAgICAgICAgICAgICA8dGJvZHkgY2xhc3NOYW1lPVwiZGl2aWRlLXkgZGl2aWRlLXNsYXRlLTEwMCBkYXJrOmRpdmlkZS1zbGF0ZS04MDBcIj5cclxuICAgICAgICAgICAgICAgIHtub3RpZmljYWNvZXNFeGliaWRhcy5tYXAoKGl0ZW0pID0+IHtcclxuICAgICAgICAgICAgICAgICAgY29uc3QgaXNWZW5jaWRhID0gaXRlbS5kaWFzX3Jlc3RhbnRlcyA8IDA7XHJcbiAgICAgICAgICAgICAgICAgIGNvbnN0IGlzQWxlcnRhID0gaXRlbS5kaWFzX3Jlc3RhbnRlcyA+PSAwICYmIGl0ZW0uZGlhc19yZXN0YW50ZXMgPD0gNztcclxuXHJcbiAgICAgICAgICAgICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPHRyXHJcbiAgICAgICAgICAgICAgICAgICAgICBrZXk9e2l0ZW0uaW5zcGVjYW9faWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJob3ZlcjpiZy1zbGF0ZS01MC82MCBkYXJrOmhvdmVyOmJnLXNsYXRlLTgwMC80MCB0cmFuc2l0aW9uLWNvbG9yc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgey8qIENvbnRhZ2VtIC8gQWxlcnRhICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTMuNSBweC00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtpc1ZlbmNpZGEgPyAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBweC0yLjUgcHktMSByb3VuZGVkLWxnIHRleHQteHMgZm9udC1ib2xkIGJnLXJvc2UtMTAwIGRhcms6Ymctcm9zZS05NTAvNjAgdGV4dC1yb3NlLTgwMCBkYXJrOnRleHQtcm9zZS0zMDAgYm9yZGVyIGJvcmRlci1yb3NlLTMwMCBkYXJrOmJvcmRlci1yb3NlLTgwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEFsZXJ0Q2lyY2xlIGNsYXNzTmFtZT1cInctMy41IGgtMy41IHRleHQtcm9zZS02MDBcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFZFTkNJRE8gSMOBIHtNYXRoLmFicyhpdGVtLmRpYXNfcmVzdGFudGVzKX0gRElBKFMpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICkgOiBpc0FsZXJ0YSA/IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHB4LTIuNSBweS0xIHJvdW5kZWQtbGcgdGV4dC14cyBmb250LWJvbGQgYmctYW1iZXItMTAwIGRhcms6YmctYW1iZXItOTUwLzYwIHRleHQtYW1iZXItODAwIGRhcms6dGV4dC1hbWJlci0zMDAgYm9yZGVyIGJvcmRlci1hbWJlci0zMDAgZGFyazpib3JkZXItYW1iZXItODAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Q2xvY2sgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjUgdGV4dC1hbWJlci02MDBcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpdGVtLmRpYXNfcmVzdGFudGVzID09PSAwXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBcIlZFTkNFIEhPSkVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogYFJFU1RBKE0pICR7aXRlbS5kaWFzX3Jlc3RhbnRlc30gRElBKFMpYH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHB4LTIuNSBweS0xIHJvdW5kZWQtbGcgdGV4dC14cyBmb250LW1lZGl1bSBiZy1lbWVyYWxkLTEwMCBkYXJrOmJnLWVtZXJhbGQtOTUwLzYwIHRleHQtZW1lcmFsZC04MDAgZGFyazp0ZXh0LWVtZXJhbGQtMzAwIGJvcmRlciBib3JkZXItZW1lcmFsZC0zMDAgZGFyazpib3JkZXItZW1lcmFsZC04MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxDaGVja0NpcmNsZTIgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjUgdGV4dC1lbWVyYWxkLTYwMFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj57aXRlbS5kaWFzX3Jlc3RhbnRlc30gZGlhcyByZXN0YW50ZXM8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgIHsvKiBUZXJtbyBGaXNjYWwgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMy41IHB4LTQgZm9udC1tb25vIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2l0ZW0ubnVtZXJvX3Rlcm1vfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC90ZD5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICB7LyogRXN0YWJlbGVjaW1lbnRvICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTMuNSBweC00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxMaW5rXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0bz17Uk9VVEVTLkVTVEFCRUxFQ0lNRU5UT1MuREVUQUxIRShpdGVtLmVzdGFiZWxlY2ltZW50b19pZCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1zbGF0ZS04MDAgZGFyazp0ZXh0LXNsYXRlLTIwMCBob3Zlcjp0ZXh0LXRlYWwtNjAwIGRhcms6aG92ZXI6dGV4dC10ZWFsLTQwMCB0cmFuc2l0aW9uLWNvbG9yc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2l0ZW0ucmF6YW9fc29jaWFsfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7aXRlbS5ub21lX2ZhbnRhc2lhICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtc2xhdGUtNDAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpdGVtLm5vbWVfZmFudGFzaWF9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgIHsvKiBEYXRhIExpbWl0ZSAqL31cclxuICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS0zLjUgcHgtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0zMDAgZm9udC1zZW1pYm9sZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxDYWxlbmRhciBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNSB0ZXh0LXNsYXRlLTQwMFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7bmV3IERhdGUoaXRlbS5kYXRhX2xpbWl0ZV9hZGVxdWFjYW8pLnRvTG9jYWxlRGF0ZVN0cmluZyhcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJwdC1CUlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgIHsvKiBGaXNjYWwgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMy41IHB4LTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHRleHQtc2xhdGUtNjAwIGRhcms6dGV4dC1zbGF0ZS0zMDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8VXNlckNoZWNrIGNsYXNzTmFtZT1cInctMy41IGgtMy41IHRleHQtc2xhdGUtNDAwXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj57aXRlbS5maXNjYWxfcmVzcG9uc2F2ZWx9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgey8qIEHDp8O1ZXMgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMy41IHB4LTQgdGV4dC1yaWdodFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktZW5kIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPExpbmtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvPXtST1VURVMuSU5TUEVDT0VTLkxBVURPKGl0ZW0uaW5zcGVjYW9faWQpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0xLjUgdGV4dC1zbGF0ZS01MDAgaG92ZXI6dGV4dC10ZWFsLTYwMCBkYXJrOnRleHQtc2xhdGUtNDAwIHJvdW5kZWQtbGcgaG92ZXI6Ymctc2xhdGUtMTAwIGRhcms6aG92ZXI6Ymctc2xhdGUtODAwIHRyYW5zaXRpb24tY29sb3JzXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiVmlzdWFsaXphciBsYXVkbyBlIHRlcm1vIG9yaWdpbmFsXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RmlsZVRleHQgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9MaW5rPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldFJlaW5zcGVjYW9BbHZvKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBlc3RhYmVsZWNpbWVudG9JZDogaXRlbS5lc3RhYmVsZWNpbWVudG9faWQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGVybW86IGl0ZW0ubnVtZXJvX3Rlcm1vLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtMyBweS0xLjUgdGV4dC14cyBmb250LWJvbGQgdGV4dC10ZWFsLTcwMCBkYXJrOnRleHQtdGVhbC0zMDAgYmctdGVhbC01MCBkYXJrOmJnLXRlYWwtOTUwLzQwIGJvcmRlciBib3JkZXItdGVhbC0yMDAgZGFyazpib3JkZXItdGVhbC04MDAgcm91bmRlZC1sZyBob3ZlcjpiZy10ZWFsLTEwMC82MCBzaGFkb3ctMnhzIHRyYW5zaXRpb24tY29sb3JzIGlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Um90YXRlQ2N3IGNsYXNzTmFtZT1cInctMy41IGgtMy41XCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPkFnZW5kYXIgUmVpbnNwZcOnw6NvPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgPC90cj5cclxuICAgICAgICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgICAgIH0pfVxyXG4gICAgICAgICAgICAgIDwvdGJvZHk+XHJcbiAgICAgICAgICAgIDwvdGFibGU+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICApfVxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIHsvKiBNb2RhbCBkZSBBYmVydHVyYSBkZSBSZWluc3Blw6fDo28gKi99XHJcbiAgICAgIHtyZWluc3BlY2FvQWx2byAmJiAoXHJcbiAgICAgICAgPEFnZW5kYXJJbnNwZWNhb01vZGFsXHJcbiAgICAgICAgICBpc09wZW49e0Jvb2xlYW4ocmVpbnNwZWNhb0Fsdm8pfVxyXG4gICAgICAgICAgb25DbG9zZT17KCkgPT4gc2V0UmVpbnNwZWNhb0Fsdm8obnVsbCl9XHJcbiAgICAgICAgICBlc3RhYmVsZWNpbWVudG9JZFByZURlZmluaWRvPXtyZWluc3BlY2FvQWx2by5lc3RhYmVsZWNpbWVudG9JZH1cclxuICAgICAgICAgIG1vdGl2b1ByZURlZmluaWRvPVwicmVpbnNwZWNhb1wiXHJcbiAgICAgICAgLz5cclxuICAgICAgKX1cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBQYWluZWxQcmF6b3NQYWdlO1xyXG4iXX0=