import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/fiscalizacao/InspecoesListPage.tsx");const React = __vite__cjsImport0_react; const useMemo = __vite__cjsImport0_react["useMemo"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport8_react_jsxDevRuntime["jsxDEV"];/**
* Página Principal do Módulo de Fiscalização & Inspeções Sanitárias
* Listagem com filtros por abas, busca textual, métricas operacionais,
* indicadores VAPT (Indicador 11) e acesso ao Painel de Prazos.
*/
import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=0fd2848a";
import { Link, useNavigate, useSearchParams } from "/node_modules/.vite/deps/react-router-dom.js?v=0fd2848a";
import { CheckCircle2, Clock, FileText, Filter, HardHat, Plus, RefreshCw, Search, ShieldAlert } from "/node_modules/.vite/deps/lucide-react.js?v=0fd2848a";
import { ROUTES } from "/src/config/routes.config.ts";
import { useIndicador11Vapt, useInspecoesList, useNotificacoesPendentes } from "/src/hooks/useFiscalizacao.ts";
import { StatusInspecaoBadge } from "/src/components/fiscalizacao/StatusInspecaoBadge.tsx";
import { ResultadoInspecaoBadge } from "/src/components/fiscalizacao/ResultadoInspecaoBadge.tsx";
import { AgendarInspecaoModal } from "/src/components/fiscalizacao/AgendarInspecaoModal.tsx";
var _jsxFileName = "E:/Projetos VSCODE/visa_braunas/src/pages/fiscalizacao/InspecoesListPage.tsx";
import __vite__cjsImport8_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=0fd2848a";
var _s = $RefreshSig$();
export const InspecoesListPage = () => {
	_s();
	const navigate = useNavigate();
	const [searchParams, setSearchParams] = useSearchParams();
	const estabelecimentoIdParam = searchParams.get("estabelecimento_id") || "";
	const [tabAtiva, setTabAtiva] = useState("todas");
	const [busca, setBusca] = useState("");
	const [motivoFiltro, setMotivoFiltro] = useState("");
	const [modalNovaAberta, setModalNovaAberta] = useState(false);
	// Consultas via React Query v5
	const { data: inspecoes = [], isLoading, isRefetching, refetch } = useInspecoesList({
		estabelecimento_id: estabelecimentoIdParam || undefined,
		motivo: tabAtiva === "vapt" ? "vapt_trabalhador" : motivoFiltro || undefined,
		status: tabAtiva === "agendadas" ? "agendada" : tabAtiva === "em_andamento" ? "em_andamento" : tabAtiva === "concluidas" ? "concluida" : undefined
	});
	const { data: notificacoes = [] } = useNotificacoesPendentes(30);
	const { data: indicadorVapt = [] } = useIndicador11Vapt(new Date().getFullYear());
	// Métricas rápidas
	const totalNotificacoesVencidas = notificacoes.filter((n) => n.dias_restantes < 0).length;
	const totalAcoesVapt = indicadorVapt[0]?.total_acoes_vapt ?? 0;
	// Filtragem local complementar para busca rápida por texto (número do termo ou ID)
	const inspecoesFiltradas = useMemo(() => {
		return inspecoes.filter((item) => {
			const matchBusca = !busca || item.numero_termo.toLowerCase().includes(busca.toLowerCase()) || item.motivo.toLowerCase().includes(busca.toLowerCase()) || item.nome_local_trabalho && item.nome_local_trabalho.toLowerCase().includes(busca.toLowerCase());
			return matchBusca;
		});
	}, [inspecoes, busca]);
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-xs",
				children: [/* @__PURE__ */ _jsxDEV("div", { children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-2 text-teal-600 dark:text-teal-400 mb-1",
						children: /* @__PURE__ */ _jsxDEV("span", {
							className: "text-[11px] font-bold uppercase tracking-wider bg-teal-50 dark:bg-teal-950/40 px-2 py-0.5 rounded border border-teal-200 dark:border-teal-800",
							children: "Módulo de Campo & Fiscalização"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 97,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 96,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("h1", {
						className: "text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2",
						children: "Inspeções Sanitárias & Vistorias Fiscais"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 101,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("p", {
						className: "text-xs text-slate-500 dark:text-slate-400 mt-1 max-w-2xl",
						children: "Gestão operacional de autos de inspeção, checklists de boas práticas, laudos periciais e monitoramento do Indicador 11 de Saúde do Trabalhador (VAPT)."
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 104,
						columnNumber: 11
					}, this)
				] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 95,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-2.5",
					children: [/* @__PURE__ */ _jsxDEV(Link, {
						to: ROUTES.INSPECOES.PRAZOS,
						className: "px-3.5 py-2 text-xs font-semibold text-amber-800 dark:text-amber-200 bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800/80 rounded-xl hover:bg-amber-100/60 shadow-2xs flex items-center gap-2 transition-colors",
						children: [
							/* @__PURE__ */ _jsxDEV(Clock, { className: "w-4 h-4 text-amber-600 dark:text-amber-400" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 114,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("span", { children: "Painel de Prazos" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 115,
								columnNumber: 13
							}, this),
							notificacoes.length > 0 && /* @__PURE__ */ _jsxDEV("span", {
								className: "px-1.5 py-0.2 rounded-full text-[10px] font-bold bg-amber-600 text-white",
								children: notificacoes.length
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 117,
								columnNumber: 15
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 110,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						onClick: () => setModalNovaAberta(true),
						className: "px-4 py-2 text-xs font-bold text-white bg-teal-600 hover:bg-teal-700 rounded-xl shadow-xs flex items-center gap-2 transition-colors",
						children: [/* @__PURE__ */ _jsxDEV(Plus, { className: "w-4 h-4" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 128,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Nova Inspeção" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 129,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 123,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 109,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 94,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 shadow-2xs",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center justify-between",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-xs font-semibold text-slate-500 dark:text-slate-400",
								children: "Vistorias no Período"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 139,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV(FileText, { className: "w-4 h-4 text-teal-600 dark:text-teal-400" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 142,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 138,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "mt-2 flex items-baseline gap-2",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-2xl font-bold text-slate-900 dark:text-white",
								children: inspecoes.length
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 145,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "text-[11px] text-slate-400",
								children: "registros"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 148,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 144,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 137,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV(Link, {
						to: ROUTES.INSPECOES.PRAZOS,
						className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 shadow-2xs hover:border-amber-400 transition-colors block",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center justify-between",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-xs font-semibold text-slate-500 dark:text-slate-400",
								children: "Notificações com Prazo"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 158,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV(Clock, { className: "w-4 h-4 text-amber-500" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 161,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 157,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "mt-2 flex items-baseline gap-2",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-2xl font-bold text-amber-600 dark:text-amber-400",
								children: notificacoes.length
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 164,
								columnNumber: 13
							}, this), totalNotificacoesVencidas > 0 && /* @__PURE__ */ _jsxDEV("span", {
								className: "text-[10px] font-bold text-rose-600 bg-rose-50 px-1.5 py-0.5 rounded border border-rose-200",
								children: [totalNotificacoesVencidas, " vencida(s)"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 168,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 163,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 153,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 shadow-2xs",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center justify-between",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-xs font-semibold text-slate-500 dark:text-slate-400",
								children: "Indicador 11 (VAPT)"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 178,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV(HardHat, { className: "w-4 h-4 text-teal-600 dark:text-teal-400" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 181,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 177,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "mt-2 flex items-baseline gap-2",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-2xl font-bold text-teal-700 dark:text-teal-300",
								children: totalAcoesVapt
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 184,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "text-[11px] text-teal-600 dark:text-teal-400 font-medium",
								children: "ações pactuadas"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 187,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 183,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 176,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 shadow-2xs",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center justify-between",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-xs font-semibold text-slate-500 dark:text-slate-400",
								children: "Laudos Concluídos"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 196,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV(CheckCircle2, { className: "w-4 h-4 text-emerald-600 dark:text-emerald-400" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 199,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 195,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "mt-2 flex items-baseline gap-2",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-2xl font-bold text-emerald-600 dark:text-emerald-400",
								children: inspecoes.filter((i) => i.status === "concluida").length
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 202,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "text-[11px] text-slate-400",
								children: "finalizadas"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 205,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 201,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 194,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 135,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-xs overflow-hidden",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "border-b border-slate-200 dark:border-slate-800 px-6 pt-3 flex items-center justify-between gap-4 overflow-x-auto",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-6",
							children: [
								/* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => setTabAtiva("todas"),
									className: `pb-3 text-xs font-bold border-b-2 transition-colors whitespace-nowrap ${tabAtiva === "todas" ? "border-teal-600 text-teal-600 dark:text-teal-400" : "border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-300"}`,
									children: "Todas as Inspeções"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 215,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => setTabAtiva("agendadas"),
									className: `pb-3 text-xs font-bold border-b-2 transition-colors whitespace-nowrap ${tabAtiva === "agendadas" ? "border-teal-600 text-teal-600 dark:text-teal-400" : "border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-300"}`,
									children: "Agendadas"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 227,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => setTabAtiva("em_andamento"),
									className: `pb-3 text-xs font-bold border-b-2 transition-colors whitespace-nowrap ${tabAtiva === "em_andamento" ? "border-teal-600 text-teal-600 dark:text-teal-400" : "border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-300"}`,
									children: "Em Andamento"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 239,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => setTabAtiva("concluidas"),
									className: `pb-3 text-xs font-bold border-b-2 transition-colors whitespace-nowrap ${tabAtiva === "concluidas" ? "border-teal-600 text-teal-600 dark:text-teal-400" : "border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-300"}`,
									children: "Concluídas"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 251,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => setTabAtiva("vapt"),
									className: `pb-3 text-xs font-bold border-b-2 transition-colors whitespace-nowrap flex items-center gap-1.5 ${tabAtiva === "vapt" ? "border-teal-600 text-teal-600 dark:text-teal-400" : "border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-300"}`,
									children: [/* @__PURE__ */ _jsxDEV(HardHat, { className: "w-3.5 h-3.5" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 272,
										columnNumber: 15
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Ações VAPT (Ind. 11)" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 273,
										columnNumber: 15
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 263,
									columnNumber: 13
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 214,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							onClick: () => refetch(),
							disabled: isRefetching,
							className: "p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-300 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 mb-2 transition-colors",
							title: "Atualizar lista",
							children: /* @__PURE__ */ _jsxDEV(RefreshCw, { className: `w-4 h-4 ${isRefetching ? "animate-spin text-teal-600" : ""}` }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 284,
								columnNumber: 13
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 277,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 213,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "p-4 bg-slate-50/50 dark:bg-slate-800/40 border-b border-slate-200 dark:border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "relative flex-1 max-w-md",
							children: [/* @__PURE__ */ _jsxDEV(Search, { className: "w-4 h-4 text-slate-400 absolute left-3 top-2.5" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 293,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								type: "text",
								placeholder: "Buscar por termo (ex: TERM-2026), local ou motivo...",
								value: busca,
								onChange: (e) => setBusca(e.target.value),
								className: "w-full pl-9 pr-4 py-2 text-xs bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-teal-500"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 294,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 292,
							columnNumber: 11
						}, this), tabAtiva !== "vapt" && /* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ _jsxDEV(Filter, { className: "w-3.5 h-3.5 text-slate-400" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 305,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("select", {
								value: motivoFiltro,
								onChange: (e) => setMotivoFiltro(e.target.value),
								className: "px-3 py-1.5 text-xs bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-700 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-teal-500",
								children: [
									/* @__PURE__ */ _jsxDEV("option", {
										value: "",
										children: "Todos os Motivos"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 311,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("option", {
										value: "rotina_programada",
										children: "Rotina Programada"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 312,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("option", {
										value: "requerimento_alvara",
										children: "Requerimento de Alvará"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 313,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("option", {
										value: "denuncia",
										children: "Atendimento a Denúncia"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 314,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("option", {
										value: "reinspecao",
										children: "Reinspeção Fiscal"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 315,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("option", {
										value: "vapt_trabalhador",
										children: "VAPT - Saúde do Trabalhador"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 316,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("option", {
										value: "investigacao_surto",
										children: "Investigação de Surto"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 317,
										columnNumber: 17
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 306,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 304,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 291,
						columnNumber: 9
					}, this),
					isLoading ? /* @__PURE__ */ _jsxDEV("div", {
						className: "p-16 text-center text-slate-400 text-xs flex flex-col items-center justify-center",
						children: [/* @__PURE__ */ _jsxDEV("div", { className: "w-6 h-6 border-2 border-teal-500 border-t-transparent rounded-full animate-spin mb-3" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 326,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Consultando registros de fiscalização..." }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 327,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 325,
						columnNumber: 11
					}, this) : inspecoesFiltradas.length === 0 ? /* @__PURE__ */ _jsxDEV("div", {
						className: "p-12 text-center text-slate-500 dark:text-slate-400 space-y-3",
						children: [
							/* @__PURE__ */ _jsxDEV(ShieldAlert, { className: "w-10 h-10 text-slate-300 dark:text-slate-700 mx-auto" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 331,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("p", {
								className: "text-xs font-semibold text-slate-700 dark:text-slate-300",
								children: "Nenhuma inspeção sanitária encontrada para os critérios selecionados."
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 332,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("p", {
								className: "text-[11px] text-slate-400 max-w-sm mx-auto",
								children: "Utilize o botão \"Nova Inspeção\" para abrir um novo termo oficial de fiscalização de campo."
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 335,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								onClick: () => setModalNovaAberta(true),
								className: "mt-2 px-4 py-2 text-xs font-bold text-teal-700 dark:text-teal-300 bg-teal-50 dark:bg-teal-950/40 border border-teal-200 dark:border-teal-800 rounded-xl hover:bg-teal-100/60 inline-flex items-center gap-1.5",
								children: [/* @__PURE__ */ _jsxDEV(Plus, { className: "w-3.5 h-3.5" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 343,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Abrir Novo Termo" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 344,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 338,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 330,
						columnNumber: 11
					}, this) : /* @__PURE__ */ _jsxDEV("div", {
						className: "overflow-x-auto",
						children: /* @__PURE__ */ _jsxDEV("table", {
							className: "w-full text-left text-xs border-collapse",
							children: [/* @__PURE__ */ _jsxDEV("thead", {
								className: "bg-slate-50/80 dark:bg-slate-800/60 border-b border-slate-200 dark:border-slate-800 text-slate-500 dark:text-slate-400 font-semibold uppercase tracking-wider",
								children: /* @__PURE__ */ _jsxDEV("tr", { children: [
									/* @__PURE__ */ _jsxDEV("th", {
										className: "py-3.5 px-4",
										children: "Termo / Protocolo"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 352,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("th", {
										className: "py-3.5 px-4",
										children: "Motivo / Tipo"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 353,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("th", {
										className: "py-3.5 px-4",
										children: "Data Vistoria"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 354,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("th", {
										className: "py-3.5 px-4",
										children: "Status"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 355,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("th", {
										className: "py-3.5 px-4",
										children: "Parecer / Resultado"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 356,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("th", {
										className: "py-3.5 px-4 text-right",
										children: "Ações"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 357,
										columnNumber: 19
									}, this)
								] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 351,
									columnNumber: 17
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 350,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("tbody", {
								className: "divide-y divide-slate-100 dark:divide-slate-800",
								children: inspecoesFiltradas.map((item) => {
									const isVapt = item.motivo === "vapt_trabalhador";
									return /* @__PURE__ */ _jsxDEV("tr", {
										className: "hover:bg-slate-50/60 dark:hover:bg-slate-800/40 transition-colors group",
										children: [
											/* @__PURE__ */ _jsxDEV("td", {
												className: "py-3.5 px-4",
												children: /* @__PURE__ */ _jsxDEV("div", {
													className: "flex flex-col",
													children: [/* @__PURE__ */ _jsxDEV("span", {
														className: "font-mono font-bold text-slate-900 dark:text-white",
														children: item.numero_termo
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 372,
														columnNumber: 27
													}, this), /* @__PURE__ */ _jsxDEV("span", {
														className: "text-[10px] text-slate-400 font-mono",
														children: [
															"ID: ",
															item.id.substring(0, 8),
															"..."
														]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 375,
														columnNumber: 27
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 371,
													columnNumber: 25
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 370,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("td", {
												className: "py-3.5 px-4",
												children: /* @__PURE__ */ _jsxDEV("div", {
													className: "flex flex-col gap-1",
													children: [/* @__PURE__ */ _jsxDEV("div", {
														className: "flex items-center gap-1.5",
														children: [isVapt && /* @__PURE__ */ _jsxDEV(HardHat, { className: "w-3.5 h-3.5 text-teal-600 dark:text-teal-400 shrink-0" }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 386,
															columnNumber: 31
														}, this), /* @__PURE__ */ _jsxDEV("span", {
															className: "font-semibold text-slate-800 dark:text-slate-200 capitalize",
															children: item.motivo.replace(/_/g, " ")
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 388,
															columnNumber: 29
														}, this)]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 384,
														columnNumber: 27
													}, this), isVapt && item.nome_local_trabalho && /* @__PURE__ */ _jsxDEV("span", {
														className: "text-[10px] text-teal-600 dark:text-teal-400 bg-teal-50 dark:bg-teal-950/40 px-1.5 py-0.5 rounded border border-teal-200 dark:border-teal-800 w-fit",
														children: ["Local: ", item.nome_local_trabalho]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 393,
														columnNumber: 29
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 383,
													columnNumber: 25
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 382,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("td", {
												className: "py-3.5 px-4",
												children: /* @__PURE__ */ _jsxDEV("div", {
													className: "flex flex-col text-slate-600 dark:text-slate-300",
													children: [/* @__PURE__ */ _jsxDEV("span", {
														className: "font-medium",
														children: new Date(item.data_inicio).toLocaleDateString("pt-BR")
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 403,
														columnNumber: 27
													}, this), item.hora_inspecao && /* @__PURE__ */ _jsxDEV("span", {
														className: "text-[10px] text-slate-400",
														children: ["Às ", item.hora_inspecao]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 407,
														columnNumber: 29
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 402,
													columnNumber: 25
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 401,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("td", {
												className: "py-3.5 px-4",
												children: /* @__PURE__ */ _jsxDEV(StatusInspecaoBadge, { status: item.status }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 416,
													columnNumber: 25
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 415,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("td", {
												className: "py-3.5 px-4",
												children: [/* @__PURE__ */ _jsxDEV(ResultadoInspecaoBadge, { resultado: item.resultado }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 421,
													columnNumber: 25
												}, this), item.resultado === "notificado_com_prazo" && item.data_limite_adequacao && /* @__PURE__ */ _jsxDEV("div", {
													className: "mt-1 flex items-center gap-1 text-[10px] text-amber-600 font-medium",
													children: [/* @__PURE__ */ _jsxDEV(Clock, { className: "w-3 h-3" }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 424,
														columnNumber: 29
													}, this), /* @__PURE__ */ _jsxDEV("span", { children: [
														"Limite:",
														" ",
														new Date(item.data_limite_adequacao).toLocaleDateString("pt-BR")
													] }, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 425,
														columnNumber: 29
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 423,
													columnNumber: 27
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 420,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("td", {
												className: "py-3.5 px-4 text-right",
												children: /* @__PURE__ */ _jsxDEV("div", {
													className: "flex items-center justify-end gap-2",
													children: /* @__PURE__ */ _jsxDEV(Link, {
														to: ROUTES.INSPECOES.LAUDO(item.id),
														className: `px-3 py-1.5 text-xs font-bold rounded-lg border transition-colors inline-flex items-center gap-1.5 ${item.status === "concluida" ? "bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-200 border-slate-200 dark:border-slate-700 hover:bg-slate-100" : "bg-teal-600 text-white border-teal-600 hover:bg-teal-700 shadow-2xs"}`,
														children: [/* @__PURE__ */ _jsxDEV(FileText, { className: "w-3.5 h-3.5" }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 446,
															columnNumber: 29
														}, this), /* @__PURE__ */ _jsxDEV("span", { children: item.status === "concluida" ? "Ver Laudo" : "Lavrar Laudo" }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 447,
															columnNumber: 29
														}, this)]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 438,
														columnNumber: 27
													}, this)
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 437,
													columnNumber: 25
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 436,
												columnNumber: 23
											}, this)
										]
									}, item.id, true, {
										fileName: _jsxFileName,
										lineNumber: 365,
										columnNumber: 21
									}, this);
								})
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 360,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 349,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 348,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 211,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(AgendarInspecaoModal, {
				isOpen: modalNovaAberta,
				onClose: () => setModalNovaAberta(false),
				estabelecimentoIdPreDefinido: estabelecimentoIdParam || undefined,
				onSucesso: (inspecao) => {
					if (inspecao?.id) {
						navigate(ROUTES.INSPECOES.LAUDO(inspecao.id));
					}
				}
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 463,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 92,
		columnNumber: 5
	}, this);
};
_s(InspecoesListPage, "kM4WvbZiI/P5BcQ4cpXFIheFy2k=", false, function() {
	return [
		useNavigate,
		useSearchParams,
		useInspecoesList,
		useNotificacoesPendentes,
		useIndicador11Vapt
	];
});
_c = InspecoesListPage;
export default InspecoesListPage;
var _c;
$RefreshReg$(_c, "InspecoesListPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/fiscalizacao/InspecoesListPage.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("E:/Projetos VSCODE/visa_braunas/src/pages/fiscalizacao/InspecoesListPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("E:/Projetos VSCODE/visa_braunas/src/pages/fiscalizacao/InspecoesListPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "E:/Projetos VSCODE/visa_braunas/src/pages/fiscalizacao/InspecoesListPage.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7Ozs7QUFNQSxPQUFPLFNBQVMsU0FBUyxnQkFBZ0I7QUFDekMsU0FBUyxNQUFNLGFBQWEsdUJBQXVCO0FBQ25ELFNBSUUsY0FDQSxPQUVBLFVBQ0EsUUFDQSxTQUNBLE1BQ0EsV0FDQSxRQUNBLG1CQUVLO0FBQ1AsU0FBUyxjQUFjO0FBQ3ZCLFNBQ0Usb0JBQ0Esa0JBQ0EsZ0NBQ0s7QUFLUCxTQUFTLDJCQUEyQjtBQUNwQyxTQUFTLDhCQUE4QjtBQUN2QyxTQUFTLDRCQUE0Qjs7OztBQUlyQyxPQUFPLE1BQU0sMEJBQW9DOztDQUMvQyxNQUFNLFdBQVcsWUFBWTtDQUM3QixNQUFNLENBQUMsY0FBYyxtQkFBbUIsZ0JBQWdCO0NBQ3hELE1BQU0seUJBQXlCLGFBQWEsSUFBSSxvQkFBb0IsS0FBSztDQUV6RSxNQUFNLENBQUMsVUFBVSxlQUFlLFNBQW9CLE9BQU87Q0FDM0QsTUFBTSxDQUFDLE9BQU8sWUFBWSxTQUFTLEVBQUU7Q0FDckMsTUFBTSxDQUFDLGNBQWMsbUJBQW1CLFNBQWtDLEVBQUU7Q0FDNUUsTUFBTSxDQUFDLGlCQUFpQixzQkFBc0IsU0FBUyxLQUFLOztDQUc1RCxNQUFNLEVBQ0osTUFBTSxZQUFZLENBQUMsR0FDbkIsV0FDQSxjQUNBLFlBQ0UsaUJBQWlCO0VBQ25CLG9CQUFvQiwwQkFBMEI7RUFDOUMsUUFBUSxhQUFhLFNBQVMscUJBQXFCLGdCQUFnQjtFQUNuRSxRQUNFLGFBQWEsY0FDVCxhQUNBLGFBQWEsaUJBQ2IsaUJBQ0EsYUFBYSxlQUNiLGNBQ0E7Q0FDUixDQUFDO0NBRUQsTUFBTSxFQUFFLE1BQU0sZUFBZSxDQUFDLE1BQU0seUJBQXlCLEVBQUU7Q0FDL0QsTUFBTSxFQUFFLE1BQU0sZ0JBQWdCLENBQUMsTUFBTSxtQkFBbUIsSUFBSSxLQUFLLENBQUMsQ0FBQyxZQUFZLENBQUM7O0NBR2hGLE1BQU0sNEJBQTRCLGFBQWEsUUFBUSxNQUFNLEVBQUUsaUJBQWlCLENBQUMsQ0FBQyxDQUFDO0NBQ25GLE1BQU0saUJBQWlCLGNBQWMsRUFBRSxFQUFFLG9CQUFvQjs7Q0FHN0QsTUFBTSxxQkFBcUIsY0FBYztFQUN2QyxPQUFPLFVBQVUsUUFBUSxTQUFTO0dBQ2hDLE1BQU0sYUFDSixDQUFDLFNBQ0QsS0FBSyxhQUFhLFlBQVksQ0FBQyxDQUFDLFNBQVMsTUFBTSxZQUFZLENBQUMsS0FDNUQsS0FBSyxPQUFPLFlBQVksQ0FBQyxDQUFDLFNBQVMsTUFBTSxZQUFZLENBQUMsS0FDckQsS0FBSyx1QkFDSixLQUFLLG9CQUFvQixZQUFZLENBQUMsQ0FBQyxTQUFTLE1BQU0sWUFBWSxDQUFDO0dBRXZFLE9BQU87RUFDVCxDQUFDO0NBQ0gsR0FBRyxDQUFDLFdBQVcsS0FBSyxDQUFDO0NBRXJCLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBZjtHQUVFLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxPQUFEO0tBQ0Usd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQ2Isd0JBQUMsUUFBRDtPQUFNLFdBQVU7aUJBQWdKO01BRTFKOzs7OztLQUNIOzs7OztLQUNMLHdCQUFDLE1BQUQ7TUFBSSxXQUFVO2dCQUEyRTtLQUVyRjs7Ozs7S0FDSix3QkFBQyxLQUFEO01BQUcsV0FBVTtnQkFBNEQ7S0FFdEU7Ozs7O0lBQ0E7Ozs7Y0FFTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsTUFBRDtNQUNFLElBQUksT0FBTyxVQUFVO01BQ3JCLFdBQVU7Z0JBRlo7T0FJRSx3QkFBQyxPQUFELEVBQU8sV0FBVSw2Q0FBOEM7Ozs7O09BQy9ELHdCQUFDLFFBQUQsWUFBTSxtQkFBc0I7Ozs7O09BQzNCLGFBQWEsU0FBUyxLQUNyQix3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFDYixhQUFhO09BQ1Y7Ozs7O01BRUo7Ozs7O2VBRU4sd0JBQUMsVUFBRDtNQUNFLE1BQUs7TUFDTCxlQUFlLG1CQUFtQixJQUFJO01BQ3RDLFdBQVU7Z0JBSFosQ0FLRSx3QkFBQyxNQUFELEVBQU0sV0FBVSxVQUFXOzs7O2dCQUMzQix3QkFBQyxRQUFELFlBQU0sZ0JBQW1COzs7O2NBQ25COzs7OzthQUNMOzs7OztZQUNGOzs7Ozs7R0FHTCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmO0tBRUUsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUEyRDtPQUVyRTs7OztpQkFDTix3QkFBQyxVQUFELEVBQVUsV0FBVSwyQ0FBNEM7Ozs7ZUFDN0Q7Ozs7O2dCQUNMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQ2IsVUFBVTtPQUNQOzs7O2lCQUNOLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUE2QjtPQUFlOzs7O2VBQ3pEOzs7OztjQUNGOzs7Ozs7S0FHTCx3QkFBQyxNQUFEO01BQ0UsSUFBSSxPQUFPLFVBQVU7TUFDckIsV0FBVTtnQkFGWixDQUlFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQTJEO09BRXJFOzs7O2lCQUNOLHdCQUFDLE9BQUQsRUFBTyxXQUFVLHlCQUEwQjs7OztlQUN4Qzs7Ozs7Z0JBQ0wsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFDYixhQUFhO09BQ1Y7Ozs7aUJBQ0wsNEJBQTRCLEtBQzNCLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUFoQixDQUNHLDJCQUEwQixhQUN2Qjs7Ozs7ZUFFTDs7Ozs7Y0FDRDs7Ozs7O0tBR04sd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUEyRDtPQUVyRTs7OztpQkFDTix3QkFBQyxTQUFELEVBQVMsV0FBVSwyQ0FBNEM7Ozs7ZUFDNUQ7Ozs7O2dCQUNMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQ2I7T0FDRzs7OztpQkFDTix3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBMkQ7T0FFckU7Ozs7ZUFDSDs7Ozs7Y0FDRjs7Ozs7O0tBR0wsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUEyRDtPQUVyRTs7OztpQkFDTix3QkFBQyxjQUFELEVBQWMsV0FBVSxpREFBa0Q7Ozs7ZUFDdkU7Ozs7O2dCQUNMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQ2IsVUFBVSxRQUFRLE1BQU0sRUFBRSxXQUFXLFdBQVcsQ0FBQyxDQUFDO09BQy9DOzs7O2lCQUNOLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUE2QjtPQUFpQjs7OztlQUMzRDs7Ozs7Y0FDRjs7Ozs7O0lBQ0Y7Ozs7OztHQUdMLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWY7S0FFRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmO1FBQ0Usd0JBQUMsVUFBRDtTQUNFLE1BQUs7U0FDTCxlQUFlLFlBQVksT0FBTztTQUNsQyxXQUFXLHlFQUNULGFBQWEsVUFDVCxxREFDQTttQkFFUDtRQUVPOzs7OztRQUVSLHdCQUFDLFVBQUQ7U0FDRSxNQUFLO1NBQ0wsZUFBZSxZQUFZLFdBQVc7U0FDdEMsV0FBVyx5RUFDVCxhQUFhLGNBQ1QscURBQ0E7bUJBRVA7UUFFTzs7Ozs7UUFFUix3QkFBQyxVQUFEO1NBQ0UsTUFBSztTQUNMLGVBQWUsWUFBWSxjQUFjO1NBQ3pDLFdBQVcseUVBQ1QsYUFBYSxpQkFDVCxxREFDQTttQkFFUDtRQUVPOzs7OztRQUVSLHdCQUFDLFVBQUQ7U0FDRSxNQUFLO1NBQ0wsZUFBZSxZQUFZLFlBQVk7U0FDdkMsV0FBVyx5RUFDVCxhQUFhLGVBQ1QscURBQ0E7bUJBRVA7UUFFTzs7Ozs7UUFFUix3QkFBQyxVQUFEO1NBQ0UsTUFBSztTQUNMLGVBQWUsWUFBWSxNQUFNO1NBQ2pDLFdBQVcsbUdBQ1QsYUFBYSxTQUNULHFEQUNBO21CQU5SLENBU0Usd0JBQUMsU0FBRCxFQUFTLFdBQVUsY0FBZTs7OzttQkFDbEMsd0JBQUMsUUFBRCxZQUFNLHVCQUEwQjs7OztpQkFDMUI7Ozs7OztPQUNMOzs7OztnQkFFTCx3QkFBQyxVQUFEO09BQ0UsTUFBSztPQUNMLGVBQWUsUUFBUTtPQUN2QixVQUFVO09BQ1YsV0FBVTtPQUNWLE9BQU07aUJBRU4sd0JBQUMsV0FBRCxFQUNFLFdBQVcsV0FBVyxlQUFlLCtCQUErQixLQUNyRTs7Ozs7TUFDSzs7OztjQUNMOzs7Ozs7S0FHTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsUUFBRCxFQUFRLFdBQVUsaURBQWtEOzs7O2lCQUNwRSx3QkFBQyxTQUFEO1FBQ0UsTUFBSztRQUNMLGFBQVk7UUFDWixPQUFPO1FBQ1AsV0FBVyxNQUFNLFNBQVMsRUFBRSxPQUFPLEtBQUs7UUFDeEMsV0FBVTtPQUNYOzs7O2VBQ0U7Ozs7O2dCQUVKLGFBQWEsVUFDWix3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLFFBQUQsRUFBUSxXQUFVLDZCQUE4Qjs7OztpQkFDaEQsd0JBQUMsVUFBRDtRQUNFLE9BQU87UUFDUCxXQUFXLE1BQU0sZ0JBQWdCLEVBQUUsT0FBTyxLQUFZO1FBQ3RELFdBQVU7a0JBSFo7U0FLRSx3QkFBQyxVQUFEO1VBQVEsT0FBTTtvQkFBRztTQUF3Qjs7Ozs7U0FDekMsd0JBQUMsVUFBRDtVQUFRLE9BQU07b0JBQW9CO1NBQXlCOzs7OztTQUMzRCx3QkFBQyxVQUFEO1VBQVEsT0FBTTtvQkFBc0I7U0FBOEI7Ozs7O1NBQ2xFLHdCQUFDLFVBQUQ7VUFBUSxPQUFNO29CQUFXO1NBQThCOzs7OztTQUN2RCx3QkFBQyxVQUFEO1VBQVEsT0FBTTtvQkFBYTtTQUF5Qjs7Ozs7U0FDcEQsd0JBQUMsVUFBRDtVQUFRLE9BQU07b0JBQW1CO1NBQW1DOzs7OztTQUNwRSx3QkFBQyxVQUFEO1VBQVEsT0FBTTtvQkFBcUI7U0FBNkI7Ozs7O1FBQzFEOzs7OztlQUNMOzs7OztjQUVKOzs7Ozs7S0FHSixZQUNDLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsT0FBRCxFQUFLLFdBQVUsdUZBQXdGOzs7O2dCQUN2Ryx3QkFBQyxRQUFELFlBQU0sMkNBQThDOzs7O2NBQ2pEOzs7OztnQkFDSCxtQkFBbUIsV0FBVyxJQUNoQyx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZjtPQUNFLHdCQUFDLGFBQUQsRUFBYSxXQUFVLHVEQUF3RDs7Ozs7T0FDL0Usd0JBQUMsS0FBRDtRQUFHLFdBQVU7a0JBQTJEO09BRXJFOzs7OztPQUNILHdCQUFDLEtBQUQ7UUFBRyxXQUFVO2tCQUE4QztPQUV4RDs7Ozs7T0FDSCx3QkFBQyxVQUFEO1FBQ0UsTUFBSztRQUNMLGVBQWUsbUJBQW1CLElBQUk7UUFDdEMsV0FBVTtrQkFIWixDQUtFLHdCQUFDLE1BQUQsRUFBTSxXQUFVLGNBQWU7Ozs7a0JBQy9CLHdCQUFDLFFBQUQsWUFBTSxtQkFBc0I7Ozs7Z0JBQ3RCOzs7Ozs7TUFDTDs7Ozs7Z0JBRUwsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQ2Isd0JBQUMsU0FBRDtPQUFPLFdBQVU7aUJBQWpCLENBQ0Usd0JBQUMsU0FBRDtRQUFPLFdBQVU7a0JBQ2Ysd0JBQUMsTUFBRDtTQUNFLHdCQUFDLE1BQUQ7VUFBSSxXQUFVO29CQUFjO1NBQXFCOzs7OztTQUNqRCx3QkFBQyxNQUFEO1VBQUksV0FBVTtvQkFBYztTQUFpQjs7Ozs7U0FDN0Msd0JBQUMsTUFBRDtVQUFJLFdBQVU7b0JBQWM7U0FBaUI7Ozs7O1NBQzdDLHdCQUFDLE1BQUQ7VUFBSSxXQUFVO29CQUFjO1NBQVU7Ozs7O1NBQ3RDLHdCQUFDLE1BQUQ7VUFBSSxXQUFVO29CQUFjO1NBQXVCOzs7OztTQUNuRCx3QkFBQyxNQUFEO1VBQUksV0FBVTtvQkFBeUI7U0FBUzs7Ozs7UUFDOUM7Ozs7O09BQ0M7Ozs7aUJBQ1Asd0JBQUMsU0FBRDtRQUFPLFdBQVU7a0JBQ2QsbUJBQW1CLEtBQUssU0FBUztTQUNoQyxNQUFNLFNBQVMsS0FBSyxXQUFXO1NBRS9CLE9BQ0Usd0JBQUMsTUFBRDtVQUVFLFdBQVU7b0JBRlo7V0FLRSx3QkFBQyxNQUFEO1lBQUksV0FBVTtzQkFDWix3QkFBQyxPQUFEO2FBQUssV0FBVTt1QkFBZixDQUNFLHdCQUFDLFFBQUQ7Y0FBTSxXQUFVO3dCQUNiLEtBQUs7YUFDRjs7Ozt1QkFDTix3QkFBQyxRQUFEO2NBQU0sV0FBVTt3QkFBaEI7ZUFBdUQ7ZUFDaEQsS0FBSyxHQUFHLFVBQVUsR0FBRyxDQUFDO2VBQUU7Y0FDekI7Ozs7O3FCQUNIOzs7Ozs7V0FDSDs7Ozs7V0FHSix3QkFBQyxNQUFEO1lBQUksV0FBVTtzQkFDWix3QkFBQyxPQUFEO2FBQUssV0FBVTt1QkFBZixDQUNFLHdCQUFDLE9BQUQ7Y0FBSyxXQUFVO3dCQUFmLENBQ0csVUFDQyx3QkFBQyxTQUFELEVBQVMsV0FBVSx3REFBeUQ7Ozs7d0JBRTlFLHdCQUFDLFFBQUQ7ZUFBTSxXQUFVO3lCQUNiLEtBQUssT0FBTyxRQUFRLE1BQU0sR0FBRztjQUMxQjs7OztzQkFDSDs7Ozs7dUJBQ0osVUFBVSxLQUFLLHVCQUNkLHdCQUFDLFFBQUQ7Y0FBTSxXQUFVO3dCQUFoQixDQUFzSyxXQUM1SixLQUFLLG1CQUNUOzs7OztxQkFFTDs7Ozs7O1dBQ0g7Ozs7O1dBR0osd0JBQUMsTUFBRDtZQUFJLFdBQVU7c0JBQ1osd0JBQUMsT0FBRDthQUFLLFdBQVU7dUJBQWYsQ0FDRSx3QkFBQyxRQUFEO2NBQU0sV0FBVTt3QkFDYixJQUFJLEtBQUssS0FBSyxXQUFXLENBQUMsQ0FBQyxtQkFBbUIsT0FBTzthQUNsRDs7Ozt1QkFDTCxLQUFLLGlCQUNKLHdCQUFDLFFBQUQ7Y0FBTSxXQUFVO3dCQUFoQixDQUE2QyxPQUN2QyxLQUFLLGFBQ0w7Ozs7O3FCQUVMOzs7Ozs7V0FDSDs7Ozs7V0FHSix3QkFBQyxNQUFEO1lBQUksV0FBVTtzQkFDWix3QkFBQyxxQkFBRCxFQUFxQixRQUFRLEtBQUssT0FBUzs7Ozs7V0FDekM7Ozs7O1dBR0osd0JBQUMsTUFBRDtZQUFJLFdBQVU7c0JBQWQsQ0FDRSx3QkFBQyx3QkFBRCxFQUF3QixXQUFXLEtBQUssVUFBWTs7OztzQkFDbkQsS0FBSyxjQUFjLDBCQUEwQixLQUFLLHlCQUNqRCx3QkFBQyxPQUFEO2FBQUssV0FBVTt1QkFBZixDQUNFLHdCQUFDLE9BQUQsRUFBTyxXQUFVLFVBQVc7Ozs7dUJBQzVCLHdCQUFDLFFBQUQ7Y0FBTTtjQUNJO2NBQ1AsSUFBSSxLQUFLLEtBQUsscUJBQXFCLENBQUMsQ0FBQyxtQkFDcEMsT0FDRjthQUNJOzs7O3FCQUNIOzs7OztvQkFFTDs7Ozs7O1dBR0osd0JBQUMsTUFBRDtZQUFJLFdBQVU7c0JBQ1osd0JBQUMsT0FBRDthQUFLLFdBQVU7dUJBQ2Isd0JBQUMsTUFBRDtjQUNFLElBQUksT0FBTyxVQUFVLE1BQU0sS0FBSyxFQUFFO2NBQ2xDLFdBQVcsc0dBQ1QsS0FBSyxXQUFXLGNBQ1osK0hBQ0E7d0JBTFIsQ0FRRSx3QkFBQyxVQUFELEVBQVUsV0FBVSxjQUFlOzs7O3dCQUNuQyx3QkFBQyxRQUFELFlBQ0csS0FBSyxXQUFXLGNBQWMsY0FBYyxlQUN6Qzs7OztzQkFDRjs7Ozs7O1lBQ0g7Ozs7O1dBQ0g7Ozs7O1VBQ0Y7WUF2RkcsS0FBSzs7OztnQkF1RlI7UUFFUixDQUFDO09BQ0k7Ozs7ZUFDRjs7Ozs7O0tBQ0o7Ozs7O0lBRUo7Ozs7OztHQUdMLHdCQUFDLHNCQUFEO0lBQ0UsUUFBUTtJQUNSLGVBQWUsbUJBQW1CLEtBQUs7SUFDdkMsOEJBQThCLDBCQUEwQjtJQUN4RCxZQUFZLGFBQWE7S0FDdkIsSUFBSSxVQUFVLElBQUk7TUFDaEIsU0FBUyxPQUFPLFVBQVUsTUFBTSxTQUFTLEVBQUUsQ0FBQztLQUM5QztJQUNGO0dBQ0Q7Ozs7O0VBQ0U7Ozs7OztBQUVUOzs7Ozs7Ozs7OztBQUVBLGVBQWUiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiSW5zcGVjb2VzTGlzdFBhZ2UudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbIi8qKlxyXG4gKiBQw6FnaW5hIFByaW5jaXBhbCBkbyBNw7NkdWxvIGRlIEZpc2NhbGl6YcOnw6NvICYgSW5zcGXDp8O1ZXMgU2FuaXTDoXJpYXNcclxuICogTGlzdGFnZW0gY29tIGZpbHRyb3MgcG9yIGFiYXMsIGJ1c2NhIHRleHR1YWwsIG3DqXRyaWNhcyBvcGVyYWNpb25haXMsXHJcbiAqIGluZGljYWRvcmVzIFZBUFQgKEluZGljYWRvciAxMSkgZSBhY2Vzc28gYW8gUGFpbmVsIGRlIFByYXpvcy5cclxuICovXHJcblxyXG5pbXBvcnQgUmVhY3QsIHsgdXNlTWVtbywgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHsgTGluaywgdXNlTmF2aWdhdGUsIHVzZVNlYXJjaFBhcmFtcyB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCI7XHJcbmltcG9ydCB7XHJcbiAgQWxlcnRDaXJjbGUsXHJcbiAgQnVpbGRpbmcyLFxyXG4gIENhbGVuZGFyLFxyXG4gIENoZWNrQ2lyY2xlMixcclxuICBDbG9jayxcclxuICBFeHRlcm5hbExpbmssXHJcbiAgRmlsZVRleHQsXHJcbiAgRmlsdGVyLFxyXG4gIEhhcmRIYXQsXHJcbiAgUGx1cyxcclxuICBSZWZyZXNoQ3csXHJcbiAgU2VhcmNoLFxyXG4gIFNoaWVsZEFsZXJ0LFxyXG4gIFgsXHJcbn0gZnJvbSBcImx1Y2lkZS1yZWFjdFwiO1xyXG5pbXBvcnQgeyBST1VURVMgfSBmcm9tIFwiLi4vLi4vY29uZmlnL3JvdXRlcy5jb25maWdcIjtcclxuaW1wb3J0IHtcclxuICB1c2VJbmRpY2Fkb3IxMVZhcHQsXHJcbiAgdXNlSW5zcGVjb2VzTGlzdCxcclxuICB1c2VOb3RpZmljYWNvZXNQZW5kZW50ZXMsXHJcbn0gZnJvbSBcIi4uLy4uL2hvb2tzL3VzZUZpc2NhbGl6YWNhb1wiO1xyXG5pbXBvcnQge1xyXG4gIFN0YXR1c0luc3BlY2FvLFxyXG4gIFRpcG9Nb3Rpdm9JbnNwZWNhbyxcclxufSBmcm9tIFwiLi4vLi4vdHlwZXMvZmlzY2FsaXphY2FvXCI7XHJcbmltcG9ydCB7IFN0YXR1c0luc3BlY2FvQmFkZ2UgfSBmcm9tIFwiLi4vLi4vY29tcG9uZW50cy9maXNjYWxpemFjYW8vU3RhdHVzSW5zcGVjYW9CYWRnZVwiO1xyXG5pbXBvcnQgeyBSZXN1bHRhZG9JbnNwZWNhb0JhZGdlIH0gZnJvbSBcIi4uLy4uL2NvbXBvbmVudHMvZmlzY2FsaXphY2FvL1Jlc3VsdGFkb0luc3BlY2FvQmFkZ2VcIjtcclxuaW1wb3J0IHsgQWdlbmRhckluc3BlY2FvTW9kYWwgfSBmcm9tIFwiLi4vLi4vY29tcG9uZW50cy9maXNjYWxpemFjYW8vQWdlbmRhckluc3BlY2FvTW9kYWxcIjtcclxuXHJcbnR5cGUgVGFiRmlsdHJvID0gXCJ0b2Rhc1wiIHwgXCJhZ2VuZGFkYXNcIiB8IFwiZW1fYW5kYW1lbnRvXCIgfCBcImNvbmNsdWlkYXNcIiB8IFwidmFwdFwiO1xyXG5cclxuZXhwb3J0IGNvbnN0IEluc3BlY29lc0xpc3RQYWdlOiBSZWFjdC5GQyA9ICgpID0+IHtcclxuICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKCk7XHJcbiAgY29uc3QgW3NlYXJjaFBhcmFtcywgc2V0U2VhcmNoUGFyYW1zXSA9IHVzZVNlYXJjaFBhcmFtcygpO1xyXG4gIGNvbnN0IGVzdGFiZWxlY2ltZW50b0lkUGFyYW0gPSBzZWFyY2hQYXJhbXMuZ2V0KFwiZXN0YWJlbGVjaW1lbnRvX2lkXCIpIHx8IFwiXCI7XHJcblxyXG4gIGNvbnN0IFt0YWJBdGl2YSwgc2V0VGFiQXRpdmFdID0gdXNlU3RhdGU8VGFiRmlsdHJvPihcInRvZGFzXCIpO1xyXG4gIGNvbnN0IFtidXNjYSwgc2V0QnVzY2FdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW21vdGl2b0ZpbHRybywgc2V0TW90aXZvRmlsdHJvXSA9IHVzZVN0YXRlPFRpcG9Nb3Rpdm9JbnNwZWNhbyB8IFwiXCI+KFwiXCIpO1xyXG4gIGNvbnN0IFttb2RhbE5vdmFBYmVydGEsIHNldE1vZGFsTm92YUFiZXJ0YV0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcblxyXG4gIC8vIENvbnN1bHRhcyB2aWEgUmVhY3QgUXVlcnkgdjVcclxuICBjb25zdCB7XHJcbiAgICBkYXRhOiBpbnNwZWNvZXMgPSBbXSxcclxuICAgIGlzTG9hZGluZyxcclxuICAgIGlzUmVmZXRjaGluZyxcclxuICAgIHJlZmV0Y2gsXHJcbiAgfSA9IHVzZUluc3BlY29lc0xpc3Qoe1xyXG4gICAgZXN0YWJlbGVjaW1lbnRvX2lkOiBlc3RhYmVsZWNpbWVudG9JZFBhcmFtIHx8IHVuZGVmaW5lZCxcclxuICAgIG1vdGl2bzogdGFiQXRpdmEgPT09IFwidmFwdFwiID8gXCJ2YXB0X3RyYWJhbGhhZG9yXCIgOiBtb3Rpdm9GaWx0cm8gfHwgdW5kZWZpbmVkLFxyXG4gICAgc3RhdHVzOlxyXG4gICAgICB0YWJBdGl2YSA9PT0gXCJhZ2VuZGFkYXNcIlxyXG4gICAgICAgID8gXCJhZ2VuZGFkYVwiXHJcbiAgICAgICAgOiB0YWJBdGl2YSA9PT0gXCJlbV9hbmRhbWVudG9cIlxyXG4gICAgICAgID8gXCJlbV9hbmRhbWVudG9cIlxyXG4gICAgICAgIDogdGFiQXRpdmEgPT09IFwiY29uY2x1aWRhc1wiXHJcbiAgICAgICAgPyBcImNvbmNsdWlkYVwiXHJcbiAgICAgICAgOiB1bmRlZmluZWQsXHJcbiAgfSk7XHJcblxyXG4gIGNvbnN0IHsgZGF0YTogbm90aWZpY2Fjb2VzID0gW10gfSA9IHVzZU5vdGlmaWNhY29lc1BlbmRlbnRlcygzMCk7XHJcbiAgY29uc3QgeyBkYXRhOiBpbmRpY2Fkb3JWYXB0ID0gW10gfSA9IHVzZUluZGljYWRvcjExVmFwdChuZXcgRGF0ZSgpLmdldEZ1bGxZZWFyKCkpO1xyXG5cclxuICAvLyBNw6l0cmljYXMgcsOhcGlkYXNcclxuICBjb25zdCB0b3RhbE5vdGlmaWNhY29lc1ZlbmNpZGFzID0gbm90aWZpY2Fjb2VzLmZpbHRlcigobikgPT4gbi5kaWFzX3Jlc3RhbnRlcyA8IDApLmxlbmd0aDtcclxuICBjb25zdCB0b3RhbEFjb2VzVmFwdCA9IGluZGljYWRvclZhcHRbMF0/LnRvdGFsX2Fjb2VzX3ZhcHQgPz8gMDtcclxuXHJcbiAgLy8gRmlsdHJhZ2VtIGxvY2FsIGNvbXBsZW1lbnRhciBwYXJhIGJ1c2NhIHLDoXBpZGEgcG9yIHRleHRvIChuw7ptZXJvIGRvIHRlcm1vIG91IElEKVxyXG4gIGNvbnN0IGluc3BlY29lc0ZpbHRyYWRhcyA9IHVzZU1lbW8oKCkgPT4ge1xyXG4gICAgcmV0dXJuIGluc3BlY29lcy5maWx0ZXIoKGl0ZW0pID0+IHtcclxuICAgICAgY29uc3QgbWF0Y2hCdXNjYSA9XHJcbiAgICAgICAgIWJ1c2NhIHx8XHJcbiAgICAgICAgaXRlbS5udW1lcm9fdGVybW8udG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhidXNjYS50b0xvd2VyQ2FzZSgpKSB8fFxyXG4gICAgICAgIGl0ZW0ubW90aXZvLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoYnVzY2EudG9Mb3dlckNhc2UoKSkgfHxcclxuICAgICAgICAoaXRlbS5ub21lX2xvY2FsX3RyYWJhbGhvICYmXHJcbiAgICAgICAgICBpdGVtLm5vbWVfbG9jYWxfdHJhYmFsaG8udG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhidXNjYS50b0xvd2VyQ2FzZSgpKSk7XHJcblxyXG4gICAgICByZXR1cm4gbWF0Y2hCdXNjYTtcclxuICAgIH0pO1xyXG4gIH0sIFtpbnNwZWNvZXMsIGJ1c2NhXSk7XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNlwiPlxyXG4gICAgICB7LyogQ2FiZcOnYWxobyBkYSBQw6FnaW5hICovfVxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgbWQ6ZmxleC1yb3cgbWQ6aXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtNCBiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC0yeGwgcC02IHNoYWRvdy14c1wiPlxyXG4gICAgICAgIDxkaXY+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRleHQtdGVhbC02MDAgZGFyazp0ZXh0LXRlYWwtNDAwIG1iLTFcIj5cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gZm9udC1ib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciBiZy10ZWFsLTUwIGRhcms6YmctdGVhbC05NTAvNDAgcHgtMiBweS0wLjUgcm91bmRlZCBib3JkZXIgYm9yZGVyLXRlYWwtMjAwIGRhcms6Ym9yZGVyLXRlYWwtODAwXCI+XHJcbiAgICAgICAgICAgICAgTcOzZHVsbyBkZSBDYW1wbyAmIEZpc2NhbGl6YcOnw6NvXHJcbiAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1ib2xkIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICBJbnNwZcOnw7VlcyBTYW5pdMOhcmlhcyAmIFZpc3RvcmlhcyBGaXNjYWlzXHJcbiAgICAgICAgICA8L2gxPlxyXG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTUwMCBkYXJrOnRleHQtc2xhdGUtNDAwIG10LTEgbWF4LXctMnhsXCI+XHJcbiAgICAgICAgICAgIEdlc3TDo28gb3BlcmFjaW9uYWwgZGUgYXV0b3MgZGUgaW5zcGXDp8OjbywgY2hlY2tsaXN0cyBkZSBib2FzIHByw6F0aWNhcywgbGF1ZG9zIHBlcmljaWFpcyBlIG1vbml0b3JhbWVudG8gZG8gSW5kaWNhZG9yIDExIGRlIFNhw7pkZSBkbyBUcmFiYWxoYWRvciAoVkFQVCkuXHJcbiAgICAgICAgICA8L3A+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIuNVwiPlxyXG4gICAgICAgICAgPExpbmtcclxuICAgICAgICAgICAgdG89e1JPVVRFUy5JTlNQRUNPRVMuUFJBWk9TfVxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJweC0zLjUgcHktMiB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1hbWJlci04MDAgZGFyazp0ZXh0LWFtYmVyLTIwMCBiZy1hbWJlci01MCBkYXJrOmJnLWFtYmVyLTk1MC80MCBib3JkZXIgYm9yZGVyLWFtYmVyLTIwMCBkYXJrOmJvcmRlci1hbWJlci04MDAvODAgcm91bmRlZC14bCBob3ZlcjpiZy1hbWJlci0xMDAvNjAgc2hhZG93LTJ4cyBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiB0cmFuc2l0aW9uLWNvbG9yc1wiXHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIDxDbG9jayBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtYW1iZXItNjAwIGRhcms6dGV4dC1hbWJlci00MDBcIiAvPlxyXG4gICAgICAgICAgICA8c3Bhbj5QYWluZWwgZGUgUHJhem9zPC9zcGFuPlxyXG4gICAgICAgICAgICB7bm90aWZpY2Fjb2VzLmxlbmd0aCA+IDAgJiYgKFxyXG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInB4LTEuNSBweS0wLjIgcm91bmRlZC1mdWxsIHRleHQtWzEwcHhdIGZvbnQtYm9sZCBiZy1hbWJlci02MDAgdGV4dC13aGl0ZVwiPlxyXG4gICAgICAgICAgICAgICAge25vdGlmaWNhY29lcy5sZW5ndGh9XHJcbiAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICApfVxyXG4gICAgICAgICAgPC9MaW5rPlxyXG5cclxuICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldE1vZGFsTm92YUFiZXJ0YSh0cnVlKX1cclxuICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNCBweS0yIHRleHQteHMgZm9udC1ib2xkIHRleHQtd2hpdGUgYmctdGVhbC02MDAgaG92ZXI6YmctdGVhbC03MDAgcm91bmRlZC14bCBzaGFkb3cteHMgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdHJhbnNpdGlvbi1jb2xvcnNcIlxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICA8UGx1cyBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz5cclxuICAgICAgICAgICAgPHNwYW4+Tm92YSBJbnNwZcOnw6NvPC9zcGFuPlxyXG4gICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgey8qIENhcmRzIGRlIFJlc3VtbyBPcGVyYWNpb25hbCAqL31cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIHNtOmdyaWQtY29scy0yIGxnOmdyaWQtY29scy00IGdhcC00XCI+XHJcbiAgICAgICAgey8qIENhcmQgMTogVG90YWwgQXRpdmFzICovfVxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGFyazpiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtODAwIHJvdW5kZWQteGwgcC00IHNoYWRvdy0yeHNcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTUwMCBkYXJrOnRleHQtc2xhdGUtNDAwXCI+XHJcbiAgICAgICAgICAgICAgVmlzdG9yaWFzIG5vIFBlcsOtb2RvXHJcbiAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgPEZpbGVUZXh0IGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC10ZWFsLTYwMCBkYXJrOnRleHQtdGVhbC00MDBcIiAvPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTIgZmxleCBpdGVtcy1iYXNlbGluZSBnYXAtMlwiPlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGQgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlXCI+XHJcbiAgICAgICAgICAgICAge2luc3BlY29lcy5sZW5ndGh9XHJcbiAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1zbGF0ZS00MDBcIj5yZWdpc3Ryb3M8L3NwYW4+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgey8qIENhcmQgMjogUHJhem9zIGUgQWxlcnRhcyAqL31cclxuICAgICAgICA8TGlua1xyXG4gICAgICAgICAgdG89e1JPVVRFUy5JTlNQRUNPRVMuUFJBWk9TfVxyXG4gICAgICAgICAgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGFyazpiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtODAwIHJvdW5kZWQteGwgcC00IHNoYWRvdy0yeHMgaG92ZXI6Ym9yZGVyLWFtYmVyLTQwMCB0cmFuc2l0aW9uLWNvbG9ycyBibG9ja1wiXHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNTAwIGRhcms6dGV4dC1zbGF0ZS00MDBcIj5cclxuICAgICAgICAgICAgICBOb3RpZmljYcOnw7VlcyBjb20gUHJhem9cclxuICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICA8Q2xvY2sgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LWFtYmVyLTUwMFwiIC8+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMiBmbGV4IGl0ZW1zLWJhc2VsaW5lIGdhcC0yXCI+XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LWFtYmVyLTYwMCBkYXJrOnRleHQtYW1iZXItNDAwXCI+XHJcbiAgICAgICAgICAgICAge25vdGlmaWNhY29lcy5sZW5ndGh9XHJcbiAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAge3RvdGFsTm90aWZpY2Fjb2VzVmVuY2lkYXMgPiAwICYmIChcclxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSBmb250LWJvbGQgdGV4dC1yb3NlLTYwMCBiZy1yb3NlLTUwIHB4LTEuNSBweS0wLjUgcm91bmRlZCBib3JkZXIgYm9yZGVyLXJvc2UtMjAwXCI+XHJcbiAgICAgICAgICAgICAgICB7dG90YWxOb3RpZmljYWNvZXNWZW5jaWRhc30gdmVuY2lkYShzKVxyXG4gICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgKX1cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvTGluaz5cclxuXHJcbiAgICAgICAgey8qIENhcmQgMzogSW5kaWNhZG9yIDExIFZBUFQgKi99XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC14bCBwLTQgc2hhZG93LTJ4c1wiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNTAwIGRhcms6dGV4dC1zbGF0ZS00MDBcIj5cclxuICAgICAgICAgICAgICBJbmRpY2Fkb3IgMTEgKFZBUFQpXHJcbiAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgPEhhcmRIYXQgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LXRlYWwtNjAwIGRhcms6dGV4dC10ZWFsLTQwMFwiIC8+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMiBmbGV4IGl0ZW1zLWJhc2VsaW5lIGdhcC0yXCI+XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LXRlYWwtNzAwIGRhcms6dGV4dC10ZWFsLTMwMFwiPlxyXG4gICAgICAgICAgICAgIHt0b3RhbEFjb2VzVmFwdH1cclxuICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LXRlYWwtNjAwIGRhcms6dGV4dC10ZWFsLTQwMCBmb250LW1lZGl1bVwiPlxyXG4gICAgICAgICAgICAgIGHDp8O1ZXMgcGFjdHVhZGFzXHJcbiAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICB7LyogQ2FyZCA0OiBDb25jbHXDrWRhcyBjb20gU3VjZXNzbyAqL31cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIGRhcms6Ymctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLXhsIHAtNCBzaGFkb3ctMnhzXCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS01MDAgZGFyazp0ZXh0LXNsYXRlLTQwMFwiPlxyXG4gICAgICAgICAgICAgIExhdWRvcyBDb25jbHXDrWRvc1xyXG4gICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgIDxDaGVja0NpcmNsZTIgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LWVtZXJhbGQtNjAwIGRhcms6dGV4dC1lbWVyYWxkLTQwMFwiIC8+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMiBmbGV4IGl0ZW1zLWJhc2VsaW5lIGdhcC0yXCI+XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LWVtZXJhbGQtNjAwIGRhcms6dGV4dC1lbWVyYWxkLTQwMFwiPlxyXG4gICAgICAgICAgICAgIHtpbnNwZWNvZXMuZmlsdGVyKChpKSA9PiBpLnN0YXR1cyA9PT0gXCJjb25jbHVpZGFcIikubGVuZ3RofVxyXG4gICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtc2xhdGUtNDAwXCI+ZmluYWxpemFkYXM8L3NwYW4+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICB7LyogQWJhcyBlIEJhcnJhIGRlIEZpbHRyb3MgKi99XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGFyazpiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtODAwIHJvdW5kZWQtMnhsIHNoYWRvdy14cyBvdmVyZmxvdy1oaWRkZW5cIj5cclxuICAgICAgICB7LyogQWJhcyBkZSBOYXZlZ2HDp8OjbyAqL31cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJvcmRlci1iIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtODAwIHB4LTYgcHQtMyBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTQgb3ZlcmZsb3cteC1hdXRvXCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC02XCI+XHJcbiAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRUYWJBdGl2YShcInRvZGFzXCIpfVxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT17YHBiLTMgdGV4dC14cyBmb250LWJvbGQgYm9yZGVyLWItMiB0cmFuc2l0aW9uLWNvbG9ycyB3aGl0ZXNwYWNlLW5vd3JhcCAke1xyXG4gICAgICAgICAgICAgICAgdGFiQXRpdmEgPT09IFwidG9kYXNcIlxyXG4gICAgICAgICAgICAgICAgICA/IFwiYm9yZGVyLXRlYWwtNjAwIHRleHQtdGVhbC02MDAgZGFyazp0ZXh0LXRlYWwtNDAwXCJcclxuICAgICAgICAgICAgICAgICAgOiBcImJvcmRlci10cmFuc3BhcmVudCB0ZXh0LXNsYXRlLTUwMCBob3Zlcjp0ZXh0LXNsYXRlLTgwMCBkYXJrOmhvdmVyOnRleHQtc2xhdGUtMzAwXCJcclxuICAgICAgICAgICAgICB9YH1cclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIFRvZGFzIGFzIEluc3Blw6fDtWVzXHJcbiAgICAgICAgICAgIDwvYnV0dG9uPlxyXG5cclxuICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFRhYkF0aXZhKFwiYWdlbmRhZGFzXCIpfVxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT17YHBiLTMgdGV4dC14cyBmb250LWJvbGQgYm9yZGVyLWItMiB0cmFuc2l0aW9uLWNvbG9ycyB3aGl0ZXNwYWNlLW5vd3JhcCAke1xyXG4gICAgICAgICAgICAgICAgdGFiQXRpdmEgPT09IFwiYWdlbmRhZGFzXCJcclxuICAgICAgICAgICAgICAgICAgPyBcImJvcmRlci10ZWFsLTYwMCB0ZXh0LXRlYWwtNjAwIGRhcms6dGV4dC10ZWFsLTQwMFwiXHJcbiAgICAgICAgICAgICAgICAgIDogXCJib3JkZXItdHJhbnNwYXJlbnQgdGV4dC1zbGF0ZS01MDAgaG92ZXI6dGV4dC1zbGF0ZS04MDAgZGFyazpob3Zlcjp0ZXh0LXNsYXRlLTMwMFwiXHJcbiAgICAgICAgICAgICAgfWB9XHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICBBZ2VuZGFkYXNcclxuICAgICAgICAgICAgPC9idXR0b24+XHJcblxyXG4gICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0VGFiQXRpdmEoXCJlbV9hbmRhbWVudG9cIil9XHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcGItMyB0ZXh0LXhzIGZvbnQtYm9sZCBib3JkZXItYi0yIHRyYW5zaXRpb24tY29sb3JzIHdoaXRlc3BhY2Utbm93cmFwICR7XHJcbiAgICAgICAgICAgICAgICB0YWJBdGl2YSA9PT0gXCJlbV9hbmRhbWVudG9cIlxyXG4gICAgICAgICAgICAgICAgICA/IFwiYm9yZGVyLXRlYWwtNjAwIHRleHQtdGVhbC02MDAgZGFyazp0ZXh0LXRlYWwtNDAwXCJcclxuICAgICAgICAgICAgICAgICAgOiBcImJvcmRlci10cmFuc3BhcmVudCB0ZXh0LXNsYXRlLTUwMCBob3Zlcjp0ZXh0LXNsYXRlLTgwMCBkYXJrOmhvdmVyOnRleHQtc2xhdGUtMzAwXCJcclxuICAgICAgICAgICAgICB9YH1cclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIEVtIEFuZGFtZW50b1xyXG4gICAgICAgICAgICA8L2J1dHRvbj5cclxuXHJcbiAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRUYWJBdGl2YShcImNvbmNsdWlkYXNcIil9XHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcGItMyB0ZXh0LXhzIGZvbnQtYm9sZCBib3JkZXItYi0yIHRyYW5zaXRpb24tY29sb3JzIHdoaXRlc3BhY2Utbm93cmFwICR7XHJcbiAgICAgICAgICAgICAgICB0YWJBdGl2YSA9PT0gXCJjb25jbHVpZGFzXCJcclxuICAgICAgICAgICAgICAgICAgPyBcImJvcmRlci10ZWFsLTYwMCB0ZXh0LXRlYWwtNjAwIGRhcms6dGV4dC10ZWFsLTQwMFwiXHJcbiAgICAgICAgICAgICAgICAgIDogXCJib3JkZXItdHJhbnNwYXJlbnQgdGV4dC1zbGF0ZS01MDAgaG92ZXI6dGV4dC1zbGF0ZS04MDAgZGFyazpob3Zlcjp0ZXh0LXNsYXRlLTMwMFwiXHJcbiAgICAgICAgICAgICAgfWB9XHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICBDb25jbHXDrWRhc1xyXG4gICAgICAgICAgICA8L2J1dHRvbj5cclxuXHJcbiAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRUYWJBdGl2YShcInZhcHRcIil9XHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcGItMyB0ZXh0LXhzIGZvbnQtYm9sZCBib3JkZXItYi0yIHRyYW5zaXRpb24tY29sb3JzIHdoaXRlc3BhY2Utbm93cmFwIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgJHtcclxuICAgICAgICAgICAgICAgIHRhYkF0aXZhID09PSBcInZhcHRcIlxyXG4gICAgICAgICAgICAgICAgICA/IFwiYm9yZGVyLXRlYWwtNjAwIHRleHQtdGVhbC02MDAgZGFyazp0ZXh0LXRlYWwtNDAwXCJcclxuICAgICAgICAgICAgICAgICAgOiBcImJvcmRlci10cmFuc3BhcmVudCB0ZXh0LXNsYXRlLTUwMCBob3Zlcjp0ZXh0LXNsYXRlLTgwMCBkYXJrOmhvdmVyOnRleHQtc2xhdGUtMzAwXCJcclxuICAgICAgICAgICAgICB9YH1cclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIDxIYXJkSGF0IGNsYXNzTmFtZT1cInctMy41IGgtMy41XCIgLz5cclxuICAgICAgICAgICAgICA8c3Bhbj5Bw6fDtWVzIFZBUFQgKEluZC4gMTEpPC9zcGFuPlxyXG4gICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHJlZmV0Y2goKX1cclxuICAgICAgICAgICAgZGlzYWJsZWQ9e2lzUmVmZXRjaGluZ31cclxuICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0xLjUgdGV4dC1zbGF0ZS00MDAgaG92ZXI6dGV4dC1zbGF0ZS02MDAgZGFyazpob3Zlcjp0ZXh0LXNsYXRlLTMwMCByb3VuZGVkLWxnIGhvdmVyOmJnLXNsYXRlLTEwMCBkYXJrOmhvdmVyOmJnLXNsYXRlLTgwMCBtYi0yIHRyYW5zaXRpb24tY29sb3JzXCJcclxuICAgICAgICAgICAgdGl0bGU9XCJBdHVhbGl6YXIgbGlzdGFcIlxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICA8UmVmcmVzaEN3XHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgdy00IGgtNCAke2lzUmVmZXRjaGluZyA/IFwiYW5pbWF0ZS1zcGluIHRleHQtdGVhbC02MDBcIiA6IFwiXCJ9YH1cclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICB7LyogTGluaGEgZGUgQnVzY2EgZSBGaWx0cm9zICovfVxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC00IGJnLXNsYXRlLTUwLzUwIGRhcms6Ymctc2xhdGUtODAwLzQwIGJvcmRlci1iIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtODAwIGZsZXggZmxleC1jb2wgc206ZmxleC1yb3cgc206aXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtM1wiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBmbGV4LTEgbWF4LXctbWRcIj5cclxuICAgICAgICAgICAgPFNlYXJjaCBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtc2xhdGUtNDAwIGFic29sdXRlIGxlZnQtMyB0b3AtMi41XCIgLz5cclxuICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiQnVzY2FyIHBvciB0ZXJtbyAoZXg6IFRFUk0tMjAyNiksIGxvY2FsIG91IG1vdGl2by4uLlwiXHJcbiAgICAgICAgICAgICAgdmFsdWU9e2J1c2NhfVxyXG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0QnVzY2EoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBwbC05IHByLTQgcHktMiB0ZXh0LXhzIGJnLXdoaXRlIGRhcms6Ymctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCByb3VuZGVkLXhsIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZSBwbGFjZWhvbGRlci1zbGF0ZS00MDAgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLXRlYWwtNTAwXCJcclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIHt0YWJBdGl2YSAhPT0gXCJ2YXB0XCIgJiYgKFxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgPEZpbHRlciBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNSB0ZXh0LXNsYXRlLTQwMFwiIC8+XHJcbiAgICAgICAgICAgICAgPHNlbGVjdFxyXG4gICAgICAgICAgICAgICAgdmFsdWU9e21vdGl2b0ZpbHRyb31cclxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0TW90aXZvRmlsdHJvKGUudGFyZ2V0LnZhbHVlIGFzIGFueSl9XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC0zIHB5LTEuNSB0ZXh0LXhzIGJnLXdoaXRlIGRhcms6Ymctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCByb3VuZGVkLXhsIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0yMDAgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLXRlYWwtNTAwXCJcclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiXCI+VG9kb3Mgb3MgTW90aXZvczwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cInJvdGluYV9wcm9ncmFtYWRhXCI+Um90aW5hIFByb2dyYW1hZGE8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJyZXF1ZXJpbWVudG9fYWx2YXJhXCI+UmVxdWVyaW1lbnRvIGRlIEFsdmFyw6E8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJkZW51bmNpYVwiPkF0ZW5kaW1lbnRvIGEgRGVuw7puY2lhPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwicmVpbnNwZWNhb1wiPlJlaW5zcGXDp8OjbyBGaXNjYWw8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJ2YXB0X3RyYWJhbGhhZG9yXCI+VkFQVCAtIFNhw7pkZSBkbyBUcmFiYWxoYWRvcjwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cImludmVzdGlnYWNhb19zdXJ0b1wiPkludmVzdGlnYcOnw6NvIGRlIFN1cnRvPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgPC9zZWxlY3Q+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgKX1cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgey8qIFRhYmVsYSBkZSBWaXN0b3JpYXMgKi99XHJcbiAgICAgICAge2lzTG9hZGluZyA/IChcclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0xNiB0ZXh0LWNlbnRlciB0ZXh0LXNsYXRlLTQwMCB0ZXh0LXhzIGZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyXCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy02IGgtNiBib3JkZXItMiBib3JkZXItdGVhbC01MDAgYm9yZGVyLXQtdHJhbnNwYXJlbnQgcm91bmRlZC1mdWxsIGFuaW1hdGUtc3BpbiBtYi0zXCIgLz5cclxuICAgICAgICAgICAgPHNwYW4+Q29uc3VsdGFuZG8gcmVnaXN0cm9zIGRlIGZpc2NhbGl6YcOnw6NvLi4uPC9zcGFuPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgKSA6IGluc3BlY29lc0ZpbHRyYWRhcy5sZW5ndGggPT09IDAgPyAoXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMTIgdGV4dC1jZW50ZXIgdGV4dC1zbGF0ZS01MDAgZGFyazp0ZXh0LXNsYXRlLTQwMCBzcGFjZS15LTNcIj5cclxuICAgICAgICAgICAgPFNoaWVsZEFsZXJ0IGNsYXNzTmFtZT1cInctMTAgaC0xMCB0ZXh0LXNsYXRlLTMwMCBkYXJrOnRleHQtc2xhdGUtNzAwIG14LWF1dG9cIiAvPlxyXG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTMwMFwiPlxyXG4gICAgICAgICAgICAgIE5lbmh1bWEgaW5zcGXDp8OjbyBzYW5pdMOhcmlhIGVuY29udHJhZGEgcGFyYSBvcyBjcml0w6lyaW9zIHNlbGVjaW9uYWRvcy5cclxuICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LXNsYXRlLTQwMCBtYXgtdy1zbSBteC1hdXRvXCI+XHJcbiAgICAgICAgICAgICAgVXRpbGl6ZSBvIGJvdMOjbyBcIk5vdmEgSW5zcGXDp8Ojb1wiIHBhcmEgYWJyaXIgdW0gbm92byB0ZXJtbyBvZmljaWFsIGRlIGZpc2NhbGl6YcOnw6NvIGRlIGNhbXBvLlxyXG4gICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRNb2RhbE5vdmFBYmVydGEodHJ1ZSl9XHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibXQtMiBweC00IHB5LTIgdGV4dC14cyBmb250LWJvbGQgdGV4dC10ZWFsLTcwMCBkYXJrOnRleHQtdGVhbC0zMDAgYmctdGVhbC01MCBkYXJrOmJnLXRlYWwtOTUwLzQwIGJvcmRlciBib3JkZXItdGVhbC0yMDAgZGFyazpib3JkZXItdGVhbC04MDAgcm91bmRlZC14bCBob3ZlcjpiZy10ZWFsLTEwMC82MCBpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNVwiXHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICA8UGx1cyBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNVwiIC8+XHJcbiAgICAgICAgICAgICAgPHNwYW4+QWJyaXIgTm92byBUZXJtbzwvc3Bhbj5cclxuICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICApIDogKFxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJvdmVyZmxvdy14LWF1dG9cIj5cclxuICAgICAgICAgICAgPHRhYmxlIGNsYXNzTmFtZT1cInctZnVsbCB0ZXh0LWxlZnQgdGV4dC14cyBib3JkZXItY29sbGFwc2VcIj5cclxuICAgICAgICAgICAgICA8dGhlYWQgY2xhc3NOYW1lPVwiYmctc2xhdGUtNTAvODAgZGFyazpiZy1zbGF0ZS04MDAvNjAgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgdGV4dC1zbGF0ZS01MDAgZGFyazp0ZXh0LXNsYXRlLTQwMCBmb250LXNlbWlib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPlxyXG4gICAgICAgICAgICAgICAgPHRyPlxyXG4gICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMy41IHB4LTRcIj5UZXJtbyAvIFByb3RvY29sbzwvdGg+XHJcbiAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0zLjUgcHgtNFwiPk1vdGl2byAvIFRpcG88L3RoPlxyXG4gICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMy41IHB4LTRcIj5EYXRhIFZpc3RvcmlhPC90aD5cclxuICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB5LTMuNSBweC00XCI+U3RhdHVzPC90aD5cclxuICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB5LTMuNSBweC00XCI+UGFyZWNlciAvIFJlc3VsdGFkbzwvdGg+XHJcbiAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0zLjUgcHgtNCB0ZXh0LXJpZ2h0XCI+QcOnw7VlczwvdGg+XHJcbiAgICAgICAgICAgICAgICA8L3RyPlxyXG4gICAgICAgICAgICAgIDwvdGhlYWQ+XHJcbiAgICAgICAgICAgICAgPHRib2R5IGNsYXNzTmFtZT1cImRpdmlkZS15IGRpdmlkZS1zbGF0ZS0xMDAgZGFyazpkaXZpZGUtc2xhdGUtODAwXCI+XHJcbiAgICAgICAgICAgICAgICB7aW5zcGVjb2VzRmlsdHJhZGFzLm1hcCgoaXRlbSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICBjb25zdCBpc1ZhcHQgPSBpdGVtLm1vdGl2byA9PT0gXCJ2YXB0X3RyYWJhbGhhZG9yXCI7XHJcblxyXG4gICAgICAgICAgICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgICAgICAgICAgIDx0clxyXG4gICAgICAgICAgICAgICAgICAgICAga2V5PXtpdGVtLmlkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaG92ZXI6Ymctc2xhdGUtNTAvNjAgZGFyazpob3ZlcjpiZy1zbGF0ZS04MDAvNDAgdHJhbnNpdGlvbi1jb2xvcnMgZ3JvdXBcIlxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIHsvKiBUZXJtbyAqL31cclxuICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS0zLjUgcHgtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2xcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1vbm8gZm9udC1ib2xkIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2l0ZW0ubnVtZXJvX3Rlcm1vfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LXNsYXRlLTQwMCBmb250LW1vbm9cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIElEOiB7aXRlbS5pZC5zdWJzdHJpbmcoMCwgOCl9Li4uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgey8qIE1vdGl2byAqL31cclxuICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS0zLjUgcHgtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgZ2FwLTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpc1ZhcHQgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8SGFyZEhhdCBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNSB0ZXh0LXRlYWwtNjAwIGRhcms6dGV4dC10ZWFsLTQwMCBzaHJpbmstMFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTgwMCBkYXJrOnRleHQtc2xhdGUtMjAwIGNhcGl0YWxpemVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2l0ZW0ubW90aXZvLnJlcGxhY2UoL18vZywgXCIgXCIpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtpc1ZhcHQgJiYgaXRlbS5ub21lX2xvY2FsX3RyYWJhbGhvICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtdGVhbC02MDAgZGFyazp0ZXh0LXRlYWwtNDAwIGJnLXRlYWwtNTAgZGFyazpiZy10ZWFsLTk1MC80MCBweC0xLjUgcHktMC41IHJvdW5kZWQgYm9yZGVyIGJvcmRlci10ZWFsLTIwMCBkYXJrOmJvcmRlci10ZWFsLTgwMCB3LWZpdFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBMb2NhbDoge2l0ZW0ubm9tZV9sb2NhbF90cmFiYWxob31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgey8qIERhdGEgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMy41IHB4LTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIHRleHQtc2xhdGUtNjAwIGRhcms6dGV4dC1zbGF0ZS0zMDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1lZGl1bVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge25ldyBEYXRlKGl0ZW0uZGF0YV9pbmljaW8pLnRvTG9jYWxlRGF0ZVN0cmluZyhcInB0LUJSXCIpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7aXRlbS5ob3JhX2luc3BlY2FvICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtc2xhdGUtNDAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIMOAcyB7aXRlbS5ob3JhX2luc3BlY2FvfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC90ZD5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICB7LyogU3RhdHVzICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTMuNSBweC00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxTdGF0dXNJbnNwZWNhb0JhZGdlIHN0YXR1cz17aXRlbS5zdGF0dXN9IC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgIHsvKiBQYXJlY2VyIC8gUmVzdWx0YWRvICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTMuNSBweC00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxSZXN1bHRhZG9JbnNwZWNhb0JhZGdlIHJlc3VsdGFkbz17aXRlbS5yZXN1bHRhZG99IC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtpdGVtLnJlc3VsdGFkbyA9PT0gXCJub3RpZmljYWRvX2NvbV9wcmF6b1wiICYmIGl0ZW0uZGF0YV9saW1pdGVfYWRlcXVhY2FvICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTEgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgdGV4dC1bMTBweF0gdGV4dC1hbWJlci02MDAgZm9udC1tZWRpdW1cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxDbG9jayBjbGFzc05hbWU9XCJ3LTMgaC0zXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBMaW1pdGU6e1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7bmV3IERhdGUoaXRlbS5kYXRhX2xpbWl0ZV9hZGVxdWFjYW8pLnRvTG9jYWxlRGF0ZVN0cmluZyhcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcInB0LUJSXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgey8qIEHDp8O1ZXMgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMy41IHB4LTQgdGV4dC1yaWdodFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktZW5kIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPExpbmtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvPXtST1VURVMuSU5TUEVDT0VTLkxBVURPKGl0ZW0uaWQpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHgtMyBweS0xLjUgdGV4dC14cyBmb250LWJvbGQgcm91bmRlZC1sZyBib3JkZXIgdHJhbnNpdGlvbi1jb2xvcnMgaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgJHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5zdGF0dXMgPT09IFwiY29uY2x1aWRhXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IFwiYmctc2xhdGUtNTAgZGFyazpiZy1zbGF0ZS04MDAgdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTIwMCBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCBob3ZlcjpiZy1zbGF0ZS0xMDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogXCJiZy10ZWFsLTYwMCB0ZXh0LXdoaXRlIGJvcmRlci10ZWFsLTYwMCBob3ZlcjpiZy10ZWFsLTcwMCBzaGFkb3ctMnhzXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGaWxlVGV4dCBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNVwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2l0ZW0uc3RhdHVzID09PSBcImNvbmNsdWlkYVwiID8gXCJWZXIgTGF1ZG9cIiA6IFwiTGF2cmFyIExhdWRvXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgPC90cj5cclxuICAgICAgICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgICAgIH0pfVxyXG4gICAgICAgICAgICAgIDwvdGJvZHk+XHJcbiAgICAgICAgICAgIDwvdGFibGU+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICApfVxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIHsvKiBNb2RhbCBkZSBBYmVydHVyYSAvIEFnZW5kYW1lbnRvICovfVxyXG4gICAgICA8QWdlbmRhckluc3BlY2FvTW9kYWxcclxuICAgICAgICBpc09wZW49e21vZGFsTm92YUFiZXJ0YX1cclxuICAgICAgICBvbkNsb3NlPXsoKSA9PiBzZXRNb2RhbE5vdmFBYmVydGEoZmFsc2UpfVxyXG4gICAgICAgIGVzdGFiZWxlY2ltZW50b0lkUHJlRGVmaW5pZG89e2VzdGFiZWxlY2ltZW50b0lkUGFyYW0gfHwgdW5kZWZpbmVkfVxyXG4gICAgICAgIG9uU3VjZXNzbz17KGluc3BlY2FvKSA9PiB7XHJcbiAgICAgICAgICBpZiAoaW5zcGVjYW8/LmlkKSB7XHJcbiAgICAgICAgICAgIG5hdmlnYXRlKFJPVVRFUy5JTlNQRUNPRVMuTEFVRE8oaW5zcGVjYW8uaWQpKTtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9fVxyXG4gICAgICAvPlxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IEluc3BlY29lc0xpc3RQYWdlO1xyXG4iXX0=