import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/UsuariosPage.tsx");const React = __vite__cjsImport0_react;const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"];/**
* Módulo de Gestão de Servidores & Usuários (UsuariosPage)
* Exclusivo para Coordenadores e Admin Master.
*/
import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=0fd2848a";
import { useQuery } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=0fd2848a";
import { UserCheck, Users } from "/node_modules/.vite/deps/lucide-react.js?v=0fd2848a";
import { apiClient } from "/src/services/apiClient.ts";
var _jsxFileName = "E:/Projetos VSCODE/visa_braunas/src/pages/UsuariosPage.tsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=0fd2848a";
var _s = $RefreshSig$();
export const UsuariosPage = () => {
	_s();
	const { data: usuarios = [], isLoading } = useQuery({
		queryKey: ["usuarios"],
		queryFn: async () => {
			const res = await apiClient.get("/usuarios");
			return res.data;
		}
	});
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "space-y-6",
		children: [/* @__PURE__ */ _jsxDEV("div", {
			className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 shadow-xs",
			children: [/* @__PURE__ */ _jsxDEV("h1", {
				className: "text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2",
				children: [/* @__PURE__ */ _jsxDEV(Users, { className: "w-5 h-5 text-teal-600" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 25,
					columnNumber: 11
				}, this), "Servidores & Usuários do Sistema"]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 24,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("p", {
				className: "text-xs text-slate-500 dark:text-slate-400 mt-1",
				children: "Gestão de contas públicas, portarias de nomeação e controle de acesso RBAC."
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 28,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 23,
			columnNumber: 7
		}, this), isLoading ? /* @__PURE__ */ _jsxDEV("div", {
			className: "p-12 text-center text-slate-400 text-xs flex flex-col items-center justify-center",
			children: [/* @__PURE__ */ _jsxDEV("div", { className: "w-6 h-6 border-2 border-teal-500 border-t-transparent rounded-full animate-spin mb-3" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 35,
				columnNumber: 11
			}, this), "Carregando usuários cadastrados..."]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 34,
			columnNumber: 9
		}, this) : /* @__PURE__ */ _jsxDEV("div", {
			className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden shadow-xs",
			children: /* @__PURE__ */ _jsxDEV("div", {
				className: "overflow-x-auto",
				children: /* @__PURE__ */ _jsxDEV("table", {
					className: "w-full text-left text-xs",
					children: [/* @__PURE__ */ _jsxDEV("thead", {
						className: "bg-slate-50 dark:bg-slate-800/60 border-b border-slate-200 dark:border-slate-800 text-slate-500 font-semibold uppercase tracking-wider",
						children: /* @__PURE__ */ _jsxDEV("tr", { children: [
							/* @__PURE__ */ _jsxDEV("th", {
								className: "py-3 px-4",
								children: "Nome Completo / E-mail"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 44,
								columnNumber: 19
							}, this),
							/* @__PURE__ */ _jsxDEV("th", {
								className: "py-3 px-4",
								children: "Matrícula / Portaria"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 45,
								columnNumber: 19
							}, this),
							/* @__PURE__ */ _jsxDEV("th", {
								className: "py-3 px-4",
								children: "Cargo"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 46,
								columnNumber: 19
							}, this),
							/* @__PURE__ */ _jsxDEV("th", {
								className: "py-3 px-4",
								children: "Perfil RBAC"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 47,
								columnNumber: 19
							}, this),
							/* @__PURE__ */ _jsxDEV("th", {
								className: "py-3 px-4",
								children: "Status"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 48,
								columnNumber: 19
							}, this)
						] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 43,
							columnNumber: 17
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 42,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("tbody", {
						className: "divide-y divide-slate-100 dark:divide-slate-800",
						children: usuarios.map((usr) => /* @__PURE__ */ _jsxDEV("tr", {
							className: "hover:bg-slate-50/50 dark:hover:bg-slate-800/40",
							children: [
								/* @__PURE__ */ _jsxDEV("td", {
									className: "py-3 px-4",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "font-semibold text-slate-900 dark:text-white",
										children: usr.nome_completo
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 55,
										columnNumber: 23
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "text-[11px] text-slate-400 font-mono",
										children: usr.email
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 58,
										columnNumber: 23
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 54,
									columnNumber: 21
								}, this),
								/* @__PURE__ */ _jsxDEV("td", {
									className: "py-3 px-4 text-slate-700 dark:text-slate-300",
									children: [/* @__PURE__ */ _jsxDEV("div", { children: usr.matricula || "—" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 63,
										columnNumber: 23
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "text-[10px] text-slate-400",
										children: usr.portaria_nomeacao || "—"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 64,
										columnNumber: 23
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 62,
									columnNumber: 21
								}, this),
								/* @__PURE__ */ _jsxDEV("td", {
									className: "py-3 px-4 text-slate-700 dark:text-slate-300",
									children: usr.cargo
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 66,
									columnNumber: 21
								}, this),
								/* @__PURE__ */ _jsxDEV("td", {
									className: "py-3 px-4",
									children: /* @__PURE__ */ _jsxDEV("span", {
										className: "inline-block px-2 py-0.5 rounded text-[10px] font-semibold bg-purple-50 dark:bg-purple-950/40 text-purple-700 dark:text-purple-300 border border-purple-200 dark:border-purple-800 uppercase",
										children: usr.perfil.replace(/_/g, " ")
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 70,
										columnNumber: 23
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 69,
									columnNumber: 21
								}, this),
								/* @__PURE__ */ _jsxDEV("td", {
									className: "py-3 px-4",
									children: /* @__PURE__ */ _jsxDEV("span", {
										className: "inline-flex items-center gap-1 text-[11px] text-emerald-600 dark:text-emerald-400 font-medium",
										children: [/* @__PURE__ */ _jsxDEV(UserCheck, { className: "w-3.5 h-3.5" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 76,
											columnNumber: 25
										}, this), usr.is_active ? "Ativo" : "Inativo"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 75,
										columnNumber: 23
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 74,
									columnNumber: 21
								}, this)
							]
						}, usr.id, true, {
							fileName: _jsxFileName,
							lineNumber: 53,
							columnNumber: 19
						}, this))
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 51,
						columnNumber: 15
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 41,
					columnNumber: 13
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 40,
				columnNumber: 11
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 39,
			columnNumber: 9
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 22,
		columnNumber: 5
	}, this);
};
_s(UsuariosPage, "EoTipho22f2dKPgB4bFxIPlK8Qk=", false, function() {
	return [useQuery];
});
_c = UsuariosPage;
export default UsuariosPage;
var _c;
$RefreshReg$(_c, "UsuariosPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/UsuariosPage.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("E:/Projetos VSCODE/visa_braunas/src/pages/UsuariosPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("E:/Projetos VSCODE/visa_braunas/src/pages/UsuariosPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "E:/Projetos VSCODE/visa_braunas/src/pages/UsuariosPage.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7OztBQUtBLE9BQU8sV0FBVztBQUNsQixTQUFTLGdCQUFnQjtBQUN6QixTQUFpQixXQUFXLGFBQWE7QUFDekMsU0FBUyxpQkFBaUI7Ozs7QUFHMUIsT0FBTyxNQUFNLHFCQUErQjs7Q0FDMUMsTUFBTSxFQUFFLE1BQU0sV0FBVyxDQUFDLEdBQUcsY0FBYyxTQUEwQjtFQUNuRSxVQUFVLENBQUMsVUFBVTtFQUNyQixTQUFTLFlBQVk7R0FDbkIsTUFBTSxNQUFNLE1BQU0sVUFBVSxJQUFxQixXQUFXO0dBQzVELE9BQU8sSUFBSTtFQUNiO0NBQ0YsQ0FBQztDQUVELE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBZixDQUNFLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWYsQ0FDRSx3QkFBQyxNQUFEO0lBQUksV0FBVTtjQUFkLENBQ0Usd0JBQUMsT0FBRCxFQUFPLFdBQVUsd0JBQXlCOzs7O2NBQUMsa0NBRXpDOzs7OzthQUNKLHdCQUFDLEtBQUQ7SUFBRyxXQUFVO2NBQWtEO0dBRTVEOzs7O1dBQ0E7Ozs7O1lBRUosWUFDQyx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmLENBQ0Usd0JBQUMsT0FBRCxFQUFLLFdBQVUsdUZBQXdGOzs7O2FBQUMsb0NBRXJHOzs7OzthQUVMLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQ2Isd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FDYix3QkFBQyxTQUFEO0tBQU8sV0FBVTtlQUFqQixDQUNFLHdCQUFDLFNBQUQ7TUFBTyxXQUFVO2dCQUNmLHdCQUFDLE1BQUQ7T0FDRSx3QkFBQyxNQUFEO1FBQUksV0FBVTtrQkFBWTtPQUEwQjs7Ozs7T0FDcEQsd0JBQUMsTUFBRDtRQUFJLFdBQVU7a0JBQVk7T0FBd0I7Ozs7O09BQ2xELHdCQUFDLE1BQUQ7UUFBSSxXQUFVO2tCQUFZO09BQVM7Ozs7O09BQ25DLHdCQUFDLE1BQUQ7UUFBSSxXQUFVO2tCQUFZO09BQWU7Ozs7O09BQ3pDLHdCQUFDLE1BQUQ7UUFBSSxXQUFVO2tCQUFZO09BQVU7Ozs7O01BQ2xDOzs7OztLQUNDOzs7O2VBQ1Asd0JBQUMsU0FBRDtNQUFPLFdBQVU7Z0JBQ2QsU0FBUyxLQUFLLFFBQ2Isd0JBQUMsTUFBRDtPQUFpQixXQUFVO2lCQUEzQjtRQUNFLHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUFkLENBQ0Usd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQ1osSUFBSTtTQUNGOzs7O21CQUNMLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUNaLElBQUk7U0FDRjs7OztpQkFDSDs7Ozs7O1FBQ0osd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQWQsQ0FDRSx3QkFBQyxPQUFELFlBQU0sSUFBSSxhQUFhLElBQVM7Ozs7bUJBQ2hDLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUE4QixJQUFJLHFCQUFxQjtTQUFTOzs7O2lCQUM3RTs7Ozs7O1FBQ0osd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQ1gsSUFBSTtRQUNIOzs7OztRQUNKLHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUNaLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUNiLElBQUksT0FBTyxRQUFRLE1BQU0sR0FBRztTQUN6Qjs7Ozs7UUFDSjs7Ozs7UUFDSix3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFDWix3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBaEIsQ0FDRSx3QkFBQyxXQUFELEVBQVcsV0FBVSxjQUFlOzs7O29CQUNuQyxJQUFJLFlBQVksVUFBVSxTQUN2Qjs7Ozs7O1FBQ0o7Ozs7O09BQ0Y7U0EzQkssSUFBSTs7OzthQTJCVCxDQUNMO0tBQ0k7Ozs7YUFDRjs7Ozs7O0dBQ0o7Ozs7O0VBQ0Y7Ozs7VUFFSjs7Ozs7O0FBRVQ7Ozs7O0FBRUEsZUFBZSIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJVc3Vhcmlvc1BhZ2UudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbIi8qKlxyXG4gKiBNw7NkdWxvIGRlIEdlc3TDo28gZGUgU2Vydmlkb3JlcyAmIFVzdcOhcmlvcyAoVXN1YXJpb3NQYWdlKVxyXG4gKiBFeGNsdXNpdm8gcGFyYSBDb29yZGVuYWRvcmVzIGUgQWRtaW4gTWFzdGVyLlxyXG4gKi9cclxuXHJcbmltcG9ydCBSZWFjdCBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHsgdXNlUXVlcnkgfSBmcm9tIFwiQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5XCI7XHJcbmltcG9ydCB7IFNoaWVsZCwgVXNlckNoZWNrLCBVc2VycyB9IGZyb20gXCJsdWNpZGUtcmVhY3RcIjtcclxuaW1wb3J0IHsgYXBpQ2xpZW50IH0gZnJvbSBcIi4uL3NlcnZpY2VzL2FwaUNsaWVudFwiO1xyXG5pbXBvcnQgeyBVc3VhcmlvU2Vzc2FvIH0gZnJvbSBcIi4uL3R5cGVzL2F1dGhcIjtcclxuXHJcbmV4cG9ydCBjb25zdCBVc3Vhcmlvc1BhZ2U6IFJlYWN0LkZDID0gKCkgPT4ge1xyXG4gIGNvbnN0IHsgZGF0YTogdXN1YXJpb3MgPSBbXSwgaXNMb2FkaW5nIH0gPSB1c2VRdWVyeTxVc3VhcmlvU2Vzc2FvW10+KHtcclxuICAgIHF1ZXJ5S2V5OiBbXCJ1c3Vhcmlvc1wiXSxcclxuICAgIHF1ZXJ5Rm46IGFzeW5jICgpID0+IHtcclxuICAgICAgY29uc3QgcmVzID0gYXdhaXQgYXBpQ2xpZW50LmdldDxVc3VhcmlvU2Vzc2FvW10+KFwiL3VzdWFyaW9zXCIpO1xyXG4gICAgICByZXR1cm4gcmVzLmRhdGE7XHJcbiAgICB9LFxyXG4gIH0pO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTZcIj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC14bCBwLTYgc2hhZG93LXhzXCI+XHJcbiAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1ib2xkIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgPFVzZXJzIGNsYXNzTmFtZT1cInctNSBoLTUgdGV4dC10ZWFsLTYwMFwiIC8+XHJcbiAgICAgICAgICBTZXJ2aWRvcmVzICYgVXN1w6FyaW9zIGRvIFNpc3RlbWFcclxuICAgICAgICA8L2gxPlxyXG4gICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS01MDAgZGFyazp0ZXh0LXNsYXRlLTQwMCBtdC0xXCI+XHJcbiAgICAgICAgICBHZXN0w6NvIGRlIGNvbnRhcyBww7pibGljYXMsIHBvcnRhcmlhcyBkZSBub21lYcOnw6NvIGUgY29udHJvbGUgZGUgYWNlc3NvIFJCQUMuXHJcbiAgICAgICAgPC9wPlxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIHtpc0xvYWRpbmcgPyAoXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTEyIHRleHQtY2VudGVyIHRleHQtc2xhdGUtNDAwIHRleHQteHMgZmxleCBmbGV4LWNvbCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXJcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy02IGgtNiBib3JkZXItMiBib3JkZXItdGVhbC01MDAgYm9yZGVyLXQtdHJhbnNwYXJlbnQgcm91bmRlZC1mdWxsIGFuaW1hdGUtc3BpbiBtYi0zXCIgLz5cclxuICAgICAgICAgIENhcnJlZ2FuZG8gdXN1w6FyaW9zIGNhZGFzdHJhZG9zLi4uXHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICkgOiAoXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC14bCBvdmVyZmxvdy1oaWRkZW4gc2hhZG93LXhzXCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm92ZXJmbG93LXgtYXV0b1wiPlxyXG4gICAgICAgICAgICA8dGFibGUgY2xhc3NOYW1lPVwidy1mdWxsIHRleHQtbGVmdCB0ZXh0LXhzXCI+XHJcbiAgICAgICAgICAgICAgPHRoZWFkIGNsYXNzTmFtZT1cImJnLXNsYXRlLTUwIGRhcms6Ymctc2xhdGUtODAwLzYwIGJvcmRlci1iIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtODAwIHRleHQtc2xhdGUtNTAwIGZvbnQtc2VtaWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCI+XHJcbiAgICAgICAgICAgICAgICA8dHI+XHJcbiAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0zIHB4LTRcIj5Ob21lIENvbXBsZXRvIC8gRS1tYWlsPC90aD5cclxuICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB5LTMgcHgtNFwiPk1hdHLDrWN1bGEgLyBQb3J0YXJpYTwvdGg+XHJcbiAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0zIHB4LTRcIj5DYXJnbzwvdGg+XHJcbiAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0zIHB4LTRcIj5QZXJmaWwgUkJBQzwvdGg+XHJcbiAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0zIHB4LTRcIj5TdGF0dXM8L3RoPlxyXG4gICAgICAgICAgICAgICAgPC90cj5cclxuICAgICAgICAgICAgICA8L3RoZWFkPlxyXG4gICAgICAgICAgICAgIDx0Ym9keSBjbGFzc05hbWU9XCJkaXZpZGUteSBkaXZpZGUtc2xhdGUtMTAwIGRhcms6ZGl2aWRlLXNsYXRlLTgwMFwiPlxyXG4gICAgICAgICAgICAgICAge3VzdWFyaW9zLm1hcCgodXNyKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgIDx0ciBrZXk9e3Vzci5pZH0gY2xhc3NOYW1lPVwiaG92ZXI6Ymctc2xhdGUtNTAvNTAgZGFyazpob3ZlcjpiZy1zbGF0ZS04MDAvNDBcIj5cclxuICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMyBweC00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHt1c3Iubm9tZV9jb21wbGV0b31cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LXNsYXRlLTQwMCBmb250LW1vbm9cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAge3Vzci5lbWFpbH1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTMgcHgtNCB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2Pnt1c3IubWF0cmljdWxhIHx8IFwi4oCUXCJ9PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtc2xhdGUtNDAwXCI+e3Vzci5wb3J0YXJpYV9ub21lYWNhbyB8fCBcIuKAlFwifTwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTMgcHgtNCB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7dXNyLmNhcmdvfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTMgcHgtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiaW5saW5lLWJsb2NrIHB4LTIgcHktMC41IHJvdW5kZWQgdGV4dC1bMTBweF0gZm9udC1zZW1pYm9sZCBiZy1wdXJwbGUtNTAgZGFyazpiZy1wdXJwbGUtOTUwLzQwIHRleHQtcHVycGxlLTcwMCBkYXJrOnRleHQtcHVycGxlLTMwMCBib3JkZXIgYm9yZGVyLXB1cnBsZS0yMDAgZGFyazpib3JkZXItcHVycGxlLTgwMCB1cHBlcmNhc2VcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAge3Vzci5wZXJmaWwucmVwbGFjZSgvXy9nLCBcIiBcIil9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMyBweC00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgdGV4dC1bMTFweF0gdGV4dC1lbWVyYWxkLTYwMCBkYXJrOnRleHQtZW1lcmFsZC00MDAgZm9udC1tZWRpdW1cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPFVzZXJDaGVjayBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNVwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHt1c3IuaXNfYWN0aXZlID8gXCJBdGl2b1wiIDogXCJJbmF0aXZvXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICAgICAgICAgICAgPC90cj5cclxuICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgIDwvdGJvZHk+XHJcbiAgICAgICAgICAgIDwvdGFibGU+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgKX1cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBVc3Vhcmlvc1BhZ2U7XHJcbiJdfQ==