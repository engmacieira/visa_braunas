import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/licenciamento/AlvaraImpressaoView.tsx");const React = __vite__cjsImport0_react;const _jsxDEV = __vite__cjsImport5_react_jsxDevRuntime["jsxDEV"];/**
* Layout Oficial do Alvará Sanitário para Visualização e Impressão em Folha A4
* Renderização vetorial com QRCodeSVG (qrcode.react), cabeçalho institucional oficial,
* tabela de CNAEs autorizados, condicionantes e regras CSS para window.print().
*/
import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=0fd2848a";
import { QRCodeSVG } from "/node_modules/.vite/deps/qrcode__react.js?v=0fd2848a";
import { Award, Building2, Shield } from "/node_modules/.vite/deps/lucide-react.js?v=0fd2848a";
import { APP_CONFIG } from "/src/config/app.config.ts";
import { ROUTES } from "/src/config/routes.config.ts";
var _jsxFileName = "E:/Projetos VSCODE/visa_braunas/src/components/licenciamento/AlvaraImpressaoView.tsx";
import __vite__cjsImport5_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=0fd2848a";
export const AlvaraImpressaoView = ({ alvara }) => {
	const estab = alvara.estabelecimento;
	// Monta a URL de validação pública completa
	const baseUrl = typeof window !== "undefined" ? window.location.origin : "";
	const urlValidacaoPublica = `${baseUrl}${ROUTES.PUBLIC.VALIDAR_ALVARA(alvara.codigo_autenticidade)}`;
	const dataEmissaoFormatada = new Date(alvara.data_emissao).toLocaleDateString("pt-BR", { timeZone: "UTC" });
	const dataVencimentoFormatada = new Date(alvara.data_vencimento).toLocaleDateString("pt-BR", { timeZone: "UTC" });
	const rtTitular = estab?.responsaveis_tecnicos?.find((r) => !r.eh_substituto)?.responsavel_tecnico;
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "alvara-container bg-slate-100 dark:bg-slate-950 p-2 sm:p-6 flex justify-center",
		children: [/* @__PURE__ */ _jsxDEV("style", { children: `
        @media print {
          body {
            background-color: #ffffff !important;
            color: #0f172a !important;
            margin: 0 !important;
            padding: 0 !important;
          }
          .no-print {
            display: none !important;
          }
          .alvara-container {
            padding: 0 !important;
            background: transparent !important;
          }
          .alvara-sheet {
            box-shadow: none !important;
            border: 2px solid #0f172a !important;
            margin: 0 auto !important;
            width: 100% !important;
            max-width: 210mm !important;
            min-height: 297mm !important;
            page-break-after: avoid !important;
            page-break-inside: avoid !important;
            padding: 16mm !important;
          }
        }
      ` }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 37,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "alvara-sheet bg-white text-slate-900 border-2 border-slate-900 rounded-none w-full max-w-[210mm] min-h-[285mm] p-6 sm:p-10 shadow-xl flex flex-col justify-between relative overflow-hidden font-sans",
			children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "absolute inset-0 flex items-center justify-center opacity-[0.03] pointer-events-none select-none",
					children: /* @__PURE__ */ _jsxDEV(Shield, { className: "w-[450px] h-[450px] text-slate-900" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 70,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 69,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "space-y-4 relative z-10",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "text-center border-b-2 border-slate-900 pb-4 space-y-1",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center justify-center gap-2 mb-1",
									children: /* @__PURE__ */ _jsxDEV("div", {
										className: "w-10 h-10 rounded-full border border-slate-800 flex items-center justify-center bg-slate-50",
										children: /* @__PURE__ */ _jsxDEV(Shield, { className: "w-6 h-6 text-slate-900" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 78,
											columnNumber: 17
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 77,
										columnNumber: 15
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 76,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("p", {
									className: "text-[11px] font-bold tracking-widest uppercase text-slate-700",
									children: [
										APP_CONFIG.pais,
										" • ",
										APP_CONFIG.estadoExtenso
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 81,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("h1", {
									className: "text-base sm:text-lg font-black uppercase tracking-wider text-slate-950",
									children: APP_CONFIG.prefeitura
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 84,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("p", {
									className: "text-xs font-semibold text-slate-800 uppercase tracking-wide",
									children: [
										APP_CONFIG.secretaria,
										" • ",
										APP_CONFIG.orgao
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 87,
									columnNumber: 13
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 75,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "text-center py-2 bg-slate-50 border border-slate-300 rounded",
							children: [/* @__PURE__ */ _jsxDEV("h2", {
								className: "text-lg sm:text-xl font-black text-slate-950 tracking-widest uppercase",
								children: "Alvará de Autorização Sanitária"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 94,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center justify-center gap-4 text-xs font-bold text-slate-800 mt-1",
								children: [
									/* @__PURE__ */ _jsxDEV("span", { children: ["NÚMERO OFICIAL: ", alvara.numero_formatado || `${alvara.numero_alvara}/${alvara.exercicio}`] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 98,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("span", { children: "•" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 99,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("span", {
										className: "font-mono text-teal-900",
										children: ["AUTENTICIDADE: ", alvara.codigo_autenticidade]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 100,
										columnNumber: 15
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 97,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 93,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("p", {
							className: "text-[11px] text-justify leading-relaxed text-slate-800 px-1",
							children: [
								"A ",
								/* @__PURE__ */ _jsxDEV("strong", { children: APP_CONFIG.orgao }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 106,
									columnNumber: 15
								}, this),
								", no uso das atribuições legais conferidas pela Lei Orgânica Municipal, Código de Saúde do ",
								APP_CONFIG.estadoExtenso,
								" e legislação federal correlata, ",
								/* @__PURE__ */ _jsxDEV("strong", { children: "CERTIFICA" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 106,
									columnNumber: 200
								}, this),
								" que o estabelecimento abaixo qualificado cumpriu as normas higiênico-sanitárias vigentes e está autorizado a exercer suas atividades regulamentadas:"
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 105,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "border border-slate-300 rounded p-3 bg-slate-50/50 space-y-2 text-xs",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "border-b border-slate-200 pb-1.5 flex items-center justify-between",
									children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "font-bold uppercase tracking-wider text-slate-900 flex items-center gap-1.5 text-[11px]",
										children: [/* @__PURE__ */ _jsxDEV(Building2, { className: "w-3.5 h-3.5 text-slate-700" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 113,
											columnNumber: 17
										}, this), "Dados do Estabelecimento Regulamentado"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 112,
										columnNumber: 15
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: "text-[10px] font-bold px-2 py-0.5 bg-slate-200 text-slate-800 rounded",
										children: ["Grau de Risco: ", estab?.nivel_risco || "Risco Avaliado"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 116,
										columnNumber: 15
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 111,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "grid grid-cols-1 sm:grid-cols-2 gap-2",
									children: [
										/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
											className: "text-[10px] text-slate-500 uppercase font-semibold block",
											children: "Razão Social"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 123,
											columnNumber: 17
										}, this), /* @__PURE__ */ _jsxDEV("span", {
											className: "font-bold text-slate-900",
											children: estab?.razao_social || "Nome do Estabelecimento"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 124,
											columnNumber: 17
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 122,
											columnNumber: 15
										}, this),
										/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
											className: "text-[10px] text-slate-500 uppercase font-semibold block",
											children: "Nome Fantasia"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 128,
											columnNumber: 17
										}, this), /* @__PURE__ */ _jsxDEV("span", {
											className: "font-medium text-slate-800",
											children: estab?.nome_fantasia || "Não informado"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 129,
											columnNumber: 17
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 127,
											columnNumber: 15
										}, this),
										/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
											className: "text-[10px] text-slate-500 uppercase font-semibold block",
											children: "CNPJ / CPF"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 133,
											columnNumber: 17
										}, this), /* @__PURE__ */ _jsxDEV("span", {
											className: "font-mono font-bold text-slate-900",
											children: estab?.cnpj_cpf || "---"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 134,
											columnNumber: 17
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 132,
											columnNumber: 15
										}, this),
										/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
											className: "text-[10px] text-slate-500 uppercase font-semibold block",
											children: "Inscrição Municipal"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 138,
											columnNumber: 17
										}, this), /* @__PURE__ */ _jsxDEV("span", {
											className: "font-mono text-slate-800",
											children: estab?.inscricao_municipal || "Isento / Não Consta"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 139,
											columnNumber: 17
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 137,
											columnNumber: 15
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 121,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "pt-1 text-[11px] text-slate-700",
									children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-[10px] text-slate-500 uppercase font-semibold block",
										children: "Endereço de Funcionamento"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 144,
										columnNumber: 15
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: [
										estab?.logradouro || "Logradouro",
										", ",
										estab?.numero || "S/N",
										" ",
										estab?.complemento && `(${estab.complemento})`,
										" - Bairro: ",
										estab?.bairro || "Centro",
										", ",
										estab?.municipio || APP_CONFIG.municipio,
										"/",
										estab?.uf || APP_CONFIG.uf,
										" - CEP: ",
										estab?.cep || "35169-000"
									] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 145,
										columnNumber: 15
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 143,
									columnNumber: 13
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 110,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "border border-slate-300 rounded p-3 bg-slate-50/50 space-y-2 text-xs",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "font-bold uppercase tracking-wider text-slate-900 flex items-center gap-1.5 text-[11px] border-b border-slate-200 pb-1.5",
								children: [/* @__PURE__ */ _jsxDEV(Award, { className: "w-3.5 h-3.5 text-slate-700" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 155,
									columnNumber: 15
								}, this), "Atividades Econômicas Autorizadas (CNAE)"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 154,
								columnNumber: 13
							}, this), estab?.cnaes && estab.cnaes.length > 0 ? /* @__PURE__ */ _jsxDEV("div", {
								className: "divide-y divide-slate-200 text-[11px]",
								children: estab.cnaes.map((item, idx) => /* @__PURE__ */ _jsxDEV("div", {
									className: "py-1 flex items-start justify-between gap-2",
									children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "font-mono font-bold text-slate-900 mr-2",
										children: item.cnae_codigo
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 164,
										columnNumber: 23
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-800",
										children: item.cnae?.descricao || "Atividade Econômica Registrada"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 167,
										columnNumber: 23
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 163,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: "text-[10px] font-semibold text-slate-600 bg-white px-1.5 py-0.5 rounded border border-slate-200 shrink-0",
										children: item.eh_principal ? "Principal" : "Secundária"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 171,
										columnNumber: 21
									}, this)]
								}, idx, true, {
									fileName: _jsxFileName,
									lineNumber: 162,
									columnNumber: 19
								}, this))
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 160,
								columnNumber: 15
							}, this) : /* @__PURE__ */ _jsxDEV("p", {
								className: "text-[11px] text-slate-600 italic",
								children: "Atividade principal autorizada conforme processo de requerimento e vistoria de campo sanitária."
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 178,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 153,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "border border-slate-300 rounded p-2.5 bg-slate-50/50",
								children: [
									/* @__PURE__ */ _jsxDEV("span", {
										className: "text-[10px] text-slate-500 uppercase font-semibold block",
										children: "Responsável Legal"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 187,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("p", {
										className: "font-bold text-slate-900 mt-0.5",
										children: estab?.representante_legal?.nome_completo || "Representante Declarado"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 188,
										columnNumber: 15
									}, this),
									estab?.representante_legal?.cpf && /* @__PURE__ */ _jsxDEV("p", {
										className: "text-[10px] text-slate-600 font-mono",
										children: ["CPF: ", estab.representante_legal.cpf]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 192,
										columnNumber: 17
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 186,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "border border-slate-300 rounded p-2.5 bg-slate-50/50",
								children: [
									/* @__PURE__ */ _jsxDEV("span", {
										className: "text-[10px] text-slate-500 uppercase font-semibold block",
										children: "Responsável Técnico (RT)"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 199,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("p", {
										className: "font-bold text-slate-900 mt-0.5",
										children: rtTitular?.nome_completo || "Não Exigido ou Conforme Legislação"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 200,
										columnNumber: 15
									}, this),
									rtTitular?.conselho_classe && /* @__PURE__ */ _jsxDEV("p", {
										className: "text-[10px] text-slate-600 font-mono",
										children: [
											rtTitular.conselho_classe,
											": ",
											rtTitular.numero_registro_conselho,
											"/",
											rtTitular.uf_conselho
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 204,
										columnNumber: 17
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 198,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 185,
							columnNumber: 11
						}, this),
						alvara.condicionantes_restricoes && /* @__PURE__ */ _jsxDEV("div", {
							className: "border border-amber-300 bg-amber-50/50 rounded p-2.5 text-xs text-amber-950",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-[10px] uppercase font-bold text-amber-800 block",
								children: "Condicionantes Sanitárias & Restrições de Operação:"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 214,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("p", {
								className: "text-[11px] mt-0.5 leading-relaxed font-medium",
								children: alvara.condicionantes_restricoes
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 217,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 213,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 74,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "pt-4 border-t-2 border-slate-900 space-y-4 relative z-10 mt-4",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "grid grid-cols-1 sm:grid-cols-3 gap-4 items-center",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "space-y-1.5 text-xs",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "p-2 border border-slate-300 rounded bg-slate-50",
									children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-[10px] text-slate-500 uppercase font-bold block",
										children: "Data de Expedição"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 230,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: "font-bold text-slate-950 text-sm",
										children: dataEmissaoFormatada
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 231,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 229,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "p-2 border-2 border-emerald-700 rounded bg-emerald-50",
									children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-[10px] text-emerald-800 uppercase font-bold block",
										children: "Válido Até"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 234,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: "font-black text-emerald-950 text-sm",
										children: dataVencimentoFormatada
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 235,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 233,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 228,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex flex-col items-center text-center p-2 border border-slate-200 rounded bg-white",
								children: [
									/* @__PURE__ */ _jsxDEV("div", {
										className: "p-1.5 bg-white border border-slate-300 rounded shadow-2xs",
										children: /* @__PURE__ */ _jsxDEV(QRCodeSVG, {
											value: urlValidacaoPublica,
											size: 96,
											level: "H",
											includeMargin: false
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 242,
											columnNumber: 17
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 241,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("span", {
										className: "text-[9px] font-bold text-slate-700 uppercase mt-1",
										children: "Autenticidade por QR Code"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 249,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("span", {
										className: "text-[8px] text-slate-500 leading-tight max-w-[140px]",
										children: "Aponte a câmera do celular para verificar a validade jurídica"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 252,
										columnNumber: 15
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 240,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "text-center flex flex-col justify-end pt-4",
								children: /* @__PURE__ */ _jsxDEV("div", {
									className: "border-t border-slate-800 pt-1.5 mx-auto w-48",
									children: [
										/* @__PURE__ */ _jsxDEV("p", {
											className: "text-xs font-bold text-slate-950",
											children: "Autoridade Sanitária"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 260,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("p", {
											className: "text-[10px] text-slate-600",
											children: APP_CONFIG.orgao
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 261,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("p", {
											className: "text-[9px] text-slate-500 font-mono",
											children: [
												"Município de ",
												APP_CONFIG.municipio,
												" / ",
												APP_CONFIG.uf
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 262,
											columnNumber: 17
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 259,
									columnNumber: 15
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 258,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 226,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "text-[9px] text-center text-slate-500 pt-2 border-t border-slate-200",
						children: [
							"Este documento possui fé pública e validade jurídica em todo o território municipal de ",
							APP_CONFIG.municipio,
							"/",
							APP_CONFIG.uf,
							". A fixação deste alvará em local visível e de fácil acesso ao público é obrigatória, nos termos do Código Sanitário Municipal."
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 268,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 225,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 67,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 35,
		columnNumber: 5
	}, this);
};
_c = AlvaraImpressaoView;
export default AlvaraImpressaoView;
var _c;
$RefreshReg$(_c, "AlvaraImpressaoView");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/licenciamento/AlvaraImpressaoView.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("E:/Projetos VSCODE/visa_braunas/src/components/licenciamento/AlvaraImpressaoView.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("E:/Projetos VSCODE/visa_braunas/src/components/licenciamento/AlvaraImpressaoView.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "E:/Projetos VSCODE/visa_braunas/src/components/licenciamento/AlvaraImpressaoView.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7Ozs7QUFNQSxPQUFPLFdBQVc7QUFDbEIsU0FBUyxpQkFBaUI7QUFDMUIsU0FBUyxPQUFPLFdBQW1DLGNBQWM7QUFDakUsU0FBUyxrQkFBa0I7QUFDM0IsU0FBUyxjQUFjOzs7QUFPdkIsT0FBTyxNQUFNLHVCQUEyRCxFQUFFLGFBQWE7Q0FDckYsTUFBTSxRQUFRLE9BQU87O0NBR3JCLE1BQU0sVUFBVSxPQUFPLFdBQVcsY0FBYyxPQUFPLFNBQVMsU0FBUztDQUN6RSxNQUFNLHNCQUFzQixHQUFHLFVBQVUsT0FBTyxPQUFPLGVBQWUsT0FBTyxvQkFBb0I7Q0FFakcsTUFBTSx1QkFBdUIsSUFBSSxLQUFLLE9BQU8sWUFBWSxDQUFDLENBQUMsbUJBQW1CLFNBQVMsRUFDckYsVUFBVSxNQUNaLENBQUM7Q0FDRCxNQUFNLDBCQUEwQixJQUFJLEtBQUssT0FBTyxlQUFlLENBQUMsQ0FBQyxtQkFBbUIsU0FBUyxFQUMzRixVQUFVLE1BQ1osQ0FBQztDQUVELE1BQU0sWUFBWSxPQUFPLHVCQUF1QixNQUFNLE1BQU0sQ0FBQyxFQUFFLGFBQWEsQ0FBQyxFQUFFO0NBRS9FLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBZixDQUVFLHdCQUFDLFNBQUQsWUFBUTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O1FBMkJDOzs7O1lBR1Qsd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZjtJQUVFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQ2Isd0JBQUMsUUFBRCxFQUFRLFdBQVUscUNBQXNDOzs7OztJQUNyRDs7Ozs7SUFHTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmO01BQ0Usd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWY7UUFDRSx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFDYix3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFDYix3QkFBQyxRQUFELEVBQVEsV0FBVSx5QkFBMEI7Ozs7O1NBQ3pDOzs7OztRQUNGOzs7OztRQUNMLHdCQUFDLEtBQUQ7U0FBRyxXQUFVO21CQUFiO1VBQ0csV0FBVztVQUFLO1VBQUksV0FBVztTQUMvQjs7Ozs7O1FBQ0gsd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQ1gsV0FBVztRQUNWOzs7OztRQUNKLHdCQUFDLEtBQUQ7U0FBRyxXQUFVO21CQUFiO1VBQ0csV0FBVztVQUFXO1VBQUksV0FBVztTQUNyQzs7Ozs7O09BQ0E7Ozs7OztNQUdMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsTUFBRDtRQUFJLFdBQVU7a0JBQXlFO09BRW5GOzs7O2lCQUNKLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmO1NBQ0Usd0JBQUMsUUFBRCxhQUFNLG9CQUFpQixPQUFPLG9CQUFvQixHQUFHLE9BQU8sY0FBYyxHQUFHLE9BQU8sV0FBa0I7Ozs7O1NBQ3RHLHdCQUFDLFFBQUQsWUFBTSxJQUFPOzs7OztTQUNiLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUFoQixDQUEwQyxtQkFBZ0IsT0FBTyxvQkFBMkI7Ozs7OztRQUN6Rjs7Ozs7ZUFDRjs7Ozs7O01BR0wsd0JBQUMsS0FBRDtPQUFHLFdBQVU7aUJBQWI7UUFBNEU7UUFDeEUsd0JBQUMsVUFBRCxZQUFTLFdBQVcsTUFBYzs7Ozs7UUFBQztRQUE0RixXQUFXO1FBQWM7UUFBaUMsd0JBQUMsVUFBRCxZQUFRLFlBQWlCOzs7OztRQUFDO09BQ3BOOzs7Ozs7TUFHSCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZjtRQUNFLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQWhCLENBQ0Usd0JBQUMsV0FBRCxFQUFXLFdBQVUsNkJBQThCOzs7O29CQUFDLHdDQUVoRDs7Ozs7bUJBQ04sd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQWhCLENBQXdGLG1CQUN0RSxPQUFPLGVBQWUsZ0JBQ2xDOzs7OztpQkFDSDs7Ozs7O1FBRUwsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWY7VUFDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQTJEO1VBQWtCOzs7O29CQUM3Rix3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFBNEIsT0FBTyxnQkFBZ0I7VUFBZ0M7Ozs7a0JBQ2hHOzs7OztVQUVMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFBMkQ7VUFBbUI7Ozs7b0JBQzlGLHdCQUFDLFFBQUQ7V0FBTSxXQUFVO3FCQUE4QixPQUFPLGlCQUFpQjtVQUFzQjs7OztrQkFDekY7Ozs7O1VBRUwsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFFBQUQ7V0FBTSxXQUFVO3FCQUEyRDtVQUFnQjs7OztvQkFDM0Ysd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQXNDLE9BQU8sWUFBWTtVQUFZOzs7O2tCQUNsRjs7Ozs7VUFFTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQTJEO1VBQXlCOzs7O29CQUNwRyx3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFBNEIsT0FBTyx1QkFBdUI7VUFBNEI7Ozs7a0JBQ25HOzs7OztTQUNGOzs7Ozs7UUFFTCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUEyRDtTQUErQjs7OzttQkFDMUcsd0JBQUMsUUFBRDtVQUNHLE9BQU8sY0FBYztVQUFhO1VBQUcsT0FBTyxVQUFVO1VBQU87VUFDN0QsT0FBTyxlQUFlLElBQUksTUFBTSxZQUFZO1VBQUc7VUFBWSxPQUFPLFVBQVU7VUFBUztVQUFHLE9BQU8sYUFBYSxXQUFXO1VBQVU7VUFBRSxPQUFPLE1BQU0sV0FBVztVQUFHO1VBQVMsT0FBTyxPQUFPO1NBQ2xMOzs7O2lCQUNIOzs7Ozs7T0FDRjs7Ozs7O01BR0wsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBaEIsQ0FDRSx3QkFBQyxPQUFELEVBQU8sV0FBVSw2QkFBOEI7Ozs7a0JBQUMsMENBRTVDOzs7OztpQkFFTCxPQUFPLFNBQVMsTUFBTSxNQUFNLFNBQVMsSUFDcEMsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQ1osTUFBTSxNQUFNLEtBQUssTUFBTSxRQUN0Qix3QkFBQyxPQUFEO1NBQWUsV0FBVTttQkFBekIsQ0FDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQ2IsS0FBSztTQUNGOzs7O21CQUNOLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUNiLEtBQUssTUFBTSxhQUFhO1NBQ3JCOzs7O2lCQUNIOzs7O21CQUNMLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUNiLEtBQUssZUFBZSxjQUFjO1NBQy9COzs7O2lCQUNIO1dBWks7Ozs7ZUFZTCxDQUNOO09BQ0U7Ozs7a0JBRUwsd0JBQUMsS0FBRDtRQUFHLFdBQVU7a0JBQW9DO09BRTlDOzs7O2VBRUY7Ozs7OztNQUdMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWY7U0FDRSx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBMkQ7U0FBdUI7Ozs7O1NBQ2xHLHdCQUFDLEtBQUQ7VUFBRyxXQUFVO29CQUNWLE9BQU8scUJBQXFCLGlCQUFpQjtTQUM3Qzs7Ozs7U0FDRixPQUFPLHFCQUFxQixPQUMzQix3QkFBQyxLQUFEO1VBQUcsV0FBVTtvQkFBYixDQUFvRCxTQUM1QyxNQUFNLG9CQUFvQixHQUMvQjs7Ozs7O1FBRUY7Ozs7O2lCQUVMLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmO1NBQ0Usd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQTJEO1NBQThCOzs7OztTQUN6Ryx3QkFBQyxLQUFEO1VBQUcsV0FBVTtvQkFDVixXQUFXLGlCQUFpQjtTQUM1Qjs7Ozs7U0FDRixXQUFXLG1CQUNWLHdCQUFDLEtBQUQ7VUFBRyxXQUFVO29CQUFiO1dBQ0csVUFBVTtXQUFnQjtXQUFHLFVBQVU7V0FBeUI7V0FBRSxVQUFVO1VBQzVFOzs7Ozs7UUFFRjs7Ozs7ZUFDRjs7Ozs7O01BR0osT0FBTyw2QkFDTix3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUF1RDtPQUVqRTs7OztpQkFDTix3QkFBQyxLQUFEO1FBQUcsV0FBVTtrQkFDVixPQUFPO09BQ1A7Ozs7ZUFDQTs7Ozs7O0tBRUo7Ozs7OztJQUdMLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZjtPQUVFLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDRSx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBdUQ7U0FBdUI7Ozs7bUJBQzlGLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUFvQztTQUEyQjs7OztpQkFDNUU7Ozs7O2tCQUNMLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQXlEO1NBQWdCOzs7O21CQUN6Rix3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBdUM7U0FBOEI7Ozs7aUJBQ2xGOzs7OztnQkFDRjs7Ozs7O09BR0wsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWY7U0FDRSx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFDYix3QkFBQyxXQUFEO1dBQ0UsT0FBTztXQUNQLE1BQU07V0FDTixPQUFNO1dBQ04sZUFBZTtVQUNoQjs7Ozs7U0FDRTs7Ozs7U0FDTCx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBcUQ7U0FFL0Q7Ozs7O1NBQ04sd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQXdEO1NBRWxFOzs7OztRQUNIOzs7Ozs7T0FHTCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFDYix3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZjtVQUNFLHdCQUFDLEtBQUQ7V0FBRyxXQUFVO3FCQUFtQztVQUF1Qjs7Ozs7VUFDdkUsd0JBQUMsS0FBRDtXQUFHLFdBQVU7cUJBQThCLFdBQVc7VUFBUzs7Ozs7VUFDL0Qsd0JBQUMsS0FBRDtXQUFHLFdBQVU7cUJBQWI7WUFBbUQ7WUFBYyxXQUFXO1lBQVU7WUFBSSxXQUFXO1dBQU07Ozs7OztTQUN4Rzs7Ozs7O09BQ0Y7Ozs7O01BQ0Y7Ozs7O2VBR0wsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWY7T0FBc0Y7T0FDSSxXQUFXO09BQVU7T0FBRSxXQUFXO09BQUc7TUFDMUg7Ozs7O2FBQ0Y7Ozs7OztHQUNGOzs7OztVQUNGOzs7Ozs7QUFFVDs7QUFFQSxlQUFlIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkFsdmFyYUltcHJlc3Nhb1ZpZXcudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbIi8qKlxyXG4gKiBMYXlvdXQgT2ZpY2lhbCBkbyBBbHZhcsOhIFNhbml0w6FyaW8gcGFyYSBWaXN1YWxpemHDp8OjbyBlIEltcHJlc3PDo28gZW0gRm9saGEgQTRcclxuICogUmVuZGVyaXphw6fDo28gdmV0b3JpYWwgY29tIFFSQ29kZVNWRyAocXJjb2RlLnJlYWN0KSwgY2FiZcOnYWxobyBpbnN0aXR1Y2lvbmFsIG9maWNpYWwsXHJcbiAqIHRhYmVsYSBkZSBDTkFFcyBhdXRvcml6YWRvcywgY29uZGljaW9uYW50ZXMgZSByZWdyYXMgQ1NTIHBhcmEgd2luZG93LnByaW50KCkuXHJcbiAqL1xyXG5cclxuaW1wb3J0IFJlYWN0IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgeyBRUkNvZGVTVkcgfSBmcm9tIFwicXJjb2RlLnJlYWN0XCI7XHJcbmltcG9ydCB7IEF3YXJkLCBCdWlsZGluZzIsIENhbGVuZGFyLCBDaGVja0NpcmNsZTIsIFNoaWVsZCB9IGZyb20gXCJsdWNpZGUtcmVhY3RcIjtcclxuaW1wb3J0IHsgQVBQX0NPTkZJRyB9IGZyb20gXCIuLi8uLi9jb25maWcvYXBwLmNvbmZpZ1wiO1xyXG5pbXBvcnQgeyBST1VURVMgfSBmcm9tIFwiLi4vLi4vY29uZmlnL3JvdXRlcy5jb25maWdcIjtcclxuaW1wb3J0IHsgQWx2YXJhU2FuaXRhcmlvRGV0YWxoZSB9IGZyb20gXCIuLi8uLi90eXBlcy9saWNlbmNpYW1lbnRvXCI7XHJcblxyXG5pbnRlcmZhY2UgQWx2YXJhSW1wcmVzc2FvVmlld1Byb3BzIHtcclxuICBhbHZhcmE6IEFsdmFyYVNhbml0YXJpb0RldGFsaGU7XHJcbn1cclxuXHJcbmV4cG9ydCBjb25zdCBBbHZhcmFJbXByZXNzYW9WaWV3OiBSZWFjdC5GQzxBbHZhcmFJbXByZXNzYW9WaWV3UHJvcHM+ID0gKHsgYWx2YXJhIH0pID0+IHtcclxuICBjb25zdCBlc3RhYiA9IGFsdmFyYS5lc3RhYmVsZWNpbWVudG87XHJcblxyXG4gIC8vIE1vbnRhIGEgVVJMIGRlIHZhbGlkYcOnw6NvIHDDumJsaWNhIGNvbXBsZXRhXHJcbiAgY29uc3QgYmFzZVVybCA9IHR5cGVvZiB3aW5kb3cgIT09IFwidW5kZWZpbmVkXCIgPyB3aW5kb3cubG9jYXRpb24ub3JpZ2luIDogXCJcIjtcclxuICBjb25zdCB1cmxWYWxpZGFjYW9QdWJsaWNhID0gYCR7YmFzZVVybH0ke1JPVVRFUy5QVUJMSUMuVkFMSURBUl9BTFZBUkEoYWx2YXJhLmNvZGlnb19hdXRlbnRpY2lkYWRlKX1gO1xyXG5cclxuICBjb25zdCBkYXRhRW1pc3Nhb0Zvcm1hdGFkYSA9IG5ldyBEYXRlKGFsdmFyYS5kYXRhX2VtaXNzYW8pLnRvTG9jYWxlRGF0ZVN0cmluZyhcInB0LUJSXCIsIHtcclxuICAgIHRpbWVab25lOiBcIlVUQ1wiLFxyXG4gIH0pO1xyXG4gIGNvbnN0IGRhdGFWZW5jaW1lbnRvRm9ybWF0YWRhID0gbmV3IERhdGUoYWx2YXJhLmRhdGFfdmVuY2ltZW50bykudG9Mb2NhbGVEYXRlU3RyaW5nKFwicHQtQlJcIiwge1xyXG4gICAgdGltZVpvbmU6IFwiVVRDXCIsXHJcbiAgfSk7XHJcblxyXG4gIGNvbnN0IHJ0VGl0dWxhciA9IGVzdGFiPy5yZXNwb25zYXZlaXNfdGVjbmljb3M/LmZpbmQoKHIpID0+ICFyLmVoX3N1YnN0aXR1dG8pPy5yZXNwb25zYXZlbF90ZWNuaWNvO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJhbHZhcmEtY29udGFpbmVyIGJnLXNsYXRlLTEwMCBkYXJrOmJnLXNsYXRlLTk1MCBwLTIgc206cC02IGZsZXgganVzdGlmeS1jZW50ZXJcIj5cclxuICAgICAgey8qIEVzdGlsb3MgZGVkaWNhZG9zIHBhcmEgaW1wcmVzc8OjbyBsaW1wYSBlbSBmb2xoYSBBNCAqL31cclxuICAgICAgPHN0eWxlPntgXHJcbiAgICAgICAgQG1lZGlhIHByaW50IHtcclxuICAgICAgICAgIGJvZHkge1xyXG4gICAgICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmZmZmZmICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgICAgIGNvbG9yOiAjMGYxNzJhICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgICAgIG1hcmdpbjogMCAhaW1wb3J0YW50O1xyXG4gICAgICAgICAgICBwYWRkaW5nOiAwICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICAubm8tcHJpbnQge1xyXG4gICAgICAgICAgICBkaXNwbGF5OiBub25lICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICAuYWx2YXJhLWNvbnRhaW5lciB7XHJcbiAgICAgICAgICAgIHBhZGRpbmc6IDAgIWltcG9ydGFudDtcclxuICAgICAgICAgICAgYmFja2dyb3VuZDogdHJhbnNwYXJlbnQgIWltcG9ydGFudDtcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIC5hbHZhcmEtc2hlZXQge1xyXG4gICAgICAgICAgICBib3gtc2hhZG93OiBub25lICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgICAgIGJvcmRlcjogMnB4IHNvbGlkICMwZjE3MmEgIWltcG9ydGFudDtcclxuICAgICAgICAgICAgbWFyZ2luOiAwIGF1dG8gIWltcG9ydGFudDtcclxuICAgICAgICAgICAgd2lkdGg6IDEwMCUgIWltcG9ydGFudDtcclxuICAgICAgICAgICAgbWF4LXdpZHRoOiAyMTBtbSAhaW1wb3J0YW50O1xyXG4gICAgICAgICAgICBtaW4taGVpZ2h0OiAyOTdtbSAhaW1wb3J0YW50O1xyXG4gICAgICAgICAgICBwYWdlLWJyZWFrLWFmdGVyOiBhdm9pZCAhaW1wb3J0YW50O1xyXG4gICAgICAgICAgICBwYWdlLWJyZWFrLWluc2lkZTogYXZvaWQgIWltcG9ydGFudDtcclxuICAgICAgICAgICAgcGFkZGluZzogMTZtbSAhaW1wb3J0YW50O1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgYH08L3N0eWxlPlxyXG5cclxuICAgICAgey8qIEZvbGhhIEE0IGNvbSBib3JkYSBvZmljaWFsIGRlIGbDqSBww7pibGljYSAqL31cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJhbHZhcmEtc2hlZXQgYmctd2hpdGUgdGV4dC1zbGF0ZS05MDAgYm9yZGVyLTIgYm9yZGVyLXNsYXRlLTkwMCByb3VuZGVkLW5vbmUgdy1mdWxsIG1heC13LVsyMTBtbV0gbWluLWgtWzI4NW1tXSBwLTYgc206cC0xMCBzaGFkb3cteGwgZmxleCBmbGV4LWNvbCBqdXN0aWZ5LWJldHdlZW4gcmVsYXRpdmUgb3ZlcmZsb3ctaGlkZGVuIGZvbnQtc2Fuc1wiPlxyXG4gICAgICAgIHsvKiBNYXJjYSBkJ8OhZ3VhIHN1dGlsIGluc3RpdHVjaW9uYWwgKi99XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSBpbnNldC0wIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIG9wYWNpdHktWzAuMDNdIHBvaW50ZXItZXZlbnRzLW5vbmUgc2VsZWN0LW5vbmVcIj5cclxuICAgICAgICAgIDxTaGllbGQgY2xhc3NOYW1lPVwidy1bNDUwcHhdIGgtWzQ1MHB4XSB0ZXh0LXNsYXRlLTkwMFwiIC8+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIHsvKiBUb3BvOiBDYWJlw6dhbGhvIEluc3RpdHVjaW9uYWwgKi99XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTQgcmVsYXRpdmUgei0xMFwiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciBib3JkZXItYi0yIGJvcmRlci1zbGF0ZS05MDAgcGItNCBzcGFjZS15LTFcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMiBtYi0xXCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEwIGgtMTAgcm91bmRlZC1mdWxsIGJvcmRlciBib3JkZXItc2xhdGUtODAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGJnLXNsYXRlLTUwXCI+XHJcbiAgICAgICAgICAgICAgICA8U2hpZWxkIGNsYXNzTmFtZT1cInctNiBoLTYgdGV4dC1zbGF0ZS05MDBcIiAvPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gZm9udC1ib2xkIHRyYWNraW5nLXdpZGVzdCB1cHBlcmNhc2UgdGV4dC1zbGF0ZS03MDBcIj5cclxuICAgICAgICAgICAgICB7QVBQX0NPTkZJRy5wYWlzfSDigKIge0FQUF9DT05GSUcuZXN0YWRvRXh0ZW5zb31cclxuICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC1iYXNlIHNtOnRleHQtbGcgZm9udC1ibGFjayB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1zbGF0ZS05NTBcIj5cclxuICAgICAgICAgICAgICB7QVBQX0NPTkZJRy5wcmVmZWl0dXJhfVxyXG4gICAgICAgICAgICA8L2gxPlxyXG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS04MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVcIj5cclxuICAgICAgICAgICAgICB7QVBQX0NPTkZJRy5zZWNyZXRhcmlhfSDigKIge0FQUF9DT05GSUcub3JnYW99XHJcbiAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIHsvKiBUw610dWxvIE9maWNpYWwgZG8gRG9jdW1lbnRvICovfVxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciBweS0yIGJnLXNsYXRlLTUwIGJvcmRlciBib3JkZXItc2xhdGUtMzAwIHJvdW5kZWRcIj5cclxuICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtbGcgc206dGV4dC14bCBmb250LWJsYWNrIHRleHQtc2xhdGUtOTUwIHRyYWNraW5nLXdpZGVzdCB1cHBlcmNhc2VcIj5cclxuICAgICAgICAgICAgICBBbHZhcsOhIGRlIEF1dG9yaXphw6fDo28gU2FuaXTDoXJpYVxyXG4gICAgICAgICAgICA8L2gyPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC00IHRleHQteHMgZm9udC1ib2xkIHRleHQtc2xhdGUtODAwIG10LTFcIj5cclxuICAgICAgICAgICAgICA8c3Bhbj5Ow5pNRVJPIE9GSUNJQUw6IHthbHZhcmEubnVtZXJvX2Zvcm1hdGFkbyB8fCBgJHthbHZhcmEubnVtZXJvX2FsdmFyYX0vJHthbHZhcmEuZXhlcmNpY2lvfWB9PC9zcGFuPlxyXG4gICAgICAgICAgICAgIDxzcGFuPuKAojwvc3Bhbj5cclxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1vbm8gdGV4dC10ZWFsLTkwMFwiPkFVVEVOVElDSURBREU6IHthbHZhcmEuY29kaWdvX2F1dGVudGljaWRhZGV9PC9zcGFuPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIHsvKiBUZXh0byBkZSBGw6kgUMO6YmxpY2EgKi99XHJcbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LWp1c3RpZnkgbGVhZGluZy1yZWxheGVkIHRleHQtc2xhdGUtODAwIHB4LTFcIj5cclxuICAgICAgICAgICAgQSA8c3Ryb25nPntBUFBfQ09ORklHLm9yZ2FvfTwvc3Ryb25nPiwgbm8gdXNvIGRhcyBhdHJpYnVpw6fDtWVzIGxlZ2FpcyBjb25mZXJpZGFzIHBlbGEgTGVpIE9yZ8OibmljYSBNdW5pY2lwYWwsIEPDs2RpZ28gZGUgU2HDumRlIGRvIHtBUFBfQ09ORklHLmVzdGFkb0V4dGVuc299IGUgbGVnaXNsYcOnw6NvIGZlZGVyYWwgY29ycmVsYXRhLCA8c3Ryb25nPkNFUlRJRklDQTwvc3Ryb25nPiBxdWUgbyBlc3RhYmVsZWNpbWVudG8gYWJhaXhvIHF1YWxpZmljYWRvIGN1bXByaXUgYXMgbm9ybWFzIGhpZ2nDqm5pY28tc2FuaXTDoXJpYXMgdmlnZW50ZXMgZSBlc3TDoSBhdXRvcml6YWRvIGEgZXhlcmNlciBzdWFzIGF0aXZpZGFkZXMgcmVndWxhbWVudGFkYXM6XHJcbiAgICAgICAgICA8L3A+XHJcblxyXG4gICAgICAgICAgey8qIEJsb2NvIDE6IElkZW50aWZpY2HDp8OjbyBkbyBFc3RhYmVsZWNpbWVudG8gKi99XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJvcmRlciBib3JkZXItc2xhdGUtMzAwIHJvdW5kZWQgcC0zIGJnLXNsYXRlLTUwLzUwIHNwYWNlLXktMiB0ZXh0LXhzXCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTIwMCBwYi0xLjUgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XHJcbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LXNsYXRlLTkwMCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHRleHQtWzExcHhdXCI+XHJcbiAgICAgICAgICAgICAgICA8QnVpbGRpbmcyIGNsYXNzTmFtZT1cInctMy41IGgtMy41IHRleHQtc2xhdGUtNzAwXCIgLz5cclxuICAgICAgICAgICAgICAgIERhZG9zIGRvIEVzdGFiZWxlY2ltZW50byBSZWd1bGFtZW50YWRvXHJcbiAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIGZvbnQtYm9sZCBweC0yIHB5LTAuNSBiZy1zbGF0ZS0yMDAgdGV4dC1zbGF0ZS04MDAgcm91bmRlZFwiPlxyXG4gICAgICAgICAgICAgICAgR3JhdSBkZSBSaXNjbzoge2VzdGFiPy5uaXZlbF9yaXNjbyB8fCBcIlJpc2NvIEF2YWxpYWRvXCJ9XHJcbiAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBzbTpncmlkLWNvbHMtMiBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LXNsYXRlLTUwMCB1cHBlcmNhc2UgZm9udC1zZW1pYm9sZCBibG9ja1wiPlJhesOjbyBTb2NpYWw8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1zbGF0ZS05MDBcIj57ZXN0YWI/LnJhemFvX3NvY2lhbCB8fCBcIk5vbWUgZG8gRXN0YWJlbGVjaW1lbnRvXCJ9PC9zcGFuPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1zbGF0ZS01MDAgdXBwZXJjYXNlIGZvbnQtc2VtaWJvbGQgYmxvY2tcIj5Ob21lIEZhbnRhc2lhPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tZWRpdW0gdGV4dC1zbGF0ZS04MDBcIj57ZXN0YWI/Lm5vbWVfZmFudGFzaWEgfHwgXCJOw6NvIGluZm9ybWFkb1wifTwvc3Bhbj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtc2xhdGUtNTAwIHVwcGVyY2FzZSBmb250LXNlbWlib2xkIGJsb2NrXCI+Q05QSiAvIENQRjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbW9ubyBmb250LWJvbGQgdGV4dC1zbGF0ZS05MDBcIj57ZXN0YWI/LmNucGpfY3BmIHx8IFwiLS0tXCJ9PC9zcGFuPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1zbGF0ZS01MDAgdXBwZXJjYXNlIGZvbnQtc2VtaWJvbGQgYmxvY2tcIj5JbnNjcmnDp8OjbyBNdW5pY2lwYWw8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1vbm8gdGV4dC1zbGF0ZS04MDBcIj57ZXN0YWI/Lmluc2NyaWNhb19tdW5pY2lwYWwgfHwgXCJJc2VudG8gLyBOw6NvIENvbnN0YVwifTwvc3Bhbj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB0LTEgdGV4dC1bMTFweF0gdGV4dC1zbGF0ZS03MDBcIj5cclxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LXNsYXRlLTUwMCB1cHBlcmNhc2UgZm9udC1zZW1pYm9sZCBibG9ja1wiPkVuZGVyZcOnbyBkZSBGdW5jaW9uYW1lbnRvPC9zcGFuPlxyXG4gICAgICAgICAgICAgIDxzcGFuPlxyXG4gICAgICAgICAgICAgICAge2VzdGFiPy5sb2dyYWRvdXJvIHx8IFwiTG9ncmFkb3Vyb1wifSwge2VzdGFiPy5udW1lcm8gfHwgXCJTL05cIn17XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICB7ZXN0YWI/LmNvbXBsZW1lbnRvICYmIGAoJHtlc3RhYi5jb21wbGVtZW50b30pYH0gLSBCYWlycm86IHtlc3RhYj8uYmFpcnJvIHx8IFwiQ2VudHJvXCJ9LCB7ZXN0YWI/Lm11bmljaXBpbyB8fCBBUFBfQ09ORklHLm11bmljaXBpb30ve2VzdGFiPy51ZiB8fCBBUFBfQ09ORklHLnVmfSAtIENFUDoge2VzdGFiPy5jZXAgfHwgXCIzNTE2OS0wMDBcIn1cclxuICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgey8qIEJsb2NvIDI6IEF0aXZpZGFkZXMgQ05BRXMgQXV0b3JpemFkYXMgKi99XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJvcmRlciBib3JkZXItc2xhdGUtMzAwIHJvdW5kZWQgcC0zIGJnLXNsYXRlLTUwLzUwIHNwYWNlLXktMiB0ZXh0LXhzXCI+XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1zbGF0ZS05MDAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSB0ZXh0LVsxMXB4XSBib3JkZXItYiBib3JkZXItc2xhdGUtMjAwIHBiLTEuNVwiPlxyXG4gICAgICAgICAgICAgIDxBd2FyZCBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNSB0ZXh0LXNsYXRlLTcwMFwiIC8+XHJcbiAgICAgICAgICAgICAgQXRpdmlkYWRlcyBFY29uw7RtaWNhcyBBdXRvcml6YWRhcyAoQ05BRSlcclxuICAgICAgICAgICAgPC9zcGFuPlxyXG5cclxuICAgICAgICAgICAge2VzdGFiPy5jbmFlcyAmJiBlc3RhYi5jbmFlcy5sZW5ndGggPiAwID8gKFxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZGl2aWRlLXkgZGl2aWRlLXNsYXRlLTIwMCB0ZXh0LVsxMXB4XVwiPlxyXG4gICAgICAgICAgICAgICAge2VzdGFiLmNuYWVzLm1hcCgoaXRlbSwgaWR4KSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgIDxkaXYga2V5PXtpZHh9IGNsYXNzTmFtZT1cInB5LTEgZmxleCBpdGVtcy1zdGFydCBqdXN0aWZ5LWJldHdlZW4gZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tb25vIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTkwMCBtci0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtpdGVtLmNuYWVfY29kaWdvfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS04MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2l0ZW0uY25hZT8uZGVzY3JpY2FvIHx8IFwiQXRpdmlkYWRlIEVjb27DtG1pY2EgUmVnaXN0cmFkYVwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS02MDAgYmctd2hpdGUgcHgtMS41IHB5LTAuNSByb3VuZGVkIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIHNocmluay0wXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7aXRlbS5laF9wcmluY2lwYWwgPyBcIlByaW5jaXBhbFwiIDogXCJTZWN1bmTDoXJpYVwifVxyXG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LXNsYXRlLTYwMCBpdGFsaWNcIj5cclxuICAgICAgICAgICAgICAgIEF0aXZpZGFkZSBwcmluY2lwYWwgYXV0b3JpemFkYSBjb25mb3JtZSBwcm9jZXNzbyBkZSByZXF1ZXJpbWVudG8gZSB2aXN0b3JpYSBkZSBjYW1wbyBzYW5pdMOhcmlhLlxyXG4gICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgKX1cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIHsvKiBCbG9jbyAzOiBSZXNwb25zw6F2ZWlzIExlZ2FpcyBlIFTDqWNuaWNvcyAqL31cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBzbTpncmlkLWNvbHMtMiBnYXAtMyB0ZXh0LXhzXCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYm9yZGVyIGJvcmRlci1zbGF0ZS0zMDAgcm91bmRlZCBwLTIuNSBiZy1zbGF0ZS01MC81MFwiPlxyXG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtc2xhdGUtNTAwIHVwcGVyY2FzZSBmb250LXNlbWlib2xkIGJsb2NrXCI+UmVzcG9uc8OhdmVsIExlZ2FsPC9zcGFuPlxyXG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXNsYXRlLTkwMCBtdC0wLjVcIj5cclxuICAgICAgICAgICAgICAgIHtlc3RhYj8ucmVwcmVzZW50YW50ZV9sZWdhbD8ubm9tZV9jb21wbGV0byB8fCBcIlJlcHJlc2VudGFudGUgRGVjbGFyYWRvXCJ9XHJcbiAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgIHtlc3RhYj8ucmVwcmVzZW50YW50ZV9sZWdhbD8uY3BmICYmIChcclxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtc2xhdGUtNjAwIGZvbnQtbW9ub1wiPlxyXG4gICAgICAgICAgICAgICAgICBDUEY6IHtlc3RhYi5yZXByZXNlbnRhbnRlX2xlZ2FsLmNwZn1cclxuICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYm9yZGVyIGJvcmRlci1zbGF0ZS0zMDAgcm91bmRlZCBwLTIuNSBiZy1zbGF0ZS01MC81MFwiPlxyXG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtc2xhdGUtNTAwIHVwcGVyY2FzZSBmb250LXNlbWlib2xkIGJsb2NrXCI+UmVzcG9uc8OhdmVsIFTDqWNuaWNvIChSVCk8L3NwYW4+XHJcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtc2xhdGUtOTAwIG10LTAuNVwiPlxyXG4gICAgICAgICAgICAgICAge3J0VGl0dWxhcj8ubm9tZV9jb21wbGV0byB8fCBcIk7Do28gRXhpZ2lkbyBvdSBDb25mb3JtZSBMZWdpc2xhw6fDo29cIn1cclxuICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAge3J0VGl0dWxhcj8uY29uc2VsaG9fY2xhc3NlICYmIChcclxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtc2xhdGUtNjAwIGZvbnQtbW9ub1wiPlxyXG4gICAgICAgICAgICAgICAgICB7cnRUaXR1bGFyLmNvbnNlbGhvX2NsYXNzZX06IHtydFRpdHVsYXIubnVtZXJvX3JlZ2lzdHJvX2NvbnNlbGhvfS97cnRUaXR1bGFyLnVmX2NvbnNlbGhvfVxyXG4gICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgey8qIENvbmRpY2lvbmFudGVzIGUgUmVzdHJpw6fDtWVzICovfVxyXG4gICAgICAgICAge2FsdmFyYS5jb25kaWNpb25hbnRlc19yZXN0cmljb2VzICYmIChcclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJib3JkZXIgYm9yZGVyLWFtYmVyLTMwMCBiZy1hbWJlci01MC81MCByb3VuZGVkIHAtMi41IHRleHQteHMgdGV4dC1hbWJlci05NTBcIj5cclxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB1cHBlcmNhc2UgZm9udC1ib2xkIHRleHQtYW1iZXItODAwIGJsb2NrXCI+XHJcbiAgICAgICAgICAgICAgICBDb25kaWNpb25hbnRlcyBTYW5pdMOhcmlhcyAmIFJlc3RyacOnw7VlcyBkZSBPcGVyYcOnw6NvOlxyXG4gICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSBtdC0wLjUgbGVhZGluZy1yZWxheGVkIGZvbnQtbWVkaXVtXCI+XHJcbiAgICAgICAgICAgICAgICB7YWx2YXJhLmNvbmRpY2lvbmFudGVzX3Jlc3RyaWNvZXN9XHJcbiAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICl9XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIHsvKiBSb2RhcMOpOiBWYWxpZGFkZSwgUVIgQ29kZSBkZSBBdXRlbnRpY2lkYWRlIGUgQXNzaW5hdHVyYSAqL31cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB0LTQgYm9yZGVyLXQtMiBib3JkZXItc2xhdGUtOTAwIHNwYWNlLXktNCByZWxhdGl2ZSB6LTEwIG10LTRcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBzbTpncmlkLWNvbHMtMyBnYXAtNCBpdGVtcy1jZW50ZXJcIj5cclxuICAgICAgICAgICAgey8qIEJsb2NvIGRlIFZhbGlkYWRlIGUgRGF0YXMgKi99XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0xLjUgdGV4dC14c1wiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0yIGJvcmRlciBib3JkZXItc2xhdGUtMzAwIHJvdW5kZWQgYmctc2xhdGUtNTBcIj5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtc2xhdGUtNTAwIHVwcGVyY2FzZSBmb250LWJvbGQgYmxvY2tcIj5EYXRhIGRlIEV4cGVkacOnw6NvPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtc2xhdGUtOTUwIHRleHQtc21cIj57ZGF0YUVtaXNzYW9Gb3JtYXRhZGF9PC9zcGFuPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0yIGJvcmRlci0yIGJvcmRlci1lbWVyYWxkLTcwMCByb3VuZGVkIGJnLWVtZXJhbGQtNTBcIj5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtZW1lcmFsZC04MDAgdXBwZXJjYXNlIGZvbnQtYm9sZCBibG9ja1wiPlbDoWxpZG8gQXTDqTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtYmxhY2sgdGV4dC1lbWVyYWxkLTk1MCB0ZXh0LXNtXCI+e2RhdGFWZW5jaW1lbnRvRm9ybWF0YWRhfTwvc3Bhbj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICB7LyogQmxvY28gQ2VudHJhbDogUVIgQ29kZSBkZSBBdXRlbnRpY2lkYWRlICovfVxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyIHRleHQtY2VudGVyIHAtMiBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCByb3VuZGVkIGJnLXdoaXRlXCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTEuNSBiZy13aGl0ZSBib3JkZXIgYm9yZGVyLXNsYXRlLTMwMCByb3VuZGVkIHNoYWRvdy0yeHNcIj5cclxuICAgICAgICAgICAgICAgIDxRUkNvZGVTVkdcclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e3VybFZhbGlkYWNhb1B1YmxpY2F9XHJcbiAgICAgICAgICAgICAgICAgIHNpemU9ezk2fVxyXG4gICAgICAgICAgICAgICAgICBsZXZlbD1cIkhcIlxyXG4gICAgICAgICAgICAgICAgICBpbmNsdWRlTWFyZ2luPXtmYWxzZX1cclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bOXB4XSBmb250LWJvbGQgdGV4dC1zbGF0ZS03MDAgdXBwZXJjYXNlIG10LTFcIj5cclxuICAgICAgICAgICAgICAgIEF1dGVudGljaWRhZGUgcG9yIFFSIENvZGVcclxuICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bOHB4XSB0ZXh0LXNsYXRlLTUwMCBsZWFkaW5nLXRpZ2h0IG1heC13LVsxNDBweF1cIj5cclxuICAgICAgICAgICAgICAgIEFwb250ZSBhIGPDom1lcmEgZG8gY2VsdWxhciBwYXJhIHZlcmlmaWNhciBhIHZhbGlkYWRlIGp1csOtZGljYVxyXG4gICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICB7LyogQmxvY28gZGEgQXNzaW5hdHVyYSBPZmljaWFsICovfVxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtY2VudGVyIGZsZXggZmxleC1jb2wganVzdGlmeS1lbmQgcHQtNFwiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTgwMCBwdC0xLjUgbXgtYXV0byB3LTQ4XCI+XHJcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTk1MFwiPkF1dG9yaWRhZGUgU2FuaXTDoXJpYTwvcD5cclxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtc2xhdGUtNjAwXCI+e0FQUF9DT05GSUcub3JnYW99PC9wPlxyXG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bOXB4XSB0ZXh0LXNsYXRlLTUwMCBmb250LW1vbm9cIj5NdW5pY8OtcGlvIGRlIHtBUFBfQ09ORklHLm11bmljaXBpb30gLyB7QVBQX0NPTkZJRy51Zn08L3A+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgey8qIFJvZGFww6kgTGVnYWwgKi99XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzlweF0gdGV4dC1jZW50ZXIgdGV4dC1zbGF0ZS01MDAgcHQtMiBib3JkZXItdCBib3JkZXItc2xhdGUtMjAwXCI+XHJcbiAgICAgICAgICAgIEVzdGUgZG9jdW1lbnRvIHBvc3N1aSBmw6kgcMO6YmxpY2EgZSB2YWxpZGFkZSBqdXLDrWRpY2EgZW0gdG9kbyBvIHRlcnJpdMOzcmlvIG11bmljaXBhbCBkZSB7QVBQX0NPTkZJRy5tdW5pY2lwaW99L3tBUFBfQ09ORklHLnVmfS4gQSBmaXhhw6fDo28gZGVzdGUgYWx2YXLDoSBlbSBsb2NhbCB2aXPDrXZlbCBlIGRlIGbDoWNpbCBhY2Vzc28gYW8gcMO6YmxpY28gw6kgb2JyaWdhdMOzcmlhLCBub3MgdGVybW9zIGRvIEPDs2RpZ28gU2FuaXTDoXJpbyBNdW5pY2lwYWwuXHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgQWx2YXJhSW1wcmVzc2FvVmlldztcclxuIl19