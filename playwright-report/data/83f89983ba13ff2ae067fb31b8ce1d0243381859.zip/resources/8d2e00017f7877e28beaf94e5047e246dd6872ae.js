import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/indicadores/RelatorioSusPage.tsx");const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport8_react_jsxDevRuntime["jsxDEV"];/**
* Página de Pré-visualização e Impressão do Relatório Oficial SUS (RelatorioSusPage)
* Rota: /relatorios/sus ou /relatorios/sus/:ano
* Permite alternar o ano do exercício e disparar a impressão oficial A4 via window.print().
*/
import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=0fd2848a";
import { Link, useParams } from "/node_modules/.vite/deps/react-router-dom.js?v=0fd2848a";
import { ArrowLeft, Calendar, FileCheck2, Printer, RefreshCw, Shield } from "/node_modules/.vite/deps/lucide-react.js?v=0fd2848a";
import { APP_CONFIG } from "/src/config/app.config.ts";
import { ROUTES } from "/src/config/routes.config.ts";
import { useAuth } from "/src/contexts/AuthContext.tsx";
import { useRelatorioSus } from "/src/hooks/useIndicadores.ts";
import { RelatorioSusImpressaoView } from "/src/components/indicadores/RelatorioSusImpressaoView.tsx";
var _jsxFileName = "E:/Projetos VSCODE/visa_braunas/src/pages/indicadores/RelatorioSusPage.tsx";
import __vite__cjsImport8_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=0fd2848a";
var _s = $RefreshSig$();
export const RelatorioSusPage = () => {
	_s();
	const { ano: paramAno } = useParams();
	const [anoSelecionado, setAnoSelecionado] = useState(paramAno ? Number(paramAno) : 2026);
	const { user } = useAuth();
	const { data: relatorio, isLoading, isRefetching, refetch, isError } = useRelatorioSus(anoSelecionado);
	const handleImprimir = () => {
		window.print();
	};
	const anosDisponiveis = [
		2026,
		2025,
		2024
	];
	// Objeto de fallback caso a requisição inicial ainda esteja em carregamento
	const relatorioFallback = {
		municipio: APP_CONFIG.municipio,
		uf: APP_CONFIG.uf,
		nome_prefeitura: APP_CONFIG.prefeitura,
		nome_secretaria: APP_CONFIG.secretaria,
		nome_coordenadoria: APP_CONFIG.orgao,
		ano_exercicio: anoSelecionado,
		data_emissao_relatorio: new Date().toLocaleDateString("pt-BR", {
			day: "2-digit",
			month: "2-digit",
			year: "numeric",
			hour: "2-digit",
			minute: "2-digit"
		}),
		indicadores_sintese: [
			{
				codigo: "IND-11",
				titulo: "Indicador 11: Ações VAPT em Saúde do Trabalhador",
				descricao: "Inspeções sanitárias em ambientes de trabalho concluídas no município.",
				unidade: "ações",
				progresso: {
					meta_pactuada: 20,
					realizado: 18,
					percentual_atingido: 90,
					status: "Em Andamento"
				}
			},
			{
				codigo: "IND-12",
				titulo: "Indicador 12: Cobertura Sanitária de Risco III (Alto Risco)",
				descricao: "Percentual de estabelecimentos de Alto Risco inspecionados no exercício.",
				unidade: "%",
				progresso: {
					meta_pactuada: 100,
					realizado: 82.5,
					percentual_atingido: 82.5,
					status: "Em Andamento"
				}
			},
			{
				codigo: "IND-13",
				titulo: "Indicador 13: Cobertura Sanitária de Risco II (Médio Risco)",
				descricao: "Percentual de estabelecimentos de Médio Risco cadastrados fiscalizados.",
				unidade: "%",
				progresso: {
					meta_pactuada: 100,
					realizado: 94,
					percentual_atingido: 94,
					status: "Em Andamento"
				}
			},
			{
				codigo: "IND-14",
				titulo: "Indicador 14: Licenciamento / Declarações de Risco I (Baixo Risco)",
				descricao: "Percentual de atividades econômicas de Baixo Risco regularizadas.",
				unidade: "%",
				progresso: {
					meta_pactuada: 100,
					realizado: 100,
					percentual_atingido: 100,
					status: "Atingida"
				}
			},
			{
				codigo: "IND-15",
				titulo: "Indicador 15: Índice Sintético Geral de Cumprimento de Metas",
				descricao: "Média do desempenho institucional em relação a todas as metas regulatórias.",
				unidade: "%",
				progresso: {
					meta_pactuada: 100,
					realizado: 91.6,
					percentual_atingido: 91.6,
					status: "Em Andamento"
				}
			}
		],
		resumo_geral: {
			total_estabelecimentos_cadastrados: 239,
			distribuicao_por_risco: {
				"Risco III": 28,
				"Risco II": 64,
				"Risco I": 112,
				Dispensados: 35
			},
			total_inspecoes_exercicio: 84,
			total_alvaras_ativos: 162,
			acoes_vapt_concluidas: 18,
			status_geral_metas: "Em Andamento"
		}
	};
	const relatorioEfetivo = relatorio || relatorioFallback;
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "print:hidden bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ _jsxDEV(Link, {
						to: ROUTES.INDICADORES.DASHBOARD,
						className: "p-2 text-slate-500 hover:text-slate-800 dark:hover:text-white rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors",
						title: "Voltar ao Painel de Indicadores",
						children: /* @__PURE__ */ _jsxDEV(ArrowLeft, { className: "w-5 h-5" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 121,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 116,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h1", {
						className: "text-base font-bold text-slate-900 dark:text-white flex items-center gap-2",
						children: [/* @__PURE__ */ _jsxDEV(FileCheck2, { className: "w-4 h-4 text-teal-600" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 125,
							columnNumber: 15
						}, this), "Relatório Oficial de Prestação de Contas Sanitárias (SUS)"]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 124,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("p", {
						className: "text-xs text-slate-500 dark:text-slate-400",
						children: [
							"Exercício ",
							anoSelecionado,
							" • Pronto para impressão formal em A4 e envio ao DIGISUS"
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 128,
						columnNumber: 13
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 123,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 115,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "flex flex-wrap items-center gap-2.5",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-1.5 bg-slate-100 dark:bg-slate-800 p-1 rounded-lg border border-slate-200 dark:border-slate-700",
							children: [/* @__PURE__ */ _jsxDEV(Calendar, { className: "w-3.5 h-3.5 text-slate-500 ml-1.5" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 137,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("select", {
								value: anoSelecionado,
								onChange: (e) => setAnoSelecionado(Number(e.target.value)),
								className: "bg-transparent text-xs font-bold text-slate-800 dark:text-slate-200 focus:outline-none pr-2 py-0.5",
								children: anosDisponiveis.map((a) => /* @__PURE__ */ _jsxDEV("option", {
									value: a,
									className: "dark:bg-slate-800 text-slate-900 dark:text-white",
									children: ["Exercício ", a]
								}, a, true, {
									fileName: _jsxFileName,
									lineNumber: 144,
									columnNumber: 17
								}, this))
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 138,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 136,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							onClick: () => refetch(),
							disabled: isRefetching,
							className: "p-2 text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white bg-slate-100 dark:bg-slate-800 rounded-lg transition-colors",
							title: "Atualizar Dados",
							children: /* @__PURE__ */ _jsxDEV(RefreshCw, { className: `w-4 h-4 ${isRefetching ? "animate-spin text-teal-600" : ""}` }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 158,
								columnNumber: 13
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 151,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							onClick: handleImprimir,
							className: "inline-flex items-center gap-2 px-4 py-2 text-xs font-bold text-white bg-teal-600 hover:bg-teal-700 rounded-lg shadow-xs hover:shadow transition-all",
							children: [/* @__PURE__ */ _jsxDEV(Printer, { className: "w-4 h-4" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 167,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Imprimir Relatório (A4)" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 168,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 162,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 134,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 114,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "print:hidden p-3.5 bg-teal-50 dark:bg-teal-950/40 border border-teal-200 dark:border-teal-800 rounded-xl text-xs text-teal-900 dark:text-teal-200 flex items-center gap-3",
				children: [/* @__PURE__ */ _jsxDEV(Shield, { className: "w-5 h-5 text-teal-600 shrink-0" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 175,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", { children: [
					/* @__PURE__ */ _jsxDEV("span", {
						className: "font-bold",
						children: "Formato Oficial de Impressão:"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 177,
						columnNumber: 11
					}, this),
					" O layout abaixo é dimensionado automaticamente para folhas A4 com cabeçalho oficial do Município de ",
					APP_CONFIG.municipio,
					"/",
					APP_CONFIG.uf,
					", matriz de indicadores técnicos e campo formal de homologação pela Coordenação Sanitária."
				] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 176,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 174,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "bg-slate-200 dark:bg-slate-950 p-4 sm:p-8 rounded-xl print:p-0 print:bg-transparent print:m-0",
				children: /* @__PURE__ */ _jsxDEV(RelatorioSusImpressaoView, {
					relatorio: relatorioEfetivo,
					nomeCoordenador: user?.nome_completo || "Coordenação de Vigilância Sanitária",
					matriculaCoordenador: user?.matricula || "VISA-0042/MG"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 185,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 184,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 112,
		columnNumber: 5
	}, this);
};
_s(RelatorioSusPage, "Rhw4m3OZHhSBtCD9izBUU3Ez3Qo=", false, function() {
	return [
		useParams,
		useAuth,
		useRelatorioSus
	];
});
_c = RelatorioSusPage;
export default RelatorioSusPage;
var _c;
$RefreshReg$(_c, "RelatorioSusPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/indicadores/RelatorioSusPage.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("E:/Projetos VSCODE/visa_braunas/src/pages/indicadores/RelatorioSusPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("E:/Projetos VSCODE/visa_braunas/src/pages/indicadores/RelatorioSusPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "E:/Projetos VSCODE/visa_braunas/src/pages/indicadores/RelatorioSusPage.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7Ozs7QUFNQSxPQUFPLFNBQVMsZ0JBQWdCO0FBQ2hDLFNBQVMsTUFBTSxpQkFBaUI7QUFDaEMsU0FFRSxXQUNBLFVBRUEsWUFFQSxTQUNBLFdBQ0EsY0FDSztBQUNQLFNBQVMsa0JBQWtCO0FBQzNCLFNBQVMsY0FBYztBQUN2QixTQUFTLGVBQWU7QUFDeEIsU0FBUyx1QkFBdUI7QUFDaEMsU0FBUyxpQ0FBaUM7Ozs7QUFFMUMsT0FBTyxNQUFNLHlCQUFtQzs7Q0FDOUMsTUFBTSxFQUFFLEtBQUssYUFBYSxVQUE0QjtDQUN0RCxNQUFNLENBQUMsZ0JBQWdCLHFCQUFxQixTQUMxQyxXQUFXLE9BQU8sUUFBUSxJQUFJLElBQ2hDO0NBQ0EsTUFBTSxFQUFFLFNBQVMsUUFBUTtDQUV6QixNQUFNLEVBQ0osTUFBTSxXQUNOLFdBQ0EsY0FDQSxTQUNBLFlBQ0UsZ0JBQWdCLGNBQWM7Q0FFbEMsTUFBTSx1QkFBdUI7RUFDM0IsT0FBTyxNQUFNO0NBQ2Y7Q0FFQSxNQUFNLGtCQUFrQjtFQUFDO0VBQU07RUFBTTtDQUFJOztDQUd6QyxNQUFNLG9CQUFvQjtFQUN4QixXQUFXLFdBQVc7RUFDdEIsSUFBSSxXQUFXO0VBQ2YsaUJBQWlCLFdBQVc7RUFDNUIsaUJBQWlCLFdBQVc7RUFDNUIsb0JBQW9CLFdBQVc7RUFDL0IsZUFBZTtFQUNmLHdCQUF3QixJQUFJLEtBQUssQ0FBQyxDQUFDLG1CQUFtQixTQUFTO0dBQzdELEtBQUs7R0FDTCxPQUFPO0dBQ1AsTUFBTTtHQUNOLE1BQU07R0FDTixRQUFRO0VBQ1YsQ0FBQztFQUNELHFCQUFxQjtHQUNuQjtJQUNFLFFBQVE7SUFDUixRQUFRO0lBQ1IsV0FBVztJQUNYLFNBQVM7SUFDVCxXQUFXO0tBQUUsZUFBZTtLQUFJLFdBQVc7S0FBSSxxQkFBcUI7S0FBTSxRQUFRO0lBQWU7R0FDbkc7R0FDQTtJQUNFLFFBQVE7SUFDUixRQUFRO0lBQ1IsV0FBVztJQUNYLFNBQVM7SUFDVCxXQUFXO0tBQUUsZUFBZTtLQUFLLFdBQVc7S0FBTSxxQkFBcUI7S0FBTSxRQUFRO0lBQWU7R0FDdEc7R0FDQTtJQUNFLFFBQVE7SUFDUixRQUFRO0lBQ1IsV0FBVztJQUNYLFNBQVM7SUFDVCxXQUFXO0tBQUUsZUFBZTtLQUFLLFdBQVc7S0FBTSxxQkFBcUI7S0FBTSxRQUFRO0lBQWU7R0FDdEc7R0FDQTtJQUNFLFFBQVE7SUFDUixRQUFRO0lBQ1IsV0FBVztJQUNYLFNBQVM7SUFDVCxXQUFXO0tBQUUsZUFBZTtLQUFLLFdBQVc7S0FBTyxxQkFBcUI7S0FBTyxRQUFRO0lBQVc7R0FDcEc7R0FDQTtJQUNFLFFBQVE7SUFDUixRQUFRO0lBQ1IsV0FBVztJQUNYLFNBQVM7SUFDVCxXQUFXO0tBQUUsZUFBZTtLQUFLLFdBQVc7S0FBTSxxQkFBcUI7S0FBTSxRQUFRO0lBQWU7R0FDdEc7RUFDRjtFQUNBLGNBQWM7R0FDWixvQ0FBb0M7R0FDcEMsd0JBQXdCO0lBQUUsYUFBYTtJQUFJLFlBQVk7SUFBSSxXQUFXO0lBQUssYUFBYTtHQUFHO0dBQzNGLDJCQUEyQjtHQUMzQixzQkFBc0I7R0FDdEIsdUJBQXVCO0dBQ3ZCLG9CQUFvQjtFQUN0QjtDQUNGO0NBRUEsTUFBTSxtQkFBbUIsYUFBYTtDQUV0QyxPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQWY7R0FFRSx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLE1BQUQ7TUFDRSxJQUFJLE9BQU8sWUFBWTtNQUN2QixXQUFVO01BQ1YsT0FBTTtnQkFFTix3QkFBQyxXQUFELEVBQVcsV0FBVSxVQUFXOzs7OztLQUM1Qjs7OztlQUNOLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxNQUFEO01BQUksV0FBVTtnQkFBZCxDQUNFLHdCQUFDLFlBQUQsRUFBWSxXQUFVLHdCQUF5Qjs7OztnQkFBQywyREFFOUM7Ozs7O2VBQ0osd0JBQUMsS0FBRDtNQUFHLFdBQVU7Z0JBQWI7T0FBMEQ7T0FDN0M7T0FBZTtNQUN6Qjs7Ozs7YUFDQTs7OzthQUNGOzs7OztjQUVMLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWY7TUFFRSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLFVBQUQsRUFBVSxXQUFVLG9DQUFxQzs7OztpQkFDekQsd0JBQUMsVUFBRDtRQUNFLE9BQU87UUFDUCxXQUFXLE1BQU0sa0JBQWtCLE9BQU8sRUFBRSxPQUFPLEtBQUssQ0FBQztRQUN6RCxXQUFVO2tCQUVULGdCQUFnQixLQUFLLE1BQ3BCLHdCQUFDLFVBQUQ7U0FBZ0IsT0FBTztTQUFHLFdBQVU7bUJBQXBDLENBQXVGLGNBQzFFLENBQ0w7V0FGSzs7OztlQUVMLENBQ1Q7T0FDSzs7OztlQUNMOzs7Ozs7TUFFTCx3QkFBQyxVQUFEO09BQ0UsTUFBSztPQUNMLGVBQWUsUUFBUTtPQUN2QixVQUFVO09BQ1YsV0FBVTtPQUNWLE9BQU07aUJBRU4sd0JBQUMsV0FBRCxFQUFXLFdBQVcsV0FBVyxlQUFlLCtCQUErQixLQUFPOzs7OztNQUNoRjs7Ozs7TUFHUix3QkFBQyxVQUFEO09BQ0UsTUFBSztPQUNMLFNBQVM7T0FDVCxXQUFVO2lCQUhaLENBS0Usd0JBQUMsU0FBRCxFQUFTLFdBQVUsVUFBVzs7OztpQkFDOUIsd0JBQUMsUUFBRCxZQUFNLDBCQUE2Qjs7OztlQUM3Qjs7Ozs7O0tBQ0w7Ozs7O1lBQ0Y7Ozs7OztHQUdMLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxRQUFELEVBQVEsV0FBVSxpQ0FBa0M7Ozs7Y0FDcEQsd0JBQUMsT0FBRDtLQUNFLHdCQUFDLFFBQUQ7TUFBTSxXQUFVO2dCQUFZO0tBQW1DOzs7OztLQUFDO0tBQ21CLFdBQVc7S0FBVTtLQUFFLFdBQVc7S0FBRztJQUVySDs7OztZQUNGOzs7Ozs7R0FHTCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUNiLHdCQUFDLDJCQUFEO0tBQ0UsV0FBVztLQUNYLGlCQUFpQixNQUFNLGlCQUFpQjtLQUN4QyxzQkFBc0IsTUFBTSxhQUFhO0lBQzFDOzs7OztHQUNFOzs7OztFQUNGOzs7Ozs7QUFFVDs7Ozs7Ozs7O0FBRUEsZUFBZSIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJSZWxhdG9yaW9TdXNQYWdlLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyIvKipcclxuICogUMOhZ2luYSBkZSBQcsOpLXZpc3VhbGl6YcOnw6NvIGUgSW1wcmVzc8OjbyBkbyBSZWxhdMOzcmlvIE9maWNpYWwgU1VTIChSZWxhdG9yaW9TdXNQYWdlKVxyXG4gKiBSb3RhOiAvcmVsYXRvcmlvcy9zdXMgb3UgL3JlbGF0b3Jpb3Mvc3VzLzphbm9cclxuICogUGVybWl0ZSBhbHRlcm5hciBvIGFubyBkbyBleGVyY8OtY2lvIGUgZGlzcGFyYXIgYSBpbXByZXNzw6NvIG9maWNpYWwgQTQgdmlhIHdpbmRvdy5wcmludCgpLlxyXG4gKi9cclxuXHJcbmltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgeyBMaW5rLCB1c2VQYXJhbXMgfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xyXG5pbXBvcnQge1xyXG4gIEFsZXJ0Q2lyY2xlLFxyXG4gIEFycm93TGVmdCxcclxuICBDYWxlbmRhcixcclxuICBDaGVja0NpcmNsZTIsXHJcbiAgRmlsZUNoZWNrMixcclxuICBGaWxlVGV4dCxcclxuICBQcmludGVyLFxyXG4gIFJlZnJlc2hDdyxcclxuICBTaGllbGQsXHJcbn0gZnJvbSBcImx1Y2lkZS1yZWFjdFwiO1xyXG5pbXBvcnQgeyBBUFBfQ09ORklHIH0gZnJvbSBcIi4uLy4uL2NvbmZpZy9hcHAuY29uZmlnXCI7XHJcbmltcG9ydCB7IFJPVVRFUyB9IGZyb20gXCIuLi8uLi9jb25maWcvcm91dGVzLmNvbmZpZ1wiO1xyXG5pbXBvcnQgeyB1c2VBdXRoIH0gZnJvbSBcIi4uLy4uL2NvbnRleHRzL0F1dGhDb250ZXh0XCI7XHJcbmltcG9ydCB7IHVzZVJlbGF0b3Jpb1N1cyB9IGZyb20gXCIuLi8uLi9ob29rcy91c2VJbmRpY2Fkb3Jlc1wiO1xyXG5pbXBvcnQgeyBSZWxhdG9yaW9TdXNJbXByZXNzYW9WaWV3IH0gZnJvbSBcIi4uLy4uL2NvbXBvbmVudHMvaW5kaWNhZG9yZXMvUmVsYXRvcmlvU3VzSW1wcmVzc2FvVmlld1wiO1xyXG5cclxuZXhwb3J0IGNvbnN0IFJlbGF0b3Jpb1N1c1BhZ2U6IFJlYWN0LkZDID0gKCkgPT4ge1xyXG4gIGNvbnN0IHsgYW5vOiBwYXJhbUFubyB9ID0gdXNlUGFyYW1zPHsgYW5vPzogc3RyaW5nIH0+KCk7XHJcbiAgY29uc3QgW2Fub1NlbGVjaW9uYWRvLCBzZXRBbm9TZWxlY2lvbmFkb10gPSB1c2VTdGF0ZTxudW1iZXI+KFxyXG4gICAgcGFyYW1Bbm8gPyBOdW1iZXIocGFyYW1Bbm8pIDogMjAyNlxyXG4gICk7XHJcbiAgY29uc3QgeyB1c2VyIH0gPSB1c2VBdXRoKCk7XHJcblxyXG4gIGNvbnN0IHtcclxuICAgIGRhdGE6IHJlbGF0b3JpbyxcclxuICAgIGlzTG9hZGluZyxcclxuICAgIGlzUmVmZXRjaGluZyxcclxuICAgIHJlZmV0Y2gsXHJcbiAgICBpc0Vycm9yLFxyXG4gIH0gPSB1c2VSZWxhdG9yaW9TdXMoYW5vU2VsZWNpb25hZG8pO1xyXG5cclxuICBjb25zdCBoYW5kbGVJbXByaW1pciA9ICgpID0+IHtcclxuICAgIHdpbmRvdy5wcmludCgpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGFub3NEaXNwb25pdmVpcyA9IFsyMDI2LCAyMDI1LCAyMDI0XTtcclxuXHJcbiAgLy8gT2JqZXRvIGRlIGZhbGxiYWNrIGNhc28gYSByZXF1aXNpw6fDo28gaW5pY2lhbCBhaW5kYSBlc3RlamEgZW0gY2FycmVnYW1lbnRvXHJcbiAgY29uc3QgcmVsYXRvcmlvRmFsbGJhY2sgPSB7XHJcbiAgICBtdW5pY2lwaW86IEFQUF9DT05GSUcubXVuaWNpcGlvLFxyXG4gICAgdWY6IEFQUF9DT05GSUcudWYsXHJcbiAgICBub21lX3ByZWZlaXR1cmE6IEFQUF9DT05GSUcucHJlZmVpdHVyYSxcclxuICAgIG5vbWVfc2VjcmV0YXJpYTogQVBQX0NPTkZJRy5zZWNyZXRhcmlhLFxyXG4gICAgbm9tZV9jb29yZGVuYWRvcmlhOiBBUFBfQ09ORklHLm9yZ2FvLFxyXG4gICAgYW5vX2V4ZXJjaWNpbzogYW5vU2VsZWNpb25hZG8sXHJcbiAgICBkYXRhX2VtaXNzYW9fcmVsYXRvcmlvOiBuZXcgRGF0ZSgpLnRvTG9jYWxlRGF0ZVN0cmluZyhcInB0LUJSXCIsIHtcclxuICAgICAgZGF5OiBcIjItZGlnaXRcIixcclxuICAgICAgbW9udGg6IFwiMi1kaWdpdFwiLFxyXG4gICAgICB5ZWFyOiBcIm51bWVyaWNcIixcclxuICAgICAgaG91cjogXCIyLWRpZ2l0XCIsXHJcbiAgICAgIG1pbnV0ZTogXCIyLWRpZ2l0XCIsXHJcbiAgICB9KSxcclxuICAgIGluZGljYWRvcmVzX3NpbnRlc2U6IFtcclxuICAgICAge1xyXG4gICAgICAgIGNvZGlnbzogXCJJTkQtMTFcIixcclxuICAgICAgICB0aXR1bG86IFwiSW5kaWNhZG9yIDExOiBBw6fDtWVzIFZBUFQgZW0gU2HDumRlIGRvIFRyYWJhbGhhZG9yXCIsXHJcbiAgICAgICAgZGVzY3JpY2FvOiBcIkluc3Blw6fDtWVzIHNhbml0w6FyaWFzIGVtIGFtYmllbnRlcyBkZSB0cmFiYWxobyBjb25jbHXDrWRhcyBubyBtdW5pY8OtcGlvLlwiLFxyXG4gICAgICAgIHVuaWRhZGU6IFwiYcOnw7Vlc1wiLFxyXG4gICAgICAgIHByb2dyZXNzbzogeyBtZXRhX3BhY3R1YWRhOiAyMCwgcmVhbGl6YWRvOiAxOCwgcGVyY2VudHVhbF9hdGluZ2lkbzogOTAuMCwgc3RhdHVzOiBcIkVtIEFuZGFtZW50b1wiIH0sXHJcbiAgICAgIH0sXHJcbiAgICAgIHtcclxuICAgICAgICBjb2RpZ286IFwiSU5ELTEyXCIsXHJcbiAgICAgICAgdGl0dWxvOiBcIkluZGljYWRvciAxMjogQ29iZXJ0dXJhIFNhbml0w6FyaWEgZGUgUmlzY28gSUlJIChBbHRvIFJpc2NvKVwiLFxyXG4gICAgICAgIGRlc2NyaWNhbzogXCJQZXJjZW50dWFsIGRlIGVzdGFiZWxlY2ltZW50b3MgZGUgQWx0byBSaXNjbyBpbnNwZWNpb25hZG9zIG5vIGV4ZXJjw61jaW8uXCIsXHJcbiAgICAgICAgdW5pZGFkZTogXCIlXCIsXHJcbiAgICAgICAgcHJvZ3Jlc3NvOiB7IG1ldGFfcGFjdHVhZGE6IDEwMCwgcmVhbGl6YWRvOiA4Mi41LCBwZXJjZW50dWFsX2F0aW5naWRvOiA4Mi41LCBzdGF0dXM6IFwiRW0gQW5kYW1lbnRvXCIgfSxcclxuICAgICAgfSxcclxuICAgICAge1xyXG4gICAgICAgIGNvZGlnbzogXCJJTkQtMTNcIixcclxuICAgICAgICB0aXR1bG86IFwiSW5kaWNhZG9yIDEzOiBDb2JlcnR1cmEgU2FuaXTDoXJpYSBkZSBSaXNjbyBJSSAoTcOpZGlvIFJpc2NvKVwiLFxyXG4gICAgICAgIGRlc2NyaWNhbzogXCJQZXJjZW50dWFsIGRlIGVzdGFiZWxlY2ltZW50b3MgZGUgTcOpZGlvIFJpc2NvIGNhZGFzdHJhZG9zIGZpc2NhbGl6YWRvcy5cIixcclxuICAgICAgICB1bmlkYWRlOiBcIiVcIixcclxuICAgICAgICBwcm9ncmVzc286IHsgbWV0YV9wYWN0dWFkYTogMTAwLCByZWFsaXphZG86IDk0LjAsIHBlcmNlbnR1YWxfYXRpbmdpZG86IDk0LjAsIHN0YXR1czogXCJFbSBBbmRhbWVudG9cIiB9LFxyXG4gICAgICB9LFxyXG4gICAgICB7XHJcbiAgICAgICAgY29kaWdvOiBcIklORC0xNFwiLFxyXG4gICAgICAgIHRpdHVsbzogXCJJbmRpY2Fkb3IgMTQ6IExpY2VuY2lhbWVudG8gLyBEZWNsYXJhw6fDtWVzIGRlIFJpc2NvIEkgKEJhaXhvIFJpc2NvKVwiLFxyXG4gICAgICAgIGRlc2NyaWNhbzogXCJQZXJjZW50dWFsIGRlIGF0aXZpZGFkZXMgZWNvbsO0bWljYXMgZGUgQmFpeG8gUmlzY28gcmVndWxhcml6YWRhcy5cIixcclxuICAgICAgICB1bmlkYWRlOiBcIiVcIixcclxuICAgICAgICBwcm9ncmVzc286IHsgbWV0YV9wYWN0dWFkYTogMTAwLCByZWFsaXphZG86IDEwMC4wLCBwZXJjZW50dWFsX2F0aW5naWRvOiAxMDAuMCwgc3RhdHVzOiBcIkF0aW5naWRhXCIgfSxcclxuICAgICAgfSxcclxuICAgICAge1xyXG4gICAgICAgIGNvZGlnbzogXCJJTkQtMTVcIixcclxuICAgICAgICB0aXR1bG86IFwiSW5kaWNhZG9yIDE1OiDDjW5kaWNlIFNpbnTDqXRpY28gR2VyYWwgZGUgQ3VtcHJpbWVudG8gZGUgTWV0YXNcIixcclxuICAgICAgICBkZXNjcmljYW86IFwiTcOpZGlhIGRvIGRlc2VtcGVuaG8gaW5zdGl0dWNpb25hbCBlbSByZWxhw6fDo28gYSB0b2RhcyBhcyBtZXRhcyByZWd1bGF0w7NyaWFzLlwiLFxyXG4gICAgICAgIHVuaWRhZGU6IFwiJVwiLFxyXG4gICAgICAgIHByb2dyZXNzbzogeyBtZXRhX3BhY3R1YWRhOiAxMDAsIHJlYWxpemFkbzogOTEuNiwgcGVyY2VudHVhbF9hdGluZ2lkbzogOTEuNiwgc3RhdHVzOiBcIkVtIEFuZGFtZW50b1wiIH0sXHJcbiAgICAgIH0sXHJcbiAgICBdLFxyXG4gICAgcmVzdW1vX2dlcmFsOiB7XHJcbiAgICAgIHRvdGFsX2VzdGFiZWxlY2ltZW50b3NfY2FkYXN0cmFkb3M6IDIzOSxcclxuICAgICAgZGlzdHJpYnVpY2FvX3Bvcl9yaXNjbzogeyBcIlJpc2NvIElJSVwiOiAyOCwgXCJSaXNjbyBJSVwiOiA2NCwgXCJSaXNjbyBJXCI6IDExMiwgRGlzcGVuc2Fkb3M6IDM1IH0sXHJcbiAgICAgIHRvdGFsX2luc3BlY29lc19leGVyY2ljaW86IDg0LFxyXG4gICAgICB0b3RhbF9hbHZhcmFzX2F0aXZvczogMTYyLFxyXG4gICAgICBhY29lc192YXB0X2NvbmNsdWlkYXM6IDE4LFxyXG4gICAgICBzdGF0dXNfZ2VyYWxfbWV0YXM6IFwiRW0gQW5kYW1lbnRvXCIsXHJcbiAgICB9LFxyXG4gIH07XHJcblxyXG4gIGNvbnN0IHJlbGF0b3Jpb0VmZXRpdm8gPSByZWxhdG9yaW8gfHwgcmVsYXRvcmlvRmFsbGJhY2s7XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNlwiPlxyXG4gICAgICB7LyogQmFycmEgU3VwZXJpb3IgZGUgRmVycmFtZW50YXMgKE9jdWx0YSBuYSBJbXByZXNzw6NvKSAqL31cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcmludDpoaWRkZW4gYmctd2hpdGUgZGFyazpiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtODAwIHJvdW5kZWQteGwgcC00IHNoYWRvdy14cyBmbGV4IGZsZXgtY29sIHNtOmZsZXgtcm93IHNtOml0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTRcIj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zXCI+XHJcbiAgICAgICAgICA8TGlua1xyXG4gICAgICAgICAgICB0bz17Uk9VVEVTLklORElDQURPUkVTLkRBU0hCT0FSRH1cclxuICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0yIHRleHQtc2xhdGUtNTAwIGhvdmVyOnRleHQtc2xhdGUtODAwIGRhcms6aG92ZXI6dGV4dC13aGl0ZSByb3VuZGVkLWxnIGhvdmVyOmJnLXNsYXRlLTEwMCBkYXJrOmhvdmVyOmJnLXNsYXRlLTgwMCB0cmFuc2l0aW9uLWNvbG9yc1wiXHJcbiAgICAgICAgICAgIHRpdGxlPVwiVm9sdGFyIGFvIFBhaW5lbCBkZSBJbmRpY2Fkb3Jlc1wiXHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIDxBcnJvd0xlZnQgY2xhc3NOYW1lPVwidy01IGgtNVwiIC8+XHJcbiAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC1iYXNlIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGUgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICA8RmlsZUNoZWNrMiBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtdGVhbC02MDBcIiAvPlxyXG4gICAgICAgICAgICAgIFJlbGF0w7NyaW8gT2ZpY2lhbCBkZSBQcmVzdGHDp8OjbyBkZSBDb250YXMgU2FuaXTDoXJpYXMgKFNVUylcclxuICAgICAgICAgICAgPC9oMT5cclxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTUwMCBkYXJrOnRleHQtc2xhdGUtNDAwXCI+XHJcbiAgICAgICAgICAgICAgRXhlcmPDrWNpbyB7YW5vU2VsZWNpb25hZG99IOKAoiBQcm9udG8gcGFyYSBpbXByZXNzw6NvIGZvcm1hbCBlbSBBNCBlIGVudmlvIGFvIERJR0lTVVNcclxuICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgaXRlbXMtY2VudGVyIGdhcC0yLjVcIj5cclxuICAgICAgICAgIHsvKiBTZWxldG9yIGRlIEFubyAqL31cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBiZy1zbGF0ZS0xMDAgZGFyazpiZy1zbGF0ZS04MDAgcC0xIHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtNzAwXCI+XHJcbiAgICAgICAgICAgIDxDYWxlbmRhciBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNSB0ZXh0LXNsYXRlLTUwMCBtbC0xLjVcIiAvPlxyXG4gICAgICAgICAgICA8c2VsZWN0XHJcbiAgICAgICAgICAgICAgdmFsdWU9e2Fub1NlbGVjaW9uYWRvfVxyXG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0QW5vU2VsZWNpb25hZG8oTnVtYmVyKGUudGFyZ2V0LnZhbHVlKSl9XHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctdHJhbnNwYXJlbnQgdGV4dC14cyBmb250LWJvbGQgdGV4dC1zbGF0ZS04MDAgZGFyazp0ZXh0LXNsYXRlLTIwMCBmb2N1czpvdXRsaW5lLW5vbmUgcHItMiBweS0wLjVcIlxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAge2Fub3NEaXNwb25pdmVpcy5tYXAoKGEpID0+IChcclxuICAgICAgICAgICAgICAgIDxvcHRpb24ga2V5PXthfSB2YWx1ZT17YX0gY2xhc3NOYW1lPVwiZGFyazpiZy1zbGF0ZS04MDAgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlXCI+XHJcbiAgICAgICAgICAgICAgICAgIEV4ZXJjw61jaW8ge2F9XHJcbiAgICAgICAgICAgICAgICA8L29wdGlvbj5cclxuICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgPC9zZWxlY3Q+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiByZWZldGNoKCl9XHJcbiAgICAgICAgICAgIGRpc2FibGVkPXtpc1JlZmV0Y2hpbmd9XHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMiB0ZXh0LXNsYXRlLTYwMCBkYXJrOnRleHQtc2xhdGUtMzAwIGhvdmVyOnRleHQtc2xhdGUtOTAwIGRhcms6aG92ZXI6dGV4dC13aGl0ZSBiZy1zbGF0ZS0xMDAgZGFyazpiZy1zbGF0ZS04MDAgcm91bmRlZC1sZyB0cmFuc2l0aW9uLWNvbG9yc1wiXHJcbiAgICAgICAgICAgIHRpdGxlPVwiQXR1YWxpemFyIERhZG9zXCJcclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgPFJlZnJlc2hDdyBjbGFzc05hbWU9e2B3LTQgaC00ICR7aXNSZWZldGNoaW5nID8gXCJhbmltYXRlLXNwaW4gdGV4dC10ZWFsLTYwMFwiIDogXCJcIn1gfSAvPlxyXG4gICAgICAgICAgPC9idXR0b24+XHJcblxyXG4gICAgICAgICAgey8qIEJvdMOjbyBkZSBJbXByZXNzw6NvIERpcmV0YSAqL31cclxuICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZUltcHJpbWlyfVxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgcHgtNCBweS0yIHRleHQteHMgZm9udC1ib2xkIHRleHQtd2hpdGUgYmctdGVhbC02MDAgaG92ZXI6YmctdGVhbC03MDAgcm91bmRlZC1sZyBzaGFkb3cteHMgaG92ZXI6c2hhZG93IHRyYW5zaXRpb24tYWxsXCJcclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgPFByaW50ZXIgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+XHJcbiAgICAgICAgICAgIDxzcGFuPkltcHJpbWlyIFJlbGF0w7NyaW8gKEE0KTwvc3Bhbj5cclxuICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIHsvKiBBbGVydGEgZGUgRGljYSBkZSBJbXByZXNzw6NvIChPY3VsdG8gbmEgSW1wcmVzc8OjbykgKi99XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHJpbnQ6aGlkZGVuIHAtMy41IGJnLXRlYWwtNTAgZGFyazpiZy10ZWFsLTk1MC80MCBib3JkZXIgYm9yZGVyLXRlYWwtMjAwIGRhcms6Ym9yZGVyLXRlYWwtODAwIHJvdW5kZWQteGwgdGV4dC14cyB0ZXh0LXRlYWwtOTAwIGRhcms6dGV4dC10ZWFsLTIwMCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxyXG4gICAgICAgIDxTaGllbGQgY2xhc3NOYW1lPVwidy01IGgtNSB0ZXh0LXRlYWwtNjAwIHNocmluay0wXCIgLz5cclxuICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ib2xkXCI+Rm9ybWF0byBPZmljaWFsIGRlIEltcHJlc3PDo286PC9zcGFuPiBPIGxheW91dCBhYmFpeG8gw6lcclxuICAgICAgICAgIGRpbWVuc2lvbmFkbyBhdXRvbWF0aWNhbWVudGUgcGFyYSBmb2xoYXMgQTQgY29tIGNhYmXDp2FsaG8gb2ZpY2lhbCBkbyBNdW5pY8OtcGlvIGRlIHtBUFBfQ09ORklHLm11bmljaXBpb30ve0FQUF9DT05GSUcudWZ9LFxyXG4gICAgICAgICAgbWF0cml6IGRlIGluZGljYWRvcmVzIHTDqWNuaWNvcyBlIGNhbXBvIGZvcm1hbCBkZSBob21vbG9nYcOnw6NvIHBlbGEgQ29vcmRlbmHDp8OjbyBTYW5pdMOhcmlhLlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIHsvKiBWaXN1YWxpemFkb3IgZGUgSW1wcmVzc8OjbyAqL31cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zbGF0ZS0yMDAgZGFyazpiZy1zbGF0ZS05NTAgcC00IHNtOnAtOCByb3VuZGVkLXhsIHByaW50OnAtMCBwcmludDpiZy10cmFuc3BhcmVudCBwcmludDptLTBcIj5cclxuICAgICAgICA8UmVsYXRvcmlvU3VzSW1wcmVzc2FvVmlld1xyXG4gICAgICAgICAgcmVsYXRvcmlvPXtyZWxhdG9yaW9FZmV0aXZvfVxyXG4gICAgICAgICAgbm9tZUNvb3JkZW5hZG9yPXt1c2VyPy5ub21lX2NvbXBsZXRvIHx8IFwiQ29vcmRlbmHDp8OjbyBkZSBWaWdpbMOibmNpYSBTYW5pdMOhcmlhXCJ9XHJcbiAgICAgICAgICBtYXRyaWN1bGFDb29yZGVuYWRvcj17dXNlcj8ubWF0cmljdWxhIHx8IFwiVklTQS0wMDQyL01HXCJ9XHJcbiAgICAgICAgLz5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgUmVsYXRvcmlvU3VzUGFnZTtcclxuIl19