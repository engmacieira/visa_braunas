import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/DashboardPage.tsx");const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport15_react_jsxDevRuntime["jsxDEV"];/**
* Painel Operacional Principal (DashboardPage)
* Visão consolidada da Vigilância Sanitária Municipal de Braúnas/MG
* Consome dados reais em tempo de execução via TanStack Query (v5) e cliente Axios da API.
*/
import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=0fd2848a";
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=0fd2848a";
import { useQuery } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=0fd2848a";
import { AlertCircle, Building2, CheckCircle2, ChevronRight, ClipboardCheck, Eye, FileCheck, PlusCircle, RefreshCw, TrendingUp } from "/node_modules/.vite/deps/lucide-react.js?v=0fd2848a";
import { APP_CONFIG } from "/src/config/app.config.ts";
import { ROUTES } from "/src/config/routes.config.ts";
import { useAuth } from "/src/contexts/AuthContext.tsx";
import { apiClient } from "/src/services/apiClient.ts";
import { useDashboardIndicadores } from "/src/hooks/useIndicadores.ts";
import { useEstabelecimentosList } from "/src/hooks/useEstabelecimentos.ts";
import { useInspecoesList, useNotificacoesPendentes } from "/src/hooks/useFiscalizacao.ts";
import { useRequerimentosList } from "/src/hooks/useLicenciamento.ts";
import RiscoBadge from "/src/components/estabelecimentos/RiscoBadge.tsx";
import SituacaoAlvaraBadge from "/src/components/estabelecimentos/SituacaoAlvaraBadge.tsx";
import { formatCpfCnpj, formatData } from "/src/utils/formatters.ts";
var _jsxFileName = "E:/Projetos VSCODE/visa_braunas/src/pages/DashboardPage.tsx";
import __vite__cjsImport15_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=0fd2848a";
var _s = $RefreshSig$();
const MOTIVO_LABELS = {
	rotina_programada: "Rotina Programada",
	requerimento_alvara: "Requerimento de Alvará",
	denuncia: "Apuração de Denúncia",
	reinspecao: "Reinspeção Fiscal",
	vapt_trabalhador: "VAPT (Saúde Trabalhador)",
	investigacao_surto: "Investigação de Surto"
};
const STATUS_INSPECAO_BADGES = {
	agendada: {
		label: "Agendada",
		bg: "bg-blue-50 dark:bg-blue-950/40",
		text: "text-blue-700 dark:text-blue-300",
		border: "border-blue-200 dark:border-blue-800"
	},
	em_andamento: {
		label: "Em Andamento",
		bg: "bg-amber-50 dark:bg-amber-950/40",
		text: "text-amber-700 dark:text-amber-300",
		border: "border-amber-200 dark:border-amber-800"
	},
	concluida: {
		label: "Concluída",
		bg: "bg-emerald-50 dark:bg-emerald-950/40",
		text: "text-emerald-700 dark:text-emerald-300",
		border: "border-emerald-200 dark:border-emerald-800"
	},
	cancelada: {
		label: "Cancelada",
		bg: "bg-slate-100 dark:bg-slate-800",
		text: "text-slate-600 dark:text-slate-400",
		border: "border-slate-200 dark:border-slate-700"
	}
};
const STATUS_REQUERIMENTO_BADGES = {
	pendente: {
		label: "Pendente",
		bg: "bg-amber-50 dark:bg-amber-950/40",
		text: "text-amber-700 dark:text-amber-300",
		border: "border-amber-200 dark:border-amber-800"
	},
	em_analise: {
		label: "Em Análise",
		bg: "bg-blue-50 dark:bg-blue-950/40",
		text: "text-blue-700 dark:text-blue-300",
		border: "border-blue-200 dark:border-blue-800"
	},
	aguardando_inspecao: {
		label: "Aguardando Vistoria",
		bg: "bg-purple-50 dark:bg-purple-950/40",
		text: "text-purple-700 dark:text-purple-300",
		border: "border-purple-200 dark:border-purple-800"
	},
	aguardando_adequacao: {
		label: "Com Notificação",
		bg: "bg-rose-50 dark:bg-rose-950/40",
		text: "text-rose-700 dark:text-rose-300",
		border: "border-rose-200 dark:border-rose-800"
	},
	deferido: {
		label: "Deferido",
		bg: "bg-emerald-50 dark:bg-emerald-950/40",
		text: "text-emerald-700 dark:text-emerald-300",
		border: "border-emerald-200 dark:border-emerald-800"
	},
	indeferido: {
		label: "Indeferido",
		bg: "bg-rose-50 dark:bg-rose-950/40",
		text: "text-rose-700 dark:text-rose-300",
		border: "border-rose-200 dark:border-rose-800"
	},
	cancelado: {
		label: "Cancelado",
		bg: "bg-slate-100 dark:bg-slate-800",
		text: "text-slate-600 dark:text-slate-400",
		border: "border-slate-200 dark:border-slate-700"
	}
};
export const DashboardPage = () => {
	_s();
	const { user } = useAuth();
	const [activeTab, setActiveTab] = useState("estabelecimentos");
	// 1. Integridade operacional e conectividade do banco
	const { data: health, isLoading: healthLoading, refetch: refetchHealth } = useQuery({
		queryKey: ["health"],
		queryFn: async () => {
			const res = await apiClient.get("/health");
			return res.data;
		},
		staleTime: 60 * 1e3
	});
	// 2. Indicadores e metas oficiais do exercício
	const { data: dashboard, isLoading: dashboardLoading } = useDashboardIndicadores(APP_CONFIG.anoExercicioPadrao);
	// 3. Registros reais do banco: Estabelecimentos recentes
	const { data: estabelecimentosData, isLoading: estabelecimentosLoading, refetch: refetchEstabelecimentos } = useEstabelecimentosList({ limit: 5 });
	// 4. Registros reais do banco: Inspeções recentes
	const { data: inspecoes = [], isLoading: inspecoesLoading, refetch: refetchInspecoes } = useInspecoesList({ limit: 5 });
	// 5. Registros reais do banco: Requerimentos pendentes
	const { data: requerimentosData, isLoading: requerimentosLoading, refetch: refetchRequerimentos } = useRequerimentosList({
		limit: 5,
		apenas_fila: true
	});
	// 6. Registros reais do banco: Notificações com prazos
	const { data: notificacoesPendentes = [], isLoading: notificacoesLoading, refetch: refetchNotificacoes } = useNotificacoesPendentes(30);
	const listaEstabelecimentos = estabelecimentosData?.itens || estabelecimentosData?.items || [];
	const totalEstabelecimentos = estabelecimentosData?.total ?? dashboard?.total_estabelecimentos_cadastrados ?? 0;
	const listaRequerimentos = requerimentosData?.items || [];
	const handleRecarregarTudo = () => {
		refetchHealth();
		refetchEstabelecimentos();
		refetchInspecoes();
		refetchRequerimentos();
		refetchNotificacoes();
	};
	const isDbOnline = health?.database === "online" || health?.status === "healthy";
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 shadow-xs",
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: "flex flex-col sm:flex-row sm:items-center justify-between gap-4",
					children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h1", {
						className: "text-xl sm:text-2xl font-bold tracking-tight text-slate-900 dark:text-white",
						children: [
							"Painel Operacional · ",
							APP_CONFIG.municipio,
							"/",
							APP_CONFIG.uf
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 197,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("p", {
						className: "text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1",
						children: [
							"Olá, ",
							/* @__PURE__ */ _jsxDEV("strong", {
								className: "text-slate-700 dark:text-slate-200",
								children: user?.nome_completo
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 201,
								columnNumber: 20
							}, this),
							" (",
							user?.cargo,
							"). Ambiente de monitoramento sanitário e gestão regulatória."
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 200,
						columnNumber: 13
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 196,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ _jsxDEV("span", {
							className: `inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-medium border ${isDbOnline ? "bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 border-emerald-200 dark:border-emerald-800" : healthLoading ? "bg-slate-100 text-slate-600 border-slate-200" : "bg-rose-50 text-rose-700 border-rose-200"}`,
							children: [/* @__PURE__ */ _jsxDEV("span", { className: `w-2 h-2 rounded-full ${isDbOnline ? "bg-emerald-500 animate-pulse" : healthLoading ? "bg-slate-400" : "bg-rose-500"}` }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 216,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: healthLoading ? "Verificando Conexão..." : isDbOnline ? "PostgreSQL & API Conectados" : "Conexão Degradada / Offline" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 225,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 207,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							onClick: handleRecarregarTudo,
							className: "p-1.5 text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-white bg-slate-100 dark:bg-slate-800 rounded-lg hover:bg-slate-200 transition-colors",
							title: "Recarregar Dados Operacionais",
							children: /* @__PURE__ */ _jsxDEV(RefreshCw, { className: "w-4 h-4" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 240,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 234,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 206,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 195,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 194,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-xs",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center justify-between text-slate-500 dark:text-slate-400 mb-2",
								children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "text-xs font-semibold uppercase tracking-wider",
									children: "Estabelecimentos Ativos"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 251,
									columnNumber: 13
								}, this), /* @__PURE__ */ _jsxDEV(Building2, { className: "w-4 h-4 text-teal-600 dark:text-teal-400" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 254,
									columnNumber: 13
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 250,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "text-2xl font-bold text-slate-900 dark:text-white tabular-nums",
								children: estabelecimentosLoading ? /* @__PURE__ */ _jsxDEV("span", {
									className: "text-sm font-normal text-slate-400 animate-pulse",
									children: "Carregando..."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 258,
									columnNumber: 15
								}, this) : totalEstabelecimentos
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 256,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("p", {
								className: "text-xs text-slate-500 dark:text-slate-400 mt-1",
								children: "Cadastros econômicos regulados pela VISA"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 263,
								columnNumber: 11
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 249,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-xs",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center justify-between text-slate-500 dark:text-slate-400 mb-2",
								children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "text-xs font-semibold uppercase tracking-wider",
									children: "Vistorias no Exercício"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 271,
									columnNumber: 13
								}, this), /* @__PURE__ */ _jsxDEV(ClipboardCheck, { className: "w-4 h-4 text-purple-600 dark:text-purple-400" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 274,
									columnNumber: 13
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 270,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "text-2xl font-bold text-slate-900 dark:text-white tabular-nums",
								children: dashboardLoading ? /* @__PURE__ */ _jsxDEV("span", {
									className: "text-sm font-normal text-slate-400 animate-pulse",
									children: "Carregando..."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 278,
									columnNumber: 15
								}, this) : dashboard?.total_inspecoes_exercicio ?? inspecoes.length
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 276,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("p", {
								className: "text-xs text-slate-500 dark:text-slate-400 mt-1",
								children: "Inspeções sanitárias e fiscalizações concluídas"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 283,
								columnNumber: 11
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 269,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-xs",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center justify-between text-slate-500 dark:text-slate-400 mb-2",
								children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "text-xs font-semibold uppercase tracking-wider",
									children: "Alvarás Vigentes"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 291,
									columnNumber: 13
								}, this), /* @__PURE__ */ _jsxDEV(FileCheck, { className: "w-4 h-4 text-blue-600 dark:text-blue-400" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 294,
									columnNumber: 13
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 290,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "text-2xl font-bold text-slate-900 dark:text-white tabular-nums",
								children: dashboardLoading ? /* @__PURE__ */ _jsxDEV("span", {
									className: "text-sm font-normal text-slate-400 animate-pulse",
									children: "Carregando..."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 298,
									columnNumber: 15
								}, this) : dashboard?.total_alvaras_ativos ?? 0
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 296,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("p", {
								className: "text-xs text-slate-500 dark:text-slate-400 mt-1",
								children: "Licenças sanitárias expedidas com QR Code"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 303,
								columnNumber: 11
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 289,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-xs",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center justify-between text-slate-500 dark:text-slate-400 mb-2",
								children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "text-xs font-semibold uppercase tracking-wider",
									children: "Notificações Pendentes"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 311,
									columnNumber: 13
								}, this), /* @__PURE__ */ _jsxDEV(AlertCircle, { className: "w-4 h-4 text-amber-600 dark:text-amber-400" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 314,
									columnNumber: 13
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 310,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "text-2xl font-bold text-slate-900 dark:text-white tabular-nums",
								children: notificacoesLoading ? /* @__PURE__ */ _jsxDEV("span", {
									className: "text-sm font-normal text-slate-400 animate-pulse",
									children: "Carregando..."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 318,
									columnNumber: 15
								}, this) : notificacoesPendentes.length
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 316,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("p", {
								className: "text-xs text-slate-500 dark:text-slate-400 mt-1",
								children: "Termos com contagem regressiva de adequação"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 323,
								columnNumber: 11
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 309,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 247,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-xs overflow-hidden",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "p-5 border-b border-slate-200 dark:border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4",
					children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h2", {
						className: "text-base font-semibold text-slate-900 dark:text-white flex items-center gap-2",
						children: [/* @__PURE__ */ _jsxDEV("span", { children: "Registros Operacionais do Banco de Dados" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 334,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							className: "text-xs font-normal text-slate-500 dark:text-slate-400",
							children: "(Consultas em tempo real)"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 335,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 333,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("p", {
						className: "text-xs text-slate-500 dark:text-slate-400 mt-0.5",
						children: "Acompanhe as últimas movimentações cadastradas no sistema."
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 339,
						columnNumber: 13
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 332,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-1 bg-slate-100 dark:bg-slate-800/80 p-1 rounded-lg",
						children: [
							/* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								onClick: () => setActiveTab("estabelecimentos"),
								className: `px-3 py-1.5 rounded-md text-xs font-medium transition-colors ${activeTab === "estabelecimentos" ? "bg-white dark:bg-slate-900 text-teal-600 dark:text-teal-400 shadow-xs" : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"}`,
								children: [
									"Estabelecimentos (",
									totalEstabelecimentos,
									")"
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 346,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								onClick: () => setActiveTab("inspecoes"),
								className: `px-3 py-1.5 rounded-md text-xs font-medium transition-colors ${activeTab === "inspecoes" ? "bg-white dark:bg-slate-900 text-teal-600 dark:text-teal-400 shadow-xs" : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"}`,
								children: [
									"Inspeções (",
									inspecoes.length,
									")"
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 357,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								onClick: () => setActiveTab("requerimentos"),
								className: `px-3 py-1.5 rounded-md text-xs font-medium transition-colors ${activeTab === "requerimentos" ? "bg-white dark:bg-slate-900 text-teal-600 dark:text-teal-400 shadow-xs" : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"}`,
								children: [
									"Fila de Alvarás (",
									listaRequerimentos.length,
									")"
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 368,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								onClick: () => setActiveTab("alertas"),
								className: `px-3 py-1.5 rounded-md text-xs font-medium transition-colors ${activeTab === "alertas" ? "bg-white dark:bg-slate-900 text-teal-600 dark:text-teal-400 shadow-xs" : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"}`,
								children: [
									"Alertas (",
									notificacoesPendentes.length,
									")"
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 379,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 345,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 331,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "p-5",
					children: [
						activeTab === "estabelecimentos" && /* @__PURE__ */ _jsxDEV("div", { children: estabelecimentosLoading ? /* @__PURE__ */ _jsxDEV("div", {
							className: "py-12 text-center text-sm text-slate-500 animate-pulse",
							children: "Consultando estabelecimentos no banco de dados..."
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 399,
							columnNumber: 17
						}, this) : listaEstabelecimentos.length === 0 ? /* @__PURE__ */ _jsxDEV("div", {
							className: "py-12 text-center",
							children: [
								/* @__PURE__ */ _jsxDEV(Building2, { className: "w-10 h-10 text-slate-300 dark:text-slate-600 mx-auto mb-3" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 404,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("p", {
									className: "text-sm font-semibold text-slate-700 dark:text-slate-300",
									children: "Nenhum estabelecimento cadastrado no banco de dados."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 405,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("p", {
									className: "text-xs text-slate-500 mt-1 max-w-md mx-auto",
									children: "Cadastre o primeiro estabelecimento regulado ou execute a carga inicial para iniciar o monitoramento sanitário."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 408,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV(Link, {
									to: ROUTES.ESTABELECIMENTOS.NOVO,
									className: "inline-flex items-center gap-2 mt-4 px-3.5 py-2 rounded-lg bg-teal-600 text-white text-xs font-semibold hover:bg-teal-700 transition-colors",
									children: [/* @__PURE__ */ _jsxDEV(PlusCircle, { className: "w-4 h-4" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 415,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Cadastrar Estabelecimento" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 416,
										columnNumber: 21
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 411,
									columnNumber: 19
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 403,
							columnNumber: 17
						}, this) : /* @__PURE__ */ _jsxDEV("div", {
							className: "overflow-x-auto",
							children: [/* @__PURE__ */ _jsxDEV("table", {
								className: "w-full text-left border-collapse text-xs",
								children: [/* @__PURE__ */ _jsxDEV("thead", { children: /* @__PURE__ */ _jsxDEV("tr", {
									className: "border-b border-slate-200 dark:border-slate-800 text-slate-500 dark:text-slate-400 font-semibold uppercase tracking-wider",
									children: [
										/* @__PURE__ */ _jsxDEV("th", {
											className: "py-3 px-3",
											children: "Razão Social / Fantasia"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 424,
											columnNumber: 25
										}, this),
										/* @__PURE__ */ _jsxDEV("th", {
											className: "py-3 px-3",
											children: "CNPJ / CPF"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 425,
											columnNumber: 25
										}, this),
										/* @__PURE__ */ _jsxDEV("th", {
											className: "py-3 px-3",
											children: "Grau de Risco"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 426,
											columnNumber: 25
										}, this),
										/* @__PURE__ */ _jsxDEV("th", {
											className: "py-3 px-3",
											children: "Situação do Alvará"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 427,
											columnNumber: 25
										}, this),
										/* @__PURE__ */ _jsxDEV("th", {
											className: "py-3 px-3 text-right",
											children: "Ação"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 428,
											columnNumber: 25
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 423,
									columnNumber: 23
								}, this) }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 422,
									columnNumber: 21
								}, this), /* @__PURE__ */ _jsxDEV("tbody", {
									className: "divide-y divide-slate-100 dark:divide-slate-800 text-slate-700 dark:text-slate-300",
									children: listaEstabelecimentos.map((est) => /* @__PURE__ */ _jsxDEV("tr", {
										className: "hover:bg-slate-50/80 dark:hover:bg-slate-800/40 transition-colors",
										children: [
											/* @__PURE__ */ _jsxDEV("td", {
												className: "py-3 px-3 font-medium text-slate-900 dark:text-white",
												children: [/* @__PURE__ */ _jsxDEV("div", { children: est.razao_social }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 435,
													columnNumber: 29
												}, this), est.nome_fantasia && /* @__PURE__ */ _jsxDEV("div", {
													className: "text-[11px] text-slate-500 dark:text-slate-400",
													children: est.nome_fantasia
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 437,
													columnNumber: 31
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 434,
												columnNumber: 27
											}, this),
											/* @__PURE__ */ _jsxDEV("td", {
												className: "py-3 px-3 font-mono text-slate-600 dark:text-slate-400",
												children: formatCpfCnpj(est.cnpj_cpf)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 442,
												columnNumber: 27
											}, this),
											/* @__PURE__ */ _jsxDEV("td", {
												className: "py-3 px-3",
												children: /* @__PURE__ */ _jsxDEV(RiscoBadge, {
													risco: est.nivel_risco,
													size: "sm"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 446,
													columnNumber: 29
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 445,
												columnNumber: 27
											}, this),
											/* @__PURE__ */ _jsxDEV("td", {
												className: "py-3 px-3",
												children: /* @__PURE__ */ _jsxDEV(SituacaoAlvaraBadge, {
													situacao: est.situacao_alvara,
													size: "sm"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 449,
													columnNumber: 29
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 448,
												columnNumber: 27
											}, this),
											/* @__PURE__ */ _jsxDEV("td", {
												className: "py-3 px-3 text-right",
												children: /* @__PURE__ */ _jsxDEV(Link, {
													to: ROUTES.ESTABELECIMENTOS.DETALHE(est.id),
													className: "inline-flex items-center gap-1 px-2.5 py-1 text-[11px] font-medium text-teal-600 hover:text-teal-700 bg-teal-50 dark:bg-teal-950/40 dark:text-teal-300 rounded-md hover:bg-teal-100 transition-colors",
													children: [/* @__PURE__ */ _jsxDEV(Eye, { className: "w-3.5 h-3.5" }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 456,
														columnNumber: 31
													}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Ficha" }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 457,
														columnNumber: 31
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 452,
													columnNumber: 29
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 451,
												columnNumber: 27
											}, this)
										]
									}, est.id, true, {
										fileName: _jsxFileName,
										lineNumber: 433,
										columnNumber: 25
									}, this))
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 431,
									columnNumber: 21
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 421,
								columnNumber: 19
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 flex justify-between items-center text-xs text-slate-500",
								children: [/* @__PURE__ */ _jsxDEV("span", { children: [
									"Mostrando ",
									listaEstabelecimentos.length,
									" de ",
									totalEstabelecimentos,
									" registros"
								] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 465,
									columnNumber: 21
								}, this), /* @__PURE__ */ _jsxDEV(Link, {
									to: ROUTES.ESTABELECIMENTOS.LIST,
									className: "font-medium text-teal-600 dark:text-teal-400 hover:underline inline-flex items-center gap-1",
									children: [/* @__PURE__ */ _jsxDEV("span", { children: "Ver todos os estabelecimentos" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 470,
										columnNumber: 23
									}, this), /* @__PURE__ */ _jsxDEV(ChevronRight, { className: "w-3.5 h-3.5" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 471,
										columnNumber: 23
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 466,
									columnNumber: 21
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 464,
								columnNumber: 19
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 420,
							columnNumber: 17
						}, this) }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 397,
							columnNumber: 13
						}, this),
						activeTab === "inspecoes" && /* @__PURE__ */ _jsxDEV("div", { children: inspecoesLoading ? /* @__PURE__ */ _jsxDEV("div", {
							className: "py-12 text-center text-sm text-slate-500 animate-pulse",
							children: "Consultando fiscalizações no banco de dados..."
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 483,
							columnNumber: 17
						}, this) : inspecoes.length === 0 ? /* @__PURE__ */ _jsxDEV("div", {
							className: "py-12 text-center",
							children: [
								/* @__PURE__ */ _jsxDEV(ClipboardCheck, { className: "w-10 h-10 text-slate-300 dark:text-slate-600 mx-auto mb-3" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 488,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("p", {
									className: "text-sm font-semibold text-slate-700 dark:text-slate-300",
									children: "Nenhuma inspeção registrada no banco de dados."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 489,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("p", {
									className: "text-xs text-slate-500 mt-1 max-w-md mx-auto",
									children: "Agende uma vistoria de rotina, análise de alvará ou ação VAPT de saúde do trabalhador."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 492,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV(Link, {
									to: ROUTES.INSPECOES.LIST,
									className: "inline-flex items-center gap-2 mt-4 px-3.5 py-2 rounded-lg bg-teal-600 text-white text-xs font-semibold hover:bg-teal-700 transition-colors",
									children: [/* @__PURE__ */ _jsxDEV(PlusCircle, { className: "w-4 h-4" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 499,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Acessar Módulo de Fiscalização" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 500,
										columnNumber: 21
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 495,
									columnNumber: 19
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 487,
							columnNumber: 17
						}, this) : /* @__PURE__ */ _jsxDEV("div", {
							className: "overflow-x-auto",
							children: [/* @__PURE__ */ _jsxDEV("table", {
								className: "w-full text-left border-collapse text-xs",
								children: [/* @__PURE__ */ _jsxDEV("thead", { children: /* @__PURE__ */ _jsxDEV("tr", {
									className: "border-b border-slate-200 dark:border-slate-800 text-slate-500 dark:text-slate-400 font-semibold uppercase tracking-wider",
									children: [
										/* @__PURE__ */ _jsxDEV("th", {
											className: "py-3 px-3",
											children: "Termo / Notificação"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 508,
											columnNumber: 25
										}, this),
										/* @__PURE__ */ _jsxDEV("th", {
											className: "py-3 px-3",
											children: "Motivo da Ação"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 509,
											columnNumber: 25
										}, this),
										/* @__PURE__ */ _jsxDEV("th", {
											className: "py-3 px-3",
											children: "Status"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 510,
											columnNumber: 25
										}, this),
										/* @__PURE__ */ _jsxDEV("th", {
											className: "py-3 px-3",
											children: "Data Início"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 511,
											columnNumber: 25
										}, this),
										/* @__PURE__ */ _jsxDEV("th", {
											className: "py-3 px-3 text-right",
											children: "Ação"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 512,
											columnNumber: 25
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 507,
									columnNumber: 23
								}, this) }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 506,
									columnNumber: 21
								}, this), /* @__PURE__ */ _jsxDEV("tbody", {
									className: "divide-y divide-slate-100 dark:divide-slate-800 text-slate-700 dark:text-slate-300",
									children: inspecoes.map((insp) => {
										const statusConfig = STATUS_INSPECAO_BADGES[insp.status] || {
											label: insp.status,
											bg: "bg-slate-100",
											text: "text-slate-700",
											border: "border-slate-200"
										};
										return /* @__PURE__ */ _jsxDEV("tr", {
											className: "hover:bg-slate-50/80 dark:hover:bg-slate-800/40 transition-colors",
											children: [
												/* @__PURE__ */ _jsxDEV("td", {
													className: "py-3 px-3 font-semibold text-slate-900 dark:text-white",
													children: insp.numero_termo
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 526,
													columnNumber: 29
												}, this),
												/* @__PURE__ */ _jsxDEV("td", {
													className: "py-3 px-3 text-slate-700 dark:text-slate-300",
													children: MOTIVO_LABELS[insp.motivo] || insp.motivo
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 529,
													columnNumber: 29
												}, this),
												/* @__PURE__ */ _jsxDEV("td", {
													className: "py-3 px-3",
													children: /* @__PURE__ */ _jsxDEV("span", {
														className: `inline-flex items-center px-2 py-0.5 rounded-md border text-[11px] font-medium ${statusConfig.bg} ${statusConfig.text} ${statusConfig.border}`,
														children: statusConfig.label
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 533,
														columnNumber: 31
													}, this)
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 532,
													columnNumber: 29
												}, this),
												/* @__PURE__ */ _jsxDEV("td", {
													className: "py-3 px-3 text-slate-600 dark:text-slate-400",
													children: formatData(insp.data_inicio)
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 539,
													columnNumber: 29
												}, this),
												/* @__PURE__ */ _jsxDEV("td", {
													className: "py-3 px-3 text-right",
													children: /* @__PURE__ */ _jsxDEV(Link, {
														to: ROUTES.INSPECOES.LAUDO(insp.id),
														className: "inline-flex items-center gap-1 px-2.5 py-1 text-[11px] font-medium text-teal-600 hover:text-teal-700 bg-teal-50 dark:bg-teal-950/40 dark:text-teal-300 rounded-md hover:bg-teal-100 transition-colors",
														children: [/* @__PURE__ */ _jsxDEV(Eye, { className: "w-3.5 h-3.5" }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 547,
															columnNumber: 33
														}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Laudo" }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 548,
															columnNumber: 33
														}, this)]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 543,
														columnNumber: 31
													}, this)
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 542,
													columnNumber: 29
												}, this)
											]
										}, insp.id, true, {
											fileName: _jsxFileName,
											lineNumber: 525,
											columnNumber: 27
										}, this);
									})
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 515,
									columnNumber: 21
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 505,
								columnNumber: 19
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 flex justify-between items-center text-xs text-slate-500",
								children: [/* @__PURE__ */ _jsxDEV("span", { children: [
									"Mostrando ",
									inspecoes.length,
									" inspeções recentes"
								] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 557,
									columnNumber: 21
								}, this), /* @__PURE__ */ _jsxDEV(Link, {
									to: ROUTES.INSPECOES.LIST,
									className: "font-medium text-teal-600 dark:text-teal-400 hover:underline inline-flex items-center gap-1",
									children: [/* @__PURE__ */ _jsxDEV("span", { children: "Ver todas as fiscalizações" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 562,
										columnNumber: 23
									}, this), /* @__PURE__ */ _jsxDEV(ChevronRight, { className: "w-3.5 h-3.5" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 563,
										columnNumber: 23
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 558,
									columnNumber: 21
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 556,
								columnNumber: 19
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 504,
							columnNumber: 17
						}, this) }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 481,
							columnNumber: 13
						}, this),
						activeTab === "requerimentos" && /* @__PURE__ */ _jsxDEV("div", { children: requerimentosLoading ? /* @__PURE__ */ _jsxDEV("div", {
							className: "py-12 text-center text-sm text-slate-500 animate-pulse",
							children: "Consultando requerimentos de alvará no banco de dados..."
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 575,
							columnNumber: 17
						}, this) : listaRequerimentos.length === 0 ? /* @__PURE__ */ _jsxDEV("div", {
							className: "py-12 text-center",
							children: [
								/* @__PURE__ */ _jsxDEV(FileCheck, { className: "w-10 h-10 text-slate-300 dark:text-slate-600 mx-auto mb-3" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 580,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("p", {
									className: "text-sm font-semibold text-slate-700 dark:text-slate-300",
									children: "Nenhum requerimento de alvará pendente na fila."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 581,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("p", {
									className: "text-xs text-slate-500 mt-1 max-w-md mx-auto",
									children: "A fila de solicitações e protocolos sanitários está limpa no momento."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 584,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV(Link, {
									to: ROUTES.LICENCIAMENTO.LIST,
									className: "inline-flex items-center gap-2 mt-4 px-3.5 py-2 rounded-lg bg-teal-600 text-white text-xs font-semibold hover:bg-teal-700 transition-colors",
									children: /* @__PURE__ */ _jsxDEV("span", { children: "Abrir Fila de Licenciamento" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 591,
										columnNumber: 21
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 587,
									columnNumber: 19
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 579,
							columnNumber: 17
						}, this) : /* @__PURE__ */ _jsxDEV("div", {
							className: "overflow-x-auto",
							children: [/* @__PURE__ */ _jsxDEV("table", {
								className: "w-full text-left border-collapse text-xs",
								children: [/* @__PURE__ */ _jsxDEV("thead", { children: /* @__PURE__ */ _jsxDEV("tr", {
									className: "border-b border-slate-200 dark:border-slate-800 text-slate-500 dark:text-slate-400 font-semibold uppercase tracking-wider",
									children: [
										/* @__PURE__ */ _jsxDEV("th", {
											className: "py-3 px-3",
											children: "Protocolo"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 599,
											columnNumber: 25
										}, this),
										/* @__PURE__ */ _jsxDEV("th", {
											className: "py-3 px-3",
											children: "Razão Social / Solicitante"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 600,
											columnNumber: 25
										}, this),
										/* @__PURE__ */ _jsxDEV("th", {
											className: "py-3 px-3",
											children: "Tipo de Solicitação"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 601,
											columnNumber: 25
										}, this),
										/* @__PURE__ */ _jsxDEV("th", {
											className: "py-3 px-3",
											children: "Status"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 602,
											columnNumber: 25
										}, this),
										/* @__PURE__ */ _jsxDEV("th", {
											className: "py-3 px-3",
											children: "Data"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 603,
											columnNumber: 25
										}, this),
										/* @__PURE__ */ _jsxDEV("th", {
											className: "py-3 px-3 text-right",
											children: "Ação"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 604,
											columnNumber: 25
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 598,
									columnNumber: 23
								}, this) }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 597,
									columnNumber: 21
								}, this), /* @__PURE__ */ _jsxDEV("tbody", {
									className: "divide-y divide-slate-100 dark:divide-slate-800 text-slate-700 dark:text-slate-300",
									children: listaRequerimentos.map((req) => {
										const statusConfig = STATUS_REQUERIMENTO_BADGES[req.status] || {
											label: req.status,
											bg: "bg-slate-100",
											text: "text-slate-700",
											border: "border-slate-200"
										};
										return /* @__PURE__ */ _jsxDEV("tr", {
											className: "hover:bg-slate-50/80 dark:hover:bg-slate-800/40 transition-colors",
											children: [
												/* @__PURE__ */ _jsxDEV("td", {
													className: "py-3 px-3 font-semibold font-mono text-slate-900 dark:text-white",
													children: req.numero_protocolo
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 618,
													columnNumber: 29
												}, this),
												/* @__PURE__ */ _jsxDEV("td", {
													className: "py-3 px-3 text-slate-800 dark:text-slate-200",
													children: req.dados_declarados?.razao_social || "Estabelecimento Vinculado"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 621,
													columnNumber: 29
												}, this),
												/* @__PURE__ */ _jsxDEV("td", {
													className: "py-3 px-3 capitalize text-slate-600 dark:text-slate-400",
													children: req.tipo_solicitacao.replace("_", " ")
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 624,
													columnNumber: 29
												}, this),
												/* @__PURE__ */ _jsxDEV("td", {
													className: "py-3 px-3",
													children: /* @__PURE__ */ _jsxDEV("span", {
														className: `inline-flex items-center px-2 py-0.5 rounded-md border text-[11px] font-medium ${statusConfig.bg} ${statusConfig.text} ${statusConfig.border}`,
														children: statusConfig.label
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 628,
														columnNumber: 31
													}, this)
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 627,
													columnNumber: 29
												}, this),
												/* @__PURE__ */ _jsxDEV("td", {
													className: "py-3 px-3 text-slate-600 dark:text-slate-400",
													children: formatData(req.data_submissao)
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 634,
													columnNumber: 29
												}, this),
												/* @__PURE__ */ _jsxDEV("td", {
													className: "py-3 px-3 text-right",
													children: /* @__PURE__ */ _jsxDEV(Link, {
														to: ROUTES.LICENCIAMENTO.REQUERIMENTO_DETALHE(req.id),
														className: "inline-flex items-center gap-1 px-2.5 py-1 text-[11px] font-medium text-teal-600 hover:text-teal-700 bg-teal-50 dark:bg-teal-950/40 dark:text-teal-300 rounded-md hover:bg-teal-100 transition-colors",
														children: [/* @__PURE__ */ _jsxDEV(Eye, { className: "w-3.5 h-3.5" }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 642,
															columnNumber: 33
														}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Análise" }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 643,
															columnNumber: 33
														}, this)]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 638,
														columnNumber: 31
													}, this)
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 637,
													columnNumber: 29
												}, this)
											]
										}, req.id, true, {
											fileName: _jsxFileName,
											lineNumber: 617,
											columnNumber: 27
										}, this);
									})
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 607,
									columnNumber: 21
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 596,
								columnNumber: 19
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 flex justify-between items-center text-xs text-slate-500",
								children: [/* @__PURE__ */ _jsxDEV("span", { children: [
									"Mostrando ",
									listaRequerimentos.length,
									" processos na fila"
								] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 652,
									columnNumber: 21
								}, this), /* @__PURE__ */ _jsxDEV(Link, {
									to: ROUTES.LICENCIAMENTO.LIST,
									className: "font-medium text-teal-600 dark:text-teal-400 hover:underline inline-flex items-center gap-1",
									children: [/* @__PURE__ */ _jsxDEV("span", { children: "Ver fila completa" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 657,
										columnNumber: 23
									}, this), /* @__PURE__ */ _jsxDEV(ChevronRight, { className: "w-3.5 h-3.5" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 658,
										columnNumber: 23
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 653,
									columnNumber: 21
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 651,
								columnNumber: 19
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 595,
							columnNumber: 17
						}, this) }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 573,
							columnNumber: 13
						}, this),
						activeTab === "alertas" && /* @__PURE__ */ _jsxDEV("div", { children: notificacoesLoading ? /* @__PURE__ */ _jsxDEV("div", {
							className: "py-12 text-center text-sm text-slate-500 animate-pulse",
							children: "Consultando notificações sanitárias no banco de dados..."
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 670,
							columnNumber: 17
						}, this) : notificacoesPendentes.length === 0 ? /* @__PURE__ */ _jsxDEV("div", {
							className: "py-12 text-center",
							children: [
								/* @__PURE__ */ _jsxDEV(CheckCircle2, { className: "w-10 h-10 text-emerald-500 mx-auto mb-3" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 675,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("p", {
									className: "text-sm font-semibold text-slate-700 dark:text-slate-300",
									children: "Nenhuma notificação com prazo a vencer no período de 30 dias."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 676,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("p", {
									className: "text-xs text-slate-500 mt-1 max-w-md mx-auto",
									children: "Todos os termos de notificação e exigências estão em dia ou cumpridos."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 679,
									columnNumber: 19
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 674,
							columnNumber: 17
						}, this) : /* @__PURE__ */ _jsxDEV("div", {
							className: "overflow-x-auto",
							children: [/* @__PURE__ */ _jsxDEV("table", {
								className: "w-full text-left border-collapse text-xs",
								children: [/* @__PURE__ */ _jsxDEV("thead", { children: /* @__PURE__ */ _jsxDEV("tr", {
									className: "border-b border-slate-200 dark:border-slate-800 text-slate-500 dark:text-slate-400 font-semibold uppercase tracking-wider",
									children: [
										/* @__PURE__ */ _jsxDEV("th", {
											className: "py-3 px-3",
											children: "Termo"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 688,
											columnNumber: 25
										}, this),
										/* @__PURE__ */ _jsxDEV("th", {
											className: "py-3 px-3",
											children: "Estabelecimento Notificado"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 689,
											columnNumber: 25
										}, this),
										/* @__PURE__ */ _jsxDEV("th", {
											className: "py-3 px-3",
											children: "Fiscal Responsável"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 690,
											columnNumber: 25
										}, this),
										/* @__PURE__ */ _jsxDEV("th", {
											className: "py-3 px-3",
											children: "Data Limite"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 691,
											columnNumber: 25
										}, this),
										/* @__PURE__ */ _jsxDEV("th", {
											className: "py-3 px-3",
											children: "Prazo Restante"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 692,
											columnNumber: 25
										}, this),
										/* @__PURE__ */ _jsxDEV("th", {
											className: "py-3 px-3 text-right",
											children: "Ação"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 693,
											columnNumber: 25
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 687,
									columnNumber: 23
								}, this) }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 686,
									columnNumber: 21
								}, this), /* @__PURE__ */ _jsxDEV("tbody", {
									className: "divide-y divide-slate-100 dark:divide-slate-800 text-slate-700 dark:text-slate-300",
									children: notificacoesPendentes.map((notif) => {
										const isVencido = notif.dias_restantes < 0;
										const isCritico = notif.dias_restantes <= 5 && !isVencido;
										return /* @__PURE__ */ _jsxDEV("tr", {
											className: "hover:bg-slate-50/80 dark:hover:bg-slate-800/40 transition-colors",
											children: [
												/* @__PURE__ */ _jsxDEV("td", {
													className: "py-3 px-3 font-semibold text-slate-900 dark:text-white",
													children: notif.numero_termo
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 703,
													columnNumber: 29
												}, this),
												/* @__PURE__ */ _jsxDEV("td", {
													className: "py-3 px-3 text-slate-800 dark:text-slate-200",
													children: notif.razao_social
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 706,
													columnNumber: 29
												}, this),
												/* @__PURE__ */ _jsxDEV("td", {
													className: "py-3 px-3 text-slate-600 dark:text-slate-400",
													children: notif.fiscal_responsavel
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 709,
													columnNumber: 29
												}, this),
												/* @__PURE__ */ _jsxDEV("td", {
													className: "py-3 px-3 text-slate-600 dark:text-slate-400",
													children: formatData(notif.data_limite_adequacao)
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 712,
													columnNumber: 29
												}, this),
												/* @__PURE__ */ _jsxDEV("td", {
													className: "py-3 px-3",
													children: /* @__PURE__ */ _jsxDEV("span", {
														className: `inline-flex items-center px-2 py-0.5 rounded-md border text-[11px] font-semibold ${isVencido ? "bg-rose-100 dark:bg-rose-950/60 text-rose-800 dark:text-rose-200 border-rose-300" : isCritico ? "bg-amber-100 dark:bg-amber-950/60 text-amber-800 dark:text-amber-200 border-amber-300" : "bg-blue-50 dark:bg-blue-950/40 text-blue-700 dark:text-blue-300 border-blue-200"}`,
														children: isVencido ? `Expirado (${Math.abs(notif.dias_restantes)} dias)` : `${notif.dias_restantes} dias restantes`
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 716,
														columnNumber: 31
													}, this)
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 715,
													columnNumber: 29
												}, this),
												/* @__PURE__ */ _jsxDEV("td", {
													className: "py-3 px-3 text-right",
													children: /* @__PURE__ */ _jsxDEV(Link, {
														to: ROUTES.INSPECOES.LAUDO(notif.inspecao_id),
														className: "inline-flex items-center gap-1 px-2.5 py-1 text-[11px] font-medium text-teal-600 hover:text-teal-700 bg-teal-50 dark:bg-teal-950/40 dark:text-teal-300 rounded-md hover:bg-teal-100 transition-colors",
														children: [/* @__PURE__ */ _jsxDEV(Eye, { className: "w-3.5 h-3.5" }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 735,
															columnNumber: 33
														}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Ver Termo" }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 736,
															columnNumber: 33
														}, this)]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 731,
														columnNumber: 31
													}, this)
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 730,
													columnNumber: 29
												}, this)
											]
										}, notif.inspecao_id, true, {
											fileName: _jsxFileName,
											lineNumber: 702,
											columnNumber: 27
										}, this);
									})
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 696,
									columnNumber: 21
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 685,
								columnNumber: 19
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 flex justify-between items-center text-xs text-slate-500",
								children: [/* @__PURE__ */ _jsxDEV("span", { children: [
									"Mostrando ",
									notificacoesPendentes.length,
									" notificações"
								] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 745,
									columnNumber: 21
								}, this), /* @__PURE__ */ _jsxDEV(Link, {
									to: ROUTES.INSPECOES.PRAZOS,
									className: "font-medium text-teal-600 dark:text-teal-400 hover:underline inline-flex items-center gap-1",
									children: [/* @__PURE__ */ _jsxDEV("span", { children: "Abrir Painel de Prazos Completo" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 750,
										columnNumber: 23
									}, this), /* @__PURE__ */ _jsxDEV(ChevronRight, { className: "w-3.5 h-3.5" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 751,
										columnNumber: 23
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 746,
									columnNumber: 21
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 744,
								columnNumber: 19
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 684,
							columnNumber: 17
						}, this) }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 668,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 394,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 330,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 shadow-xs",
				children: [/* @__PURE__ */ _jsxDEV("h2", {
					className: "text-base font-semibold text-slate-900 dark:text-white mb-4",
					children: "Acessos Rápidos aos Módulos do Sistema"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 763,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4",
					children: [
						/* @__PURE__ */ _jsxDEV(Link, {
							to: ROUTES.ESTABELECIMENTOS.LIST,
							className: "p-4 rounded-xl border border-slate-200 dark:border-slate-800 hover:border-teal-500 dark:hover:border-teal-500 transition-all hover:shadow-xs group",
							children: /* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-3",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "w-10 h-10 rounded-lg bg-teal-50 dark:bg-teal-950/40 text-teal-600 flex items-center justify-center group-hover:scale-105 transition-transform",
									children: /* @__PURE__ */ _jsxDEV(Building2, { className: "w-5 h-5" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 774,
										columnNumber: 17
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 773,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h3", {
									className: "text-sm font-semibold text-slate-900 dark:text-white group-hover:text-teal-600 transition-colors",
									children: "Estabelecimentos"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 777,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("p", {
									className: "text-xs text-slate-500 dark:text-slate-400",
									children: "Cadastros, CNAEs e vínculos de RT"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 780,
									columnNumber: 17
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 776,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 772,
								columnNumber: 13
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 768,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV(Link, {
							to: ROUTES.INSPECOES.LIST,
							className: "p-4 rounded-xl border border-slate-200 dark:border-slate-800 hover:border-teal-500 dark:hover:border-teal-500 transition-all hover:shadow-xs group",
							children: /* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-3",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "w-10 h-10 rounded-lg bg-teal-50 dark:bg-teal-950/40 text-teal-600 flex items-center justify-center group-hover:scale-105 transition-transform",
									children: /* @__PURE__ */ _jsxDEV(ClipboardCheck, { className: "w-5 h-5" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 793,
										columnNumber: 17
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 792,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h3", {
									className: "text-sm font-semibold text-slate-900 dark:text-white group-hover:text-teal-600 transition-colors",
									children: "Fiscalização & VAPT"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 796,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("p", {
									className: "text-xs text-slate-500 dark:text-slate-400",
									children: "Termos, vistorias e notificações"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 799,
									columnNumber: 17
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 795,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 791,
								columnNumber: 13
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 787,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV(Link, {
							to: ROUTES.LICENCIAMENTO.LIST,
							className: "p-4 rounded-xl border border-slate-200 dark:border-slate-800 hover:border-teal-500 dark:hover:border-teal-500 transition-all hover:shadow-xs group",
							children: /* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-3",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "w-10 h-10 rounded-lg bg-teal-50 dark:bg-teal-950/40 text-teal-600 flex items-center justify-center group-hover:scale-105 transition-transform",
									children: /* @__PURE__ */ _jsxDEV(FileCheck, { className: "w-5 h-5" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 812,
										columnNumber: 17
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 811,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h3", {
									className: "text-sm font-semibold text-slate-900 dark:text-white group-hover:text-teal-600 transition-colors",
									children: "Alvarás Sanitários"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 815,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("p", {
									className: "text-xs text-slate-500 dark:text-slate-400",
									children: "Requerimentos e emissão com QR Code"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 818,
									columnNumber: 17
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 814,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 810,
								columnNumber: 13
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 806,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV(Link, {
							to: ROUTES.OUVIDORIA.LIST,
							className: "p-4 rounded-xl border border-slate-200 dark:border-slate-800 hover:border-teal-500 dark:hover:border-teal-500 transition-all hover:shadow-xs group",
							children: /* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-3",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "w-10 h-10 rounded-lg bg-teal-50 dark:bg-teal-950/40 text-teal-600 flex items-center justify-center group-hover:scale-105 transition-transform",
									children: /* @__PURE__ */ _jsxDEV(AlertCircle, { className: "w-5 h-5" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 831,
										columnNumber: 17
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 830,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h3", {
									className: "text-sm font-semibold text-slate-900 dark:text-white group-hover:text-teal-600 transition-colors",
									children: "Ouvidoria & Denúncias"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 834,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("p", {
									className: "text-xs text-slate-500 dark:text-slate-400",
									children: "Triagem e despacho fiscal"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 837,
									columnNumber: 17
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 833,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 829,
								columnNumber: 13
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 825,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV(Link, {
							to: ROUTES.INDICADORES.DASHBOARD,
							className: "p-4 rounded-xl border border-slate-200 dark:border-slate-800 hover:border-teal-500 dark:hover:border-teal-500 transition-all hover:shadow-xs group",
							children: /* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-3",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "w-10 h-10 rounded-lg bg-teal-50 dark:bg-teal-950/40 text-teal-600 flex items-center justify-center group-hover:scale-105 transition-transform",
									children: /* @__PURE__ */ _jsxDEV(TrendingUp, { className: "w-5 h-5" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 850,
										columnNumber: 17
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 849,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h3", {
									className: "text-sm font-semibold text-slate-900 dark:text-white group-hover:text-teal-600 transition-colors",
									children: "Indicadores 11 a 15"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 853,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("p", {
									className: "text-xs text-slate-500 dark:text-slate-400",
									children: "Painéis analíticos e metas SUS"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 856,
									columnNumber: 17
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 852,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 848,
								columnNumber: 13
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 844,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV(Link, {
							to: ROUTES.RELATORIOS.SUS(),
							className: "p-4 rounded-xl border border-slate-200 dark:border-slate-800 hover:border-teal-500 dark:hover:border-teal-500 transition-all hover:shadow-xs group",
							children: /* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-3",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "w-10 h-10 rounded-lg bg-teal-50 dark:bg-teal-950/40 text-teal-600 flex items-center justify-center group-hover:scale-105 transition-transform",
									children: /* @__PURE__ */ _jsxDEV(FileCheck, { className: "w-5 h-5" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 869,
										columnNumber: 17
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 868,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h3", {
									className: "text-sm font-semibold text-slate-900 dark:text-white group-hover:text-teal-600 transition-colors",
									children: "Prestação de Contas SUS"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 872,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("p", {
									className: "text-xs text-slate-500 dark:text-slate-400",
									children: "Relatório oficial DIGISUS em A4"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 875,
									columnNumber: 17
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 871,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 867,
								columnNumber: 13
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 863,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 767,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 762,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 192,
		columnNumber: 5
	}, this);
};
_s(DashboardPage, "iLhjL3YNmJ6/Jt82z6djzLv7AOU=", false, function() {
	return [
		useAuth,
		useQuery,
		useDashboardIndicadores,
		useEstabelecimentosList,
		useInspecoesList,
		useRequerimentosList,
		useNotificacoesPendentes
	];
});
_c = DashboardPage;
export default DashboardPage;
var _c;
$RefreshReg$(_c, "DashboardPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/DashboardPage.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("E:/Projetos VSCODE/visa_braunas/src/pages/DashboardPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("E:/Projetos VSCODE/visa_braunas/src/pages/DashboardPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "E:/Projetos VSCODE/visa_braunas/src/pages/DashboardPage.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7Ozs7QUFNQSxPQUFPLFNBQVMsZ0JBQWdCO0FBQ2hDLFNBQVMsWUFBWTtBQUNyQixTQUFTLGdCQUFnQjtBQUN6QixTQUNFLGFBQ0EsV0FFQSxjQUNBLGNBQ0EsZ0JBR0EsS0FDQSxXQUNBLFlBQ0EsV0FFQSxrQkFDSztBQUNQLFNBQVMsa0JBQWtCO0FBQzNCLFNBQVMsY0FBYztBQUN2QixTQUFTLGVBQWU7QUFDeEIsU0FBUyxpQkFBaUI7QUFDMUIsU0FBUywrQkFBK0I7QUFDeEMsU0FBUywrQkFBK0I7QUFDeEMsU0FBUyxrQkFBa0IsZ0NBQWdDO0FBQzNELFNBQVMsNEJBQTRCO0FBQ3JDLE9BQU8sZ0JBQWdCO0FBQ3ZCLE9BQU8seUJBQXlCO0FBQ2hDLFNBQVMsZUFBZSxrQkFBa0I7Ozs7QUFRMUMsTUFBTSxnQkFBd0M7Q0FDNUMsbUJBQW1CO0NBQ25CLHFCQUFxQjtDQUNyQixVQUFVO0NBQ1YsWUFBWTtDQUNaLGtCQUFrQjtDQUNsQixvQkFBb0I7QUFDdEI7QUFFQSxNQUFNLHlCQUFzRztDQUMxRyxVQUFVO0VBQ1IsT0FBTztFQUNQLElBQUk7RUFDSixNQUFNO0VBQ04sUUFBUTtDQUNWO0NBQ0EsY0FBYztFQUNaLE9BQU87RUFDUCxJQUFJO0VBQ0osTUFBTTtFQUNOLFFBQVE7Q0FDVjtDQUNBLFdBQVc7RUFDVCxPQUFPO0VBQ1AsSUFBSTtFQUNKLE1BQU07RUFDTixRQUFRO0NBQ1Y7Q0FDQSxXQUFXO0VBQ1QsT0FBTztFQUNQLElBQUk7RUFDSixNQUFNO0VBQ04sUUFBUTtDQUNWO0FBQ0Y7QUFFQSxNQUFNLDZCQUEwRztDQUM5RyxVQUFVO0VBQ1IsT0FBTztFQUNQLElBQUk7RUFDSixNQUFNO0VBQ04sUUFBUTtDQUNWO0NBQ0EsWUFBWTtFQUNWLE9BQU87RUFDUCxJQUFJO0VBQ0osTUFBTTtFQUNOLFFBQVE7Q0FDVjtDQUNBLHFCQUFxQjtFQUNuQixPQUFPO0VBQ1AsSUFBSTtFQUNKLE1BQU07RUFDTixRQUFRO0NBQ1Y7Q0FDQSxzQkFBc0I7RUFDcEIsT0FBTztFQUNQLElBQUk7RUFDSixNQUFNO0VBQ04sUUFBUTtDQUNWO0NBQ0EsVUFBVTtFQUNSLE9BQU87RUFDUCxJQUFJO0VBQ0osTUFBTTtFQUNOLFFBQVE7Q0FDVjtDQUNBLFlBQVk7RUFDVixPQUFPO0VBQ1AsSUFBSTtFQUNKLE1BQU07RUFDTixRQUFRO0NBQ1Y7Q0FDQSxXQUFXO0VBQ1QsT0FBTztFQUNQLElBQUk7RUFDSixNQUFNO0VBQ04sUUFBUTtDQUNWO0FBQ0Y7QUFFQSxPQUFPLE1BQU0sc0JBQWdDOztDQUMzQyxNQUFNLEVBQUUsU0FBUyxRQUFRO0NBQ3pCLE1BQU0sQ0FBQyxXQUFXLGdCQUFnQixTQUNoQyxrQkFDRjs7Q0FHQSxNQUFNLEVBQUUsTUFBTSxRQUFRLFdBQVcsZUFBZSxTQUFTLGtCQUFrQixTQUFxQjtFQUM5RixVQUFVLENBQUMsUUFBUTtFQUNuQixTQUFTLFlBQVk7R0FDbkIsTUFBTSxNQUFNLE1BQU0sVUFBVSxJQUFnQixTQUFTO0dBQ3JELE9BQU8sSUFBSTtFQUNiO0VBQ0EsV0FBVyxLQUFLO0NBQ2xCLENBQUM7O0NBR0QsTUFBTSxFQUFFLE1BQU0sV0FBVyxXQUFXLHFCQUFxQix3QkFDdkQsV0FBVyxrQkFDYjs7Q0FHQSxNQUFNLEVBQ0osTUFBTSxzQkFDTixXQUFXLHlCQUNYLFNBQVMsNEJBQ1Asd0JBQXdCLEVBQUUsT0FBTyxFQUFFLENBQUM7O0NBR3hDLE1BQU0sRUFDSixNQUFNLFlBQVksQ0FBQyxHQUNuQixXQUFXLGtCQUNYLFNBQVMscUJBQ1AsaUJBQWlCLEVBQUUsT0FBTyxFQUFFLENBQUM7O0NBR2pDLE1BQU0sRUFDSixNQUFNLG1CQUNOLFdBQVcsc0JBQ1gsU0FBUyx5QkFDUCxxQkFBcUI7RUFBRSxPQUFPO0VBQUcsYUFBYTtDQUFLLENBQUM7O0NBR3hELE1BQU0sRUFDSixNQUFNLHdCQUF3QixDQUFDLEdBQy9CLFdBQVcscUJBQ1gsU0FBUyx3QkFDUCx5QkFBeUIsRUFBRTtDQUUvQixNQUFNLHdCQUNKLHNCQUFzQixTQUNyQixzQkFBcUgsU0FDdEgsQ0FBQztDQUNILE1BQU0sd0JBQXdCLHNCQUFzQixTQUFTLFdBQVcsc0NBQXNDO0NBQzlHLE1BQU0scUJBQXFCLG1CQUFtQixTQUFTLENBQUM7Q0FFeEQsTUFBTSw2QkFBNkI7RUFDakMsY0FBYztFQUNkLHdCQUF3QjtFQUN4QixpQkFBaUI7RUFDakIscUJBQXFCO0VBQ3JCLG9CQUFvQjtDQUN0QjtDQUVBLE1BQU0sYUFBYSxRQUFRLGFBQWEsWUFBWSxRQUFRLFdBQVc7Q0FFdkUsT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUFmO0dBRUUsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FDYix3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE1BQUQ7TUFBSSxXQUFVO2dCQUFkO09BQTRGO09BQ3BFLFdBQVc7T0FBVTtPQUFFLFdBQVc7TUFDdEQ7Ozs7O2VBQ0osd0JBQUMsS0FBRDtNQUFHLFdBQVU7Z0JBQWI7T0FBMEU7T0FDbkUsd0JBQUMsVUFBRDtRQUFRLFdBQVU7a0JBQXNDLE1BQU07T0FBc0I7Ozs7O09BQUM7T0FBRyxNQUFNO09BQU07TUFFeEc7Ozs7O2FBQ0E7Ozs7ZUFFTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLFFBQUQ7T0FDRSxXQUFXLHNGQUNULGFBQ0ksMkhBQ0EsZ0JBQ0EsaURBQ0E7aUJBTlIsQ0FTRSx3QkFBQyxRQUFELEVBQ0UsV0FBVyx3QkFDVCxhQUNJLGlDQUNBLGdCQUNBLGlCQUNBLGdCQUVQOzs7O2lCQUNELHdCQUFDLFFBQUQsWUFDRyxnQkFDRywyQkFDQSxhQUNBLGdDQUNBLDhCQUNBOzs7O2VBQ0Y7Ozs7O2dCQUVOLHdCQUFDLFVBQUQ7T0FDRSxNQUFLO09BQ0wsU0FBUztPQUNULFdBQVU7T0FDVixPQUFNO2lCQUVOLHdCQUFDLFdBQUQsRUFBVyxXQUFVLFVBQVc7Ozs7O01BQzFCOzs7O2NBQ0w7Ozs7O2FBQ0Y7Ozs7OztHQUNGOzs7OztHQUdMLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWY7S0FFRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZjtPQUNFLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQWlEO1FBRTNEOzs7O2tCQUNOLHdCQUFDLFdBQUQsRUFBVyxXQUFVLDJDQUE0Qzs7OztnQkFDOUQ7Ozs7OztPQUNMLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUNaLDBCQUNDLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUFtRDtRQUFtQjs7OzttQkFFdEY7T0FFQzs7Ozs7T0FDTCx3QkFBQyxLQUFEO1FBQUcsV0FBVTtrQkFBa0Q7T0FFNUQ7Ozs7O01BQ0E7Ozs7OztLQUdMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmO09BQ0Usd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFBaUQ7UUFFM0Q7Ozs7a0JBQ04sd0JBQUMsZ0JBQUQsRUFBZ0IsV0FBVSwrQ0FBZ0Q7Ozs7Z0JBQ3ZFOzs7Ozs7T0FDTCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFDWixtQkFDQyx3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFBbUQ7UUFBbUI7Ozs7bUJBRXRGLFdBQVcsNkJBQTZCLFVBQVU7T0FFakQ7Ozs7O09BQ0wsd0JBQUMsS0FBRDtRQUFHLFdBQVU7a0JBQWtEO09BRTVEOzs7OztNQUNBOzs7Ozs7S0FHTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZjtPQUNFLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQWlEO1FBRTNEOzs7O2tCQUNOLHdCQUFDLFdBQUQsRUFBVyxXQUFVLDJDQUE0Qzs7OztnQkFDOUQ7Ozs7OztPQUNMLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUNaLG1CQUNDLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUFtRDtRQUFtQjs7OzttQkFFdEYsV0FBVyx3QkFBd0I7T0FFbEM7Ozs7O09BQ0wsd0JBQUMsS0FBRDtRQUFHLFdBQVU7a0JBQWtEO09BRTVEOzs7OztNQUNBOzs7Ozs7S0FHTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZjtPQUNFLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQWlEO1FBRTNEOzs7O2tCQUNOLHdCQUFDLGFBQUQsRUFBYSxXQUFVLDZDQUE4Qzs7OztnQkFDbEU7Ozs7OztPQUNMLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUNaLHNCQUNDLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUFtRDtRQUFtQjs7OzttQkFFdEYsc0JBQXNCO09BRXJCOzs7OztPQUNMLHdCQUFDLEtBQUQ7UUFBRyxXQUFVO2tCQUFrRDtPQUU1RDs7Ozs7TUFDQTs7Ozs7O0lBQ0Y7Ozs7OztHQUdMLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE1BQUQ7TUFBSSxXQUFVO2dCQUFkLENBQ0Usd0JBQUMsUUFBRCxZQUFNLDJDQUE4Qzs7OztnQkFDcEQsd0JBQUMsUUFBRDtPQUFNLFdBQVU7aUJBQXlEO01BRW5FOzs7O2NBQ0o7Ozs7O2VBQ0osd0JBQUMsS0FBRDtNQUFHLFdBQVU7Z0JBQW9EO0tBRTlEOzs7O2FBQ0E7Ozs7ZUFHTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZjtPQUNFLHdCQUFDLFVBQUQ7UUFDRSxNQUFLO1FBQ0wsZUFBZSxhQUFhLGtCQUFrQjtRQUM5QyxXQUFXLGdFQUNULGNBQWMscUJBQ1YsMEVBQ0E7a0JBTlI7U0FRQztTQUNvQjtTQUFzQjtRQUNuQzs7Ozs7O09BQ1Isd0JBQUMsVUFBRDtRQUNFLE1BQUs7UUFDTCxlQUFlLGFBQWEsV0FBVztRQUN2QyxXQUFXLGdFQUNULGNBQWMsY0FDViwwRUFDQTtrQkFOUjtTQVFDO1NBQ2EsVUFBVTtTQUFPO1FBQ3ZCOzs7Ozs7T0FDUix3QkFBQyxVQUFEO1FBQ0UsTUFBSztRQUNMLGVBQWUsYUFBYSxlQUFlO1FBQzNDLFdBQVcsZ0VBQ1QsY0FBYyxrQkFDViwwRUFDQTtrQkFOUjtTQVFDO1NBQ21CLG1CQUFtQjtTQUFPO1FBQ3RDOzs7Ozs7T0FDUix3QkFBQyxVQUFEO1FBQ0UsTUFBSztRQUNMLGVBQWUsYUFBYSxTQUFTO1FBQ3JDLFdBQVcsZ0VBQ1QsY0FBYyxZQUNWLDBFQUNBO2tCQU5SO1NBUUM7U0FDVyxzQkFBc0I7U0FBTztRQUNqQzs7Ozs7O01BQ0w7Ozs7O2FBQ0Y7Ozs7O2NBR0wsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZjtNQUVHLGNBQWMsc0JBQ2Isd0JBQUMsT0FBRCxZQUNHLDBCQUNDLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUF5RDtNQUVuRTs7OztpQkFDSCxzQkFBc0IsV0FBVyxJQUNuQyx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZjtRQUNFLHdCQUFDLFdBQUQsRUFBVyxXQUFVLDREQUE2RDs7Ozs7UUFDbEYsd0JBQUMsS0FBRDtTQUFHLFdBQVU7bUJBQTJEO1FBRXJFOzs7OztRQUNILHdCQUFDLEtBQUQ7U0FBRyxXQUFVO21CQUErQztRQUV6RDs7Ozs7UUFDSCx3QkFBQyxNQUFEO1NBQ0UsSUFBSSxPQUFPLGlCQUFpQjtTQUM1QixXQUFVO21CQUZaLENBSUUsd0JBQUMsWUFBRCxFQUFZLFdBQVUsVUFBVzs7OzttQkFDakMsd0JBQUMsUUFBRCxZQUFNLDRCQUErQjs7OztpQkFDakM7Ozs7OztPQUNIOzs7OztpQkFFTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLFNBQUQ7UUFBTyxXQUFVO2tCQUFqQixDQUNFLHdCQUFDLFNBQUQsWUFDRSx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFBZDtVQUNFLHdCQUFDLE1BQUQ7V0FBSSxXQUFVO3FCQUFZO1VBQTJCOzs7OztVQUNyRCx3QkFBQyxNQUFEO1dBQUksV0FBVTtxQkFBWTtVQUFjOzs7OztVQUN4Qyx3QkFBQyxNQUFEO1dBQUksV0FBVTtxQkFBWTtVQUFpQjs7Ozs7VUFDM0Msd0JBQUMsTUFBRDtXQUFJLFdBQVU7cUJBQVk7VUFBc0I7Ozs7O1VBQ2hELHdCQUFDLE1BQUQ7V0FBSSxXQUFVO3FCQUF1QjtVQUFROzs7OztTQUMzQzs7Ozs7aUJBQ0M7Ozs7a0JBQ1Asd0JBQUMsU0FBRDtTQUFPLFdBQVU7bUJBQ2Qsc0JBQXNCLEtBQUssUUFDMUIsd0JBQUMsTUFBRDtVQUFpQixXQUFVO29CQUEzQjtXQUNFLHdCQUFDLE1BQUQ7WUFBSSxXQUFVO3NCQUFkLENBQ0Usd0JBQUMsT0FBRCxZQUFNLElBQUksYUFBa0I7Ozs7c0JBQzNCLElBQUksaUJBQ0gsd0JBQUMsT0FBRDthQUFLLFdBQVU7dUJBQ1osSUFBSTtZQUNGOzs7O29CQUVMOzs7Ozs7V0FDSix3QkFBQyxNQUFEO1lBQUksV0FBVTtzQkFDWCxjQUFjLElBQUksUUFBUTtXQUN6Qjs7Ozs7V0FDSix3QkFBQyxNQUFEO1lBQUksV0FBVTtzQkFDWix3QkFBQyxZQUFEO2FBQVksT0FBTyxJQUFJO2FBQWEsTUFBSztZQUFNOzs7OztXQUM3Qzs7Ozs7V0FDSix3QkFBQyxNQUFEO1lBQUksV0FBVTtzQkFDWix3QkFBQyxxQkFBRDthQUFxQixVQUFVLElBQUk7YUFBaUIsTUFBSztZQUFNOzs7OztXQUM3RDs7Ozs7V0FDSix3QkFBQyxNQUFEO1lBQUksV0FBVTtzQkFDWix3QkFBQyxNQUFEO2FBQ0UsSUFBSSxPQUFPLGlCQUFpQixRQUFRLElBQUksRUFBRTthQUMxQyxXQUFVO3VCQUZaLENBSUUsd0JBQUMsS0FBRCxFQUFLLFdBQVUsY0FBZTs7Ozt1QkFDOUIsd0JBQUMsUUFBRCxZQUFNLFFBQVc7Ozs7cUJBQ2I7Ozs7OztXQUNKOzs7OztVQUNGO1lBM0JLLElBQUk7Ozs7Z0JBMkJULENBQ0w7UUFDSTs7OztnQkFDRjs7Ozs7aUJBQ1Asd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxRQUFEO1NBQU07U0FBVyxzQkFBc0I7U0FBTztTQUFLO1NBQXNCO1FBQWdCOzs7O2tCQUN6Rix3QkFBQyxNQUFEO1NBQ0UsSUFBSSxPQUFPLGlCQUFpQjtTQUM1QixXQUFVO21CQUZaLENBSUUsd0JBQUMsUUFBRCxZQUFNLGdDQUFtQzs7OzttQkFDekMsd0JBQUMsY0FBRCxFQUFjLFdBQVUsY0FBZTs7OztpQkFDbkM7Ozs7O2dCQUNIOzs7OztlQUNGOzs7OztlQUVKOzs7OztNQUlOLGNBQWMsZUFDYix3QkFBQyxPQUFELFlBQ0csbUJBQ0Msd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQXlEO01BRW5FOzs7O2lCQUNILFVBQVUsV0FBVyxJQUN2Qix3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZjtRQUNFLHdCQUFDLGdCQUFELEVBQWdCLFdBQVUsNERBQTZEOzs7OztRQUN2Rix3QkFBQyxLQUFEO1NBQUcsV0FBVTttQkFBMkQ7UUFFckU7Ozs7O1FBQ0gsd0JBQUMsS0FBRDtTQUFHLFdBQVU7bUJBQStDO1FBRXpEOzs7OztRQUNILHdCQUFDLE1BQUQ7U0FDRSxJQUFJLE9BQU8sVUFBVTtTQUNyQixXQUFVO21CQUZaLENBSUUsd0JBQUMsWUFBRCxFQUFZLFdBQVUsVUFBVzs7OzttQkFDakMsd0JBQUMsUUFBRCxZQUFNLGlDQUFvQzs7OztpQkFDdEM7Ozs7OztPQUNIOzs7OztpQkFFTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLFNBQUQ7UUFBTyxXQUFVO2tCQUFqQixDQUNFLHdCQUFDLFNBQUQsWUFDRSx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFBZDtVQUNFLHdCQUFDLE1BQUQ7V0FBSSxXQUFVO3FCQUFZO1VBQXVCOzs7OztVQUNqRCx3QkFBQyxNQUFEO1dBQUksV0FBVTtxQkFBWTtVQUFrQjs7Ozs7VUFDNUMsd0JBQUMsTUFBRDtXQUFJLFdBQVU7cUJBQVk7VUFBVTs7Ozs7VUFDcEMsd0JBQUMsTUFBRDtXQUFJLFdBQVU7cUJBQVk7VUFBZTs7Ozs7VUFDekMsd0JBQUMsTUFBRDtXQUFJLFdBQVU7cUJBQXVCO1VBQVE7Ozs7O1NBQzNDOzs7OztpQkFDQzs7OztrQkFDUCx3QkFBQyxTQUFEO1NBQU8sV0FBVTttQkFDZCxVQUFVLEtBQUssU0FBUztVQUN2QixNQUFNLGVBQWUsdUJBQXVCLEtBQUssV0FBVztXQUMxRCxPQUFPLEtBQUs7V0FDWixJQUFJO1dBQ0osTUFBTTtXQUNOLFFBQVE7VUFDVjtVQUVBLE9BQ0Usd0JBQUMsTUFBRDtXQUFrQixXQUFVO3FCQUE1QjtZQUNFLHdCQUFDLE1BQUQ7YUFBSSxXQUFVO3VCQUNYLEtBQUs7WUFDSjs7Ozs7WUFDSix3QkFBQyxNQUFEO2FBQUksV0FBVTt1QkFDWCxjQUFjLEtBQUssV0FBVyxLQUFLO1lBQ2xDOzs7OztZQUNKLHdCQUFDLE1BQUQ7YUFBSSxXQUFVO3VCQUNaLHdCQUFDLFFBQUQ7Y0FDRSxXQUFXLGtGQUFrRixhQUFhLEdBQUcsR0FBRyxhQUFhLEtBQUssR0FBRyxhQUFhO3dCQUVqSixhQUFhO2FBQ1Y7Ozs7O1lBQ0o7Ozs7O1lBQ0osd0JBQUMsTUFBRDthQUFJLFdBQVU7dUJBQ1gsV0FBVyxLQUFLLFdBQVc7WUFDMUI7Ozs7O1lBQ0osd0JBQUMsTUFBRDthQUFJLFdBQVU7dUJBQ1osd0JBQUMsTUFBRDtjQUNFLElBQUksT0FBTyxVQUFVLE1BQU0sS0FBSyxFQUFFO2NBQ2xDLFdBQVU7d0JBRlosQ0FJRSx3QkFBQyxLQUFELEVBQUssV0FBVSxjQUFlOzs7O3dCQUM5Qix3QkFBQyxRQUFELFlBQU0sUUFBVzs7OztzQkFDYjs7Ozs7O1lBQ0o7Ozs7O1dBQ0Y7YUExQkssS0FBSzs7OztpQkEwQlY7U0FFUixDQUFDO1FBQ0k7Ozs7Z0JBQ0Y7Ozs7O2lCQUNQLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsUUFBRDtTQUFNO1NBQVcsVUFBVTtTQUFPO1FBQXlCOzs7O2tCQUMzRCx3QkFBQyxNQUFEO1NBQ0UsSUFBSSxPQUFPLFVBQVU7U0FDckIsV0FBVTttQkFGWixDQUlFLHdCQUFDLFFBQUQsWUFBTSw2QkFBZ0M7Ozs7bUJBQ3RDLHdCQUFDLGNBQUQsRUFBYyxXQUFVLGNBQWU7Ozs7aUJBQ25DOzs7OztnQkFDSDs7Ozs7ZUFDRjs7Ozs7ZUFFSjs7Ozs7TUFJTixjQUFjLG1CQUNiLHdCQUFDLE9BQUQsWUFDRyx1QkFDQyx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBeUQ7TUFFbkU7Ozs7aUJBQ0gsbUJBQW1CLFdBQVcsSUFDaEMsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWY7UUFDRSx3QkFBQyxXQUFELEVBQVcsV0FBVSw0REFBNkQ7Ozs7O1FBQ2xGLHdCQUFDLEtBQUQ7U0FBRyxXQUFVO21CQUEyRDtRQUVyRTs7Ozs7UUFDSCx3QkFBQyxLQUFEO1NBQUcsV0FBVTttQkFBK0M7UUFFekQ7Ozs7O1FBQ0gsd0JBQUMsTUFBRDtTQUNFLElBQUksT0FBTyxjQUFjO1NBQ3pCLFdBQVU7bUJBRVYsd0JBQUMsUUFBRCxZQUFNLDhCQUFpQzs7Ozs7UUFDbkM7Ozs7O09BQ0g7Ozs7O2lCQUVMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsU0FBRDtRQUFPLFdBQVU7a0JBQWpCLENBQ0Usd0JBQUMsU0FBRCxZQUNFLHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUFkO1VBQ0Usd0JBQUMsTUFBRDtXQUFJLFdBQVU7cUJBQVk7VUFBYTs7Ozs7VUFDdkMsd0JBQUMsTUFBRDtXQUFJLFdBQVU7cUJBQVk7VUFBOEI7Ozs7O1VBQ3hELHdCQUFDLE1BQUQ7V0FBSSxXQUFVO3FCQUFZO1VBQXVCOzs7OztVQUNqRCx3QkFBQyxNQUFEO1dBQUksV0FBVTtxQkFBWTtVQUFVOzs7OztVQUNwQyx3QkFBQyxNQUFEO1dBQUksV0FBVTtxQkFBWTtVQUFROzs7OztVQUNsQyx3QkFBQyxNQUFEO1dBQUksV0FBVTtxQkFBdUI7VUFBUTs7Ozs7U0FDM0M7Ozs7O2lCQUNDOzs7O2tCQUNQLHdCQUFDLFNBQUQ7U0FBTyxXQUFVO21CQUNkLG1CQUFtQixLQUFLLFFBQVE7VUFDL0IsTUFBTSxlQUFlLDJCQUEyQixJQUFJLFdBQVc7V0FDN0QsT0FBTyxJQUFJO1dBQ1gsSUFBSTtXQUNKLE1BQU07V0FDTixRQUFRO1VBQ1Y7VUFFQSxPQUNFLHdCQUFDLE1BQUQ7V0FBaUIsV0FBVTtxQkFBM0I7WUFDRSx3QkFBQyxNQUFEO2FBQUksV0FBVTt1QkFDWCxJQUFJO1lBQ0g7Ozs7O1lBQ0osd0JBQUMsTUFBRDthQUFJLFdBQVU7dUJBQ1gsSUFBSSxrQkFBa0IsZ0JBQWdCO1lBQ3JDOzs7OztZQUNKLHdCQUFDLE1BQUQ7YUFBSSxXQUFVO3VCQUNYLElBQUksaUJBQWlCLFFBQVEsS0FBSyxHQUFHO1lBQ3BDOzs7OztZQUNKLHdCQUFDLE1BQUQ7YUFBSSxXQUFVO3VCQUNaLHdCQUFDLFFBQUQ7Y0FDRSxXQUFXLGtGQUFrRixhQUFhLEdBQUcsR0FBRyxhQUFhLEtBQUssR0FBRyxhQUFhO3dCQUVqSixhQUFhO2FBQ1Y7Ozs7O1lBQ0o7Ozs7O1lBQ0osd0JBQUMsTUFBRDthQUFJLFdBQVU7dUJBQ1gsV0FBVyxJQUFJLGNBQWM7WUFDNUI7Ozs7O1lBQ0osd0JBQUMsTUFBRDthQUFJLFdBQVU7dUJBQ1osd0JBQUMsTUFBRDtjQUNFLElBQUksT0FBTyxjQUFjLHFCQUFxQixJQUFJLEVBQUU7Y0FDcEQsV0FBVTt3QkFGWixDQUlFLHdCQUFDLEtBQUQsRUFBSyxXQUFVLGNBQWU7Ozs7d0JBQzlCLHdCQUFDLFFBQUQsWUFBTSxVQUFhOzs7O3NCQUNmOzs7Ozs7WUFDSjs7Ozs7V0FDRjthQTdCSyxJQUFJOzs7O2lCQTZCVDtTQUVSLENBQUM7UUFDSTs7OztnQkFDRjs7Ozs7aUJBQ1Asd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxRQUFEO1NBQU07U0FBVyxtQkFBbUI7U0FBTztRQUF3Qjs7OztrQkFDbkUsd0JBQUMsTUFBRDtTQUNFLElBQUksT0FBTyxjQUFjO1NBQ3pCLFdBQVU7bUJBRlosQ0FJRSx3QkFBQyxRQUFELFlBQU0sb0JBQXVCOzs7O21CQUM3Qix3QkFBQyxjQUFELEVBQWMsV0FBVSxjQUFlOzs7O2lCQUNuQzs7Ozs7Z0JBQ0g7Ozs7O2VBQ0Y7Ozs7O2VBRUo7Ozs7O01BSU4sY0FBYyxhQUNiLHdCQUFDLE9BQUQsWUFDRyxzQkFDQyx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBeUQ7TUFFbkU7Ozs7aUJBQ0gsc0JBQXNCLFdBQVcsSUFDbkMsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWY7UUFDRSx3QkFBQyxjQUFELEVBQWMsV0FBVSwwQ0FBMkM7Ozs7O1FBQ25FLHdCQUFDLEtBQUQ7U0FBRyxXQUFVO21CQUEyRDtRQUVyRTs7Ozs7UUFDSCx3QkFBQyxLQUFEO1NBQUcsV0FBVTttQkFBK0M7UUFFekQ7Ozs7O09BQ0E7Ozs7O2lCQUVMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsU0FBRDtRQUFPLFdBQVU7a0JBQWpCLENBQ0Usd0JBQUMsU0FBRCxZQUNFLHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUFkO1VBQ0Usd0JBQUMsTUFBRDtXQUFJLFdBQVU7cUJBQVk7VUFBUzs7Ozs7VUFDbkMsd0JBQUMsTUFBRDtXQUFJLFdBQVU7cUJBQVk7VUFBOEI7Ozs7O1VBQ3hELHdCQUFDLE1BQUQ7V0FBSSxXQUFVO3FCQUFZO1VBQXNCOzs7OztVQUNoRCx3QkFBQyxNQUFEO1dBQUksV0FBVTtxQkFBWTtVQUFlOzs7OztVQUN6Qyx3QkFBQyxNQUFEO1dBQUksV0FBVTtxQkFBWTtVQUFrQjs7Ozs7VUFDNUMsd0JBQUMsTUFBRDtXQUFJLFdBQVU7cUJBQXVCO1VBQVE7Ozs7O1NBQzNDOzs7OztpQkFDQzs7OztrQkFDUCx3QkFBQyxTQUFEO1NBQU8sV0FBVTttQkFDZCxzQkFBc0IsS0FBSyxVQUFVO1VBQ3BDLE1BQU0sWUFBWSxNQUFNLGlCQUFpQjtVQUN6QyxNQUFNLFlBQVksTUFBTSxrQkFBa0IsS0FBSyxDQUFDO1VBRWhELE9BQ0Usd0JBQUMsTUFBRDtXQUE0QixXQUFVO3FCQUF0QztZQUNFLHdCQUFDLE1BQUQ7YUFBSSxXQUFVO3VCQUNYLE1BQU07WUFDTDs7Ozs7WUFDSix3QkFBQyxNQUFEO2FBQUksV0FBVTt1QkFDWCxNQUFNO1lBQ0w7Ozs7O1lBQ0osd0JBQUMsTUFBRDthQUFJLFdBQVU7dUJBQ1gsTUFBTTtZQUNMOzs7OztZQUNKLHdCQUFDLE1BQUQ7YUFBSSxXQUFVO3VCQUNYLFdBQVcsTUFBTSxxQkFBcUI7WUFDckM7Ozs7O1lBQ0osd0JBQUMsTUFBRDthQUFJLFdBQVU7dUJBQ1osd0JBQUMsUUFBRDtjQUNFLFdBQVcsb0ZBQ1QsWUFDSSxxRkFDQSxZQUNBLDBGQUNBO3dCQUdMLFlBQ0csYUFBYSxLQUFLLElBQUksTUFBTSxjQUFjLEVBQUUsVUFDNUMsR0FBRyxNQUFNLGVBQWU7YUFDeEI7Ozs7O1lBQ0o7Ozs7O1lBQ0osd0JBQUMsTUFBRDthQUFJLFdBQVU7dUJBQ1osd0JBQUMsTUFBRDtjQUNFLElBQUksT0FBTyxVQUFVLE1BQU0sTUFBTSxXQUFXO2NBQzVDLFdBQVU7d0JBRlosQ0FJRSx3QkFBQyxLQUFELEVBQUssV0FBVSxjQUFlOzs7O3dCQUM5Qix3QkFBQyxRQUFELFlBQU0sWUFBZTs7OztzQkFDakI7Ozs7OztZQUNKOzs7OztXQUNGO2FBckNLLE1BQU07Ozs7aUJBcUNYO1NBRVIsQ0FBQztRQUNJOzs7O2dCQUNGOzs7OztpQkFDUCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLFFBQUQ7U0FBTTtTQUFXLHNCQUFzQjtTQUFPO1FBQW1COzs7O2tCQUNqRSx3QkFBQyxNQUFEO1NBQ0UsSUFBSSxPQUFPLFVBQVU7U0FDckIsV0FBVTttQkFGWixDQUlFLHdCQUFDLFFBQUQsWUFBTSxrQ0FBcUM7Ozs7bUJBQzNDLHdCQUFDLGNBQUQsRUFBYyxXQUFVLGNBQWU7Ozs7aUJBQ25DOzs7OztnQkFDSDs7Ozs7ZUFDRjs7Ozs7ZUFFSjs7Ozs7S0FFSjs7Ozs7WUFDRjs7Ozs7O0dBR0wsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLE1BQUQ7S0FBSSxXQUFVO2VBQThEO0lBRXhFOzs7O2NBRUosd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZjtNQUNFLHdCQUFDLE1BQUQ7T0FDRSxJQUFJLE9BQU8saUJBQWlCO09BQzVCLFdBQVU7aUJBRVYsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFDYix3QkFBQyxXQUFELEVBQVcsV0FBVSxVQUFXOzs7OztRQUM3Qjs7OztrQkFDTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQW1HO1FBRTdHOzs7O2tCQUNKLHdCQUFDLEtBQUQ7U0FBRyxXQUFVO21CQUE2QztRQUV2RDs7OztnQkFDQTs7OztnQkFDRjs7Ozs7O01BQ0Q7Ozs7O01BRU4sd0JBQUMsTUFBRDtPQUNFLElBQUksT0FBTyxVQUFVO09BQ3JCLFdBQVU7aUJBRVYsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFDYix3QkFBQyxnQkFBRCxFQUFnQixXQUFVLFVBQVc7Ozs7O1FBQ2xDOzs7O2tCQUNMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFBbUc7UUFFN0c7Ozs7a0JBQ0osd0JBQUMsS0FBRDtTQUFHLFdBQVU7bUJBQTZDO1FBRXZEOzs7O2dCQUNBOzs7O2dCQUNGOzs7Ozs7TUFDRDs7Ozs7TUFFTix3QkFBQyxNQUFEO09BQ0UsSUFBSSxPQUFPLGNBQWM7T0FDekIsV0FBVTtpQkFFVix3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUNiLHdCQUFDLFdBQUQsRUFBVyxXQUFVLFVBQVc7Ozs7O1FBQzdCOzs7O2tCQUNMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFBbUc7UUFFN0c7Ozs7a0JBQ0osd0JBQUMsS0FBRDtTQUFHLFdBQVU7bUJBQTZDO1FBRXZEOzs7O2dCQUNBOzs7O2dCQUNGOzs7Ozs7TUFDRDs7Ozs7TUFFTix3QkFBQyxNQUFEO09BQ0UsSUFBSSxPQUFPLFVBQVU7T0FDckIsV0FBVTtpQkFFVix3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUNiLHdCQUFDLGFBQUQsRUFBYSxXQUFVLFVBQVc7Ozs7O1FBQy9COzs7O2tCQUNMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFBbUc7UUFFN0c7Ozs7a0JBQ0osd0JBQUMsS0FBRDtTQUFHLFdBQVU7bUJBQTZDO1FBRXZEOzs7O2dCQUNBOzs7O2dCQUNGOzs7Ozs7TUFDRDs7Ozs7TUFFTix3QkFBQyxNQUFEO09BQ0UsSUFBSSxPQUFPLFlBQVk7T0FDdkIsV0FBVTtpQkFFVix3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUNiLHdCQUFDLFlBQUQsRUFBWSxXQUFVLFVBQVc7Ozs7O1FBQzlCOzs7O2tCQUNMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFBbUc7UUFFN0c7Ozs7a0JBQ0osd0JBQUMsS0FBRDtTQUFHLFdBQVU7bUJBQTZDO1FBRXZEOzs7O2dCQUNBOzs7O2dCQUNGOzs7Ozs7TUFDRDs7Ozs7TUFFTix3QkFBQyxNQUFEO09BQ0UsSUFBSSxPQUFPLFdBQVcsSUFBSTtPQUMxQixXQUFVO2lCQUVWLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQ2Isd0JBQUMsV0FBRCxFQUFXLFdBQVUsVUFBVzs7Ozs7UUFDN0I7Ozs7a0JBQ0wsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUFtRztRQUU3Rzs7OztrQkFDSix3QkFBQyxLQUFEO1NBQUcsV0FBVTttQkFBNkM7UUFFdkQ7Ozs7Z0JBQ0E7Ozs7Z0JBQ0Y7Ozs7OztNQUNEOzs7OztLQUNIOzs7OztZQUNGOzs7Ozs7RUFDRjs7Ozs7O0FBRVQ7Ozs7Ozs7Ozs7Ozs7QUFFQSxlQUFlIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkRhc2hib2FyZFBhZ2UudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbIi8qKlxyXG4gKiBQYWluZWwgT3BlcmFjaW9uYWwgUHJpbmNpcGFsIChEYXNoYm9hcmRQYWdlKVxyXG4gKiBWaXPDo28gY29uc29saWRhZGEgZGEgVmlnaWzDom5jaWEgU2FuaXTDoXJpYSBNdW5pY2lwYWwgZGUgQnJhw7puYXMvTUdcclxuICogQ29uc29tZSBkYWRvcyByZWFpcyBlbSB0ZW1wbyBkZSBleGVjdcOnw6NvIHZpYSBUYW5TdGFjayBRdWVyeSAodjUpIGUgY2xpZW50ZSBBeGlvcyBkYSBBUEkuXHJcbiAqL1xyXG5cclxuaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7IExpbmsgfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xyXG5pbXBvcnQgeyB1c2VRdWVyeSB9IGZyb20gXCJAdGFuc3RhY2svcmVhY3QtcXVlcnlcIjtcclxuaW1wb3J0IHtcclxuICBBbGVydENpcmNsZSxcclxuICBCdWlsZGluZzIsXHJcbiAgQ2FsZW5kYXIsXHJcbiAgQ2hlY2tDaXJjbGUyLFxyXG4gIENoZXZyb25SaWdodCxcclxuICBDbGlwYm9hcmRDaGVjayxcclxuICBDbG9jayxcclxuICBFeHRlcm5hbExpbmssXHJcbiAgRXllLFxyXG4gIEZpbGVDaGVjayxcclxuICBQbHVzQ2lyY2xlLFxyXG4gIFJlZnJlc2hDdyxcclxuICBTaGllbGRBbGVydCxcclxuICBUcmVuZGluZ1VwLFxyXG59IGZyb20gXCJsdWNpZGUtcmVhY3RcIjtcclxuaW1wb3J0IHsgQVBQX0NPTkZJRyB9IGZyb20gXCIuLi9jb25maWcvYXBwLmNvbmZpZ1wiO1xyXG5pbXBvcnQgeyBST1VURVMgfSBmcm9tIFwiLi4vY29uZmlnL3JvdXRlcy5jb25maWdcIjtcclxuaW1wb3J0IHsgdXNlQXV0aCB9IGZyb20gXCIuLi9jb250ZXh0cy9BdXRoQ29udGV4dFwiO1xyXG5pbXBvcnQgeyBhcGlDbGllbnQgfSBmcm9tIFwiLi4vc2VydmljZXMvYXBpQ2xpZW50XCI7XHJcbmltcG9ydCB7IHVzZURhc2hib2FyZEluZGljYWRvcmVzIH0gZnJvbSBcIi4uL2hvb2tzL3VzZUluZGljYWRvcmVzXCI7XHJcbmltcG9ydCB7IHVzZUVzdGFiZWxlY2ltZW50b3NMaXN0IH0gZnJvbSBcIi4uL2hvb2tzL3VzZUVzdGFiZWxlY2ltZW50b3NcIjtcclxuaW1wb3J0IHsgdXNlSW5zcGVjb2VzTGlzdCwgdXNlTm90aWZpY2Fjb2VzUGVuZGVudGVzIH0gZnJvbSBcIi4uL2hvb2tzL3VzZUZpc2NhbGl6YWNhb1wiO1xyXG5pbXBvcnQgeyB1c2VSZXF1ZXJpbWVudG9zTGlzdCB9IGZyb20gXCIuLi9ob29rcy91c2VMaWNlbmNpYW1lbnRvXCI7XHJcbmltcG9ydCBSaXNjb0JhZGdlIGZyb20gXCIuLi9jb21wb25lbnRzL2VzdGFiZWxlY2ltZW50b3MvUmlzY29CYWRnZVwiO1xyXG5pbXBvcnQgU2l0dWFjYW9BbHZhcmFCYWRnZSBmcm9tIFwiLi4vY29tcG9uZW50cy9lc3RhYmVsZWNpbWVudG9zL1NpdHVhY2FvQWx2YXJhQmFkZ2VcIjtcclxuaW1wb3J0IHsgZm9ybWF0Q3BmQ25waiwgZm9ybWF0RGF0YSB9IGZyb20gXCIuLi91dGlscy9mb3JtYXR0ZXJzXCI7XHJcblxyXG5pbnRlcmZhY2UgSGVhbHRoRGF0YSB7XHJcbiAgc3RhdHVzOiBzdHJpbmc7XHJcbiAgZGF0YWJhc2U6IHN0cmluZztcclxuICB0aW1lc3RhbXA6IHN0cmluZztcclxufVxyXG5cclxuY29uc3QgTU9USVZPX0xBQkVMUzogUmVjb3JkPHN0cmluZywgc3RyaW5nPiA9IHtcclxuICByb3RpbmFfcHJvZ3JhbWFkYTogXCJSb3RpbmEgUHJvZ3JhbWFkYVwiLFxyXG4gIHJlcXVlcmltZW50b19hbHZhcmE6IFwiUmVxdWVyaW1lbnRvIGRlIEFsdmFyw6FcIixcclxuICBkZW51bmNpYTogXCJBcHVyYcOnw6NvIGRlIERlbsO6bmNpYVwiLFxyXG4gIHJlaW5zcGVjYW86IFwiUmVpbnNwZcOnw6NvIEZpc2NhbFwiLFxyXG4gIHZhcHRfdHJhYmFsaGFkb3I6IFwiVkFQVCAoU2HDumRlIFRyYWJhbGhhZG9yKVwiLFxyXG4gIGludmVzdGlnYWNhb19zdXJ0bzogXCJJbnZlc3RpZ2HDp8OjbyBkZSBTdXJ0b1wiLFxyXG59O1xyXG5cclxuY29uc3QgU1RBVFVTX0lOU1BFQ0FPX0JBREdFUzogUmVjb3JkPHN0cmluZywgeyBsYWJlbDogc3RyaW5nOyBiZzogc3RyaW5nOyB0ZXh0OiBzdHJpbmc7IGJvcmRlcjogc3RyaW5nIH0+ID0ge1xyXG4gIGFnZW5kYWRhOiB7XHJcbiAgICBsYWJlbDogXCJBZ2VuZGFkYVwiLFxyXG4gICAgYmc6IFwiYmctYmx1ZS01MCBkYXJrOmJnLWJsdWUtOTUwLzQwXCIsXHJcbiAgICB0ZXh0OiBcInRleHQtYmx1ZS03MDAgZGFyazp0ZXh0LWJsdWUtMzAwXCIsXHJcbiAgICBib3JkZXI6IFwiYm9yZGVyLWJsdWUtMjAwIGRhcms6Ym9yZGVyLWJsdWUtODAwXCIsXHJcbiAgfSxcclxuICBlbV9hbmRhbWVudG86IHtcclxuICAgIGxhYmVsOiBcIkVtIEFuZGFtZW50b1wiLFxyXG4gICAgYmc6IFwiYmctYW1iZXItNTAgZGFyazpiZy1hbWJlci05NTAvNDBcIixcclxuICAgIHRleHQ6IFwidGV4dC1hbWJlci03MDAgZGFyazp0ZXh0LWFtYmVyLTMwMFwiLFxyXG4gICAgYm9yZGVyOiBcImJvcmRlci1hbWJlci0yMDAgZGFyazpib3JkZXItYW1iZXItODAwXCIsXHJcbiAgfSxcclxuICBjb25jbHVpZGE6IHtcclxuICAgIGxhYmVsOiBcIkNvbmNsdcOtZGFcIixcclxuICAgIGJnOiBcImJnLWVtZXJhbGQtNTAgZGFyazpiZy1lbWVyYWxkLTk1MC80MFwiLFxyXG4gICAgdGV4dDogXCJ0ZXh0LWVtZXJhbGQtNzAwIGRhcms6dGV4dC1lbWVyYWxkLTMwMFwiLFxyXG4gICAgYm9yZGVyOiBcImJvcmRlci1lbWVyYWxkLTIwMCBkYXJrOmJvcmRlci1lbWVyYWxkLTgwMFwiLFxyXG4gIH0sXHJcbiAgY2FuY2VsYWRhOiB7XHJcbiAgICBsYWJlbDogXCJDYW5jZWxhZGFcIixcclxuICAgIGJnOiBcImJnLXNsYXRlLTEwMCBkYXJrOmJnLXNsYXRlLTgwMFwiLFxyXG4gICAgdGV4dDogXCJ0ZXh0LXNsYXRlLTYwMCBkYXJrOnRleHQtc2xhdGUtNDAwXCIsXHJcbiAgICBib3JkZXI6IFwiYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDBcIixcclxuICB9LFxyXG59O1xyXG5cclxuY29uc3QgU1RBVFVTX1JFUVVFUklNRU5UT19CQURHRVM6IFJlY29yZDxzdHJpbmcsIHsgbGFiZWw6IHN0cmluZzsgYmc6IHN0cmluZzsgdGV4dDogc3RyaW5nOyBib3JkZXI6IHN0cmluZyB9PiA9IHtcclxuICBwZW5kZW50ZToge1xyXG4gICAgbGFiZWw6IFwiUGVuZGVudGVcIixcclxuICAgIGJnOiBcImJnLWFtYmVyLTUwIGRhcms6YmctYW1iZXItOTUwLzQwXCIsXHJcbiAgICB0ZXh0OiBcInRleHQtYW1iZXItNzAwIGRhcms6dGV4dC1hbWJlci0zMDBcIixcclxuICAgIGJvcmRlcjogXCJib3JkZXItYW1iZXItMjAwIGRhcms6Ym9yZGVyLWFtYmVyLTgwMFwiLFxyXG4gIH0sXHJcbiAgZW1fYW5hbGlzZToge1xyXG4gICAgbGFiZWw6IFwiRW0gQW7DoWxpc2VcIixcclxuICAgIGJnOiBcImJnLWJsdWUtNTAgZGFyazpiZy1ibHVlLTk1MC80MFwiLFxyXG4gICAgdGV4dDogXCJ0ZXh0LWJsdWUtNzAwIGRhcms6dGV4dC1ibHVlLTMwMFwiLFxyXG4gICAgYm9yZGVyOiBcImJvcmRlci1ibHVlLTIwMCBkYXJrOmJvcmRlci1ibHVlLTgwMFwiLFxyXG4gIH0sXHJcbiAgYWd1YXJkYW5kb19pbnNwZWNhbzoge1xyXG4gICAgbGFiZWw6IFwiQWd1YXJkYW5kbyBWaXN0b3JpYVwiLFxyXG4gICAgYmc6IFwiYmctcHVycGxlLTUwIGRhcms6YmctcHVycGxlLTk1MC80MFwiLFxyXG4gICAgdGV4dDogXCJ0ZXh0LXB1cnBsZS03MDAgZGFyazp0ZXh0LXB1cnBsZS0zMDBcIixcclxuICAgIGJvcmRlcjogXCJib3JkZXItcHVycGxlLTIwMCBkYXJrOmJvcmRlci1wdXJwbGUtODAwXCIsXHJcbiAgfSxcclxuICBhZ3VhcmRhbmRvX2FkZXF1YWNhbzoge1xyXG4gICAgbGFiZWw6IFwiQ29tIE5vdGlmaWNhw6fDo29cIixcclxuICAgIGJnOiBcImJnLXJvc2UtNTAgZGFyazpiZy1yb3NlLTk1MC80MFwiLFxyXG4gICAgdGV4dDogXCJ0ZXh0LXJvc2UtNzAwIGRhcms6dGV4dC1yb3NlLTMwMFwiLFxyXG4gICAgYm9yZGVyOiBcImJvcmRlci1yb3NlLTIwMCBkYXJrOmJvcmRlci1yb3NlLTgwMFwiLFxyXG4gIH0sXHJcbiAgZGVmZXJpZG86IHtcclxuICAgIGxhYmVsOiBcIkRlZmVyaWRvXCIsXHJcbiAgICBiZzogXCJiZy1lbWVyYWxkLTUwIGRhcms6YmctZW1lcmFsZC05NTAvNDBcIixcclxuICAgIHRleHQ6IFwidGV4dC1lbWVyYWxkLTcwMCBkYXJrOnRleHQtZW1lcmFsZC0zMDBcIixcclxuICAgIGJvcmRlcjogXCJib3JkZXItZW1lcmFsZC0yMDAgZGFyazpib3JkZXItZW1lcmFsZC04MDBcIixcclxuICB9LFxyXG4gIGluZGVmZXJpZG86IHtcclxuICAgIGxhYmVsOiBcIkluZGVmZXJpZG9cIixcclxuICAgIGJnOiBcImJnLXJvc2UtNTAgZGFyazpiZy1yb3NlLTk1MC80MFwiLFxyXG4gICAgdGV4dDogXCJ0ZXh0LXJvc2UtNzAwIGRhcms6dGV4dC1yb3NlLTMwMFwiLFxyXG4gICAgYm9yZGVyOiBcImJvcmRlci1yb3NlLTIwMCBkYXJrOmJvcmRlci1yb3NlLTgwMFwiLFxyXG4gIH0sXHJcbiAgY2FuY2VsYWRvOiB7XHJcbiAgICBsYWJlbDogXCJDYW5jZWxhZG9cIixcclxuICAgIGJnOiBcImJnLXNsYXRlLTEwMCBkYXJrOmJnLXNsYXRlLTgwMFwiLFxyXG4gICAgdGV4dDogXCJ0ZXh0LXNsYXRlLTYwMCBkYXJrOnRleHQtc2xhdGUtNDAwXCIsXHJcbiAgICBib3JkZXI6IFwiYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDBcIixcclxuICB9LFxyXG59O1xyXG5cclxuZXhwb3J0IGNvbnN0IERhc2hib2FyZFBhZ2U6IFJlYWN0LkZDID0gKCkgPT4ge1xyXG4gIGNvbnN0IHsgdXNlciB9ID0gdXNlQXV0aCgpO1xyXG4gIGNvbnN0IFthY3RpdmVUYWIsIHNldEFjdGl2ZVRhYl0gPSB1c2VTdGF0ZTxcImVzdGFiZWxlY2ltZW50b3NcIiB8IFwiaW5zcGVjb2VzXCIgfCBcInJlcXVlcmltZW50b3NcIiB8IFwiYWxlcnRhc1wiPihcclxuICAgIFwiZXN0YWJlbGVjaW1lbnRvc1wiXHJcbiAgKTtcclxuXHJcbiAgLy8gMS4gSW50ZWdyaWRhZGUgb3BlcmFjaW9uYWwgZSBjb25lY3RpdmlkYWRlIGRvIGJhbmNvXHJcbiAgY29uc3QgeyBkYXRhOiBoZWFsdGgsIGlzTG9hZGluZzogaGVhbHRoTG9hZGluZywgcmVmZXRjaDogcmVmZXRjaEhlYWx0aCB9ID0gdXNlUXVlcnk8SGVhbHRoRGF0YT4oe1xyXG4gICAgcXVlcnlLZXk6IFtcImhlYWx0aFwiXSxcclxuICAgIHF1ZXJ5Rm46IGFzeW5jICgpID0+IHtcclxuICAgICAgY29uc3QgcmVzID0gYXdhaXQgYXBpQ2xpZW50LmdldDxIZWFsdGhEYXRhPihcIi9oZWFsdGhcIik7XHJcbiAgICAgIHJldHVybiByZXMuZGF0YTtcclxuICAgIH0sXHJcbiAgICBzdGFsZVRpbWU6IDYwICogMTAwMCxcclxuICB9KTtcclxuXHJcbiAgLy8gMi4gSW5kaWNhZG9yZXMgZSBtZXRhcyBvZmljaWFpcyBkbyBleGVyY8OtY2lvXHJcbiAgY29uc3QgeyBkYXRhOiBkYXNoYm9hcmQsIGlzTG9hZGluZzogZGFzaGJvYXJkTG9hZGluZyB9ID0gdXNlRGFzaGJvYXJkSW5kaWNhZG9yZXMoXHJcbiAgICBBUFBfQ09ORklHLmFub0V4ZXJjaWNpb1BhZHJhb1xyXG4gICk7XHJcblxyXG4gIC8vIDMuIFJlZ2lzdHJvcyByZWFpcyBkbyBiYW5jbzogRXN0YWJlbGVjaW1lbnRvcyByZWNlbnRlc1xyXG4gIGNvbnN0IHtcclxuICAgIGRhdGE6IGVzdGFiZWxlY2ltZW50b3NEYXRhLFxyXG4gICAgaXNMb2FkaW5nOiBlc3RhYmVsZWNpbWVudG9zTG9hZGluZyxcclxuICAgIHJlZmV0Y2g6IHJlZmV0Y2hFc3RhYmVsZWNpbWVudG9zLFxyXG4gIH0gPSB1c2VFc3RhYmVsZWNpbWVudG9zTGlzdCh7IGxpbWl0OiA1IH0pO1xyXG5cclxuICAvLyA0LiBSZWdpc3Ryb3MgcmVhaXMgZG8gYmFuY286IEluc3Blw6fDtWVzIHJlY2VudGVzXHJcbiAgY29uc3Qge1xyXG4gICAgZGF0YTogaW5zcGVjb2VzID0gW10sXHJcbiAgICBpc0xvYWRpbmc6IGluc3BlY29lc0xvYWRpbmcsXHJcbiAgICByZWZldGNoOiByZWZldGNoSW5zcGVjb2VzLFxyXG4gIH0gPSB1c2VJbnNwZWNvZXNMaXN0KHsgbGltaXQ6IDUgfSk7XHJcblxyXG4gIC8vIDUuIFJlZ2lzdHJvcyByZWFpcyBkbyBiYW5jbzogUmVxdWVyaW1lbnRvcyBwZW5kZW50ZXNcclxuICBjb25zdCB7XHJcbiAgICBkYXRhOiByZXF1ZXJpbWVudG9zRGF0YSxcclxuICAgIGlzTG9hZGluZzogcmVxdWVyaW1lbnRvc0xvYWRpbmcsXHJcbiAgICByZWZldGNoOiByZWZldGNoUmVxdWVyaW1lbnRvcyxcclxuICB9ID0gdXNlUmVxdWVyaW1lbnRvc0xpc3QoeyBsaW1pdDogNSwgYXBlbmFzX2ZpbGE6IHRydWUgfSk7XHJcblxyXG4gIC8vIDYuIFJlZ2lzdHJvcyByZWFpcyBkbyBiYW5jbzogTm90aWZpY2HDp8O1ZXMgY29tIHByYXpvc1xyXG4gIGNvbnN0IHtcclxuICAgIGRhdGE6IG5vdGlmaWNhY29lc1BlbmRlbnRlcyA9IFtdLFxyXG4gICAgaXNMb2FkaW5nOiBub3RpZmljYWNvZXNMb2FkaW5nLFxyXG4gICAgcmVmZXRjaDogcmVmZXRjaE5vdGlmaWNhY29lcyxcclxuICB9ID0gdXNlTm90aWZpY2Fjb2VzUGVuZGVudGVzKDMwKTtcclxuXHJcbiAgY29uc3QgbGlzdGFFc3RhYmVsZWNpbWVudG9zID1cclxuICAgIGVzdGFiZWxlY2ltZW50b3NEYXRhPy5pdGVucyB8fFxyXG4gICAgKGVzdGFiZWxlY2ltZW50b3NEYXRhIGFzIHsgaXRlbXM/OiB0eXBlb2YgZXN0YWJlbGVjaW1lbnRvc0RhdGEgZXh0ZW5kcyB7IGl0ZW5zOiBpbmZlciBUIH0gPyBUIDogbmV2ZXIgfSB8IHVuZGVmaW5lZCk/Lml0ZW1zIHx8XHJcbiAgICBbXTtcclxuICBjb25zdCB0b3RhbEVzdGFiZWxlY2ltZW50b3MgPSBlc3RhYmVsZWNpbWVudG9zRGF0YT8udG90YWwgPz8gZGFzaGJvYXJkPy50b3RhbF9lc3RhYmVsZWNpbWVudG9zX2NhZGFzdHJhZG9zID8/IDA7XHJcbiAgY29uc3QgbGlzdGFSZXF1ZXJpbWVudG9zID0gcmVxdWVyaW1lbnRvc0RhdGE/Lml0ZW1zIHx8IFtdO1xyXG5cclxuICBjb25zdCBoYW5kbGVSZWNhcnJlZ2FyVHVkbyA9ICgpID0+IHtcclxuICAgIHJlZmV0Y2hIZWFsdGgoKTtcclxuICAgIHJlZmV0Y2hFc3RhYmVsZWNpbWVudG9zKCk7XHJcbiAgICByZWZldGNoSW5zcGVjb2VzKCk7XHJcbiAgICByZWZldGNoUmVxdWVyaW1lbnRvcygpO1xyXG4gICAgcmVmZXRjaE5vdGlmaWNhY29lcygpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGlzRGJPbmxpbmUgPSBoZWFsdGg/LmRhdGFiYXNlID09PSBcIm9ubGluZVwiIHx8IGhlYWx0aD8uc3RhdHVzID09PSBcImhlYWx0aHlcIjtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS02XCI+XHJcbiAgICAgIHsvKiBDYWJlw6dhbGhvIGRlIEJvYXMtVmluZGFzIGUgQ29uZXjDo28gKi99XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGFyazpiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtODAwIHJvdW5kZWQteGwgcC02IHNoYWRvdy14c1wiPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBzbTpmbGV4LXJvdyBzbTppdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC00XCI+XHJcbiAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC14bCBzbTp0ZXh0LTJ4bCBmb250LWJvbGQgdHJhY2tpbmctdGlnaHQgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlXCI+XHJcbiAgICAgICAgICAgICAgUGFpbmVsIE9wZXJhY2lvbmFsIMK3IHtBUFBfQ09ORklHLm11bmljaXBpb30ve0FQUF9DT05GSUcudWZ9XHJcbiAgICAgICAgICAgIDwvaDE+XHJcbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgc206dGV4dC1zbSB0ZXh0LXNsYXRlLTUwMCBkYXJrOnRleHQtc2xhdGUtNDAwIG10LTFcIj5cclxuICAgICAgICAgICAgICBPbMOhLCA8c3Ryb25nIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0yMDBcIj57dXNlcj8ubm9tZV9jb21wbGV0b308L3N0cm9uZz4gKHt1c2VyPy5jYXJnb30pLlxyXG4gICAgICAgICAgICAgIEFtYmllbnRlIGRlIG1vbml0b3JhbWVudG8gc2FuaXTDoXJpbyBlIGdlc3TDo28gcmVndWxhdMOzcmlhLlxyXG4gICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgIDxzcGFuXHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgcHgtMyBweS0xIHJvdW5kZWQtZnVsbCB0ZXh0LXhzIGZvbnQtbWVkaXVtIGJvcmRlciAke1xyXG4gICAgICAgICAgICAgICAgaXNEYk9ubGluZVxyXG4gICAgICAgICAgICAgICAgICA/IFwiYmctZW1lcmFsZC01MCBkYXJrOmJnLWVtZXJhbGQtOTUwLzQwIHRleHQtZW1lcmFsZC03MDAgZGFyazp0ZXh0LWVtZXJhbGQtMzAwIGJvcmRlci1lbWVyYWxkLTIwMCBkYXJrOmJvcmRlci1lbWVyYWxkLTgwMFwiXHJcbiAgICAgICAgICAgICAgICAgIDogaGVhbHRoTG9hZGluZ1xyXG4gICAgICAgICAgICAgICAgICA/IFwiYmctc2xhdGUtMTAwIHRleHQtc2xhdGUtNjAwIGJvcmRlci1zbGF0ZS0yMDBcIlxyXG4gICAgICAgICAgICAgICAgICA6IFwiYmctcm9zZS01MCB0ZXh0LXJvc2UtNzAwIGJvcmRlci1yb3NlLTIwMFwiXHJcbiAgICAgICAgICAgICAgfWB9XHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICA8c3BhblxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgdy0yIGgtMiByb3VuZGVkLWZ1bGwgJHtcclxuICAgICAgICAgICAgICAgICAgaXNEYk9ubGluZVxyXG4gICAgICAgICAgICAgICAgICAgID8gXCJiZy1lbWVyYWxkLTUwMCBhbmltYXRlLXB1bHNlXCJcclxuICAgICAgICAgICAgICAgICAgICA6IGhlYWx0aExvYWRpbmdcclxuICAgICAgICAgICAgICAgICAgICA/IFwiYmctc2xhdGUtNDAwXCJcclxuICAgICAgICAgICAgICAgICAgICA6IFwiYmctcm9zZS01MDBcIlxyXG4gICAgICAgICAgICAgICAgfWB9XHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICA8c3Bhbj5cclxuICAgICAgICAgICAgICAgIHtoZWFsdGhMb2FkaW5nXHJcbiAgICAgICAgICAgICAgICAgID8gXCJWZXJpZmljYW5kbyBDb25leMOjby4uLlwiXHJcbiAgICAgICAgICAgICAgICAgIDogaXNEYk9ubGluZVxyXG4gICAgICAgICAgICAgICAgICA/IFwiUG9zdGdyZVNRTCAmIEFQSSBDb25lY3RhZG9zXCJcclxuICAgICAgICAgICAgICAgICAgOiBcIkNvbmV4w6NvIERlZ3JhZGFkYSAvIE9mZmxpbmVcIn1cclxuICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgIDwvc3Bhbj5cclxuXHJcbiAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVSZWNhcnJlZ2FyVHVkb31cclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTEuNSB0ZXh0LXNsYXRlLTUwMCBob3Zlcjp0ZXh0LXNsYXRlLTgwMCBkYXJrOnRleHQtc2xhdGUtNDAwIGRhcms6aG92ZXI6dGV4dC13aGl0ZSBiZy1zbGF0ZS0xMDAgZGFyazpiZy1zbGF0ZS04MDAgcm91bmRlZC1sZyBob3ZlcjpiZy1zbGF0ZS0yMDAgdHJhbnNpdGlvbi1jb2xvcnNcIlxyXG4gICAgICAgICAgICAgIHRpdGxlPVwiUmVjYXJyZWdhciBEYWRvcyBPcGVyYWNpb25haXNcIlxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgPFJlZnJlc2hDdyBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz5cclxuICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICB7LyogR3JpZCBkZSBNw6l0cmljYXMgUHJpbmNpcGFpcyBDb25zb2xpZGFkYXMgKi99XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBzbTpncmlkLWNvbHMtMiBsZzpncmlkLWNvbHMtNCBnYXAtNFwiPlxyXG4gICAgICAgIHsvKiBDYXJkIDE6IEVzdGFiZWxlY2ltZW50b3Mgbm8gQmFuY28gKi99XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC14bCBwLTUgc2hhZG93LXhzXCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiB0ZXh0LXNsYXRlLTUwMCBkYXJrOnRleHQtc2xhdGUtNDAwIG1iLTJcIj5cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPlxyXG4gICAgICAgICAgICAgIEVzdGFiZWxlY2ltZW50b3MgQXRpdm9zXHJcbiAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgPEJ1aWxkaW5nMiBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtdGVhbC02MDAgZGFyazp0ZXh0LXRlYWwtNDAwXCIgLz5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGQgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlIHRhYnVsYXItbnVtc1wiPlxyXG4gICAgICAgICAgICB7ZXN0YWJlbGVjaW1lbnRvc0xvYWRpbmcgPyAoXHJcbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW5vcm1hbCB0ZXh0LXNsYXRlLTQwMCBhbmltYXRlLXB1bHNlXCI+Q2FycmVnYW5kby4uLjwvc3Bhbj5cclxuICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICB0b3RhbEVzdGFiZWxlY2ltZW50b3NcclxuICAgICAgICAgICAgKX1cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTUwMCBkYXJrOnRleHQtc2xhdGUtNDAwIG10LTFcIj5cclxuICAgICAgICAgICAgQ2FkYXN0cm9zIGVjb27DtG1pY29zIHJlZ3VsYWRvcyBwZWxhIFZJU0FcclxuICAgICAgICAgIDwvcD5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgey8qIENhcmQgMjogVmlzdG9yaWFzIFJlYWxpemFkYXMgbm8gRXhlcmPDrWNpbyAqL31cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIGRhcms6Ymctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLXhsIHAtNSBzaGFkb3cteHNcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHRleHQtc2xhdGUtNTAwIGRhcms6dGV4dC1zbGF0ZS00MDAgbWItMlwiPlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCI+XHJcbiAgICAgICAgICAgICAgVmlzdG9yaWFzIG5vIEV4ZXJjw61jaW9cclxuICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICA8Q2xpcGJvYXJkQ2hlY2sgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LXB1cnBsZS02MDAgZGFyazp0ZXh0LXB1cnBsZS00MDBcIiAvPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGUgdGFidWxhci1udW1zXCI+XHJcbiAgICAgICAgICAgIHtkYXNoYm9hcmRMb2FkaW5nID8gKFxyXG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1ub3JtYWwgdGV4dC1zbGF0ZS00MDAgYW5pbWF0ZS1wdWxzZVwiPkNhcnJlZ2FuZG8uLi48L3NwYW4+XHJcbiAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgZGFzaGJvYXJkPy50b3RhbF9pbnNwZWNvZXNfZXhlcmNpY2lvID8/IGluc3BlY29lcy5sZW5ndGhcclxuICAgICAgICAgICAgKX1cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTUwMCBkYXJrOnRleHQtc2xhdGUtNDAwIG10LTFcIj5cclxuICAgICAgICAgICAgSW5zcGXDp8O1ZXMgc2FuaXTDoXJpYXMgZSBmaXNjYWxpemHDp8O1ZXMgY29uY2x1w61kYXNcclxuICAgICAgICAgIDwvcD5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgey8qIENhcmQgMzogQWx2YXLDoXMgU2FuaXTDoXJpb3MgQXRpdm9zICovfVxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGFyazpiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtODAwIHJvdW5kZWQteGwgcC01IHNoYWRvdy14c1wiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gdGV4dC1zbGF0ZS01MDAgZGFyazp0ZXh0LXNsYXRlLTQwMCBtYi0yXCI+XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1zZW1pYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXJcIj5cclxuICAgICAgICAgICAgICBBbHZhcsOhcyBWaWdlbnRlc1xyXG4gICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgIDxGaWxlQ2hlY2sgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LWJsdWUtNjAwIGRhcms6dGV4dC1ibHVlLTQwMFwiIC8+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZSB0YWJ1bGFyLW51bXNcIj5cclxuICAgICAgICAgICAge2Rhc2hib2FyZExvYWRpbmcgPyAoXHJcbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW5vcm1hbCB0ZXh0LXNsYXRlLTQwMCBhbmltYXRlLXB1bHNlXCI+Q2FycmVnYW5kby4uLjwvc3Bhbj5cclxuICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICBkYXNoYm9hcmQ/LnRvdGFsX2FsdmFyYXNfYXRpdm9zID8/IDBcclxuICAgICAgICAgICAgKX1cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTUwMCBkYXJrOnRleHQtc2xhdGUtNDAwIG10LTFcIj5cclxuICAgICAgICAgICAgTGljZW7Dp2FzIHNhbml0w6FyaWFzIGV4cGVkaWRhcyBjb20gUVIgQ29kZVxyXG4gICAgICAgICAgPC9wPlxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICB7LyogQ2FyZCA0OiBOb3RpZmljYcOnw7VlcyBjb20gUHJhem8gKi99XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC14bCBwLTUgc2hhZG93LXhzXCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiB0ZXh0LXNsYXRlLTUwMCBkYXJrOnRleHQtc2xhdGUtNDAwIG1iLTJcIj5cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPlxyXG4gICAgICAgICAgICAgIE5vdGlmaWNhw6fDtWVzIFBlbmRlbnRlc1xyXG4gICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgIDxBbGVydENpcmNsZSBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtYW1iZXItNjAwIGRhcms6dGV4dC1hbWJlci00MDBcIiAvPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGUgdGFidWxhci1udW1zXCI+XHJcbiAgICAgICAgICAgIHtub3RpZmljYWNvZXNMb2FkaW5nID8gKFxyXG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1ub3JtYWwgdGV4dC1zbGF0ZS00MDAgYW5pbWF0ZS1wdWxzZVwiPkNhcnJlZ2FuZG8uLi48L3NwYW4+XHJcbiAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgbm90aWZpY2Fjb2VzUGVuZGVudGVzLmxlbmd0aFxyXG4gICAgICAgICAgICApfVxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNTAwIGRhcms6dGV4dC1zbGF0ZS00MDAgbXQtMVwiPlxyXG4gICAgICAgICAgICBUZXJtb3MgY29tIGNvbnRhZ2VtIHJlZ3Jlc3NpdmEgZGUgYWRlcXVhw6fDo29cclxuICAgICAgICAgIDwvcD5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICB7LyogU2XDp8OjbyBPcGVyYWNpb25hbCBjb20gRGFkb3MgZG8gQmFuY28gZGUgRGFkb3MgKi99XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGFyazpiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtODAwIHJvdW5kZWQteGwgc2hhZG93LXhzIG92ZXJmbG93LWhpZGRlblwiPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC01IGJvcmRlci1iIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtODAwIGZsZXggZmxleC1jb2wgc206ZmxleC1yb3cgc206aXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtNFwiPlxyXG4gICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtYmFzZSBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgIDxzcGFuPlJlZ2lzdHJvcyBPcGVyYWNpb25haXMgZG8gQmFuY28gZGUgRGFkb3M8L3NwYW4+XHJcbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LW5vcm1hbCB0ZXh0LXNsYXRlLTUwMCBkYXJrOnRleHQtc2xhdGUtNDAwXCI+XHJcbiAgICAgICAgICAgICAgICAoQ29uc3VsdGFzIGVtIHRlbXBvIHJlYWwpXHJcbiAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICA8L2gyPlxyXG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNTAwIGRhcms6dGV4dC1zbGF0ZS00MDAgbXQtMC41XCI+XHJcbiAgICAgICAgICAgICAgQWNvbXBhbmhlIGFzIMO6bHRpbWFzIG1vdmltZW50YcOnw7VlcyBjYWRhc3RyYWRhcyBubyBzaXN0ZW1hLlxyXG4gICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICB7LyogQWJhcyBSw6FwaWRhcyAqL31cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgYmctc2xhdGUtMTAwIGRhcms6Ymctc2xhdGUtODAwLzgwIHAtMSByb3VuZGVkLWxnXCI+XHJcbiAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRBY3RpdmVUYWIoXCJlc3RhYmVsZWNpbWVudG9zXCIpfVxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT17YHB4LTMgcHktMS41IHJvdW5kZWQtbWQgdGV4dC14cyBmb250LW1lZGl1bSB0cmFuc2l0aW9uLWNvbG9ycyAke1xyXG4gICAgICAgICAgICAgICAgYWN0aXZlVGFiID09PSBcImVzdGFiZWxlY2ltZW50b3NcIlxyXG4gICAgICAgICAgICAgICAgICA/IFwiYmctd2hpdGUgZGFyazpiZy1zbGF0ZS05MDAgdGV4dC10ZWFsLTYwMCBkYXJrOnRleHQtdGVhbC00MDAgc2hhZG93LXhzXCJcclxuICAgICAgICAgICAgICAgICAgOiBcInRleHQtc2xhdGUtNjAwIGRhcms6dGV4dC1zbGF0ZS00MDAgaG92ZXI6dGV4dC1zbGF0ZS05MDAgZGFyazpob3Zlcjp0ZXh0LXdoaXRlXCJcclxuICAgICAgICAgICAgICB9YH1cclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIEVzdGFiZWxlY2ltZW50b3MgKHt0b3RhbEVzdGFiZWxlY2ltZW50b3N9KVxyXG4gICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEFjdGl2ZVRhYihcImluc3BlY29lc1wiKX1cclxuICAgICAgICAgICAgICBjbGFzc05hbWU9e2BweC0zIHB5LTEuNSByb3VuZGVkLW1kIHRleHQteHMgZm9udC1tZWRpdW0gdHJhbnNpdGlvbi1jb2xvcnMgJHtcclxuICAgICAgICAgICAgICAgIGFjdGl2ZVRhYiA9PT0gXCJpbnNwZWNvZXNcIlxyXG4gICAgICAgICAgICAgICAgICA/IFwiYmctd2hpdGUgZGFyazpiZy1zbGF0ZS05MDAgdGV4dC10ZWFsLTYwMCBkYXJrOnRleHQtdGVhbC00MDAgc2hhZG93LXhzXCJcclxuICAgICAgICAgICAgICAgICAgOiBcInRleHQtc2xhdGUtNjAwIGRhcms6dGV4dC1zbGF0ZS00MDAgaG92ZXI6dGV4dC1zbGF0ZS05MDAgZGFyazpob3Zlcjp0ZXh0LXdoaXRlXCJcclxuICAgICAgICAgICAgICB9YH1cclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIEluc3Blw6fDtWVzICh7aW5zcGVjb2VzLmxlbmd0aH0pXHJcbiAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0QWN0aXZlVGFiKFwicmVxdWVyaW1lbnRvc1wiKX1cclxuICAgICAgICAgICAgICBjbGFzc05hbWU9e2BweC0zIHB5LTEuNSByb3VuZGVkLW1kIHRleHQteHMgZm9udC1tZWRpdW0gdHJhbnNpdGlvbi1jb2xvcnMgJHtcclxuICAgICAgICAgICAgICAgIGFjdGl2ZVRhYiA9PT0gXCJyZXF1ZXJpbWVudG9zXCJcclxuICAgICAgICAgICAgICAgICAgPyBcImJnLXdoaXRlIGRhcms6Ymctc2xhdGUtOTAwIHRleHQtdGVhbC02MDAgZGFyazp0ZXh0LXRlYWwtNDAwIHNoYWRvdy14c1wiXHJcbiAgICAgICAgICAgICAgICAgIDogXCJ0ZXh0LXNsYXRlLTYwMCBkYXJrOnRleHQtc2xhdGUtNDAwIGhvdmVyOnRleHQtc2xhdGUtOTAwIGRhcms6aG92ZXI6dGV4dC13aGl0ZVwiXHJcbiAgICAgICAgICAgICAgfWB9XHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICBGaWxhIGRlIEFsdmFyw6FzICh7bGlzdGFSZXF1ZXJpbWVudG9zLmxlbmd0aH0pXHJcbiAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0QWN0aXZlVGFiKFwiYWxlcnRhc1wiKX1cclxuICAgICAgICAgICAgICBjbGFzc05hbWU9e2BweC0zIHB5LTEuNSByb3VuZGVkLW1kIHRleHQteHMgZm9udC1tZWRpdW0gdHJhbnNpdGlvbi1jb2xvcnMgJHtcclxuICAgICAgICAgICAgICAgIGFjdGl2ZVRhYiA9PT0gXCJhbGVydGFzXCJcclxuICAgICAgICAgICAgICAgICAgPyBcImJnLXdoaXRlIGRhcms6Ymctc2xhdGUtOTAwIHRleHQtdGVhbC02MDAgZGFyazp0ZXh0LXRlYWwtNDAwIHNoYWRvdy14c1wiXHJcbiAgICAgICAgICAgICAgICAgIDogXCJ0ZXh0LXNsYXRlLTYwMCBkYXJrOnRleHQtc2xhdGUtNDAwIGhvdmVyOnRleHQtc2xhdGUtOTAwIGRhcms6aG92ZXI6dGV4dC13aGl0ZVwiXHJcbiAgICAgICAgICAgICAgfWB9XHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICBBbGVydGFzICh7bm90aWZpY2Fjb2VzUGVuZGVudGVzLmxlbmd0aH0pXHJcbiAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIHsvKiBDb250ZcO6ZG8gZGEgQWJhIEF0aXZhICovfVxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC01XCI+XHJcbiAgICAgICAgICB7LyogVEFCIDE6IEVzdGFiZWxlY2ltZW50b3MgKi99XHJcbiAgICAgICAgICB7YWN0aXZlVGFiID09PSBcImVzdGFiZWxlY2ltZW50b3NcIiAmJiAoXHJcbiAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAge2VzdGFiZWxlY2ltZW50b3NMb2FkaW5nID8gKFxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweS0xMiB0ZXh0LWNlbnRlciB0ZXh0LXNtIHRleHQtc2xhdGUtNTAwIGFuaW1hdGUtcHVsc2VcIj5cclxuICAgICAgICAgICAgICAgICAgQ29uc3VsdGFuZG8gZXN0YWJlbGVjaW1lbnRvcyBubyBiYW5jbyBkZSBkYWRvcy4uLlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgKSA6IGxpc3RhRXN0YWJlbGVjaW1lbnRvcy5sZW5ndGggPT09IDAgPyAoXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB5LTEyIHRleHQtY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxCdWlsZGluZzIgY2xhc3NOYW1lPVwidy0xMCBoLTEwIHRleHQtc2xhdGUtMzAwIGRhcms6dGV4dC1zbGF0ZS02MDAgbXgtYXV0byBtYi0zXCIgLz5cclxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0zMDBcIj5cclxuICAgICAgICAgICAgICAgICAgICBOZW5odW0gZXN0YWJlbGVjaW1lbnRvIGNhZGFzdHJhZG8gbm8gYmFuY28gZGUgZGFkb3MuXHJcbiAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTUwMCBtdC0xIG1heC13LW1kIG14LWF1dG9cIj5cclxuICAgICAgICAgICAgICAgICAgICBDYWRhc3RyZSBvIHByaW1laXJvIGVzdGFiZWxlY2ltZW50byByZWd1bGFkbyBvdSBleGVjdXRlIGEgY2FyZ2EgaW5pY2lhbCBwYXJhIGluaWNpYXIgbyBtb25pdG9yYW1lbnRvIHNhbml0w6FyaW8uXHJcbiAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgPExpbmtcclxuICAgICAgICAgICAgICAgICAgICB0bz17Uk9VVEVTLkVTVEFCRUxFQ0lNRU5UT1MuTk9WT31cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgbXQtNCBweC0zLjUgcHktMiByb3VuZGVkLWxnIGJnLXRlYWwtNjAwIHRleHQtd2hpdGUgdGV4dC14cyBmb250LXNlbWlib2xkIGhvdmVyOmJnLXRlYWwtNzAwIHRyYW5zaXRpb24tY29sb3JzXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIDxQbHVzQ2lyY2xlIGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuPkNhZGFzdHJhciBFc3RhYmVsZWNpbWVudG88L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm92ZXJmbG93LXgtYXV0b1wiPlxyXG4gICAgICAgICAgICAgICAgICA8dGFibGUgY2xhc3NOYW1lPVwidy1mdWxsIHRleHQtbGVmdCBib3JkZXItY29sbGFwc2UgdGV4dC14c1wiPlxyXG4gICAgICAgICAgICAgICAgICAgIDx0aGVhZD5cclxuICAgICAgICAgICAgICAgICAgICAgIDx0ciBjbGFzc05hbWU9XCJib3JkZXItYiBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCB0ZXh0LXNsYXRlLTUwMCBkYXJrOnRleHQtc2xhdGUtNDAwIGZvbnQtc2VtaWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0zIHB4LTNcIj5SYXrDo28gU29jaWFsIC8gRmFudGFzaWE8L3RoPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMyBweC0zXCI+Q05QSiAvIENQRjwvdGg+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0zIHB4LTNcIj5HcmF1IGRlIFJpc2NvPC90aD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB5LTMgcHgtM1wiPlNpdHVhw6fDo28gZG8gQWx2YXLDoTwvdGg+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0zIHB4LTMgdGV4dC1yaWdodFwiPkHDp8OjbzwvdGg+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvdGhlYWQ+XHJcbiAgICAgICAgICAgICAgICAgICAgPHRib2R5IGNsYXNzTmFtZT1cImRpdmlkZS15IGRpdmlkZS1zbGF0ZS0xMDAgZGFyazpkaXZpZGUtc2xhdGUtODAwIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0zMDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtsaXN0YUVzdGFiZWxlY2ltZW50b3MubWFwKChlc3QpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPHRyIGtleT17ZXN0LmlkfSBjbGFzc05hbWU9XCJob3ZlcjpiZy1zbGF0ZS01MC84MCBkYXJrOmhvdmVyOmJnLXNsYXRlLTgwMC80MCB0cmFuc2l0aW9uLWNvbG9yc1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS0zIHB4LTMgZm9udC1tZWRpdW0gdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2Pntlc3QucmF6YW9fc29jaWFsfTwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2VzdC5ub21lX2ZhbnRhc2lhICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LXNsYXRlLTUwMCBkYXJrOnRleHQtc2xhdGUtNDAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2VzdC5ub21lX2ZhbnRhc2lhfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMyBweC0zIGZvbnQtbW9ubyB0ZXh0LXNsYXRlLTYwMCBkYXJrOnRleHQtc2xhdGUtNDAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Zm9ybWF0Q3BmQ25waihlc3QuY25wal9jcGYpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTMgcHgtM1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPFJpc2NvQmFkZ2UgcmlzY289e2VzdC5uaXZlbF9yaXNjb30gc2l6ZT1cInNtXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS0zIHB4LTNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxTaXR1YWNhb0FsdmFyYUJhZGdlIHNpdHVhY2FvPXtlc3Quc2l0dWFjYW9fYWx2YXJhfSBzaXplPVwic21cIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTMgcHgtMyB0ZXh0LXJpZ2h0XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8TGlua1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0bz17Uk9VVEVTLkVTVEFCRUxFQ0lNRU5UT1MuREVUQUxIRShlc3QuaWQpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgcHgtMi41IHB5LTEgdGV4dC1bMTFweF0gZm9udC1tZWRpdW0gdGV4dC10ZWFsLTYwMCBob3Zlcjp0ZXh0LXRlYWwtNzAwIGJnLXRlYWwtNTAgZGFyazpiZy10ZWFsLTk1MC80MCBkYXJrOnRleHQtdGVhbC0zMDAgcm91bmRlZC1tZCBob3ZlcjpiZy10ZWFsLTEwMCB0cmFuc2l0aW9uLWNvbG9yc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxFeWUgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5GaWNoYTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxyXG4gICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC90Ym9keT5cclxuICAgICAgICAgICAgICAgICAgPC90YWJsZT5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC00IHB0LTMgYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTEwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyIHRleHQteHMgdGV4dC1zbGF0ZS01MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICA8c3Bhbj5Nb3N0cmFuZG8ge2xpc3RhRXN0YWJlbGVjaW1lbnRvcy5sZW5ndGh9IGRlIHt0b3RhbEVzdGFiZWxlY2ltZW50b3N9IHJlZ2lzdHJvczwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8TGlua1xyXG4gICAgICAgICAgICAgICAgICAgICAgdG89e1JPVVRFUy5FU1RBQkVMRUNJTUVOVE9TLkxJU1R9XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmb250LW1lZGl1bSB0ZXh0LXRlYWwtNjAwIGRhcms6dGV4dC10ZWFsLTQwMCBob3Zlcjp1bmRlcmxpbmUgaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0xXCJcclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5WZXIgdG9kb3Mgb3MgZXN0YWJlbGVjaW1lbnRvczwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxDaGV2cm9uUmlnaHQgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgey8qIFRBQiAyOiBJbnNwZcOnw7VlcyAqL31cclxuICAgICAgICAgIHthY3RpdmVUYWIgPT09IFwiaW5zcGVjb2VzXCIgJiYgKFxyXG4gICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgIHtpbnNwZWNvZXNMb2FkaW5nID8gKFxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweS0xMiB0ZXh0LWNlbnRlciB0ZXh0LXNtIHRleHQtc2xhdGUtNTAwIGFuaW1hdGUtcHVsc2VcIj5cclxuICAgICAgICAgICAgICAgICAgQ29uc3VsdGFuZG8gZmlzY2FsaXphw6fDtWVzIG5vIGJhbmNvIGRlIGRhZG9zLi4uXHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICApIDogaW5zcGVjb2VzLmxlbmd0aCA9PT0gMCA/IChcclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHktMTIgdGV4dC1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgPENsaXBib2FyZENoZWNrIGNsYXNzTmFtZT1cInctMTAgaC0xMCB0ZXh0LXNsYXRlLTMwMCBkYXJrOnRleHQtc2xhdGUtNjAwIG14LWF1dG8gbWItM1wiIC8+XHJcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgTmVuaHVtYSBpbnNwZcOnw6NvIHJlZ2lzdHJhZGEgbm8gYmFuY28gZGUgZGFkb3MuXHJcbiAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTUwMCBtdC0xIG1heC13LW1kIG14LWF1dG9cIj5cclxuICAgICAgICAgICAgICAgICAgICBBZ2VuZGUgdW1hIHZpc3RvcmlhIGRlIHJvdGluYSwgYW7DoWxpc2UgZGUgYWx2YXLDoSBvdSBhw6fDo28gVkFQVCBkZSBzYcO6ZGUgZG8gdHJhYmFsaGFkb3IuXHJcbiAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgPExpbmtcclxuICAgICAgICAgICAgICAgICAgICB0bz17Uk9VVEVTLklOU1BFQ09FUy5MSVNUfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBtdC00IHB4LTMuNSBweS0yIHJvdW5kZWQtbGcgYmctdGVhbC02MDAgdGV4dC13aGl0ZSB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgaG92ZXI6YmctdGVhbC03MDAgdHJhbnNpdGlvbi1jb2xvcnNcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgPFBsdXNDaXJjbGUgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4+QWNlc3NhciBNw7NkdWxvIGRlIEZpc2NhbGl6YcOnw6NvPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJvdmVyZmxvdy14LWF1dG9cIj5cclxuICAgICAgICAgICAgICAgICAgPHRhYmxlIGNsYXNzTmFtZT1cInctZnVsbCB0ZXh0LWxlZnQgYm9yZGVyLWNvbGxhcHNlIHRleHQteHNcIj5cclxuICAgICAgICAgICAgICAgICAgICA8dGhlYWQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8dHIgY2xhc3NOYW1lPVwiYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgdGV4dC1zbGF0ZS01MDAgZGFyazp0ZXh0LXNsYXRlLTQwMCBmb250LXNlbWlib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMyBweC0zXCI+VGVybW8gLyBOb3RpZmljYcOnw6NvPC90aD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB5LTMgcHgtM1wiPk1vdGl2byBkYSBBw6fDo288L3RoPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMyBweC0zXCI+U3RhdHVzPC90aD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB5LTMgcHgtM1wiPkRhdGEgSW7DrWNpbzwvdGg+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0zIHB4LTMgdGV4dC1yaWdodFwiPkHDp8OjbzwvdGg+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvdGhlYWQ+XHJcbiAgICAgICAgICAgICAgICAgICAgPHRib2R5IGNsYXNzTmFtZT1cImRpdmlkZS15IGRpdmlkZS1zbGF0ZS0xMDAgZGFyazpkaXZpZGUtc2xhdGUtODAwIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0zMDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtpbnNwZWNvZXMubWFwKChpbnNwKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHN0YXR1c0NvbmZpZyA9IFNUQVRVU19JTlNQRUNBT19CQURHRVNbaW5zcC5zdGF0dXNdIHx8IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbDogaW5zcC5zdGF0dXMsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgYmc6IFwiYmctc2xhdGUtMTAwXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdGV4dDogXCJ0ZXh0LXNsYXRlLTcwMFwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGJvcmRlcjogXCJib3JkZXItc2xhdGUtMjAwXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH07XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDx0ciBrZXk9e2luc3AuaWR9IGNsYXNzTmFtZT1cImhvdmVyOmJnLXNsYXRlLTUwLzgwIGRhcms6aG92ZXI6Ymctc2xhdGUtODAwLzQwIHRyYW5zaXRpb24tY29sb3JzXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMyBweC0zIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpbnNwLm51bWVyb190ZXJtb31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMyBweC0zIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0zMDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge01PVElWT19MQUJFTFNbaW5zcC5tb3Rpdm9dIHx8IGluc3AubW90aXZvfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS0zIHB4LTNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgcHgtMiBweS0wLjUgcm91bmRlZC1tZCBib3JkZXIgdGV4dC1bMTFweF0gZm9udC1tZWRpdW0gJHtzdGF0dXNDb25maWcuYmd9ICR7c3RhdHVzQ29uZmlnLnRleHR9ICR7c3RhdHVzQ29uZmlnLmJvcmRlcn1gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3N0YXR1c0NvbmZpZy5sYWJlbH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS0zIHB4LTMgdGV4dC1zbGF0ZS02MDAgZGFyazp0ZXh0LXNsYXRlLTQwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Zm9ybWF0RGF0YShpbnNwLmRhdGFfaW5pY2lvKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMyBweC0zIHRleHQtcmlnaHRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPExpbmtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0bz17Uk9VVEVTLklOU1BFQ09FUy5MQVVETyhpbnNwLmlkKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgcHgtMi41IHB5LTEgdGV4dC1bMTFweF0gZm9udC1tZWRpdW0gdGV4dC10ZWFsLTYwMCBob3Zlcjp0ZXh0LXRlYWwtNzAwIGJnLXRlYWwtNTAgZGFyazpiZy10ZWFsLTk1MC80MCBkYXJrOnRleHQtdGVhbC0zMDAgcm91bmRlZC1tZCBob3ZlcjpiZy10ZWFsLTEwMCB0cmFuc2l0aW9uLWNvbG9yc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RXllIGNsYXNzTmFtZT1cInctMy41IGgtMy41XCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5MYXVkbzwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApO1xyXG4gICAgICAgICAgICAgICAgICAgICAgfSl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC90Ym9keT5cclxuICAgICAgICAgICAgICAgICAgPC90YWJsZT5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC00IHB0LTMgYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTEwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyIHRleHQteHMgdGV4dC1zbGF0ZS01MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICA8c3Bhbj5Nb3N0cmFuZG8ge2luc3BlY29lcy5sZW5ndGh9IGluc3Blw6fDtWVzIHJlY2VudGVzPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDxMaW5rXHJcbiAgICAgICAgICAgICAgICAgICAgICB0bz17Uk9VVEVTLklOU1BFQ09FUy5MSVNUfVxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZm9udC1tZWRpdW0gdGV4dC10ZWFsLTYwMCBkYXJrOnRleHQtdGVhbC00MDAgaG92ZXI6dW5kZXJsaW5lIGlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMVwiXHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4+VmVyIHRvZGFzIGFzIGZpc2NhbGl6YcOnw7Vlczwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxDaGV2cm9uUmlnaHQgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgey8qIFRBQiAzOiBSZXF1ZXJpbWVudG9zICovfVxyXG4gICAgICAgICAge2FjdGl2ZVRhYiA9PT0gXCJyZXF1ZXJpbWVudG9zXCIgJiYgKFxyXG4gICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgIHtyZXF1ZXJpbWVudG9zTG9hZGluZyA/IChcclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHktMTIgdGV4dC1jZW50ZXIgdGV4dC1zbSB0ZXh0LXNsYXRlLTUwMCBhbmltYXRlLXB1bHNlXCI+XHJcbiAgICAgICAgICAgICAgICAgIENvbnN1bHRhbmRvIHJlcXVlcmltZW50b3MgZGUgYWx2YXLDoSBubyBiYW5jbyBkZSBkYWRvcy4uLlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgKSA6IGxpc3RhUmVxdWVyaW1lbnRvcy5sZW5ndGggPT09IDAgPyAoXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB5LTEyIHRleHQtY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxGaWxlQ2hlY2sgY2xhc3NOYW1lPVwidy0xMCBoLTEwIHRleHQtc2xhdGUtMzAwIGRhcms6dGV4dC1zbGF0ZS02MDAgbXgtYXV0byBtYi0zXCIgLz5cclxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0zMDBcIj5cclxuICAgICAgICAgICAgICAgICAgICBOZW5odW0gcmVxdWVyaW1lbnRvIGRlIGFsdmFyw6EgcGVuZGVudGUgbmEgZmlsYS5cclxuICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNTAwIG10LTEgbWF4LXctbWQgbXgtYXV0b1wiPlxyXG4gICAgICAgICAgICAgICAgICAgIEEgZmlsYSBkZSBzb2xpY2l0YcOnw7VlcyBlIHByb3RvY29sb3Mgc2FuaXTDoXJpb3MgZXN0w6EgbGltcGEgbm8gbW9tZW50by5cclxuICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICA8TGlua1xyXG4gICAgICAgICAgICAgICAgICAgIHRvPXtST1VURVMuTElDRU5DSUFNRU5UTy5MSVNUfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBtdC00IHB4LTMuNSBweS0yIHJvdW5kZWQtbGcgYmctdGVhbC02MDAgdGV4dC13aGl0ZSB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgaG92ZXI6YmctdGVhbC03MDAgdHJhbnNpdGlvbi1jb2xvcnNcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4+QWJyaXIgRmlsYSBkZSBMaWNlbmNpYW1lbnRvPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJvdmVyZmxvdy14LWF1dG9cIj5cclxuICAgICAgICAgICAgICAgICAgPHRhYmxlIGNsYXNzTmFtZT1cInctZnVsbCB0ZXh0LWxlZnQgYm9yZGVyLWNvbGxhcHNlIHRleHQteHNcIj5cclxuICAgICAgICAgICAgICAgICAgICA8dGhlYWQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8dHIgY2xhc3NOYW1lPVwiYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgdGV4dC1zbGF0ZS01MDAgZGFyazp0ZXh0LXNsYXRlLTQwMCBmb250LXNlbWlib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMyBweC0zXCI+UHJvdG9jb2xvPC90aD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB5LTMgcHgtM1wiPlJhesOjbyBTb2NpYWwgLyBTb2xpY2l0YW50ZTwvdGg+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0zIHB4LTNcIj5UaXBvIGRlIFNvbGljaXRhw6fDo288L3RoPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMyBweC0zXCI+U3RhdHVzPC90aD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB5LTMgcHgtM1wiPkRhdGE8L3RoPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMyBweC0zIHRleHQtcmlnaHRcIj5Bw6fDo288L3RoPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC90cj5cclxuICAgICAgICAgICAgICAgICAgICA8L3RoZWFkPlxyXG4gICAgICAgICAgICAgICAgICAgIDx0Ym9keSBjbGFzc05hbWU9XCJkaXZpZGUteSBkaXZpZGUtc2xhdGUtMTAwIGRhcms6ZGl2aWRlLXNsYXRlLTgwMCB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7bGlzdGFSZXF1ZXJpbWVudG9zLm1hcCgocmVxKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHN0YXR1c0NvbmZpZyA9IFNUQVRVU19SRVFVRVJJTUVOVE9fQkFER0VTW3JlcS5zdGF0dXNdIHx8IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbDogcmVxLnN0YXR1cyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBiZzogXCJiZy1zbGF0ZS0xMDBcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB0ZXh0OiBcInRleHQtc2xhdGUtNzAwXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgYm9yZGVyOiBcImJvcmRlci1zbGF0ZS0yMDBcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgfTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHRyIGtleT17cmVxLmlkfSBjbGFzc05hbWU9XCJob3ZlcjpiZy1zbGF0ZS01MC84MCBkYXJrOmhvdmVyOmJnLXNsYXRlLTgwMC80MCB0cmFuc2l0aW9uLWNvbG9yc1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTMgcHgtMyBmb250LXNlbWlib2xkIGZvbnQtbW9ubyB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3JlcS5udW1lcm9fcHJvdG9jb2xvfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS0zIHB4LTMgdGV4dC1zbGF0ZS04MDAgZGFyazp0ZXh0LXNsYXRlLTIwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cmVxLmRhZG9zX2RlY2xhcmFkb3M/LnJhemFvX3NvY2lhbCB8fCBcIkVzdGFiZWxlY2ltZW50byBWaW5jdWxhZG9cIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMyBweC0zIGNhcGl0YWxpemUgdGV4dC1zbGF0ZS02MDAgZGFyazp0ZXh0LXNsYXRlLTQwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cmVxLnRpcG9fc29saWNpdGFjYW8ucmVwbGFjZShcIl9cIiwgXCIgXCIpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS0zIHB4LTNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgcHgtMiBweS0wLjUgcm91bmRlZC1tZCBib3JkZXIgdGV4dC1bMTFweF0gZm9udC1tZWRpdW0gJHtzdGF0dXNDb25maWcuYmd9ICR7c3RhdHVzQ29uZmlnLnRleHR9ICR7c3RhdHVzQ29uZmlnLmJvcmRlcn1gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3N0YXR1c0NvbmZpZy5sYWJlbH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS0zIHB4LTMgdGV4dC1zbGF0ZS02MDAgZGFyazp0ZXh0LXNsYXRlLTQwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Zm9ybWF0RGF0YShyZXEuZGF0YV9zdWJtaXNzYW8pfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS0zIHB4LTMgdGV4dC1yaWdodFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8TGlua1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvPXtST1VURVMuTElDRU5DSUFNRU5UTy5SRVFVRVJJTUVOVE9fREVUQUxIRShyZXEuaWQpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMSBweC0yLjUgcHktMSB0ZXh0LVsxMXB4XSBmb250LW1lZGl1bSB0ZXh0LXRlYWwtNjAwIGhvdmVyOnRleHQtdGVhbC03MDAgYmctdGVhbC01MCBkYXJrOmJnLXRlYWwtOTUwLzQwIGRhcms6dGV4dC10ZWFsLTMwMCByb3VuZGVkLW1kIGhvdmVyOmJnLXRlYWwtMTAwIHRyYW5zaXRpb24tY29sb3JzXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxFeWUgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPkFuw6FsaXNlPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvdHI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgICAgICAgICAgICB9KX1cclxuICAgICAgICAgICAgICAgICAgICA8L3Rib2R5PlxyXG4gICAgICAgICAgICAgICAgICA8L3RhYmxlPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTQgcHQtMyBib3JkZXItdCBib3JkZXItc2xhdGUtMTAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCBmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXIgdGV4dC14cyB0ZXh0LXNsYXRlLTUwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuPk1vc3RyYW5kbyB7bGlzdGFSZXF1ZXJpbWVudG9zLmxlbmd0aH0gcHJvY2Vzc29zIG5hIGZpbGE8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPExpbmtcclxuICAgICAgICAgICAgICAgICAgICAgIHRvPXtST1VURVMuTElDRU5DSUFNRU5UTy5MSVNUfVxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZm9udC1tZWRpdW0gdGV4dC10ZWFsLTYwMCBkYXJrOnRleHQtdGVhbC00MDAgaG92ZXI6dW5kZXJsaW5lIGlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMVwiXHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4+VmVyIGZpbGEgY29tcGxldGE8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8Q2hldnJvblJpZ2h0IGNsYXNzTmFtZT1cInctMy41IGgtMy41XCIgLz5cclxuICAgICAgICAgICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgIHsvKiBUQUIgNDogQWxlcnRhcyBlIFByYXpvcyAqL31cclxuICAgICAgICAgIHthY3RpdmVUYWIgPT09IFwiYWxlcnRhc1wiICYmIChcclxuICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICB7bm90aWZpY2Fjb2VzTG9hZGluZyA/IChcclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHktMTIgdGV4dC1jZW50ZXIgdGV4dC1zbSB0ZXh0LXNsYXRlLTUwMCBhbmltYXRlLXB1bHNlXCI+XHJcbiAgICAgICAgICAgICAgICAgIENvbnN1bHRhbmRvIG5vdGlmaWNhw6fDtWVzIHNhbml0w6FyaWFzIG5vIGJhbmNvIGRlIGRhZG9zLi4uXHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICApIDogbm90aWZpY2Fjb2VzUGVuZGVudGVzLmxlbmd0aCA9PT0gMCA/IChcclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHktMTIgdGV4dC1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgPENoZWNrQ2lyY2xlMiBjbGFzc05hbWU9XCJ3LTEwIGgtMTAgdGV4dC1lbWVyYWxkLTUwMCBteC1hdXRvIG1iLTNcIiAvPlxyXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTMwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIE5lbmh1bWEgbm90aWZpY2HDp8OjbyBjb20gcHJhem8gYSB2ZW5jZXIgbm8gcGVyw61vZG8gZGUgMzAgZGlhcy5cclxuICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNTAwIG10LTEgbWF4LXctbWQgbXgtYXV0b1wiPlxyXG4gICAgICAgICAgICAgICAgICAgIFRvZG9zIG9zIHRlcm1vcyBkZSBub3RpZmljYcOnw6NvIGUgZXhpZ8OqbmNpYXMgZXN0w6NvIGVtIGRpYSBvdSBjdW1wcmlkb3MuXHJcbiAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm92ZXJmbG93LXgtYXV0b1wiPlxyXG4gICAgICAgICAgICAgICAgICA8dGFibGUgY2xhc3NOYW1lPVwidy1mdWxsIHRleHQtbGVmdCBib3JkZXItY29sbGFwc2UgdGV4dC14c1wiPlxyXG4gICAgICAgICAgICAgICAgICAgIDx0aGVhZD5cclxuICAgICAgICAgICAgICAgICAgICAgIDx0ciBjbGFzc05hbWU9XCJib3JkZXItYiBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCB0ZXh0LXNsYXRlLTUwMCBkYXJrOnRleHQtc2xhdGUtNDAwIGZvbnQtc2VtaWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0zIHB4LTNcIj5UZXJtbzwvdGg+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0zIHB4LTNcIj5Fc3RhYmVsZWNpbWVudG8gTm90aWZpY2FkbzwvdGg+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0zIHB4LTNcIj5GaXNjYWwgUmVzcG9uc8OhdmVsPC90aD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB5LTMgcHgtM1wiPkRhdGEgTGltaXRlPC90aD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB5LTMgcHgtM1wiPlByYXpvIFJlc3RhbnRlPC90aD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB5LTMgcHgtMyB0ZXh0LXJpZ2h0XCI+QcOnw6NvPC90aD5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvdHI+XHJcbiAgICAgICAgICAgICAgICAgICAgPC90aGVhZD5cclxuICAgICAgICAgICAgICAgICAgICA8dGJvZHkgY2xhc3NOYW1lPVwiZGl2aWRlLXkgZGl2aWRlLXNsYXRlLTEwMCBkYXJrOmRpdmlkZS1zbGF0ZS04MDAgdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTMwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge25vdGlmaWNhY29lc1BlbmRlbnRlcy5tYXAoKG5vdGlmKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGlzVmVuY2lkbyA9IG5vdGlmLmRpYXNfcmVzdGFudGVzIDwgMDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgaXNDcml0aWNvID0gbm90aWYuZGlhc19yZXN0YW50ZXMgPD0gNSAmJiAhaXNWZW5jaWRvO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8dHIga2V5PXtub3RpZi5pbnNwZWNhb19pZH0gY2xhc3NOYW1lPVwiaG92ZXI6Ymctc2xhdGUtNTAvODAgZGFyazpob3ZlcjpiZy1zbGF0ZS04MDAvNDAgdHJhbnNpdGlvbi1jb2xvcnNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS0zIHB4LTMgZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge25vdGlmLm51bWVyb190ZXJtb31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMyBweC0zIHRleHQtc2xhdGUtODAwIGRhcms6dGV4dC1zbGF0ZS0yMDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge25vdGlmLnJhemFvX3NvY2lhbH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMyBweC0zIHRleHQtc2xhdGUtNjAwIGRhcms6dGV4dC1zbGF0ZS00MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge25vdGlmLmZpc2NhbF9yZXNwb25zYXZlbH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMyBweC0zIHRleHQtc2xhdGUtNjAwIGRhcms6dGV4dC1zbGF0ZS00MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2Zvcm1hdERhdGEobm90aWYuZGF0YV9saW1pdGVfYWRlcXVhY2FvKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMyBweC0zXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIHB4LTIgcHktMC41IHJvdW5kZWQtbWQgYm9yZGVyIHRleHQtWzExcHhdIGZvbnQtc2VtaWJvbGQgJHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlzVmVuY2lkb1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IFwiYmctcm9zZS0xMDAgZGFyazpiZy1yb3NlLTk1MC82MCB0ZXh0LXJvc2UtODAwIGRhcms6dGV4dC1yb3NlLTIwMCBib3JkZXItcm9zZS0zMDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IGlzQ3JpdGljb1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IFwiYmctYW1iZXItMTAwIGRhcms6YmctYW1iZXItOTUwLzYwIHRleHQtYW1iZXItODAwIGRhcms6dGV4dC1hbWJlci0yMDAgYm9yZGVyLWFtYmVyLTMwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogXCJiZy1ibHVlLTUwIGRhcms6YmctYmx1ZS05NTAvNDAgdGV4dC1ibHVlLTcwMCBkYXJrOnRleHQtYmx1ZS0zMDAgYm9yZGVyLWJsdWUtMjAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9YH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpc1ZlbmNpZG9cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gYEV4cGlyYWRvICgke01hdGguYWJzKG5vdGlmLmRpYXNfcmVzdGFudGVzKX0gZGlhcylgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IGAke25vdGlmLmRpYXNfcmVzdGFudGVzfSBkaWFzIHJlc3RhbnRlc2B9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMyBweC0zIHRleHQtcmlnaHRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPExpbmtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0bz17Uk9VVEVTLklOU1BFQ09FUy5MQVVETyhub3RpZi5pbnNwZWNhb19pZCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0xIHB4LTIuNSBweS0xIHRleHQtWzExcHhdIGZvbnQtbWVkaXVtIHRleHQtdGVhbC02MDAgaG92ZXI6dGV4dC10ZWFsLTcwMCBiZy10ZWFsLTUwIGRhcms6YmctdGVhbC05NTAvNDAgZGFyazp0ZXh0LXRlYWwtMzAwIHJvdW5kZWQtbWQgaG92ZXI6YmctdGVhbC0xMDAgdHJhbnNpdGlvbi1jb2xvcnNcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEV5ZSBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNVwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+VmVyIFRlcm1vPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvdHI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgICAgICAgICAgICB9KX1cclxuICAgICAgICAgICAgICAgICAgICA8L3Rib2R5PlxyXG4gICAgICAgICAgICAgICAgICA8L3RhYmxlPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTQgcHQtMyBib3JkZXItdCBib3JkZXItc2xhdGUtMTAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCBmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXIgdGV4dC14cyB0ZXh0LXNsYXRlLTUwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuPk1vc3RyYW5kbyB7bm90aWZpY2Fjb2VzUGVuZGVudGVzLmxlbmd0aH0gbm90aWZpY2HDp8O1ZXM8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPExpbmtcclxuICAgICAgICAgICAgICAgICAgICAgIHRvPXtST1VURVMuSU5TUEVDT0VTLlBSQVpPU31cclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtIHRleHQtdGVhbC02MDAgZGFyazp0ZXh0LXRlYWwtNDAwIGhvdmVyOnVuZGVybGluZSBpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTFcIlxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPkFicmlyIFBhaW5lbCBkZSBQcmF6b3MgQ29tcGxldG88L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8Q2hldnJvblJpZ2h0IGNsYXNzTmFtZT1cInctMy41IGgtMy41XCIgLz5cclxuICAgICAgICAgICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICApfVxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIHsvKiBBY2Vzc29zIFLDoXBpZG9zIGFvcyBNw7NkdWxvcyBQcmluY2lwYWlzICovfVxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIGRhcms6Ymctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLXhsIHAtNiBzaGFkb3cteHNcIj5cclxuICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1iYXNlIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlIG1iLTRcIj5cclxuICAgICAgICAgIEFjZXNzb3MgUsOhcGlkb3MgYW9zIE3Ds2R1bG9zIGRvIFNpc3RlbWFcclxuICAgICAgICA8L2gyPlxyXG5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgc206Z3JpZC1jb2xzLTIgbGc6Z3JpZC1jb2xzLTMgZ2FwLTRcIj5cclxuICAgICAgICAgIDxMaW5rXHJcbiAgICAgICAgICAgIHRvPXtST1VURVMuRVNUQUJFTEVDSU1FTlRPUy5MSVNUfVxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJwLTQgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgaG92ZXI6Ym9yZGVyLXRlYWwtNTAwIGRhcms6aG92ZXI6Ym9yZGVyLXRlYWwtNTAwIHRyYW5zaXRpb24tYWxsIGhvdmVyOnNoYWRvdy14cyBncm91cFwiXHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTAgaC0xMCByb3VuZGVkLWxnIGJnLXRlYWwtNTAgZGFyazpiZy10ZWFsLTk1MC80MCB0ZXh0LXRlYWwtNjAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdyb3VwLWhvdmVyOnNjYWxlLTEwNSB0cmFuc2l0aW9uLXRyYW5zZm9ybVwiPlxyXG4gICAgICAgICAgICAgICAgPEJ1aWxkaW5nMiBjbGFzc05hbWU9XCJ3LTUgaC01XCIgLz5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGUgZ3JvdXAtaG92ZXI6dGV4dC10ZWFsLTYwMCB0cmFuc2l0aW9uLWNvbG9yc1wiPlxyXG4gICAgICAgICAgICAgICAgICBFc3RhYmVsZWNpbWVudG9zXHJcbiAgICAgICAgICAgICAgICA8L2gzPlxyXG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTUwMCBkYXJrOnRleHQtc2xhdGUtNDAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIENhZGFzdHJvcywgQ05BRXMgZSB2w61uY3Vsb3MgZGUgUlRcclxuICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L0xpbms+XHJcblxyXG4gICAgICAgICAgPExpbmtcclxuICAgICAgICAgICAgdG89e1JPVVRFUy5JTlNQRUNPRVMuTElTVH1cclxuICAgICAgICAgICAgY2xhc3NOYW1lPVwicC00IHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtODAwIGhvdmVyOmJvcmRlci10ZWFsLTUwMCBkYXJrOmhvdmVyOmJvcmRlci10ZWFsLTUwMCB0cmFuc2l0aW9uLWFsbCBob3ZlcjpzaGFkb3cteHMgZ3JvdXBcIlxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zXCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEwIGgtMTAgcm91bmRlZC1sZyBiZy10ZWFsLTUwIGRhcms6YmctdGVhbC05NTAvNDAgdGV4dC10ZWFsLTYwMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBncm91cC1ob3ZlcjpzY2FsZS0xMDUgdHJhbnNpdGlvbi10cmFuc2Zvcm1cIj5cclxuICAgICAgICAgICAgICAgIDxDbGlwYm9hcmRDaGVjayBjbGFzc05hbWU9XCJ3LTUgaC01XCIgLz5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGUgZ3JvdXAtaG92ZXI6dGV4dC10ZWFsLTYwMCB0cmFuc2l0aW9uLWNvbG9yc1wiPlxyXG4gICAgICAgICAgICAgICAgICBGaXNjYWxpemHDp8OjbyAmIFZBUFRcclxuICAgICAgICAgICAgICAgIDwvaDM+XHJcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNTAwIGRhcms6dGV4dC1zbGF0ZS00MDBcIj5cclxuICAgICAgICAgICAgICAgICAgVGVybW9zLCB2aXN0b3JpYXMgZSBub3RpZmljYcOnw7Vlc1xyXG4gICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvTGluaz5cclxuXHJcbiAgICAgICAgICA8TGlua1xyXG4gICAgICAgICAgICB0bz17Uk9VVEVTLkxJQ0VOQ0lBTUVOVE8uTElTVH1cclxuICAgICAgICAgICAgY2xhc3NOYW1lPVwicC00IHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtODAwIGhvdmVyOmJvcmRlci10ZWFsLTUwMCBkYXJrOmhvdmVyOmJvcmRlci10ZWFsLTUwMCB0cmFuc2l0aW9uLWFsbCBob3ZlcjpzaGFkb3cteHMgZ3JvdXBcIlxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zXCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEwIGgtMTAgcm91bmRlZC1sZyBiZy10ZWFsLTUwIGRhcms6YmctdGVhbC05NTAvNDAgdGV4dC10ZWFsLTYwMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBncm91cC1ob3ZlcjpzY2FsZS0xMDUgdHJhbnNpdGlvbi10cmFuc2Zvcm1cIj5cclxuICAgICAgICAgICAgICAgIDxGaWxlQ2hlY2sgY2xhc3NOYW1lPVwidy01IGgtNVwiIC8+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlIGdyb3VwLWhvdmVyOnRleHQtdGVhbC02MDAgdHJhbnNpdGlvbi1jb2xvcnNcIj5cclxuICAgICAgICAgICAgICAgICAgQWx2YXLDoXMgU2FuaXTDoXJpb3NcclxuICAgICAgICAgICAgICAgIDwvaDM+XHJcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNTAwIGRhcms6dGV4dC1zbGF0ZS00MDBcIj5cclxuICAgICAgICAgICAgICAgICAgUmVxdWVyaW1lbnRvcyBlIGVtaXNzw6NvIGNvbSBRUiBDb2RlXHJcbiAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9MaW5rPlxyXG5cclxuICAgICAgICAgIDxMaW5rXHJcbiAgICAgICAgICAgIHRvPXtST1VURVMuT1VWSURPUklBLkxJU1R9XHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtNCByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCBob3Zlcjpib3JkZXItdGVhbC01MDAgZGFyazpob3Zlcjpib3JkZXItdGVhbC01MDAgdHJhbnNpdGlvbi1hbGwgaG92ZXI6c2hhZG93LXhzIGdyb3VwXCJcclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xMCBoLTEwIHJvdW5kZWQtbGcgYmctdGVhbC01MCBkYXJrOmJnLXRlYWwtOTUwLzQwIHRleHQtdGVhbC02MDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ3JvdXAtaG92ZXI6c2NhbGUtMTA1IHRyYW5zaXRpb24tdHJhbnNmb3JtXCI+XHJcbiAgICAgICAgICAgICAgICA8QWxlcnRDaXJjbGUgY2xhc3NOYW1lPVwidy01IGgtNVwiIC8+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlIGdyb3VwLWhvdmVyOnRleHQtdGVhbC02MDAgdHJhbnNpdGlvbi1jb2xvcnNcIj5cclxuICAgICAgICAgICAgICAgICAgT3V2aWRvcmlhICYgRGVuw7puY2lhc1xyXG4gICAgICAgICAgICAgICAgPC9oMz5cclxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS01MDAgZGFyazp0ZXh0LXNsYXRlLTQwMFwiPlxyXG4gICAgICAgICAgICAgICAgICBUcmlhZ2VtIGUgZGVzcGFjaG8gZmlzY2FsXHJcbiAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9MaW5rPlxyXG5cclxuICAgICAgICAgIDxMaW5rXHJcbiAgICAgICAgICAgIHRvPXtST1VURVMuSU5ESUNBRE9SRVMuREFTSEJPQVJEfVxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJwLTQgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgaG92ZXI6Ym9yZGVyLXRlYWwtNTAwIGRhcms6aG92ZXI6Ym9yZGVyLXRlYWwtNTAwIHRyYW5zaXRpb24tYWxsIGhvdmVyOnNoYWRvdy14cyBncm91cFwiXHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTAgaC0xMCByb3VuZGVkLWxnIGJnLXRlYWwtNTAgZGFyazpiZy10ZWFsLTk1MC80MCB0ZXh0LXRlYWwtNjAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdyb3VwLWhvdmVyOnNjYWxlLTEwNSB0cmFuc2l0aW9uLXRyYW5zZm9ybVwiPlxyXG4gICAgICAgICAgICAgICAgPFRyZW5kaW5nVXAgY2xhc3NOYW1lPVwidy01IGgtNVwiIC8+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlIGdyb3VwLWhvdmVyOnRleHQtdGVhbC02MDAgdHJhbnNpdGlvbi1jb2xvcnNcIj5cclxuICAgICAgICAgICAgICAgICAgSW5kaWNhZG9yZXMgMTEgYSAxNVxyXG4gICAgICAgICAgICAgICAgPC9oMz5cclxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS01MDAgZGFyazp0ZXh0LXNsYXRlLTQwMFwiPlxyXG4gICAgICAgICAgICAgICAgICBQYWluw6lpcyBhbmFsw610aWNvcyBlIG1ldGFzIFNVU1xyXG4gICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvTGluaz5cclxuXHJcbiAgICAgICAgICA8TGlua1xyXG4gICAgICAgICAgICB0bz17Uk9VVEVTLlJFTEFUT1JJT1MuU1VTKCl9XHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtNCByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCBob3Zlcjpib3JkZXItdGVhbC01MDAgZGFyazpob3Zlcjpib3JkZXItdGVhbC01MDAgdHJhbnNpdGlvbi1hbGwgaG92ZXI6c2hhZG93LXhzIGdyb3VwXCJcclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xMCBoLTEwIHJvdW5kZWQtbGcgYmctdGVhbC01MCBkYXJrOmJnLXRlYWwtOTUwLzQwIHRleHQtdGVhbC02MDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ3JvdXAtaG92ZXI6c2NhbGUtMTA1IHRyYW5zaXRpb24tdHJhbnNmb3JtXCI+XHJcbiAgICAgICAgICAgICAgICA8RmlsZUNoZWNrIGNsYXNzTmFtZT1cInctNSBoLTVcIiAvPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZSBncm91cC1ob3Zlcjp0ZXh0LXRlYWwtNjAwIHRyYW5zaXRpb24tY29sb3JzXCI+XHJcbiAgICAgICAgICAgICAgICAgIFByZXN0YcOnw6NvIGRlIENvbnRhcyBTVVNcclxuICAgICAgICAgICAgICAgIDwvaDM+XHJcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNTAwIGRhcms6dGV4dC1zbGF0ZS00MDBcIj5cclxuICAgICAgICAgICAgICAgICAgUmVsYXTDs3JpbyBvZmljaWFsIERJR0lTVVMgZW0gQTRcclxuICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IERhc2hib2FyZFBhZ2U7XHJcbiJdfQ==