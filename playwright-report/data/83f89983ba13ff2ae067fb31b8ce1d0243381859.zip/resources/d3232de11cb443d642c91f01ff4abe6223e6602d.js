import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/fiscalizacao/LaudoInspecaoFormPage.tsx");const React = __vite__cjsImport0_react; const useEffect = __vite__cjsImport0_react["useEffect"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport15_react_jsxDevRuntime["jsxDEV"];/**
* Tela de Lavratura e Emissão do Laudo Técnico de Inspeção Sanitária
* Rota: /inspecoes/:id/laudo
* Consolida dados cadastrais, checklist dinâmico JSONB, relatório fotográfico
* de evidências, prazos para adequação e parecer conclusivo do fiscal.
*/
import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=0fd2848a";
import { Link, useNavigate, useParams } from "/node_modules/.vite/deps/react-router-dom.js?v=0fd2848a";
import { useForm } from "/node_modules/.vite/deps/react-hook-form.js?v=0fd2848a";
import { zodResolver } from "/node_modules/.vite/deps/@hookform_resolvers_zod.js?v=0fd2848a";
import * as z from "/node_modules/.vite/deps/zod.js?v=0fd2848a";
import { AlertTriangle, ArrowLeft, Building2, CheckCircle, Clock, FileCheck2, FileText, HardHat, Printer, Save, ShieldCheck } from "/node_modules/.vite/deps/lucide-react.js?v=0fd2848a";
import { APP_CONFIG } from "/src/config/app.config.ts";
import { ROUTES } from "/src/config/routes.config.ts";
import { useConcluirInspecaoMutation, useInspecaoDetalhe } from "/src/hooks/useFiscalizacao.ts";
import { useEstabelecimentoDetalhe } from "/src/hooks/useEstabelecimentos.ts";
import { StatusInspecaoBadge } from "/src/components/fiscalizacao/StatusInspecaoBadge.tsx";
import { ResultadoInspecaoBadge } from "/src/components/fiscalizacao/ResultadoInspecaoBadge.tsx";
import { ChecklistDinamico } from "/src/components/fiscalizacao/ChecklistDinamico.tsx";
import { UploadEvidencias } from "/src/components/fiscalizacao/UploadEvidencias.tsx";
import { RiscoBadge } from "/src/components/estabelecimentos/RiscoBadge.tsx";
var _jsxFileName = "E:/Projetos VSCODE/visa_braunas/src/pages/fiscalizacao/LaudoInspecaoFormPage.tsx";
import __vite__cjsImport15_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=0fd2848a";
var _s = $RefreshSig$();
const laudoSchema = z.object({
	resultado: z.enum([
		"aprovado",
		"aprovado_com_exigencias",
		"notificado_com_prazo",
		"auto_infracao",
		"interditado_parcialmente",
		"interditado_totalmente",
		"indeferido"
	]),
	data_fim: z.string().min(10, "Data de encerramento da vistoria é obrigatória"),
	relato_vistoria: z.string().min(15, "Relato minucioso da vistoria deve ter no mínimo 15 caracteres"),
	irregularidades_constatadas: z.string().optional(),
	exigencias_notificadas: z.string().optional(),
	prazo_adequacao_dias: z.number().min(0),
	data_limite_adequacao: z.string().optional(),
	nome_pessoa_acompanhou: z.string().optional(),
	cpf_pessoa_acompanhou: z.string().optional(),
	// VAPT
	nome_local_trabalho: z.string().optional(),
	principais_riscos_identificados: z.string().optional(),
	recomendacoes_orientacoes: z.string().optional()
}).superRefine((data, ctx) => {
	if (data.resultado === "notificado_com_prazo") {
		if (data.prazo_adequacao_dias <= 0) {
			ctx.addIssue({
				code: z.ZodIssueCode.custom,
				path: ["prazo_adequacao_dias"],
				message: "Para notificações com prazo, informe o período de adequação em dias (ex: 15 ou 30)."
			});
		}
		if (!data.exigencias_notificadas || data.exigencias_notificadas.trim().length === 0) {
			ctx.addIssue({
				code: z.ZodIssueCode.custom,
				path: ["exigencias_notificadas"],
				message: "Descreva expressamente as exigências e medidas corretivas notificadas."
			});
		}
	}
});
export const LaudoInspecaoFormPage = () => {
	_s();
	const { id } = useParams();
	const navigate = useNavigate();
	const { data: inspecao, isLoading, isError } = useInspecaoDetalhe(id);
	const { data: estabelecimento } = useEstabelecimentoDetalhe(inspecao?.estabelecimento_id);
	const concluirMutation = useConcluirInspecaoMutation(id || "");
	// Estados locais para estruturas JSONB
	const [checklistRespostas, setChecklistRespostas] = useState({});
	const [fotosEvidencias, setFotosEvidencias] = useState([]);
	const [sucessoMensagem, setSucessoMensagem] = useState(false);
	const hoje = new Date().toISOString().split("T")[0];
	const { register, handleSubmit, watch, setValue, reset, formState: { errors, isSubmitting } } = useForm({
		resolver: zodResolver(laudoSchema),
		defaultValues: {
			resultado: "aprovado",
			data_fim: hoje,
			relato_vistoria: "",
			irregularidades_constatadas: "",
			exigencias_notificadas: "",
			prazo_adequacao_dias: 0,
			data_limite_adequacao: "",
			nome_pessoa_acompanhou: "",
			cpf_pessoa_acompanhou: "",
			nome_local_trabalho: "",
			principais_riscos_identificados: "",
			recomendacoes_orientacoes: ""
		}
	});
	const resultadoSelecionado = watch("resultado");
	const prazoDias = watch("prazo_adequacao_dias");
	// Preenche dados existentes quando carregar a inspeção
	useEffect(() => {
		if (inspecao) {
			reset({
				resultado: inspecao.resultado || "aprovado",
				data_fim: inspecao.data_fim || hoje,
				relato_vistoria: inspecao.relato_vistoria || "",
				irregularidades_constatadas: inspecao.irregularidades_constatadas || "",
				exigencias_notificadas: inspecao.exigencias_notificadas || "",
				prazo_adequacao_dias: inspecao.prazo_adequacao_dias || 0,
				data_limite_adequacao: inspecao.data_limite_adequacao || "",
				nome_pessoa_acompanhou: inspecao.nome_pessoa_acompanhou || "",
				cpf_pessoa_acompanhou: inspecao.cpf_pessoa_acompanhou || "",
				nome_local_trabalho: inspecao.nome_local_trabalho || "",
				principais_riscos_identificados: inspecao.principais_riscos_identificados || "",
				recomendacoes_orientacoes: inspecao.recomendacoes_orientacoes || ""
			});
			if (inspecao.checklist_respostas) {
				setChecklistRespostas(inspecao.checklist_respostas);
			}
			if (inspecao.relatorio_fotografico) {
				setFotosEvidencias(inspecao.relatorio_fotografico);
			}
		}
	}, [
		inspecao,
		reset,
		hoje
	]);
	// Atualiza data limite automaticamente caso prazo em dias seja digitado
	useEffect(() => {
		if (resultadoSelecionado === "notificado_com_prazo" && prazoDias > 0) {
			const dataCalculada = new Date();
			dataCalculada.setDate(dataCalculada.getDate() + Number(prazoDias));
			setValue("data_limite_adequacao", dataCalculada.toISOString().split("T")[0]);
		}
	}, [
		prazoDias,
		resultadoSelecionado,
		setValue
	]);
	if (isLoading) {
		return /* @__PURE__ */ _jsxDEV("div", {
			className: "p-16 text-center text-slate-400 text-xs flex flex-col items-center justify-center",
			children: [/* @__PURE__ */ _jsxDEV("div", { className: "w-6 h-6 border-2 border-teal-500 border-t-transparent rounded-full animate-spin mb-3" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 178,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Carregando dados da inspeção sanitária..." }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 179,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 177,
			columnNumber: 7
		}, this);
	}
	if (isError || !inspecao) {
		return /* @__PURE__ */ _jsxDEV("div", {
			className: "p-8 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl text-center space-y-4",
			children: [
				/* @__PURE__ */ _jsxDEV(AlertTriangle, { className: "w-10 h-10 text-rose-500 mx-auto" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 187,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("h2", {
					className: "text-sm font-bold text-slate-900 dark:text-white",
					children: "Inspeção não encontrada ou indisponível"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 188,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("p", {
					className: "text-xs text-slate-500",
					children: "Não foi possível localizar os registros deste termo fiscal."
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 191,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV(Link, {
					to: ROUTES.INSPECOES.LIST,
					className: "inline-flex items-center gap-1.5 px-4 py-2 text-xs font-bold text-teal-700 bg-teal-50 rounded-xl border border-teal-200 hover:bg-teal-100",
					children: [/* @__PURE__ */ _jsxDEV(ArrowLeft, { className: "w-3.5 h-3.5" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 198,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Voltar para Inspeções" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 199,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 194,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 186,
			columnNumber: 7
		}, this);
	}
	const isConcluida = inspecao.status === "concluida";
	const isVapt = inspecao.motivo === "vapt_trabalhador";
	const onSubmit = async (data) => {
		try {
			const payload = {
				...data,
				prazo_adequacao_dias: Number(data.prazo_adequacao_dias || 0),
				checklist_respostas: checklistRespostas,
				relatorio_fotografico: fotosEvidencias
			};
			await concluirMutation.mutateAsync(payload);
			setSucessoMensagem(true);
			window.scrollTo({
				top: 0,
				behavior: "smooth"
			});
		} catch (err) {}
	};
	const handleImprimirTermo = () => {
		window.print();
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "space-y-6 max-w-5xl mx-auto pb-12",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex items-center justify-between",
				children: [/* @__PURE__ */ _jsxDEV(Link, {
					to: ROUTES.INSPECOES.LIST,
					className: "inline-flex items-center gap-2 text-xs font-semibold text-slate-600 dark:text-slate-300 hover:text-teal-600 dark:hover:text-teal-400 transition-colors",
					children: [/* @__PURE__ */ _jsxDEV(ArrowLeft, { className: "w-4 h-4" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 237,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Voltar para Lista de Vistorias" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 238,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 233,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-2",
					children: [isConcluida && /* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						onClick: handleImprimirTermo,
						className: "px-3.5 py-1.5 text-xs font-semibold text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-700/60 shadow-2xs flex items-center gap-1.5 transition-colors",
						children: [/* @__PURE__ */ _jsxDEV(Printer, { className: "w-3.5 h-3.5 text-slate-600 dark:text-slate-400" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 248,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Imprimir Termo Oficial" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 249,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 243,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV(StatusInspecaoBadge, { status: inspecao.status }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 253,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 241,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 232,
				columnNumber: 7
			}, this),
			sucessoMensagem && /* @__PURE__ */ _jsxDEV("div", {
				className: "p-4 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 rounded-2xl flex items-center justify-between text-xs text-emerald-800 dark:text-emerald-200 animate-in fade-in duration-200",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ _jsxDEV(CheckCircle, { className: "w-4 h-4 text-emerald-600 shrink-0" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 261,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("span", { children: [/* @__PURE__ */ _jsxDEV("strong", { children: "Laudo Concluído com Sucesso!" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 263,
						columnNumber: 15
					}, this), " O termo sanitário foi emitido e registrado no prontuário do estabelecimento."] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 262,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 260,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					onClick: () => setSucessoMensagem(false),
					className: "text-emerald-600 hover:text-emerald-800 font-bold ml-4",
					children: "Fechar"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 266,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 259,
				columnNumber: 9
			}, this),
			concluirMutation.isError && /* @__PURE__ */ _jsxDEV("div", {
				className: "p-4 bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 rounded-2xl flex items-center gap-2 text-xs text-rose-800 dark:text-rose-200",
				children: [/* @__PURE__ */ _jsxDEV(AlertTriangle, { className: "w-4 h-4 text-rose-600 shrink-0" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 279,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("span", { children: concluirMutation.error instanceof Error ? concluirMutation.error.message : "Erro ao concluir a inspeção sanitária." }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 280,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 278,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-xs space-y-4",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100 dark:border-slate-800",
					children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-2 text-[11px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider",
						children: [
							/* @__PURE__ */ _jsxDEV("span", { children: APP_CONFIG.municipio }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 293,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("span", { children: "•" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 294,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("span", { children: APP_CONFIG.orgao }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 295,
								columnNumber: 15
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 292,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("h1", {
						className: "text-lg font-bold text-slate-900 dark:text-white mt-0.5 flex items-center gap-2",
						children: [/* @__PURE__ */ _jsxDEV(FileCheck2, { className: "w-5 h-5 text-teal-600 dark:text-teal-400" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 298,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Termo Fiscal de Inspeção Sanitária" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 299,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 297,
						columnNumber: 13
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 291,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "text-right",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-[10px] text-slate-400 uppercase font-semibold block",
								children: "Termo / Registro"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 305,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "text-sm font-mono font-bold text-slate-900 dark:text-white",
								children: inspecao.numero_termo
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 308,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 304,
							columnNumber: 13
						}, this), inspecao.resultado && /* @__PURE__ */ _jsxDEV(ResultadoInspecaoBadge, { resultado: inspecao.resultado }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 313,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 303,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 290,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 text-xs",
					children: [
						/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "text-slate-400 block text-[10px] uppercase font-semibold",
							children: "Motivo da Ação"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 321,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							className: "font-semibold text-slate-800 dark:text-slate-200 capitalize",
							children: inspecao.motivo.replace(/_/g, " ")
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 324,
							columnNumber: 13
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 320,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "text-slate-400 block text-[10px] uppercase font-semibold",
							children: "Data de Início"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 330,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							className: "font-medium text-slate-800 dark:text-slate-200",
							children: new Date(inspecao.data_inicio).toLocaleDateString("pt-BR")
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 333,
							columnNumber: 13
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 329,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "text-slate-400 block text-[10px] uppercase font-semibold",
							children: "Fiscal Responsável"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 339,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							className: "font-medium text-slate-800 dark:text-slate-200",
							children: "Servidor Autoridade Sanitária"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 342,
							columnNumber: 13
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 338,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "text-slate-400 block text-[10px] uppercase font-semibold",
							children: "Equipe / Acompanhantes"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 348,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							className: "font-medium text-slate-800 dark:text-slate-200",
							children: inspecao.fiscais_acompanhantes || "Vistoria Individual"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 351,
							columnNumber: 13
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 347,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 319,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 289,
				columnNumber: 7
			}, this),
			estabelecimento && /* @__PURE__ */ _jsxDEV("div", {
				className: "bg-slate-50/70 dark:bg-slate-850 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-2xs space-y-3",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center justify-between",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ _jsxDEV(Building2, { className: "w-4 h-4 text-teal-600 dark:text-teal-400" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 363,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("h3", {
								className: "text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider",
								children: "Estabelecimento Vistoriado"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 364,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 362,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ _jsxDEV(RiscoBadge, { risco: estabelecimento.nivel_risco }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 369,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV(Link, {
								to: ROUTES.ESTABELECIMENTOS.DETALHE(estabelecimento.id),
								target: "_blank",
								className: "text-[11px] font-semibold text-teal-600 dark:text-teal-400 hover:underline",
								children: "Abrir Prontuário"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 370,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 368,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 361,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs",
						children: [
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-slate-400 text-[10px] block",
								children: "Razão Social"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 382,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "font-bold text-slate-900 dark:text-white",
								children: estabelecimento.razao_social
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 383,
								columnNumber: 15
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 381,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-slate-400 text-[10px] block",
								children: "Nome Fantasia"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 388,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "font-medium text-slate-800 dark:text-slate-200",
								children: estabelecimento.nome_fantasia || "Não informado"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 389,
								columnNumber: 15
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 387,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-slate-400 text-[10px] block",
								children: "CNPJ / CPF"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 394,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "font-mono font-medium text-slate-800 dark:text-slate-200",
								children: estabelecimento.cnpj_cpf
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 395,
								columnNumber: 15
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 393,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 380,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "text-xs text-slate-600 dark:text-slate-300 pt-1 border-t border-slate-200/60 dark:border-slate-800",
						children: [
							/* @__PURE__ */ _jsxDEV("strong", { children: "Endereço:" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 402,
								columnNumber: 13
							}, this),
							" ",
							estabelecimento.logradouro,
							", ",
							estabelecimento.numero,
							" ",
							estabelecimento.complemento && `(${estabelecimento.complemento})`,
							" -",
							" ",
							estabelecimento.bairro,
							", ",
							estabelecimento.municipio,
							"/",
							estabelecimento.uf,
							" - CEP:",
							" ",
							estabelecimento.cep
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 401,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 360,
				columnNumber: 9
			}, this),
			isVapt && /* @__PURE__ */ _jsxDEV("div", {
				className: "bg-teal-50/50 dark:bg-teal-950/20 border border-teal-200 dark:border-teal-800/80 rounded-2xl p-5 shadow-2xs space-y-3",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-2 text-teal-800 dark:text-teal-300",
						children: [/* @__PURE__ */ _jsxDEV(HardHat, { className: "w-5 h-5 text-teal-600 dark:text-teal-400" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 414,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("h3", {
							className: "text-xs font-bold uppercase tracking-wider",
							children: "Vigilância em Ambientes e Processos de Trabalho (VAPT - Indicador 11)"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 415,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 413,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("p", {
						className: "text-[11px] text-teal-700/80 dark:text-teal-400",
						children: "Ação fiscalizadora de verificação e controle dos fatores de risco à saúde e segurança do trabalhador."
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 419,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "grid grid-cols-1 md:grid-cols-2 gap-4 text-xs pt-1",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "p-3 bg-white dark:bg-slate-900 border border-teal-200 dark:border-teal-800/60 rounded-xl",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-slate-400 block text-[10px] uppercase font-semibold",
								children: "Setor / Posto de Trabalho Inspecionado"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 425,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "font-bold text-slate-800 dark:text-slate-200",
								children: inspecao.nome_local_trabalho || "Ambiente geral da empresa"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 428,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 424,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "p-3 bg-white dark:bg-slate-900 border border-teal-200 dark:border-teal-800/60 rounded-xl",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-slate-400 block text-[10px] uppercase font-semibold",
								children: "Riscos Ocupacionais Identificados"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 434,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "font-medium text-slate-700 dark:text-slate-300",
								children: inspecao.principais_riscos_identificados || "Riscos ergonômicos e físicos avaliados"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 437,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 433,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 423,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 412,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV("form", {
				onSubmit: handleSubmit(onSubmit),
				className: "space-y-6",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-xs space-y-4",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-2 pb-2 border-b border-slate-100 dark:border-slate-800",
							children: [/* @__PURE__ */ _jsxDEV(FileText, { className: "w-4 h-4 text-teal-600 dark:text-teal-400" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 450,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("h2", {
								className: "text-sm font-bold text-slate-900 dark:text-white",
								children: "1. Avaliação Sanitária de Conformidades (Checklist)"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 451,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 449,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV(ChecklistDinamico, {
							value: checklistRespostas,
							onChange: setChecklistRespostas,
							readOnly: isConcluida
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 456,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 448,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-xs space-y-4",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-2 pb-2 border-b border-slate-100 dark:border-slate-800",
							children: [/* @__PURE__ */ _jsxDEV(ShieldCheck, { className: "w-4 h-4 text-teal-600 dark:text-teal-400" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 466,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("h2", {
								className: "text-sm font-bold text-slate-900 dark:text-white",
								children: "2. Evidências Fotográficas da Inspeção"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 467,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 465,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV(UploadEvidencias, {
							value: fotosEvidencias,
							onChange: setFotosEvidencias,
							readOnly: isConcluida
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 472,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 464,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-xs space-y-5",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-2 pb-2 border-b border-slate-100 dark:border-slate-800",
								children: [/* @__PURE__ */ _jsxDEV(FileCheck2, { className: "w-4 h-4 text-teal-600 dark:text-teal-400" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 482,
									columnNumber: 13
								}, this), /* @__PURE__ */ _jsxDEV("h2", {
									className: "text-sm font-bold text-slate-900 dark:text-white",
									children: "3. Parecer Conclusivo & Deliberação Fiscal"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 483,
									columnNumber: 13
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 481,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { children: [
								/* @__PURE__ */ _jsxDEV("label", {
									className: "block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1",
									children: ["Relato Minucioso da Vistoria Sanitária ", /* @__PURE__ */ _jsxDEV("span", {
										className: "text-rose-500",
										children: "*"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 491,
										columnNumber: 54
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 490,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("textarea", {
									rows: 4,
									disabled: isConcluida,
									...register("relato_vistoria"),
									placeholder: "Descreva as condições gerais do estabelecimento, procedimentos inspecionados, conduta dos funcionários e constatações fiscais...",
									className: "w-full p-3 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-teal-500 disabled:opacity-80"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 493,
									columnNumber: 13
								}, this),
								errors.relato_vistoria && /* @__PURE__ */ _jsxDEV("p", {
									className: "text-[11px] text-rose-600 mt-1",
									children: errors.relato_vistoria.message
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 501,
									columnNumber: 15
								}, this)
							] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 489,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1",
								children: "Irregularidades Sanitárias Constatadas (se houver)"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 509,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("textarea", {
								rows: 3,
								disabled: isConcluida,
								...register("irregularidades_constatadas"),
								placeholder: "Aponte infrações à legislação sanitária federal, estadual ou código municipal de posturas...",
								className: "w-full p-3 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-teal-500 disabled:opacity-80"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 512,
								columnNumber: 13
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 508,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2 border-t border-slate-100 dark:border-slate-800",
								children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
									className: "block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1",
									children: ["Parecer / Resultado da Vistoria ", /* @__PURE__ */ _jsxDEV("span", {
										className: "text-rose-500",
										children: "*"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 525,
										columnNumber: 49
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 524,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("select", {
									disabled: isConcluida,
									...register("resultado"),
									className: "w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-teal-500 disabled:opacity-80",
									children: [
										/* @__PURE__ */ _jsxDEV("option", {
											value: "aprovado",
											children: "Aprovado (Sem Exigências)"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 532,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("option", {
											value: "aprovado_com_exigencias",
											children: "Aprovado com Exigências Menores"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 533,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("option", {
											value: "notificado_com_prazo",
											children: "Notificado com Prazo de Adequação"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 534,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("option", {
											value: "auto_infracao",
											children: "Lavrado Auto de Infração Sanitária"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 535,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("option", {
											value: "interditado_parcialmente",
											children: "Interdição Cautelar Parcial"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 536,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("option", {
											value: "interditado_totalmente",
											children: "Interdição Cautelar Total"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 537,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("option", {
											value: "indeferido",
											children: "Indeferido (Licenciamento Recusado)"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 538,
											columnNumber: 17
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 527,
									columnNumber: 15
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 523,
									columnNumber: 13
								}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
									className: "block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1",
									children: ["Data de Conclusão / Encerramento ", /* @__PURE__ */ _jsxDEV("span", {
										className: "text-rose-500",
										children: "*"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 544,
										columnNumber: 50
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 543,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("input", {
									type: "date",
									disabled: isConcluida,
									...register("data_fim"),
									className: "w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-teal-500 disabled:opacity-80"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 546,
									columnNumber: 15
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 542,
									columnNumber: 13
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 522,
								columnNumber: 11
							}, this),
							resultadoSelecionado === "notificado_com_prazo" && /* @__PURE__ */ _jsxDEV("div", {
								className: "p-4 bg-amber-50/70 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800/80 rounded-xl space-y-4 animate-in fade-in duration-150",
								children: [
									/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center gap-2 text-amber-800 dark:text-amber-300",
										children: [/* @__PURE__ */ _jsxDEV(Clock, { className: "w-4 h-4 text-amber-600" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 559,
											columnNumber: 17
										}, this), /* @__PURE__ */ _jsxDEV("h4", {
											className: "text-xs font-bold uppercase tracking-wider",
											children: "Controle de Prazo para Adequação Sanitária"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 560,
											columnNumber: 17
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 558,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "grid grid-cols-1 sm:grid-cols-2 gap-4",
										children: [/* @__PURE__ */ _jsxDEV("div", { children: [
											/* @__PURE__ */ _jsxDEV("label", {
												className: "block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1",
												children: ["Prazo Concedido (em dias corridos) ", /* @__PURE__ */ _jsxDEV("span", {
													className: "text-rose-500",
													children: "*"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 568,
													columnNumber: 56
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 567,
												columnNumber: 19
											}, this),
											/* @__PURE__ */ _jsxDEV("input", {
												type: "number",
												min: "1",
												disabled: isConcluida,
												...register("prazo_adequacao_dias", { valueAsNumber: true }),
												className: "w-full px-3 py-2 text-xs bg-white dark:bg-slate-800 border border-amber-300 dark:border-amber-700 rounded-lg text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-amber-500"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 570,
												columnNumber: 19
											}, this),
											errors.prazo_adequacao_dias && /* @__PURE__ */ _jsxDEV("p", {
												className: "text-[11px] text-rose-600 mt-1",
												children: errors.prazo_adequacao_dias.message
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 578,
												columnNumber: 21
											}, this)
										] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 566,
											columnNumber: 17
										}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
											className: "block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1",
											children: "Data Limite para Cumprimento"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 585,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("input", {
											type: "date",
											disabled: isConcluida,
											...register("data_limite_adequacao"),
											className: "w-full px-3 py-2 text-xs bg-white dark:bg-slate-800 border border-amber-300 dark:border-amber-700 rounded-lg text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-amber-500"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 588,
											columnNumber: 19
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 584,
											columnNumber: 17
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 565,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("div", { children: [
										/* @__PURE__ */ _jsxDEV("label", {
											className: "block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1",
											children: ["Exigências Expressamente Notificadas ", /* @__PURE__ */ _jsxDEV("span", {
												className: "text-rose-500",
												children: "*"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 599,
												columnNumber: 56
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 598,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("textarea", {
											rows: 3,
											disabled: isConcluida,
											...register("exigencias_notificadas"),
											placeholder: "Enumere as obrigações a serem sanadas pelo responsável legal antes da reinspeção...",
											className: "w-full p-2.5 text-xs bg-white dark:bg-slate-800 border border-amber-300 dark:border-amber-700 rounded-lg text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-amber-500"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 601,
											columnNumber: 17
										}, this),
										errors.exigencias_notificadas && /* @__PURE__ */ _jsxDEV("p", {
											className: "text-[11px] text-rose-600 mt-1",
											children: errors.exigencias_notificadas.message
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 609,
											columnNumber: 19
										}, this)
									] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 597,
										columnNumber: 15
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 557,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "pt-2 border-t border-slate-100 dark:border-slate-800 space-y-3",
								children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "text-xs font-bold text-slate-800 dark:text-slate-200 block",
									children: "Representante / Acompanhante no Ato da Vistoria"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 619,
									columnNumber: 13
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "grid grid-cols-1 sm:grid-cols-2 gap-4",
									children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
										className: "block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1",
										children: "Nome Completo da Pessoa que Acompanhou"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 625,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("input", {
										type: "text",
										disabled: isConcluida,
										...register("nome_pessoa_acompanhou"),
										placeholder: "Ex: Carlos Eduardo de Oliveira (Gerente de Loja)",
										className: "w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-teal-500 disabled:opacity-80"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 628,
										columnNumber: 17
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 624,
										columnNumber: 15
									}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
										className: "block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1",
										children: "CPF do Acompanhante"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 638,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("input", {
										type: "text",
										disabled: isConcluida,
										...register("cpf_pessoa_acompanhou"),
										placeholder: "000.000.000-00",
										className: "w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-teal-500 disabled:opacity-80"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 641,
										columnNumber: 17
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 637,
										columnNumber: 15
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 623,
									columnNumber: 13
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 618,
								columnNumber: 11
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 480,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 flex items-center justify-between shadow-2xs",
						children: [
							/* @__PURE__ */ _jsxDEV(Link, {
								to: ROUTES.INSPECOES.LIST,
								className: "px-4 py-2 text-xs font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition-colors",
								children: "Voltar para Listagem"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 655,
								columnNumber: 11
							}, this),
							!isConcluida && /* @__PURE__ */ _jsxDEV("button", {
								type: "submit",
								disabled: isSubmitting,
								className: "px-6 py-2.5 text-xs font-bold text-white bg-teal-600 hover:bg-teal-700 rounded-xl shadow-xs transition-colors flex items-center gap-2 disabled:opacity-60",
								children: [/* @__PURE__ */ _jsxDEV(Save, { className: "w-4 h-4" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 668,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: isSubmitting ? "Emitindo Laudo..." : "Salvar & Concluir Laudo Sanitário" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 669,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 663,
								columnNumber: 13
							}, this),
							isConcluida && /* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-2 text-xs font-bold text-emerald-600 dark:text-emerald-400",
								children: [/* @__PURE__ */ _jsxDEV(CheckCircle, { className: "w-4 h-4" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 677,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Laudo Sanitário Emitido e Concluído" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 678,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 676,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 654,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 446,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 230,
		columnNumber: 5
	}, this);
};
_s(LaudoInspecaoFormPage, "W0LQsov4mA3IrIy3Vc+UUq0sxEY=", false, function() {
	return [
		useParams,
		useNavigate,
		useInspecaoDetalhe,
		useEstabelecimentoDetalhe,
		useConcluirInspecaoMutation,
		useForm
	];
});
_c = LaudoInspecaoFormPage;
export default LaudoInspecaoFormPage;
var _c;
$RefreshReg$(_c, "LaudoInspecaoFormPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/fiscalizacao/LaudoInspecaoFormPage.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("E:/Projetos VSCODE/visa_braunas/src/pages/fiscalizacao/LaudoInspecaoFormPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("E:/Projetos VSCODE/visa_braunas/src/pages/fiscalizacao/LaudoInspecaoFormPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "E:/Projetos VSCODE/visa_braunas/src/pages/fiscalizacao/LaudoInspecaoFormPage.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7Ozs7O0FBT0EsT0FBTyxTQUFTLFdBQVcsZ0JBQWdCO0FBQzNDLFNBQVMsTUFBTSxhQUFhLGlCQUFpQjtBQUM3QyxTQUFTLGVBQWU7QUFDeEIsU0FBUyxtQkFBbUI7QUFDNUIsWUFBWSxPQUFPO0FBQ25CLFNBQ0UsZUFDQSxXQUNBLFdBRUEsYUFDQSxPQUNBLFlBQ0EsVUFDQSxTQUNBLFNBQ0EsTUFDQSxtQkFFSztBQUNQLFNBQVMsa0JBQWtCO0FBQzNCLFNBQVMsY0FBYztBQUV2QixTQUNFLDZCQUNBLDBCQUNLO0FBQ1AsU0FBUyxpQ0FBaUM7QUFPMUMsU0FBUywyQkFBMkI7QUFDcEMsU0FBUyw4QkFBOEI7QUFDdkMsU0FBUyx5QkFBeUI7QUFDbEMsU0FBUyx3QkFBd0I7QUFDakMsU0FBUyxrQkFBa0I7Ozs7QUFFM0IsTUFBTSxjQUFjLEVBQ2pCLE9BQU87Q0FDTixXQUFXLEVBQUUsS0FBSztFQUNoQjtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtDQUNGLENBQUM7Q0FDRCxVQUFVLEVBQUUsT0FBTyxDQUFDLENBQUMsSUFBSSxJQUFJLGdEQUFnRDtDQUM3RSxpQkFBaUIsRUFBRSxPQUFPLENBQUMsQ0FBQyxJQUFJLElBQUksK0RBQStEO0NBQ25HLDZCQUE2QixFQUFFLE9BQU8sQ0FBQyxDQUFDLFNBQVM7Q0FDakQsd0JBQXdCLEVBQUUsT0FBTyxDQUFDLENBQUMsU0FBUztDQUM1QyxzQkFBc0IsRUFBRSxPQUFPLENBQUMsQ0FBQyxJQUFJLENBQUM7Q0FDdEMsdUJBQXVCLEVBQUUsT0FBTyxDQUFDLENBQUMsU0FBUztDQUMzQyx3QkFBd0IsRUFBRSxPQUFPLENBQUMsQ0FBQyxTQUFTO0NBQzVDLHVCQUF1QixFQUFFLE9BQU8sQ0FBQyxDQUFDLFNBQVM7O0NBRTNDLHFCQUFxQixFQUFFLE9BQU8sQ0FBQyxDQUFDLFNBQVM7Q0FDekMsaUNBQWlDLEVBQUUsT0FBTyxDQUFDLENBQUMsU0FBUztDQUNyRCwyQkFBMkIsRUFBRSxPQUFPLENBQUMsQ0FBQyxTQUFTO0FBQ2pELENBQUMsQ0FBQyxDQUNELGFBQWEsTUFBTSxRQUFRO0NBQzFCLElBQUksS0FBSyxjQUFjLHdCQUF3QjtFQUM3QyxJQUFJLEtBQUssd0JBQXdCLEdBQUc7R0FDbEMsSUFBSSxTQUFTO0lBQ1gsTUFBTSxFQUFFLGFBQWE7SUFDckIsTUFBTSxDQUFDLHNCQUFzQjtJQUM3QixTQUFTO0dBQ1gsQ0FBQztFQUNIO0VBQ0EsSUFBSSxDQUFDLEtBQUssMEJBQTBCLEtBQUssdUJBQXVCLEtBQUssQ0FBQyxDQUFDLFdBQVcsR0FBRztHQUNuRixJQUFJLFNBQVM7SUFDWCxNQUFNLEVBQUUsYUFBYTtJQUNyQixNQUFNLENBQUMsd0JBQXdCO0lBQy9CLFNBQVM7R0FDWCxDQUFDO0VBQ0g7Q0FDRjtBQUNGLENBQUM7QUFJSCxPQUFPLE1BQU0sOEJBQXdDOztDQUNuRCxNQUFNLEVBQUUsT0FBTyxVQUEwQjtDQUN6QyxNQUFNLFdBQVcsWUFBWTtDQUU3QixNQUFNLEVBQUUsTUFBTSxVQUFVLFdBQVcsWUFBWSxtQkFBbUIsRUFBRTtDQUNwRSxNQUFNLEVBQUUsTUFBTSxvQkFBb0IsMEJBQ2hDLFVBQVUsa0JBQ1o7Q0FDQSxNQUFNLG1CQUFtQiw0QkFBNEIsTUFBTSxFQUFFOztDQUc3RCxNQUFNLENBQUMsb0JBQW9CLHlCQUF5QixTQUE2QixDQUFDLENBQUM7Q0FDbkYsTUFBTSxDQUFDLGlCQUFpQixzQkFBc0IsU0FBMEIsQ0FBQyxDQUFDO0NBQzFFLE1BQU0sQ0FBQyxpQkFBaUIsc0JBQXNCLFNBQVMsS0FBSztDQUU1RCxNQUFNLE9BQU8sSUFBSSxLQUFLLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDO0NBRWpELE1BQU0sRUFDSixVQUNBLGNBQ0EsT0FDQSxVQUNBLE9BQ0EsV0FBVyxFQUFFLFFBQVEsbUJBQ25CLFFBQXVCO0VBQ3pCLFVBQVUsWUFBWSxXQUFXO0VBQ2pDLGVBQWU7R0FDYixXQUFXO0dBQ1gsVUFBVTtHQUNWLGlCQUFpQjtHQUNqQiw2QkFBNkI7R0FDN0Isd0JBQXdCO0dBQ3hCLHNCQUFzQjtHQUN0Qix1QkFBdUI7R0FDdkIsd0JBQXdCO0dBQ3hCLHVCQUF1QjtHQUN2QixxQkFBcUI7R0FDckIsaUNBQWlDO0dBQ2pDLDJCQUEyQjtFQUM3QjtDQUNGLENBQUM7Q0FFRCxNQUFNLHVCQUF1QixNQUFNLFdBQVc7Q0FDOUMsTUFBTSxZQUFZLE1BQU0sc0JBQXNCOztDQUc5QyxnQkFBZ0I7RUFDZCxJQUFJLFVBQVU7R0FDWixNQUFNO0lBQ0osV0FBVyxTQUFTLGFBQWE7SUFDakMsVUFBVSxTQUFTLFlBQVk7SUFDL0IsaUJBQWlCLFNBQVMsbUJBQW1CO0lBQzdDLDZCQUE2QixTQUFTLCtCQUErQjtJQUNyRSx3QkFBd0IsU0FBUywwQkFBMEI7SUFDM0Qsc0JBQXNCLFNBQVMsd0JBQXdCO0lBQ3ZELHVCQUF1QixTQUFTLHlCQUF5QjtJQUN6RCx3QkFBd0IsU0FBUywwQkFBMEI7SUFDM0QsdUJBQXVCLFNBQVMseUJBQXlCO0lBQ3pELHFCQUFxQixTQUFTLHVCQUF1QjtJQUNyRCxpQ0FDRSxTQUFTLG1DQUFtQztJQUM5QywyQkFBMkIsU0FBUyw2QkFBNkI7R0FDbkUsQ0FBQztHQUVELElBQUksU0FBUyxxQkFBcUI7SUFDaEMsc0JBQXNCLFNBQVMsbUJBQW1CO0dBQ3BEO0dBQ0EsSUFBSSxTQUFTLHVCQUF1QjtJQUNsQyxtQkFBbUIsU0FBUyxxQkFBcUI7R0FDbkQ7RUFDRjtDQUNGLEdBQUc7RUFBQztFQUFVO0VBQU87Q0FBSSxDQUFDOztDQUcxQixnQkFBZ0I7RUFDZCxJQUFJLHlCQUF5QiwwQkFBMEIsWUFBWSxHQUFHO0dBQ3BFLE1BQU0sZ0JBQWdCLElBQUksS0FBSztHQUMvQixjQUFjLFFBQVEsY0FBYyxRQUFRLElBQUksT0FBTyxTQUFTLENBQUM7R0FDakUsU0FBUyx5QkFBeUIsY0FBYyxZQUFZLENBQUMsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLEVBQUU7RUFDN0U7Q0FDRixHQUFHO0VBQUM7RUFBVztFQUFzQjtDQUFRLENBQUM7Q0FFOUMsSUFBSSxXQUFXO0VBQ2IsT0FDRSx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmLENBQ0Usd0JBQUMsT0FBRCxFQUFLLFdBQVUsdUZBQXdGOzs7O2FBQ3ZHLHdCQUFDLFFBQUQsWUFBTSw0Q0FBK0M7Ozs7V0FDbEQ7Ozs7OztDQUVUO0NBRUEsSUFBSSxXQUFXLENBQUMsVUFBVTtFQUN4QixPQUNFLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWY7SUFDRSx3QkFBQyxlQUFELEVBQWUsV0FBVSxrQ0FBbUM7Ozs7O0lBQzVELHdCQUFDLE1BQUQ7S0FBSSxXQUFVO2VBQW1EO0lBRTdEOzs7OztJQUNKLHdCQUFDLEtBQUQ7S0FBRyxXQUFVO2VBQXlCO0lBRW5DOzs7OztJQUNILHdCQUFDLE1BQUQ7S0FDRSxJQUFJLE9BQU8sVUFBVTtLQUNyQixXQUFVO2VBRlosQ0FJRSx3QkFBQyxXQUFELEVBQVcsV0FBVSxjQUFlOzs7O2VBQ3BDLHdCQUFDLFFBQUQsWUFBTSx3QkFBMkI7Ozs7YUFDN0I7Ozs7OztHQUNIOzs7Ozs7Q0FFVDtDQUVBLE1BQU0sY0FBYyxTQUFTLFdBQVc7Q0FDeEMsTUFBTSxTQUFTLFNBQVMsV0FBVztDQUVuQyxNQUFNLFdBQVcsT0FBTyxTQUF3QjtFQUM5QyxJQUFJO0dBQ0YsTUFBTSxVQUFvQztJQUN4QyxHQUFHO0lBQ0gsc0JBQXNCLE9BQU8sS0FBSyx3QkFBd0IsQ0FBQztJQUMzRCxxQkFBcUI7SUFDckIsdUJBQXVCO0dBQ3pCO0dBRUEsTUFBTSxpQkFBaUIsWUFBWSxPQUFPO0dBQzFDLG1CQUFtQixJQUFJO0dBQ3ZCLE9BQU8sU0FBUztJQUFFLEtBQUs7SUFBRyxVQUFVO0dBQVMsQ0FBQztFQUNoRCxTQUFTLEtBQVUsQ0FFbkI7Q0FDRjtDQUVBLE1BQU0sNEJBQTRCO0VBQ2hDLE9BQU8sTUFBTTtDQUNmO0NBRUEsT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUFmO0dBRUUsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLE1BQUQ7S0FDRSxJQUFJLE9BQU8sVUFBVTtLQUNyQixXQUFVO2VBRlosQ0FJRSx3QkFBQyxXQUFELEVBQVcsV0FBVSxVQUFXOzs7O2VBQ2hDLHdCQUFDLFFBQUQsWUFBTSxpQ0FBb0M7Ozs7YUFDdEM7Ozs7O2NBRU4sd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNHLGVBQ0Msd0JBQUMsVUFBRDtNQUNFLE1BQUs7TUFDTCxTQUFTO01BQ1QsV0FBVTtnQkFIWixDQUtFLHdCQUFDLFNBQUQsRUFBUyxXQUFVLGlEQUFrRDs7OztnQkFDckUsd0JBQUMsUUFBRCxZQUFNLHlCQUE0Qjs7OztjQUM1Qjs7Ozs7ZUFHVix3QkFBQyxxQkFBRCxFQUFxQixRQUFRLFNBQVMsT0FBUzs7OzthQUM1Qzs7Ozs7WUFDRjs7Ozs7O0dBR0osbUJBQ0Msd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxhQUFELEVBQWEsV0FBVSxvQ0FBcUM7Ozs7ZUFDNUQsd0JBQUMsUUFBRCxhQUNFLHdCQUFDLFVBQUQsWUFBUSwrQkFBb0M7Ozs7ZUFBQywrRUFDekM7Ozs7YUFDSDs7Ozs7Y0FDTCx3QkFBQyxVQUFEO0tBQ0UsTUFBSztLQUNMLGVBQWUsbUJBQW1CLEtBQUs7S0FDdkMsV0FBVTtlQUNYO0lBRU87Ozs7WUFDTDs7Ozs7O0dBSU4saUJBQWlCLFdBQ2hCLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxlQUFELEVBQWUsV0FBVSxpQ0FBa0M7Ozs7Y0FDM0Qsd0JBQUMsUUFBRCxZQUNHLGlCQUFpQixpQkFBaUIsUUFDL0IsaUJBQWlCLE1BQU0sVUFDdkIseUNBQ0E7Ozs7WUFDSDs7Ozs7O0dBSVAsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWY7T0FDRSx3QkFBQyxRQUFELFlBQU8sV0FBVyxVQUFnQjs7Ozs7T0FDbEMsd0JBQUMsUUFBRCxZQUFNLElBQU87Ozs7O09BQ2Isd0JBQUMsUUFBRCxZQUFPLFdBQVcsTUFBWTs7Ozs7TUFDM0I7Ozs7O2VBQ0wsd0JBQUMsTUFBRDtNQUFJLFdBQVU7Z0JBQWQsQ0FDRSx3QkFBQyxZQUFELEVBQVksV0FBVSwyQ0FBNEM7Ozs7Z0JBQ2xFLHdCQUFDLFFBQUQsWUFBTSxxQ0FBd0M7Ozs7Y0FDNUM7Ozs7O2FBQ0Q7Ozs7ZUFFTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQTJEO09BRXJFOzs7O2lCQUNOLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUNiLFNBQVM7T0FDTjs7OztlQUNIOzs7OztnQkFDSixTQUFTLGFBQ1Isd0JBQUMsd0JBQUQsRUFBd0IsV0FBVyxTQUFTLFVBQVk7Ozs7Y0FFdkQ7Ozs7O2FBQ0Y7Ozs7O2NBR0wsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZjtNQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxRQUFEO09BQU0sV0FBVTtpQkFBMkQ7TUFFckU7Ozs7Z0JBQ04sd0JBQUMsUUFBRDtPQUFNLFdBQVU7aUJBQ2IsU0FBUyxPQUFPLFFBQVEsTUFBTSxHQUFHO01BQzlCOzs7O2NBQ0g7Ozs7O01BRUwsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFFBQUQ7T0FBTSxXQUFVO2lCQUEyRDtNQUVyRTs7OztnQkFDTix3QkFBQyxRQUFEO09BQU0sV0FBVTtpQkFDYixJQUFJLEtBQUssU0FBUyxXQUFXLENBQUMsQ0FBQyxtQkFBbUIsT0FBTztNQUN0RDs7OztjQUNIOzs7OztNQUVMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxRQUFEO09BQU0sV0FBVTtpQkFBMkQ7TUFFckU7Ozs7Z0JBQ04sd0JBQUMsUUFBRDtPQUFNLFdBQVU7aUJBQWlEO01BRTNEOzs7O2NBQ0g7Ozs7O01BRUwsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFFBQUQ7T0FBTSxXQUFVO2lCQUEyRDtNQUVyRTs7OztnQkFDTix3QkFBQyxRQUFEO09BQU0sV0FBVTtpQkFDYixTQUFTLHlCQUF5QjtNQUMvQjs7OztjQUNIOzs7OztLQUNGOzs7OztZQUNGOzs7Ozs7R0FHSixtQkFDQyx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmO0tBQ0Usd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLFdBQUQsRUFBVyxXQUFVLDJDQUE0Qzs7OztpQkFDakUsd0JBQUMsTUFBRDtRQUFJLFdBQVU7a0JBQTRFO09BRXRGOzs7O2VBQ0Q7Ozs7O2dCQUNMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsWUFBRCxFQUFZLE9BQU8sZ0JBQWdCLFlBQWM7Ozs7aUJBQ2pELHdCQUFDLE1BQUQ7UUFDRSxJQUFJLE9BQU8saUJBQWlCLFFBQVEsZ0JBQWdCLEVBQUU7UUFDdEQsUUFBTztRQUNQLFdBQVU7a0JBQ1g7T0FFSzs7OztlQUNIOzs7OztjQUNGOzs7Ozs7S0FFTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZjtPQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBbUM7T0FBa0I7Ozs7aUJBQ3JFLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUNiLGdCQUFnQjtPQUNiOzs7O2VBQ0g7Ozs7O09BQ0wsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUFtQztPQUFtQjs7OztpQkFDdEUsd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQ2IsZ0JBQWdCLGlCQUFpQjtPQUM5Qjs7OztlQUNIOzs7OztPQUNMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBbUM7T0FBZ0I7Ozs7aUJBQ25FLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUNiLGdCQUFnQjtPQUNiOzs7O2VBQ0g7Ozs7O01BQ0Y7Ozs7OztLQUVMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmO09BQ0Usd0JBQUMsVUFBRCxZQUFRLFlBQWlCOzs7OztPQUFDO09BQUUsZ0JBQWdCO09BQVc7T0FBRyxnQkFBZ0I7T0FBUTtPQUNqRixnQkFBZ0IsZUFBZSxJQUFJLGdCQUFnQixZQUFZO09BQUc7T0FBRztPQUNyRSxnQkFBZ0I7T0FBTztPQUFHLGdCQUFnQjtPQUFVO09BQUUsZ0JBQWdCO09BQUc7T0FBUTtPQUNqRixnQkFBZ0I7TUFDZDs7Ozs7O0lBQ0Y7Ozs7OztHQUlOLFVBQ0Msd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZjtLQUNFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsU0FBRCxFQUFTLFdBQVUsMkNBQTRDOzs7O2dCQUMvRCx3QkFBQyxNQUFEO09BQUksV0FBVTtpQkFBNkM7TUFFdkQ7Ozs7Y0FDRDs7Ozs7O0tBQ0wsd0JBQUMsS0FBRDtNQUFHLFdBQVU7Z0JBQWtEO0tBRTVEOzs7OztLQUVILHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBMkQ7T0FFckU7Ozs7aUJBQ04sd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQ2IsU0FBUyx1QkFBdUI7T0FDN0I7Ozs7ZUFDSDs7Ozs7Z0JBRUwsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBMkQ7T0FFckU7Ozs7aUJBQ04sd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQ2IsU0FBUyxtQ0FBbUM7T0FDekM7Ozs7ZUFDSDs7Ozs7Y0FDRjs7Ozs7O0lBQ0Y7Ozs7OztHQUlQLHdCQUFDLFFBQUQ7SUFBTSxVQUFVLGFBQWEsUUFBUTtJQUFHLFdBQVU7Y0FBbEQ7S0FFRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsVUFBRCxFQUFVLFdBQVUsMkNBQTRDOzs7O2lCQUNoRSx3QkFBQyxNQUFEO1FBQUksV0FBVTtrQkFBbUQ7T0FFN0Q7Ozs7ZUFDRDs7Ozs7Z0JBRUwsd0JBQUMsbUJBQUQ7T0FDRSxPQUFPO09BQ1AsVUFBVTtPQUNWLFVBQVU7TUFDWDs7OztjQUNFOzs7Ozs7S0FHTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsYUFBRCxFQUFhLFdBQVUsMkNBQTRDOzs7O2lCQUNuRSx3QkFBQyxNQUFEO1FBQUksV0FBVTtrQkFBbUQ7T0FFN0Q7Ozs7ZUFDRDs7Ozs7Z0JBRUwsd0JBQUMsa0JBQUQ7T0FDRSxPQUFPO09BQ1AsVUFBVTtPQUNWLFVBQVU7TUFDWDs7OztjQUNFOzs7Ozs7S0FHTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZjtPQUNFLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsWUFBRCxFQUFZLFdBQVUsMkNBQTRDOzs7O2tCQUNsRSx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFBbUQ7UUFFN0Q7Ozs7Z0JBQ0Q7Ozs7OztPQUdMLHdCQUFDLE9BQUQ7UUFDRSx3QkFBQyxTQUFEO1NBQU8sV0FBVTttQkFBakIsQ0FBdUYsMkNBQzlDLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUFnQjtTQUFPOzs7O2lCQUN6RTs7Ozs7O1FBQ1Asd0JBQUMsWUFBRDtTQUNFLE1BQU07U0FDTixVQUFVO1NBQ1YsR0FBSSxTQUFTLGlCQUFpQjtTQUM5QixhQUFZO1NBQ1osV0FBVTtRQUNYOzs7OztRQUNBLE9BQU8sbUJBQ04sd0JBQUMsS0FBRDtTQUFHLFdBQVU7bUJBQ1YsT0FBTyxnQkFBZ0I7UUFDdkI7Ozs7O09BRUY7Ozs7O09BR0wsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7UUFBTyxXQUFVO2tCQUFzRTtPQUVoRjs7OztpQkFDUCx3QkFBQyxZQUFEO1FBQ0UsTUFBTTtRQUNOLFVBQVU7UUFDVixHQUFJLFNBQVMsNkJBQTZCO1FBQzFDLGFBQVk7UUFDWixXQUFVO09BQ1g7Ozs7ZUFDRTs7Ozs7T0FHTCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO1NBQU8sV0FBVTttQkFBakIsQ0FBdUYsb0NBQ3JELHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUFnQjtTQUFPOzs7O2lCQUNsRTs7Ozs7a0JBQ1Asd0JBQUMsVUFBRDtTQUNFLFVBQVU7U0FDVixHQUFJLFNBQVMsV0FBVztTQUN4QixXQUFVO21CQUhaO1VBS0Usd0JBQUMsVUFBRDtXQUFRLE9BQU07cUJBQVc7VUFBaUM7Ozs7O1VBQzFELHdCQUFDLFVBQUQ7V0FBUSxPQUFNO3FCQUEwQjtVQUF1Qzs7Ozs7VUFDL0Usd0JBQUMsVUFBRDtXQUFRLE9BQU07cUJBQXVCO1VBQXlDOzs7OztVQUM5RSx3QkFBQyxVQUFEO1dBQVEsT0FBTTtxQkFBZ0I7VUFBMEM7Ozs7O1VBQ3hFLHdCQUFDLFVBQUQ7V0FBUSxPQUFNO3FCQUEyQjtVQUFtQzs7Ozs7VUFDNUUsd0JBQUMsVUFBRDtXQUFRLE9BQU07cUJBQXlCO1VBQWlDOzs7OztVQUN4RSx3QkFBQyxVQUFEO1dBQVEsT0FBTTtxQkFBYTtVQUEyQzs7Ozs7U0FDaEU7Ozs7O2dCQUNMOzs7O2tCQUVMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO1NBQU8sV0FBVTttQkFBakIsQ0FBdUYscUNBQ3BELHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUFnQjtTQUFPOzs7O2lCQUNuRTs7Ozs7a0JBQ1Asd0JBQUMsU0FBRDtTQUNFLE1BQUs7U0FDTCxVQUFVO1NBQ1YsR0FBSSxTQUFTLFVBQVU7U0FDdkIsV0FBVTtRQUNYOzs7O2dCQUNFOzs7O2dCQUNGOzs7Ozs7T0FHSix5QkFBeUIsMEJBQ3hCLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmO1NBQ0Usd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDRSx3QkFBQyxPQUFELEVBQU8sV0FBVSx5QkFBMEI7Ozs7b0JBQzNDLHdCQUFDLE1BQUQ7V0FBSSxXQUFVO3FCQUE2QztVQUV2RDs7OztrQkFDRDs7Ozs7O1NBRUwsd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDRSx3QkFBQyxPQUFEO1dBQ0Usd0JBQUMsU0FBRDtZQUFPLFdBQVU7c0JBQWpCLENBQXVGLHVDQUNsRCx3QkFBQyxRQUFEO2FBQU0sV0FBVTt1QkFBZ0I7WUFBTzs7OztvQkFDckU7Ozs7OztXQUNQLHdCQUFDLFNBQUQ7WUFDRSxNQUFLO1lBQ0wsS0FBSTtZQUNKLFVBQVU7WUFDVixHQUFJLFNBQVMsd0JBQXdCLEVBQUUsZUFBZSxLQUFLLENBQUM7WUFDNUQsV0FBVTtXQUNYOzs7OztXQUNBLE9BQU8sd0JBQ04sd0JBQUMsS0FBRDtZQUFHLFdBQVU7c0JBQ1YsT0FBTyxxQkFBcUI7V0FDNUI7Ozs7O1VBRUY7Ozs7b0JBRUwsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7V0FBTyxXQUFVO3FCQUFzRTtVQUVoRjs7OztvQkFDUCx3QkFBQyxTQUFEO1dBQ0UsTUFBSztXQUNMLFVBQVU7V0FDVixHQUFJLFNBQVMsdUJBQXVCO1dBQ3BDLFdBQVU7VUFDWDs7OztrQkFDRTs7OztrQkFDRjs7Ozs7O1NBRUwsd0JBQUMsT0FBRDtVQUNFLHdCQUFDLFNBQUQ7V0FBTyxXQUFVO3FCQUFqQixDQUF1Rix5Q0FDaEQsd0JBQUMsUUFBRDtZQUFNLFdBQVU7c0JBQWdCO1dBQU87Ozs7bUJBQ3ZFOzs7Ozs7VUFDUCx3QkFBQyxZQUFEO1dBQ0UsTUFBTTtXQUNOLFVBQVU7V0FDVixHQUFJLFNBQVMsd0JBQXdCO1dBQ3JDLGFBQVk7V0FDWixXQUFVO1VBQ1g7Ozs7O1VBQ0EsT0FBTywwQkFDTix3QkFBQyxLQUFEO1dBQUcsV0FBVTtxQkFDVixPQUFPLHVCQUF1QjtVQUM5Qjs7Ozs7U0FFRjs7Ozs7UUFDRjs7Ozs7O09BSVAsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFBNkQ7UUFFdkU7Ozs7a0JBRU4sd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtVQUFPLFdBQVU7b0JBQXNFO1NBRWhGOzs7O21CQUNQLHdCQUFDLFNBQUQ7VUFDRSxNQUFLO1VBQ0wsVUFBVTtVQUNWLEdBQUksU0FBUyx3QkFBd0I7VUFDckMsYUFBWTtVQUNaLFdBQVU7U0FDWDs7OztpQkFDRTs7OzttQkFFTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtVQUFPLFdBQVU7b0JBQXNFO1NBRWhGOzs7O21CQUNQLHdCQUFDLFNBQUQ7VUFDRSxNQUFLO1VBQ0wsVUFBVTtVQUNWLEdBQUksU0FBUyx1QkFBdUI7VUFDcEMsYUFBWTtVQUNaLFdBQVU7U0FDWDs7OztpQkFDRTs7OztpQkFDRjs7Ozs7Z0JBQ0Y7Ozs7OztNQUNGOzs7Ozs7S0FHTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZjtPQUNFLHdCQUFDLE1BQUQ7UUFDRSxJQUFJLE9BQU8sVUFBVTtRQUNyQixXQUFVO2tCQUNYO09BRUs7Ozs7O09BRUwsQ0FBQyxlQUNBLHdCQUFDLFVBQUQ7UUFDRSxNQUFLO1FBQ0wsVUFBVTtRQUNWLFdBQVU7a0JBSFosQ0FLRSx3QkFBQyxNQUFELEVBQU0sV0FBVSxVQUFXOzs7O2tCQUMzQix3QkFBQyxRQUFELFlBQ0csZUFBZSxzQkFBc0Isb0NBQ2xDOzs7O2dCQUNBOzs7Ozs7T0FHVCxlQUNDLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsYUFBRCxFQUFhLFdBQVUsVUFBVzs7OztrQkFDbEMsd0JBQUMsUUFBRCxZQUFNLHNDQUF5Qzs7OztnQkFDNUM7Ozs7OztNQUVKOzs7Ozs7SUFDRDs7Ozs7O0VBQ0g7Ozs7OztBQUVUOzs7Ozs7Ozs7Ozs7QUFFQSxlQUFlIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkxhdWRvSW5zcGVjYW9Gb3JtUGFnZS50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiLyoqXHJcbiAqIFRlbGEgZGUgTGF2cmF0dXJhIGUgRW1pc3PDo28gZG8gTGF1ZG8gVMOpY25pY28gZGUgSW5zcGXDp8OjbyBTYW5pdMOhcmlhXHJcbiAqIFJvdGE6IC9pbnNwZWNvZXMvOmlkL2xhdWRvXHJcbiAqIENvbnNvbGlkYSBkYWRvcyBjYWRhc3RyYWlzLCBjaGVja2xpc3QgZGluw6JtaWNvIEpTT05CLCByZWxhdMOzcmlvIGZvdG9ncsOhZmljb1xyXG4gKiBkZSBldmlkw6puY2lhcywgcHJhem9zIHBhcmEgYWRlcXVhw6fDo28gZSBwYXJlY2VyIGNvbmNsdXNpdm8gZG8gZmlzY2FsLlxyXG4gKi9cclxuXHJcbmltcG9ydCBSZWFjdCwgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7IExpbmssIHVzZU5hdmlnYXRlLCB1c2VQYXJhbXMgfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xyXG5pbXBvcnQgeyB1c2VGb3JtIH0gZnJvbSBcInJlYWN0LWhvb2stZm9ybVwiO1xyXG5pbXBvcnQgeyB6b2RSZXNvbHZlciB9IGZyb20gXCJAaG9va2Zvcm0vcmVzb2x2ZXJzL3pvZFwiO1xyXG5pbXBvcnQgKiBhcyB6IGZyb20gXCJ6b2RcIjtcclxuaW1wb3J0IHtcclxuICBBbGVydFRyaWFuZ2xlLFxyXG4gIEFycm93TGVmdCxcclxuICBCdWlsZGluZzIsXHJcbiAgQ2FsZW5kYXIsXHJcbiAgQ2hlY2tDaXJjbGUsXHJcbiAgQ2xvY2ssXHJcbiAgRmlsZUNoZWNrMixcclxuICBGaWxlVGV4dCxcclxuICBIYXJkSGF0LFxyXG4gIFByaW50ZXIsXHJcbiAgU2F2ZSxcclxuICBTaGllbGRDaGVjayxcclxuICBVc2VyQ2hlY2ssXHJcbn0gZnJvbSBcImx1Y2lkZS1yZWFjdFwiO1xyXG5pbXBvcnQgeyBBUFBfQ09ORklHIH0gZnJvbSBcIi4uLy4uL2NvbmZpZy9hcHAuY29uZmlnXCI7XHJcbmltcG9ydCB7IFJPVVRFUyB9IGZyb20gXCIuLi8uLi9jb25maWcvcm91dGVzLmNvbmZpZ1wiO1xyXG5pbXBvcnQgeyBwYXJzZUFwaUVycm9yIH0gZnJvbSBcIi4uLy4uL3V0aWxzL2FwaUVycm9ySGFuZGxlclwiO1xyXG5pbXBvcnQge1xyXG4gIHVzZUNvbmNsdWlySW5zcGVjYW9NdXRhdGlvbixcclxuICB1c2VJbnNwZWNhb0RldGFsaGUsXHJcbn0gZnJvbSBcIi4uLy4uL2hvb2tzL3VzZUZpc2NhbGl6YWNhb1wiO1xyXG5pbXBvcnQgeyB1c2VFc3RhYmVsZWNpbWVudG9EZXRhbGhlIH0gZnJvbSBcIi4uLy4uL2hvb2tzL3VzZUVzdGFiZWxlY2ltZW50b3NcIjtcclxuaW1wb3J0IHtcclxuICBDaGVja2xpc3RSZXNwb3N0YXMsXHJcbiAgRm90b0V2aWRlbmNpYSxcclxuICBMYXVkb0NvbmNsdXNhb0Zvcm1WYWx1ZXMsXHJcbiAgUmVzdWx0YWRvSW5zcGVjYW8sXHJcbn0gZnJvbSBcIi4uLy4uL3R5cGVzL2Zpc2NhbGl6YWNhb1wiO1xyXG5pbXBvcnQgeyBTdGF0dXNJbnNwZWNhb0JhZGdlIH0gZnJvbSBcIi4uLy4uL2NvbXBvbmVudHMvZmlzY2FsaXphY2FvL1N0YXR1c0luc3BlY2FvQmFkZ2VcIjtcclxuaW1wb3J0IHsgUmVzdWx0YWRvSW5zcGVjYW9CYWRnZSB9IGZyb20gXCIuLi8uLi9jb21wb25lbnRzL2Zpc2NhbGl6YWNhby9SZXN1bHRhZG9JbnNwZWNhb0JhZGdlXCI7XHJcbmltcG9ydCB7IENoZWNrbGlzdERpbmFtaWNvIH0gZnJvbSBcIi4uLy4uL2NvbXBvbmVudHMvZmlzY2FsaXphY2FvL0NoZWNrbGlzdERpbmFtaWNvXCI7XHJcbmltcG9ydCB7IFVwbG9hZEV2aWRlbmNpYXMgfSBmcm9tIFwiLi4vLi4vY29tcG9uZW50cy9maXNjYWxpemFjYW8vVXBsb2FkRXZpZGVuY2lhc1wiO1xyXG5pbXBvcnQgeyBSaXNjb0JhZGdlIH0gZnJvbSBcIi4uLy4uL2NvbXBvbmVudHMvZXN0YWJlbGVjaW1lbnRvcy9SaXNjb0JhZGdlXCI7XHJcblxyXG5jb25zdCBsYXVkb1NjaGVtYSA9IHpcclxuICAub2JqZWN0KHtcclxuICAgIHJlc3VsdGFkbzogei5lbnVtKFtcclxuICAgICAgXCJhcHJvdmFkb1wiLFxyXG4gICAgICBcImFwcm92YWRvX2NvbV9leGlnZW5jaWFzXCIsXHJcbiAgICAgIFwibm90aWZpY2Fkb19jb21fcHJhem9cIixcclxuICAgICAgXCJhdXRvX2luZnJhY2FvXCIsXHJcbiAgICAgIFwiaW50ZXJkaXRhZG9fcGFyY2lhbG1lbnRlXCIsXHJcbiAgICAgIFwiaW50ZXJkaXRhZG9fdG90YWxtZW50ZVwiLFxyXG4gICAgICBcImluZGVmZXJpZG9cIixcclxuICAgIF0pLFxyXG4gICAgZGF0YV9maW06IHouc3RyaW5nKCkubWluKDEwLCBcIkRhdGEgZGUgZW5jZXJyYW1lbnRvIGRhIHZpc3RvcmlhIMOpIG9icmlnYXTDs3JpYVwiKSxcclxuICAgIHJlbGF0b192aXN0b3JpYTogei5zdHJpbmcoKS5taW4oMTUsIFwiUmVsYXRvIG1pbnVjaW9zbyBkYSB2aXN0b3JpYSBkZXZlIHRlciBubyBtw61uaW1vIDE1IGNhcmFjdGVyZXNcIiksXHJcbiAgICBpcnJlZ3VsYXJpZGFkZXNfY29uc3RhdGFkYXM6IHouc3RyaW5nKCkub3B0aW9uYWwoKSxcclxuICAgIGV4aWdlbmNpYXNfbm90aWZpY2FkYXM6IHouc3RyaW5nKCkub3B0aW9uYWwoKSxcclxuICAgIHByYXpvX2FkZXF1YWNhb19kaWFzOiB6Lm51bWJlcigpLm1pbigwKSxcclxuICAgIGRhdGFfbGltaXRlX2FkZXF1YWNhbzogei5zdHJpbmcoKS5vcHRpb25hbCgpLFxyXG4gICAgbm9tZV9wZXNzb2FfYWNvbXBhbmhvdTogei5zdHJpbmcoKS5vcHRpb25hbCgpLFxyXG4gICAgY3BmX3Blc3NvYV9hY29tcGFuaG91OiB6LnN0cmluZygpLm9wdGlvbmFsKCksXHJcbiAgICAvLyBWQVBUXHJcbiAgICBub21lX2xvY2FsX3RyYWJhbGhvOiB6LnN0cmluZygpLm9wdGlvbmFsKCksXHJcbiAgICBwcmluY2lwYWlzX3Jpc2Nvc19pZGVudGlmaWNhZG9zOiB6LnN0cmluZygpLm9wdGlvbmFsKCksXHJcbiAgICByZWNvbWVuZGFjb2VzX29yaWVudGFjb2VzOiB6LnN0cmluZygpLm9wdGlvbmFsKCksXHJcbiAgfSlcclxuICAuc3VwZXJSZWZpbmUoKGRhdGEsIGN0eCkgPT4ge1xyXG4gICAgaWYgKGRhdGEucmVzdWx0YWRvID09PSBcIm5vdGlmaWNhZG9fY29tX3ByYXpvXCIpIHtcclxuICAgICAgaWYgKGRhdGEucHJhem9fYWRlcXVhY2FvX2RpYXMgPD0gMCkge1xyXG4gICAgICAgIGN0eC5hZGRJc3N1ZSh7XHJcbiAgICAgICAgICBjb2RlOiB6LlpvZElzc3VlQ29kZS5jdXN0b20sXHJcbiAgICAgICAgICBwYXRoOiBbXCJwcmF6b19hZGVxdWFjYW9fZGlhc1wiXSxcclxuICAgICAgICAgIG1lc3NhZ2U6IFwiUGFyYSBub3RpZmljYcOnw7VlcyBjb20gcHJhem8sIGluZm9ybWUgbyBwZXLDrW9kbyBkZSBhZGVxdWHDp8OjbyBlbSBkaWFzIChleDogMTUgb3UgMzApLlwiLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9XHJcbiAgICAgIGlmICghZGF0YS5leGlnZW5jaWFzX25vdGlmaWNhZGFzIHx8IGRhdGEuZXhpZ2VuY2lhc19ub3RpZmljYWRhcy50cmltKCkubGVuZ3RoID09PSAwKSB7XHJcbiAgICAgICAgY3R4LmFkZElzc3VlKHtcclxuICAgICAgICAgIGNvZGU6IHouWm9kSXNzdWVDb2RlLmN1c3RvbSxcclxuICAgICAgICAgIHBhdGg6IFtcImV4aWdlbmNpYXNfbm90aWZpY2FkYXNcIl0sXHJcbiAgICAgICAgICBtZXNzYWdlOiBcIkRlc2NyZXZhIGV4cHJlc3NhbWVudGUgYXMgZXhpZ8OqbmNpYXMgZSBtZWRpZGFzIGNvcnJldGl2YXMgbm90aWZpY2FkYXMuXCIsXHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9KTtcclxuXHJcbnR5cGUgTGF1ZG9Gb3JtRGF0YSA9IHouaW5mZXI8dHlwZW9mIGxhdWRvU2NoZW1hPjtcclxuXHJcbmV4cG9ydCBjb25zdCBMYXVkb0luc3BlY2FvRm9ybVBhZ2U6IFJlYWN0LkZDID0gKCkgPT4ge1xyXG4gIGNvbnN0IHsgaWQgfSA9IHVzZVBhcmFtczx7IGlkOiBzdHJpbmcgfT4oKTtcclxuICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKCk7XHJcblxyXG4gIGNvbnN0IHsgZGF0YTogaW5zcGVjYW8sIGlzTG9hZGluZywgaXNFcnJvciB9ID0gdXNlSW5zcGVjYW9EZXRhbGhlKGlkKTtcclxuICBjb25zdCB7IGRhdGE6IGVzdGFiZWxlY2ltZW50byB9ID0gdXNlRXN0YWJlbGVjaW1lbnRvRGV0YWxoZShcclxuICAgIGluc3BlY2FvPy5lc3RhYmVsZWNpbWVudG9faWRcclxuICApO1xyXG4gIGNvbnN0IGNvbmNsdWlyTXV0YXRpb24gPSB1c2VDb25jbHVpckluc3BlY2FvTXV0YXRpb24oaWQgfHwgXCJcIik7XHJcblxyXG4gIC8vIEVzdGFkb3MgbG9jYWlzIHBhcmEgZXN0cnV0dXJhcyBKU09OQlxyXG4gIGNvbnN0IFtjaGVja2xpc3RSZXNwb3N0YXMsIHNldENoZWNrbGlzdFJlc3Bvc3Rhc10gPSB1c2VTdGF0ZTxDaGVja2xpc3RSZXNwb3N0YXM+KHt9KTtcclxuICBjb25zdCBbZm90b3NFdmlkZW5jaWFzLCBzZXRGb3Rvc0V2aWRlbmNpYXNdID0gdXNlU3RhdGU8Rm90b0V2aWRlbmNpYVtdPihbXSk7XHJcbiAgY29uc3QgW3N1Y2Vzc29NZW5zYWdlbSwgc2V0U3VjZXNzb01lbnNhZ2VtXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuXHJcbiAgY29uc3QgaG9qZSA9IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKS5zcGxpdChcIlRcIilbMF07XHJcblxyXG4gIGNvbnN0IHtcclxuICAgIHJlZ2lzdGVyLFxyXG4gICAgaGFuZGxlU3VibWl0LFxyXG4gICAgd2F0Y2gsXHJcbiAgICBzZXRWYWx1ZSxcclxuICAgIHJlc2V0LFxyXG4gICAgZm9ybVN0YXRlOiB7IGVycm9ycywgaXNTdWJtaXR0aW5nIH0sXHJcbiAgfSA9IHVzZUZvcm08TGF1ZG9Gb3JtRGF0YT4oe1xyXG4gICAgcmVzb2x2ZXI6IHpvZFJlc29sdmVyKGxhdWRvU2NoZW1hKSxcclxuICAgIGRlZmF1bHRWYWx1ZXM6IHtcclxuICAgICAgcmVzdWx0YWRvOiBcImFwcm92YWRvXCIsXHJcbiAgICAgIGRhdGFfZmltOiBob2plLFxyXG4gICAgICByZWxhdG9fdmlzdG9yaWE6IFwiXCIsXHJcbiAgICAgIGlycmVndWxhcmlkYWRlc19jb25zdGF0YWRhczogXCJcIixcclxuICAgICAgZXhpZ2VuY2lhc19ub3RpZmljYWRhczogXCJcIixcclxuICAgICAgcHJhem9fYWRlcXVhY2FvX2RpYXM6IDAsXHJcbiAgICAgIGRhdGFfbGltaXRlX2FkZXF1YWNhbzogXCJcIixcclxuICAgICAgbm9tZV9wZXNzb2FfYWNvbXBhbmhvdTogXCJcIixcclxuICAgICAgY3BmX3Blc3NvYV9hY29tcGFuaG91OiBcIlwiLFxyXG4gICAgICBub21lX2xvY2FsX3RyYWJhbGhvOiBcIlwiLFxyXG4gICAgICBwcmluY2lwYWlzX3Jpc2Nvc19pZGVudGlmaWNhZG9zOiBcIlwiLFxyXG4gICAgICByZWNvbWVuZGFjb2VzX29yaWVudGFjb2VzOiBcIlwiLFxyXG4gICAgfSxcclxuICB9KTtcclxuXHJcbiAgY29uc3QgcmVzdWx0YWRvU2VsZWNpb25hZG8gPSB3YXRjaChcInJlc3VsdGFkb1wiKTtcclxuICBjb25zdCBwcmF6b0RpYXMgPSB3YXRjaChcInByYXpvX2FkZXF1YWNhb19kaWFzXCIpO1xyXG5cclxuICAvLyBQcmVlbmNoZSBkYWRvcyBleGlzdGVudGVzIHF1YW5kbyBjYXJyZWdhciBhIGluc3Blw6fDo29cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgaWYgKGluc3BlY2FvKSB7XHJcbiAgICAgIHJlc2V0KHtcclxuICAgICAgICByZXN1bHRhZG86IGluc3BlY2FvLnJlc3VsdGFkbyB8fCBcImFwcm92YWRvXCIsXHJcbiAgICAgICAgZGF0YV9maW06IGluc3BlY2FvLmRhdGFfZmltIHx8IGhvamUsXHJcbiAgICAgICAgcmVsYXRvX3Zpc3RvcmlhOiBpbnNwZWNhby5yZWxhdG9fdmlzdG9yaWEgfHwgXCJcIixcclxuICAgICAgICBpcnJlZ3VsYXJpZGFkZXNfY29uc3RhdGFkYXM6IGluc3BlY2FvLmlycmVndWxhcmlkYWRlc19jb25zdGF0YWRhcyB8fCBcIlwiLFxyXG4gICAgICAgIGV4aWdlbmNpYXNfbm90aWZpY2FkYXM6IGluc3BlY2FvLmV4aWdlbmNpYXNfbm90aWZpY2FkYXMgfHwgXCJcIixcclxuICAgICAgICBwcmF6b19hZGVxdWFjYW9fZGlhczogaW5zcGVjYW8ucHJhem9fYWRlcXVhY2FvX2RpYXMgfHwgMCxcclxuICAgICAgICBkYXRhX2xpbWl0ZV9hZGVxdWFjYW86IGluc3BlY2FvLmRhdGFfbGltaXRlX2FkZXF1YWNhbyB8fCBcIlwiLFxyXG4gICAgICAgIG5vbWVfcGVzc29hX2Fjb21wYW5ob3U6IGluc3BlY2FvLm5vbWVfcGVzc29hX2Fjb21wYW5ob3UgfHwgXCJcIixcclxuICAgICAgICBjcGZfcGVzc29hX2Fjb21wYW5ob3U6IGluc3BlY2FvLmNwZl9wZXNzb2FfYWNvbXBhbmhvdSB8fCBcIlwiLFxyXG4gICAgICAgIG5vbWVfbG9jYWxfdHJhYmFsaG86IGluc3BlY2FvLm5vbWVfbG9jYWxfdHJhYmFsaG8gfHwgXCJcIixcclxuICAgICAgICBwcmluY2lwYWlzX3Jpc2Nvc19pZGVudGlmaWNhZG9zOlxyXG4gICAgICAgICAgaW5zcGVjYW8ucHJpbmNpcGFpc19yaXNjb3NfaWRlbnRpZmljYWRvcyB8fCBcIlwiLFxyXG4gICAgICAgIHJlY29tZW5kYWNvZXNfb3JpZW50YWNvZXM6IGluc3BlY2FvLnJlY29tZW5kYWNvZXNfb3JpZW50YWNvZXMgfHwgXCJcIixcclxuICAgICAgfSk7XHJcblxyXG4gICAgICBpZiAoaW5zcGVjYW8uY2hlY2tsaXN0X3Jlc3Bvc3Rhcykge1xyXG4gICAgICAgIHNldENoZWNrbGlzdFJlc3Bvc3RhcyhpbnNwZWNhby5jaGVja2xpc3RfcmVzcG9zdGFzKTtcclxuICAgICAgfVxyXG4gICAgICBpZiAoaW5zcGVjYW8ucmVsYXRvcmlvX2ZvdG9ncmFmaWNvKSB7XHJcbiAgICAgICAgc2V0Rm90b3NFdmlkZW5jaWFzKGluc3BlY2FvLnJlbGF0b3Jpb19mb3RvZ3JhZmljbyk7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9LCBbaW5zcGVjYW8sIHJlc2V0LCBob2plXSk7XHJcblxyXG4gIC8vIEF0dWFsaXphIGRhdGEgbGltaXRlIGF1dG9tYXRpY2FtZW50ZSBjYXNvIHByYXpvIGVtIGRpYXMgc2VqYSBkaWdpdGFkb1xyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBpZiAocmVzdWx0YWRvU2VsZWNpb25hZG8gPT09IFwibm90aWZpY2Fkb19jb21fcHJhem9cIiAmJiBwcmF6b0RpYXMgPiAwKSB7XHJcbiAgICAgIGNvbnN0IGRhdGFDYWxjdWxhZGEgPSBuZXcgRGF0ZSgpO1xyXG4gICAgICBkYXRhQ2FsY3VsYWRhLnNldERhdGUoZGF0YUNhbGN1bGFkYS5nZXREYXRlKCkgKyBOdW1iZXIocHJhem9EaWFzKSk7XHJcbiAgICAgIHNldFZhbHVlKFwiZGF0YV9saW1pdGVfYWRlcXVhY2FvXCIsIGRhdGFDYWxjdWxhZGEudG9JU09TdHJpbmcoKS5zcGxpdChcIlRcIilbMF0pO1xyXG4gICAgfVxyXG4gIH0sIFtwcmF6b0RpYXMsIHJlc3VsdGFkb1NlbGVjaW9uYWRvLCBzZXRWYWx1ZV0pO1xyXG5cclxuICBpZiAoaXNMb2FkaW5nKSB7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMTYgdGV4dC1jZW50ZXIgdGV4dC1zbGF0ZS00MDAgdGV4dC14cyBmbGV4IGZsZXgtY29sIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlclwiPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy02IGgtNiBib3JkZXItMiBib3JkZXItdGVhbC01MDAgYm9yZGVyLXQtdHJhbnNwYXJlbnQgcm91bmRlZC1mdWxsIGFuaW1hdGUtc3BpbiBtYi0zXCIgLz5cclxuICAgICAgICA8c3Bhbj5DYXJyZWdhbmRvIGRhZG9zIGRhIGluc3Blw6fDo28gc2FuaXTDoXJpYS4uLjwvc3Bhbj5cclxuICAgICAgPC9kaXY+XHJcbiAgICApO1xyXG4gIH1cclxuXHJcbiAgaWYgKGlzRXJyb3IgfHwgIWluc3BlY2FvKSB7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtOCBiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC0yeGwgdGV4dC1jZW50ZXIgc3BhY2UteS00XCI+XHJcbiAgICAgICAgPEFsZXJ0VHJpYW5nbGUgY2xhc3NOYW1lPVwidy0xMCBoLTEwIHRleHQtcm9zZS01MDAgbXgtYXV0b1wiIC8+XHJcbiAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1ib2xkIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZVwiPlxyXG4gICAgICAgICAgSW5zcGXDp8OjbyBuw6NvIGVuY29udHJhZGEgb3UgaW5kaXNwb27DrXZlbFxyXG4gICAgICAgIDwvaDI+XHJcbiAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTUwMFwiPlxyXG4gICAgICAgICAgTsOjbyBmb2kgcG9zc8OtdmVsIGxvY2FsaXphciBvcyByZWdpc3Ryb3MgZGVzdGUgdGVybW8gZmlzY2FsLlxyXG4gICAgICAgIDwvcD5cclxuICAgICAgICA8TGlua1xyXG4gICAgICAgICAgdG89e1JPVVRFUy5JTlNQRUNPRVMuTElTVH1cclxuICAgICAgICAgIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHB4LTQgcHktMiB0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXRlYWwtNzAwIGJnLXRlYWwtNTAgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXRlYWwtMjAwIGhvdmVyOmJnLXRlYWwtMTAwXCJcclxuICAgICAgICA+XHJcbiAgICAgICAgICA8QXJyb3dMZWZ0IGNsYXNzTmFtZT1cInctMy41IGgtMy41XCIgLz5cclxuICAgICAgICAgIDxzcGFuPlZvbHRhciBwYXJhIEluc3Blw6fDtWVzPC9zcGFuPlxyXG4gICAgICAgIDwvTGluaz5cclxuICAgICAgPC9kaXY+XHJcbiAgICApO1xyXG4gIH1cclxuXHJcbiAgY29uc3QgaXNDb25jbHVpZGEgPSBpbnNwZWNhby5zdGF0dXMgPT09IFwiY29uY2x1aWRhXCI7XHJcbiAgY29uc3QgaXNWYXB0ID0gaW5zcGVjYW8ubW90aXZvID09PSBcInZhcHRfdHJhYmFsaGFkb3JcIjtcclxuXHJcbiAgY29uc3Qgb25TdWJtaXQgPSBhc3luYyAoZGF0YTogTGF1ZG9Gb3JtRGF0YSkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcGF5bG9hZDogTGF1ZG9Db25jbHVzYW9Gb3JtVmFsdWVzID0ge1xyXG4gICAgICAgIC4uLmRhdGEsXHJcbiAgICAgICAgcHJhem9fYWRlcXVhY2FvX2RpYXM6IE51bWJlcihkYXRhLnByYXpvX2FkZXF1YWNhb19kaWFzIHx8IDApLFxyXG4gICAgICAgIGNoZWNrbGlzdF9yZXNwb3N0YXM6IGNoZWNrbGlzdFJlc3Bvc3RhcyxcclxuICAgICAgICByZWxhdG9yaW9fZm90b2dyYWZpY286IGZvdG9zRXZpZGVuY2lhcyxcclxuICAgICAgfTtcclxuXHJcbiAgICAgIGF3YWl0IGNvbmNsdWlyTXV0YXRpb24ubXV0YXRlQXN5bmMocGF5bG9hZCk7XHJcbiAgICAgIHNldFN1Y2Vzc29NZW5zYWdlbSh0cnVlKTtcclxuICAgICAgd2luZG93LnNjcm9sbFRvKHsgdG9wOiAwLCBiZWhhdmlvcjogXCJzbW9vdGhcIiB9KTtcclxuICAgIH0gY2F0Y2ggKGVycjogYW55KSB7XHJcbiAgICAgIC8vIEVycm8gZXhpYmlkbyBuYSB0ZWxhXHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlSW1wcmltaXJUZXJtbyA9ICgpID0+IHtcclxuICAgIHdpbmRvdy5wcmludCgpO1xyXG4gIH07XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNiBtYXgtdy01eGwgbXgtYXV0byBwYi0xMlwiPlxyXG4gICAgICB7LyogQmFycmEgZGUgTmF2ZWdhw6fDo28gU3VwZXJpb3IgKi99XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XHJcbiAgICAgICAgPExpbmtcclxuICAgICAgICAgIHRvPXtST1VURVMuSU5TUEVDT0VTLkxJU1R9XHJcbiAgICAgICAgICBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNjAwIGRhcms6dGV4dC1zbGF0ZS0zMDAgaG92ZXI6dGV4dC10ZWFsLTYwMCBkYXJrOmhvdmVyOnRleHQtdGVhbC00MDAgdHJhbnNpdGlvbi1jb2xvcnNcIlxyXG4gICAgICAgID5cclxuICAgICAgICAgIDxBcnJvd0xlZnQgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+XHJcbiAgICAgICAgICA8c3Bhbj5Wb2x0YXIgcGFyYSBMaXN0YSBkZSBWaXN0b3JpYXM8L3NwYW4+XHJcbiAgICAgICAgPC9MaW5rPlxyXG5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICB7aXNDb25jbHVpZGEgJiYgKFxyXG4gICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlSW1wcmltaXJUZXJtb31cclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC0zLjUgcHktMS41IHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMjAwIGJnLXdoaXRlIGRhcms6Ymctc2xhdGUtODAwIGJvcmRlciBib3JkZXItc2xhdGUtMzAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCByb3VuZGVkLWxnIGhvdmVyOmJnLXNsYXRlLTUwIGRhcms6aG92ZXI6Ymctc2xhdGUtNzAwLzYwIHNoYWRvdy0yeHMgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSB0cmFuc2l0aW9uLWNvbG9yc1wiXHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICA8UHJpbnRlciBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNSB0ZXh0LXNsYXRlLTYwMCBkYXJrOnRleHQtc2xhdGUtNDAwXCIgLz5cclxuICAgICAgICAgICAgICA8c3Bhbj5JbXByaW1pciBUZXJtbyBPZmljaWFsPC9zcGFuPlxyXG4gICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgPFN0YXR1c0luc3BlY2FvQmFkZ2Ugc3RhdHVzPXtpbnNwZWNhby5zdGF0dXN9IC8+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgey8qIEJhbm5lciBkZSBTdWNlc3NvICovfVxyXG4gICAgICB7c3VjZXNzb01lbnNhZ2VtICYmIChcclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNCBiZy1lbWVyYWxkLTUwIGRhcms6YmctZW1lcmFsZC05NTAvNDAgYm9yZGVyIGJvcmRlci1lbWVyYWxkLTIwMCBkYXJrOmJvcmRlci1lbWVyYWxkLTgwMCByb3VuZGVkLTJ4bCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gdGV4dC14cyB0ZXh0LWVtZXJhbGQtODAwIGRhcms6dGV4dC1lbWVyYWxkLTIwMCBhbmltYXRlLWluIGZhZGUtaW4gZHVyYXRpb24tMjAwXCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgIDxDaGVja0NpcmNsZSBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtZW1lcmFsZC02MDAgc2hyaW5rLTBcIiAvPlxyXG4gICAgICAgICAgICA8c3Bhbj5cclxuICAgICAgICAgICAgICA8c3Ryb25nPkxhdWRvIENvbmNsdcOtZG8gY29tIFN1Y2Vzc28hPC9zdHJvbmc+IE8gdGVybW8gc2FuaXTDoXJpbyBmb2kgZW1pdGlkbyBlIHJlZ2lzdHJhZG8gbm8gcHJvbnR1w6FyaW8gZG8gZXN0YWJlbGVjaW1lbnRvLlxyXG4gICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFN1Y2Vzc29NZW5zYWdlbShmYWxzZSl9XHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtZW1lcmFsZC02MDAgaG92ZXI6dGV4dC1lbWVyYWxkLTgwMCBmb250LWJvbGQgbWwtNFwiXHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIEZlY2hhclxyXG4gICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICl9XHJcblxyXG4gICAgICB7LyogQmFubmVyIGRlIEVycm8gKi99XHJcbiAgICAgIHtjb25jbHVpck11dGF0aW9uLmlzRXJyb3IgJiYgKFxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC00IGJnLXJvc2UtNTAgZGFyazpiZy1yb3NlLTk1MC80MCBib3JkZXIgYm9yZGVyLXJvc2UtMjAwIGRhcms6Ym9yZGVyLXJvc2UtODAwIHJvdW5kZWQtMnhsIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRleHQteHMgdGV4dC1yb3NlLTgwMCBkYXJrOnRleHQtcm9zZS0yMDBcIj5cclxuICAgICAgICAgIDxBbGVydFRyaWFuZ2xlIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1yb3NlLTYwMCBzaHJpbmstMFwiIC8+XHJcbiAgICAgICAgICA8c3Bhbj5cclxuICAgICAgICAgICAge2NvbmNsdWlyTXV0YXRpb24uZXJyb3IgaW5zdGFuY2VvZiBFcnJvclxyXG4gICAgICAgICAgICAgID8gY29uY2x1aXJNdXRhdGlvbi5lcnJvci5tZXNzYWdlXHJcbiAgICAgICAgICAgICAgOiBcIkVycm8gYW8gY29uY2x1aXIgYSBpbnNwZcOnw6NvIHNhbml0w6FyaWEuXCJ9XHJcbiAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICl9XHJcblxyXG4gICAgICB7LyogQ2FiZcOnYWxobyBJbnN0aXR1Y2lvbmFsIGRvIExhdWRvICovfVxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIGRhcms6Ymctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLTJ4bCBwLTYgc2hhZG93LXhzIHNwYWNlLXktNFwiPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBzbTpmbGV4LXJvdyBzbTppdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC00IHBiLTQgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTEwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDBcIj5cclxuICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdGV4dC1bMTFweF0gZm9udC1ib2xkIHRleHQtc2xhdGUtNTAwIGRhcms6dGV4dC1zbGF0ZS00MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCI+XHJcbiAgICAgICAgICAgICAgPHNwYW4+e0FQUF9DT05GSUcubXVuaWNpcGlvfTwvc3Bhbj5cclxuICAgICAgICAgICAgICA8c3Bhbj7igKI8L3NwYW4+XHJcbiAgICAgICAgICAgICAgPHNwYW4+e0FQUF9DT05GSUcub3JnYW99PC9zcGFuPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1ib2xkIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZSBtdC0wLjUgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICA8RmlsZUNoZWNrMiBjbGFzc05hbWU9XCJ3LTUgaC01IHRleHQtdGVhbC02MDAgZGFyazp0ZXh0LXRlYWwtNDAwXCIgLz5cclxuICAgICAgICAgICAgICA8c3Bhbj5UZXJtbyBGaXNjYWwgZGUgSW5zcGXDp8OjbyBTYW5pdMOhcmlhPC9zcGFuPlxyXG4gICAgICAgICAgICA8L2gxPlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtcmlnaHRcIj5cclxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LXNsYXRlLTQwMCB1cHBlcmNhc2UgZm9udC1zZW1pYm9sZCBibG9ja1wiPlxyXG4gICAgICAgICAgICAgICAgVGVybW8gLyBSZWdpc3Ryb1xyXG4gICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbW9ubyBmb250LWJvbGQgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlXCI+XHJcbiAgICAgICAgICAgICAgICB7aW5zcGVjYW8ubnVtZXJvX3Rlcm1vfVxyXG4gICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIHtpbnNwZWNhby5yZXN1bHRhZG8gJiYgKFxyXG4gICAgICAgICAgICAgIDxSZXN1bHRhZG9JbnNwZWNhb0JhZGdlIHJlc3VsdGFkbz17aW5zcGVjYW8ucmVzdWx0YWRvfSAvPlxyXG4gICAgICAgICAgICApfVxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIHsvKiBHcmFkZSBkZSBNZXRhZGFkb3MgZGEgRmlzY2FsaXphw6fDo28gKi99XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIHNtOmdyaWQtY29scy0yIG1kOmdyaWQtY29scy00IGdhcC00IHRleHQteHNcIj5cclxuICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNDAwIGJsb2NrIHRleHQtWzEwcHhdIHVwcGVyY2FzZSBmb250LXNlbWlib2xkXCI+XHJcbiAgICAgICAgICAgICAgTW90aXZvIGRhIEHDp8Ojb1xyXG4gICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS04MDAgZGFyazp0ZXh0LXNsYXRlLTIwMCBjYXBpdGFsaXplXCI+XHJcbiAgICAgICAgICAgICAge2luc3BlY2FvLm1vdGl2by5yZXBsYWNlKC9fL2csIFwiIFwiKX1cclxuICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDAgYmxvY2sgdGV4dC1bMTBweF0gdXBwZXJjYXNlIGZvbnQtc2VtaWJvbGRcIj5cclxuICAgICAgICAgICAgICBEYXRhIGRlIEluw61jaW9cclxuICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1lZGl1bSB0ZXh0LXNsYXRlLTgwMCBkYXJrOnRleHQtc2xhdGUtMjAwXCI+XHJcbiAgICAgICAgICAgICAge25ldyBEYXRlKGluc3BlY2FvLmRhdGFfaW5pY2lvKS50b0xvY2FsZURhdGVTdHJpbmcoXCJwdC1CUlwiKX1cclxuICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDAgYmxvY2sgdGV4dC1bMTBweF0gdXBwZXJjYXNlIGZvbnQtc2VtaWJvbGRcIj5cclxuICAgICAgICAgICAgICBGaXNjYWwgUmVzcG9uc8OhdmVsXHJcbiAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tZWRpdW0gdGV4dC1zbGF0ZS04MDAgZGFyazp0ZXh0LXNsYXRlLTIwMFwiPlxyXG4gICAgICAgICAgICAgIFNlcnZpZG9yIEF1dG9yaWRhZGUgU2FuaXTDoXJpYVxyXG4gICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMCBibG9jayB0ZXh0LVsxMHB4XSB1cHBlcmNhc2UgZm9udC1zZW1pYm9sZFwiPlxyXG4gICAgICAgICAgICAgIEVxdWlwZSAvIEFjb21wYW5oYW50ZXNcclxuICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1lZGl1bSB0ZXh0LXNsYXRlLTgwMCBkYXJrOnRleHQtc2xhdGUtMjAwXCI+XHJcbiAgICAgICAgICAgICAge2luc3BlY2FvLmZpc2NhaXNfYWNvbXBhbmhhbnRlcyB8fCBcIlZpc3RvcmlhIEluZGl2aWR1YWxcIn1cclxuICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgey8qIENhcnTDo28gZGUgSWRlbnRpZmljYcOnw6NvIGRvIEVzdGFiZWxlY2ltZW50byAqL31cclxuICAgICAge2VzdGFiZWxlY2ltZW50byAmJiAoXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zbGF0ZS01MC83MCBkYXJrOmJnLXNsYXRlLTg1MCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC0yeGwgcC01IHNoYWRvdy0yeHMgc3BhY2UteS0zXCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgPEJ1aWxkaW5nMiBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtdGVhbC02MDAgZGFyazp0ZXh0LXRlYWwtNDAwXCIgLz5cclxuICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPlxyXG4gICAgICAgICAgICAgICAgRXN0YWJlbGVjaW1lbnRvIFZpc3RvcmlhZG9cclxuICAgICAgICAgICAgICA8L2gzPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgIDxSaXNjb0JhZGdlIHJpc2NvPXtlc3RhYmVsZWNpbWVudG8ubml2ZWxfcmlzY299IC8+XHJcbiAgICAgICAgICAgICAgPExpbmtcclxuICAgICAgICAgICAgICAgIHRvPXtST1VURVMuRVNUQUJFTEVDSU1FTlRPUy5ERVRBTEhFKGVzdGFiZWxlY2ltZW50by5pZCl9XHJcbiAgICAgICAgICAgICAgICB0YXJnZXQ9XCJfYmxhbmtcIlxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gZm9udC1zZW1pYm9sZCB0ZXh0LXRlYWwtNjAwIGRhcms6dGV4dC10ZWFsLTQwMCBob3Zlcjp1bmRlcmxpbmVcIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIEFicmlyIFByb250dcOhcmlvXHJcbiAgICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBzbTpncmlkLWNvbHMtMyBnYXAtMyB0ZXh0LXhzXCI+XHJcbiAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDAgdGV4dC1bMTBweF0gYmxvY2tcIj5SYXrDo28gU29jaWFsPC9zcGFuPlxyXG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGVcIj5cclxuICAgICAgICAgICAgICAgIHtlc3RhYmVsZWNpbWVudG8ucmF6YW9fc29jaWFsfVxyXG4gICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDAgdGV4dC1bMTBweF0gYmxvY2tcIj5Ob21lIEZhbnRhc2lhPC9zcGFuPlxyXG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtIHRleHQtc2xhdGUtODAwIGRhcms6dGV4dC1zbGF0ZS0yMDBcIj5cclxuICAgICAgICAgICAgICAgIHtlc3RhYmVsZWNpbWVudG8ubm9tZV9mYW50YXNpYSB8fCBcIk7Do28gaW5mb3JtYWRvXCJ9XHJcbiAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMCB0ZXh0LVsxMHB4XSBibG9ja1wiPkNOUEogLyBDUEY8L3NwYW4+XHJcbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tb25vIGZvbnQtbWVkaXVtIHRleHQtc2xhdGUtODAwIGRhcms6dGV4dC1zbGF0ZS0yMDBcIj5cclxuICAgICAgICAgICAgICAgIHtlc3RhYmVsZWNpbWVudG8uY25wal9jcGZ9XHJcbiAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTYwMCBkYXJrOnRleHQtc2xhdGUtMzAwIHB0LTEgYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTIwMC82MCBkYXJrOmJvcmRlci1zbGF0ZS04MDBcIj5cclxuICAgICAgICAgICAgPHN0cm9uZz5FbmRlcmXDp286PC9zdHJvbmc+IHtlc3RhYmVsZWNpbWVudG8ubG9ncmFkb3Vyb30sIHtlc3RhYmVsZWNpbWVudG8ubnVtZXJvfXtcIiBcIn1cclxuICAgICAgICAgICAge2VzdGFiZWxlY2ltZW50by5jb21wbGVtZW50byAmJiBgKCR7ZXN0YWJlbGVjaW1lbnRvLmNvbXBsZW1lbnRvfSlgfSAte1wiIFwifVxyXG4gICAgICAgICAgICB7ZXN0YWJlbGVjaW1lbnRvLmJhaXJyb30sIHtlc3RhYmVsZWNpbWVudG8ubXVuaWNpcGlvfS97ZXN0YWJlbGVjaW1lbnRvLnVmfSAtIENFUDp7XCIgXCJ9XHJcbiAgICAgICAgICAgIHtlc3RhYmVsZWNpbWVudG8uY2VwfVxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICl9XHJcblxyXG4gICAgICB7LyogQkxPQ08gVkFQVCAtIFNBw5pERSBETyBUUkFCQUxIQURPUiAoSU5ESUNBRE9SIDExKSAqL31cclxuICAgICAge2lzVmFwdCAmJiAoXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy10ZWFsLTUwLzUwIGRhcms6YmctdGVhbC05NTAvMjAgYm9yZGVyIGJvcmRlci10ZWFsLTIwMCBkYXJrOmJvcmRlci10ZWFsLTgwMC84MCByb3VuZGVkLTJ4bCBwLTUgc2hhZG93LTJ4cyBzcGFjZS15LTNcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdGV4dC10ZWFsLTgwMCBkYXJrOnRleHQtdGVhbC0zMDBcIj5cclxuICAgICAgICAgICAgPEhhcmRIYXQgY2xhc3NOYW1lPVwidy01IGgtNSB0ZXh0LXRlYWwtNjAwIGRhcms6dGV4dC10ZWFsLTQwMFwiIC8+XHJcbiAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXJcIj5cclxuICAgICAgICAgICAgICBWaWdpbMOibmNpYSBlbSBBbWJpZW50ZXMgZSBQcm9jZXNzb3MgZGUgVHJhYmFsaG8gKFZBUFQgLSBJbmRpY2Fkb3IgMTEpXHJcbiAgICAgICAgICAgIDwvaDM+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtdGVhbC03MDAvODAgZGFyazp0ZXh0LXRlYWwtNDAwXCI+XHJcbiAgICAgICAgICAgIEHDp8OjbyBmaXNjYWxpemFkb3JhIGRlIHZlcmlmaWNhw6fDo28gZSBjb250cm9sZSBkb3MgZmF0b3JlcyBkZSByaXNjbyDDoCBzYcO6ZGUgZSBzZWd1cmFuw6dhIGRvIHRyYWJhbGhhZG9yLlxyXG4gICAgICAgICAgPC9wPlxyXG5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMiBnYXAtNCB0ZXh0LXhzIHB0LTFcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTMgYmctd2hpdGUgZGFyazpiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci10ZWFsLTIwMCBkYXJrOmJvcmRlci10ZWFsLTgwMC82MCByb3VuZGVkLXhsXCI+XHJcbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDAgYmxvY2sgdGV4dC1bMTBweF0gdXBwZXJjYXNlIGZvbnQtc2VtaWJvbGRcIj5cclxuICAgICAgICAgICAgICAgIFNldG9yIC8gUG9zdG8gZGUgVHJhYmFsaG8gSW5zcGVjaW9uYWRvXHJcbiAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXNsYXRlLTgwMCBkYXJrOnRleHQtc2xhdGUtMjAwXCI+XHJcbiAgICAgICAgICAgICAgICB7aW5zcGVjYW8ubm9tZV9sb2NhbF90cmFiYWxobyB8fCBcIkFtYmllbnRlIGdlcmFsIGRhIGVtcHJlc2FcIn1cclxuICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTMgYmctd2hpdGUgZGFyazpiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci10ZWFsLTIwMCBkYXJrOmJvcmRlci10ZWFsLTgwMC82MCByb3VuZGVkLXhsXCI+XHJcbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDAgYmxvY2sgdGV4dC1bMTBweF0gdXBwZXJjYXNlIGZvbnQtc2VtaWJvbGRcIj5cclxuICAgICAgICAgICAgICAgIFJpc2NvcyBPY3VwYWNpb25haXMgSWRlbnRpZmljYWRvc1xyXG4gICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1lZGl1bSB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMzAwXCI+XHJcbiAgICAgICAgICAgICAgICB7aW5zcGVjYW8ucHJpbmNpcGFpc19yaXNjb3NfaWRlbnRpZmljYWRvcyB8fCBcIlJpc2NvcyBlcmdvbsO0bWljb3MgZSBmw61zaWNvcyBhdmFsaWFkb3NcIn1cclxuICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICl9XHJcblxyXG4gICAgICB7LyogRm9ybXVsw6FyaW8gUHJpbmNpcGFsICovfVxyXG4gICAgICA8Zm9ybSBvblN1Ym1pdD17aGFuZGxlU3VibWl0KG9uU3VibWl0KX0gY2xhc3NOYW1lPVwic3BhY2UteS02XCI+XHJcbiAgICAgICAgey8qIEJsb2NvIDE6IENoZWNrbGlzdCBTYW5pdMOhcmlvIERpbsOibWljbyAqL31cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIGRhcms6Ymctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLTJ4bCBwLTYgc2hhZG93LXhzIHNwYWNlLXktNFwiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBwYi0yIGJvcmRlci1iIGJvcmRlci1zbGF0ZS0xMDAgZGFyazpib3JkZXItc2xhdGUtODAwXCI+XHJcbiAgICAgICAgICAgIDxGaWxlVGV4dCBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtdGVhbC02MDAgZGFyazp0ZXh0LXRlYWwtNDAwXCIgLz5cclxuICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1ib2xkIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZVwiPlxyXG4gICAgICAgICAgICAgIDEuIEF2YWxpYcOnw6NvIFNhbml0w6FyaWEgZGUgQ29uZm9ybWlkYWRlcyAoQ2hlY2tsaXN0KVxyXG4gICAgICAgICAgICA8L2gyPlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgPENoZWNrbGlzdERpbmFtaWNvXHJcbiAgICAgICAgICAgIHZhbHVlPXtjaGVja2xpc3RSZXNwb3N0YXN9XHJcbiAgICAgICAgICAgIG9uQ2hhbmdlPXtzZXRDaGVja2xpc3RSZXNwb3N0YXN9XHJcbiAgICAgICAgICAgIHJlYWRPbmx5PXtpc0NvbmNsdWlkYX1cclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIHsvKiBCbG9jbyAyOiBSZWxhdMOzcmlvIEZvdG9ncsOhZmljbyBkZSBFdmlkw6puY2lhcyAqL31cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIGRhcms6Ymctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLTJ4bCBwLTYgc2hhZG93LXhzIHNwYWNlLXktNFwiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBwYi0yIGJvcmRlci1iIGJvcmRlci1zbGF0ZS0xMDAgZGFyazpib3JkZXItc2xhdGUtODAwXCI+XHJcbiAgICAgICAgICAgIDxTaGllbGRDaGVjayBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtdGVhbC02MDAgZGFyazp0ZXh0LXRlYWwtNDAwXCIgLz5cclxuICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1ib2xkIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZVwiPlxyXG4gICAgICAgICAgICAgIDIuIEV2aWTDqm5jaWFzIEZvdG9ncsOhZmljYXMgZGEgSW5zcGXDp8Ojb1xyXG4gICAgICAgICAgICA8L2gyPlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgPFVwbG9hZEV2aWRlbmNpYXNcclxuICAgICAgICAgICAgdmFsdWU9e2ZvdG9zRXZpZGVuY2lhc31cclxuICAgICAgICAgICAgb25DaGFuZ2U9e3NldEZvdG9zRXZpZGVuY2lhc31cclxuICAgICAgICAgICAgcmVhZE9ubHk9e2lzQ29uY2x1aWRhfVxyXG4gICAgICAgICAgLz5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgey8qIEJsb2NvIDM6IFJlbGF0byBlIFBhcmVjZXIgVMOpY25pY28gKi99XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC0yeGwgcC02IHNoYWRvdy14cyBzcGFjZS15LTVcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgcGItMiBib3JkZXItYiBib3JkZXItc2xhdGUtMTAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMFwiPlxyXG4gICAgICAgICAgICA8RmlsZUNoZWNrMiBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtdGVhbC02MDAgZGFyazp0ZXh0LXRlYWwtNDAwXCIgLz5cclxuICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1ib2xkIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZVwiPlxyXG4gICAgICAgICAgICAgIDMuIFBhcmVjZXIgQ29uY2x1c2l2byAmIERlbGliZXJhw6fDo28gRmlzY2FsXHJcbiAgICAgICAgICAgIDwvaDI+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICB7LyogUmVsYXRvIE1pbnVjaW9zbyBkYSBWaXN0b3JpYSAqL31cclxuICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTMwMCBtYi0xXCI+XHJcbiAgICAgICAgICAgICAgUmVsYXRvIE1pbnVjaW9zbyBkYSBWaXN0b3JpYSBTYW5pdMOhcmlhIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcm9zZS01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICA8dGV4dGFyZWFcclxuICAgICAgICAgICAgICByb3dzPXs0fVxyXG4gICAgICAgICAgICAgIGRpc2FibGVkPXtpc0NvbmNsdWlkYX1cclxuICAgICAgICAgICAgICB7Li4ucmVnaXN0ZXIoXCJyZWxhdG9fdmlzdG9yaWFcIil9XHJcbiAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJEZXNjcmV2YSBhcyBjb25kacOnw7VlcyBnZXJhaXMgZG8gZXN0YWJlbGVjaW1lbnRvLCBwcm9jZWRpbWVudG9zIGluc3BlY2lvbmFkb3MsIGNvbmR1dGEgZG9zIGZ1bmNpb27DoXJpb3MgZSBjb25zdGF0YcOnw7VlcyBmaXNjYWlzLi4uXCJcclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcC0zIHRleHQteHMgYmctc2xhdGUtNTAgZGFyazpiZy1zbGF0ZS04MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQteGwgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlIHBsYWNlaG9sZGVyLXNsYXRlLTQwMCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctdGVhbC01MDAgZGlzYWJsZWQ6b3BhY2l0eS04MFwiXHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIHtlcnJvcnMucmVsYXRvX3Zpc3RvcmlhICYmIChcclxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LXJvc2UtNjAwIG10LTFcIj5cclxuICAgICAgICAgICAgICAgIHtlcnJvcnMucmVsYXRvX3Zpc3RvcmlhLm1lc3NhZ2V9XHJcbiAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICApfVxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgey8qIElycmVndWxhcmlkYWRlcyBDb25zdGF0YWRhcyAqL31cclxuICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTMwMCBtYi0xXCI+XHJcbiAgICAgICAgICAgICAgSXJyZWd1bGFyaWRhZGVzIFNhbml0w6FyaWFzIENvbnN0YXRhZGFzIChzZSBob3V2ZXIpXHJcbiAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgIDx0ZXh0YXJlYVxyXG4gICAgICAgICAgICAgIHJvd3M9ezN9XHJcbiAgICAgICAgICAgICAgZGlzYWJsZWQ9e2lzQ29uY2x1aWRhfVxyXG4gICAgICAgICAgICAgIHsuLi5yZWdpc3RlcihcImlycmVndWxhcmlkYWRlc19jb25zdGF0YWRhc1wiKX1cclxuICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkFwb250ZSBpbmZyYcOnw7VlcyDDoCBsZWdpc2xhw6fDo28gc2FuaXTDoXJpYSBmZWRlcmFsLCBlc3RhZHVhbCBvdSBjw7NkaWdvIG11bmljaXBhbCBkZSBwb3N0dXJhcy4uLlwiXHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHAtMyB0ZXh0LXhzIGJnLXNsYXRlLTUwIGRhcms6Ymctc2xhdGUtODAwIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCByb3VuZGVkLXhsIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZSBwbGFjZWhvbGRlci1zbGF0ZS00MDAgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLXRlYWwtNTAwIGRpc2FibGVkOm9wYWNpdHktODBcIlxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgey8qIFJlc3VsdGFkbyAvIERlbGliZXJhw6fDo28gKi99XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgc206Z3JpZC1jb2xzLTIgZ2FwLTQgcHQtMiBib3JkZXItdCBib3JkZXItc2xhdGUtMTAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMFwiPlxyXG4gICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTMwMCBtYi0xXCI+XHJcbiAgICAgICAgICAgICAgICBQYXJlY2VyIC8gUmVzdWx0YWRvIGRhIFZpc3RvcmlhIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcm9zZS01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPHNlbGVjdFxyXG4gICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2lzQ29uY2x1aWRhfVxyXG4gICAgICAgICAgICAgICAgey4uLnJlZ2lzdGVyKFwicmVzdWx0YWRvXCIpfVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMgcHktMiB0ZXh0LXhzIGJnLXNsYXRlLTUwIGRhcms6Ymctc2xhdGUtODAwIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCByb3VuZGVkLWxnIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZSBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctdGVhbC01MDAgZGlzYWJsZWQ6b3BhY2l0eS04MFwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cImFwcm92YWRvXCI+QXByb3ZhZG8gKFNlbSBFeGlnw6puY2lhcyk8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJhcHJvdmFkb19jb21fZXhpZ2VuY2lhc1wiPkFwcm92YWRvIGNvbSBFeGlnw6puY2lhcyBNZW5vcmVzPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwibm90aWZpY2Fkb19jb21fcHJhem9cIj5Ob3RpZmljYWRvIGNvbSBQcmF6byBkZSBBZGVxdWHDp8Ojbzwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cImF1dG9faW5mcmFjYW9cIj5MYXZyYWRvIEF1dG8gZGUgSW5mcmHDp8OjbyBTYW5pdMOhcmlhPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiaW50ZXJkaXRhZG9fcGFyY2lhbG1lbnRlXCI+SW50ZXJkacOnw6NvIENhdXRlbGFyIFBhcmNpYWw8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJpbnRlcmRpdGFkb190b3RhbG1lbnRlXCI+SW50ZXJkacOnw6NvIENhdXRlbGFyIFRvdGFsPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiaW5kZWZlcmlkb1wiPkluZGVmZXJpZG8gKExpY2VuY2lhbWVudG8gUmVjdXNhZG8pPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgPC9zZWxlY3Q+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0zMDAgbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgRGF0YSBkZSBDb25jbHVzw6NvIC8gRW5jZXJyYW1lbnRvIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcm9zZS01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICB0eXBlPVwiZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICBkaXNhYmxlZD17aXNDb25jbHVpZGF9XHJcbiAgICAgICAgICAgICAgICB7Li4ucmVnaXN0ZXIoXCJkYXRhX2ZpbVwiKX1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC0zIHB5LTIgdGV4dC14cyBiZy1zbGF0ZS01MCBkYXJrOmJnLXNsYXRlLTgwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC1sZyB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGUgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLXRlYWwtNTAwIGRpc2FibGVkOm9wYWNpdHktODBcIlxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgey8qIEJsb2NvIENvbmRpY2lvbmFsIGRlIE5vdGlmaWNhw6fDo28gY29tIFByYXpvICovfVxyXG4gICAgICAgICAge3Jlc3VsdGFkb1NlbGVjaW9uYWRvID09PSBcIm5vdGlmaWNhZG9fY29tX3ByYXpvXCIgJiYgKFxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNCBiZy1hbWJlci01MC83MCBkYXJrOmJnLWFtYmVyLTk1MC8zMCBib3JkZXIgYm9yZGVyLWFtYmVyLTIwMCBkYXJrOmJvcmRlci1hbWJlci04MDAvODAgcm91bmRlZC14bCBzcGFjZS15LTQgYW5pbWF0ZS1pbiBmYWRlLWluIGR1cmF0aW9uLTE1MFwiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdGV4dC1hbWJlci04MDAgZGFyazp0ZXh0LWFtYmVyLTMwMFwiPlxyXG4gICAgICAgICAgICAgICAgPENsb2NrIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1hbWJlci02MDBcIiAvPlxyXG4gICAgICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPlxyXG4gICAgICAgICAgICAgICAgICBDb250cm9sZSBkZSBQcmF6byBwYXJhIEFkZXF1YcOnw6NvIFNhbml0w6FyaWFcclxuICAgICAgICAgICAgICAgIDwvaDQ+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBzbTpncmlkLWNvbHMtMiBnYXAtNFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMzAwIG1iLTFcIj5cclxuICAgICAgICAgICAgICAgICAgICBQcmF6byBDb25jZWRpZG8gKGVtIGRpYXMgY29ycmlkb3MpIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcm9zZS01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICBtaW49XCIxXCJcclxuICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17aXNDb25jbHVpZGF9XHJcbiAgICAgICAgICAgICAgICAgICAgey4uLnJlZ2lzdGVyKFwicHJhem9fYWRlcXVhY2FvX2RpYXNcIiwgeyB2YWx1ZUFzTnVtYmVyOiB0cnVlIH0pfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC0zIHB5LTIgdGV4dC14cyBiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTgwMCBib3JkZXIgYm9yZGVyLWFtYmVyLTMwMCBkYXJrOmJvcmRlci1hbWJlci03MDAgcm91bmRlZC1sZyB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGUgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLWFtYmVyLTUwMFwiXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIHtlcnJvcnMucHJhem9fYWRlcXVhY2FvX2RpYXMgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtcm9zZS02MDAgbXQtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5wcmF6b19hZGVxdWFjYW9fZGlhcy5tZXNzYWdlfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTMwMCBtYi0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgRGF0YSBMaW1pdGUgcGFyYSBDdW1wcmltZW50b1xyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2lzQ29uY2x1aWRhfVxyXG4gICAgICAgICAgICAgICAgICAgIHsuLi5yZWdpc3RlcihcImRhdGFfbGltaXRlX2FkZXF1YWNhb1wiKX1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIHRleHQteHMgYmctd2hpdGUgZGFyazpiZy1zbGF0ZS04MDAgYm9yZGVyIGJvcmRlci1hbWJlci0zMDAgZGFyazpib3JkZXItYW1iZXItNzAwIHJvdW5kZWQtbGcgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1hbWJlci01MDBcIlxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0zMDAgbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgICBFeGlnw6puY2lhcyBFeHByZXNzYW1lbnRlIE5vdGlmaWNhZGFzIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcm9zZS01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIDx0ZXh0YXJlYVxyXG4gICAgICAgICAgICAgICAgICByb3dzPXszfVxyXG4gICAgICAgICAgICAgICAgICBkaXNhYmxlZD17aXNDb25jbHVpZGF9XHJcbiAgICAgICAgICAgICAgICAgIHsuLi5yZWdpc3RlcihcImV4aWdlbmNpYXNfbm90aWZpY2FkYXNcIil9XHJcbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW51bWVyZSBhcyBvYnJpZ2HDp8O1ZXMgYSBzZXJlbSBzYW5hZGFzIHBlbG8gcmVzcG9uc8OhdmVsIGxlZ2FsIGFudGVzIGRhIHJlaW5zcGXDp8Ojby4uLlwiXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBwLTIuNSB0ZXh0LXhzIGJnLXdoaXRlIGRhcms6Ymctc2xhdGUtODAwIGJvcmRlciBib3JkZXItYW1iZXItMzAwIGRhcms6Ym9yZGVyLWFtYmVyLTcwMCByb3VuZGVkLWxnIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZSBwbGFjZWhvbGRlci1zbGF0ZS00MDAgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLWFtYmVyLTUwMFwiXHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAge2Vycm9ycy5leGlnZW5jaWFzX25vdGlmaWNhZGFzICYmIChcclxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1yb3NlLTYwMCBtdC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5leGlnZW5jaWFzX25vdGlmaWNhZGFzLm1lc3NhZ2V9XHJcbiAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICB7LyogRGFkb3MgZG8gQWNvbXBhbmhhbnRlIG5vIExvY2FsICovfVxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwdC0yIGJvcmRlci10IGJvcmRlci1zbGF0ZS0xMDAgZGFyazpib3JkZXItc2xhdGUtODAwIHNwYWNlLXktM1wiPlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTgwMCBkYXJrOnRleHQtc2xhdGUtMjAwIGJsb2NrXCI+XHJcbiAgICAgICAgICAgICAgUmVwcmVzZW50YW50ZSAvIEFjb21wYW5oYW50ZSBubyBBdG8gZGEgVmlzdG9yaWFcclxuICAgICAgICAgICAgPC9zcGFuPlxyXG5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIHNtOmdyaWQtY29scy0yIGdhcC00XCI+XHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTMwMCBtYi0xXCI+XHJcbiAgICAgICAgICAgICAgICAgIE5vbWUgQ29tcGxldG8gZGEgUGVzc29hIHF1ZSBBY29tcGFuaG91XHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2lzQ29uY2x1aWRhfVxyXG4gICAgICAgICAgICAgICAgICB7Li4ucmVnaXN0ZXIoXCJub21lX3Blc3NvYV9hY29tcGFuaG91XCIpfVxyXG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkV4OiBDYXJsb3MgRWR1YXJkbyBkZSBPbGl2ZWlyYSAoR2VyZW50ZSBkZSBMb2phKVwiXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC0zIHB5LTIgdGV4dC14cyBiZy1zbGF0ZS01MCBkYXJrOmJnLXNsYXRlLTgwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC1sZyB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGUgcGxhY2Vob2xkZXItc2xhdGUtNDAwIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy10ZWFsLTUwMCBkaXNhYmxlZDpvcGFjaXR5LTgwXCJcclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0zMDAgbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgICBDUEYgZG8gQWNvbXBhbmhhbnRlXHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2lzQ29uY2x1aWRhfVxyXG4gICAgICAgICAgICAgICAgICB7Li4ucmVnaXN0ZXIoXCJjcGZfcGVzc29hX2Fjb21wYW5ob3VcIil9XHJcbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiMDAwLjAwMC4wMDAtMDBcIlxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIHRleHQteHMgYmctc2xhdGUtNTAgZGFyazpiZy1zbGF0ZS04MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQtbGcgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlIHBsYWNlaG9sZGVyLXNsYXRlLTQwMCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctdGVhbC01MDAgZGlzYWJsZWQ6b3BhY2l0eS04MFwiXHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICB7LyogQmFycmEgZGUgQcOnw7VlcyBJbmZlcmlvciAqL31cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIGRhcms6Ymctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLTJ4bCBwLTQgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHNoYWRvdy0yeHNcIj5cclxuICAgICAgICAgIDxMaW5rXHJcbiAgICAgICAgICAgIHRvPXtST1VURVMuSU5TUEVDT0VTLkxJU1R9XHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTQgcHktMiB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS02MDAgZGFyazp0ZXh0LXNsYXRlLTMwMCBob3ZlcjpiZy1zbGF0ZS0xMDAgZGFyazpob3ZlcjpiZy1zbGF0ZS04MDAgcm91bmRlZC14bCB0cmFuc2l0aW9uLWNvbG9yc1wiXHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIFZvbHRhciBwYXJhIExpc3RhZ2VtXHJcbiAgICAgICAgICA8L0xpbms+XHJcblxyXG4gICAgICAgICAgeyFpc0NvbmNsdWlkYSAmJiAoXHJcbiAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcclxuICAgICAgICAgICAgICBkaXNhYmxlZD17aXNTdWJtaXR0aW5nfVxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTYgcHktMi41IHRleHQteHMgZm9udC1ib2xkIHRleHQtd2hpdGUgYmctdGVhbC02MDAgaG92ZXI6YmctdGVhbC03MDAgcm91bmRlZC14bCBzaGFkb3cteHMgdHJhbnNpdGlvbi1jb2xvcnMgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgZGlzYWJsZWQ6b3BhY2l0eS02MFwiXHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICA8U2F2ZSBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz5cclxuICAgICAgICAgICAgICA8c3Bhbj5cclxuICAgICAgICAgICAgICAgIHtpc1N1Ym1pdHRpbmcgPyBcIkVtaXRpbmRvIExhdWRvLi4uXCIgOiBcIlNhbHZhciAmIENvbmNsdWlyIExhdWRvIFNhbml0w6FyaW9cIn1cclxuICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICB7aXNDb25jbHVpZGEgJiYgKFxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRleHQteHMgZm9udC1ib2xkIHRleHQtZW1lcmFsZC02MDAgZGFyazp0ZXh0LWVtZXJhbGQtNDAwXCI+XHJcbiAgICAgICAgICAgICAgPENoZWNrQ2lyY2xlIGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPlxyXG4gICAgICAgICAgICAgIDxzcGFuPkxhdWRvIFNhbml0w6FyaW8gRW1pdGlkbyBlIENvbmNsdcOtZG88L3NwYW4+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgKX1cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9mb3JtPlxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IExhdWRvSW5zcGVjYW9Gb3JtUGFnZTtcclxuIl19