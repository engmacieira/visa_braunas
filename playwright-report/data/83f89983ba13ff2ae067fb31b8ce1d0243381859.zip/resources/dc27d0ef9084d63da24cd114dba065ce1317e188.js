import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/ouvidoria/RegistrarDenunciaInternaPage.tsx");const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport9_react_jsxDevRuntime["jsxDEV"];/**
* Formulário Administrativo Interno de Registro de Denúncia Sanitária
* Rota: /ouvidoria/nova
* Usado por servidores municipais para registrar manifestações recebidas
* por telefone, atendimento presencial de balcão ou ofícios de órgãos de controle.
*/
import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=0fd2848a";
import { Link, useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=0fd2848a";
import { useForm } from "/node_modules/.vite/deps/react-hook-form.js?v=0fd2848a";
import { zodResolver } from "/node_modules/.vite/deps/@hookform_resolvers_zod.js?v=0fd2848a";
import * as z from "/node_modules/.vite/deps/zod.js?v=0fd2848a";
import { AlertTriangle, ArrowLeft, Lock, Save, Search, Shield } from "/node_modules/.vite/deps/lucide-react.js?v=0fd2848a";
import { ROUTES } from "/src/config/routes.config.ts";
import { useRegistrarDenunciaMutation } from "/src/hooks/useOuvidoria.ts";
import { useEstabelecimentosList } from "/src/hooks/useEstabelecimentos.ts";
var _jsxFileName = "E:/Projetos VSCODE/visa_braunas/src/pages/ouvidoria/RegistrarDenunciaInternaPage.tsx";
import __vite__cjsImport9_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=0fd2848a";
var _s = $RefreshSig$();
const registrarDenunciaSchema = z.object({
	local_denunciado_identificacao: z.string().min(3, "Identificação do local denunciado é obrigatória (mínimo 3 caracteres)"),
	relato_denuncia: z.string().min(10, "Relato minucioso deve conter no mínimo 10 caracteres"),
	origem: z.enum([
		"formulario_web",
		"presencial",
		"telefone",
		"ouvidoria_geral",
		"oficio_ministerio"
	]),
	gravidade: z.enum([
		"baixa",
		"media",
		"alta",
		"urgente"
	]),
	estabelecimento_id: z.string().optional(),
	logradouro: z.string().optional(),
	numero: z.string().optional(),
	bairro: z.string().optional(),
	ponto_referencia: z.string().optional(),
	denunciante_anonimo: z.boolean(),
	denunciante_nome: z.string().optional(),
	denunciante_telefone: z.string().optional(),
	denunciante_email: z.string().email("E-mail inválido").optional().or(z.literal(""))
}).superRefine((data, ctx) => {
	if (!data.denunciante_anonimo) {
		if (!data.denunciante_nome || data.denunciante_nome.trim().length === 0) {
			ctx.addIssue({
				code: z.ZodIssueCode.custom,
				path: ["denunciante_nome"],
				message: "Informe o nome do denunciante quando a manifestação não for anônima."
			});
		}
	}
});
export const RegistrarDenunciaInternaPage = () => {
	_s();
	const navigate = useNavigate();
	const registrarMutation = useRegistrarDenunciaMutation();
	const [buscaEstabelecimento, setBuscaEstabelecimento] = useState("");
	const { data: estabelecimentosData } = useEstabelecimentosList({
		busca: buscaEstabelecimento || undefined,
		limit: 20,
		situacao: "Ativo"
	});
	const { register, handleSubmit, watch, setValue, formState: { errors, isSubmitting } } = useForm({
		resolver: zodResolver(registrarDenunciaSchema),
		defaultValues: {
			origem: "presencial",
			gravidade: "media",
			local_denunciado_identificacao: "",
			relato_denuncia: "",
			denunciante_anonimo: true,
			denunciante_nome: "",
			denunciante_telefone: "",
			denunciante_email: "",
			logradouro: "",
			numero: "",
			bairro: "",
			ponto_referencia: ""
		}
	});
	const denuncianteAnonimo = watch("denunciante_anonimo");
	const onSubmit = async (data) => {
		try {
			const payload = {
				local_denunciado_identificacao: data.local_denunciado_identificacao.trim(),
				relato_denuncia: data.relato_denuncia.trim(),
				origem: data.origem,
				gravidade: data.gravidade,
				estabelecimento_id: data.estabelecimento_id || null,
				logradouro: data.logradouro?.trim() || null,
				numero: data.numero?.trim() || null,
				bairro: data.bairro?.trim() || null,
				ponto_referencia: data.ponto_referencia?.trim() || null,
				denunciante_anonimo: data.denunciante_anonimo,
				denunciante_nome: data.denunciante_anonimo ? null : data.denunciante_nome?.trim() || null,
				denunciante_telefone: data.denunciante_anonimo ? null : data.denunciante_telefone?.trim() || null,
				denunciante_email: data.denunciante_anonimo ? null : data.denunciante_email?.trim() || null
			};
			const criada = await registrarMutation.mutateAsync(payload);
			navigate(ROUTES.OUVIDORIA.DETALHE(criada.id));
		} catch {}
	};
	const handleSelecionarEstabelecimento = (estId) => {
		setValue("estabelecimento_id", estId);
		const est = estabelecimentosData?.itens.find((e) => e.id === estId);
		if (est) {
			setValue("local_denunciado_identificacao", est.razao_social);
			setValue("logradouro", est.logradouro);
			setValue("numero", est.numero);
			setValue("bairro", est.bairro);
		}
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "space-y-6 max-w-4xl mx-auto pb-12",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex items-center justify-between",
				children: /* @__PURE__ */ _jsxDEV(Link, {
					to: ROUTES.OUVIDORIA.LIST,
					className: "inline-flex items-center gap-2 text-xs font-semibold text-slate-600 dark:text-slate-300 hover:text-teal-600 dark:hover:text-teal-400 transition-colors",
					children: [/* @__PURE__ */ _jsxDEV(ArrowLeft, { className: "w-4 h-4" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 153,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Voltar para Lista de Denúncias" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 154,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 149,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 148,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-xs space-y-2",
				children: [/* @__PURE__ */ _jsxDEV("h1", {
					className: "text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2",
					children: [/* @__PURE__ */ _jsxDEV(Shield, { className: "w-5 h-5 text-teal-600" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 160,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Registro Interno de Manifestação / Denúncia" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 161,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 159,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("p", {
					className: "text-xs text-slate-500 dark:text-slate-400",
					children: "Cadastro oficial de queixas recebidas pelo balcão da vigilância sanitária, linhas telefônicas ou ofícios de controle externo."
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 163,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 158,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("form", {
				onSubmit: handleSubmit(onSubmit),
				className: "space-y-6",
				children: [
					registrarMutation.isError && /* @__PURE__ */ _jsxDEV("div", {
						className: "p-4 bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 rounded-2xl flex items-center gap-2 text-xs text-rose-800 dark:text-rose-200",
						children: [/* @__PURE__ */ _jsxDEV(AlertTriangle, { className: "w-4 h-4 text-rose-600 shrink-0" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 171,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: registrarMutation.error instanceof Error ? registrarMutation.error.message : "Erro ao protocolar a denúncia." }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 172,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 170,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-xs space-y-4",
						children: [/* @__PURE__ */ _jsxDEV("h2", {
							className: "text-xs font-bold uppercase tracking-wider text-slate-900 dark:text-white border-b border-slate-100 dark:border-slate-800 pb-2",
							children: "1. Dados de Entrada & Classificação de Risco"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 182,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "grid grid-cols-1 sm:grid-cols-2 gap-4",
							children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1",
								children: ["Canal de Recebimento ", /* @__PURE__ */ _jsxDEV("span", {
									className: "text-rose-500",
									children: "*"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 189,
									columnNumber: 38
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 188,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("select", {
								...register("origem"),
								className: "w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-teal-500",
								children: [
									/* @__PURE__ */ _jsxDEV("option", {
										value: "presencial",
										children: "Atendimento Presencial (Balcão VISA)"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 195,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("option", {
										value: "telefone",
										children: "Atendimento Telefônico / Linha Direta"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 196,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("option", {
										value: "oficio_ministerio",
										children: "Ofício (Ministério Público / Órgãos)"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 197,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("option", {
										value: "ouvidoria_geral",
										children: "Ouvidoria Geral do Município"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 198,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("option", {
										value: "formulario_web",
										children: "Formulário Eletrônico Web"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 199,
										columnNumber: 17
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 191,
								columnNumber: 15
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 187,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1",
								children: ["Gravidade / Prioridade Preliminar ", /* @__PURE__ */ _jsxDEV("span", {
									className: "text-rose-500",
									children: "*"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 205,
									columnNumber: 51
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 204,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("select", {
								...register("gravidade"),
								className: "w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-teal-500 font-bold",
								children: [
									/* @__PURE__ */ _jsxDEV("option", {
										value: "baixa",
										children: "Baixa (Rotina secundária)"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 211,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("option", {
										value: "media",
										children: "Média (Padrão de triagem)"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 212,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("option", {
										value: "alta",
										children: "Alta (Risco sanitário significativo)"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 213,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("option", {
										value: "urgente",
										children: "Urgente (Risco iminente à saúde pública)"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 214,
										columnNumber: 17
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 207,
								columnNumber: 15
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 203,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 186,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 181,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-xs space-y-4",
						children: [
							/* @__PURE__ */ _jsxDEV("h2", {
								className: "text-xs font-bold uppercase tracking-wider text-slate-900 dark:text-white border-b border-slate-100 dark:border-slate-800 pb-2",
								children: "2. Local & Narrativa dos Fatos"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 222,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "space-y-2",
								children: [
									/* @__PURE__ */ _jsxDEV("label", {
										className: "block text-xs font-semibold text-slate-700 dark:text-slate-300",
										children: "Vincular a Estabelecimento Cadastrado (Opcional)"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 228,
										columnNumber: 13
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "flex gap-2",
										children: /* @__PURE__ */ _jsxDEV("div", {
											className: "relative flex-1",
											children: [/* @__PURE__ */ _jsxDEV(Search, { className: "w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 233,
												columnNumber: 17
											}, this), /* @__PURE__ */ _jsxDEV("input", {
												type: "text",
												placeholder: "Pesquisar estabelecimento por Razão Social ou CNPJ...",
												value: buscaEstabelecimento,
												onChange: (e) => setBuscaEstabelecimento(e.target.value),
												className: "w-full pl-8 pr-3 py-1.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-1 focus:ring-teal-500"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 234,
												columnNumber: 17
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 232,
											columnNumber: 15
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 231,
										columnNumber: 13
									}, this),
									estabelecimentosData && estabelecimentosData.itens.length > 0 && buscaEstabelecimento && /* @__PURE__ */ _jsxDEV("div", {
										className: "max-h-40 overflow-y-auto border border-slate-200 dark:border-slate-700 rounded-lg divide-y divide-slate-100 dark:divide-slate-800 text-xs bg-white dark:bg-slate-900",
										children: estabelecimentosData.itens.map((est) => /* @__PURE__ */ _jsxDEV("button", {
											type: "button",
											onClick: () => handleSelecionarEstabelecimento(est.id),
											className: "w-full text-left p-2.5 hover:bg-slate-50 dark:hover:bg-slate-800 flex items-center justify-between",
											children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("p", {
												className: "font-bold text-slate-900 dark:text-white",
												children: est.razao_social
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 254,
												columnNumber: 23
											}, this), /* @__PURE__ */ _jsxDEV("p", {
												className: "text-[10px] text-slate-400 font-mono",
												children: [
													"CNPJ/CPF: ",
													est.cnpj_cpf,
													" • ",
													est.bairro
												]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 255,
												columnNumber: 23
											}, this)] }, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 253,
												columnNumber: 21
											}, this), /* @__PURE__ */ _jsxDEV("span", {
												className: "text-[10px] text-teal-600 font-semibold",
												children: "Selecionar"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 259,
												columnNumber: 21
											}, this)]
										}, est.id, true, {
											fileName: _jsxFileName,
											lineNumber: 247,
											columnNumber: 19
										}, this))
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 245,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("input", {
										type: "hidden",
										...register("estabelecimento_id")
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 264,
										columnNumber: 13
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 227,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { children: [
								/* @__PURE__ */ _jsxDEV("label", {
									className: "block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1",
									children: ["Identificação do Local Denunciado (Nome da Empresa ou Descrição) ", /* @__PURE__ */ _jsxDEV("span", {
										className: "text-rose-500",
										children: "*"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 269,
										columnNumber: 80
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 268,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("input", {
									type: "text",
									...register("local_denunciado_identificacao"),
									placeholder: "Ex: Padaria Estrela da Manhã, Feira Livre Municipal, Residência com criação irregular...",
									className: "w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-teal-500"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 271,
									columnNumber: 13
								}, this),
								errors.local_denunciado_identificacao && /* @__PURE__ */ _jsxDEV("p", {
									className: "text-[11px] text-rose-600 mt-1",
									children: errors.local_denunciado_identificacao.message
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 278,
									columnNumber: 15
								}, this)
							] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 267,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "grid grid-cols-1 sm:grid-cols-3 gap-4",
								children: [
									/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
										className: "block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1",
										children: "Logradouro (Rua / Av.)"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 286,
										columnNumber: 15
									}, this), /* @__PURE__ */ _jsxDEV("input", {
										type: "text",
										...register("logradouro"),
										placeholder: "Rua...",
										className: "w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-teal-500"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 289,
										columnNumber: 15
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 285,
										columnNumber: 13
									}, this),
									/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
										className: "block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1",
										children: "Número"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 298,
										columnNumber: 15
									}, this), /* @__PURE__ */ _jsxDEV("input", {
										type: "text",
										...register("numero"),
										placeholder: "Nº ou S/N",
										className: "w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-teal-500"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 301,
										columnNumber: 15
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 297,
										columnNumber: 13
									}, this),
									/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
										className: "block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1",
										children: "Bairro"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 310,
										columnNumber: 15
									}, this), /* @__PURE__ */ _jsxDEV("input", {
										type: "text",
										...register("bairro"),
										placeholder: "Bairro...",
										className: "w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-teal-500"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 313,
										columnNumber: 15
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 309,
										columnNumber: 13
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 284,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { children: [
								/* @__PURE__ */ _jsxDEV("label", {
									className: "block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1",
									children: ["Relato Minucioso dos Fatos Denunciados ", /* @__PURE__ */ _jsxDEV("span", {
										className: "text-rose-500",
										children: "*"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 324,
										columnNumber: 54
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 323,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("textarea", {
									rows: 4,
									...register("relato_denuncia"),
									placeholder: "Descreva minuciosamente a irregularidade sanitária constatada, datas, condições dos produtos e riscos observados...",
									className: "w-full p-3 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-teal-500"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 326,
									columnNumber: 13
								}, this),
								errors.relato_denuncia && /* @__PURE__ */ _jsxDEV("p", {
									className: "text-[11px] text-rose-600 mt-1",
									children: errors.relato_denuncia.message
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 333,
									columnNumber: 15
								}, this)
							] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 322,
								columnNumber: 11
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 221,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-xs space-y-4",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-2",
							children: [/* @__PURE__ */ _jsxDEV("h2", {
								className: "text-xs font-bold uppercase tracking-wider text-slate-900 dark:text-white",
								children: "3. Dados do Denunciante & Sigilo Legal"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 343,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-2",
								children: /* @__PURE__ */ _jsxDEV("label", {
									className: "relative inline-flex items-center cursor-pointer",
									children: [
										/* @__PURE__ */ _jsxDEV("input", {
											type: "checkbox",
											...register("denunciante_anonimo"),
											className: "sr-only peer"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 348,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", { className: "w-9 h-5 bg-slate-200 peer-focus:outline-none rounded-full peer dark:bg-slate-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-teal-600" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 353,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("span", {
											className: "ml-2 text-xs font-semibold text-slate-700 dark:text-slate-300",
											children: "Denúncia Anônima"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 354,
											columnNumber: 17
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 347,
									columnNumber: 15
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 346,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 342,
							columnNumber: 11
						}, this), denuncianteAnonimo ? /* @__PURE__ */ _jsxDEV("div", {
							className: "p-3.5 bg-slate-50 dark:bg-slate-800/60 rounded-xl text-xs text-slate-600 dark:text-slate-400 flex items-center gap-2.5",
							children: [/* @__PURE__ */ _jsxDEV(Lock, { className: "w-4 h-4 text-slate-500 shrink-0" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 363,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: "A identidade do manifestante está protegida por sigilo legal. Nenhum dado pessoal será exigido ou registrado." }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 364,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 362,
							columnNumber: 13
						}, this) : /* @__PURE__ */ _jsxDEV("div", {
							className: "grid grid-cols-1 sm:grid-cols-3 gap-4 animate-in fade-in duration-150",
							children: [
								/* @__PURE__ */ _jsxDEV("div", { children: [
									/* @__PURE__ */ _jsxDEV("label", {
										className: "block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1",
										children: ["Nome Completo do Cidadão ", /* @__PURE__ */ _jsxDEV("span", {
											className: "text-rose-500",
											children: "*"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 372,
											columnNumber: 44
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 371,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("input", {
										type: "text",
										...register("denunciante_nome"),
										placeholder: "Nome do denunciante...",
										className: "w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-teal-500"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 374,
										columnNumber: 17
									}, this),
									errors.denunciante_nome && /* @__PURE__ */ _jsxDEV("p", {
										className: "text-[11px] text-rose-600 mt-1",
										children: errors.denunciante_nome.message
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 381,
										columnNumber: 19
									}, this)
								] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 370,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
									className: "block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1",
									children: "Telefone de Contato"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 388,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("input", {
									type: "text",
									...register("denunciante_telefone"),
									placeholder: "(33) 99999-9999",
									className: "w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-teal-500"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 391,
									columnNumber: 17
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 387,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
									className: "block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1",
									children: "E-mail do Cidadão"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 400,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("input", {
									type: "email",
									...register("denunciante_email"),
									placeholder: "cidadao@exemplo.com",
									className: "w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-teal-500"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 403,
									columnNumber: 17
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 399,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 369,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 341,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center justify-end gap-3 pt-2",
						children: [/* @__PURE__ */ _jsxDEV(Link, {
							to: ROUTES.OUVIDORIA.LIST,
							className: "px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl",
							children: "Cancelar"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 416,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							type: "submit",
							disabled: isSubmitting,
							className: "px-6 py-2.5 text-xs font-bold text-white bg-teal-600 hover:bg-teal-700 rounded-xl shadow-xs transition-colors flex items-center gap-2 disabled:opacity-60",
							children: [/* @__PURE__ */ _jsxDEV(Save, { className: "w-4 h-4" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 427,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: isSubmitting ? "Registrando..." : "Protocolar Denúncia Oficial" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 428,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 422,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 415,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 168,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 146,
		columnNumber: 5
	}, this);
};
_s(RegistrarDenunciaInternaPage, "dRAYTFG7CKrMzMyAWGkWmy1IQTg=", false, function() {
	return [
		useNavigate,
		useRegistrarDenunciaMutation,
		useEstabelecimentosList,
		useForm
	];
});
_c = RegistrarDenunciaInternaPage;
export default RegistrarDenunciaInternaPage;
var _c;
$RefreshReg$(_c, "RegistrarDenunciaInternaPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/ouvidoria/RegistrarDenunciaInternaPage.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("E:/Projetos VSCODE/visa_braunas/src/pages/ouvidoria/RegistrarDenunciaInternaPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("E:/Projetos VSCODE/visa_braunas/src/pages/ouvidoria/RegistrarDenunciaInternaPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "E:/Projetos VSCODE/visa_braunas/src/pages/ouvidoria/RegistrarDenunciaInternaPage.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7Ozs7O0FBT0EsT0FBTyxTQUFTLGdCQUFnQjtBQUNoQyxTQUFTLE1BQU0sbUJBQW1CO0FBQ2xDLFNBQVMsZUFBZTtBQUN4QixTQUFTLG1CQUFtQjtBQUM1QixZQUFZLE9BQU87QUFDbkIsU0FDRSxlQUNBLFdBRUEsTUFFQSxNQUNBLFFBQ0EsY0FHSztBQUNQLFNBQVMsY0FBYztBQUN2QixTQUFTLG9DQUFvQztBQUM3QyxTQUFTLCtCQUErQjs7OztBQUd4QyxNQUFNLDBCQUEwQixFQUM3QixPQUFPO0NBQ04sZ0NBQWdDLEVBQzdCLE9BQU8sQ0FBQyxDQUNSLElBQUksR0FBRyx1RUFBdUU7Q0FDakYsaUJBQWlCLEVBQ2QsT0FBTyxDQUFDLENBQ1IsSUFBSSxJQUFJLHNEQUFzRDtDQUNqRSxRQUFRLEVBQUUsS0FBSztFQUNiO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7Q0FDRixDQUFDO0NBQ0QsV0FBVyxFQUFFLEtBQUs7RUFBQztFQUFTO0VBQVM7RUFBUTtDQUFTLENBQUM7Q0FDdkQsb0JBQW9CLEVBQUUsT0FBTyxDQUFDLENBQUMsU0FBUztDQUV4QyxZQUFZLEVBQUUsT0FBTyxDQUFDLENBQUMsU0FBUztDQUNoQyxRQUFRLEVBQUUsT0FBTyxDQUFDLENBQUMsU0FBUztDQUM1QixRQUFRLEVBQUUsT0FBTyxDQUFDLENBQUMsU0FBUztDQUM1QixrQkFBa0IsRUFBRSxPQUFPLENBQUMsQ0FBQyxTQUFTO0NBRXRDLHFCQUFxQixFQUFFLFFBQVE7Q0FDL0Isa0JBQWtCLEVBQUUsT0FBTyxDQUFDLENBQUMsU0FBUztDQUN0QyxzQkFBc0IsRUFBRSxPQUFPLENBQUMsQ0FBQyxTQUFTO0NBQzFDLG1CQUFtQixFQUFFLE9BQU8sQ0FBQyxDQUFDLE1BQU0saUJBQWlCLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxHQUFHLEVBQUUsUUFBUSxFQUFFLENBQUM7QUFDcEYsQ0FBQyxDQUFDLENBQ0QsYUFBYSxNQUFNLFFBQVE7Q0FDMUIsSUFBSSxDQUFDLEtBQUsscUJBQXFCO0VBQzdCLElBQUksQ0FBQyxLQUFLLG9CQUFvQixLQUFLLGlCQUFpQixLQUFLLENBQUMsQ0FBQyxXQUFXLEdBQUc7R0FDdkUsSUFBSSxTQUFTO0lBQ1gsTUFBTSxFQUFFLGFBQWE7SUFDckIsTUFBTSxDQUFDLGtCQUFrQjtJQUN6QixTQUFTO0dBQ1gsQ0FBQztFQUNIO0NBQ0Y7QUFDRixDQUFDO0FBSUgsT0FBTyxNQUFNLHFDQUErQzs7Q0FDMUQsTUFBTSxXQUFXLFlBQVk7Q0FDN0IsTUFBTSxvQkFBb0IsNkJBQTZCO0NBQ3ZELE1BQU0sQ0FBQyxzQkFBc0IsMkJBQTJCLFNBQVMsRUFBRTtDQUVuRSxNQUFNLEVBQUUsTUFBTSx5QkFBeUIsd0JBQXdCO0VBQzdELE9BQU8sd0JBQXdCO0VBQy9CLE9BQU87RUFDUCxVQUFVO0NBQ1osQ0FBQztDQUVELE1BQU0sRUFDSixVQUNBLGNBQ0EsT0FDQSxVQUNBLFdBQVcsRUFBRSxRQUFRLG1CQUNuQixRQUEyQjtFQUM3QixVQUFVLFlBQVksdUJBQXVCO0VBQzdDLGVBQWU7R0FDYixRQUFRO0dBQ1IsV0FBVztHQUNYLGdDQUFnQztHQUNoQyxpQkFBaUI7R0FDakIscUJBQXFCO0dBQ3JCLGtCQUFrQjtHQUNsQixzQkFBc0I7R0FDdEIsbUJBQW1CO0dBQ25CLFlBQVk7R0FDWixRQUFRO0dBQ1IsUUFBUTtHQUNSLGtCQUFrQjtFQUNwQjtDQUNGLENBQUM7Q0FFRCxNQUFNLHFCQUFxQixNQUFNLHFCQUFxQjtDQUV0RCxNQUFNLFdBQVcsT0FBTyxTQUE0QjtFQUNsRCxJQUFJO0dBQ0YsTUFBTSxVQUFnQztJQUNwQyxnQ0FBZ0MsS0FBSywrQkFBK0IsS0FBSztJQUN6RSxpQkFBaUIsS0FBSyxnQkFBZ0IsS0FBSztJQUMzQyxRQUFRLEtBQUs7SUFDYixXQUFXLEtBQUs7SUFDaEIsb0JBQW9CLEtBQUssc0JBQXNCO0lBQy9DLFlBQVksS0FBSyxZQUFZLEtBQUssS0FBSztJQUN2QyxRQUFRLEtBQUssUUFBUSxLQUFLLEtBQUs7SUFDL0IsUUFBUSxLQUFLLFFBQVEsS0FBSyxLQUFLO0lBQy9CLGtCQUFrQixLQUFLLGtCQUFrQixLQUFLLEtBQUs7SUFDbkQscUJBQXFCLEtBQUs7SUFDMUIsa0JBQWtCLEtBQUssc0JBQXNCLE9BQU8sS0FBSyxrQkFBa0IsS0FBSyxLQUFLO0lBQ3JGLHNCQUFzQixLQUFLLHNCQUFzQixPQUFPLEtBQUssc0JBQXNCLEtBQUssS0FBSztJQUM3RixtQkFBbUIsS0FBSyxzQkFBc0IsT0FBTyxLQUFLLG1CQUFtQixLQUFLLEtBQUs7R0FDekY7R0FFQSxNQUFNLFNBQVMsTUFBTSxrQkFBa0IsWUFBWSxPQUFPO0dBQzFELFNBQVMsT0FBTyxVQUFVLFFBQVEsT0FBTyxFQUFFLENBQUM7RUFDOUMsUUFBUSxDQUVSO0NBQ0Y7Q0FFQSxNQUFNLG1DQUFtQyxVQUFrQjtFQUN6RCxTQUFTLHNCQUFzQixLQUFLO0VBQ3BDLE1BQU0sTUFBTSxzQkFBc0IsTUFBTSxNQUFNLE1BQU0sRUFBRSxPQUFPLEtBQUs7RUFDbEUsSUFBSSxLQUFLO0dBQ1AsU0FBUyxrQ0FBa0MsSUFBSSxZQUFZO0dBQzNELFNBQVMsY0FBYyxJQUFJLFVBQVU7R0FDckMsU0FBUyxVQUFVLElBQUksTUFBTTtHQUM3QixTQUFTLFVBQVUsSUFBSSxNQUFNO0VBQy9CO0NBQ0Y7Q0FFQSxPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQWY7R0FFRSx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUNiLHdCQUFDLE1BQUQ7S0FDRSxJQUFJLE9BQU8sVUFBVTtLQUNyQixXQUFVO2VBRlosQ0FJRSx3QkFBQyxXQUFELEVBQVcsV0FBVSxVQUFXOzs7O2VBQ2hDLHdCQUFDLFFBQUQsWUFBTSxpQ0FBb0M7Ozs7YUFDdEM7Ozs7OztHQUNIOzs7OztHQUVMLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxNQUFEO0tBQUksV0FBVTtlQUFkLENBQ0Usd0JBQUMsUUFBRCxFQUFRLFdBQVUsd0JBQXlCOzs7O2VBQzNDLHdCQUFDLFFBQUQsWUFBTSw4Q0FBaUQ7Ozs7YUFDckQ7Ozs7O2NBQ0osd0JBQUMsS0FBRDtLQUFHLFdBQVU7ZUFBNkM7SUFFdkQ7Ozs7WUFDQTs7Ozs7O0dBRUwsd0JBQUMsUUFBRDtJQUFNLFVBQVUsYUFBYSxRQUFRO0lBQUcsV0FBVTtjQUFsRDtLQUNHLGtCQUFrQixXQUNqQix3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLGVBQUQsRUFBZSxXQUFVLGlDQUFrQzs7OztnQkFDM0Qsd0JBQUMsUUFBRCxZQUNHLGtCQUFrQixpQkFBaUIsUUFDaEMsa0JBQWtCLE1BQU0sVUFDeEIsaUNBQ0E7Ozs7Y0FDSDs7Ozs7O0tBSVAsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxNQUFEO09BQUksV0FBVTtpQkFBaUk7TUFFM0k7Ozs7Z0JBRUosd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtRQUFPLFdBQVU7a0JBQWpCLENBQXVGLHlCQUNoRSx3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFBZ0I7UUFBTzs7OztnQkFDdkQ7Ozs7O2lCQUNQLHdCQUFDLFVBQUQ7UUFDRSxHQUFJLFNBQVMsUUFBUTtRQUNyQixXQUFVO2tCQUZaO1NBSUUsd0JBQUMsVUFBRDtVQUFRLE9BQU07b0JBQWE7U0FBNEM7Ozs7O1NBQ3ZFLHdCQUFDLFVBQUQ7VUFBUSxPQUFNO29CQUFXO1NBQTZDOzs7OztTQUN0RSx3QkFBQyxVQUFEO1VBQVEsT0FBTTtvQkFBb0I7U0FBNEM7Ozs7O1NBQzlFLHdCQUFDLFVBQUQ7VUFBUSxPQUFNO29CQUFrQjtTQUFvQzs7Ozs7U0FDcEUsd0JBQUMsVUFBRDtVQUFRLE9BQU07b0JBQWlCO1NBQWlDOzs7OztRQUMxRDs7Ozs7ZUFDTDs7OztpQkFFTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtRQUFPLFdBQVU7a0JBQWpCLENBQXVGLHNDQUNuRCx3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFBZ0I7UUFBTzs7OztnQkFDcEU7Ozs7O2lCQUNQLHdCQUFDLFVBQUQ7UUFDRSxHQUFJLFNBQVMsV0FBVztRQUN4QixXQUFVO2tCQUZaO1NBSUUsd0JBQUMsVUFBRDtVQUFRLE9BQU07b0JBQVE7U0FBaUM7Ozs7O1NBQ3ZELHdCQUFDLFVBQUQ7VUFBUSxPQUFNO29CQUFRO1NBQWlDOzs7OztTQUN2RCx3QkFBQyxVQUFEO1VBQVEsT0FBTTtvQkFBTztTQUE0Qzs7Ozs7U0FDakUsd0JBQUMsVUFBRDtVQUFRLE9BQU07b0JBQVU7U0FBZ0Q7Ozs7O1FBQ2xFOzs7OztlQUNMOzs7O2VBQ0Y7Ozs7O2NBQ0Y7Ozs7OztLQUdMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmO09BQ0Usd0JBQUMsTUFBRDtRQUFJLFdBQVU7a0JBQWlJO09BRTNJOzs7OztPQUdKLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmO1NBQ0Usd0JBQUMsU0FBRDtVQUFPLFdBQVU7b0JBQWlFO1NBRTNFOzs7OztTQUNQLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUNiLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUFmLENBQ0Usd0JBQUMsUUFBRCxFQUFRLFdBQVUscURBQXNEOzs7O3FCQUN4RSx3QkFBQyxTQUFEO1lBQ0UsTUFBSztZQUNMLGFBQVk7WUFDWixPQUFPO1lBQ1AsV0FBVyxNQUFNLHdCQUF3QixFQUFFLE9BQU8sS0FBSztZQUN2RCxXQUFVO1dBQ1g7Ozs7bUJBQ0U7Ozs7OztTQUNGOzs7OztTQUVKLHdCQUF3QixxQkFBcUIsTUFBTSxTQUFTLEtBQUssd0JBQ2hFLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUNaLHFCQUFxQixNQUFNLEtBQUssUUFDL0Isd0JBQUMsVUFBRDtXQUVFLE1BQUs7V0FDTCxlQUFlLGdDQUFnQyxJQUFJLEVBQUU7V0FDckQsV0FBVTtxQkFKWixDQU1FLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxLQUFEO1lBQUcsV0FBVTtzQkFBNEMsSUFBSTtXQUFnQjs7OztxQkFDN0Usd0JBQUMsS0FBRDtZQUFHLFdBQVU7c0JBQWI7YUFBb0Q7YUFDdkMsSUFBSTthQUFTO2FBQUksSUFBSTtZQUMvQjs7Ozs7bUJBQ0E7Ozs7cUJBQ0wsd0JBQUMsUUFBRDtZQUFNLFdBQVU7c0JBQTBDO1dBQWdCOzs7O21CQUNwRTthQVpELElBQUk7Ozs7aUJBWUgsQ0FDVDtTQUNFOzs7OztTQUVQLHdCQUFDLFNBQUQ7VUFBTyxNQUFLO1VBQVMsR0FBSSxTQUFTLG9CQUFvQjtTQUFJOzs7OztRQUN2RDs7Ozs7O09BRUwsd0JBQUMsT0FBRDtRQUNFLHdCQUFDLFNBQUQ7U0FBTyxXQUFVO21CQUFqQixDQUF1RixxRUFDcEIsd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQWdCO1NBQU87Ozs7aUJBQ25HOzs7Ozs7UUFDUCx3QkFBQyxTQUFEO1NBQ0UsTUFBSztTQUNMLEdBQUksU0FBUyxnQ0FBZ0M7U0FDN0MsYUFBWTtTQUNaLFdBQVU7UUFDWDs7Ozs7UUFDQSxPQUFPLGtDQUNOLHdCQUFDLEtBQUQ7U0FBRyxXQUFVO21CQUNWLE9BQU8sK0JBQStCO1FBQ3RDOzs7OztPQUVGOzs7OztPQUVMLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmO1NBQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7VUFBTyxXQUFVO29CQUFzRTtTQUVoRjs7OzttQkFDUCx3QkFBQyxTQUFEO1VBQ0UsTUFBSztVQUNMLEdBQUksU0FBUyxZQUFZO1VBQ3pCLGFBQVk7VUFDWixXQUFVO1NBQ1g7Ozs7aUJBQ0U7Ozs7O1NBRUwsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7VUFBTyxXQUFVO29CQUFzRTtTQUVoRjs7OzttQkFDUCx3QkFBQyxTQUFEO1VBQ0UsTUFBSztVQUNMLEdBQUksU0FBUyxRQUFRO1VBQ3JCLGFBQVk7VUFDWixXQUFVO1NBQ1g7Ozs7aUJBQ0U7Ozs7O1NBRUwsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7VUFBTyxXQUFVO29CQUFzRTtTQUVoRjs7OzttQkFDUCx3QkFBQyxTQUFEO1VBQ0UsTUFBSztVQUNMLEdBQUksU0FBUyxRQUFRO1VBQ3JCLGFBQVk7VUFDWixXQUFVO1NBQ1g7Ozs7aUJBQ0U7Ozs7O1FBQ0Y7Ozs7OztPQUVMLHdCQUFDLE9BQUQ7UUFDRSx3QkFBQyxTQUFEO1NBQU8sV0FBVTttQkFBakIsQ0FBdUYsMkNBQzlDLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUFnQjtTQUFPOzs7O2lCQUN6RTs7Ozs7O1FBQ1Asd0JBQUMsWUFBRDtTQUNFLE1BQU07U0FDTixHQUFJLFNBQVMsaUJBQWlCO1NBQzlCLGFBQVk7U0FDWixXQUFVO1FBQ1g7Ozs7O1FBQ0EsT0FBTyxtQkFDTix3QkFBQyxLQUFEO1NBQUcsV0FBVTttQkFDVixPQUFPLGdCQUFnQjtRQUN2Qjs7Ozs7T0FFRjs7Ozs7TUFDRjs7Ozs7O0tBR0wsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLE1BQUQ7UUFBSSxXQUFVO2tCQUE0RTtPQUV0Rjs7OztpQkFDSix3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFDYix3QkFBQyxTQUFEO1NBQU8sV0FBVTttQkFBakI7VUFDRSx3QkFBQyxTQUFEO1dBQ0UsTUFBSztXQUNMLEdBQUksU0FBUyxxQkFBcUI7V0FDbEMsV0FBVTtVQUNYOzs7OztVQUNELHdCQUFDLE9BQUQsRUFBSyxXQUFVLGtXQUFtVzs7Ozs7VUFDbFgsd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQWdFO1VBRTFFOzs7OztTQUNEOzs7Ozs7T0FDSjs7OztlQUNGOzs7OztnQkFFSixxQkFDQyx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLE1BQUQsRUFBTSxXQUFVLGtDQUFtQzs7OztpQkFDbkQsd0JBQUMsUUFBRCxZQUFNLGdIQUVBOzs7O2VBQ0g7Ozs7O2lCQUVMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmO1FBQ0Usd0JBQUMsT0FBRDtTQUNFLHdCQUFDLFNBQUQ7VUFBTyxXQUFVO29CQUFqQixDQUF1Riw2QkFDNUQsd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQWdCO1VBQU87Ozs7a0JBQzNEOzs7Ozs7U0FDUCx3QkFBQyxTQUFEO1VBQ0UsTUFBSztVQUNMLEdBQUksU0FBUyxrQkFBa0I7VUFDL0IsYUFBWTtVQUNaLFdBQVU7U0FDWDs7Ozs7U0FDQSxPQUFPLG9CQUNOLHdCQUFDLEtBQUQ7VUFBRyxXQUFVO29CQUNWLE9BQU8saUJBQWlCO1NBQ3hCOzs7OztRQUVGOzs7OztRQUVMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO1NBQU8sV0FBVTttQkFBc0U7UUFFaEY7Ozs7a0JBQ1Asd0JBQUMsU0FBRDtTQUNFLE1BQUs7U0FDTCxHQUFJLFNBQVMsc0JBQXNCO1NBQ25DLGFBQVk7U0FDWixXQUFVO1FBQ1g7Ozs7Z0JBQ0U7Ozs7O1FBRUwsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7U0FBTyxXQUFVO21CQUFzRTtRQUVoRjs7OztrQkFDUCx3QkFBQyxTQUFEO1NBQ0UsTUFBSztTQUNMLEdBQUksU0FBUyxtQkFBbUI7U0FDaEMsYUFBWTtTQUNaLFdBQVU7UUFDWDs7OztnQkFDRTs7Ozs7T0FDRjs7Ozs7Y0FFSjs7Ozs7O0tBR0wsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxNQUFEO09BQ0UsSUFBSSxPQUFPLFVBQVU7T0FDckIsV0FBVTtpQkFDWDtNQUVLOzs7O2dCQUNOLHdCQUFDLFVBQUQ7T0FDRSxNQUFLO09BQ0wsVUFBVTtPQUNWLFdBQVU7aUJBSFosQ0FLRSx3QkFBQyxNQUFELEVBQU0sV0FBVSxVQUFXOzs7O2lCQUMzQix3QkFBQyxRQUFELFlBQU8sZUFBZSxtQkFBbUIsOEJBQW9DOzs7O2VBQ3ZFOzs7OztjQUNMOzs7Ozs7SUFDRDs7Ozs7O0VBQ0g7Ozs7OztBQUVUOzs7Ozs7Ozs7O0FBRUEsZUFBZSIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJSZWdpc3RyYXJEZW51bmNpYUludGVybmFQYWdlLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyIvKipcclxuICogRm9ybXVsw6FyaW8gQWRtaW5pc3RyYXRpdm8gSW50ZXJubyBkZSBSZWdpc3RybyBkZSBEZW7Dum5jaWEgU2FuaXTDoXJpYVxyXG4gKiBSb3RhOiAvb3V2aWRvcmlhL25vdmFcclxuICogVXNhZG8gcG9yIHNlcnZpZG9yZXMgbXVuaWNpcGFpcyBwYXJhIHJlZ2lzdHJhciBtYW5pZmVzdGHDp8O1ZXMgcmVjZWJpZGFzXHJcbiAqIHBvciB0ZWxlZm9uZSwgYXRlbmRpbWVudG8gcHJlc2VuY2lhbCBkZSBiYWxjw6NvIG91IG9mw61jaW9zIGRlIMOzcmfDo29zIGRlIGNvbnRyb2xlLlxyXG4gKi9cclxuXHJcbmltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgeyBMaW5rLCB1c2VOYXZpZ2F0ZSB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCI7XHJcbmltcG9ydCB7IHVzZUZvcm0gfSBmcm9tIFwicmVhY3QtaG9vay1mb3JtXCI7XHJcbmltcG9ydCB7IHpvZFJlc29sdmVyIH0gZnJvbSBcIkBob29rZm9ybS9yZXNvbHZlcnMvem9kXCI7XHJcbmltcG9ydCAqIGFzIHogZnJvbSBcInpvZFwiO1xyXG5pbXBvcnQge1xyXG4gIEFsZXJ0VHJpYW5nbGUsXHJcbiAgQXJyb3dMZWZ0LFxyXG4gIEJ1aWxkaW5nMixcclxuICBMb2NrLFxyXG4gIFBsdXMsXHJcbiAgU2F2ZSxcclxuICBTZWFyY2gsXHJcbiAgU2hpZWxkLFxyXG4gIFNoaWVsZENoZWNrLFxyXG4gIFVzZXIsXHJcbn0gZnJvbSBcImx1Y2lkZS1yZWFjdFwiO1xyXG5pbXBvcnQgeyBST1VURVMgfSBmcm9tIFwiLi4vLi4vY29uZmlnL3JvdXRlcy5jb25maWdcIjtcclxuaW1wb3J0IHsgdXNlUmVnaXN0cmFyRGVudW5jaWFNdXRhdGlvbiB9IGZyb20gXCIuLi8uLi9ob29rcy91c2VPdXZpZG9yaWFcIjtcclxuaW1wb3J0IHsgdXNlRXN0YWJlbGVjaW1lbnRvc0xpc3QgfSBmcm9tIFwiLi4vLi4vaG9va3MvdXNlRXN0YWJlbGVjaW1lbnRvc1wiO1xyXG5pbXBvcnQgeyBDYW5hbERlbnVuY2lhLCBHcmF2aWRhZGVEZW51bmNpYSwgUmVnaXN0cmFyRGVudW5jaWFEVE8gfSBmcm9tIFwiLi4vLi4vdHlwZXMvb3V2aWRvcmlhXCI7XHJcblxyXG5jb25zdCByZWdpc3RyYXJEZW51bmNpYVNjaGVtYSA9IHpcclxuICAub2JqZWN0KHtcclxuICAgIGxvY2FsX2RlbnVuY2lhZG9faWRlbnRpZmljYWNhbzogelxyXG4gICAgICAuc3RyaW5nKClcclxuICAgICAgLm1pbigzLCBcIklkZW50aWZpY2HDp8OjbyBkbyBsb2NhbCBkZW51bmNpYWRvIMOpIG9icmlnYXTDs3JpYSAobcOtbmltbyAzIGNhcmFjdGVyZXMpXCIpLFxyXG4gICAgcmVsYXRvX2RlbnVuY2lhOiB6XHJcbiAgICAgIC5zdHJpbmcoKVxyXG4gICAgICAubWluKDEwLCBcIlJlbGF0byBtaW51Y2lvc28gZGV2ZSBjb250ZXIgbm8gbcOtbmltbyAxMCBjYXJhY3RlcmVzXCIpLFxyXG4gICAgb3JpZ2VtOiB6LmVudW0oW1xyXG4gICAgICBcImZvcm11bGFyaW9fd2ViXCIsXHJcbiAgICAgIFwicHJlc2VuY2lhbFwiLFxyXG4gICAgICBcInRlbGVmb25lXCIsXHJcbiAgICAgIFwib3V2aWRvcmlhX2dlcmFsXCIsXHJcbiAgICAgIFwib2ZpY2lvX21pbmlzdGVyaW9cIixcclxuICAgIF0pLFxyXG4gICAgZ3JhdmlkYWRlOiB6LmVudW0oW1wiYmFpeGFcIiwgXCJtZWRpYVwiLCBcImFsdGFcIiwgXCJ1cmdlbnRlXCJdKSxcclxuICAgIGVzdGFiZWxlY2ltZW50b19pZDogei5zdHJpbmcoKS5vcHRpb25hbCgpLFxyXG5cclxuICAgIGxvZ3JhZG91cm86IHouc3RyaW5nKCkub3B0aW9uYWwoKSxcclxuICAgIG51bWVybzogei5zdHJpbmcoKS5vcHRpb25hbCgpLFxyXG4gICAgYmFpcnJvOiB6LnN0cmluZygpLm9wdGlvbmFsKCksXHJcbiAgICBwb250b19yZWZlcmVuY2lhOiB6LnN0cmluZygpLm9wdGlvbmFsKCksXHJcblxyXG4gICAgZGVudW5jaWFudGVfYW5vbmltbzogei5ib29sZWFuKCksXHJcbiAgICBkZW51bmNpYW50ZV9ub21lOiB6LnN0cmluZygpLm9wdGlvbmFsKCksXHJcbiAgICBkZW51bmNpYW50ZV90ZWxlZm9uZTogei5zdHJpbmcoKS5vcHRpb25hbCgpLFxyXG4gICAgZGVudW5jaWFudGVfZW1haWw6IHouc3RyaW5nKCkuZW1haWwoXCJFLW1haWwgaW52w6FsaWRvXCIpLm9wdGlvbmFsKCkub3Ioei5saXRlcmFsKFwiXCIpKSxcclxuICB9KVxyXG4gIC5zdXBlclJlZmluZSgoZGF0YSwgY3R4KSA9PiB7XHJcbiAgICBpZiAoIWRhdGEuZGVudW5jaWFudGVfYW5vbmltbykge1xyXG4gICAgICBpZiAoIWRhdGEuZGVudW5jaWFudGVfbm9tZSB8fCBkYXRhLmRlbnVuY2lhbnRlX25vbWUudHJpbSgpLmxlbmd0aCA9PT0gMCkge1xyXG4gICAgICAgIGN0eC5hZGRJc3N1ZSh7XHJcbiAgICAgICAgICBjb2RlOiB6LlpvZElzc3VlQ29kZS5jdXN0b20sXHJcbiAgICAgICAgICBwYXRoOiBbXCJkZW51bmNpYW50ZV9ub21lXCJdLFxyXG4gICAgICAgICAgbWVzc2FnZTogXCJJbmZvcm1lIG8gbm9tZSBkbyBkZW51bmNpYW50ZSBxdWFuZG8gYSBtYW5pZmVzdGHDp8OjbyBuw6NvIGZvciBhbsO0bmltYS5cIixcclxuICAgICAgICB9KTtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH0pO1xyXG5cclxudHlwZSBSZWdpc3RyYXJGb3JtRGF0YSA9IHouaW5mZXI8dHlwZW9mIHJlZ2lzdHJhckRlbnVuY2lhU2NoZW1hPjtcclxuXHJcbmV4cG9ydCBjb25zdCBSZWdpc3RyYXJEZW51bmNpYUludGVybmFQYWdlOiBSZWFjdC5GQyA9ICgpID0+IHtcclxuICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKCk7XHJcbiAgY29uc3QgcmVnaXN0cmFyTXV0YXRpb24gPSB1c2VSZWdpc3RyYXJEZW51bmNpYU11dGF0aW9uKCk7XHJcbiAgY29uc3QgW2J1c2NhRXN0YWJlbGVjaW1lbnRvLCBzZXRCdXNjYUVzdGFiZWxlY2ltZW50b10gPSB1c2VTdGF0ZShcIlwiKTtcclxuXHJcbiAgY29uc3QgeyBkYXRhOiBlc3RhYmVsZWNpbWVudG9zRGF0YSB9ID0gdXNlRXN0YWJlbGVjaW1lbnRvc0xpc3Qoe1xyXG4gICAgYnVzY2E6IGJ1c2NhRXN0YWJlbGVjaW1lbnRvIHx8IHVuZGVmaW5lZCxcclxuICAgIGxpbWl0OiAyMCxcclxuICAgIHNpdHVhY2FvOiBcIkF0aXZvXCIsXHJcbiAgfSk7XHJcblxyXG4gIGNvbnN0IHtcclxuICAgIHJlZ2lzdGVyLFxyXG4gICAgaGFuZGxlU3VibWl0LFxyXG4gICAgd2F0Y2gsXHJcbiAgICBzZXRWYWx1ZSxcclxuICAgIGZvcm1TdGF0ZTogeyBlcnJvcnMsIGlzU3VibWl0dGluZyB9LFxyXG4gIH0gPSB1c2VGb3JtPFJlZ2lzdHJhckZvcm1EYXRhPih7XHJcbiAgICByZXNvbHZlcjogem9kUmVzb2x2ZXIocmVnaXN0cmFyRGVudW5jaWFTY2hlbWEpLFxyXG4gICAgZGVmYXVsdFZhbHVlczoge1xyXG4gICAgICBvcmlnZW06IFwicHJlc2VuY2lhbFwiLFxyXG4gICAgICBncmF2aWRhZGU6IFwibWVkaWFcIixcclxuICAgICAgbG9jYWxfZGVudW5jaWFkb19pZGVudGlmaWNhY2FvOiBcIlwiLFxyXG4gICAgICByZWxhdG9fZGVudW5jaWE6IFwiXCIsXHJcbiAgICAgIGRlbnVuY2lhbnRlX2Fub25pbW86IHRydWUsXHJcbiAgICAgIGRlbnVuY2lhbnRlX25vbWU6IFwiXCIsXHJcbiAgICAgIGRlbnVuY2lhbnRlX3RlbGVmb25lOiBcIlwiLFxyXG4gICAgICBkZW51bmNpYW50ZV9lbWFpbDogXCJcIixcclxuICAgICAgbG9ncmFkb3VybzogXCJcIixcclxuICAgICAgbnVtZXJvOiBcIlwiLFxyXG4gICAgICBiYWlycm86IFwiXCIsXHJcbiAgICAgIHBvbnRvX3JlZmVyZW5jaWE6IFwiXCIsXHJcbiAgICB9LFxyXG4gIH0pO1xyXG5cclxuICBjb25zdCBkZW51bmNpYW50ZUFub25pbW8gPSB3YXRjaChcImRlbnVuY2lhbnRlX2Fub25pbW9cIik7XHJcblxyXG4gIGNvbnN0IG9uU3VibWl0ID0gYXN5bmMgKGRhdGE6IFJlZ2lzdHJhckZvcm1EYXRhKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCBwYXlsb2FkOiBSZWdpc3RyYXJEZW51bmNpYURUTyA9IHtcclxuICAgICAgICBsb2NhbF9kZW51bmNpYWRvX2lkZW50aWZpY2FjYW86IGRhdGEubG9jYWxfZGVudW5jaWFkb19pZGVudGlmaWNhY2FvLnRyaW0oKSxcclxuICAgICAgICByZWxhdG9fZGVudW5jaWE6IGRhdGEucmVsYXRvX2RlbnVuY2lhLnRyaW0oKSxcclxuICAgICAgICBvcmlnZW06IGRhdGEub3JpZ2VtIGFzIENhbmFsRGVudW5jaWEsXHJcbiAgICAgICAgZ3JhdmlkYWRlOiBkYXRhLmdyYXZpZGFkZSBhcyBHcmF2aWRhZGVEZW51bmNpYSxcclxuICAgICAgICBlc3RhYmVsZWNpbWVudG9faWQ6IGRhdGEuZXN0YWJlbGVjaW1lbnRvX2lkIHx8IG51bGwsXHJcbiAgICAgICAgbG9ncmFkb3VybzogZGF0YS5sb2dyYWRvdXJvPy50cmltKCkgfHwgbnVsbCxcclxuICAgICAgICBudW1lcm86IGRhdGEubnVtZXJvPy50cmltKCkgfHwgbnVsbCxcclxuICAgICAgICBiYWlycm86IGRhdGEuYmFpcnJvPy50cmltKCkgfHwgbnVsbCxcclxuICAgICAgICBwb250b19yZWZlcmVuY2lhOiBkYXRhLnBvbnRvX3JlZmVyZW5jaWE/LnRyaW0oKSB8fCBudWxsLFxyXG4gICAgICAgIGRlbnVuY2lhbnRlX2Fub25pbW86IGRhdGEuZGVudW5jaWFudGVfYW5vbmltbyxcclxuICAgICAgICBkZW51bmNpYW50ZV9ub21lOiBkYXRhLmRlbnVuY2lhbnRlX2Fub25pbW8gPyBudWxsIDogZGF0YS5kZW51bmNpYW50ZV9ub21lPy50cmltKCkgfHwgbnVsbCxcclxuICAgICAgICBkZW51bmNpYW50ZV90ZWxlZm9uZTogZGF0YS5kZW51bmNpYW50ZV9hbm9uaW1vID8gbnVsbCA6IGRhdGEuZGVudW5jaWFudGVfdGVsZWZvbmU/LnRyaW0oKSB8fCBudWxsLFxyXG4gICAgICAgIGRlbnVuY2lhbnRlX2VtYWlsOiBkYXRhLmRlbnVuY2lhbnRlX2Fub25pbW8gPyBudWxsIDogZGF0YS5kZW51bmNpYW50ZV9lbWFpbD8udHJpbSgpIHx8IG51bGwsXHJcbiAgICAgIH07XHJcblxyXG4gICAgICBjb25zdCBjcmlhZGEgPSBhd2FpdCByZWdpc3RyYXJNdXRhdGlvbi5tdXRhdGVBc3luYyhwYXlsb2FkKTtcclxuICAgICAgbmF2aWdhdGUoUk9VVEVTLk9VVklET1JJQS5ERVRBTEhFKGNyaWFkYS5pZCkpO1xyXG4gICAgfSBjYXRjaCB7XHJcbiAgICAgIC8vIEVycm8gw6kgdHJhdGFkbyBwZWxvIHJlYWN0LXF1ZXJ5XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlU2VsZWNpb25hckVzdGFiZWxlY2ltZW50byA9IChlc3RJZDogc3RyaW5nKSA9PiB7XHJcbiAgICBzZXRWYWx1ZShcImVzdGFiZWxlY2ltZW50b19pZFwiLCBlc3RJZCk7XHJcbiAgICBjb25zdCBlc3QgPSBlc3RhYmVsZWNpbWVudG9zRGF0YT8uaXRlbnMuZmluZCgoZSkgPT4gZS5pZCA9PT0gZXN0SWQpO1xyXG4gICAgaWYgKGVzdCkge1xyXG4gICAgICBzZXRWYWx1ZShcImxvY2FsX2RlbnVuY2lhZG9faWRlbnRpZmljYWNhb1wiLCBlc3QucmF6YW9fc29jaWFsKTtcclxuICAgICAgc2V0VmFsdWUoXCJsb2dyYWRvdXJvXCIsIGVzdC5sb2dyYWRvdXJvKTtcclxuICAgICAgc2V0VmFsdWUoXCJudW1lcm9cIiwgZXN0Lm51bWVybyk7XHJcbiAgICAgIHNldFZhbHVlKFwiYmFpcnJvXCIsIGVzdC5iYWlycm8pO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNiBtYXgtdy00eGwgbXgtYXV0byBwYi0xMlwiPlxyXG4gICAgICB7LyogVG9wbyAqL31cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cclxuICAgICAgICA8TGlua1xyXG4gICAgICAgICAgdG89e1JPVVRFUy5PVVZJRE9SSUEuTElTVH1cclxuICAgICAgICAgIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS02MDAgZGFyazp0ZXh0LXNsYXRlLTMwMCBob3Zlcjp0ZXh0LXRlYWwtNjAwIGRhcms6aG92ZXI6dGV4dC10ZWFsLTQwMCB0cmFuc2l0aW9uLWNvbG9yc1wiXHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgPEFycm93TGVmdCBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz5cclxuICAgICAgICAgIDxzcGFuPlZvbHRhciBwYXJhIExpc3RhIGRlIERlbsO6bmNpYXM8L3NwYW4+XHJcbiAgICAgICAgPC9MaW5rPlxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGFyazpiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtODAwIHJvdW5kZWQtMnhsIHAtNiBzaGFkb3cteHMgc3BhY2UteS0yXCI+XHJcbiAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1ib2xkIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgPFNoaWVsZCBjbGFzc05hbWU9XCJ3LTUgaC01IHRleHQtdGVhbC02MDBcIiAvPlxyXG4gICAgICAgICAgPHNwYW4+UmVnaXN0cm8gSW50ZXJubyBkZSBNYW5pZmVzdGHDp8OjbyAvIERlbsO6bmNpYTwvc3Bhbj5cclxuICAgICAgICA8L2gxPlxyXG4gICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS01MDAgZGFyazp0ZXh0LXNsYXRlLTQwMFwiPlxyXG4gICAgICAgICAgQ2FkYXN0cm8gb2ZpY2lhbCBkZSBxdWVpeGFzIHJlY2ViaWRhcyBwZWxvIGJhbGPDo28gZGEgdmlnaWzDom5jaWEgc2FuaXTDoXJpYSwgbGluaGFzIHRlbGVmw7RuaWNhcyBvdSBvZsOtY2lvcyBkZSBjb250cm9sZSBleHRlcm5vLlxyXG4gICAgICAgIDwvcD5cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICA8Zm9ybSBvblN1Ym1pdD17aGFuZGxlU3VibWl0KG9uU3VibWl0KX0gY2xhc3NOYW1lPVwic3BhY2UteS02XCI+XHJcbiAgICAgICAge3JlZ2lzdHJhck11dGF0aW9uLmlzRXJyb3IgJiYgKFxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTQgYmctcm9zZS01MCBkYXJrOmJnLXJvc2UtOTUwLzQwIGJvcmRlciBib3JkZXItcm9zZS0yMDAgZGFyazpib3JkZXItcm9zZS04MDAgcm91bmRlZC0yeGwgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdGV4dC14cyB0ZXh0LXJvc2UtODAwIGRhcms6dGV4dC1yb3NlLTIwMFwiPlxyXG4gICAgICAgICAgICA8QWxlcnRUcmlhbmdsZSBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtcm9zZS02MDAgc2hyaW5rLTBcIiAvPlxyXG4gICAgICAgICAgICA8c3Bhbj5cclxuICAgICAgICAgICAgICB7cmVnaXN0cmFyTXV0YXRpb24uZXJyb3IgaW5zdGFuY2VvZiBFcnJvclxyXG4gICAgICAgICAgICAgICAgPyByZWdpc3RyYXJNdXRhdGlvbi5lcnJvci5tZXNzYWdlXHJcbiAgICAgICAgICAgICAgICA6IFwiRXJybyBhbyBwcm90b2NvbGFyIGEgZGVuw7puY2lhLlwifVxyXG4gICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICApfVxyXG5cclxuICAgICAgICB7LyogQmxvY28gMTogUGFyw6JtZXRyb3MgZGEgTWFuaWZlc3Rhw6fDo28gKi99XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC0yeGwgcC02IHNoYWRvdy14cyBzcGFjZS15LTRcIj5cclxuICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlIGJvcmRlci1iIGJvcmRlci1zbGF0ZS0xMDAgZGFyazpib3JkZXItc2xhdGUtODAwIHBiLTJcIj5cclxuICAgICAgICAgICAgMS4gRGFkb3MgZGUgRW50cmFkYSAmIENsYXNzaWZpY2HDp8OjbyBkZSBSaXNjb1xyXG4gICAgICAgICAgPC9oMj5cclxuXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgc206Z3JpZC1jb2xzLTIgZ2FwLTRcIj5cclxuICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0zMDAgbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgQ2FuYWwgZGUgUmVjZWJpbWVudG8gPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yb3NlLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICA8c2VsZWN0XHJcbiAgICAgICAgICAgICAgICB7Li4ucmVnaXN0ZXIoXCJvcmlnZW1cIil9XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIHRleHQteHMgYmctc2xhdGUtNTAgZGFyazpiZy1zbGF0ZS04MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQtbGcgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy10ZWFsLTUwMFwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cInByZXNlbmNpYWxcIj5BdGVuZGltZW50byBQcmVzZW5jaWFsIChCYWxjw6NvIFZJU0EpPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwidGVsZWZvbmVcIj5BdGVuZGltZW50byBUZWxlZsO0bmljbyAvIExpbmhhIERpcmV0YTwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIm9maWNpb19taW5pc3RlcmlvXCI+T2bDrWNpbyAoTWluaXN0w6lyaW8gUMO6YmxpY28gLyDDk3Jnw6Nvcyk8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJvdXZpZG9yaWFfZ2VyYWxcIj5PdXZpZG9yaWEgR2VyYWwgZG8gTXVuaWPDrXBpbzwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cImZvcm11bGFyaW9fd2ViXCI+Rm9ybXVsw6FyaW8gRWxldHLDtG5pY28gV2ViPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgPC9zZWxlY3Q+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0zMDAgbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgR3JhdmlkYWRlIC8gUHJpb3JpZGFkZSBQcmVsaW1pbmFyIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcm9zZS01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPHNlbGVjdFxyXG4gICAgICAgICAgICAgICAgey4uLnJlZ2lzdGVyKFwiZ3JhdmlkYWRlXCIpfVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMgcHktMiB0ZXh0LXhzIGJnLXNsYXRlLTUwIGRhcms6Ymctc2xhdGUtODAwIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCByb3VuZGVkLWxnIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZSBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctdGVhbC01MDAgZm9udC1ib2xkXCJcclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiYmFpeGFcIj5CYWl4YSAoUm90aW5hIHNlY3VuZMOhcmlhKTwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIm1lZGlhXCI+TcOpZGlhIChQYWRyw6NvIGRlIHRyaWFnZW0pPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiYWx0YVwiPkFsdGEgKFJpc2NvIHNhbml0w6FyaW8gc2lnbmlmaWNhdGl2byk8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJ1cmdlbnRlXCI+VXJnZW50ZSAoUmlzY28gaW1pbmVudGUgw6Agc2HDumRlIHDDumJsaWNhKTwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgIDwvc2VsZWN0PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICB7LyogQmxvY28gMjogTG9jYWwgZSBGYXRvcyBEZW51bmNpYWRvcyAqL31cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIGRhcms6Ymctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLTJ4bCBwLTYgc2hhZG93LXhzIHNwYWNlLXktNFwiPlxyXG4gICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGUgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTEwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgcGItMlwiPlxyXG4gICAgICAgICAgICAyLiBMb2NhbCAmIE5hcnJhdGl2YSBkb3MgRmF0b3NcclxuICAgICAgICAgIDwvaDI+XHJcblxyXG4gICAgICAgICAgey8qIFbDrW5jdWxvIE9wY2lvbmFsIGNvbSBFc3RhYmVsZWNpbWVudG8gZG8gQ2F0w6Fsb2dvICovfVxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTJcIj5cclxuICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMzAwXCI+XHJcbiAgICAgICAgICAgICAgVmluY3VsYXIgYSBFc3RhYmVsZWNpbWVudG8gQ2FkYXN0cmFkbyAoT3BjaW9uYWwpXHJcbiAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgZmxleC0xXCI+XHJcbiAgICAgICAgICAgICAgICA8U2VhcmNoIGNsYXNzTmFtZT1cInctMy41IGgtMy41IHRleHQtc2xhdGUtNDAwIGFic29sdXRlIGxlZnQtMyB0b3AtMi41XCIgLz5cclxuICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiUGVzcXVpc2FyIGVzdGFiZWxlY2ltZW50byBwb3IgUmF6w6NvIFNvY2lhbCBvdSBDTlBKLi4uXCJcclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e2J1c2NhRXN0YWJlbGVjaW1lbnRvfVxyXG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEJ1c2NhRXN0YWJlbGVjaW1lbnRvKGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHBsLTggcHItMyBweS0xLjUgdGV4dC14cyBiZy1zbGF0ZS01MCBkYXJrOmJnLXNsYXRlLTgwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC1sZyB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGUgcGxhY2Vob2xkZXItc2xhdGUtNDAwIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTEgZm9jdXM6cmluZy10ZWFsLTUwMFwiXHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIHtlc3RhYmVsZWNpbWVudG9zRGF0YSAmJiBlc3RhYmVsZWNpbWVudG9zRGF0YS5pdGVucy5sZW5ndGggPiAwICYmIGJ1c2NhRXN0YWJlbGVjaW1lbnRvICYmIChcclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1heC1oLTQwIG92ZXJmbG93LXktYXV0byBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC1sZyBkaXZpZGUteSBkaXZpZGUtc2xhdGUtMTAwIGRhcms6ZGl2aWRlLXNsYXRlLTgwMCB0ZXh0LXhzIGJnLXdoaXRlIGRhcms6Ymctc2xhdGUtOTAwXCI+XHJcbiAgICAgICAgICAgICAgICB7ZXN0YWJlbGVjaW1lbnRvc0RhdGEuaXRlbnMubWFwKChlc3QpID0+IChcclxuICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgIGtleT17ZXN0LmlkfVxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZVNlbGVjaW9uYXJFc3RhYmVsZWNpbWVudG8oZXN0LmlkKX1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgdGV4dC1sZWZ0IHAtMi41IGhvdmVyOmJnLXNsYXRlLTUwIGRhcms6aG92ZXI6Ymctc2xhdGUtODAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZVwiPntlc3QucmF6YW9fc29jaWFsfTwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtc2xhdGUtNDAwIGZvbnQtbW9ub1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBDTlBKL0NQRjoge2VzdC5jbnBqX2NwZn0g4oCiIHtlc3QuYmFpcnJvfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtdGVhbC02MDAgZm9udC1zZW1pYm9sZFwiPlNlbGVjaW9uYXI8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwiaGlkZGVuXCIgey4uLnJlZ2lzdGVyKFwiZXN0YWJlbGVjaW1lbnRvX2lkXCIpfSAvPlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMzAwIG1iLTFcIj5cclxuICAgICAgICAgICAgICBJZGVudGlmaWNhw6fDo28gZG8gTG9jYWwgRGVudW5jaWFkbyAoTm9tZSBkYSBFbXByZXNhIG91IERlc2NyacOnw6NvKSA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJvc2UtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgIHsuLi5yZWdpc3RlcihcImxvY2FsX2RlbnVuY2lhZG9faWRlbnRpZmljYWNhb1wiKX1cclxuICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkV4OiBQYWRhcmlhIEVzdHJlbGEgZGEgTWFuaMOjLCBGZWlyYSBMaXZyZSBNdW5pY2lwYWwsIFJlc2lkw6puY2lhIGNvbSBjcmlhw6fDo28gaXJyZWd1bGFyLi4uXCJcclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIHRleHQteHMgYmctc2xhdGUtNTAgZGFyazpiZy1zbGF0ZS04MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQtbGcgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy10ZWFsLTUwMFwiXHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIHtlcnJvcnMubG9jYWxfZGVudW5jaWFkb19pZGVudGlmaWNhY2FvICYmIChcclxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LXJvc2UtNjAwIG10LTFcIj5cclxuICAgICAgICAgICAgICAgIHtlcnJvcnMubG9jYWxfZGVudW5jaWFkb19pZGVudGlmaWNhY2FvLm1lc3NhZ2V9XHJcbiAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICApfVxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIHNtOmdyaWQtY29scy0zIGdhcC00XCI+XHJcbiAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMzAwIG1iLTFcIj5cclxuICAgICAgICAgICAgICAgIExvZ3JhZG91cm8gKFJ1YSAvIEF2LilcclxuICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgey4uLnJlZ2lzdGVyKFwibG9ncmFkb3Vyb1wiKX1cclxuICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiUnVhLi4uXCJcclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC0zIHB5LTIgdGV4dC14cyBiZy1zbGF0ZS01MCBkYXJrOmJnLXNsYXRlLTgwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC1sZyB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGUgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLXRlYWwtNTAwXCJcclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMzAwIG1iLTFcIj5cclxuICAgICAgICAgICAgICAgIE7Dum1lcm9cclxuICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgey4uLnJlZ2lzdGVyKFwibnVtZXJvXCIpfVxyXG4gICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJOwrogb3UgUy9OXCJcclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC0zIHB5LTIgdGV4dC14cyBiZy1zbGF0ZS01MCBkYXJrOmJnLXNsYXRlLTgwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC1sZyB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGUgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLXRlYWwtNTAwXCJcclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMzAwIG1iLTFcIj5cclxuICAgICAgICAgICAgICAgIEJhaXJyb1xyXG4gICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICB7Li4ucmVnaXN0ZXIoXCJiYWlycm9cIil9XHJcbiAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkJhaXJyby4uLlwiXHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIHRleHQteHMgYmctc2xhdGUtNTAgZGFyazpiZy1zbGF0ZS04MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQtbGcgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy10ZWFsLTUwMFwiXHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0zMDAgbWItMVwiPlxyXG4gICAgICAgICAgICAgIFJlbGF0byBNaW51Y2lvc28gZG9zIEZhdG9zIERlbnVuY2lhZG9zIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcm9zZS01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICA8dGV4dGFyZWFcclxuICAgICAgICAgICAgICByb3dzPXs0fVxyXG4gICAgICAgICAgICAgIHsuLi5yZWdpc3RlcihcInJlbGF0b19kZW51bmNpYVwiKX1cclxuICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkRlc2NyZXZhIG1pbnVjaW9zYW1lbnRlIGEgaXJyZWd1bGFyaWRhZGUgc2FuaXTDoXJpYSBjb25zdGF0YWRhLCBkYXRhcywgY29uZGnDp8O1ZXMgZG9zIHByb2R1dG9zIGUgcmlzY29zIG9ic2VydmFkb3MuLi5cIlxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBwLTMgdGV4dC14cyBiZy1zbGF0ZS01MCBkYXJrOmJnLXNsYXRlLTgwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC1sZyB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGUgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLXRlYWwtNTAwXCJcclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAge2Vycm9ycy5yZWxhdG9fZGVudW5jaWEgJiYgKFxyXG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtcm9zZS02MDAgbXQtMVwiPlxyXG4gICAgICAgICAgICAgICAge2Vycm9ycy5yZWxhdG9fZGVudW5jaWEubWVzc2FnZX1cclxuICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICl9XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgey8qIEJsb2NvIDM6IEF1dG9yaWEgJiBTaWdpbG8gTGVnYWwgKi99XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC0yeGwgcC02IHNoYWRvdy14cyBzcGFjZS15LTRcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGJvcmRlci1iIGJvcmRlci1zbGF0ZS0xMDAgZGFyazpib3JkZXItc2xhdGUtODAwIHBiLTJcIj5cclxuICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGVcIj5cclxuICAgICAgICAgICAgICAzLiBEYWRvcyBkbyBEZW51bmNpYW50ZSAmIFNpZ2lsbyBMZWdhbFxyXG4gICAgICAgICAgICA8L2gyPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInJlbGF0aXZlIGlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBjdXJzb3ItcG9pbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXHJcbiAgICAgICAgICAgICAgICAgIHsuLi5yZWdpc3RlcihcImRlbnVuY2lhbnRlX2Fub25pbW9cIil9XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInNyLW9ubHkgcGVlclwiXHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTkgaC01IGJnLXNsYXRlLTIwMCBwZWVyLWZvY3VzOm91dGxpbmUtbm9uZSByb3VuZGVkLWZ1bGwgcGVlciBkYXJrOmJnLXNsYXRlLTcwMCBwZWVyLWNoZWNrZWQ6YWZ0ZXI6dHJhbnNsYXRlLXgtZnVsbCBwZWVyLWNoZWNrZWQ6YWZ0ZXI6Ym9yZGVyLXdoaXRlIGFmdGVyOmNvbnRlbnQtWycnXSBhZnRlcjphYnNvbHV0ZSBhZnRlcjp0b3AtWzJweF0gYWZ0ZXI6bGVmdC1bMnB4XSBhZnRlcjpiZy13aGl0ZSBhZnRlcjpib3JkZXItc2xhdGUtMzAwIGFmdGVyOmJvcmRlciBhZnRlcjpyb3VuZGVkLWZ1bGwgYWZ0ZXI6aC00IGFmdGVyOnctNCBhZnRlcjp0cmFuc2l0aW9uLWFsbCBwZWVyLWNoZWNrZWQ6YmctdGVhbC02MDBcIiAvPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWwtMiB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTMwMFwiPlxyXG4gICAgICAgICAgICAgICAgICBEZW7Dum5jaWEgQW7DtG5pbWFcclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIHtkZW51bmNpYW50ZUFub25pbW8gPyAoXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0zLjUgYmctc2xhdGUtNTAgZGFyazpiZy1zbGF0ZS04MDAvNjAgcm91bmRlZC14bCB0ZXh0LXhzIHRleHQtc2xhdGUtNjAwIGRhcms6dGV4dC1zbGF0ZS00MDAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIuNVwiPlxyXG4gICAgICAgICAgICAgIDxMb2NrIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1zbGF0ZS01MDAgc2hyaW5rLTBcIiAvPlxyXG4gICAgICAgICAgICAgIDxzcGFuPlxyXG4gICAgICAgICAgICAgICAgQSBpZGVudGlkYWRlIGRvIG1hbmlmZXN0YW50ZSBlc3TDoSBwcm90ZWdpZGEgcG9yIHNpZ2lsbyBsZWdhbC4gTmVuaHVtIGRhZG8gcGVzc29hbCBzZXLDoSBleGlnaWRvIG91IHJlZ2lzdHJhZG8uXHJcbiAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBzbTpncmlkLWNvbHMtMyBnYXAtNCBhbmltYXRlLWluIGZhZGUtaW4gZHVyYXRpb24tMTUwXCI+XHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTMwMCBtYi0xXCI+XHJcbiAgICAgICAgICAgICAgICAgIE5vbWUgQ29tcGxldG8gZG8gQ2lkYWTDo28gPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yb3NlLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgey4uLnJlZ2lzdGVyKFwiZGVudW5jaWFudGVfbm9tZVwiKX1cclxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJOb21lIGRvIGRlbnVuY2lhbnRlLi4uXCJcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMgcHktMiB0ZXh0LXhzIGJnLXNsYXRlLTUwIGRhcms6Ymctc2xhdGUtODAwIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCByb3VuZGVkLWxnIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZSBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctdGVhbC01MDBcIlxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIHtlcnJvcnMuZGVudW5jaWFudGVfbm9tZSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtcm9zZS02MDAgbXQtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuZGVudW5jaWFudGVfbm9tZS5tZXNzYWdlfVxyXG4gICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMzAwIG1iLTFcIj5cclxuICAgICAgICAgICAgICAgICAgVGVsZWZvbmUgZGUgQ29udGF0b1xyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgIHsuLi5yZWdpc3RlcihcImRlbnVuY2lhbnRlX3RlbGVmb25lXCIpfVxyXG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIigzMykgOTk5OTktOTk5OVwiXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC0zIHB5LTIgdGV4dC14cyBiZy1zbGF0ZS01MCBkYXJrOmJnLXNsYXRlLTgwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC1sZyB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGUgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLXRlYWwtNTAwXCJcclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0zMDAgbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgICBFLW1haWwgZG8gQ2lkYWTDo29cclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgdHlwZT1cImVtYWlsXCJcclxuICAgICAgICAgICAgICAgICAgey4uLnJlZ2lzdGVyKFwiZGVudW5jaWFudGVfZW1haWxcIil9XHJcbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiY2lkYWRhb0BleGVtcGxvLmNvbVwiXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC0zIHB5LTIgdGV4dC14cyBiZy1zbGF0ZS01MCBkYXJrOmJnLXNsYXRlLTgwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC1sZyB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGUgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLXRlYWwtNTAwXCJcclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgKX1cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgey8qIEJvdMOjbyBkZSBFbnZpbyAqL31cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktZW5kIGdhcC0zIHB0LTJcIj5cclxuICAgICAgICAgIDxMaW5rXHJcbiAgICAgICAgICAgIHRvPXtST1VURVMuT1VWSURPUklBLkxJU1R9XHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTQgcHktMiB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS02MDAgaG92ZXI6Ymctc2xhdGUtMTAwIHJvdW5kZWQteGxcIlxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICBDYW5jZWxhclxyXG4gICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcclxuICAgICAgICAgICAgZGlzYWJsZWQ9e2lzU3VibWl0dGluZ31cclxuICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNiBweS0yLjUgdGV4dC14cyBmb250LWJvbGQgdGV4dC13aGl0ZSBiZy10ZWFsLTYwMCBob3ZlcjpiZy10ZWFsLTcwMCByb3VuZGVkLXhsIHNoYWRvdy14cyB0cmFuc2l0aW9uLWNvbG9ycyBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBkaXNhYmxlZDpvcGFjaXR5LTYwXCJcclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgPFNhdmUgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+XHJcbiAgICAgICAgICAgIDxzcGFuPntpc1N1Ym1pdHRpbmcgPyBcIlJlZ2lzdHJhbmRvLi4uXCIgOiBcIlByb3RvY29sYXIgRGVuw7puY2lhIE9maWNpYWxcIn08L3NwYW4+XHJcbiAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9mb3JtPlxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IFJlZ2lzdHJhckRlbnVuY2lhSW50ZXJuYVBhZ2U7XHJcbiJdfQ==