import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/indicadores/DashboardIndicadoresPage.tsx");const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport11_react_jsxDevRuntime["jsxDEV"];/**
* Painel Executivo de Indicadores Sanitários & Metas Pactuadas (DashboardIndicadoresPage)
* Rota: /indicadores
* Monitoramento contínuo dos Indicadores 11 a 15 do Pacto SUS / DIGISUS,
* gráficos analíticos Recharts, alertas de vencimento e prestação de contas.
*/
import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=0fd2848a";
import { Link, useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=0fd2848a";
import { BarChart3, Calendar, Printer, RefreshCw, Target } from "/node_modules/.vite/deps/lucide-react.js?v=0fd2848a";
import { APP_CONFIG } from "/src/config/app.config.ts";
import { ROUTES } from "/src/config/routes.config.ts";
import { useAuth } from "/src/contexts/AuthContext.tsx";
import { useAlertasVencimento, useDashboardIndicadores } from "/src/hooks/useIndicadores.ts";
import { CardMetaIndicador } from "/src/components/indicadores/CardMetaIndicador.tsx";
import { GraficoDistribuicaoRisco } from "/src/components/indicadores/GraficoDistribuicaoRisco.tsx";
import { GraficoEvolucaoInspecoes } from "/src/components/indicadores/GraficoEvolucaoInspecoes.tsx";
import { TabelaAlertasOperacionais } from "/src/components/indicadores/TabelaAlertasOperacionais.tsx";
var _jsxFileName = "E:/Projetos VSCODE/visa_braunas/src/pages/indicadores/DashboardIndicadoresPage.tsx";
import __vite__cjsImport11_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=0fd2848a";
var _s = $RefreshSig$();
export const DashboardIndicadoresPage = () => {
	_s();
	const { user } = useAuth();
	const navigate = useNavigate();
	const [anoExercicio, setAnoExercicio] = useState(2026);
	const { data: dashboard, isLoading: loadingDashboard, isRefetching, refetch } = useDashboardIndicadores(anoExercicio);
	const { data: alertas, isLoading: loadingAlertas } = useAlertasVencimento(30);
	// Lista dos 5 indicadores oficiais pactuados
	const listaIndicadores = dashboard ? [
		dashboard.indicador_11_vapt,
		dashboard.indicador_12_risco_3,
		dashboard.indicador_13_risco_2,
		dashboard.indicador_14_risco_1,
		dashboard.indicador_15_sintetico
	] : [
		{
			codigo: "IND-11",
			titulo: "Indicador 11: Ações VAPT em Saúde do Trabalhador",
			descricao: "Inspeções sanitárias em ambientes de trabalho concluídas no município.",
			unidade: "ações",
			progresso: {
				meta_pactuada: 20,
				realizado: 18,
				percentual_atingido: 90,
				status: "Em Andamento"
			}
		},
		{
			codigo: "IND-12",
			titulo: "Indicador 12: Cobertura Sanitária de Risco III (Alto Risco)",
			descricao: "Percentual de estabelecimentos de Alto Risco inspecionados no exercício.",
			unidade: "%",
			progresso: {
				meta_pactuada: 100,
				realizado: 82.5,
				percentual_atingido: 82.5,
				status: "Em Andamento"
			}
		},
		{
			codigo: "IND-13",
			titulo: "Indicador 13: Cobertura Sanitária de Risco II (Médio Risco)",
			descricao: "Percentual de estabelecimentos de Médio Risco cadastrados monitorados.",
			unidade: "%",
			progresso: {
				meta_pactuada: 100,
				realizado: 94,
				percentual_atingido: 94,
				status: "Em Andamento"
			}
		},
		{
			codigo: "IND-14",
			titulo: "Indicador 14: Licenciamento / Declarações de Risco I (Baixo)",
			descricao: "Percentual de atividades econômicas de Baixo Risco regularizadas.",
			unidade: "%",
			progresso: {
				meta_pactuada: 100,
				realizado: 100,
				percentual_atingido: 100,
				status: "Atingida"
			}
		},
		{
			codigo: "IND-15",
			titulo: "Indicador 15: Índice Sintético Geral de Cumprimento de Metas",
			descricao: "Média do desempenho institucional em relação a todas as metas regulatórias.",
			unidade: "%",
			progresso: {
				meta_pactuada: 100,
				realizado: 91.6,
				percentual_atingido: 91.6,
				status: "Em Andamento"
			}
		}
	];
	const anosDisponiveis = [
		2026,
		2025,
		2024
	];
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "space-y-6 pb-12",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 shadow-xs",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex flex-col md:flex-row md:items-center justify-between gap-4",
					children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "p-1.5 rounded-lg bg-teal-50 dark:bg-teal-950/40 text-teal-600 dark:text-teal-400",
							children: /* @__PURE__ */ _jsxDEV(BarChart3, { className: "w-5 h-5" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 113,
								columnNumber: 17
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 112,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("h1", {
							className: "text-xl sm:text-2xl font-bold tracking-tight text-slate-900 dark:text-white",
							children: "Painel Executivo de Metas & Indicadores Sanitários"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 115,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 111,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("p", {
						className: "text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1.5",
						children: [
							"Monitoramento oficial do Pacto da Saúde, DIGISUS e vigilância de riscos de ",
							APP_CONFIG.municipio,
							"/",
							APP_CONFIG.uf,
							"."
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 119,
						columnNumber: 13
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 110,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "flex flex-wrap items-center gap-2.5",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-1.5 bg-slate-100 dark:bg-slate-800 p-1 rounded-lg border border-slate-200 dark:border-slate-700",
								children: [/* @__PURE__ */ _jsxDEV(Calendar, { className: "w-3.5 h-3.5 text-slate-500 ml-1.5" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 128,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("select", {
									value: anoExercicio,
									onChange: (e) => setAnoExercicio(Number(e.target.value)),
									className: "bg-transparent text-xs font-bold text-slate-800 dark:text-slate-200 focus:outline-none pr-2 py-0.5",
									children: anosDisponiveis.map((a) => /* @__PURE__ */ _jsxDEV("option", {
										value: a,
										className: "dark:bg-slate-800 text-slate-900 dark:text-white",
										children: ["Exercício ", a]
									}, a, true, {
										fileName: _jsxFileName,
										lineNumber: 135,
										columnNumber: 19
									}, this))
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 129,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 127,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								onClick: () => refetch(),
								disabled: isRefetching,
								className: "p-2 text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-lg transition-colors",
								title: "Recarregar Dados",
								children: /* @__PURE__ */ _jsxDEV(RefreshCw, { className: `w-4 h-4 ${isRefetching ? "animate-spin text-teal-600" : ""}` }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 150,
									columnNumber: 15
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 143,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV(Link, {
								to: ROUTES.RELATORIOS.SUS(anoExercicio),
								className: "inline-flex items-center gap-2 px-3.5 py-2 text-xs font-bold text-white bg-teal-600 hover:bg-teal-700 rounded-lg shadow-xs hover:shadow transition-all",
								children: [/* @__PURE__ */ _jsxDEV(Printer, { className: "w-4 h-4" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 158,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Gerar Relatório Oficial SUS" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 159,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 154,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 125,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 109,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "grid grid-cols-2 sm:grid-cols-4 gap-3 pt-5 mt-5 border-t border-slate-100 dark:border-slate-800",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "p-3 bg-slate-50 dark:bg-slate-800/40 rounded-lg",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-[10px] uppercase font-bold text-slate-400 block tracking-wider",
								children: "Empresas Ativas"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 167,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "text-xl font-bold text-slate-900 dark:text-white tabular-nums",
								children: dashboard?.total_estabelecimentos_cadastrados ?? 239
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 170,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 166,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "p-3 bg-slate-50 dark:bg-slate-800/40 rounded-lg",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-[10px] uppercase font-bold text-slate-400 block tracking-wider",
								children: "Vistorias Realizadas"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 176,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "text-xl font-bold text-slate-900 dark:text-white tabular-nums",
								children: dashboard?.total_inspecoes_exercicio ?? 84
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 179,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 175,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "p-3 bg-slate-50 dark:bg-slate-800/40 rounded-lg",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-[10px] uppercase font-bold text-slate-400 block tracking-wider",
								children: "Alvarás Vigentes"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 185,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "text-xl font-bold text-slate-900 dark:text-white tabular-nums",
								children: dashboard?.total_alvaras_ativos ?? 162
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 188,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 184,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "p-3 bg-teal-50/50 dark:bg-teal-950/30 border border-teal-100 dark:border-teal-900/40 rounded-lg",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-[10px] uppercase font-bold text-teal-700 dark:text-teal-400 block tracking-wider",
								children: "Índice Geral (IND-15)"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 194,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "text-xl font-bold text-teal-700 dark:text-teal-300 tabular-nums",
								children: [dashboard?.indicador_15_sintetico.progresso.percentual_atingido.toFixed(1) ?? "91.6", "%"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 197,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 193,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 165,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 108,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "flex items-center justify-between mb-3",
				children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h2", {
					className: "text-sm font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300 flex items-center gap-1.5",
					children: [/* @__PURE__ */ _jsxDEV(Target, { className: "w-4 h-4 text-teal-600" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 209,
						columnNumber: 15
					}, this), "Metas Sanitárias Anuais Pactuadas (Indicadores 11 a 15)"]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 208,
					columnNumber: 13
				}, this), /* @__PURE__ */ _jsxDEV("p", {
					className: "text-xs text-slate-400",
					children: "Taxa de atingimento acumulado em relação aos compromissos do Plano Municipal de Saúde"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 212,
					columnNumber: 13
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 207,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("span", {
					className: "text-xs text-slate-500 dark:text-slate-400 hidden sm:inline",
					children: ["Ano de Referência: ", /* @__PURE__ */ _jsxDEV("strong", { children: anoExercicio }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 217,
						columnNumber: 32
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 216,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 206,
				columnNumber: 9
			}, this), loadingDashboard ? /* @__PURE__ */ _jsxDEV("div", {
				className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4",
				children: [
					1,
					2,
					3,
					4,
					5
				].map((i) => /* @__PURE__ */ _jsxDEV("div", { className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 h-48 animate-pulse" }, i, false, {
					fileName: _jsxFileName,
					lineNumber: 224,
					columnNumber: 15
				}, this))
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 222,
				columnNumber: 11
			}, this) : /* @__PURE__ */ _jsxDEV("div", {
				className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4",
				children: listaIndicadores.map((ind) => /* @__PURE__ */ _jsxDEV(CardMetaIndicador, {
					indicador: ind,
					onClick: () => {
						if (ind.codigo === "IND-11") {
							navigate(ROUTES.INSPECOES.LIST);
						} else if (ind.codigo === "IND-12" || ind.codigo === "IND-13" || ind.codigo === "IND-14") {
							navigate(ROUTES.ESTABELECIMENTOS.LIST);
						}
					}
				}, ind.codigo, false, {
					fileName: _jsxFileName,
					lineNumber: 233,
					columnNumber: 15
				}, this))
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 231,
				columnNumber: 11
			}, this)] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 205,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "grid grid-cols-1 lg:grid-cols-2 gap-6",
				children: [/* @__PURE__ */ _jsxDEV(GraficoDistribuicaoRisco, {
					distribuicao: dashboard?.distribuicao_estabelecimentos_por_risco,
					totalCadastrados: dashboard?.total_estabelecimentos_cadastrados
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 251,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV(GraficoEvolucaoInspecoes, {
					ano: anoExercicio,
					totalVapt: dashboard?.indicador_11_vapt.progresso.realizado,
					totalGeral: dashboard?.total_inspecoes_exercicio
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 256,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 250,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(TabelaAlertasOperacionais, {
				alertas,
				isLoading: loadingAlertas
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 264,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 106,
		columnNumber: 5
	}, this);
};
_s(DashboardIndicadoresPage, "GG2ONiuAT48KF2vqhOdyVFRnPVA=", false, function() {
	return [
		useAuth,
		useNavigate,
		useDashboardIndicadores,
		useAlertasVencimento
	];
});
_c = DashboardIndicadoresPage;
export default DashboardIndicadoresPage;
var _c;
$RefreshReg$(_c, "DashboardIndicadoresPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/indicadores/DashboardIndicadoresPage.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("E:/Projetos VSCODE/visa_braunas/src/pages/indicadores/DashboardIndicadoresPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("E:/Projetos VSCODE/visa_braunas/src/pages/indicadores/DashboardIndicadoresPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "E:/Projetos VSCODE/visa_braunas/src/pages/indicadores/DashboardIndicadoresPage.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7Ozs7O0FBT0EsT0FBTyxTQUFTLGdCQUFnQjtBQUNoQyxTQUFTLE1BQU0sbUJBQW1CO0FBQ2xDLFNBRUUsV0FDQSxVQU9BLFNBQ0EsV0FJQSxjQUNLO0FBQ1AsU0FBUyxrQkFBa0I7QUFDM0IsU0FBUyxjQUFjO0FBQ3ZCLFNBQVMsZUFBZTtBQUN4QixTQUNFLHNCQUNBLCtCQUNLO0FBQ1AsU0FBUyx5QkFBeUI7QUFDbEMsU0FBUyxnQ0FBZ0M7QUFDekMsU0FBUyxnQ0FBZ0M7QUFDekMsU0FBUyxpQ0FBaUM7Ozs7QUFFMUMsT0FBTyxNQUFNLGlDQUEyQzs7Q0FDdEQsTUFBTSxFQUFFLFNBQVMsUUFBUTtDQUN6QixNQUFNLFdBQVcsWUFBWTtDQUM3QixNQUFNLENBQUMsY0FBYyxtQkFBbUIsU0FBaUIsSUFBSTtDQUU3RCxNQUFNLEVBQ0osTUFBTSxXQUNOLFdBQVcsa0JBQ1gsY0FDQSxZQUNFLHdCQUF3QixZQUFZO0NBRXhDLE1BQU0sRUFDSixNQUFNLFNBQ04sV0FBVyxtQkFDVCxxQkFBcUIsRUFBRTs7Q0FHM0IsTUFBTSxtQkFBbUIsWUFDckI7RUFDRSxVQUFVO0VBQ1YsVUFBVTtFQUNWLFVBQVU7RUFDVixVQUFVO0VBQ1YsVUFBVTtDQUNaLElBQ0E7RUFDRTtHQUNFLFFBQVE7R0FDUixRQUFRO0dBQ1IsV0FBVztHQUNYLFNBQVM7R0FDVCxXQUFXO0lBQUUsZUFBZTtJQUFJLFdBQVc7SUFBSSxxQkFBcUI7SUFBTSxRQUFRO0dBQWU7RUFDbkc7RUFDQTtHQUNFLFFBQVE7R0FDUixRQUFRO0dBQ1IsV0FBVztHQUNYLFNBQVM7R0FDVCxXQUFXO0lBQUUsZUFBZTtJQUFLLFdBQVc7SUFBTSxxQkFBcUI7SUFBTSxRQUFRO0dBQWU7RUFDdEc7RUFDQTtHQUNFLFFBQVE7R0FDUixRQUFRO0dBQ1IsV0FBVztHQUNYLFNBQVM7R0FDVCxXQUFXO0lBQUUsZUFBZTtJQUFLLFdBQVc7SUFBTSxxQkFBcUI7SUFBTSxRQUFRO0dBQWU7RUFDdEc7RUFDQTtHQUNFLFFBQVE7R0FDUixRQUFRO0dBQ1IsV0FBVztHQUNYLFNBQVM7R0FDVCxXQUFXO0lBQUUsZUFBZTtJQUFLLFdBQVc7SUFBTyxxQkFBcUI7SUFBTyxRQUFRO0dBQVc7RUFDcEc7RUFDQTtHQUNFLFFBQVE7R0FDUixRQUFRO0dBQ1IsV0FBVztHQUNYLFNBQVM7R0FDVCxXQUFXO0lBQUUsZUFBZTtJQUFLLFdBQVc7SUFBTSxxQkFBcUI7SUFBTSxRQUFRO0dBQWU7RUFDdEc7Q0FDRjtDQUVKLE1BQU0sa0JBQWtCO0VBQUM7RUFBTTtFQUFNO0NBQUk7Q0FFekMsT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUFmO0dBRUUsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxRQUFEO09BQU0sV0FBVTtpQkFDZCx3QkFBQyxXQUFELEVBQVcsV0FBVSxVQUFXOzs7OztNQUM1Qjs7OztnQkFDTix3QkFBQyxNQUFEO09BQUksV0FBVTtpQkFBOEU7TUFFeEY7Ozs7Y0FDRDs7Ozs7ZUFDTCx3QkFBQyxLQUFEO01BQUcsV0FBVTtnQkFBYjtPQUE0RTtPQUNFLFdBQVc7T0FBVTtPQUFFLFdBQVc7T0FBRztNQUNoSDs7Ozs7YUFDQTs7OztlQUdMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmO09BRUUsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxVQUFELEVBQVUsV0FBVSxvQ0FBcUM7Ozs7a0JBQ3pELHdCQUFDLFVBQUQ7U0FDRSxPQUFPO1NBQ1AsV0FBVyxNQUFNLGdCQUFnQixPQUFPLEVBQUUsT0FBTyxLQUFLLENBQUM7U0FDdkQsV0FBVTttQkFFVCxnQkFBZ0IsS0FBSyxNQUNwQix3QkFBQyxVQUFEO1VBQWdCLE9BQU87VUFBRyxXQUFVO29CQUFwQyxDQUF1RixjQUMxRSxDQUNMO1lBRks7Ozs7Z0JBRUwsQ0FDVDtRQUNLOzs7O2dCQUNMOzs7Ozs7T0FHTCx3QkFBQyxVQUFEO1FBQ0UsTUFBSztRQUNMLGVBQWUsUUFBUTtRQUN2QixVQUFVO1FBQ1YsV0FBVTtRQUNWLE9BQU07a0JBRU4sd0JBQUMsV0FBRCxFQUFXLFdBQVcsV0FBVyxlQUFlLCtCQUErQixLQUFPOzs7OztPQUNoRjs7Ozs7T0FHUix3QkFBQyxNQUFEO1FBQ0UsSUFBSSxPQUFPLFdBQVcsSUFBSSxZQUFZO1FBQ3RDLFdBQVU7a0JBRlosQ0FJRSx3QkFBQyxTQUFELEVBQVMsV0FBVSxVQUFXOzs7O2tCQUM5Qix3QkFBQyxRQUFELFlBQU0sOEJBQWlDOzs7O2dCQUNuQzs7Ozs7O01BQ0g7Ozs7O2FBQ0Y7Ozs7O2NBR0wsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZjtNQUNFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQXNFO09BRWhGOzs7O2lCQUNOLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUNiLFdBQVcsc0NBQXNDO09BQzlDOzs7O2VBQ0g7Ozs7OztNQUVMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQXNFO09BRWhGOzs7O2lCQUNOLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUNiLFdBQVcsNkJBQTZCO09BQ3JDOzs7O2VBQ0g7Ozs7OztNQUVMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQXNFO09BRWhGOzs7O2lCQUNOLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUNiLFdBQVcsd0JBQXdCO09BQ2hDOzs7O2VBQ0g7Ozs7OztNQUVMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQXdGO09BRWxHOzs7O2lCQUNOLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUFoQixDQUNHLFdBQVcsdUJBQXVCLFVBQVUsb0JBQW9CLFFBQVEsQ0FBQyxLQUFLLFFBQU8sR0FDbEY7Ozs7O2VBQ0g7Ozs7OztLQUNGOzs7OztZQUNGOzs7Ozs7R0FHTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxNQUFEO0tBQUksV0FBVTtlQUFkLENBQ0Usd0JBQUMsUUFBRCxFQUFRLFdBQVUsd0JBQXlCOzs7O2VBQUMseURBRTFDOzs7OztjQUNKLHdCQUFDLEtBQUQ7S0FBRyxXQUFVO2VBQXlCO0lBRW5DOzs7O1lBQ0E7Ozs7Y0FDTCx3QkFBQyxRQUFEO0tBQU0sV0FBVTtlQUFoQixDQUE4RSx1QkFDekQsd0JBQUMsVUFBRCxZQUFTLGFBQXFCOzs7O2FBQzdDOzs7OztZQUNIOzs7OzthQUVKLG1CQUNDLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQ1o7S0FBQztLQUFHO0tBQUc7S0FBRztLQUFHO0lBQUMsQ0FBQyxDQUFDLEtBQUssTUFDcEIsd0JBQUMsT0FBRCxFQUVFLFdBQVUsNkdBQ1gsR0FGTTs7OztXQUVOLENBQ0Y7R0FDRTs7OztjQUVMLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQ1osaUJBQWlCLEtBQUssUUFDckIsd0JBQUMsbUJBQUQ7S0FFRSxXQUFXO0tBQ1gsZUFBZTtNQUNiLElBQUksSUFBSSxXQUFXLFVBQVU7T0FDM0IsU0FBUyxPQUFPLFVBQVUsSUFBSTtNQUNoQyxPQUFPLElBQUksSUFBSSxXQUFXLFlBQVksSUFBSSxXQUFXLFlBQVksSUFBSSxXQUFXLFVBQVU7T0FDeEYsU0FBUyxPQUFPLGlCQUFpQixJQUFJO01BQ3ZDO0tBQ0Y7SUFDRCxHQVRNLElBQUk7Ozs7V0FTVixDQUNGO0dBQ0U7Ozs7V0FFSjs7Ozs7R0FHTCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsMEJBQUQ7S0FDRSxjQUFjLFdBQVc7S0FDekIsa0JBQWtCLFdBQVc7SUFDOUI7Ozs7Y0FFRCx3QkFBQywwQkFBRDtLQUNFLEtBQUs7S0FDTCxXQUFXLFdBQVcsa0JBQWtCLFVBQVU7S0FDbEQsWUFBWSxXQUFXO0lBQ3hCOzs7O1lBQ0U7Ozs7OztHQUdMLHdCQUFDLDJCQUFEO0lBQ1c7SUFDVCxXQUFXO0dBQ1o7Ozs7O0VBQ0U7Ozs7OztBQUVUOzs7Ozs7Ozs7O0FBRUEsZUFBZSIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJEYXNoYm9hcmRJbmRpY2Fkb3Jlc1BhZ2UudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbIi8qKlxyXG4gKiBQYWluZWwgRXhlY3V0aXZvIGRlIEluZGljYWRvcmVzIFNhbml0w6FyaW9zICYgTWV0YXMgUGFjdHVhZGFzIChEYXNoYm9hcmRJbmRpY2Fkb3Jlc1BhZ2UpXHJcbiAqIFJvdGE6IC9pbmRpY2Fkb3Jlc1xyXG4gKiBNb25pdG9yYW1lbnRvIGNvbnTDrW51byBkb3MgSW5kaWNhZG9yZXMgMTEgYSAxNSBkbyBQYWN0byBTVVMgLyBESUdJU1VTLFxyXG4gKiBncsOhZmljb3MgYW5hbMOtdGljb3MgUmVjaGFydHMsIGFsZXJ0YXMgZGUgdmVuY2ltZW50byBlIHByZXN0YcOnw6NvIGRlIGNvbnRhcy5cclxuICovXHJcblxyXG5pbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHsgTGluaywgdXNlTmF2aWdhdGUgfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xyXG5pbXBvcnQge1xyXG4gIEFsZXJ0Q2lyY2xlLFxyXG4gIEJhckNoYXJ0MyxcclxuICBDYWxlbmRhcixcclxuICBDaGVja0NpcmNsZTIsXHJcbiAgQ2hldnJvblJpZ2h0LFxyXG4gIENsaXBib2FyZENoZWNrLFxyXG4gIERvd25sb2FkLFxyXG4gIEZpbGVDaGVjazIsXHJcbiAgRmlsZVRleHQsXHJcbiAgUHJpbnRlcixcclxuICBSZWZyZXNoQ3csXHJcbiAgU2hpZWxkLFxyXG4gIFNoaWVsZEFsZXJ0LFxyXG4gIFNwYXJrbGVzLFxyXG4gIFRhcmdldCxcclxufSBmcm9tIFwibHVjaWRlLXJlYWN0XCI7XHJcbmltcG9ydCB7IEFQUF9DT05GSUcgfSBmcm9tIFwiLi4vLi4vY29uZmlnL2FwcC5jb25maWdcIjtcclxuaW1wb3J0IHsgUk9VVEVTIH0gZnJvbSBcIi4uLy4uL2NvbmZpZy9yb3V0ZXMuY29uZmlnXCI7XHJcbmltcG9ydCB7IHVzZUF1dGggfSBmcm9tIFwiLi4vLi4vY29udGV4dHMvQXV0aENvbnRleHRcIjtcclxuaW1wb3J0IHtcclxuICB1c2VBbGVydGFzVmVuY2ltZW50byxcclxuICB1c2VEYXNoYm9hcmRJbmRpY2Fkb3JlcyxcclxufSBmcm9tIFwiLi4vLi4vaG9va3MvdXNlSW5kaWNhZG9yZXNcIjtcclxuaW1wb3J0IHsgQ2FyZE1ldGFJbmRpY2Fkb3IgfSBmcm9tIFwiLi4vLi4vY29tcG9uZW50cy9pbmRpY2Fkb3Jlcy9DYXJkTWV0YUluZGljYWRvclwiO1xyXG5pbXBvcnQgeyBHcmFmaWNvRGlzdHJpYnVpY2FvUmlzY28gfSBmcm9tIFwiLi4vLi4vY29tcG9uZW50cy9pbmRpY2Fkb3Jlcy9HcmFmaWNvRGlzdHJpYnVpY2FvUmlzY29cIjtcclxuaW1wb3J0IHsgR3JhZmljb0V2b2x1Y2FvSW5zcGVjb2VzIH0gZnJvbSBcIi4uLy4uL2NvbXBvbmVudHMvaW5kaWNhZG9yZXMvR3JhZmljb0V2b2x1Y2FvSW5zcGVjb2VzXCI7XHJcbmltcG9ydCB7IFRhYmVsYUFsZXJ0YXNPcGVyYWNpb25haXMgfSBmcm9tIFwiLi4vLi4vY29tcG9uZW50cy9pbmRpY2Fkb3Jlcy9UYWJlbGFBbGVydGFzT3BlcmFjaW9uYWlzXCI7XHJcblxyXG5leHBvcnQgY29uc3QgRGFzaGJvYXJkSW5kaWNhZG9yZXNQYWdlOiBSZWFjdC5GQyA9ICgpID0+IHtcclxuICBjb25zdCB7IHVzZXIgfSA9IHVzZUF1dGgoKTtcclxuICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKCk7XHJcbiAgY29uc3QgW2Fub0V4ZXJjaWNpbywgc2V0QW5vRXhlcmNpY2lvXSA9IHVzZVN0YXRlPG51bWJlcj4oMjAyNik7XHJcblxyXG4gIGNvbnN0IHtcclxuICAgIGRhdGE6IGRhc2hib2FyZCxcclxuICAgIGlzTG9hZGluZzogbG9hZGluZ0Rhc2hib2FyZCxcclxuICAgIGlzUmVmZXRjaGluZyxcclxuICAgIHJlZmV0Y2gsXHJcbiAgfSA9IHVzZURhc2hib2FyZEluZGljYWRvcmVzKGFub0V4ZXJjaWNpbyk7XHJcblxyXG4gIGNvbnN0IHtcclxuICAgIGRhdGE6IGFsZXJ0YXMsXHJcbiAgICBpc0xvYWRpbmc6IGxvYWRpbmdBbGVydGFzLFxyXG4gIH0gPSB1c2VBbGVydGFzVmVuY2ltZW50bygzMCk7XHJcblxyXG4gIC8vIExpc3RhIGRvcyA1IGluZGljYWRvcmVzIG9maWNpYWlzIHBhY3R1YWRvc1xyXG4gIGNvbnN0IGxpc3RhSW5kaWNhZG9yZXMgPSBkYXNoYm9hcmRcclxuICAgID8gW1xyXG4gICAgICAgIGRhc2hib2FyZC5pbmRpY2Fkb3JfMTFfdmFwdCxcclxuICAgICAgICBkYXNoYm9hcmQuaW5kaWNhZG9yXzEyX3Jpc2NvXzMsXHJcbiAgICAgICAgZGFzaGJvYXJkLmluZGljYWRvcl8xM19yaXNjb18yLFxyXG4gICAgICAgIGRhc2hib2FyZC5pbmRpY2Fkb3JfMTRfcmlzY29fMSxcclxuICAgICAgICBkYXNoYm9hcmQuaW5kaWNhZG9yXzE1X3NpbnRldGljbyxcclxuICAgICAgXVxyXG4gICAgOiBbXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgY29kaWdvOiBcIklORC0xMVwiLFxyXG4gICAgICAgICAgdGl0dWxvOiBcIkluZGljYWRvciAxMTogQcOnw7VlcyBWQVBUIGVtIFNhw7pkZSBkbyBUcmFiYWxoYWRvclwiLFxyXG4gICAgICAgICAgZGVzY3JpY2FvOiBcIkluc3Blw6fDtWVzIHNhbml0w6FyaWFzIGVtIGFtYmllbnRlcyBkZSB0cmFiYWxobyBjb25jbHXDrWRhcyBubyBtdW5pY8OtcGlvLlwiLFxyXG4gICAgICAgICAgdW5pZGFkZTogXCJhw6fDtWVzXCIsXHJcbiAgICAgICAgICBwcm9ncmVzc286IHsgbWV0YV9wYWN0dWFkYTogMjAsIHJlYWxpemFkbzogMTgsIHBlcmNlbnR1YWxfYXRpbmdpZG86IDkwLjAsIHN0YXR1czogXCJFbSBBbmRhbWVudG9cIiB9LFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgY29kaWdvOiBcIklORC0xMlwiLFxyXG4gICAgICAgICAgdGl0dWxvOiBcIkluZGljYWRvciAxMjogQ29iZXJ0dXJhIFNhbml0w6FyaWEgZGUgUmlzY28gSUlJIChBbHRvIFJpc2NvKVwiLFxyXG4gICAgICAgICAgZGVzY3JpY2FvOiBcIlBlcmNlbnR1YWwgZGUgZXN0YWJlbGVjaW1lbnRvcyBkZSBBbHRvIFJpc2NvIGluc3BlY2lvbmFkb3Mgbm8gZXhlcmPDrWNpby5cIixcclxuICAgICAgICAgIHVuaWRhZGU6IFwiJVwiLFxyXG4gICAgICAgICAgcHJvZ3Jlc3NvOiB7IG1ldGFfcGFjdHVhZGE6IDEwMCwgcmVhbGl6YWRvOiA4Mi41LCBwZXJjZW50dWFsX2F0aW5naWRvOiA4Mi41LCBzdGF0dXM6IFwiRW0gQW5kYW1lbnRvXCIgfSxcclxuICAgICAgICB9LFxyXG4gICAgICAgIHtcclxuICAgICAgICAgIGNvZGlnbzogXCJJTkQtMTNcIixcclxuICAgICAgICAgIHRpdHVsbzogXCJJbmRpY2Fkb3IgMTM6IENvYmVydHVyYSBTYW5pdMOhcmlhIGRlIFJpc2NvIElJIChNw6lkaW8gUmlzY28pXCIsXHJcbiAgICAgICAgICBkZXNjcmljYW86IFwiUGVyY2VudHVhbCBkZSBlc3RhYmVsZWNpbWVudG9zIGRlIE3DqWRpbyBSaXNjbyBjYWRhc3RyYWRvcyBtb25pdG9yYWRvcy5cIixcclxuICAgICAgICAgIHVuaWRhZGU6IFwiJVwiLFxyXG4gICAgICAgICAgcHJvZ3Jlc3NvOiB7IG1ldGFfcGFjdHVhZGE6IDEwMCwgcmVhbGl6YWRvOiA5NC4wLCBwZXJjZW50dWFsX2F0aW5naWRvOiA5NC4wLCBzdGF0dXM6IFwiRW0gQW5kYW1lbnRvXCIgfSxcclxuICAgICAgICB9LFxyXG4gICAgICAgIHtcclxuICAgICAgICAgIGNvZGlnbzogXCJJTkQtMTRcIixcclxuICAgICAgICAgIHRpdHVsbzogXCJJbmRpY2Fkb3IgMTQ6IExpY2VuY2lhbWVudG8gLyBEZWNsYXJhw6fDtWVzIGRlIFJpc2NvIEkgKEJhaXhvKVwiLFxyXG4gICAgICAgICAgZGVzY3JpY2FvOiBcIlBlcmNlbnR1YWwgZGUgYXRpdmlkYWRlcyBlY29uw7RtaWNhcyBkZSBCYWl4byBSaXNjbyByZWd1bGFyaXphZGFzLlwiLFxyXG4gICAgICAgICAgdW5pZGFkZTogXCIlXCIsXHJcbiAgICAgICAgICBwcm9ncmVzc286IHsgbWV0YV9wYWN0dWFkYTogMTAwLCByZWFsaXphZG86IDEwMC4wLCBwZXJjZW50dWFsX2F0aW5naWRvOiAxMDAuMCwgc3RhdHVzOiBcIkF0aW5naWRhXCIgfSxcclxuICAgICAgICB9LFxyXG4gICAgICAgIHtcclxuICAgICAgICAgIGNvZGlnbzogXCJJTkQtMTVcIixcclxuICAgICAgICAgIHRpdHVsbzogXCJJbmRpY2Fkb3IgMTU6IMONbmRpY2UgU2ludMOpdGljbyBHZXJhbCBkZSBDdW1wcmltZW50byBkZSBNZXRhc1wiLFxyXG4gICAgICAgICAgZGVzY3JpY2FvOiBcIk3DqWRpYSBkbyBkZXNlbXBlbmhvIGluc3RpdHVjaW9uYWwgZW0gcmVsYcOnw6NvIGEgdG9kYXMgYXMgbWV0YXMgcmVndWxhdMOzcmlhcy5cIixcclxuICAgICAgICAgIHVuaWRhZGU6IFwiJVwiLFxyXG4gICAgICAgICAgcHJvZ3Jlc3NvOiB7IG1ldGFfcGFjdHVhZGE6IDEwMCwgcmVhbGl6YWRvOiA5MS42LCBwZXJjZW50dWFsX2F0aW5naWRvOiA5MS42LCBzdGF0dXM6IFwiRW0gQW5kYW1lbnRvXCIgfSxcclxuICAgICAgICB9LFxyXG4gICAgICBdO1xyXG5cclxuICBjb25zdCBhbm9zRGlzcG9uaXZlaXMgPSBbMjAyNiwgMjAyNSwgMjAyNF07XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNiBwYi0xMlwiPlxyXG4gICAgICB7LyogVG9wIEJhbm5lciBFeGVjdXRpdm8gKi99XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGFyazpiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtODAwIHJvdW5kZWQteGwgcC02IHNoYWRvdy14c1wiPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBtZDpmbGV4LXJvdyBtZDppdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC00XCI+XHJcbiAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicC0xLjUgcm91bmRlZC1sZyBiZy10ZWFsLTUwIGRhcms6YmctdGVhbC05NTAvNDAgdGV4dC10ZWFsLTYwMCBkYXJrOnRleHQtdGVhbC00MDBcIj5cclxuICAgICAgICAgICAgICAgIDxCYXJDaGFydDMgY2xhc3NOYW1lPVwidy01IGgtNVwiIC8+XHJcbiAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LXhsIHNtOnRleHQtMnhsIGZvbnQtYm9sZCB0cmFja2luZy10aWdodCB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGVcIj5cclxuICAgICAgICAgICAgICAgIFBhaW5lbCBFeGVjdXRpdm8gZGUgTWV0YXMgJiBJbmRpY2Fkb3JlcyBTYW5pdMOhcmlvc1xyXG4gICAgICAgICAgICAgIDwvaDE+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHNtOnRleHQtc20gdGV4dC1zbGF0ZS01MDAgZGFyazp0ZXh0LXNsYXRlLTQwMCBtdC0xLjVcIj5cclxuICAgICAgICAgICAgICBNb25pdG9yYW1lbnRvIG9maWNpYWwgZG8gUGFjdG8gZGEgU2HDumRlLCBESUdJU1VTIGUgdmlnaWzDom5jaWEgZGUgcmlzY29zIGRlIHtBUFBfQ09ORklHLm11bmljaXBpb30ve0FQUF9DT05GSUcudWZ9LlxyXG4gICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICB7LyogQ29udHJvbGVzIGRlIEHDp8OjbyBlIFNlbGV0b3IgZGUgQW5vICovfVxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBpdGVtcy1jZW50ZXIgZ2FwLTIuNVwiPlxyXG4gICAgICAgICAgICB7LyogU2VsZXRvciBkZSBBbm8gKi99XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBiZy1zbGF0ZS0xMDAgZGFyazpiZy1zbGF0ZS04MDAgcC0xIHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtNzAwXCI+XHJcbiAgICAgICAgICAgICAgPENhbGVuZGFyIGNsYXNzTmFtZT1cInctMy41IGgtMy41IHRleHQtc2xhdGUtNTAwIG1sLTEuNVwiIC8+XHJcbiAgICAgICAgICAgICAgPHNlbGVjdFxyXG4gICAgICAgICAgICAgICAgdmFsdWU9e2Fub0V4ZXJjaWNpb31cclxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0QW5vRXhlcmNpY2lvKE51bWJlcihlLnRhcmdldC52YWx1ZSkpfVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctdHJhbnNwYXJlbnQgdGV4dC14cyBmb250LWJvbGQgdGV4dC1zbGF0ZS04MDAgZGFyazp0ZXh0LXNsYXRlLTIwMCBmb2N1czpvdXRsaW5lLW5vbmUgcHItMiBweS0wLjVcIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIHthbm9zRGlzcG9uaXZlaXMubWFwKChhKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgIDxvcHRpb24ga2V5PXthfSB2YWx1ZT17YX0gY2xhc3NOYW1lPVwiZGFyazpiZy1zbGF0ZS04MDAgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgRXhlcmPDrWNpbyB7YX1cclxuICAgICAgICAgICAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICA8L3NlbGVjdD5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICB7LyogQm90w6NvIGRlIEF0dWFsaXphciBDYWNoZSAqL31cclxuICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHJlZmV0Y2goKX1cclxuICAgICAgICAgICAgICBkaXNhYmxlZD17aXNSZWZldGNoaW5nfVxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMiB0ZXh0LXNsYXRlLTYwMCBkYXJrOnRleHQtc2xhdGUtMzAwIGhvdmVyOnRleHQtc2xhdGUtOTAwIGRhcms6aG92ZXI6dGV4dC13aGl0ZSBiZy1zbGF0ZS0xMDAgZGFyazpiZy1zbGF0ZS04MDAgaG92ZXI6Ymctc2xhdGUtMjAwIGRhcms6aG92ZXI6Ymctc2xhdGUtNzAwIHJvdW5kZWQtbGcgdHJhbnNpdGlvbi1jb2xvcnNcIlxyXG4gICAgICAgICAgICAgIHRpdGxlPVwiUmVjYXJyZWdhciBEYWRvc1wiXHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICA8UmVmcmVzaEN3IGNsYXNzTmFtZT17YHctNCBoLTQgJHtpc1JlZmV0Y2hpbmcgPyBcImFuaW1hdGUtc3BpbiB0ZXh0LXRlYWwtNjAwXCIgOiBcIlwifWB9IC8+XHJcbiAgICAgICAgICAgIDwvYnV0dG9uPlxyXG5cclxuICAgICAgICAgICAgey8qIEJvdMOjbyBPZmljaWFsOiBHZXJhciBSZWxhdMOzcmlvIFNVUyAqL31cclxuICAgICAgICAgICAgPExpbmtcclxuICAgICAgICAgICAgICB0bz17Uk9VVEVTLlJFTEFUT1JJT1MuU1VTKGFub0V4ZXJjaWNpbyl9XHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHB4LTMuNSBweS0yIHRleHQteHMgZm9udC1ib2xkIHRleHQtd2hpdGUgYmctdGVhbC02MDAgaG92ZXI6YmctdGVhbC03MDAgcm91bmRlZC1sZyBzaGFkb3cteHMgaG92ZXI6c2hhZG93IHRyYW5zaXRpb24tYWxsXCJcclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIDxQcmludGVyIGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPlxyXG4gICAgICAgICAgICAgIDxzcGFuPkdlcmFyIFJlbGF0w7NyaW8gT2ZpY2lhbCBTVVM8L3NwYW4+XHJcbiAgICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICB7LyogQmFycmEgZGUgUmVzdW1vIFLDoXBpZG8gKi99XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0yIHNtOmdyaWQtY29scy00IGdhcC0zIHB0LTUgbXQtNSBib3JkZXItdCBib3JkZXItc2xhdGUtMTAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMFwiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTMgYmctc2xhdGUtNTAgZGFyazpiZy1zbGF0ZS04MDAvNDAgcm91bmRlZC1sZ1wiPlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB1cHBlcmNhc2UgZm9udC1ib2xkIHRleHQtc2xhdGUtNDAwIGJsb2NrIHRyYWNraW5nLXdpZGVyXCI+XHJcbiAgICAgICAgICAgICAgRW1wcmVzYXMgQXRpdmFzXHJcbiAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14bCBmb250LWJvbGQgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlIHRhYnVsYXItbnVtc1wiPlxyXG4gICAgICAgICAgICAgIHtkYXNoYm9hcmQ/LnRvdGFsX2VzdGFiZWxlY2ltZW50b3NfY2FkYXN0cmFkb3MgPz8gMjM5fVxyXG4gICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMyBiZy1zbGF0ZS01MCBkYXJrOmJnLXNsYXRlLTgwMC80MCByb3VuZGVkLWxnXCI+XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHVwcGVyY2FzZSBmb250LWJvbGQgdGV4dC1zbGF0ZS00MDAgYmxvY2sgdHJhY2tpbmctd2lkZXJcIj5cclxuICAgICAgICAgICAgICBWaXN0b3JpYXMgUmVhbGl6YWRhc1xyXG4gICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1ib2xkIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZSB0YWJ1bGFyLW51bXNcIj5cclxuICAgICAgICAgICAgICB7ZGFzaGJvYXJkPy50b3RhbF9pbnNwZWNvZXNfZXhlcmNpY2lvID8/IDg0fVxyXG4gICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMyBiZy1zbGF0ZS01MCBkYXJrOmJnLXNsYXRlLTgwMC80MCByb3VuZGVkLWxnXCI+XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHVwcGVyY2FzZSBmb250LWJvbGQgdGV4dC1zbGF0ZS00MDAgYmxvY2sgdHJhY2tpbmctd2lkZXJcIj5cclxuICAgICAgICAgICAgICBBbHZhcsOhcyBWaWdlbnRlc1xyXG4gICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1ib2xkIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZSB0YWJ1bGFyLW51bXNcIj5cclxuICAgICAgICAgICAgICB7ZGFzaGJvYXJkPy50b3RhbF9hbHZhcmFzX2F0aXZvcyA/PyAxNjJ9XHJcbiAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0zIGJnLXRlYWwtNTAvNTAgZGFyazpiZy10ZWFsLTk1MC8zMCBib3JkZXIgYm9yZGVyLXRlYWwtMTAwIGRhcms6Ym9yZGVyLXRlYWwtOTAwLzQwIHJvdW5kZWQtbGdcIj5cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdXBwZXJjYXNlIGZvbnQtYm9sZCB0ZXh0LXRlYWwtNzAwIGRhcms6dGV4dC10ZWFsLTQwMCBibG9jayB0cmFja2luZy13aWRlclwiPlxyXG4gICAgICAgICAgICAgIMONbmRpY2UgR2VyYWwgKElORC0xNSlcclxuICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LXRlYWwtNzAwIGRhcms6dGV4dC10ZWFsLTMwMCB0YWJ1bGFyLW51bXNcIj5cclxuICAgICAgICAgICAgICB7ZGFzaGJvYXJkPy5pbmRpY2Fkb3JfMTVfc2ludGV0aWNvLnByb2dyZXNzby5wZXJjZW50dWFsX2F0aW5naWRvLnRvRml4ZWQoMSkgPz8gXCI5MS42XCJ9JVxyXG4gICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICB7LyogU2XDp8OjbyAxOiBHcmlkIGRlIE1ldGFzIFBhY3R1YWRhcyAoSW5kaWNhZG9yZXMgMTEgYSAxNSkgKi99XHJcbiAgICAgIDxkaXY+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gbWItM1wiPlxyXG4gICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1ib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMzAwIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjVcIj5cclxuICAgICAgICAgICAgICA8VGFyZ2V0IGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC10ZWFsLTYwMFwiIC8+XHJcbiAgICAgICAgICAgICAgTWV0YXMgU2FuaXTDoXJpYXMgQW51YWlzIFBhY3R1YWRhcyAoSW5kaWNhZG9yZXMgMTEgYSAxNSlcclxuICAgICAgICAgICAgPC9oMj5cclxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTQwMFwiPlxyXG4gICAgICAgICAgICAgIFRheGEgZGUgYXRpbmdpbWVudG8gYWN1bXVsYWRvIGVtIHJlbGHDp8OjbyBhb3MgY29tcHJvbWlzc29zIGRvIFBsYW5vIE11bmljaXBhbCBkZSBTYcO6ZGVcclxuICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNTAwIGRhcms6dGV4dC1zbGF0ZS00MDAgaGlkZGVuIHNtOmlubGluZVwiPlxyXG4gICAgICAgICAgICBBbm8gZGUgUmVmZXLDqm5jaWE6IDxzdHJvbmc+e2Fub0V4ZXJjaWNpb308L3N0cm9uZz5cclxuICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAge2xvYWRpbmdEYXNoYm9hcmQgPyAoXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgbGc6Z3JpZC1jb2xzLTMgZ2FwLTRcIj5cclxuICAgICAgICAgICAge1sxLCAyLCAzLCA0LCA1XS5tYXAoKGkpID0+IChcclxuICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICBrZXk9e2l9XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC14bCBwLTYgaC00OCBhbmltYXRlLXB1bHNlXCJcclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICApKX1cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICkgOiAoXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgbGc6Z3JpZC1jb2xzLTMgZ2FwLTRcIj5cclxuICAgICAgICAgICAge2xpc3RhSW5kaWNhZG9yZXMubWFwKChpbmQpID0+IChcclxuICAgICAgICAgICAgICA8Q2FyZE1ldGFJbmRpY2Fkb3JcclxuICAgICAgICAgICAgICAgIGtleT17aW5kLmNvZGlnb31cclxuICAgICAgICAgICAgICAgIGluZGljYWRvcj17aW5kfVxyXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICBpZiAoaW5kLmNvZGlnbyA9PT0gXCJJTkQtMTFcIikge1xyXG4gICAgICAgICAgICAgICAgICAgIG5hdmlnYXRlKFJPVVRFUy5JTlNQRUNPRVMuTElTVCk7XHJcbiAgICAgICAgICAgICAgICAgIH0gZWxzZSBpZiAoaW5kLmNvZGlnbyA9PT0gXCJJTkQtMTJcIiB8fCBpbmQuY29kaWdvID09PSBcIklORC0xM1wiIHx8IGluZC5jb2RpZ28gPT09IFwiSU5ELTE0XCIpIHtcclxuICAgICAgICAgICAgICAgICAgICBuYXZpZ2F0ZShST1VURVMuRVNUQUJFTEVDSU1FTlRPUy5MSVNUKTtcclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICApKX1cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICl9XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgey8qIFNlw6fDo28gMjogR3LDoWZpY29zIFZpc3VhaXMgY29tIFJlY2hhcnRzIChSb3NjYSBkZSBSaXNjbyArIEJhcnJhcyBkZSBJbnNwZcOnw7VlcykgKi99XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBsZzpncmlkLWNvbHMtMiBnYXAtNlwiPlxyXG4gICAgICAgIDxHcmFmaWNvRGlzdHJpYnVpY2FvUmlzY29cclxuICAgICAgICAgIGRpc3RyaWJ1aWNhbz17ZGFzaGJvYXJkPy5kaXN0cmlidWljYW9fZXN0YWJlbGVjaW1lbnRvc19wb3JfcmlzY299XHJcbiAgICAgICAgICB0b3RhbENhZGFzdHJhZG9zPXtkYXNoYm9hcmQ/LnRvdGFsX2VzdGFiZWxlY2ltZW50b3NfY2FkYXN0cmFkb3N9XHJcbiAgICAgICAgLz5cclxuXHJcbiAgICAgICAgPEdyYWZpY29Fdm9sdWNhb0luc3BlY29lc1xyXG4gICAgICAgICAgYW5vPXthbm9FeGVyY2ljaW99XHJcbiAgICAgICAgICB0b3RhbFZhcHQ9e2Rhc2hib2FyZD8uaW5kaWNhZG9yXzExX3ZhcHQucHJvZ3Jlc3NvLnJlYWxpemFkb31cclxuICAgICAgICAgIHRvdGFsR2VyYWw9e2Rhc2hib2FyZD8udG90YWxfaW5zcGVjb2VzX2V4ZXJjaWNpb31cclxuICAgICAgICAvPlxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIHsvKiBTZcOnw6NvIDM6IFBhaW5lbCBkZSBBbGVydGFzIE9wZXJhY2lvbmFpcyBkZSBWZW5jaW1lbnRvICovfVxyXG4gICAgICA8VGFiZWxhQWxlcnRhc09wZXJhY2lvbmFpc1xyXG4gICAgICAgIGFsZXJ0YXM9e2FsZXJ0YXN9XHJcbiAgICAgICAgaXNMb2FkaW5nPXtsb2FkaW5nQWxlcnRhc31cclxuICAgICAgLz5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBEYXNoYm9hcmRJbmRpY2Fkb3Jlc1BhZ2U7XHJcbiJdfQ==