import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/fiscalizacao/ResultadoInspecaoBadge.tsx");const React = __vite__cjsImport0_react;const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];/**
* Componente Badge para Parecer e Resultado do Laudo Conclusivo
* Aprovado | Aprovado c/ Exigências | Notificado c/ Prazo | Auto de Infração | Interdição | Indeferido
*/
import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=0fd2848a";
import { AlertOctagon, AlertTriangle, Ban, CheckCircle2, FileWarning, ShieldCheck, XCircle } from "/node_modules/.vite/deps/lucide-react.js?v=0fd2848a";
var _jsxFileName = "E:/Projetos VSCODE/visa_braunas/src/components/fiscalizacao/ResultadoInspecaoBadge.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=0fd2848a";
const RESULTADO_CONFIG = {
	aprovado: {
		label: "Aprovado",
		bg: "bg-emerald-50 dark:bg-emerald-950/40",
		text: "text-emerald-700 dark:text-emerald-300",
		border: "border-emerald-200 dark:border-emerald-800",
		icon: CheckCircle2
	},
	aprovado_com_exigencias: {
		label: "Aprovado c/ Exigências",
		bg: "bg-teal-50 dark:bg-teal-950/40",
		text: "text-teal-700 dark:text-teal-300",
		border: "border-teal-200 dark:border-teal-800",
		icon: ShieldCheck
	},
	notificado_com_prazo: {
		label: "Notificado com Prazo",
		bg: "bg-amber-50 dark:bg-amber-950/40",
		text: "text-amber-700 dark:text-amber-300",
		border: "border-amber-200 dark:border-amber-800",
		icon: AlertTriangle
	},
	auto_infracao: {
		label: "Auto de Infração",
		bg: "bg-rose-50 dark:bg-rose-950/40",
		text: "text-rose-700 dark:text-rose-300",
		border: "border-rose-200 dark:border-rose-800",
		icon: FileWarning
	},
	interditado_parcialmente: {
		label: "Interdição Parcial",
		bg: "bg-purple-50 dark:bg-purple-950/40",
		text: "text-purple-700 dark:text-purple-300",
		border: "border-purple-200 dark:border-purple-800",
		icon: AlertOctagon
	},
	interditado_totalmente: {
		label: "Interdição Total",
		bg: "bg-red-50 dark:bg-red-950/40",
		text: "text-red-700 dark:text-red-300",
		border: "border-red-200 dark:border-red-800",
		icon: Ban
	},
	indeferido: {
		label: "Indeferido",
		bg: "bg-slate-100 dark:bg-slate-800",
		text: "text-slate-700 dark:text-slate-300",
		border: "border-slate-200 dark:border-slate-700",
		icon: XCircle
	}
};
export const ResultadoInspecaoBadge = ({ resultado, size = "sm" }) => {
	if (!resultado) {
		return /* @__PURE__ */ _jsxDEV("span", {
			className: "text-[11px] text-slate-400 italic",
			children: "Pendente de Laudo"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 84,
			columnNumber: 7
		}, this);
	}
	const config = RESULTADO_CONFIG[resultado] || {
		label: resultado.replace(/_/g, " "),
		bg: "bg-slate-100",
		text: "text-slate-700",
		border: "border-slate-200",
		icon: CheckCircle2
	};
	const Icon = config.icon;
	const sizeClasses = size === "sm" ? "text-[11px] px-2 py-0.5 gap-1 font-medium" : "text-xs px-2.5 py-1 gap-1.5 font-semibold";
	return /* @__PURE__ */ _jsxDEV("span", {
		className: `inline-flex items-center rounded-md border ${config.bg} ${config.text} ${config.border} ${sizeClasses} whitespace-nowrap`,
		children: [/* @__PURE__ */ _jsxDEV(Icon, { className: "w-3 h-3 shrink-0" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 106,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("span", { children: config.label }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 107,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 103,
		columnNumber: 5
	}, this);
};
_c = ResultadoInspecaoBadge;
export default ResultadoInspecaoBadge;
var _c;
$RefreshReg$(_c, "ResultadoInspecaoBadge");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/fiscalizacao/ResultadoInspecaoBadge.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("E:/Projetos VSCODE/visa_braunas/src/components/fiscalizacao/ResultadoInspecaoBadge.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("E:/Projetos VSCODE/visa_braunas/src/components/fiscalizacao/ResultadoInspecaoBadge.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "E:/Projetos VSCODE/visa_braunas/src/components/fiscalizacao/ResultadoInspecaoBadge.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7OztBQUtBLE9BQU8sV0FBVztBQUNsQixTQUNFLGNBQ0EsZUFDQSxLQUNBLGNBQ0EsYUFDQSxhQUNBLGVBQ0s7OztBQVFQLE1BQU0sbUJBR0Y7Q0FDRixVQUFVO0VBQ1IsT0FBTztFQUNQLElBQUk7RUFDSixNQUFNO0VBQ04sUUFBUTtFQUNSLE1BQU07Q0FDUjtDQUNBLHlCQUF5QjtFQUN2QixPQUFPO0VBQ1AsSUFBSTtFQUNKLE1BQU07RUFDTixRQUFRO0VBQ1IsTUFBTTtDQUNSO0NBQ0Esc0JBQXNCO0VBQ3BCLE9BQU87RUFDUCxJQUFJO0VBQ0osTUFBTTtFQUNOLFFBQVE7RUFDUixNQUFNO0NBQ1I7Q0FDQSxlQUFlO0VBQ2IsT0FBTztFQUNQLElBQUk7RUFDSixNQUFNO0VBQ04sUUFBUTtFQUNSLE1BQU07Q0FDUjtDQUNBLDBCQUEwQjtFQUN4QixPQUFPO0VBQ1AsSUFBSTtFQUNKLE1BQU07RUFDTixRQUFRO0VBQ1IsTUFBTTtDQUNSO0NBQ0Esd0JBQXdCO0VBQ3RCLE9BQU87RUFDUCxJQUFJO0VBQ0osTUFBTTtFQUNOLFFBQVE7RUFDUixNQUFNO0NBQ1I7Q0FDQSxZQUFZO0VBQ1YsT0FBTztFQUNQLElBQUk7RUFDSixNQUFNO0VBQ04sUUFBUTtFQUNSLE1BQU07Q0FDUjtBQUNGO0FBRUEsT0FBTyxNQUFNLDBCQUFpRSxFQUM1RSxXQUNBLE9BQU8sV0FDSDtDQUNKLElBQUksQ0FBQyxXQUFXO0VBQ2QsT0FDRSx3QkFBQyxRQUFEO0dBQU0sV0FBVTthQUFvQztFQUF1Qjs7Ozs7Q0FFL0U7Q0FFQSxNQUFNLFNBQVMsaUJBQWlCLGNBQWM7RUFDNUMsT0FBTyxVQUFVLFFBQVEsTUFBTSxHQUFHO0VBQ2xDLElBQUk7RUFDSixNQUFNO0VBQ04sUUFBUTtFQUNSLE1BQU07Q0FDUjtDQUVBLE1BQU0sT0FBTyxPQUFPO0NBQ3BCLE1BQU0sY0FDSixTQUFTLE9BQ0wsOENBQ0E7Q0FFTixPQUNFLHdCQUFDLFFBQUQ7RUFDRSxXQUFXLDhDQUE4QyxPQUFPLEdBQUcsR0FBRyxPQUFPLEtBQUssR0FBRyxPQUFPLE9BQU8sR0FBRyxZQUFZO1lBRHBILENBR0Usd0JBQUMsTUFBRCxFQUFNLFdBQVUsbUJBQW9COzs7O1lBQ3BDLHdCQUFDLFFBQUQsWUFBTyxPQUFPLE1BQVk7Ozs7VUFDdEI7Ozs7OztBQUVWOztBQUVBLGVBQWUiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiUmVzdWx0YWRvSW5zcGVjYW9CYWRnZS50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiLyoqXHJcbiAqIENvbXBvbmVudGUgQmFkZ2UgcGFyYSBQYXJlY2VyIGUgUmVzdWx0YWRvIGRvIExhdWRvIENvbmNsdXNpdm9cclxuICogQXByb3ZhZG8gfCBBcHJvdmFkbyBjLyBFeGlnw6puY2lhcyB8IE5vdGlmaWNhZG8gYy8gUHJhem8gfCBBdXRvIGRlIEluZnJhw6fDo28gfCBJbnRlcmRpw6fDo28gfCBJbmRlZmVyaWRvXHJcbiAqL1xyXG5cclxuaW1wb3J0IFJlYWN0IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQge1xyXG4gIEFsZXJ0T2N0YWdvbixcclxuICBBbGVydFRyaWFuZ2xlLFxyXG4gIEJhbixcclxuICBDaGVja0NpcmNsZTIsXHJcbiAgRmlsZVdhcm5pbmcsXHJcbiAgU2hpZWxkQ2hlY2ssXHJcbiAgWENpcmNsZSxcclxufSBmcm9tIFwibHVjaWRlLXJlYWN0XCI7XHJcbmltcG9ydCB7IFJlc3VsdGFkb0luc3BlY2FvIH0gZnJvbSBcIi4uLy4uL3R5cGVzL2Zpc2NhbGl6YWNhb1wiO1xyXG5cclxuaW50ZXJmYWNlIFJlc3VsdGFkb0luc3BlY2FvQmFkZ2VQcm9wcyB7XHJcbiAgcmVzdWx0YWRvPzogUmVzdWx0YWRvSW5zcGVjYW8gfCBzdHJpbmcgfCBudWxsO1xyXG4gIHNpemU/OiBcInNtXCIgfCBcIm1kXCI7XHJcbn1cclxuXHJcbmNvbnN0IFJFU1VMVEFET19DT05GSUc6IFJlY29yZDxcclxuICBzdHJpbmcsXHJcbiAgeyBsYWJlbDogc3RyaW5nOyBiZzogc3RyaW5nOyB0ZXh0OiBzdHJpbmc7IGJvcmRlcjogc3RyaW5nOyBpY29uOiBSZWFjdC5Db21wb25lbnRUeXBlPHsgY2xhc3NOYW1lPzogc3RyaW5nIH0+IH1cclxuPiA9IHtcclxuICBhcHJvdmFkbzoge1xyXG4gICAgbGFiZWw6IFwiQXByb3ZhZG9cIixcclxuICAgIGJnOiBcImJnLWVtZXJhbGQtNTAgZGFyazpiZy1lbWVyYWxkLTk1MC80MFwiLFxyXG4gICAgdGV4dDogXCJ0ZXh0LWVtZXJhbGQtNzAwIGRhcms6dGV4dC1lbWVyYWxkLTMwMFwiLFxyXG4gICAgYm9yZGVyOiBcImJvcmRlci1lbWVyYWxkLTIwMCBkYXJrOmJvcmRlci1lbWVyYWxkLTgwMFwiLFxyXG4gICAgaWNvbjogQ2hlY2tDaXJjbGUyLFxyXG4gIH0sXHJcbiAgYXByb3ZhZG9fY29tX2V4aWdlbmNpYXM6IHtcclxuICAgIGxhYmVsOiBcIkFwcm92YWRvIGMvIEV4aWfDqm5jaWFzXCIsXHJcbiAgICBiZzogXCJiZy10ZWFsLTUwIGRhcms6YmctdGVhbC05NTAvNDBcIixcclxuICAgIHRleHQ6IFwidGV4dC10ZWFsLTcwMCBkYXJrOnRleHQtdGVhbC0zMDBcIixcclxuICAgIGJvcmRlcjogXCJib3JkZXItdGVhbC0yMDAgZGFyazpib3JkZXItdGVhbC04MDBcIixcclxuICAgIGljb246IFNoaWVsZENoZWNrLFxyXG4gIH0sXHJcbiAgbm90aWZpY2Fkb19jb21fcHJhem86IHtcclxuICAgIGxhYmVsOiBcIk5vdGlmaWNhZG8gY29tIFByYXpvXCIsXHJcbiAgICBiZzogXCJiZy1hbWJlci01MCBkYXJrOmJnLWFtYmVyLTk1MC80MFwiLFxyXG4gICAgdGV4dDogXCJ0ZXh0LWFtYmVyLTcwMCBkYXJrOnRleHQtYW1iZXItMzAwXCIsXHJcbiAgICBib3JkZXI6IFwiYm9yZGVyLWFtYmVyLTIwMCBkYXJrOmJvcmRlci1hbWJlci04MDBcIixcclxuICAgIGljb246IEFsZXJ0VHJpYW5nbGUsXHJcbiAgfSxcclxuICBhdXRvX2luZnJhY2FvOiB7XHJcbiAgICBsYWJlbDogXCJBdXRvIGRlIEluZnJhw6fDo29cIixcclxuICAgIGJnOiBcImJnLXJvc2UtNTAgZGFyazpiZy1yb3NlLTk1MC80MFwiLFxyXG4gICAgdGV4dDogXCJ0ZXh0LXJvc2UtNzAwIGRhcms6dGV4dC1yb3NlLTMwMFwiLFxyXG4gICAgYm9yZGVyOiBcImJvcmRlci1yb3NlLTIwMCBkYXJrOmJvcmRlci1yb3NlLTgwMFwiLFxyXG4gICAgaWNvbjogRmlsZVdhcm5pbmcsXHJcbiAgfSxcclxuICBpbnRlcmRpdGFkb19wYXJjaWFsbWVudGU6IHtcclxuICAgIGxhYmVsOiBcIkludGVyZGnDp8OjbyBQYXJjaWFsXCIsXHJcbiAgICBiZzogXCJiZy1wdXJwbGUtNTAgZGFyazpiZy1wdXJwbGUtOTUwLzQwXCIsXHJcbiAgICB0ZXh0OiBcInRleHQtcHVycGxlLTcwMCBkYXJrOnRleHQtcHVycGxlLTMwMFwiLFxyXG4gICAgYm9yZGVyOiBcImJvcmRlci1wdXJwbGUtMjAwIGRhcms6Ym9yZGVyLXB1cnBsZS04MDBcIixcclxuICAgIGljb246IEFsZXJ0T2N0YWdvbixcclxuICB9LFxyXG4gIGludGVyZGl0YWRvX3RvdGFsbWVudGU6IHtcclxuICAgIGxhYmVsOiBcIkludGVyZGnDp8OjbyBUb3RhbFwiLFxyXG4gICAgYmc6IFwiYmctcmVkLTUwIGRhcms6YmctcmVkLTk1MC80MFwiLFxyXG4gICAgdGV4dDogXCJ0ZXh0LXJlZC03MDAgZGFyazp0ZXh0LXJlZC0zMDBcIixcclxuICAgIGJvcmRlcjogXCJib3JkZXItcmVkLTIwMCBkYXJrOmJvcmRlci1yZWQtODAwXCIsXHJcbiAgICBpY29uOiBCYW4sXHJcbiAgfSxcclxuICBpbmRlZmVyaWRvOiB7XHJcbiAgICBsYWJlbDogXCJJbmRlZmVyaWRvXCIsXHJcbiAgICBiZzogXCJiZy1zbGF0ZS0xMDAgZGFyazpiZy1zbGF0ZS04MDBcIixcclxuICAgIHRleHQ6IFwidGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTMwMFwiLFxyXG4gICAgYm9yZGVyOiBcImJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtNzAwXCIsXHJcbiAgICBpY29uOiBYQ2lyY2xlLFxyXG4gIH0sXHJcbn07XHJcblxyXG5leHBvcnQgY29uc3QgUmVzdWx0YWRvSW5zcGVjYW9CYWRnZTogUmVhY3QuRkM8UmVzdWx0YWRvSW5zcGVjYW9CYWRnZVByb3BzPiA9ICh7XHJcbiAgcmVzdWx0YWRvLFxyXG4gIHNpemUgPSBcInNtXCIsXHJcbn0pID0+IHtcclxuICBpZiAoIXJlc3VsdGFkbykge1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1zbGF0ZS00MDAgaXRhbGljXCI+UGVuZGVudGUgZGUgTGF1ZG88L3NwYW4+XHJcbiAgICApO1xyXG4gIH1cclxuXHJcbiAgY29uc3QgY29uZmlnID0gUkVTVUxUQURPX0NPTkZJR1tyZXN1bHRhZG9dIHx8IHtcclxuICAgIGxhYmVsOiByZXN1bHRhZG8ucmVwbGFjZSgvXy9nLCBcIiBcIiksXHJcbiAgICBiZzogXCJiZy1zbGF0ZS0xMDBcIixcclxuICAgIHRleHQ6IFwidGV4dC1zbGF0ZS03MDBcIixcclxuICAgIGJvcmRlcjogXCJib3JkZXItc2xhdGUtMjAwXCIsXHJcbiAgICBpY29uOiBDaGVja0NpcmNsZTIsXHJcbiAgfTtcclxuXHJcbiAgY29uc3QgSWNvbiA9IGNvbmZpZy5pY29uO1xyXG4gIGNvbnN0IHNpemVDbGFzc2VzID1cclxuICAgIHNpemUgPT09IFwic21cIlxyXG4gICAgICA/IFwidGV4dC1bMTFweF0gcHgtMiBweS0wLjUgZ2FwLTEgZm9udC1tZWRpdW1cIlxyXG4gICAgICA6IFwidGV4dC14cyBweC0yLjUgcHktMSBnYXAtMS41IGZvbnQtc2VtaWJvbGRcIjtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxzcGFuXHJcbiAgICAgIGNsYXNzTmFtZT17YGlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciByb3VuZGVkLW1kIGJvcmRlciAke2NvbmZpZy5iZ30gJHtjb25maWcudGV4dH0gJHtjb25maWcuYm9yZGVyfSAke3NpemVDbGFzc2VzfSB3aGl0ZXNwYWNlLW5vd3JhcGB9XHJcbiAgICA+XHJcbiAgICAgIDxJY29uIGNsYXNzTmFtZT1cInctMyBoLTMgc2hyaW5rLTBcIiAvPlxyXG4gICAgICA8c3Bhbj57Y29uZmlnLmxhYmVsfTwvc3Bhbj5cclxuICAgIDwvc3Bhbj5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgUmVzdWx0YWRvSW5zcGVjYW9CYWRnZTtcclxuIl19