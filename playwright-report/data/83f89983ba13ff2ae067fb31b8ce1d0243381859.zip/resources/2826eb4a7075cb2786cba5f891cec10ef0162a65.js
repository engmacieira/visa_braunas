import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ProtectedRoute.tsx");const React = __vite__cjsImport0_react;const _jsxDEV = __vite__cjsImport6_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport6_react_jsxDevRuntime["Fragment"];/**
* Componente de Proteção de Rotas e Controle de Acesso Baseado em Perfis (RBAC)
* Redireciona usuários não autenticados para a tela de Login
* e exibe tela de 'Acesso Restrito' para servidores sem privilégios suficientes.
*/
import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=0fd2848a";
import { Link, Navigate, Outlet, useLocation } from "/node_modules/.vite/deps/react-router-dom.js?v=0fd2848a";
import { ShieldAlert } from "/node_modules/.vite/deps/lucide-react.js?v=0fd2848a";
import { APP_CONFIG } from "/src/config/app.config.ts";
import { ROUTES } from "/src/config/routes.config.ts";
import { useAuth } from "/src/contexts/AuthContext.tsx";
var _jsxFileName = "E:/Projetos VSCODE/visa_braunas/src/components/ProtectedRoute.tsx";
import __vite__cjsImport6_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=0fd2848a";
var _s = $RefreshSig$();
const PERFIL_LABELS = {
	admin_master: "Administrador Master",
	coordenador: "Coordenador de Vigilância",
	fiscal_tecnico: "Fiscal Técnico Sanitário",
	digitador: "Digitador Operacional"
};
export const ProtectedRoute = ({ allowedRoles, children }) => {
	_s();
	const { isAuthenticated, isLoading, user, hasPermission } = useAuth();
	const location = useLocation();
	// Estado de Carregamento Inicial da Sessão
	if (isLoading) {
		return /* @__PURE__ */ _jsxDEV("div", {
			className: "min-h-screen bg-slate-900 flex flex-col items-center justify-center text-slate-100 p-4",
			children: [
				/* @__PURE__ */ _jsxDEV("div", { className: "w-10 h-10 border-3 border-teal-500 border-t-transparent rounded-full animate-spin mb-4" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 38,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("h2", {
					className: "text-base font-semibold tracking-wide",
					children: APP_CONFIG.nome
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 39,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("p", {
					className: "text-xs text-slate-400 mt-1",
					children: "Validando credenciais de acesso seguro..."
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 42,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 37,
			columnNumber: 7
		}, this);
	}
	// Redirecionamento para Login se não autenticado
	if (!isAuthenticated || !user) {
		return /* @__PURE__ */ _jsxDEV(Navigate, {
			to: ROUTES.AUTH.LOGIN,
			state: { from: location },
			replace: true
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 51,
			columnNumber: 12
		}, this);
	}
	// Validação de Permissão por Perfil (RBAC)
	if (allowedRoles && allowedRoles.length > 0 && !hasPermission(allowedRoles)) {
		const rolesFormatadas = allowedRoles.map((r) => PERFIL_LABELS[r] || r).join(", ");
		return /* @__PURE__ */ _jsxDEV("div", {
			className: "min-h-[70vh] flex items-center justify-center p-6",
			children: /* @__PURE__ */ _jsxDEV("div", {
				className: "max-w-md w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-8 text-center shadow-xs",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "w-12 h-12 rounded-full bg-rose-50 dark:bg-rose-950/40 text-rose-600 dark:text-rose-400 flex items-center justify-center mx-auto mb-4",
						children: /* @__PURE__ */ _jsxDEV(ShieldAlert, { className: "w-6 h-6" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 64,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 63,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("h2", {
						className: "text-lg font-semibold text-slate-900 dark:text-slate-100",
						children: "Acesso Restrito"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 67,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("p", {
						className: "text-sm text-slate-600 dark:text-slate-400 mt-2",
						children: [
							"O seu perfil de acesso (",
							/* @__PURE__ */ _jsxDEV("span", {
								className: "font-medium text-slate-900 dark:text-slate-200",
								children: PERFIL_LABELS[user.perfil] || user.perfil
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 73,
								columnNumber: 13
							}, this),
							") não possui autorização regulatória para visualizar esta página."
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 71,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "mt-4 p-3 bg-slate-50 dark:bg-slate-800/60 rounded-lg text-xs text-slate-500 dark:text-slate-400 text-left",
						children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "font-semibold block text-slate-700 dark:text-slate-300 mb-1",
							children: "Perfis Habilitados:"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 80,
							columnNumber: 13
						}, this), rolesFormatadas]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 79,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "mt-6",
						children: /* @__PURE__ */ _jsxDEV(Link, {
							to: ROUTES.DASHBOARD,
							className: "inline-flex items-center justify-center px-4 py-2 text-xs font-medium text-white bg-slate-900 dark:bg-slate-800 dark:hover:bg-slate-700 rounded-lg hover:bg-slate-800 transition-colors",
							children: "Voltar ao Painel Geral"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 87,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 86,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 62,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 61,
			columnNumber: 7
		}, this);
	}
	return children ? /* @__PURE__ */ _jsxDEV(_Fragment, { children }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 99,
		columnNumber: 21
	}, this) : /* @__PURE__ */ _jsxDEV(Outlet, {}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 99,
		columnNumber: 39
	}, this);
};
_s(ProtectedRoute, "OBJXlKgN4kx/m3UCbfHVzbVNLpA=", false, function() {
	return [useAuth, useLocation];
});
_c = ProtectedRoute;
export default ProtectedRoute;
var _c;
$RefreshReg$(_c, "ProtectedRoute");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/ProtectedRoute.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("E:/Projetos VSCODE/visa_braunas/src/components/ProtectedRoute.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("E:/Projetos VSCODE/visa_braunas/src/components/ProtectedRoute.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "E:/Projetos VSCODE/visa_braunas/src/components/ProtectedRoute.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7Ozs7QUFNQSxPQUFPLFdBQVc7QUFDbEIsU0FBUyxNQUFNLFVBQVUsUUFBUSxtQkFBbUI7QUFDcEQsU0FBUyxtQkFBbUI7QUFDNUIsU0FBUyxrQkFBa0I7QUFDM0IsU0FBUyxjQUFjO0FBQ3ZCLFNBQVMsZUFBZTs7OztBQVF4QixNQUFNLGdCQUErQztDQUNuRCxjQUFjO0NBQ2QsYUFBYTtDQUNiLGdCQUFnQjtDQUNoQixXQUFXO0FBQ2I7QUFFQSxPQUFPLE1BQU0sa0JBQWlELEVBQzVELGNBQ0EsZUFDSTs7Q0FDSixNQUFNLEVBQUUsaUJBQWlCLFdBQVcsTUFBTSxrQkFBa0IsUUFBUTtDQUNwRSxNQUFNLFdBQVcsWUFBWTs7Q0FHN0IsSUFBSSxXQUFXO0VBQ2IsT0FDRSx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmO0lBQ0Usd0JBQUMsT0FBRCxFQUFLLFdBQVUseUZBQTBGOzs7OztJQUN6Ryx3QkFBQyxNQUFEO0tBQUksV0FBVTtlQUNYLFdBQVc7SUFDVjs7Ozs7SUFDSix3QkFBQyxLQUFEO0tBQUcsV0FBVTtlQUE4QjtJQUV4Qzs7Ozs7R0FDQTs7Ozs7O0NBRVQ7O0NBR0EsSUFBSSxDQUFDLG1CQUFtQixDQUFDLE1BQU07RUFDN0IsT0FBTyx3QkFBQyxVQUFEO0dBQVUsSUFBSSxPQUFPLEtBQUs7R0FBTyxPQUFPLEVBQUUsTUFBTSxTQUFTO0dBQUc7RUFBUzs7Ozs7Q0FDOUU7O0NBR0EsSUFBSSxnQkFBZ0IsYUFBYSxTQUFTLEtBQUssQ0FBQyxjQUFjLFlBQVksR0FBRztFQUMzRSxNQUFNLGtCQUFrQixhQUNyQixLQUFLLE1BQU0sY0FBYyxNQUFNLENBQUMsQ0FBQyxDQUNqQyxLQUFLLElBQUk7RUFFWixPQUNFLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQ2Isd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZjtLQUNFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUNiLHdCQUFDLGFBQUQsRUFBYSxXQUFVLFVBQVc7Ozs7O0tBQy9COzs7OztLQUVMLHdCQUFDLE1BQUQ7TUFBSSxXQUFVO2dCQUEyRDtLQUVyRTs7Ozs7S0FFSix3QkFBQyxLQUFEO01BQUcsV0FBVTtnQkFBYjtPQUErRDtPQUU3RCx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFDYixjQUFjLEtBQUssV0FBVyxLQUFLO09BQ2hDOzs7OztPQUFDO01BRU47Ozs7OztLQUVILHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsUUFBRDtPQUFNLFdBQVU7aUJBQThEO01BRXhFOzs7O2dCQUNMLGVBQ0U7Ozs7OztLQUVMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUNiLHdCQUFDLE1BQUQ7T0FDRSxJQUFJLE9BQU87T0FDWCxXQUFVO2lCQUNYO01BRUs7Ozs7O0tBQ0g7Ozs7O0lBQ0Y7Ozs7OztFQUNGOzs7OztDQUVUO0NBRUEsT0FBTyxXQUFXLHFDQUFHLFNBQVc7Ozs7WUFBSSx3QkFBQyxRQUFELENBQVM7Ozs7O0FBQy9DOzs7OztBQUVBLGVBQWUiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiUHJvdGVjdGVkUm91dGUudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbIi8qKlxyXG4gKiBDb21wb25lbnRlIGRlIFByb3Rlw6fDo28gZGUgUm90YXMgZSBDb250cm9sZSBkZSBBY2Vzc28gQmFzZWFkbyBlbSBQZXJmaXMgKFJCQUMpXHJcbiAqIFJlZGlyZWNpb25hIHVzdcOhcmlvcyBuw6NvIGF1dGVudGljYWRvcyBwYXJhIGEgdGVsYSBkZSBMb2dpblxyXG4gKiBlIGV4aWJlIHRlbGEgZGUgJ0FjZXNzbyBSZXN0cml0bycgcGFyYSBzZXJ2aWRvcmVzIHNlbSBwcml2aWzDqWdpb3Mgc3VmaWNpZW50ZXMuXHJcbiAqL1xyXG5cclxuaW1wb3J0IFJlYWN0IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgeyBMaW5rLCBOYXZpZ2F0ZSwgT3V0bGV0LCB1c2VMb2NhdGlvbiB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCI7XHJcbmltcG9ydCB7IFNoaWVsZEFsZXJ0IH0gZnJvbSBcImx1Y2lkZS1yZWFjdFwiO1xyXG5pbXBvcnQgeyBBUFBfQ09ORklHIH0gZnJvbSBcIi4uL2NvbmZpZy9hcHAuY29uZmlnXCI7XHJcbmltcG9ydCB7IFJPVVRFUyB9IGZyb20gXCIuLi9jb25maWcvcm91dGVzLmNvbmZpZ1wiO1xyXG5pbXBvcnQgeyB1c2VBdXRoIH0gZnJvbSBcIi4uL2NvbnRleHRzL0F1dGhDb250ZXh0XCI7XHJcbmltcG9ydCB7IFBlcmZpbFVzdWFyaW8gfSBmcm9tIFwiLi4vdHlwZXMvYXV0aFwiO1xyXG5cclxuaW50ZXJmYWNlIFByb3RlY3RlZFJvdXRlUHJvcHMge1xyXG4gIGFsbG93ZWRSb2xlcz86IFBlcmZpbFVzdWFyaW9bXTtcclxuICBjaGlsZHJlbj86IFJlYWN0LlJlYWN0Tm9kZTtcclxufVxyXG5cclxuY29uc3QgUEVSRklMX0xBQkVMUzogUmVjb3JkPFBlcmZpbFVzdWFyaW8sIHN0cmluZz4gPSB7XHJcbiAgYWRtaW5fbWFzdGVyOiBcIkFkbWluaXN0cmFkb3IgTWFzdGVyXCIsXHJcbiAgY29vcmRlbmFkb3I6IFwiQ29vcmRlbmFkb3IgZGUgVmlnaWzDom5jaWFcIixcclxuICBmaXNjYWxfdGVjbmljbzogXCJGaXNjYWwgVMOpY25pY28gU2FuaXTDoXJpb1wiLFxyXG4gIGRpZ2l0YWRvcjogXCJEaWdpdGFkb3IgT3BlcmFjaW9uYWxcIixcclxufTtcclxuXHJcbmV4cG9ydCBjb25zdCBQcm90ZWN0ZWRSb3V0ZTogUmVhY3QuRkM8UHJvdGVjdGVkUm91dGVQcm9wcz4gPSAoe1xyXG4gIGFsbG93ZWRSb2xlcyxcclxuICBjaGlsZHJlbixcclxufSkgPT4ge1xyXG4gIGNvbnN0IHsgaXNBdXRoZW50aWNhdGVkLCBpc0xvYWRpbmcsIHVzZXIsIGhhc1Blcm1pc3Npb24gfSA9IHVzZUF1dGgoKTtcclxuICBjb25zdCBsb2NhdGlvbiA9IHVzZUxvY2F0aW9uKCk7XHJcblxyXG4gIC8vIEVzdGFkbyBkZSBDYXJyZWdhbWVudG8gSW5pY2lhbCBkYSBTZXNzw6NvXHJcbiAgaWYgKGlzTG9hZGluZykge1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJtaW4taC1zY3JlZW4gYmctc2xhdGUtOTAwIGZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRleHQtc2xhdGUtMTAwIHAtNFwiPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xMCBoLTEwIGJvcmRlci0zIGJvcmRlci10ZWFsLTUwMCBib3JkZXItdC10cmFuc3BhcmVudCByb3VuZGVkLWZ1bGwgYW5pbWF0ZS1zcGluIG1iLTRcIiAvPlxyXG4gICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LWJhc2UgZm9udC1zZW1pYm9sZCB0cmFja2luZy13aWRlXCI+XHJcbiAgICAgICAgICB7QVBQX0NPTkZJRy5ub21lfVxyXG4gICAgICAgIDwvaDI+XHJcbiAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTQwMCBtdC0xXCI+XHJcbiAgICAgICAgICBWYWxpZGFuZG8gY3JlZGVuY2lhaXMgZGUgYWNlc3NvIHNlZ3Vyby4uLlxyXG4gICAgICAgIDwvcD5cclxuICAgICAgPC9kaXY+XHJcbiAgICApO1xyXG4gIH1cclxuXHJcbiAgLy8gUmVkaXJlY2lvbmFtZW50byBwYXJhIExvZ2luIHNlIG7Do28gYXV0ZW50aWNhZG9cclxuICBpZiAoIWlzQXV0aGVudGljYXRlZCB8fCAhdXNlcikge1xyXG4gICAgcmV0dXJuIDxOYXZpZ2F0ZSB0bz17Uk9VVEVTLkFVVEguTE9HSU59IHN0YXRlPXt7IGZyb206IGxvY2F0aW9uIH19IHJlcGxhY2UgLz47XHJcbiAgfVxyXG5cclxuICAvLyBWYWxpZGHDp8OjbyBkZSBQZXJtaXNzw6NvIHBvciBQZXJmaWwgKFJCQUMpXHJcbiAgaWYgKGFsbG93ZWRSb2xlcyAmJiBhbGxvd2VkUm9sZXMubGVuZ3RoID4gMCAmJiAhaGFzUGVybWlzc2lvbihhbGxvd2VkUm9sZXMpKSB7XHJcbiAgICBjb25zdCByb2xlc0Zvcm1hdGFkYXMgPSBhbGxvd2VkUm9sZXNcclxuICAgICAgLm1hcCgocikgPT4gUEVSRklMX0xBQkVMU1tyXSB8fCByKVxyXG4gICAgICAuam9pbihcIiwgXCIpO1xyXG5cclxuICAgIHJldHVybiAoXHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWluLWgtWzcwdmhdIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHAtNlwiPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWF4LXctbWQgdy1mdWxsIGJnLXdoaXRlIGRhcms6Ymctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLXhsIHAtOCB0ZXh0LWNlbnRlciBzaGFkb3cteHNcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xMiBoLTEyIHJvdW5kZWQtZnVsbCBiZy1yb3NlLTUwIGRhcms6Ymctcm9zZS05NTAvNDAgdGV4dC1yb3NlLTYwMCBkYXJrOnRleHQtcm9zZS00MDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgbXgtYXV0byBtYi00XCI+XHJcbiAgICAgICAgICAgIDxTaGllbGRBbGVydCBjbGFzc05hbWU9XCJ3LTYgaC02XCIgLz5cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXNsYXRlLTEwMFwiPlxyXG4gICAgICAgICAgICBBY2Vzc28gUmVzdHJpdG9cclxuICAgICAgICAgIDwvaDI+XHJcblxyXG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LXNsYXRlLTYwMCBkYXJrOnRleHQtc2xhdGUtNDAwIG10LTJcIj5cclxuICAgICAgICAgICAgTyBzZXUgcGVyZmlsIGRlIGFjZXNzbyAoXHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC1zbGF0ZS0yMDBcIj5cclxuICAgICAgICAgICAgICB7UEVSRklMX0xBQkVMU1t1c2VyLnBlcmZpbF0gfHwgdXNlci5wZXJmaWx9XHJcbiAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgKSBuw6NvIHBvc3N1aSBhdXRvcml6YcOnw6NvIHJlZ3VsYXTDs3JpYSBwYXJhIHZpc3VhbGl6YXIgZXN0YSBww6FnaW5hLlxyXG4gICAgICAgICAgPC9wPlxyXG5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNCBwLTMgYmctc2xhdGUtNTAgZGFyazpiZy1zbGF0ZS04MDAvNjAgcm91bmRlZC1sZyB0ZXh0LXhzIHRleHQtc2xhdGUtNTAwIGRhcms6dGV4dC1zbGF0ZS00MDAgdGV4dC1sZWZ0XCI+XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgYmxvY2sgdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTMwMCBtYi0xXCI+XHJcbiAgICAgICAgICAgICAgUGVyZmlzIEhhYmlsaXRhZG9zOlxyXG4gICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgIHtyb2xlc0Zvcm1hdGFkYXN9XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTZcIj5cclxuICAgICAgICAgICAgPExpbmtcclxuICAgICAgICAgICAgICB0bz17Uk9VVEVTLkRBU0hCT0FSRH1cclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcHgtNCBweS0yIHRleHQteHMgZm9udC1tZWRpdW0gdGV4dC13aGl0ZSBiZy1zbGF0ZS05MDAgZGFyazpiZy1zbGF0ZS04MDAgZGFyazpob3ZlcjpiZy1zbGF0ZS03MDAgcm91bmRlZC1sZyBob3ZlcjpiZy1zbGF0ZS04MDAgdHJhbnNpdGlvbi1jb2xvcnNcIlxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgVm9sdGFyIGFvIFBhaW5lbCBHZXJhbFxyXG4gICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcbiAgICApO1xyXG4gIH1cclxuXHJcbiAgcmV0dXJuIGNoaWxkcmVuID8gPD57Y2hpbGRyZW59PC8+IDogPE91dGxldCAvPjtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IFByb3RlY3RlZFJvdXRlO1xyXG4iXX0=