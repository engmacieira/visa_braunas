import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/licenciamento/ModalEmitirAlvara.tsx");const React = __vite__cjsImport0_react;const _jsxDEV = __vite__cjsImport6_react_jsxDevRuntime["jsxDEV"];/**
* Modal de Expedição e Emissão Oficial de Alvará Sanitário
* Permite revisão final das condicionantes, vigência e geração com QR Code.
*/
import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=0fd2848a";
import { useForm } from "/node_modules/.vite/deps/react-hook-form.js?v=0fd2848a";
import { zodResolver } from "/node_modules/.vite/deps/@hookform_resolvers_zod.js?v=0fd2848a";
import * as z from "/node_modules/.vite/deps/zod.js?v=0fd2848a";
import { AlertTriangle, Award, Calendar, FileCheck2, ShieldCheck, X } from "/node_modules/.vite/deps/lucide-react.js?v=0fd2848a";
import { useEmitirAlvaraMutation } from "/src/hooks/useLicenciamento.ts";
var _jsxFileName = "E:/Projetos VSCODE/visa_braunas/src/components/licenciamento/ModalEmitirAlvara.tsx";
import __vite__cjsImport6_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=0fd2848a";
var _s = $RefreshSig$();
const emitirAlvaraSchema = z.object({
	validade_meses: z.number().min(1, "Mínimo 1 mês").max(60, "Máximo 60 meses"),
	condicionantes_restricoes: z.string().max(2e3, "Máximo 2000 caracteres").optional()
});
export const ModalEmitirAlvara = ({ isOpen, onClose, estabelecimentoId, requerimentoId, inspecaoId, razaoSocial, cnpjCpf, onSucesso }) => {
	_s();
	const emitirMutation = useEmitirAlvaraMutation();
	const { register, handleSubmit, watch, formState: { errors, isSubmitting } } = useForm({
		resolver: zodResolver(emitirAlvaraSchema),
		defaultValues: {
			validade_meses: 12,
			condicionantes_restricoes: ""
		}
	});
	const validadeMeses = watch("validade_meses") || 12;
	// Cálculo da data prevista de vencimento
	const hoje = new Date();
	const dataVencimentoPrevista = new Date();
	dataVencimentoPrevista.setMonth(dataVencimentoPrevista.getMonth() + Number(validadeMeses));
	if (!isOpen) return null;
	const onSubmit = async (data) => {
		try {
			const payload = {
				estabelecimento_id: estabelecimentoId,
				requerimento_id: requerimentoId || undefined,
				inspecao_conclusiva_id: inspecaoId || undefined,
				validade_meses: Number(data.validade_meses),
				condicionantes_restricoes: data.condicionantes_restricoes?.trim() || undefined
			};
			const alvaraCriado = await emitirMutation.mutateAsync(payload);
			if (onSucesso) {
				onSucesso(alvaraCriado);
			}
			onClose();
		} catch {}
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-xs",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl w-full max-w-lg shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150 flex flex-col",
			children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "px-6 py-4 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between bg-slate-50/50 dark:bg-slate-800/40",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-2.5",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "w-9 h-9 rounded-xl bg-teal-100 dark:bg-teal-950/60 text-teal-700 dark:text-teal-300 flex items-center justify-center",
						children: /* @__PURE__ */ _jsxDEV(Award, { className: "w-5 h-5" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 101,
							columnNumber: 15
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 100,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h2", {
						className: "text-sm font-bold text-slate-900 dark:text-white",
						children: "Expedição Oficial de Alvará Sanitário"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 104,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("p", {
						className: "text-[11px] text-slate-500 dark:text-slate-400",
						children: "Geração de numeração sequencial e código de autenticidade com QR Code"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 107,
						columnNumber: 15
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 103,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 99,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					onClick: onClose,
					className: "p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-300 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors",
					children: /* @__PURE__ */ _jsxDEV(X, { className: "w-5 h-5" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 117,
						columnNumber: 13
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 112,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 98,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("form", {
				onSubmit: handleSubmit(onSubmit),
				className: "p-6 space-y-4",
				children: [
					emitirMutation.isError && /* @__PURE__ */ _jsxDEV("div", {
						className: "p-3 bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 rounded-xl flex items-center gap-2 text-xs text-rose-700 dark:text-rose-300",
						children: [/* @__PURE__ */ _jsxDEV(AlertTriangle, { className: "w-4 h-4 shrink-0" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 125,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: emitirMutation.error instanceof Error ? emitirMutation.error.message : "Erro ao emitir o alvará sanitário. Verifique os dados e tente novamente." }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 126,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 124,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "p-3.5 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-xl space-y-1",
						children: [
							/* @__PURE__ */ _jsxDEV("span", {
								className: "text-[10px] uppercase font-bold text-slate-400 block tracking-wider",
								children: "Beneficiário / Estabelecimento"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 136,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("p", {
								className: "text-xs font-bold text-slate-900 dark:text-white truncate",
								children: razaoSocial || "Estabelecimento Selecionado"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 139,
								columnNumber: 13
							}, this),
							cnpjCpf && /* @__PURE__ */ _jsxDEV("p", {
								className: "text-[11px] font-mono text-slate-500 dark:text-slate-400",
								children: ["CNPJ/CPF: ", cnpjCpf]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 143,
								columnNumber: 15
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 135,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "grid grid-cols-1 sm:grid-cols-2 gap-4",
						children: [/* @__PURE__ */ _jsxDEV("div", { children: [
							/* @__PURE__ */ _jsxDEV("label", {
								className: "block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1",
								children: ["Vigência (Meses) ", /* @__PURE__ */ _jsxDEV("span", {
									className: "text-rose-500",
									children: "*"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 153,
									columnNumber: 34
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 152,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("input", {
								type: "number",
								min: "1",
								max: "60",
								...register("validade_meses", { valueAsNumber: true }),
								className: "w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-teal-500"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 155,
								columnNumber: 15
							}, this),
							errors.validade_meses && /* @__PURE__ */ _jsxDEV("p", {
								className: "text-[11px] text-rose-600 mt-1",
								children: errors.validade_meses.message
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 163,
								columnNumber: 17
							}, this)
						] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 151,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1",
							children: "Data Prevista de Vencimento"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 170,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "px-3 py-2 text-xs bg-slate-100 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-700 dark:text-slate-300 flex items-center gap-1.5 font-medium",
							children: [/* @__PURE__ */ _jsxDEV(Calendar, { className: "w-3.5 h-3.5 text-teal-600" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 174,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: dataVencimentoPrevista.toLocaleDateString("pt-BR") }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 175,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 173,
							columnNumber: 15
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 169,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 150,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", { children: [
						/* @__PURE__ */ _jsxDEV("label", {
							className: "block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1",
							children: "Condicionantes, Restrições ou Observações Técnicas (Opcional)"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 182,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("textarea", {
							rows: 3,
							...register("condicionantes_restricoes"),
							placeholder: "Ex: Válido exclusivamente para comercialização sem fracionamento. Manter rotina semestral de limpeza de caixas d'água.",
							className: "w-full p-2.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-teal-500"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 185,
							columnNumber: 13
						}, this),
						errors.condicionantes_restricoes && /* @__PURE__ */ _jsxDEV("p", {
							className: "text-[11px] text-rose-600 mt-1",
							children: errors.condicionantes_restricoes.message
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 192,
							columnNumber: 15
						}, this)
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 181,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "p-3 bg-teal-50/70 dark:bg-teal-950/30 border border-teal-200 dark:border-teal-800/60 rounded-xl flex items-start gap-2.5 text-xs text-teal-800 dark:text-teal-200",
						children: [/* @__PURE__ */ _jsxDEV(ShieldCheck, { className: "w-4 h-4 text-teal-600 mt-0.5 shrink-0" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 199,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("p", {
							className: "text-[11px] leading-relaxed",
							children: [
								"Ao emitir, o sistema registrará a numeração sequencial anual, gerará o token de autenticidade pública e atualizará a situação cadastral do estabelecimento para ",
								/* @__PURE__ */ _jsxDEV("strong", { children: "Válido" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 201,
									columnNumber: 175
								}, this),
								"."
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 200,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 198,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center justify-end gap-2.5 pt-3 border-t border-slate-100 dark:border-slate-800",
						children: [/* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							onClick: onClose,
							disabled: isSubmitting,
							className: "px-4 py-2 text-xs font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors",
							children: "Cancelar"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 207,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							type: "submit",
							disabled: isSubmitting,
							className: "px-5 py-2 text-xs font-bold text-white bg-teal-600 hover:bg-teal-700 rounded-lg shadow-xs transition-colors flex items-center gap-2 disabled:opacity-60",
							children: [/* @__PURE__ */ _jsxDEV(FileCheck2, { className: "w-4 h-4" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 220,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: isSubmitting ? "Emitindo..." : "Confirmar e Emitir Alvará" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 221,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 215,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 206,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 122,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 96,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 95,
		columnNumber: 5
	}, this);
};
_s(ModalEmitirAlvara, "Dgycgr5wswKD5Ur+uM8EqtDMxOg=", false, function() {
	return [useEmitirAlvaraMutation, useForm];
});
_c = ModalEmitirAlvara;
export default ModalEmitirAlvara;
var _c;
$RefreshReg$(_c, "ModalEmitirAlvara");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/licenciamento/ModalEmitirAlvara.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("E:/Projetos VSCODE/visa_braunas/src/components/licenciamento/ModalEmitirAlvara.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("E:/Projetos VSCODE/visa_braunas/src/components/licenciamento/ModalEmitirAlvara.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "E:/Projetos VSCODE/visa_braunas/src/components/licenciamento/ModalEmitirAlvara.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7OztBQUtBLE9BQU8sV0FBeUI7QUFDaEMsU0FBUyxlQUFlO0FBQ3hCLFNBQVMsbUJBQW1CO0FBQzVCLFlBQVksT0FBTztBQUNuQixTQUNFLGVBQ0EsT0FDQSxVQUVBLFlBQ0EsYUFDQSxTQUNLO0FBQ1AsU0FBUywrQkFBK0I7Ozs7QUFHeEMsTUFBTSxxQkFBcUIsRUFBRSxPQUFPO0NBQ2xDLGdCQUFnQixFQUFFLE9BQU8sQ0FBQyxDQUFDLElBQUksR0FBRyxjQUFjLENBQUMsQ0FBQyxJQUFJLElBQUksaUJBQWlCO0NBQzNFLDJCQUEyQixFQUFFLE9BQU8sQ0FBQyxDQUFDLElBQUksS0FBTSx3QkFBd0IsQ0FBQyxDQUFDLFNBQVM7QUFDckYsQ0FBQztBQWVELE9BQU8sTUFBTSxxQkFBdUQsRUFDbEUsUUFDQSxTQUNBLG1CQUNBLGdCQUNBLFlBQ0EsYUFDQSxTQUNBLGdCQUNJOztDQUNKLE1BQU0saUJBQWlCLHdCQUF3QjtDQUUvQyxNQUFNLEVBQ0osVUFDQSxjQUNBLE9BQ0EsV0FBVyxFQUFFLFFBQVEsbUJBQ25CLFFBQThCO0VBQ2hDLFVBQVUsWUFBWSxrQkFBa0I7RUFDeEMsZUFBZTtHQUNiLGdCQUFnQjtHQUNoQiwyQkFBMkI7RUFDN0I7Q0FDRixDQUFDO0NBRUQsTUFBTSxnQkFBZ0IsTUFBTSxnQkFBZ0IsS0FBSzs7Q0FHakQsTUFBTSxPQUFPLElBQUksS0FBSztDQUN0QixNQUFNLHlCQUF5QixJQUFJLEtBQUs7Q0FDeEMsdUJBQXVCLFNBQVMsdUJBQXVCLFNBQVMsSUFBSSxPQUFPLGFBQWEsQ0FBQztDQUV6RixJQUFJLENBQUMsUUFBUSxPQUFPO0NBRXBCLE1BQU0sV0FBVyxPQUFPLFNBQStCO0VBQ3JELElBQUk7R0FDRixNQUFNLFVBQTJCO0lBQy9CLG9CQUFvQjtJQUNwQixpQkFBaUIsa0JBQWtCO0lBQ25DLHdCQUF3QixjQUFjO0lBQ3RDLGdCQUFnQixPQUFPLEtBQUssY0FBYztJQUMxQywyQkFBMkIsS0FBSywyQkFBMkIsS0FBSyxLQUFLO0dBQ3ZFO0dBRUEsTUFBTSxlQUFlLE1BQU0sZUFBZSxZQUFZLE9BQU87R0FDN0QsSUFBSSxXQUFXO0lBQ2IsVUFBVSxZQUFZO0dBQ3hCO0dBQ0EsUUFBUTtFQUNWLFFBQVEsQ0FFUjtDQUNGO0NBRUEsT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUNiLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWYsQ0FFRSx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUNiLHdCQUFDLE9BQUQsRUFBTyxXQUFVLFVBQVc7Ozs7O0tBQ3pCOzs7O2VBQ0wsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE1BQUQ7TUFBSSxXQUFVO2dCQUFtRDtLQUU3RDs7OztlQUNKLHdCQUFDLEtBQUQ7TUFBRyxXQUFVO2dCQUFpRDtLQUUzRDs7OzthQUNBOzs7O2FBQ0Y7Ozs7O2NBQ0wsd0JBQUMsVUFBRDtLQUNFLE1BQUs7S0FDTCxTQUFTO0tBQ1QsV0FBVTtlQUVWLHdCQUFDLEdBQUQsRUFBRyxXQUFVLFVBQVc7Ozs7O0lBQ2xCOzs7O1lBQ0w7Ozs7O2FBR0wsd0JBQUMsUUFBRDtJQUFNLFVBQVUsYUFBYSxRQUFRO0lBQUcsV0FBVTtjQUFsRDtLQUNHLGVBQWUsV0FDZCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLGVBQUQsRUFBZSxXQUFVLG1CQUFvQjs7OztnQkFDN0Msd0JBQUMsUUFBRCxZQUNHLGVBQWUsaUJBQWlCLFFBQzdCLGVBQWUsTUFBTSxVQUNyQiwyRUFDQTs7OztjQUNIOzs7Ozs7S0FJUCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZjtPQUNFLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUFzRTtPQUVoRjs7Ozs7T0FDTix3QkFBQyxLQUFEO1FBQUcsV0FBVTtrQkFDVixlQUFlO09BQ2Y7Ozs7O09BQ0YsV0FDQyx3QkFBQyxLQUFEO1FBQUcsV0FBVTtrQkFBYixDQUF3RSxjQUMzRCxPQUNWOzs7Ozs7TUFFRjs7Ozs7O0tBR0wsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxPQUFEO09BQ0Usd0JBQUMsU0FBRDtRQUFPLFdBQVU7a0JBQWpCLENBQXVGLHFCQUNwRSx3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFBZ0I7UUFBTzs7OztnQkFDbkQ7Ozs7OztPQUNQLHdCQUFDLFNBQUQ7UUFDRSxNQUFLO1FBQ0wsS0FBSTtRQUNKLEtBQUk7UUFDSixHQUFJLFNBQVMsa0JBQWtCLEVBQUUsZUFBZSxLQUFLLENBQUM7UUFDdEQsV0FBVTtPQUNYOzs7OztPQUNBLE9BQU8sa0JBQ04sd0JBQUMsS0FBRDtRQUFHLFdBQVU7a0JBQ1YsT0FBTyxlQUFlO09BQ3RCOzs7OztNQUVGOzs7O2dCQUVMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxRQUFEO09BQU0sV0FBVTtpQkFBc0U7TUFFaEY7Ozs7Z0JBQ04sd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxVQUFELEVBQVUsV0FBVSw0QkFBNkI7Ozs7aUJBQ2pELHdCQUFDLFFBQUQsWUFBTyx1QkFBdUIsbUJBQW1CLE9BQU8sRUFBUTs7OztlQUM3RDs7Ozs7Y0FDRjs7OztjQUNGOzs7Ozs7S0FHTCx3QkFBQyxPQUFEO01BQ0Usd0JBQUMsU0FBRDtPQUFPLFdBQVU7aUJBQXNFO01BRWhGOzs7OztNQUNQLHdCQUFDLFlBQUQ7T0FDRSxNQUFNO09BQ04sR0FBSSxTQUFTLDJCQUEyQjtPQUN4QyxhQUFZO09BQ1osV0FBVTtNQUNYOzs7OztNQUNBLE9BQU8sNkJBQ04sd0JBQUMsS0FBRDtPQUFHLFdBQVU7aUJBQ1YsT0FBTywwQkFBMEI7TUFDakM7Ozs7O0tBRUY7Ozs7O0tBRUwsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxhQUFELEVBQWEsV0FBVSx3Q0FBeUM7Ozs7Z0JBQ2hFLHdCQUFDLEtBQUQ7T0FBRyxXQUFVO2lCQUFiO1FBQTJDO1FBQ3VILHdCQUFDLFVBQUQsWUFBUSxTQUFjOzs7OztRQUFDO09BQ3RMOzs7OztjQUNBOzs7Ozs7S0FHTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLFVBQUQ7T0FDRSxNQUFLO09BQ0wsU0FBUztPQUNULFVBQVU7T0FDVixXQUFVO2lCQUNYO01BRU87Ozs7Z0JBQ1Isd0JBQUMsVUFBRDtPQUNFLE1BQUs7T0FDTCxVQUFVO09BQ1YsV0FBVTtpQkFIWixDQUtFLHdCQUFDLFlBQUQsRUFBWSxXQUFVLFVBQVc7Ozs7aUJBQ2pDLHdCQUFDLFFBQUQsWUFBTyxlQUFlLGdCQUFnQiw0QkFBa0M7Ozs7ZUFDbEU7Ozs7O2NBQ0w7Ozs7OztJQUNEOzs7OztXQUNIOzs7Ozs7Q0FDRjs7Ozs7QUFFVDs7Ozs7QUFFQSxlQUFlIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIk1vZGFsRW1pdGlyQWx2YXJhLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyIvKipcclxuICogTW9kYWwgZGUgRXhwZWRpw6fDo28gZSBFbWlzc8OjbyBPZmljaWFsIGRlIEFsdmFyw6EgU2FuaXTDoXJpb1xyXG4gKiBQZXJtaXRlIHJldmlzw6NvIGZpbmFsIGRhcyBjb25kaWNpb25hbnRlcywgdmlnw6puY2lhIGUgZ2VyYcOnw6NvIGNvbSBRUiBDb2RlLlxyXG4gKi9cclxuXHJcbmltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgeyB1c2VGb3JtIH0gZnJvbSBcInJlYWN0LWhvb2stZm9ybVwiO1xyXG5pbXBvcnQgeyB6b2RSZXNvbHZlciB9IGZyb20gXCJAaG9va2Zvcm0vcmVzb2x2ZXJzL3pvZFwiO1xyXG5pbXBvcnQgKiBhcyB6IGZyb20gXCJ6b2RcIjtcclxuaW1wb3J0IHtcclxuICBBbGVydFRyaWFuZ2xlLFxyXG4gIEF3YXJkLFxyXG4gIENhbGVuZGFyLFxyXG4gIENoZWNrQ2lyY2xlMixcclxuICBGaWxlQ2hlY2syLFxyXG4gIFNoaWVsZENoZWNrLFxyXG4gIFgsXHJcbn0gZnJvbSBcImx1Y2lkZS1yZWFjdFwiO1xyXG5pbXBvcnQgeyB1c2VFbWl0aXJBbHZhcmFNdXRhdGlvbiB9IGZyb20gXCIuLi8uLi9ob29rcy91c2VMaWNlbmNpYW1lbnRvXCI7XHJcbmltcG9ydCB7IEFsdmFyYVNhbml0YXJpb0RldGFsaGUsIEVtaXRpckFsdmFyYURUTyB9IGZyb20gXCIuLi8uLi90eXBlcy9saWNlbmNpYW1lbnRvXCI7XHJcblxyXG5jb25zdCBlbWl0aXJBbHZhcmFTY2hlbWEgPSB6Lm9iamVjdCh7XHJcbiAgdmFsaWRhZGVfbWVzZXM6IHoubnVtYmVyKCkubWluKDEsIFwiTcOtbmltbyAxIG3DqnNcIikubWF4KDYwLCBcIk3DoXhpbW8gNjAgbWVzZXNcIiksXHJcbiAgY29uZGljaW9uYW50ZXNfcmVzdHJpY29lczogei5zdHJpbmcoKS5tYXgoMjAwMCwgXCJNw6F4aW1vIDIwMDAgY2FyYWN0ZXJlc1wiKS5vcHRpb25hbCgpLFxyXG59KTtcclxuXHJcbnR5cGUgRW1pdGlyQWx2YXJhRm9ybURhdGEgPSB6LmluZmVyPHR5cGVvZiBlbWl0aXJBbHZhcmFTY2hlbWE+O1xyXG5cclxuaW50ZXJmYWNlIE1vZGFsRW1pdGlyQWx2YXJhUHJvcHMge1xyXG4gIGlzT3BlbjogYm9vbGVhbjtcclxuICBvbkNsb3NlOiAoKSA9PiB2b2lkO1xyXG4gIGVzdGFiZWxlY2ltZW50b0lkOiBzdHJpbmc7XHJcbiAgcmVxdWVyaW1lbnRvSWQ/OiBzdHJpbmc7XHJcbiAgaW5zcGVjYW9JZD86IHN0cmluZztcclxuICByYXphb1NvY2lhbD86IHN0cmluZztcclxuICBjbnBqQ3BmPzogc3RyaW5nO1xyXG4gIG9uU3VjZXNzbz86IChhbHZhcmE6IEFsdmFyYVNhbml0YXJpb0RldGFsaGUpID0+IHZvaWQ7XHJcbn1cclxuXHJcbmV4cG9ydCBjb25zdCBNb2RhbEVtaXRpckFsdmFyYTogUmVhY3QuRkM8TW9kYWxFbWl0aXJBbHZhcmFQcm9wcz4gPSAoe1xyXG4gIGlzT3BlbixcclxuICBvbkNsb3NlLFxyXG4gIGVzdGFiZWxlY2ltZW50b0lkLFxyXG4gIHJlcXVlcmltZW50b0lkLFxyXG4gIGluc3BlY2FvSWQsXHJcbiAgcmF6YW9Tb2NpYWwsXHJcbiAgY25wakNwZixcclxuICBvblN1Y2Vzc28sXHJcbn0pID0+IHtcclxuICBjb25zdCBlbWl0aXJNdXRhdGlvbiA9IHVzZUVtaXRpckFsdmFyYU11dGF0aW9uKCk7XHJcblxyXG4gIGNvbnN0IHtcclxuICAgIHJlZ2lzdGVyLFxyXG4gICAgaGFuZGxlU3VibWl0LFxyXG4gICAgd2F0Y2gsXHJcbiAgICBmb3JtU3RhdGU6IHsgZXJyb3JzLCBpc1N1Ym1pdHRpbmcgfSxcclxuICB9ID0gdXNlRm9ybTxFbWl0aXJBbHZhcmFGb3JtRGF0YT4oe1xyXG4gICAgcmVzb2x2ZXI6IHpvZFJlc29sdmVyKGVtaXRpckFsdmFyYVNjaGVtYSksXHJcbiAgICBkZWZhdWx0VmFsdWVzOiB7XHJcbiAgICAgIHZhbGlkYWRlX21lc2VzOiAxMixcclxuICAgICAgY29uZGljaW9uYW50ZXNfcmVzdHJpY29lczogXCJcIixcclxuICAgIH0sXHJcbiAgfSk7XHJcblxyXG4gIGNvbnN0IHZhbGlkYWRlTWVzZXMgPSB3YXRjaChcInZhbGlkYWRlX21lc2VzXCIpIHx8IDEyO1xyXG5cclxuICAvLyBDw6FsY3VsbyBkYSBkYXRhIHByZXZpc3RhIGRlIHZlbmNpbWVudG9cclxuICBjb25zdCBob2plID0gbmV3IERhdGUoKTtcclxuICBjb25zdCBkYXRhVmVuY2ltZW50b1ByZXZpc3RhID0gbmV3IERhdGUoKTtcclxuICBkYXRhVmVuY2ltZW50b1ByZXZpc3RhLnNldE1vbnRoKGRhdGFWZW5jaW1lbnRvUHJldmlzdGEuZ2V0TW9udGgoKSArIE51bWJlcih2YWxpZGFkZU1lc2VzKSk7XHJcblxyXG4gIGlmICghaXNPcGVuKSByZXR1cm4gbnVsbDtcclxuXHJcbiAgY29uc3Qgb25TdWJtaXQgPSBhc3luYyAoZGF0YTogRW1pdGlyQWx2YXJhRm9ybURhdGEpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHBheWxvYWQ6IEVtaXRpckFsdmFyYURUTyA9IHtcclxuICAgICAgICBlc3RhYmVsZWNpbWVudG9faWQ6IGVzdGFiZWxlY2ltZW50b0lkLFxyXG4gICAgICAgIHJlcXVlcmltZW50b19pZDogcmVxdWVyaW1lbnRvSWQgfHwgdW5kZWZpbmVkLFxyXG4gICAgICAgIGluc3BlY2FvX2NvbmNsdXNpdmFfaWQ6IGluc3BlY2FvSWQgfHwgdW5kZWZpbmVkLFxyXG4gICAgICAgIHZhbGlkYWRlX21lc2VzOiBOdW1iZXIoZGF0YS52YWxpZGFkZV9tZXNlcyksXHJcbiAgICAgICAgY29uZGljaW9uYW50ZXNfcmVzdHJpY29lczogZGF0YS5jb25kaWNpb25hbnRlc19yZXN0cmljb2VzPy50cmltKCkgfHwgdW5kZWZpbmVkLFxyXG4gICAgICB9O1xyXG5cclxuICAgICAgY29uc3QgYWx2YXJhQ3JpYWRvID0gYXdhaXQgZW1pdGlyTXV0YXRpb24ubXV0YXRlQXN5bmMocGF5bG9hZCk7XHJcbiAgICAgIGlmIChvblN1Y2Vzc28pIHtcclxuICAgICAgICBvblN1Y2Vzc28oYWx2YXJhQ3JpYWRvKTtcclxuICAgICAgfVxyXG4gICAgICBvbkNsb3NlKCk7XHJcbiAgICB9IGNhdGNoIHtcclxuICAgICAgLy8gRXJybyDDqSB0cmF0YWRvIGUgZXhpYmlkbyB2aWEgbXV0YXRlIHN0YXRlXHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZml4ZWQgaW5zZXQtMCB6LTUwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHAtNCBiZy1ibGFjay81MCBiYWNrZHJvcC1ibHVyLXhzXCI+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGFyazpiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtODAwIHJvdW5kZWQtMnhsIHctZnVsbCBtYXgtdy1sZyBzaGFkb3ctMnhsIG92ZXJmbG93LWhpZGRlbiBhbmltYXRlLWluIGZhZGUtaW4gem9vbS1pbi05NSBkdXJhdGlvbi0xNTAgZmxleCBmbGV4LWNvbFwiPlxyXG4gICAgICAgIHsvKiBDYWJlw6dhbGhvICovfVxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHgtNiBweS00IGJvcmRlci1iIGJvcmRlci1zbGF0ZS0xMDAgZGFyazpib3JkZXItc2xhdGUtODAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBiZy1zbGF0ZS01MC81MCBkYXJrOmJnLXNsYXRlLTgwMC80MFwiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMi41XCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy05IGgtOSByb3VuZGVkLXhsIGJnLXRlYWwtMTAwIGRhcms6YmctdGVhbC05NTAvNjAgdGV4dC10ZWFsLTcwMCBkYXJrOnRleHQtdGVhbC0zMDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICA8QXdhcmQgY2xhc3NOYW1lPVwidy01IGgtNVwiIC8+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGVcIj5cclxuICAgICAgICAgICAgICAgIEV4cGVkacOnw6NvIE9maWNpYWwgZGUgQWx2YXLDoSBTYW5pdMOhcmlvXHJcbiAgICAgICAgICAgICAgPC9oMj5cclxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LXNsYXRlLTUwMCBkYXJrOnRleHQtc2xhdGUtNDAwXCI+XHJcbiAgICAgICAgICAgICAgICBHZXJhw6fDo28gZGUgbnVtZXJhw6fDo28gc2VxdWVuY2lhbCBlIGPDs2RpZ28gZGUgYXV0ZW50aWNpZGFkZSBjb20gUVIgQ29kZVxyXG4gICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgIG9uQ2xpY2s9e29uQ2xvc2V9XHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMS41IHRleHQtc2xhdGUtNDAwIGhvdmVyOnRleHQtc2xhdGUtNjAwIGRhcms6aG92ZXI6dGV4dC1zbGF0ZS0zMDAgcm91bmRlZC1sZyBob3ZlcjpiZy1zbGF0ZS0xMDAgZGFyazpob3ZlcjpiZy1zbGF0ZS04MDAgdHJhbnNpdGlvbi1jb2xvcnNcIlxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICA8WCBjbGFzc05hbWU9XCJ3LTUgaC01XCIgLz5cclxuICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICB7LyogQ29ycG8gKi99XHJcbiAgICAgICAgPGZvcm0gb25TdWJtaXQ9e2hhbmRsZVN1Ym1pdChvblN1Ym1pdCl9IGNsYXNzTmFtZT1cInAtNiBzcGFjZS15LTRcIj5cclxuICAgICAgICAgIHtlbWl0aXJNdXRhdGlvbi5pc0Vycm9yICYmIChcclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTMgYmctcm9zZS01MCBkYXJrOmJnLXJvc2UtOTUwLzQwIGJvcmRlciBib3JkZXItcm9zZS0yMDAgZGFyazpib3JkZXItcm9zZS04MDAgcm91bmRlZC14bCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiB0ZXh0LXhzIHRleHQtcm9zZS03MDAgZGFyazp0ZXh0LXJvc2UtMzAwXCI+XHJcbiAgICAgICAgICAgICAgPEFsZXJ0VHJpYW5nbGUgY2xhc3NOYW1lPVwidy00IGgtNCBzaHJpbmstMFwiIC8+XHJcbiAgICAgICAgICAgICAgPHNwYW4+XHJcbiAgICAgICAgICAgICAgICB7ZW1pdGlyTXV0YXRpb24uZXJyb3IgaW5zdGFuY2VvZiBFcnJvclxyXG4gICAgICAgICAgICAgICAgICA/IGVtaXRpck11dGF0aW9uLmVycm9yLm1lc3NhZ2VcclxuICAgICAgICAgICAgICAgICAgOiBcIkVycm8gYW8gZW1pdGlyIG8gYWx2YXLDoSBzYW5pdMOhcmlvLiBWZXJpZmlxdWUgb3MgZGFkb3MgZSB0ZW50ZSBub3ZhbWVudGUuXCJ9XHJcbiAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgey8qIERhZG9zIGRvIEVzdGFiZWxlY2ltZW50byBEZXN0aW5hdMOhcmlvICovfVxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTMuNSBiZy1zbGF0ZS01MCBkYXJrOmJnLXNsYXRlLTgwMC82MCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC14bCBzcGFjZS15LTFcIj5cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdXBwZXJjYXNlIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTQwMCBibG9jayB0cmFja2luZy13aWRlclwiPlxyXG4gICAgICAgICAgICAgIEJlbmVmaWNpw6FyaW8gLyBFc3RhYmVsZWNpbWVudG9cclxuICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGUgdHJ1bmNhdGVcIj5cclxuICAgICAgICAgICAgICB7cmF6YW9Tb2NpYWwgfHwgXCJFc3RhYmVsZWNpbWVudG8gU2VsZWNpb25hZG9cIn1cclxuICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICB7Y25wakNwZiAmJiAoXHJcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gZm9udC1tb25vIHRleHQtc2xhdGUtNTAwIGRhcms6dGV4dC1zbGF0ZS00MDBcIj5cclxuICAgICAgICAgICAgICAgIENOUEovQ1BGOiB7Y25wakNwZn1cclxuICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICl9XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICB7LyogUHJhem8gZGUgVmFsaWRhZGUgKi99XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgc206Z3JpZC1jb2xzLTIgZ2FwLTRcIj5cclxuICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0zMDAgbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgVmlnw6puY2lhIChNZXNlcykgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yb3NlLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgbWluPVwiMVwiXHJcbiAgICAgICAgICAgICAgICBtYXg9XCI2MFwiXHJcbiAgICAgICAgICAgICAgICB7Li4ucmVnaXN0ZXIoXCJ2YWxpZGFkZV9tZXNlc1wiLCB7IHZhbHVlQXNOdW1iZXI6IHRydWUgfSl9XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIHRleHQteHMgYmctc2xhdGUtNTAgZGFyazpiZy1zbGF0ZS04MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQtbGcgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy10ZWFsLTUwMFwiXHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICB7ZXJyb3JzLnZhbGlkYWRlX21lc2VzICYmIChcclxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtcm9zZS02MDAgbXQtMVwiPlxyXG4gICAgICAgICAgICAgICAgICB7ZXJyb3JzLnZhbGlkYWRlX21lc2VzLm1lc3NhZ2V9XHJcbiAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImJsb2NrIHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMzAwIG1iLTFcIj5cclxuICAgICAgICAgICAgICAgIERhdGEgUHJldmlzdGEgZGUgVmVuY2ltZW50b1xyXG4gICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB4LTMgcHktMiB0ZXh0LXhzIGJnLXNsYXRlLTEwMCBkYXJrOmJnLXNsYXRlLTgwMC84MCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC1sZyB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMzAwIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgZm9udC1tZWRpdW1cIj5cclxuICAgICAgICAgICAgICAgIDxDYWxlbmRhciBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNSB0ZXh0LXRlYWwtNjAwXCIgLz5cclxuICAgICAgICAgICAgICAgIDxzcGFuPntkYXRhVmVuY2ltZW50b1ByZXZpc3RhLnRvTG9jYWxlRGF0ZVN0cmluZyhcInB0LUJSXCIpfTwvc3Bhbj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICB7LyogQ29uZGljaW9uYW50ZXMgZSBSZXN0cmnDp8O1ZXMgKi99XHJcbiAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0zMDAgbWItMVwiPlxyXG4gICAgICAgICAgICAgIENvbmRpY2lvbmFudGVzLCBSZXN0cmnDp8O1ZXMgb3UgT2JzZXJ2YcOnw7VlcyBUw6ljbmljYXMgKE9wY2lvbmFsKVxyXG4gICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICA8dGV4dGFyZWFcclxuICAgICAgICAgICAgICByb3dzPXszfVxyXG4gICAgICAgICAgICAgIHsuLi5yZWdpc3RlcihcImNvbmRpY2lvbmFudGVzX3Jlc3RyaWNvZXNcIil9XHJcbiAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFeDogVsOhbGlkbyBleGNsdXNpdmFtZW50ZSBwYXJhIGNvbWVyY2lhbGl6YcOnw6NvIHNlbSBmcmFjaW9uYW1lbnRvLiBNYW50ZXIgcm90aW5hIHNlbWVzdHJhbCBkZSBsaW1wZXphIGRlIGNhaXhhcyBkJ8OhZ3VhLlwiXHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHAtMi41IHRleHQteHMgYmctc2xhdGUtNTAgZGFyazpiZy1zbGF0ZS04MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQtbGcgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlIHBsYWNlaG9sZGVyLXNsYXRlLTQwMCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctdGVhbC01MDBcIlxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICB7ZXJyb3JzLmNvbmRpY2lvbmFudGVzX3Jlc3RyaWNvZXMgJiYgKFxyXG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtcm9zZS02MDAgbXQtMVwiPlxyXG4gICAgICAgICAgICAgICAge2Vycm9ycy5jb25kaWNpb25hbnRlc19yZXN0cmljb2VzLm1lc3NhZ2V9XHJcbiAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICApfVxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTMgYmctdGVhbC01MC83MCBkYXJrOmJnLXRlYWwtOTUwLzMwIGJvcmRlciBib3JkZXItdGVhbC0yMDAgZGFyazpib3JkZXItdGVhbC04MDAvNjAgcm91bmRlZC14bCBmbGV4IGl0ZW1zLXN0YXJ0IGdhcC0yLjUgdGV4dC14cyB0ZXh0LXRlYWwtODAwIGRhcms6dGV4dC10ZWFsLTIwMFwiPlxyXG4gICAgICAgICAgICA8U2hpZWxkQ2hlY2sgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LXRlYWwtNjAwIG10LTAuNSBzaHJpbmstMFwiIC8+XHJcbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIGxlYWRpbmctcmVsYXhlZFwiPlxyXG4gICAgICAgICAgICAgIEFvIGVtaXRpciwgbyBzaXN0ZW1hIHJlZ2lzdHJhcsOhIGEgbnVtZXJhw6fDo28gc2VxdWVuY2lhbCBhbnVhbCwgZ2VyYXLDoSBvIHRva2VuIGRlIGF1dGVudGljaWRhZGUgcMO6YmxpY2EgZSBhdHVhbGl6YXLDoSBhIHNpdHVhw6fDo28gY2FkYXN0cmFsIGRvIGVzdGFiZWxlY2ltZW50byBwYXJhIDxzdHJvbmc+VsOhbGlkbzwvc3Ryb25nPi5cclxuICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgey8qIEJvdMO1ZXMgZGUgQcOnw6NvICovfVxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWVuZCBnYXAtMi41IHB0LTMgYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTEwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDBcIj5cclxuICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgIG9uQ2xpY2s9e29uQ2xvc2V9XHJcbiAgICAgICAgICAgICAgZGlzYWJsZWQ9e2lzU3VibWl0dGluZ31cclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC00IHB5LTIgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNjAwIGRhcms6dGV4dC1zbGF0ZS0zMDAgaG92ZXI6Ymctc2xhdGUtMTAwIGRhcms6aG92ZXI6Ymctc2xhdGUtODAwIHJvdW5kZWQtbGcgdHJhbnNpdGlvbi1jb2xvcnNcIlxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgQ2FuY2VsYXJcclxuICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcclxuICAgICAgICAgICAgICBkaXNhYmxlZD17aXNTdWJtaXR0aW5nfVxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTUgcHktMiB0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXdoaXRlIGJnLXRlYWwtNjAwIGhvdmVyOmJnLXRlYWwtNzAwIHJvdW5kZWQtbGcgc2hhZG93LXhzIHRyYW5zaXRpb24tY29sb3JzIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yIGRpc2FibGVkOm9wYWNpdHktNjBcIlxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgPEZpbGVDaGVjazIgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+XHJcbiAgICAgICAgICAgICAgPHNwYW4+e2lzU3VibWl0dGluZyA/IFwiRW1pdGluZG8uLi5cIiA6IFwiQ29uZmlybWFyIGUgRW1pdGlyIEFsdmFyw6FcIn08L3NwYW4+XHJcbiAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9mb3JtPlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBNb2RhbEVtaXRpckFsdmFyYTtcclxuIl19