import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/contexts/AuthContext.tsx");const React = __vite__cjsImport0_react; const createContext = __vite__cjsImport0_react["createContext"]; const useCallback = __vite__cjsImport0_react["useCallback"]; const useContext = __vite__cjsImport0_react["useContext"]; const useEffect = __vite__cjsImport0_react["useEffect"]; const useMemo = __vite__cjsImport0_react["useMemo"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];/**
* Contexto de Autenticação e Sessão (AuthContext)
* Gerencia o ciclo de vida da sessão JWT do servidor municipal,
* verificação de perfis RBAC e persistência segura no cliente.
*/
import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=0fd2848a";
import { APP_CONFIG } from "/src/config/app.config.ts";
import authService from "/src/services/authService.ts";
var _jsxFileName = "E:/Projetos VSCODE/visa_braunas/src/contexts/AuthContext.tsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=0fd2848a";
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
const AuthContext = createContext(undefined);
_c = AuthContext;
export const AuthProvider = ({ children }) => {
	_s();
	const [token, setToken] = useState(() => {
		try {
			return localStorage.getItem(APP_CONFIG.storageKeys.token);
		} catch {
			return null;
		}
	});
	const [user, setUser] = useState(() => {
		try {
			const cached = localStorage.getItem(APP_CONFIG.storageKeys.user);
			return cached ? JSON.parse(cached) : null;
		} catch {
			return null;
		}
	});
	const [isLoading, setIsLoading] = useState(true);
	const logout = useCallback(() => {
		setToken(null);
		setUser(null);
		authService.logout();
	}, []);
	// Inicialização assíncrona da sessão: validação do token com a API
	useEffect(() => {
		let isMounted = true;
		async function initializeAuth() {
			const storedToken = localStorage.getItem(APP_CONFIG.storageKeys.token);
			if (!storedToken) {
				if (isMounted) {
					setIsLoading(false);
				}
				return;
			}
			try {
				const userData = await authService.getMe();
				if (isMounted) {
					setUser(userData);
					localStorage.setItem(APP_CONFIG.storageKeys.user, JSON.stringify(userData));
				}
			} catch (error) {
				// Se o token for inválido ou estiver expirado, limpa a sessão
				if (isMounted) {
					logout();
				}
			} finally {
				if (isMounted) {
					setIsLoading(false);
				}
			}
		}
		initializeAuth();
		// Ouvinte para expiração automática disparada pelos interceptors HTTP
		const handleUnauthorized = () => {
			logout();
		};
		window.addEventListener("vigiminas:auth:unauthorized", handleUnauthorized);
		return () => {
			isMounted = false;
			window.removeEventListener("vigiminas:auth:unauthorized", handleUnauthorized);
		};
	}, [logout]);
	const login = useCallback(async (credentials) => {
		const tokenData = await authService.login(credentials);
		// Persiste o token
		localStorage.setItem(APP_CONFIG.storageKeys.token, tokenData.access_token);
		setToken(tokenData.access_token);
		// Busca dados cadastrais completos do usuário logado
		try {
			const fullUser = await authService.getMe();
			setUser(fullUser);
			localStorage.setItem(APP_CONFIG.storageKeys.user, JSON.stringify(fullUser));
		} catch {
			// Fallback para metadados vindos no payload do token se /me falhar temporariamente
			const fallbackUser = {
				id: tokenData.usuario_id,
				email: credentials.email,
				perfil: tokenData.perfil,
				nome_completo: tokenData.nome_completo,
				cpf: "",
				cargo: "Servidor Municipal",
				is_active: true
			};
			setUser(fallbackUser);
			localStorage.setItem(APP_CONFIG.storageKeys.user, JSON.stringify(fallbackUser));
		}
		return tokenData;
	}, []);
	/**
	* Validador RBAC:
	* Retorna true se o usuário possuir um dos papéis permitidos.
	* O perfil 'admin_master' possui passe-livre em todas as rotas operacionais.
	*/
	const hasPermission = useCallback((allowedRoles) => {
		if (!allowedRoles || allowedRoles.length === 0) {
			return true;
		}
		if (!user) {
			return false;
		}
		if (user.perfil === "admin_master") {
			return true;
		}
		return allowedRoles.includes(user.perfil);
	}, [user]);
	const value = useMemo(() => ({
		user,
		token,
		isAuthenticated: Boolean(token && user),
		isLoading,
		login,
		logout,
		hasPermission
	}), [
		user,
		token,
		isLoading,
		login,
		logout,
		hasPermission
	]);
	return /* @__PURE__ */ _jsxDEV(AuthContext.Provider, {
		value,
		children
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 188,
		columnNumber: 10
	}, this);
};
_s(AuthProvider, "oSTBPTgc3apGU4b94Z6KW9pv9xU=");
_c2 = AuthProvider;
export const useAuth = () => {
	_s2();
	const context = useContext(AuthContext);
	if (!context) {
		throw new Error("useAuth deve ser utilizado dentro de um <AuthProvider />");
	}
	return context;
};
_s2(useAuth, "b9L3QQ+jgeyIrH0NfHrJ8nn7VMU=");
export default AuthContext;
var _c, _c2;
$RefreshReg$(_c, "AuthContext");
$RefreshReg$(_c2, "AuthProvider");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/contexts/AuthContext.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("E:/Projetos VSCODE/visa_braunas/src/contexts/AuthContext.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("E:/Projetos VSCODE/visa_braunas/src/contexts/AuthContext.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "E:/Projetos VSCODE/visa_braunas/src/contexts/AuthContext.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7Ozs7QUFNQSxPQUFPLFNBQ0wsZUFDQSxhQUNBLFlBQ0EsV0FDQSxTQUNBLGdCQUNLO0FBQ1AsU0FBUyxrQkFBa0I7QUFDM0IsT0FBTyxpQkFBaUI7Ozs7QUFrQnhCLE1BQU0sY0FBYyxjQUEyQyxTQUFTOztBQUV4RSxPQUFPLE1BQU0sZ0JBQXlELEVBQ3BFLGVBQ0k7O0NBQ0osTUFBTSxDQUFDLE9BQU8sWUFBWSxlQUE4QjtFQUN0RCxJQUFJO0dBQ0YsT0FBTyxhQUFhLFFBQVEsV0FBVyxZQUFZLEtBQUs7RUFDMUQsUUFBUTtHQUNOLE9BQU87RUFDVDtDQUNGLENBQUM7Q0FFRCxNQUFNLENBQUMsTUFBTSxXQUFXLGVBQXFDO0VBQzNELElBQUk7R0FDRixNQUFNLFNBQVMsYUFBYSxRQUFRLFdBQVcsWUFBWSxJQUFJO0dBQy9ELE9BQU8sU0FBUyxLQUFLLE1BQU0sTUFBTSxJQUFJO0VBQ3ZDLFFBQVE7R0FDTixPQUFPO0VBQ1Q7Q0FDRixDQUFDO0NBRUQsTUFBTSxDQUFDLFdBQVcsZ0JBQWdCLFNBQWtCLElBQUk7Q0FFeEQsTUFBTSxTQUFTLGtCQUFrQjtFQUMvQixTQUFTLElBQUk7RUFDYixRQUFRLElBQUk7RUFDWixZQUFZLE9BQU87Q0FDckIsR0FBRyxDQUFDLENBQUM7O0NBR0wsZ0JBQWdCO0VBQ2QsSUFBSSxZQUFZO0VBRWhCLGVBQWUsaUJBQWlCO0dBQzlCLE1BQU0sY0FBYyxhQUFhLFFBQVEsV0FBVyxZQUFZLEtBQUs7R0FDckUsSUFBSSxDQUFDLGFBQWE7SUFDaEIsSUFBSSxXQUFXO0tBQ2IsYUFBYSxLQUFLO0lBQ3BCO0lBQ0E7R0FDRjtHQUVBLElBQUk7SUFDRixNQUFNLFdBQVcsTUFBTSxZQUFZLE1BQU07SUFDekMsSUFBSSxXQUFXO0tBQ2IsUUFBUSxRQUFRO0tBQ2hCLGFBQWEsUUFDWCxXQUFXLFlBQVksTUFDdkIsS0FBSyxVQUFVLFFBQVEsQ0FDekI7SUFDRjtHQUNGLFNBQVMsT0FBTzs7SUFFZCxJQUFJLFdBQVc7S0FDYixPQUFPO0lBQ1Q7R0FDRixVQUFVO0lBQ1IsSUFBSSxXQUFXO0tBQ2IsYUFBYSxLQUFLO0lBQ3BCO0dBQ0Y7RUFDRjtFQUVBLGVBQWU7O0VBR2YsTUFBTSwyQkFBMkI7R0FDL0IsT0FBTztFQUNUO0VBRUEsT0FBTyxpQkFBaUIsK0JBQStCLGtCQUFrQjtFQUN6RSxhQUFhO0dBQ1gsWUFBWTtHQUNaLE9BQU8sb0JBQ0wsK0JBQ0Esa0JBQ0Y7RUFDRjtDQUNGLEdBQUcsQ0FBQyxNQUFNLENBQUM7Q0FFWCxNQUFNLFFBQVEsWUFDWixPQUFPLGdCQUEwRDtFQUMvRCxNQUFNLFlBQVksTUFBTSxZQUFZLE1BQU0sV0FBVzs7RUFHckQsYUFBYSxRQUFRLFdBQVcsWUFBWSxPQUFPLFVBQVUsWUFBWTtFQUN6RSxTQUFTLFVBQVUsWUFBWTs7RUFHL0IsSUFBSTtHQUNGLE1BQU0sV0FBVyxNQUFNLFlBQVksTUFBTTtHQUN6QyxRQUFRLFFBQVE7R0FDaEIsYUFBYSxRQUNYLFdBQVcsWUFBWSxNQUN2QixLQUFLLFVBQVUsUUFBUSxDQUN6QjtFQUNGLFFBQVE7O0dBRU4sTUFBTSxlQUE4QjtJQUNsQyxJQUFJLFVBQVU7SUFDZCxPQUFPLFlBQVk7SUFDbkIsUUFBUSxVQUFVO0lBQ2xCLGVBQWUsVUFBVTtJQUN6QixLQUFLO0lBQ0wsT0FBTztJQUNQLFdBQVc7R0FDYjtHQUNBLFFBQVEsWUFBWTtHQUNwQixhQUFhLFFBQ1gsV0FBVyxZQUFZLE1BQ3ZCLEtBQUssVUFBVSxZQUFZLENBQzdCO0VBQ0Y7RUFFQSxPQUFPO0NBQ1QsR0FDQSxDQUFDLENBQ0g7Ozs7OztDQU9BLE1BQU0sZ0JBQWdCLGFBQ25CLGlCQUE0QztFQUMzQyxJQUFJLENBQUMsZ0JBQWdCLGFBQWEsV0FBVyxHQUFHO0dBQzlDLE9BQU87RUFDVDtFQUNBLElBQUksQ0FBQyxNQUFNO0dBQ1QsT0FBTztFQUNUO0VBQ0EsSUFBSSxLQUFLLFdBQVcsZ0JBQWdCO0dBQ2xDLE9BQU87RUFDVDtFQUNBLE9BQU8sYUFBYSxTQUFTLEtBQUssTUFBTTtDQUMxQyxHQUNBLENBQUMsSUFBSSxDQUNQO0NBRUEsTUFBTSxRQUFRLGVBQ0w7RUFDTDtFQUNBO0VBQ0EsaUJBQWlCLFFBQVEsU0FBUyxJQUFJO0VBQ3RDO0VBQ0E7RUFDQTtFQUNBO0NBQ0YsSUFDQTtFQUFDO0VBQU07RUFBTztFQUFXO0VBQU87RUFBUTtDQUFhLENBQ3ZEO0NBRUEsT0FBTyx3QkFBQyxZQUFZLFVBQWI7RUFBNkI7RUFBUTtDQUErQjs7Ozs7QUFDN0U7OztBQUVBLE9BQU8sTUFBTSxnQkFBaUM7O0NBQzVDLE1BQU0sVUFBVSxXQUFXLFdBQVc7Q0FDdEMsSUFBSSxDQUFDLFNBQVM7RUFDWixNQUFNLElBQUksTUFBTSwwREFBMEQ7Q0FDNUU7Q0FDQSxPQUFPO0FBQ1Q7O0FBRUEsZUFBZSIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJBdXRoQ29udGV4dC50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiLyoqXHJcbiAqIENvbnRleHRvIGRlIEF1dGVudGljYcOnw6NvIGUgU2Vzc8OjbyAoQXV0aENvbnRleHQpXHJcbiAqIEdlcmVuY2lhIG8gY2ljbG8gZGUgdmlkYSBkYSBzZXNzw6NvIEpXVCBkbyBzZXJ2aWRvciBtdW5pY2lwYWwsXHJcbiAqIHZlcmlmaWNhw6fDo28gZGUgcGVyZmlzIFJCQUMgZSBwZXJzaXN0w6puY2lhIHNlZ3VyYSBubyBjbGllbnRlLlxyXG4gKi9cclxuXHJcbmltcG9ydCBSZWFjdCwge1xyXG4gIGNyZWF0ZUNvbnRleHQsXHJcbiAgdXNlQ2FsbGJhY2ssXHJcbiAgdXNlQ29udGV4dCxcclxuICB1c2VFZmZlY3QsXHJcbiAgdXNlTWVtbyxcclxuICB1c2VTdGF0ZSxcclxufSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHsgQVBQX0NPTkZJRyB9IGZyb20gXCIuLi9jb25maWcvYXBwLmNvbmZpZ1wiO1xyXG5pbXBvcnQgYXV0aFNlcnZpY2UgZnJvbSBcIi4uL3NlcnZpY2VzL2F1dGhTZXJ2aWNlXCI7XHJcbmltcG9ydCB7XHJcbiAgTG9naW5DcmVkZW50aWFscyxcclxuICBQZXJmaWxVc3VhcmlvLFxyXG4gIFRva2VuUmVzcG9uc2UsXHJcbiAgVXN1YXJpb1Nlc3NhbyxcclxufSBmcm9tIFwiLi4vdHlwZXMvYXV0aFwiO1xyXG5cclxuZXhwb3J0IGludGVyZmFjZSBBdXRoQ29udGV4dFR5cGUge1xyXG4gIHVzZXI6IFVzdWFyaW9TZXNzYW8gfCBudWxsO1xyXG4gIHRva2VuOiBzdHJpbmcgfCBudWxsO1xyXG4gIGlzQXV0aGVudGljYXRlZDogYm9vbGVhbjtcclxuICBpc0xvYWRpbmc6IGJvb2xlYW47XHJcbiAgbG9naW46IChjcmVkZW50aWFsczogTG9naW5DcmVkZW50aWFscykgPT4gUHJvbWlzZTxUb2tlblJlc3BvbnNlPjtcclxuICBsb2dvdXQ6ICgpID0+IHZvaWQ7XHJcbiAgaGFzUGVybWlzc2lvbjogKGFsbG93ZWRSb2xlcz86IFBlcmZpbFVzdWFyaW9bXSkgPT4gYm9vbGVhbjtcclxufVxyXG5cclxuY29uc3QgQXV0aENvbnRleHQgPSBjcmVhdGVDb250ZXh0PEF1dGhDb250ZXh0VHlwZSB8IHVuZGVmaW5lZD4odW5kZWZpbmVkKTtcclxuXHJcbmV4cG9ydCBjb25zdCBBdXRoUHJvdmlkZXI6IFJlYWN0LkZDPHsgY2hpbGRyZW46IFJlYWN0LlJlYWN0Tm9kZSB9PiA9ICh7XHJcbiAgY2hpbGRyZW4sXHJcbn0pID0+IHtcclxuICBjb25zdCBbdG9rZW4sIHNldFRva2VuXSA9IHVzZVN0YXRlPHN0cmluZyB8IG51bGw+KCgpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIHJldHVybiBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShBUFBfQ09ORklHLnN0b3JhZ2VLZXlzLnRva2VuKTtcclxuICAgIH0gY2F0Y2gge1xyXG4gICAgICByZXR1cm4gbnVsbDtcclxuICAgIH1cclxuICB9KTtcclxuXHJcbiAgY29uc3QgW3VzZXIsIHNldFVzZXJdID0gdXNlU3RhdGU8VXN1YXJpb1Nlc3NhbyB8IG51bGw+KCgpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IGNhY2hlZCA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKEFQUF9DT05GSUcuc3RvcmFnZUtleXMudXNlcik7XHJcbiAgICAgIHJldHVybiBjYWNoZWQgPyBKU09OLnBhcnNlKGNhY2hlZCkgOiBudWxsO1xyXG4gICAgfSBjYXRjaCB7XHJcbiAgICAgIHJldHVybiBudWxsO1xyXG4gICAgfVxyXG4gIH0pO1xyXG5cclxuICBjb25zdCBbaXNMb2FkaW5nLCBzZXRJc0xvYWRpbmddID0gdXNlU3RhdGU8Ym9vbGVhbj4odHJ1ZSk7XHJcblxyXG4gIGNvbnN0IGxvZ291dCA9IHVzZUNhbGxiYWNrKCgpID0+IHtcclxuICAgIHNldFRva2VuKG51bGwpO1xyXG4gICAgc2V0VXNlcihudWxsKTtcclxuICAgIGF1dGhTZXJ2aWNlLmxvZ291dCgpO1xyXG4gIH0sIFtdKTtcclxuXHJcbiAgLy8gSW5pY2lhbGl6YcOnw6NvIGFzc8OtbmNyb25hIGRhIHNlc3PDo286IHZhbGlkYcOnw6NvIGRvIHRva2VuIGNvbSBhIEFQSVxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBsZXQgaXNNb3VudGVkID0gdHJ1ZTtcclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBpbml0aWFsaXplQXV0aCgpIHtcclxuICAgICAgY29uc3Qgc3RvcmVkVG9rZW4gPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShBUFBfQ09ORklHLnN0b3JhZ2VLZXlzLnRva2VuKTtcclxuICAgICAgaWYgKCFzdG9yZWRUb2tlbikge1xyXG4gICAgICAgIGlmIChpc01vdW50ZWQpIHtcclxuICAgICAgICAgIHNldElzTG9hZGluZyhmYWxzZSk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybjtcclxuICAgICAgfVxyXG5cclxuICAgICAgdHJ5IHtcclxuICAgICAgICBjb25zdCB1c2VyRGF0YSA9IGF3YWl0IGF1dGhTZXJ2aWNlLmdldE1lKCk7XHJcbiAgICAgICAgaWYgKGlzTW91bnRlZCkge1xyXG4gICAgICAgICAgc2V0VXNlcih1c2VyRGF0YSk7XHJcbiAgICAgICAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbShcclxuICAgICAgICAgICAgQVBQX0NPTkZJRy5zdG9yYWdlS2V5cy51c2VyLFxyXG4gICAgICAgICAgICBKU09OLnN0cmluZ2lmeSh1c2VyRGF0YSlcclxuICAgICAgICAgICk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIC8vIFNlIG8gdG9rZW4gZm9yIGludsOhbGlkbyBvdSBlc3RpdmVyIGV4cGlyYWRvLCBsaW1wYSBhIHNlc3PDo29cclxuICAgICAgICBpZiAoaXNNb3VudGVkKSB7XHJcbiAgICAgICAgICBsb2dvdXQoKTtcclxuICAgICAgICB9XHJcbiAgICAgIH0gZmluYWxseSB7XHJcbiAgICAgICAgaWYgKGlzTW91bnRlZCkge1xyXG4gICAgICAgICAgc2V0SXNMb2FkaW5nKGZhbHNlKTtcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBpbml0aWFsaXplQXV0aCgpO1xyXG5cclxuICAgIC8vIE91dmludGUgcGFyYSBleHBpcmHDp8OjbyBhdXRvbcOhdGljYSBkaXNwYXJhZGEgcGVsb3MgaW50ZXJjZXB0b3JzIEhUVFBcclxuICAgIGNvbnN0IGhhbmRsZVVuYXV0aG9yaXplZCA9ICgpID0+IHtcclxuICAgICAgbG9nb3V0KCk7XHJcbiAgICB9O1xyXG5cclxuICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKFwidmlnaW1pbmFzOmF1dGg6dW5hdXRob3JpemVkXCIsIGhhbmRsZVVuYXV0aG9yaXplZCk7XHJcbiAgICByZXR1cm4gKCkgPT4ge1xyXG4gICAgICBpc01vdW50ZWQgPSBmYWxzZTtcclxuICAgICAgd2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoXHJcbiAgICAgICAgXCJ2aWdpbWluYXM6YXV0aDp1bmF1dGhvcml6ZWRcIixcclxuICAgICAgICBoYW5kbGVVbmF1dGhvcml6ZWRcclxuICAgICAgKTtcclxuICAgIH07XHJcbiAgfSwgW2xvZ291dF0pO1xyXG5cclxuICBjb25zdCBsb2dpbiA9IHVzZUNhbGxiYWNrKFxyXG4gICAgYXN5bmMgKGNyZWRlbnRpYWxzOiBMb2dpbkNyZWRlbnRpYWxzKTogUHJvbWlzZTxUb2tlblJlc3BvbnNlPiA9PiB7XHJcbiAgICAgIGNvbnN0IHRva2VuRGF0YSA9IGF3YWl0IGF1dGhTZXJ2aWNlLmxvZ2luKGNyZWRlbnRpYWxzKTtcclxuXHJcbiAgICAgIC8vIFBlcnNpc3RlIG8gdG9rZW5cclxuICAgICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oQVBQX0NPTkZJRy5zdG9yYWdlS2V5cy50b2tlbiwgdG9rZW5EYXRhLmFjY2Vzc190b2tlbik7XHJcbiAgICAgIHNldFRva2VuKHRva2VuRGF0YS5hY2Nlc3NfdG9rZW4pO1xyXG5cclxuICAgICAgLy8gQnVzY2EgZGFkb3MgY2FkYXN0cmFpcyBjb21wbGV0b3MgZG8gdXN1w6FyaW8gbG9nYWRvXHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgY29uc3QgZnVsbFVzZXIgPSBhd2FpdCBhdXRoU2VydmljZS5nZXRNZSgpO1xyXG4gICAgICAgIHNldFVzZXIoZnVsbFVzZXIpO1xyXG4gICAgICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKFxyXG4gICAgICAgICAgQVBQX0NPTkZJRy5zdG9yYWdlS2V5cy51c2VyLFxyXG4gICAgICAgICAgSlNPTi5zdHJpbmdpZnkoZnVsbFVzZXIpXHJcbiAgICAgICAgKTtcclxuICAgICAgfSBjYXRjaCB7XHJcbiAgICAgICAgLy8gRmFsbGJhY2sgcGFyYSBtZXRhZGFkb3MgdmluZG9zIG5vIHBheWxvYWQgZG8gdG9rZW4gc2UgL21lIGZhbGhhciB0ZW1wb3JhcmlhbWVudGVcclxuICAgICAgICBjb25zdCBmYWxsYmFja1VzZXI6IFVzdWFyaW9TZXNzYW8gPSB7XHJcbiAgICAgICAgICBpZDogdG9rZW5EYXRhLnVzdWFyaW9faWQsXHJcbiAgICAgICAgICBlbWFpbDogY3JlZGVudGlhbHMuZW1haWwsXHJcbiAgICAgICAgICBwZXJmaWw6IHRva2VuRGF0YS5wZXJmaWwsXHJcbiAgICAgICAgICBub21lX2NvbXBsZXRvOiB0b2tlbkRhdGEubm9tZV9jb21wbGV0byxcclxuICAgICAgICAgIGNwZjogXCJcIixcclxuICAgICAgICAgIGNhcmdvOiBcIlNlcnZpZG9yIE11bmljaXBhbFwiLFxyXG4gICAgICAgICAgaXNfYWN0aXZlOiB0cnVlLFxyXG4gICAgICAgIH07XHJcbiAgICAgICAgc2V0VXNlcihmYWxsYmFja1VzZXIpO1xyXG4gICAgICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKFxyXG4gICAgICAgICAgQVBQX0NPTkZJRy5zdG9yYWdlS2V5cy51c2VyLFxyXG4gICAgICAgICAgSlNPTi5zdHJpbmdpZnkoZmFsbGJhY2tVc2VyKVxyXG4gICAgICAgICk7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIHJldHVybiB0b2tlbkRhdGE7XHJcbiAgICB9LFxyXG4gICAgW11cclxuICApO1xyXG5cclxuICAvKipcclxuICAgKiBWYWxpZGFkb3IgUkJBQzpcclxuICAgKiBSZXRvcm5hIHRydWUgc2UgbyB1c3XDoXJpbyBwb3NzdWlyIHVtIGRvcyBwYXDDqWlzIHBlcm1pdGlkb3MuXHJcbiAgICogTyBwZXJmaWwgJ2FkbWluX21hc3RlcicgcG9zc3VpIHBhc3NlLWxpdnJlIGVtIHRvZGFzIGFzIHJvdGFzIG9wZXJhY2lvbmFpcy5cclxuICAgKi9cclxuICBjb25zdCBoYXNQZXJtaXNzaW9uID0gdXNlQ2FsbGJhY2soXHJcbiAgICAoYWxsb3dlZFJvbGVzPzogUGVyZmlsVXN1YXJpb1tdKTogYm9vbGVhbiA9PiB7XHJcbiAgICAgIGlmICghYWxsb3dlZFJvbGVzIHx8IGFsbG93ZWRSb2xlcy5sZW5ndGggPT09IDApIHtcclxuICAgICAgICByZXR1cm4gdHJ1ZTtcclxuICAgICAgfVxyXG4gICAgICBpZiAoIXVzZXIpIHtcclxuICAgICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICAgIH1cclxuICAgICAgaWYgKHVzZXIucGVyZmlsID09PSBcImFkbWluX21hc3RlclwiKSB7XHJcbiAgICAgICAgcmV0dXJuIHRydWU7XHJcbiAgICAgIH1cclxuICAgICAgcmV0dXJuIGFsbG93ZWRSb2xlcy5pbmNsdWRlcyh1c2VyLnBlcmZpbCk7XHJcbiAgICB9LFxyXG4gICAgW3VzZXJdXHJcbiAgKTtcclxuXHJcbiAgY29uc3QgdmFsdWUgPSB1c2VNZW1vPEF1dGhDb250ZXh0VHlwZT4oXHJcbiAgICAoKSA9PiAoe1xyXG4gICAgICB1c2VyLFxyXG4gICAgICB0b2tlbixcclxuICAgICAgaXNBdXRoZW50aWNhdGVkOiBCb29sZWFuKHRva2VuICYmIHVzZXIpLFxyXG4gICAgICBpc0xvYWRpbmcsXHJcbiAgICAgIGxvZ2luLFxyXG4gICAgICBsb2dvdXQsXHJcbiAgICAgIGhhc1Blcm1pc3Npb24sXHJcbiAgICB9KSxcclxuICAgIFt1c2VyLCB0b2tlbiwgaXNMb2FkaW5nLCBsb2dpbiwgbG9nb3V0LCBoYXNQZXJtaXNzaW9uXVxyXG4gICk7XHJcblxyXG4gIHJldHVybiA8QXV0aENvbnRleHQuUHJvdmlkZXIgdmFsdWU9e3ZhbHVlfT57Y2hpbGRyZW59PC9BdXRoQ29udGV4dC5Qcm92aWRlcj47XHJcbn07XHJcblxyXG5leHBvcnQgY29uc3QgdXNlQXV0aCA9ICgpOiBBdXRoQ29udGV4dFR5cGUgPT4ge1xyXG4gIGNvbnN0IGNvbnRleHQgPSB1c2VDb250ZXh0KEF1dGhDb250ZXh0KTtcclxuICBpZiAoIWNvbnRleHQpIHtcclxuICAgIHRocm93IG5ldyBFcnJvcihcInVzZUF1dGggZGV2ZSBzZXIgdXRpbGl6YWRvIGRlbnRybyBkZSB1bSA8QXV0aFByb3ZpZGVyIC8+XCIpO1xyXG4gIH1cclxuICByZXR1cm4gY29udGV4dDtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IEF1dGhDb250ZXh0O1xyXG4iXX0=