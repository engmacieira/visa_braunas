import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/estabelecimentos/RiscoBadge.tsx");const React = __vite__cjsImport0_react;const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];/**
* Componente Badge para Nível de Risco Sanitário Preponderante
* Risco III (Alto/Vermelho) > Risco II (Médio/Âmbar) > Risco I (Baixo/Azul) > Dispensado (Verde)
*/
import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=0fd2848a";
import { ShieldAlert } from "/node_modules/.vite/deps/lucide-react.js?v=0fd2848a";
var _jsxFileName = "E:/Projetos VSCODE/visa_braunas/src/components/estabelecimentos/RiscoBadge.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=0fd2848a";
const RISCO_CONFIG = {
	"Risco III": {
		label: "Risco III (Alto)",
		bg: "bg-rose-50 dark:bg-rose-950/40",
		text: "text-rose-700 dark:text-rose-300",
		border: "border-rose-200 dark:border-rose-800"
	},
	"Risco II": {
		label: "Risco II (Médio)",
		bg: "bg-amber-50 dark:bg-amber-950/40",
		text: "text-amber-700 dark:text-amber-300",
		border: "border-amber-200 dark:border-amber-800"
	},
	"Risco I": {
		label: "Risco I (Baixo)",
		bg: "bg-blue-50 dark:bg-blue-950/40",
		text: "text-blue-700 dark:text-blue-300",
		border: "border-blue-200 dark:border-blue-800"
	},
	Dispensado: {
		label: "Dispensado",
		bg: "bg-emerald-50 dark:bg-emerald-950/40",
		text: "text-emerald-700 dark:text-emerald-300",
		border: "border-emerald-200 dark:border-emerald-800"
	}
};
export const RiscoBadge = ({ risco, size = "sm", showIcon = true }) => {
	const config = RISCO_CONFIG[risco] || {
		label: risco,
		bg: "bg-slate-100 dark:bg-slate-800",
		text: "text-slate-700 dark:text-slate-300",
		border: "border-slate-200 dark:border-slate-700"
	};
	const sizeClasses = size === "sm" ? "text-[11px] px-2 py-0.5 gap-1" : "text-xs px-2.5 py-1 gap-1.5 font-semibold";
	return /* @__PURE__ */ _jsxDEV("span", {
		className: `inline-flex items-center rounded-md border font-medium ${config.bg} ${config.text} ${config.border} ${sizeClasses} whitespace-nowrap`,
		children: [showIcon && /* @__PURE__ */ _jsxDEV(ShieldAlert, { className: "w-3 h-3 shrink-0" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 67,
			columnNumber: 20
		}, this), /* @__PURE__ */ _jsxDEV("span", { children: config.label }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 68,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 64,
		columnNumber: 5
	}, this);
};
_c = RiscoBadge;
export default RiscoBadge;
var _c;
$RefreshReg$(_c, "RiscoBadge");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/estabelecimentos/RiscoBadge.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("E:/Projetos VSCODE/visa_braunas/src/components/estabelecimentos/RiscoBadge.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("E:/Projetos VSCODE/visa_braunas/src/components/estabelecimentos/RiscoBadge.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "E:/Projetos VSCODE/visa_braunas/src/components/estabelecimentos/RiscoBadge.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7OztBQUtBLE9BQU8sV0FBVztBQUNsQixTQUFTLG1CQUFtQjs7O0FBUzVCLE1BQU0sZUFHRjtDQUNGLGFBQWE7RUFDWCxPQUFPO0VBQ1AsSUFBSTtFQUNKLE1BQU07RUFDTixRQUFRO0NBQ1Y7Q0FDQSxZQUFZO0VBQ1YsT0FBTztFQUNQLElBQUk7RUFDSixNQUFNO0VBQ04sUUFBUTtDQUNWO0NBQ0EsV0FBVztFQUNULE9BQU87RUFDUCxJQUFJO0VBQ0osTUFBTTtFQUNOLFFBQVE7Q0FDVjtDQUNBLFlBQVk7RUFDVixPQUFPO0VBQ1AsSUFBSTtFQUNKLE1BQU07RUFDTixRQUFRO0NBQ1Y7QUFDRjtBQUVBLE9BQU8sTUFBTSxjQUF5QyxFQUNwRCxPQUNBLE9BQU8sTUFDUCxXQUFXLFdBQ1A7Q0FDSixNQUFNLFNBQVMsYUFBYSxVQUFVO0VBQ3BDLE9BQU87RUFDUCxJQUFJO0VBQ0osTUFBTTtFQUNOLFFBQVE7Q0FDVjtDQUVBLE1BQU0sY0FDSixTQUFTLE9BQ0wsa0NBQ0E7Q0FFTixPQUNFLHdCQUFDLFFBQUQ7RUFDRSxXQUFXLDBEQUEwRCxPQUFPLEdBQUcsR0FBRyxPQUFPLEtBQUssR0FBRyxPQUFPLE9BQU8sR0FBRyxZQUFZO1lBRGhJLENBR0csWUFBWSx3QkFBQyxhQUFELEVBQWEsV0FBVSxtQkFBb0I7Ozs7WUFDeEQsd0JBQUMsUUFBRCxZQUFPLE9BQU8sTUFBWTs7OztVQUN0Qjs7Ozs7O0FBRVY7O0FBRUEsZUFBZSIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJSaXNjb0JhZGdlLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyIvKipcclxuICogQ29tcG9uZW50ZSBCYWRnZSBwYXJhIE7DrXZlbCBkZSBSaXNjbyBTYW5pdMOhcmlvIFByZXBvbmRlcmFudGVcclxuICogUmlzY28gSUlJIChBbHRvL1Zlcm1lbGhvKSA+IFJpc2NvIElJIChNw6lkaW8vw4JtYmFyKSA+IFJpc2NvIEkgKEJhaXhvL0F6dWwpID4gRGlzcGVuc2FkbyAoVmVyZGUpXHJcbiAqL1xyXG5cclxuaW1wb3J0IFJlYWN0IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgeyBTaGllbGRBbGVydCB9IGZyb20gXCJsdWNpZGUtcmVhY3RcIjtcclxuaW1wb3J0IHsgTml2ZWxSaXNjbyB9IGZyb20gXCIuLi8uLi90eXBlcy9lc3RhYmVsZWNpbWVudG9cIjtcclxuXHJcbmludGVyZmFjZSBSaXNjb0JhZGdlUHJvcHMge1xyXG4gIHJpc2NvOiBOaXZlbFJpc2NvIHwgc3RyaW5nO1xyXG4gIHNpemU/OiBcInNtXCIgfCBcIm1kXCI7XHJcbiAgc2hvd0ljb24/OiBib29sZWFuO1xyXG59XHJcblxyXG5jb25zdCBSSVNDT19DT05GSUc6IFJlY29yZDxcclxuICBzdHJpbmcsXHJcbiAgeyBsYWJlbDogc3RyaW5nOyBiZzogc3RyaW5nOyB0ZXh0OiBzdHJpbmc7IGJvcmRlcjogc3RyaW5nIH1cclxuPiA9IHtcclxuICBcIlJpc2NvIElJSVwiOiB7XHJcbiAgICBsYWJlbDogXCJSaXNjbyBJSUkgKEFsdG8pXCIsXHJcbiAgICBiZzogXCJiZy1yb3NlLTUwIGRhcms6Ymctcm9zZS05NTAvNDBcIixcclxuICAgIHRleHQ6IFwidGV4dC1yb3NlLTcwMCBkYXJrOnRleHQtcm9zZS0zMDBcIixcclxuICAgIGJvcmRlcjogXCJib3JkZXItcm9zZS0yMDAgZGFyazpib3JkZXItcm9zZS04MDBcIixcclxuICB9LFxyXG4gIFwiUmlzY28gSUlcIjoge1xyXG4gICAgbGFiZWw6IFwiUmlzY28gSUkgKE3DqWRpbylcIixcclxuICAgIGJnOiBcImJnLWFtYmVyLTUwIGRhcms6YmctYW1iZXItOTUwLzQwXCIsXHJcbiAgICB0ZXh0OiBcInRleHQtYW1iZXItNzAwIGRhcms6dGV4dC1hbWJlci0zMDBcIixcclxuICAgIGJvcmRlcjogXCJib3JkZXItYW1iZXItMjAwIGRhcms6Ym9yZGVyLWFtYmVyLTgwMFwiLFxyXG4gIH0sXHJcbiAgXCJSaXNjbyBJXCI6IHtcclxuICAgIGxhYmVsOiBcIlJpc2NvIEkgKEJhaXhvKVwiLFxyXG4gICAgYmc6IFwiYmctYmx1ZS01MCBkYXJrOmJnLWJsdWUtOTUwLzQwXCIsXHJcbiAgICB0ZXh0OiBcInRleHQtYmx1ZS03MDAgZGFyazp0ZXh0LWJsdWUtMzAwXCIsXHJcbiAgICBib3JkZXI6IFwiYm9yZGVyLWJsdWUtMjAwIGRhcms6Ym9yZGVyLWJsdWUtODAwXCIsXHJcbiAgfSxcclxuICBEaXNwZW5zYWRvOiB7XHJcbiAgICBsYWJlbDogXCJEaXNwZW5zYWRvXCIsXHJcbiAgICBiZzogXCJiZy1lbWVyYWxkLTUwIGRhcms6YmctZW1lcmFsZC05NTAvNDBcIixcclxuICAgIHRleHQ6IFwidGV4dC1lbWVyYWxkLTcwMCBkYXJrOnRleHQtZW1lcmFsZC0zMDBcIixcclxuICAgIGJvcmRlcjogXCJib3JkZXItZW1lcmFsZC0yMDAgZGFyazpib3JkZXItZW1lcmFsZC04MDBcIixcclxuICB9LFxyXG59O1xyXG5cclxuZXhwb3J0IGNvbnN0IFJpc2NvQmFkZ2U6IFJlYWN0LkZDPFJpc2NvQmFkZ2VQcm9wcz4gPSAoe1xyXG4gIHJpc2NvLFxyXG4gIHNpemUgPSBcInNtXCIsXHJcbiAgc2hvd0ljb24gPSB0cnVlLFxyXG59KSA9PiB7XHJcbiAgY29uc3QgY29uZmlnID0gUklTQ09fQ09ORklHW3Jpc2NvXSB8fCB7XHJcbiAgICBsYWJlbDogcmlzY28sXHJcbiAgICBiZzogXCJiZy1zbGF0ZS0xMDAgZGFyazpiZy1zbGF0ZS04MDBcIixcclxuICAgIHRleHQ6IFwidGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTMwMFwiLFxyXG4gICAgYm9yZGVyOiBcImJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtNzAwXCIsXHJcbiAgfTtcclxuXHJcbiAgY29uc3Qgc2l6ZUNsYXNzZXMgPVxyXG4gICAgc2l6ZSA9PT0gXCJzbVwiXHJcbiAgICAgID8gXCJ0ZXh0LVsxMXB4XSBweC0yIHB5LTAuNSBnYXAtMVwiXHJcbiAgICAgIDogXCJ0ZXh0LXhzIHB4LTIuNSBweS0xIGdhcC0xLjUgZm9udC1zZW1pYm9sZFwiO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPHNwYW5cclxuICAgICAgY2xhc3NOYW1lPXtgaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIHJvdW5kZWQtbWQgYm9yZGVyIGZvbnQtbWVkaXVtICR7Y29uZmlnLmJnfSAke2NvbmZpZy50ZXh0fSAke2NvbmZpZy5ib3JkZXJ9ICR7c2l6ZUNsYXNzZXN9IHdoaXRlc3BhY2Utbm93cmFwYH1cclxuICAgID5cclxuICAgICAge3Nob3dJY29uICYmIDxTaGllbGRBbGVydCBjbGFzc05hbWU9XCJ3LTMgaC0zIHNocmluay0wXCIgLz59XHJcbiAgICAgIDxzcGFuPntjb25maWcubGFiZWx9PC9zcGFuPlxyXG4gICAgPC9zcGFuPlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBSaXNjb0JhZGdlO1xyXG4iXX0=