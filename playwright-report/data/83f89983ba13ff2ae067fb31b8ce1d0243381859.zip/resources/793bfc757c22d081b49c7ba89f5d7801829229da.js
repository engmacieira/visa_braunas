import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/estabelecimentos/EstabelecimentoFormPage.tsx");const React = __vite__cjsImport0_react; const useEffect = __vite__cjsImport0_react["useEffect"]; const useMemo = __vite__cjsImport0_react["useMemo"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport12_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport12_react_jsxDevRuntime["Fragment"];/**
* Formulário Multi-Seção de Cadastro e Edição de Estabelecimentos (EstabelecimentoFormPage)
* Integração com React Hook Form + Zod, cálculo dinâmico de risco sanitário preponderante,
* validações em tempo real e injeção do componente de busca assíncrona de CNAEs.
*/
import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=0fd2848a";
import { Controller, useForm } from "/node_modules/.vite/deps/react-hook-form.js?v=0fd2848a";
import { Link, useNavigate, useParams } from "/node_modules/.vite/deps/react-router-dom.js?v=0fd2848a";
import { zodResolver } from "/node_modules/.vite/deps/@hookform_resolvers_zod.js?v=0fd2848a";
import { AlertCircle, ArrowLeft, Building2, Droplets, MapPin, Save, User } from "/node_modules/.vite/deps/lucide-react.js?v=0fd2848a";
import { z } from "/node_modules/.vite/deps/zod.js?v=0fd2848a";
import CnaeSelectAsync from "/src/components/estabelecimentos/CnaeSelectAsync.tsx";
import RiscoBadge from "/src/components/estabelecimentos/RiscoBadge.tsx";
import { useEstabelecimentoDetalhe, useSalvarEstabelecimentoMutation } from "/src/hooks/useEstabelecimentos.ts";
import { APP_CONFIG } from "/src/config/app.config.ts";
import { ROUTES } from "/src/config/routes.config.ts";
import { parseApiError } from "/src/utils/apiErrorHandler.ts";
var _jsxFileName = "E:/Projetos VSCODE/visa_braunas/src/pages/estabelecimentos/EstabelecimentoFormPage.tsx";
import __vite__cjsImport12_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=0fd2848a";
var _s = $RefreshSig$();
// Esquema Zod espelhando estritamente as regras de negócio do Backend
const estabelecimentoSchema = z.object({
	tipo_cadastro: z.enum(["PF", "PJ"]),
	cnpj_cpf: z.string().min(11, "O documento deve ter no mínimo 11 dígitos").max(18, "O documento deve ter no máximo 18 caracteres"),
	razao_social: z.string().min(2, "A Razão Social deve conter pelo menos 2 caracteres").max(200, "Máximo de 200 caracteres"),
	nome_fantasia: z.string().max(200).optional(),
	inscricao_municipal: z.string().max(50).optional(),
	natureza_juridica: z.string().max(100).optional(),
	// Localização
	cep: z.string().min(8, "CEP deve conter 8 dígitos").max(10, "CEP inválido"),
	logradouro: z.string().min(2, "Logradouro é obrigatório"),
	numero: z.string().min(1, "Número é obrigatório"),
	complemento: z.string().max(100).optional(),
	bairro: z.string().min(2, "Bairro é obrigatório"),
	municipio: z.string().min(1, "Município é obrigatório"),
	uf: z.string().min(2, "UF é obrigatória"),
	ponto_referencia: z.string().optional(),
	acesso_compartilhado_residencia: z.boolean(),
	// Contatos
	telefone_fixo: z.string().max(20).optional(),
	telefone_celular: z.string().min(8, "Telefone celular é obrigatório"),
	email: z.string().email("E-mail com formato inválido"),
	// Parâmetros Sanitários
	competencia_fiscalizacao: z.enum([
		"Municipal",
		"Estadual",
		"Pactuado"
	]),
	horario_funcionamento: z.string().optional(),
	fonte_abastecimento_agua: z.string().optional(),
	possui_reservatorio_proprio: z.boolean(),
	capacidade_reservatorio_litros: z.number().min(0),
	// Representante Legal
	representante_legal: z.object({
		nome_completo: z.string().min(3, "Nome do representante deve conter pelo menos 3 caracteres"),
		cpf: z.string().min(11, "CPF deve conter pelo menos 11 dígitos"),
		rg_numero: z.string().optional(),
		rg_orgao_emissor: z.string().optional(),
		telefone: z.string().min(8, "Telefone do representante é obrigatório"),
		email: z.string().email("E-mail do representante inválido"),
		endereco_residencial: z.string().min(5, "Endereço residencial do representante é obrigatório")
	}),
	// CNAEs (Pelo menos um CNAE obrigatório com exatamente 1 principal)
	cnaes: z.array(z.object({
		cnae_codigo: z.string().min(1, "Código do CNAE é obrigatório"),
		descricao: z.string().optional(),
		grau_risco_padrao: z.enum([
			"Risco I",
			"Risco II",
			"Risco III",
			"Dispensado"
		]).optional(),
		exige_rt: z.boolean().optional(),
		eh_principal: z.boolean(),
		data_inicio_atividade: z.string().optional()
	})).min(1, "É obrigatório vincular pelo menos 1 atividade CNAE").refine((cnaes) => cnaes.filter((c) => c.eh_principal).length === 1, "Exatamente uma atividade CNAE deve ser marcada como principal")
});
export const EstabelecimentoFormPage = () => {
	_s();
	const { id } = useParams();
	const isEditing = Boolean(id);
	const navigate = useNavigate();
	const [formError, setFormError] = useState(null);
	const { data: estabExistente, isLoading: carregandoDados } = useEstabelecimentoDetalhe(id);
	const salvarMutation = useSalvarEstabelecimentoMutation(id);
	const { register, handleSubmit, control, watch, reset, formState: { errors, isSubmitting } } = useForm({
		resolver: zodResolver(estabelecimentoSchema),
		defaultValues: {
			tipo_cadastro: "PJ",
			cnpj_cpf: "",
			razao_social: "",
			nome_fantasia: "",
			inscricao_municipal: "",
			natureza_juridica: "",
			cep: "35189000",
			logradouro: "",
			numero: "",
			complemento: "",
			bairro: "Centro",
			municipio: APP_CONFIG.municipio,
			uf: APP_CONFIG.uf,
			ponto_referencia: "",
			acesso_compartilhado_residencia: false,
			telefone_fixo: "",
			telefone_celular: "",
			email: "",
			competencia_fiscalizacao: "Municipal",
			horario_funcionamento: "Segunda a Sexta, 08:00 às 18:00",
			fonte_abastecimento_agua: "Rede Pública (COPASA)",
			possui_reservatorio_proprio: false,
			capacidade_reservatorio_litros: 0,
			representante_legal: {
				nome_completo: "",
				cpf: "",
				rg_numero: "",
				rg_orgao_emissor: "SSP/MG",
				telefone: "",
				email: "",
				endereco_residencial: ""
			},
			cnaes: []
		}
	});
	// Preenche dados para edição
	useEffect(() => {
		if (estabExistente) {
			reset({
				tipo_cadastro: estabExistente.tipo_cadastro,
				cnpj_cpf: estabExistente.cnpj_cpf,
				razao_social: estabExistente.razao_social,
				nome_fantasia: estabExistente.nome_fantasia || "",
				inscricao_municipal: estabExistente.inscricao_municipal || "",
				natureza_juridica: estabExistente.natureza_juridica || "",
				cep: estabExistente.cep,
				logradouro: estabExistente.logradouro,
				numero: estabExistente.numero,
				complemento: estabExistente.complemento || "",
				bairro: estabExistente.bairro,
				municipio: estabExistente.municipio,
				uf: estabExistente.uf,
				ponto_referencia: estabExistente.ponto_referencia || "",
				acesso_compartilhado_residencia: estabExistente.acesso_compartilhado_residencia,
				telefone_fixo: estabExistente.telefone_fixo || "",
				telefone_celular: estabExistente.telefone_celular,
				email: estabExistente.email,
				competencia_fiscalizacao: estabExistente.competencia_fiscalizacao,
				horario_funcionamento: estabExistente.horario_funcionamento || "",
				fonte_abastecimento_agua: estabExistente.fonte_abastecimento_agua || "Rede Pública (COPASA)",
				possui_reservatorio_proprio: estabExistente.possui_reservatorio_proprio,
				capacidade_reservatorio_litros: estabExistente.capacidade_reservatorio_litros,
				representante_legal: estabExistente.representante_legal ? {
					nome_completo: estabExistente.representante_legal.nome_completo,
					cpf: estabExistente.representante_legal.cpf,
					rg_numero: estabExistente.representante_legal.rg_numero || "",
					rg_orgao_emissor: estabExistente.representante_legal.rg_orgao_emissor || "SSP/MG",
					telefone: estabExistente.representante_legal.telefone,
					email: estabExistente.representante_legal.email,
					endereco_residencial: estabExistente.representante_legal.endereco_residencial
				} : {
					nome_completo: "",
					cpf: "",
					rg_numero: "",
					rg_orgao_emissor: "SSP/MG",
					telefone: "",
					email: "",
					endereco_residencial: ""
				},
				cnaes: estabExistente.cnaes.map((c) => ({
					cnae_codigo: c.cnae_codigo,
					descricao: c.cnae?.descricao,
					grau_risco_padrao: c.cnae?.grau_risco_padrao,
					exige_rt: c.cnae?.exige_rt,
					eh_principal: c.eh_principal,
					data_inicio_atividade: c.data_inicio_atividade || ""
				}))
			});
		}
	}, [estabExistente, reset]);
	const watchedCnaes = watch("cnaes") || [];
	// Cálculo reativo do risco sanitário preponderante no formulário
	const riscoPreponderante = useMemo(() => {
		if (watchedCnaes.length === 0) return "Dispensado";
		const riscos = watchedCnaes.map((c) => c.grau_risco_padrao);
		if (riscos.includes("Risco III")) return "Risco III";
		if (riscos.includes("Risco II")) return "Risco II";
		if (riscos.includes("Risco I")) return "Risco I";
		return "Dispensado";
	}, [watchedCnaes]);
	const onSubmit = async (values) => {
		setFormError(null);
		try {
			const salvo = await salvarMutation.mutateAsync(values);
			navigate(ROUTES.ESTABELECIMENTOS.DETALHE(salvo.id));
		} catch (err) {
			setFormError(parseApiError(err));
		}
	};
	if (isEditing && carregandoDados) {
		return /* @__PURE__ */ _jsxDEV("div", {
			className: "p-16 text-center text-xs text-slate-400 flex flex-col items-center justify-center",
			children: [/* @__PURE__ */ _jsxDEV("div", { className: "w-6 h-6 border-2 border-teal-500 border-t-transparent rounded-full animate-spin mb-3" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 271,
				columnNumber: 9
			}, this), "Carregando dados do estabelecimento para edição..."]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 270,
			columnNumber: 7
		}, this);
	}
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "space-y-6 max-w-4xl mx-auto",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 shadow-xs",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						onClick: () => navigate(ROUTES.ESTABELECIMENTOS.LIST),
						className: "p-1 text-slate-400 hover:text-slate-600 dark:hover:text-white rounded",
						title: "Voltar",
						children: /* @__PURE__ */ _jsxDEV(ArrowLeft, { className: "w-4 h-4" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 288,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 282,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h1", {
						className: "text-xl font-bold text-slate-900 dark:text-white",
						children: isEditing ? "Editar Estabelecimento" : "Novo Estabelecimento Regulado"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 291,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("p", {
						className: "text-xs text-slate-500 dark:text-slate-400",
						children: [
							"Preencha os dados cadastrais, endereço em ",
							APP_CONFIG.municipio,
							"/",
							APP_CONFIG.uf,
							" e atividades econômicas."
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 294,
						columnNumber: 13
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 290,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 281,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-2 p-2 bg-slate-50 dark:bg-slate-800/80 rounded-lg border border-slate-200 dark:border-slate-700",
					children: [/* @__PURE__ */ _jsxDEV("span", {
						className: "text-[11px] font-medium text-slate-500",
						children: "Risco Estimado:"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 301,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV(RiscoBadge, {
						risco: riscoPreponderante,
						size: "sm"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 304,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 300,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 280,
				columnNumber: 7
			}, this),
			formError && /* @__PURE__ */ _jsxDEV("div", {
				className: "p-4 bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 rounded-xl text-xs text-rose-800 dark:text-rose-200 flex items-start gap-3",
				children: [/* @__PURE__ */ _jsxDEV(AlertCircle, { className: "w-5 h-5 text-rose-600 shrink-0 mt-0.5" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 310,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
					className: "font-semibold block",
					children: "Erro na Validação:"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 312,
					columnNumber: 13
				}, this), /* @__PURE__ */ _jsxDEV("span", { children: formError }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 313,
					columnNumber: 13
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 311,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 309,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV("form", {
				onSubmit: handleSubmit(onSubmit),
				className: "space-y-6",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 shadow-xs space-y-4",
						children: [/* @__PURE__ */ _jsxDEV("h2", {
							className: "text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider flex items-center gap-2 pb-2 border-b border-slate-100 dark:border-slate-800",
							children: [/* @__PURE__ */ _jsxDEV(Building2, { className: "w-4 h-4 text-teal-600" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 322,
								columnNumber: 13
							}, this), "1. Identificação Jurídica"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 321,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs",
							children: [
								/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
									className: "block text-slate-700 dark:text-slate-300 font-medium mb-1",
									children: "Tipo de Cadastro *"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 328,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("select", {
									...register("tipo_cadastro"),
									className: "w-full py-2 px-3 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg",
									children: [/* @__PURE__ */ _jsxDEV("option", {
										value: "PJ",
										children: "Pessoa Jurídica (PJ)"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 335,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("option", {
										value: "PF",
										children: "Pessoa Física (PF)"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 336,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 331,
									columnNumber: 15
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 327,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "sm:col-span-2",
									children: [
										/* @__PURE__ */ _jsxDEV("label", {
											className: "block text-slate-700 dark:text-slate-300 font-medium mb-1",
											children: "CNPJ ou CPF (apenas números ou com máscara) *"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 341,
											columnNumber: 15
										}, this),
										/* @__PURE__ */ _jsxDEV("input", {
											type: "text",
											...register("cnpj_cpf"),
											placeholder: "Ex: 18.303.187/0001-44 ou 111.222.333-44",
											className: "w-full py-2 px-3 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg font-mono"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 344,
											columnNumber: 15
										}, this),
										errors.cnpj_cpf && /* @__PURE__ */ _jsxDEV("span", {
											className: "text-[11px] text-rose-600 mt-1 block",
											children: errors.cnpj_cpf.message
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 351,
											columnNumber: 17
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 340,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "sm:col-span-2",
									children: [
										/* @__PURE__ */ _jsxDEV("label", {
											className: "block text-slate-700 dark:text-slate-300 font-medium mb-1",
											children: "Razão Social / Nome Civil *"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 358,
											columnNumber: 15
										}, this),
										/* @__PURE__ */ _jsxDEV("input", {
											type: "text",
											...register("razao_social"),
											placeholder: "Nome empresarial registrado",
											className: "w-full py-2 px-3 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 361,
											columnNumber: 15
										}, this),
										errors.razao_social && /* @__PURE__ */ _jsxDEV("span", {
											className: "text-[11px] text-rose-600 mt-1 block",
											children: errors.razao_social.message
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 368,
											columnNumber: 17
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 357,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
									className: "block text-slate-700 dark:text-slate-300 font-medium mb-1",
									children: "Nome Fantasia"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 375,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("input", {
									type: "text",
									...register("nome_fantasia"),
									placeholder: "Nome comercial divulgado",
									className: "w-full py-2 px-3 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 378,
									columnNumber: 15
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 374,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
									className: "block text-slate-700 dark:text-slate-300 font-medium mb-1",
									children: "Inscrição Municipal"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 387,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("input", {
									type: "text",
									...register("inscricao_municipal"),
									placeholder: "Ex: 102030",
									className: "w-full py-2 px-3 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg font-mono"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 390,
									columnNumber: 15
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 386,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
									className: "block text-slate-700 dark:text-slate-300 font-medium mb-1",
									children: "Competência de Fiscalização"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 399,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("select", {
									...register("competencia_fiscalizacao"),
									className: "w-full py-2 px-3 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg",
									children: [
										/* @__PURE__ */ _jsxDEV("option", {
											value: "Municipal",
											children: "Municipal"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 406,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("option", {
											value: "Estadual",
											children: "Estadual"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 407,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("option", {
											value: "Pactuado",
											children: "Pactuado"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 408,
											columnNumber: 17
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 402,
									columnNumber: 15
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 398,
									columnNumber: 13
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 326,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 320,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 shadow-xs space-y-4",
						children: [/* @__PURE__ */ _jsxDEV("h2", {
							className: "text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider flex items-center gap-2 pb-2 border-b border-slate-100 dark:border-slate-800",
							children: [
								/* @__PURE__ */ _jsxDEV(MapPin, { className: "w-4 h-4 text-teal-600" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 417,
									columnNumber: 13
								}, this),
								"2. Endereço e Contatos em ",
								APP_CONFIG.municipio,
								"/",
								APP_CONFIG.uf
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 416,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "grid grid-cols-1 sm:grid-cols-4 gap-4 text-xs",
							children: [
								/* @__PURE__ */ _jsxDEV("div", { children: [
									/* @__PURE__ */ _jsxDEV("label", {
										className: "block text-slate-700 dark:text-slate-300 font-medium mb-1",
										children: "CEP *"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 423,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("input", {
										type: "text",
										...register("cep"),
										placeholder: "35189000 ou 35189-000",
										className: "w-full py-2 px-3 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg font-mono"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 426,
										columnNumber: 15
									}, this),
									errors.cep && /* @__PURE__ */ _jsxDEV("span", {
										className: "text-[11px] text-rose-600 mt-1 block",
										children: errors.cep.message
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 433,
										columnNumber: 17
									}, this)
								] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 422,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "sm:col-span-2",
									children: [
										/* @__PURE__ */ _jsxDEV("label", {
											className: "block text-slate-700 dark:text-slate-300 font-medium mb-1",
											children: "Logradouro (Rua, Avenida, Praça) *"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 440,
											columnNumber: 15
										}, this),
										/* @__PURE__ */ _jsxDEV("input", {
											type: "text",
											...register("logradouro"),
											placeholder: "Ex: Avenida Juscelino Kubitschek",
											className: "w-full py-2 px-3 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 443,
											columnNumber: 15
										}, this),
										errors.logradouro && /* @__PURE__ */ _jsxDEV("span", {
											className: "text-[11px] text-rose-600 mt-1 block",
											children: errors.logradouro.message
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 450,
											columnNumber: 17
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 439,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("div", { children: [
									/* @__PURE__ */ _jsxDEV("label", {
										className: "block text-slate-700 dark:text-slate-300 font-medium mb-1",
										children: "Número *"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 457,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("input", {
										type: "text",
										...register("numero"),
										placeholder: "Ex: 100 ou S/N",
										className: "w-full py-2 px-3 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 460,
										columnNumber: 15
									}, this),
									errors.numero && /* @__PURE__ */ _jsxDEV("span", {
										className: "text-[11px] text-rose-600 mt-1 block",
										children: errors.numero.message
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 467,
										columnNumber: 17
									}, this)
								] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 456,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
									className: "block text-slate-700 dark:text-slate-300 font-medium mb-1",
									children: "Complemento"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 474,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("input", {
									type: "text",
									...register("complemento"),
									placeholder: "Ex: Sala 2, Galpão A",
									className: "w-full py-2 px-3 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 477,
									columnNumber: 15
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 473,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("div", { children: [
									/* @__PURE__ */ _jsxDEV("label", {
										className: "block text-slate-700 dark:text-slate-300 font-medium mb-1",
										children: "Bairro *"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 486,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("input", {
										type: "text",
										...register("bairro"),
										placeholder: "Centro, Novo Horizonte, etc.",
										className: "w-full py-2 px-3 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 489,
										columnNumber: 15
									}, this),
									errors.bairro && /* @__PURE__ */ _jsxDEV("span", {
										className: "text-[11px] text-rose-600 mt-1 block",
										children: errors.bairro.message
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 496,
										columnNumber: 17
									}, this)
								] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 485,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
									className: "block text-slate-700 dark:text-slate-300 font-medium mb-1",
									children: "Município"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 503,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("input", {
									type: "text",
									...register("municipio"),
									readOnly: true,
									className: "w-full py-2 px-3 bg-slate-100 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-500 cursor-not-allowed"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 506,
									columnNumber: 15
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 502,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
									className: "block text-slate-700 dark:text-slate-300 font-medium mb-1",
									children: "UF"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 515,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("input", {
									type: "text",
									...register("uf"),
									readOnly: true,
									className: "w-full py-2 px-3 bg-slate-100 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-500 cursor-not-allowed"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 518,
									columnNumber: 15
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 514,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "sm:col-span-2",
									children: [
										/* @__PURE__ */ _jsxDEV("label", {
											className: "block text-slate-700 dark:text-slate-300 font-medium mb-1",
											children: "Telefone Celular / WhatsApp *"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 527,
											columnNumber: 15
										}, this),
										/* @__PURE__ */ _jsxDEV("input", {
											type: "text",
											...register("telefone_celular"),
											placeholder: "(33) 98888-0000",
											className: "w-full py-2 px-3 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg font-mono"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 530,
											columnNumber: 15
										}, this),
										errors.telefone_celular && /* @__PURE__ */ _jsxDEV("span", {
											className: "text-[11px] text-rose-600 mt-1 block",
											children: errors.telefone_celular.message
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 537,
											columnNumber: 17
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 526,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "sm:col-span-2",
									children: [
										/* @__PURE__ */ _jsxDEV("label", {
											className: "block text-slate-700 dark:text-slate-300 font-medium mb-1",
											children: "E-mail Institucional *"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 544,
											columnNumber: 15
										}, this),
										/* @__PURE__ */ _jsxDEV("input", {
											type: "email",
											...register("email"),
											placeholder: "contato@empresa.com.br",
											className: "w-full py-2 px-3 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 547,
											columnNumber: 15
										}, this),
										errors.email && /* @__PURE__ */ _jsxDEV("span", {
											className: "text-[11px] text-rose-600 mt-1 block",
											children: errors.email.message
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 554,
											columnNumber: 17
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 543,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "sm:col-span-4 flex items-center gap-2 pt-2",
									children: [/* @__PURE__ */ _jsxDEV("input", {
										type: "checkbox",
										id: "acesso_compartilhado_check",
										...register("acesso_compartilhado_residencia"),
										className: "rounded text-teal-600 focus:ring-teal-500 h-4 w-4"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 561,
										columnNumber: 15
									}, this), /* @__PURE__ */ _jsxDEV("label", {
										htmlFor: "acesso_compartilhado_check",
										className: "text-xs text-slate-700 dark:text-slate-300 cursor-pointer",
										children: "O estabelecimento possui acesso compartilhado ou funciona em residência"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 567,
										columnNumber: 15
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 560,
									columnNumber: 13
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 421,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 415,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 shadow-xs",
						children: /* @__PURE__ */ _jsxDEV(Controller, {
							control,
							name: "cnaes",
							render: ({ field }) => /* @__PURE__ */ _jsxDEV(CnaeSelectAsync, {
								selectedCnaes: field.value,
								onChange: field.onChange,
								error: errors.cnaes?.message
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 583,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 579,
							columnNumber: 11
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 578,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 shadow-xs space-y-4",
						children: [/* @__PURE__ */ _jsxDEV("h2", {
							className: "text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider flex items-center gap-2 pb-2 border-b border-slate-100 dark:border-slate-800",
							children: [/* @__PURE__ */ _jsxDEV(User, { className: "w-4 h-4 text-teal-600" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 595,
								columnNumber: 13
							}, this), "4. Representante Legal"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 594,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "sm:col-span-2",
									children: [
										/* @__PURE__ */ _jsxDEV("label", {
											className: "block text-slate-700 dark:text-slate-300 font-medium mb-1",
											children: "Nome Completo do Representante *"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 601,
											columnNumber: 15
										}, this),
										/* @__PURE__ */ _jsxDEV("input", {
											type: "text",
											...register("representante_legal.nome_completo"),
											placeholder: "Ex: José Carlos Ferreira",
											className: "w-full py-2 px-3 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 604,
											columnNumber: 15
										}, this),
										errors.representante_legal?.nome_completo && /* @__PURE__ */ _jsxDEV("span", {
											className: "text-[11px] text-rose-600 mt-1 block",
											children: errors.representante_legal.nome_completo.message
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 611,
											columnNumber: 17
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 600,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("div", { children: [
									/* @__PURE__ */ _jsxDEV("label", {
										className: "block text-slate-700 dark:text-slate-300 font-medium mb-1",
										children: "CPF do Representante *"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 618,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("input", {
										type: "text",
										...register("representante_legal.cpf"),
										placeholder: "111.222.333-44",
										className: "w-full py-2 px-3 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg font-mono"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 621,
										columnNumber: 15
									}, this),
									errors.representante_legal?.cpf && /* @__PURE__ */ _jsxDEV("span", {
										className: "text-[11px] text-rose-600 mt-1 block",
										children: errors.representante_legal.cpf.message
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 628,
										columnNumber: 17
									}, this)
								] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 617,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
									className: "block text-slate-700 dark:text-slate-300 font-medium mb-1",
									children: "Telefone do Representante *"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 635,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("input", {
									type: "text",
									...register("representante_legal.telefone"),
									placeholder: "(33) 98801-1122",
									className: "w-full py-2 px-3 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg font-mono"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 638,
									columnNumber: 15
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 634,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "sm:col-span-2",
									children: [/* @__PURE__ */ _jsxDEV("label", {
										className: "block text-slate-700 dark:text-slate-300 font-medium mb-1",
										children: "E-mail do Representante *"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 647,
										columnNumber: 15
									}, this), /* @__PURE__ */ _jsxDEV("input", {
										type: "email",
										...register("representante_legal.email"),
										placeholder: "representante@email.com",
										className: "w-full py-2 px-3 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 650,
										columnNumber: 15
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 646,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "sm:col-span-3",
									children: [/* @__PURE__ */ _jsxDEV("label", {
										className: "block text-slate-700 dark:text-slate-300 font-medium mb-1",
										children: "Endereço Residencial do Representante *"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 659,
										columnNumber: 15
									}, this), /* @__PURE__ */ _jsxDEV("input", {
										type: "text",
										...register("representante_legal.endereco_residencial"),
										placeholder: "Rua, Número, Bairro, Município/UF",
										className: "w-full py-2 px-3 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 662,
										columnNumber: 15
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 658,
									columnNumber: 13
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 599,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 593,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 shadow-xs space-y-4",
						children: [/* @__PURE__ */ _jsxDEV("h2", {
							className: "text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider flex items-center gap-2 pb-2 border-b border-slate-100 dark:border-slate-800",
							children: [/* @__PURE__ */ _jsxDEV(Droplets, { className: "w-4 h-4 text-teal-600" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 675,
								columnNumber: 13
							}, this), "5. Saneamento e Abastecimento de Água"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 674,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs",
							children: [
								/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
									className: "block text-slate-700 dark:text-slate-300 font-medium mb-1",
									children: "Fonte de Abastecimento"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 681,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("input", {
									type: "text",
									...register("fonte_abastecimento_agua"),
									placeholder: "Rede Pública (COPASA)",
									className: "w-full py-2 px-3 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 684,
									columnNumber: 15
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 680,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center gap-2 pt-6",
									children: [/* @__PURE__ */ _jsxDEV("input", {
										type: "checkbox",
										id: "reservatorio_proprio_check",
										...register("possui_reservatorio_proprio"),
										className: "rounded text-teal-600 focus:ring-teal-500 h-4 w-4"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 693,
										columnNumber: 15
									}, this), /* @__PURE__ */ _jsxDEV("label", {
										htmlFor: "reservatorio_proprio_check",
										className: "text-xs text-slate-700 dark:text-slate-300 cursor-pointer",
										children: "Possui reservatório próprio"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 699,
										columnNumber: 15
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 692,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
									className: "block text-slate-700 dark:text-slate-300 font-medium mb-1",
									children: "Capacidade do Reservatório (Litros)"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 708,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("input", {
									type: "number",
									...register("capacidade_reservatorio_litros"),
									placeholder: "Ex: 5000",
									className: "w-full py-2 px-3 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg font-mono"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 711,
									columnNumber: 15
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 707,
									columnNumber: 13
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 679,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 673,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center justify-end gap-3 pt-4 border-t border-slate-200 dark:border-slate-800",
						children: [/* @__PURE__ */ _jsxDEV(Link, {
							to: ROUTES.ESTABELECIMENTOS.LIST,
							className: "px-4 py-2 text-xs font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors",
							children: "Cancelar"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 723,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							type: "submit",
							disabled: isSubmitting || salvarMutation.isPending,
							className: "inline-flex items-center gap-2 px-5 py-2.5 text-xs font-semibold text-white bg-teal-600 hover:bg-teal-500 rounded-lg shadow-xs transition-colors disabled:opacity-50",
							children: isSubmitting || salvarMutation.isPending ? /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("div", { className: "w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 737,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Gravando no Banco..." }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 738,
								columnNumber: 17
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 736,
								columnNumber: 15
							}, this) : /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV(Save, { className: "w-3.5 h-3.5" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 742,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Salvar Estabelecimento" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 743,
								columnNumber: 17
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 741,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 730,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 722,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 318,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 278,
		columnNumber: 5
	}, this);
};
_s(EstabelecimentoFormPage, "vhFJ3F58L2fM8TV3iwRFZJIxtfA=", false, function() {
	return [
		useParams,
		useNavigate,
		useEstabelecimentoDetalhe,
		useSalvarEstabelecimentoMutation,
		useForm
	];
});
_c = EstabelecimentoFormPage;
export default EstabelecimentoFormPage;
var _c;
$RefreshReg$(_c, "EstabelecimentoFormPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/estabelecimentos/EstabelecimentoFormPage.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("E:/Projetos VSCODE/visa_braunas/src/pages/estabelecimentos/EstabelecimentoFormPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("E:/Projetos VSCODE/visa_braunas/src/pages/estabelecimentos/EstabelecimentoFormPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "E:/Projetos VSCODE/visa_braunas/src/pages/estabelecimentos/EstabelecimentoFormPage.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7Ozs7QUFNQSxPQUFPLFNBQVMsV0FBVyxTQUFTLGdCQUFnQjtBQUNwRCxTQUFTLFlBQVksZUFBZTtBQUNwQyxTQUFTLE1BQU0sYUFBYSxpQkFBaUI7QUFDN0MsU0FBUyxtQkFBbUI7QUFDNUIsU0FDRSxhQUVBLFdBQ0EsV0FFQSxVQUNBLFFBRUEsTUFFQSxZQUNLO0FBQ1AsU0FBUyxTQUFTO0FBQ2xCLE9BQU8scUJBRUE7QUFDUCxPQUFPLGdCQUFnQjtBQUN2QixTQUNFLDJCQUNBLHdDQUNLO0FBT1AsU0FBUyxrQkFBa0I7QUFDM0IsU0FBUyxjQUFjO0FBQ3ZCLFNBQVMscUJBQXFCOzs7OztBQUc5QixNQUFNLHdCQUF3QixFQUFFLE9BQU87Q0FDckMsZUFBZSxFQUFFLEtBQUssQ0FBQyxNQUFNLElBQUksQ0FBQztDQUNsQyxVQUFVLEVBQ1AsT0FBTyxDQUFDLENBQ1IsSUFBSSxJQUFJLDJDQUEyQyxDQUFDLENBQ3BELElBQUksSUFBSSw4Q0FBOEM7Q0FDekQsY0FBYyxFQUNYLE9BQU8sQ0FBQyxDQUNSLElBQUksR0FBRyxvREFBb0QsQ0FBQyxDQUM1RCxJQUFJLEtBQUssMEJBQTBCO0NBQ3RDLGVBQWUsRUFBRSxPQUFPLENBQUMsQ0FBQyxJQUFJLEdBQUcsQ0FBQyxDQUFDLFNBQVM7Q0FDNUMscUJBQXFCLEVBQUUsT0FBTyxDQUFDLENBQUMsSUFBSSxFQUFFLENBQUMsQ0FBQyxTQUFTO0NBQ2pELG1CQUFtQixFQUFFLE9BQU8sQ0FBQyxDQUFDLElBQUksR0FBRyxDQUFDLENBQUMsU0FBUzs7Q0FHaEQsS0FBSyxFQUNGLE9BQU8sQ0FBQyxDQUNSLElBQUksR0FBRywyQkFBMkIsQ0FBQyxDQUNuQyxJQUFJLElBQUksY0FBYztDQUN6QixZQUFZLEVBQUUsT0FBTyxDQUFDLENBQUMsSUFBSSxHQUFHLDBCQUEwQjtDQUN4RCxRQUFRLEVBQUUsT0FBTyxDQUFDLENBQUMsSUFBSSxHQUFHLHNCQUFzQjtDQUNoRCxhQUFhLEVBQUUsT0FBTyxDQUFDLENBQUMsSUFBSSxHQUFHLENBQUMsQ0FBQyxTQUFTO0NBQzFDLFFBQVEsRUFBRSxPQUFPLENBQUMsQ0FBQyxJQUFJLEdBQUcsc0JBQXNCO0NBQ2hELFdBQVcsRUFBRSxPQUFPLENBQUMsQ0FBQyxJQUFJLEdBQUcseUJBQXlCO0NBQ3RELElBQUksRUFBRSxPQUFPLENBQUMsQ0FBQyxJQUFJLEdBQUcsa0JBQWtCO0NBQ3hDLGtCQUFrQixFQUFFLE9BQU8sQ0FBQyxDQUFDLFNBQVM7Q0FDdEMsaUNBQWlDLEVBQUUsUUFBUTs7Q0FHM0MsZUFBZSxFQUFFLE9BQU8sQ0FBQyxDQUFDLElBQUksRUFBRSxDQUFDLENBQUMsU0FBUztDQUMzQyxrQkFBa0IsRUFBRSxPQUFPLENBQUMsQ0FBQyxJQUFJLEdBQUcsZ0NBQWdDO0NBQ3BFLE9BQU8sRUFBRSxPQUFPLENBQUMsQ0FBQyxNQUFNLDZCQUE2Qjs7Q0FHckQsMEJBQTBCLEVBQUUsS0FBSztFQUFDO0VBQWE7RUFBWTtDQUFVLENBQUM7Q0FDdEUsdUJBQXVCLEVBQUUsT0FBTyxDQUFDLENBQUMsU0FBUztDQUMzQywwQkFBMEIsRUFBRSxPQUFPLENBQUMsQ0FBQyxTQUFTO0NBQzlDLDZCQUE2QixFQUFFLFFBQVE7Q0FDdkMsZ0NBQWdDLEVBQUUsT0FBTyxDQUFDLENBQUMsSUFBSSxDQUFDOztDQUdoRCxxQkFBcUIsRUFBRSxPQUFPO0VBQzVCLGVBQWUsRUFDWixPQUFPLENBQUMsQ0FDUixJQUFJLEdBQUcsMkRBQTJEO0VBQ3JFLEtBQUssRUFDRixPQUFPLENBQUMsQ0FDUixJQUFJLElBQUksdUNBQXVDO0VBQ2xELFdBQVcsRUFBRSxPQUFPLENBQUMsQ0FBQyxTQUFTO0VBQy9CLGtCQUFrQixFQUFFLE9BQU8sQ0FBQyxDQUFDLFNBQVM7RUFDdEMsVUFBVSxFQUFFLE9BQU8sQ0FBQyxDQUFDLElBQUksR0FBRyx5Q0FBeUM7RUFDckUsT0FBTyxFQUFFLE9BQU8sQ0FBQyxDQUFDLE1BQU0sa0NBQWtDO0VBQzFELHNCQUFzQixFQUNuQixPQUFPLENBQUMsQ0FDUixJQUFJLEdBQUcscURBQXFEO0NBQ2pFLENBQUM7O0NBR0QsT0FBTyxFQUNKLE1BQ0MsRUFBRSxPQUFPO0VBQ1AsYUFBYSxFQUFFLE9BQU8sQ0FBQyxDQUFDLElBQUksR0FBRyw4QkFBOEI7RUFDN0QsV0FBVyxFQUFFLE9BQU8sQ0FBQyxDQUFDLFNBQVM7RUFDL0IsbUJBQW1CLEVBQ2hCLEtBQUs7R0FBQztHQUFXO0dBQVk7R0FBYTtFQUFZLENBQUMsQ0FBQyxDQUN4RCxTQUFTO0VBQ1osVUFBVSxFQUFFLFFBQVEsQ0FBQyxDQUFDLFNBQVM7RUFDL0IsY0FBYyxFQUFFLFFBQVE7RUFDeEIsdUJBQXVCLEVBQUUsT0FBTyxDQUFDLENBQUMsU0FBUztDQUM3QyxDQUFDLENBQ0gsQ0FBQyxDQUNBLElBQUksR0FBRyxvREFBb0QsQ0FBQyxDQUM1RCxRQUNFLFVBQVUsTUFBTSxRQUFRLE1BQU0sRUFBRSxZQUFZLENBQUMsQ0FBQyxXQUFXLEdBQzFELCtEQUNGO0FBQ0osQ0FBQztBQUlELE9BQU8sTUFBTSxnQ0FBMEM7O0NBQ3JELE1BQU0sRUFBRSxPQUFPLFVBQTBCO0NBQ3pDLE1BQU0sWUFBWSxRQUFRLEVBQUU7Q0FDNUIsTUFBTSxXQUFXLFlBQVk7Q0FFN0IsTUFBTSxDQUFDLFdBQVcsZ0JBQWdCLFNBQXdCLElBQUk7Q0FFOUQsTUFBTSxFQUFFLE1BQU0sZ0JBQWdCLFdBQVcsb0JBQ3ZDLDBCQUEwQixFQUFFO0NBRTlCLE1BQU0saUJBQWlCLGlDQUFpQyxFQUFFO0NBRTFELE1BQU0sRUFDSixVQUNBLGNBQ0EsU0FDQSxPQUNBLE9BQ0EsV0FBVyxFQUFFLFFBQVEsbUJBQ25CLFFBQW1DO0VBQ3JDLFVBQVUsWUFBWSxxQkFBcUI7RUFDM0MsZUFBZTtHQUNiLGVBQWU7R0FDZixVQUFVO0dBQ1YsY0FBYztHQUNkLGVBQWU7R0FDZixxQkFBcUI7R0FDckIsbUJBQW1CO0dBQ25CLEtBQUs7R0FDTCxZQUFZO0dBQ1osUUFBUTtHQUNSLGFBQWE7R0FDYixRQUFRO0dBQ1IsV0FBVyxXQUFXO0dBQ3RCLElBQUksV0FBVztHQUNmLGtCQUFrQjtHQUNsQixpQ0FBaUM7R0FDakMsZUFBZTtHQUNmLGtCQUFrQjtHQUNsQixPQUFPO0dBQ1AsMEJBQTBCO0dBQzFCLHVCQUF1QjtHQUN2QiwwQkFBMEI7R0FDMUIsNkJBQTZCO0dBQzdCLGdDQUFnQztHQUNoQyxxQkFBcUI7SUFDbkIsZUFBZTtJQUNmLEtBQUs7SUFDTCxXQUFXO0lBQ1gsa0JBQWtCO0lBQ2xCLFVBQVU7SUFDVixPQUFPO0lBQ1Asc0JBQXNCO0dBQ3hCO0dBQ0EsT0FBTyxDQUFDO0VBQ1Y7Q0FDRixDQUFDOztDQUdELGdCQUFnQjtFQUNkLElBQUksZ0JBQWdCO0dBQ2xCLE1BQU07SUFDSixlQUFlLGVBQWU7SUFDOUIsVUFBVSxlQUFlO0lBQ3pCLGNBQWMsZUFBZTtJQUM3QixlQUFlLGVBQWUsaUJBQWlCO0lBQy9DLHFCQUFxQixlQUFlLHVCQUF1QjtJQUMzRCxtQkFBbUIsZUFBZSxxQkFBcUI7SUFDdkQsS0FBSyxlQUFlO0lBQ3BCLFlBQVksZUFBZTtJQUMzQixRQUFRLGVBQWU7SUFDdkIsYUFBYSxlQUFlLGVBQWU7SUFDM0MsUUFBUSxlQUFlO0lBQ3ZCLFdBQVcsZUFBZTtJQUMxQixJQUFJLGVBQWU7SUFDbkIsa0JBQWtCLGVBQWUsb0JBQW9CO0lBQ3JELGlDQUNFLGVBQWU7SUFDakIsZUFBZSxlQUFlLGlCQUFpQjtJQUMvQyxrQkFBa0IsZUFBZTtJQUNqQyxPQUFPLGVBQWU7SUFDdEIsMEJBQTBCLGVBQWU7SUFDekMsdUJBQXVCLGVBQWUseUJBQXlCO0lBQy9ELDBCQUNFLGVBQWUsNEJBQTRCO0lBQzdDLDZCQUNFLGVBQWU7SUFDakIsZ0NBQ0UsZUFBZTtJQUNqQixxQkFBcUIsZUFBZSxzQkFDaEM7S0FDRSxlQUFlLGVBQWUsb0JBQW9CO0tBQ2xELEtBQUssZUFBZSxvQkFBb0I7S0FDeEMsV0FBVyxlQUFlLG9CQUFvQixhQUFhO0tBQzNELGtCQUNFLGVBQWUsb0JBQW9CLG9CQUFvQjtLQUN6RCxVQUFVLGVBQWUsb0JBQW9CO0tBQzdDLE9BQU8sZUFBZSxvQkFBb0I7S0FDMUMsc0JBQ0UsZUFBZSxvQkFBb0I7SUFDdkMsSUFDQTtLQUNFLGVBQWU7S0FDZixLQUFLO0tBQ0wsV0FBVztLQUNYLGtCQUFrQjtLQUNsQixVQUFVO0tBQ1YsT0FBTztLQUNQLHNCQUFzQjtJQUN4QjtJQUNKLE9BQU8sZUFBZSxNQUFNLEtBQUssT0FBTztLQUN0QyxhQUFhLEVBQUU7S0FDZixXQUFXLEVBQUUsTUFBTTtLQUNuQixtQkFBbUIsRUFBRSxNQUFNO0tBQzNCLFVBQVUsRUFBRSxNQUFNO0tBQ2xCLGNBQWMsRUFBRTtLQUNoQix1QkFBdUIsRUFBRSx5QkFBeUI7SUFDcEQsRUFBRTtHQUNKLENBQUM7RUFDSDtDQUNGLEdBQUcsQ0FBQyxnQkFBZ0IsS0FBSyxDQUFDO0NBRTFCLE1BQU0sZUFBZSxNQUFNLE9BQU8sS0FBSyxDQUFDOztDQUd4QyxNQUFNLHFCQUFxQixjQUEwQjtFQUNuRCxJQUFJLGFBQWEsV0FBVyxHQUFHLE9BQU87RUFDdEMsTUFBTSxTQUFTLGFBQWEsS0FBSyxNQUFNLEVBQUUsaUJBQWlCO0VBQzFELElBQUksT0FBTyxTQUFTLFdBQVcsR0FBRyxPQUFPO0VBQ3pDLElBQUksT0FBTyxTQUFTLFVBQVUsR0FBRyxPQUFPO0VBQ3hDLElBQUksT0FBTyxTQUFTLFNBQVMsR0FBRyxPQUFPO0VBQ3ZDLE9BQU87Q0FDVCxHQUFHLENBQUMsWUFBWSxDQUFDO0NBRWpCLE1BQU0sV0FBVyxPQUFPLFdBQXNDO0VBQzVELGFBQWEsSUFBSTtFQUNqQixJQUFJO0dBQ0YsTUFBTSxRQUFRLE1BQU0sZUFBZSxZQUFZLE1BQW1DO0dBQ2xGLFNBQVMsT0FBTyxpQkFBaUIsUUFBUSxNQUFNLEVBQUUsQ0FBQztFQUNwRCxTQUFTLEtBQWM7R0FDckIsYUFBYSxjQUFjLEdBQUcsQ0FBQztFQUNqQztDQUNGO0NBRUEsSUFBSSxhQUFhLGlCQUFpQjtFQUNoQyxPQUNFLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWYsQ0FDRSx3QkFBQyxPQUFELEVBQUssV0FBVSx1RkFBd0Y7Ozs7YUFBQyxvREFFckc7Ozs7OztDQUVUO0NBRUEsT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUFmO0dBRUUsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxVQUFEO01BQ0UsTUFBSztNQUNMLGVBQWUsU0FBUyxPQUFPLGlCQUFpQixJQUFJO01BQ3BELFdBQVU7TUFDVixPQUFNO2dCQUVOLHdCQUFDLFdBQUQsRUFBVyxXQUFVLFVBQVc7Ozs7O0tBQzFCOzs7O2VBQ1Isd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE1BQUQ7TUFBSSxXQUFVO2dCQUNYLFlBQVksMkJBQTJCO0tBQ3RDOzs7O2VBQ0osd0JBQUMsS0FBRDtNQUFHLFdBQVU7Z0JBQWI7T0FBMEQ7T0FDYixXQUFXO09BQVU7T0FBRSxXQUFXO09BQUc7TUFDL0U7Ozs7O2FBQ0E7Ozs7YUFDRjs7Ozs7Y0FFTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsUUFBRDtNQUFNLFdBQVU7Z0JBQXlDO0tBRW5EOzs7O2VBQ04sd0JBQUMsWUFBRDtNQUFZLE9BQU87TUFBb0IsTUFBSztLQUFNOzs7O2FBQy9DOzs7OztZQUNGOzs7Ozs7R0FFSixhQUNDLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxhQUFELEVBQWEsV0FBVSx3Q0FBeUM7Ozs7Y0FDaEUsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFFBQUQ7S0FBTSxXQUFVO2VBQXNCO0lBQXdCOzs7O2NBQzlELHdCQUFDLFFBQUQsWUFBTyxVQUFnQjs7OztZQUNwQjs7OztZQUNGOzs7Ozs7R0FHUCx3QkFBQyxRQUFEO0lBQU0sVUFBVSxhQUFhLFFBQVE7SUFBRyxXQUFVO2NBQWxEO0tBRUUsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxNQUFEO09BQUksV0FBVTtpQkFBZCxDQUNFLHdCQUFDLFdBQUQsRUFBVyxXQUFVLHdCQUF5Qjs7OztpQkFBQywyQkFFN0M7Ozs7O2dCQUVKLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmO1FBQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7U0FBTyxXQUFVO21CQUE0RDtRQUV0RTs7OztrQkFDUCx3QkFBQyxVQUFEO1NBQ0UsR0FBSSxTQUFTLGVBQWU7U0FDNUIsV0FBVTttQkFGWixDQUlFLHdCQUFDLFVBQUQ7VUFBUSxPQUFNO29CQUFLO1NBQTRCOzs7O21CQUMvQyx3QkFBQyxVQUFEO1VBQVEsT0FBTTtvQkFBSztTQUEwQjs7OztpQkFDdkM7Ozs7O2dCQUNMOzs7OztRQUVMLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmO1VBQ0Usd0JBQUMsU0FBRDtXQUFPLFdBQVU7cUJBQTREO1VBRXRFOzs7OztVQUNQLHdCQUFDLFNBQUQ7V0FDRSxNQUFLO1dBQ0wsR0FBSSxTQUFTLFVBQVU7V0FDdkIsYUFBWTtXQUNaLFdBQVU7VUFDWDs7Ozs7VUFDQSxPQUFPLFlBQ04sd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQ2IsT0FBTyxTQUFTO1VBQ2I7Ozs7O1NBRUw7Ozs7OztRQUVMLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmO1VBQ0Usd0JBQUMsU0FBRDtXQUFPLFdBQVU7cUJBQTREO1VBRXRFOzs7OztVQUNQLHdCQUFDLFNBQUQ7V0FDRSxNQUFLO1dBQ0wsR0FBSSxTQUFTLGNBQWM7V0FDM0IsYUFBWTtXQUNaLFdBQVU7VUFDWDs7Ozs7VUFDQSxPQUFPLGdCQUNOLHdCQUFDLFFBQUQ7V0FBTSxXQUFVO3FCQUNiLE9BQU8sYUFBYTtVQUNqQjs7Ozs7U0FFTDs7Ozs7O1FBRUwsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7U0FBTyxXQUFVO21CQUE0RDtRQUV0RTs7OztrQkFDUCx3QkFBQyxTQUFEO1NBQ0UsTUFBSztTQUNMLEdBQUksU0FBUyxlQUFlO1NBQzVCLGFBQVk7U0FDWixXQUFVO1FBQ1g7Ozs7Z0JBQ0U7Ozs7O1FBRUwsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7U0FBTyxXQUFVO21CQUE0RDtRQUV0RTs7OztrQkFDUCx3QkFBQyxTQUFEO1NBQ0UsTUFBSztTQUNMLEdBQUksU0FBUyxxQkFBcUI7U0FDbEMsYUFBWTtTQUNaLFdBQVU7UUFDWDs7OztnQkFDRTs7Ozs7UUFFTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtTQUFPLFdBQVU7bUJBQTREO1FBRXRFOzs7O2tCQUNQLHdCQUFDLFVBQUQ7U0FDRSxHQUFJLFNBQVMsMEJBQTBCO1NBQ3ZDLFdBQVU7bUJBRlo7VUFJRSx3QkFBQyxVQUFEO1dBQVEsT0FBTTtxQkFBWTtVQUFpQjs7Ozs7VUFDM0Msd0JBQUMsVUFBRDtXQUFRLE9BQU07cUJBQVc7VUFBZ0I7Ozs7O1VBQ3pDLHdCQUFDLFVBQUQ7V0FBUSxPQUFNO3FCQUFXO1VBQWdCOzs7OztTQUNuQzs7Ozs7Z0JBQ0w7Ozs7O09BQ0Y7Ozs7O2NBQ0Y7Ozs7OztLQUdMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQWQ7UUFDRSx3QkFBQyxRQUFELEVBQVEsV0FBVSx3QkFBeUI7Ozs7O1FBQUM7UUFDakIsV0FBVztRQUFVO1FBQUUsV0FBVztPQUMzRDs7Ozs7Z0JBRUosd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWY7UUFDRSx3QkFBQyxPQUFEO1NBQ0Usd0JBQUMsU0FBRDtVQUFPLFdBQVU7b0JBQTREO1NBRXRFOzs7OztTQUNQLHdCQUFDLFNBQUQ7VUFDRSxNQUFLO1VBQ0wsR0FBSSxTQUFTLEtBQUs7VUFDbEIsYUFBWTtVQUNaLFdBQVU7U0FDWDs7Ozs7U0FDQSxPQUFPLE9BQ04sd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQ2IsT0FBTyxJQUFJO1NBQ1I7Ozs7O1FBRUw7Ozs7O1FBRUwsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWY7VUFDRSx3QkFBQyxTQUFEO1dBQU8sV0FBVTtxQkFBNEQ7VUFFdEU7Ozs7O1VBQ1Asd0JBQUMsU0FBRDtXQUNFLE1BQUs7V0FDTCxHQUFJLFNBQVMsWUFBWTtXQUN6QixhQUFZO1dBQ1osV0FBVTtVQUNYOzs7OztVQUNBLE9BQU8sY0FDTix3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFDYixPQUFPLFdBQVc7VUFDZjs7Ozs7U0FFTDs7Ozs7O1FBRUwsd0JBQUMsT0FBRDtTQUNFLHdCQUFDLFNBQUQ7VUFBTyxXQUFVO29CQUE0RDtTQUV0RTs7Ozs7U0FDUCx3QkFBQyxTQUFEO1VBQ0UsTUFBSztVQUNMLEdBQUksU0FBUyxRQUFRO1VBQ3JCLGFBQVk7VUFDWixXQUFVO1NBQ1g7Ozs7O1NBQ0EsT0FBTyxVQUNOLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUNiLE9BQU8sT0FBTztTQUNYOzs7OztRQUVMOzs7OztRQUVMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO1NBQU8sV0FBVTttQkFBNEQ7UUFFdEU7Ozs7a0JBQ1Asd0JBQUMsU0FBRDtTQUNFLE1BQUs7U0FDTCxHQUFJLFNBQVMsYUFBYTtTQUMxQixhQUFZO1NBQ1osV0FBVTtRQUNYOzs7O2dCQUNFOzs7OztRQUVMLHdCQUFDLE9BQUQ7U0FDRSx3QkFBQyxTQUFEO1VBQU8sV0FBVTtvQkFBNEQ7U0FFdEU7Ozs7O1NBQ1Asd0JBQUMsU0FBRDtVQUNFLE1BQUs7VUFDTCxHQUFJLFNBQVMsUUFBUTtVQUNyQixhQUFZO1VBQ1osV0FBVTtTQUNYOzs7OztTQUNBLE9BQU8sVUFDTix3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFDYixPQUFPLE9BQU87U0FDWDs7Ozs7UUFFTDs7Ozs7UUFFTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtTQUFPLFdBQVU7bUJBQTREO1FBRXRFOzs7O2tCQUNQLHdCQUFDLFNBQUQ7U0FDRSxNQUFLO1NBQ0wsR0FBSSxTQUFTLFdBQVc7U0FDeEI7U0FDQSxXQUFVO1FBQ1g7Ozs7Z0JBQ0U7Ozs7O1FBRUwsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7U0FBTyxXQUFVO21CQUE0RDtRQUV0RTs7OztrQkFDUCx3QkFBQyxTQUFEO1NBQ0UsTUFBSztTQUNMLEdBQUksU0FBUyxJQUFJO1NBQ2pCO1NBQ0EsV0FBVTtRQUNYOzs7O2dCQUNFOzs7OztRQUVMLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmO1VBQ0Usd0JBQUMsU0FBRDtXQUFPLFdBQVU7cUJBQTREO1VBRXRFOzs7OztVQUNQLHdCQUFDLFNBQUQ7V0FDRSxNQUFLO1dBQ0wsR0FBSSxTQUFTLGtCQUFrQjtXQUMvQixhQUFZO1dBQ1osV0FBVTtVQUNYOzs7OztVQUNBLE9BQU8sb0JBQ04sd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQ2IsT0FBTyxpQkFBaUI7VUFDckI7Ozs7O1NBRUw7Ozs7OztRQUVMLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmO1VBQ0Usd0JBQUMsU0FBRDtXQUFPLFdBQVU7cUJBQTREO1VBRXRFOzs7OztVQUNQLHdCQUFDLFNBQUQ7V0FDRSxNQUFLO1dBQ0wsR0FBSSxTQUFTLE9BQU87V0FDcEIsYUFBWTtXQUNaLFdBQVU7VUFDWDs7Ozs7VUFDQSxPQUFPLFNBQ04sd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQ2IsT0FBTyxNQUFNO1VBQ1Y7Ozs7O1NBRUw7Ozs7OztRQUVMLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsU0FBRDtVQUNFLE1BQUs7VUFDTCxJQUFHO1VBQ0gsR0FBSSxTQUFTLGlDQUFpQztVQUM5QyxXQUFVO1NBQ1g7Ozs7bUJBQ0Qsd0JBQUMsU0FBRDtVQUNFLFNBQVE7VUFDUixXQUFVO29CQUNYO1NBRU07Ozs7aUJBQ0o7Ozs7OztPQUNGOzs7OztjQUNGOzs7Ozs7S0FHTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFDYix3QkFBQyxZQUFEO09BQ1c7T0FDVCxNQUFLO09BQ0wsU0FBUyxFQUFFLFlBQ1Qsd0JBQUMsaUJBQUQ7UUFDRSxlQUFlLE1BQU07UUFDckIsVUFBVSxNQUFNO1FBQ2hCLE9BQU8sT0FBTyxPQUFPO09BQ3RCOzs7OztNQUVKOzs7OztLQUNFOzs7OztLQUdMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQWQsQ0FDRSx3QkFBQyxNQUFELEVBQU0sV0FBVSx3QkFBeUI7Ozs7aUJBQUMsd0JBRXhDOzs7OztnQkFFSix3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZjtRQUNFLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmO1VBQ0Usd0JBQUMsU0FBRDtXQUFPLFdBQVU7cUJBQTREO1VBRXRFOzs7OztVQUNQLHdCQUFDLFNBQUQ7V0FDRSxNQUFLO1dBQ0wsR0FBSSxTQUFTLG1DQUFtQztXQUNoRCxhQUFZO1dBQ1osV0FBVTtVQUNYOzs7OztVQUNBLE9BQU8scUJBQXFCLGlCQUMzQix3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFDYixPQUFPLG9CQUFvQixjQUFjO1VBQ3RDOzs7OztTQUVMOzs7Ozs7UUFFTCx3QkFBQyxPQUFEO1NBQ0Usd0JBQUMsU0FBRDtVQUFPLFdBQVU7b0JBQTREO1NBRXRFOzs7OztTQUNQLHdCQUFDLFNBQUQ7VUFDRSxNQUFLO1VBQ0wsR0FBSSxTQUFTLHlCQUF5QjtVQUN0QyxhQUFZO1VBQ1osV0FBVTtTQUNYOzs7OztTQUNBLE9BQU8scUJBQXFCLE9BQzNCLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUNiLE9BQU8sb0JBQW9CLElBQUk7U0FDNUI7Ozs7O1FBRUw7Ozs7O1FBRUwsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7U0FBTyxXQUFVO21CQUE0RDtRQUV0RTs7OztrQkFDUCx3QkFBQyxTQUFEO1NBQ0UsTUFBSztTQUNMLEdBQUksU0FBUyw4QkFBOEI7U0FDM0MsYUFBWTtTQUNaLFdBQVU7UUFDWDs7OztnQkFDRTs7Ozs7UUFFTCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLFNBQUQ7VUFBTyxXQUFVO29CQUE0RDtTQUV0RTs7OzttQkFDUCx3QkFBQyxTQUFEO1VBQ0UsTUFBSztVQUNMLEdBQUksU0FBUywyQkFBMkI7VUFDeEMsYUFBWTtVQUNaLFdBQVU7U0FDWDs7OztpQkFDRTs7Ozs7O1FBRUwsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDRSx3QkFBQyxTQUFEO1VBQU8sV0FBVTtvQkFBNEQ7U0FFdEU7Ozs7bUJBQ1Asd0JBQUMsU0FBRDtVQUNFLE1BQUs7VUFDTCxHQUFJLFNBQVMsMENBQTBDO1VBQ3ZELGFBQVk7VUFDWixXQUFVO1NBQ1g7Ozs7aUJBQ0U7Ozs7OztPQUNGOzs7OztjQUNGOzs7Ozs7S0FHTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLE1BQUQ7T0FBSSxXQUFVO2lCQUFkLENBQ0Usd0JBQUMsVUFBRCxFQUFVLFdBQVUsd0JBQXlCOzs7O2lCQUFDLHVDQUU1Qzs7Ozs7Z0JBRUosd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWY7UUFDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtTQUFPLFdBQVU7bUJBQTREO1FBRXRFOzs7O2tCQUNQLHdCQUFDLFNBQUQ7U0FDRSxNQUFLO1NBQ0wsR0FBSSxTQUFTLDBCQUEwQjtTQUN2QyxhQUFZO1NBQ1osV0FBVTtRQUNYOzs7O2dCQUNFOzs7OztRQUVMLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsU0FBRDtVQUNFLE1BQUs7VUFDTCxJQUFHO1VBQ0gsR0FBSSxTQUFTLDZCQUE2QjtVQUMxQyxXQUFVO1NBQ1g7Ozs7bUJBQ0Qsd0JBQUMsU0FBRDtVQUNFLFNBQVE7VUFDUixXQUFVO29CQUNYO1NBRU07Ozs7aUJBQ0o7Ozs7OztRQUVMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO1NBQU8sV0FBVTttQkFBNEQ7UUFFdEU7Ozs7a0JBQ1Asd0JBQUMsU0FBRDtTQUNFLE1BQUs7U0FDTCxHQUFJLFNBQVMsZ0NBQWdDO1NBQzdDLGFBQVk7U0FDWixXQUFVO1FBQ1g7Ozs7Z0JBQ0U7Ozs7O09BQ0Y7Ozs7O2NBQ0Y7Ozs7OztLQUdMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsTUFBRDtPQUNFLElBQUksT0FBTyxpQkFBaUI7T0FDNUIsV0FBVTtpQkFDWDtNQUVLOzs7O2dCQUVOLHdCQUFDLFVBQUQ7T0FDRSxNQUFLO09BQ0wsVUFBVSxnQkFBZ0IsZUFBZTtPQUN6QyxXQUFVO2lCQUVULGdCQUFnQixlQUFlLFlBQzlCLGdEQUNFLHdCQUFDLE9BQUQsRUFBSyxXQUFVLG1GQUFvRjs7OztpQkFDbkcsd0JBQUMsUUFBRCxZQUFNLHVCQUEwQjs7OztlQUNoQzs7OztrQkFFRixnREFDRSx3QkFBQyxNQUFELEVBQU0sV0FBVSxjQUFlOzs7O2lCQUMvQix3QkFBQyxRQUFELFlBQU0seUJBQTRCOzs7O2VBQ2xDOzs7OztNQUVFOzs7O2NBQ0w7Ozs7OztJQUNEOzs7Ozs7RUFDSDs7Ozs7O0FBRVQ7Ozs7Ozs7Ozs7O0FBRUEsZUFBZSIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJFc3RhYmVsZWNpbWVudG9Gb3JtUGFnZS50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiLyoqXHJcbiAqIEZvcm11bMOhcmlvIE11bHRpLVNlw6fDo28gZGUgQ2FkYXN0cm8gZSBFZGnDp8OjbyBkZSBFc3RhYmVsZWNpbWVudG9zIChFc3RhYmVsZWNpbWVudG9Gb3JtUGFnZSlcclxuICogSW50ZWdyYcOnw6NvIGNvbSBSZWFjdCBIb29rIEZvcm0gKyBab2QsIGPDoWxjdWxvIGRpbsOibWljbyBkZSByaXNjbyBzYW5pdMOhcmlvIHByZXBvbmRlcmFudGUsXHJcbiAqIHZhbGlkYcOnw7VlcyBlbSB0ZW1wbyByZWFsIGUgaW5qZcOnw6NvIGRvIGNvbXBvbmVudGUgZGUgYnVzY2EgYXNzw61uY3JvbmEgZGUgQ05BRXMuXHJcbiAqL1xyXG5cclxuaW1wb3J0IFJlYWN0LCB7IHVzZUVmZmVjdCwgdXNlTWVtbywgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHsgQ29udHJvbGxlciwgdXNlRm9ybSB9IGZyb20gXCJyZWFjdC1ob29rLWZvcm1cIjtcclxuaW1wb3J0IHsgTGluaywgdXNlTmF2aWdhdGUsIHVzZVBhcmFtcyB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCI7XHJcbmltcG9ydCB7IHpvZFJlc29sdmVyIH0gZnJvbSBcIkBob29rZm9ybS9yZXNvbHZlcnMvem9kXCI7XHJcbmltcG9ydCB7XHJcbiAgQWxlcnRDaXJjbGUsXHJcbiAgQWxlcnRUcmlhbmdsZSxcclxuICBBcnJvd0xlZnQsXHJcbiAgQnVpbGRpbmcyLFxyXG4gIENoZWNrQ2lyY2xlMixcclxuICBEcm9wbGV0cyxcclxuICBNYXBQaW4sXHJcbiAgUGhvbmUsXHJcbiAgU2F2ZSxcclxuICBTaGllbGQsXHJcbiAgVXNlcixcclxufSBmcm9tIFwibHVjaWRlLXJlYWN0XCI7XHJcbmltcG9ydCB7IHogfSBmcm9tIFwiem9kXCI7XHJcbmltcG9ydCBDbmFlU2VsZWN0QXN5bmMsIHtcclxuICBTZWxlY3RlZENOQUUsXHJcbn0gZnJvbSBcIi4uLy4uL2NvbXBvbmVudHMvZXN0YWJlbGVjaW1lbnRvcy9DbmFlU2VsZWN0QXN5bmNcIjtcclxuaW1wb3J0IFJpc2NvQmFkZ2UgZnJvbSBcIi4uLy4uL2NvbXBvbmVudHMvZXN0YWJlbGVjaW1lbnRvcy9SaXNjb0JhZGdlXCI7XHJcbmltcG9ydCB7XHJcbiAgdXNlRXN0YWJlbGVjaW1lbnRvRGV0YWxoZSxcclxuICB1c2VTYWx2YXJFc3RhYmVsZWNpbWVudG9NdXRhdGlvbixcclxufSBmcm9tIFwiLi4vLi4vaG9va3MvdXNlRXN0YWJlbGVjaW1lbnRvc1wiO1xyXG5pbXBvcnQge1xyXG4gIENvbXBldGVuY2lhRmlzY2FsaXphY2FvLFxyXG4gIEVzdGFiZWxlY2ltZW50b0Zvcm1WYWx1ZXMsXHJcbiAgTml2ZWxSaXNjbyxcclxuICBUaXBvUGVzc29hLFxyXG59IGZyb20gXCIuLi8uLi90eXBlcy9lc3RhYmVsZWNpbWVudG9cIjtcclxuaW1wb3J0IHsgQVBQX0NPTkZJRyB9IGZyb20gXCIuLi8uLi9jb25maWcvYXBwLmNvbmZpZ1wiO1xyXG5pbXBvcnQgeyBST1VURVMgfSBmcm9tIFwiLi4vLi4vY29uZmlnL3JvdXRlcy5jb25maWdcIjtcclxuaW1wb3J0IHsgcGFyc2VBcGlFcnJvciB9IGZyb20gXCIuLi8uLi91dGlscy9hcGlFcnJvckhhbmRsZXJcIjtcclxuXHJcbi8vIEVzcXVlbWEgWm9kIGVzcGVsaGFuZG8gZXN0cml0YW1lbnRlIGFzIHJlZ3JhcyBkZSBuZWfDs2NpbyBkbyBCYWNrZW5kXHJcbmNvbnN0IGVzdGFiZWxlY2ltZW50b1NjaGVtYSA9IHoub2JqZWN0KHtcclxuICB0aXBvX2NhZGFzdHJvOiB6LmVudW0oW1wiUEZcIiwgXCJQSlwiXSksXHJcbiAgY25wal9jcGY6IHpcclxuICAgIC5zdHJpbmcoKVxyXG4gICAgLm1pbigxMSwgXCJPIGRvY3VtZW50byBkZXZlIHRlciBubyBtw61uaW1vIDExIGTDrWdpdG9zXCIpXHJcbiAgICAubWF4KDE4LCBcIk8gZG9jdW1lbnRvIGRldmUgdGVyIG5vIG3DoXhpbW8gMTggY2FyYWN0ZXJlc1wiKSxcclxuICByYXphb19zb2NpYWw6IHpcclxuICAgIC5zdHJpbmcoKVxyXG4gICAgLm1pbigyLCBcIkEgUmF6w6NvIFNvY2lhbCBkZXZlIGNvbnRlciBwZWxvIG1lbm9zIDIgY2FyYWN0ZXJlc1wiKVxyXG4gICAgLm1heCgyMDAsIFwiTcOheGltbyBkZSAyMDAgY2FyYWN0ZXJlc1wiKSxcclxuICBub21lX2ZhbnRhc2lhOiB6LnN0cmluZygpLm1heCgyMDApLm9wdGlvbmFsKCksXHJcbiAgaW5zY3JpY2FvX211bmljaXBhbDogei5zdHJpbmcoKS5tYXgoNTApLm9wdGlvbmFsKCksXHJcbiAgbmF0dXJlemFfanVyaWRpY2E6IHouc3RyaW5nKCkubWF4KDEwMCkub3B0aW9uYWwoKSxcclxuXHJcbiAgLy8gTG9jYWxpemHDp8Ojb1xyXG4gIGNlcDogelxyXG4gICAgLnN0cmluZygpXHJcbiAgICAubWluKDgsIFwiQ0VQIGRldmUgY29udGVyIDggZMOtZ2l0b3NcIilcclxuICAgIC5tYXgoMTAsIFwiQ0VQIGludsOhbGlkb1wiKSxcclxuICBsb2dyYWRvdXJvOiB6LnN0cmluZygpLm1pbigyLCBcIkxvZ3JhZG91cm8gw6kgb2JyaWdhdMOzcmlvXCIpLFxyXG4gIG51bWVybzogei5zdHJpbmcoKS5taW4oMSwgXCJOw7ptZXJvIMOpIG9icmlnYXTDs3Jpb1wiKSxcclxuICBjb21wbGVtZW50bzogei5zdHJpbmcoKS5tYXgoMTAwKS5vcHRpb25hbCgpLFxyXG4gIGJhaXJybzogei5zdHJpbmcoKS5taW4oMiwgXCJCYWlycm8gw6kgb2JyaWdhdMOzcmlvXCIpLFxyXG4gIG11bmljaXBpbzogei5zdHJpbmcoKS5taW4oMSwgXCJNdW5pY8OtcGlvIMOpIG9icmlnYXTDs3Jpb1wiKSxcclxuICB1Zjogei5zdHJpbmcoKS5taW4oMiwgXCJVRiDDqSBvYnJpZ2F0w7NyaWFcIiksXHJcbiAgcG9udG9fcmVmZXJlbmNpYTogei5zdHJpbmcoKS5vcHRpb25hbCgpLFxyXG4gIGFjZXNzb19jb21wYXJ0aWxoYWRvX3Jlc2lkZW5jaWE6IHouYm9vbGVhbigpLFxyXG5cclxuICAvLyBDb250YXRvc1xyXG4gIHRlbGVmb25lX2ZpeG86IHouc3RyaW5nKCkubWF4KDIwKS5vcHRpb25hbCgpLFxyXG4gIHRlbGVmb25lX2NlbHVsYXI6IHouc3RyaW5nKCkubWluKDgsIFwiVGVsZWZvbmUgY2VsdWxhciDDqSBvYnJpZ2F0w7NyaW9cIiksXHJcbiAgZW1haWw6IHouc3RyaW5nKCkuZW1haWwoXCJFLW1haWwgY29tIGZvcm1hdG8gaW52w6FsaWRvXCIpLFxyXG5cclxuICAvLyBQYXLDom1ldHJvcyBTYW5pdMOhcmlvc1xyXG4gIGNvbXBldGVuY2lhX2Zpc2NhbGl6YWNhbzogei5lbnVtKFtcIk11bmljaXBhbFwiLCBcIkVzdGFkdWFsXCIsIFwiUGFjdHVhZG9cIl0pLFxyXG4gIGhvcmFyaW9fZnVuY2lvbmFtZW50bzogei5zdHJpbmcoKS5vcHRpb25hbCgpLFxyXG4gIGZvbnRlX2FiYXN0ZWNpbWVudG9fYWd1YTogei5zdHJpbmcoKS5vcHRpb25hbCgpLFxyXG4gIHBvc3N1aV9yZXNlcnZhdG9yaW9fcHJvcHJpbzogei5ib29sZWFuKCksXHJcbiAgY2FwYWNpZGFkZV9yZXNlcnZhdG9yaW9fbGl0cm9zOiB6Lm51bWJlcigpLm1pbigwKSxcclxuXHJcbiAgLy8gUmVwcmVzZW50YW50ZSBMZWdhbFxyXG4gIHJlcHJlc2VudGFudGVfbGVnYWw6IHoub2JqZWN0KHtcclxuICAgIG5vbWVfY29tcGxldG86IHpcclxuICAgICAgLnN0cmluZygpXHJcbiAgICAgIC5taW4oMywgXCJOb21lIGRvIHJlcHJlc2VudGFudGUgZGV2ZSBjb250ZXIgcGVsbyBtZW5vcyAzIGNhcmFjdGVyZXNcIiksXHJcbiAgICBjcGY6IHpcclxuICAgICAgLnN0cmluZygpXHJcbiAgICAgIC5taW4oMTEsIFwiQ1BGIGRldmUgY29udGVyIHBlbG8gbWVub3MgMTEgZMOtZ2l0b3NcIiksXHJcbiAgICByZ19udW1lcm86IHouc3RyaW5nKCkub3B0aW9uYWwoKSxcclxuICAgIHJnX29yZ2FvX2VtaXNzb3I6IHouc3RyaW5nKCkub3B0aW9uYWwoKSxcclxuICAgIHRlbGVmb25lOiB6LnN0cmluZygpLm1pbig4LCBcIlRlbGVmb25lIGRvIHJlcHJlc2VudGFudGUgw6kgb2JyaWdhdMOzcmlvXCIpLFxyXG4gICAgZW1haWw6IHouc3RyaW5nKCkuZW1haWwoXCJFLW1haWwgZG8gcmVwcmVzZW50YW50ZSBpbnbDoWxpZG9cIiksXHJcbiAgICBlbmRlcmVjb19yZXNpZGVuY2lhbDogelxyXG4gICAgICAuc3RyaW5nKClcclxuICAgICAgLm1pbig1LCBcIkVuZGVyZcOnbyByZXNpZGVuY2lhbCBkbyByZXByZXNlbnRhbnRlIMOpIG9icmlnYXTDs3Jpb1wiKSxcclxuICB9KSxcclxuXHJcbiAgLy8gQ05BRXMgKFBlbG8gbWVub3MgdW0gQ05BRSBvYnJpZ2F0w7NyaW8gY29tIGV4YXRhbWVudGUgMSBwcmluY2lwYWwpXHJcbiAgY25hZXM6IHpcclxuICAgIC5hcnJheShcclxuICAgICAgei5vYmplY3Qoe1xyXG4gICAgICAgIGNuYWVfY29kaWdvOiB6LnN0cmluZygpLm1pbigxLCBcIkPDs2RpZ28gZG8gQ05BRSDDqSBvYnJpZ2F0w7NyaW9cIiksXHJcbiAgICAgICAgZGVzY3JpY2FvOiB6LnN0cmluZygpLm9wdGlvbmFsKCksXHJcbiAgICAgICAgZ3JhdV9yaXNjb19wYWRyYW86IHpcclxuICAgICAgICAgIC5lbnVtKFtcIlJpc2NvIElcIiwgXCJSaXNjbyBJSVwiLCBcIlJpc2NvIElJSVwiLCBcIkRpc3BlbnNhZG9cIl0pXHJcbiAgICAgICAgICAub3B0aW9uYWwoKSxcclxuICAgICAgICBleGlnZV9ydDogei5ib29sZWFuKCkub3B0aW9uYWwoKSxcclxuICAgICAgICBlaF9wcmluY2lwYWw6IHouYm9vbGVhbigpLFxyXG4gICAgICAgIGRhdGFfaW5pY2lvX2F0aXZpZGFkZTogei5zdHJpbmcoKS5vcHRpb25hbCgpLFxyXG4gICAgICB9KVxyXG4gICAgKVxyXG4gICAgLm1pbigxLCBcIsOJIG9icmlnYXTDs3JpbyB2aW5jdWxhciBwZWxvIG1lbm9zIDEgYXRpdmlkYWRlIENOQUVcIilcclxuICAgIC5yZWZpbmUoXHJcbiAgICAgIChjbmFlcykgPT4gY25hZXMuZmlsdGVyKChjKSA9PiBjLmVoX3ByaW5jaXBhbCkubGVuZ3RoID09PSAxLFxyXG4gICAgICBcIkV4YXRhbWVudGUgdW1hIGF0aXZpZGFkZSBDTkFFIGRldmUgc2VyIG1hcmNhZGEgY29tbyBwcmluY2lwYWxcIlxyXG4gICAgKSxcclxufSk7XHJcblxyXG5leHBvcnQgdHlwZSBFc3RhYmVsZWNpbWVudG9Gb3JtU2NoZW1hID0gei5pbmZlcjx0eXBlb2YgZXN0YWJlbGVjaW1lbnRvU2NoZW1hPjtcclxuXHJcbmV4cG9ydCBjb25zdCBFc3RhYmVsZWNpbWVudG9Gb3JtUGFnZTogUmVhY3QuRkMgPSAoKSA9PiB7XHJcbiAgY29uc3QgeyBpZCB9ID0gdXNlUGFyYW1zPHsgaWQ6IHN0cmluZyB9PigpO1xyXG4gIGNvbnN0IGlzRWRpdGluZyA9IEJvb2xlYW4oaWQpO1xyXG4gIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKTtcclxuXHJcbiAgY29uc3QgW2Zvcm1FcnJvciwgc2V0Rm9ybUVycm9yXSA9IHVzZVN0YXRlPHN0cmluZyB8IG51bGw+KG51bGwpO1xyXG5cclxuICBjb25zdCB7IGRhdGE6IGVzdGFiRXhpc3RlbnRlLCBpc0xvYWRpbmc6IGNhcnJlZ2FuZG9EYWRvcyB9ID1cclxuICAgIHVzZUVzdGFiZWxlY2ltZW50b0RldGFsaGUoaWQpO1xyXG5cclxuICBjb25zdCBzYWx2YXJNdXRhdGlvbiA9IHVzZVNhbHZhckVzdGFiZWxlY2ltZW50b011dGF0aW9uKGlkKTtcclxuXHJcbiAgY29uc3Qge1xyXG4gICAgcmVnaXN0ZXIsXHJcbiAgICBoYW5kbGVTdWJtaXQsXHJcbiAgICBjb250cm9sLFxyXG4gICAgd2F0Y2gsXHJcbiAgICByZXNldCxcclxuICAgIGZvcm1TdGF0ZTogeyBlcnJvcnMsIGlzU3VibWl0dGluZyB9LFxyXG4gIH0gPSB1c2VGb3JtPEVzdGFiZWxlY2ltZW50b0Zvcm1TY2hlbWE+KHtcclxuICAgIHJlc29sdmVyOiB6b2RSZXNvbHZlcihlc3RhYmVsZWNpbWVudG9TY2hlbWEpLFxyXG4gICAgZGVmYXVsdFZhbHVlczoge1xyXG4gICAgICB0aXBvX2NhZGFzdHJvOiBcIlBKXCIsXHJcbiAgICAgIGNucGpfY3BmOiBcIlwiLFxyXG4gICAgICByYXphb19zb2NpYWw6IFwiXCIsXHJcbiAgICAgIG5vbWVfZmFudGFzaWE6IFwiXCIsXHJcbiAgICAgIGluc2NyaWNhb19tdW5pY2lwYWw6IFwiXCIsXHJcbiAgICAgIG5hdHVyZXphX2p1cmlkaWNhOiBcIlwiLFxyXG4gICAgICBjZXA6IFwiMzUxODkwMDBcIixcclxuICAgICAgbG9ncmFkb3VybzogXCJcIixcclxuICAgICAgbnVtZXJvOiBcIlwiLFxyXG4gICAgICBjb21wbGVtZW50bzogXCJcIixcclxuICAgICAgYmFpcnJvOiBcIkNlbnRyb1wiLFxyXG4gICAgICBtdW5pY2lwaW86IEFQUF9DT05GSUcubXVuaWNpcGlvLFxyXG4gICAgICB1ZjogQVBQX0NPTkZJRy51ZixcclxuICAgICAgcG9udG9fcmVmZXJlbmNpYTogXCJcIixcclxuICAgICAgYWNlc3NvX2NvbXBhcnRpbGhhZG9fcmVzaWRlbmNpYTogZmFsc2UsXHJcbiAgICAgIHRlbGVmb25lX2ZpeG86IFwiXCIsXHJcbiAgICAgIHRlbGVmb25lX2NlbHVsYXI6IFwiXCIsXHJcbiAgICAgIGVtYWlsOiBcIlwiLFxyXG4gICAgICBjb21wZXRlbmNpYV9maXNjYWxpemFjYW86IFwiTXVuaWNpcGFsXCIsXHJcbiAgICAgIGhvcmFyaW9fZnVuY2lvbmFtZW50bzogXCJTZWd1bmRhIGEgU2V4dGEsIDA4OjAwIMOgcyAxODowMFwiLFxyXG4gICAgICBmb250ZV9hYmFzdGVjaW1lbnRvX2FndWE6IFwiUmVkZSBQw7pibGljYSAoQ09QQVNBKVwiLFxyXG4gICAgICBwb3NzdWlfcmVzZXJ2YXRvcmlvX3Byb3ByaW86IGZhbHNlLFxyXG4gICAgICBjYXBhY2lkYWRlX3Jlc2VydmF0b3Jpb19saXRyb3M6IDAsXHJcbiAgICAgIHJlcHJlc2VudGFudGVfbGVnYWw6IHtcclxuICAgICAgICBub21lX2NvbXBsZXRvOiBcIlwiLFxyXG4gICAgICAgIGNwZjogXCJcIixcclxuICAgICAgICByZ19udW1lcm86IFwiXCIsXHJcbiAgICAgICAgcmdfb3JnYW9fZW1pc3NvcjogXCJTU1AvTUdcIixcclxuICAgICAgICB0ZWxlZm9uZTogXCJcIixcclxuICAgICAgICBlbWFpbDogXCJcIixcclxuICAgICAgICBlbmRlcmVjb19yZXNpZGVuY2lhbDogXCJcIixcclxuICAgICAgfSxcclxuICAgICAgY25hZXM6IFtdLFxyXG4gICAgfSxcclxuICB9KTtcclxuXHJcbiAgLy8gUHJlZW5jaGUgZGFkb3MgcGFyYSBlZGnDp8Ojb1xyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBpZiAoZXN0YWJFeGlzdGVudGUpIHtcclxuICAgICAgcmVzZXQoe1xyXG4gICAgICAgIHRpcG9fY2FkYXN0cm86IGVzdGFiRXhpc3RlbnRlLnRpcG9fY2FkYXN0cm8sXHJcbiAgICAgICAgY25wal9jcGY6IGVzdGFiRXhpc3RlbnRlLmNucGpfY3BmLFxyXG4gICAgICAgIHJhemFvX3NvY2lhbDogZXN0YWJFeGlzdGVudGUucmF6YW9fc29jaWFsLFxyXG4gICAgICAgIG5vbWVfZmFudGFzaWE6IGVzdGFiRXhpc3RlbnRlLm5vbWVfZmFudGFzaWEgfHwgXCJcIixcclxuICAgICAgICBpbnNjcmljYW9fbXVuaWNpcGFsOiBlc3RhYkV4aXN0ZW50ZS5pbnNjcmljYW9fbXVuaWNpcGFsIHx8IFwiXCIsXHJcbiAgICAgICAgbmF0dXJlemFfanVyaWRpY2E6IGVzdGFiRXhpc3RlbnRlLm5hdHVyZXphX2p1cmlkaWNhIHx8IFwiXCIsXHJcbiAgICAgICAgY2VwOiBlc3RhYkV4aXN0ZW50ZS5jZXAsXHJcbiAgICAgICAgbG9ncmFkb3VybzogZXN0YWJFeGlzdGVudGUubG9ncmFkb3VybyxcclxuICAgICAgICBudW1lcm86IGVzdGFiRXhpc3RlbnRlLm51bWVybyxcclxuICAgICAgICBjb21wbGVtZW50bzogZXN0YWJFeGlzdGVudGUuY29tcGxlbWVudG8gfHwgXCJcIixcclxuICAgICAgICBiYWlycm86IGVzdGFiRXhpc3RlbnRlLmJhaXJybyxcclxuICAgICAgICBtdW5pY2lwaW86IGVzdGFiRXhpc3RlbnRlLm11bmljaXBpbyxcclxuICAgICAgICB1ZjogZXN0YWJFeGlzdGVudGUudWYsXHJcbiAgICAgICAgcG9udG9fcmVmZXJlbmNpYTogZXN0YWJFeGlzdGVudGUucG9udG9fcmVmZXJlbmNpYSB8fCBcIlwiLFxyXG4gICAgICAgIGFjZXNzb19jb21wYXJ0aWxoYWRvX3Jlc2lkZW5jaWE6XHJcbiAgICAgICAgICBlc3RhYkV4aXN0ZW50ZS5hY2Vzc29fY29tcGFydGlsaGFkb19yZXNpZGVuY2lhLFxyXG4gICAgICAgIHRlbGVmb25lX2ZpeG86IGVzdGFiRXhpc3RlbnRlLnRlbGVmb25lX2ZpeG8gfHwgXCJcIixcclxuICAgICAgICB0ZWxlZm9uZV9jZWx1bGFyOiBlc3RhYkV4aXN0ZW50ZS50ZWxlZm9uZV9jZWx1bGFyLFxyXG4gICAgICAgIGVtYWlsOiBlc3RhYkV4aXN0ZW50ZS5lbWFpbCxcclxuICAgICAgICBjb21wZXRlbmNpYV9maXNjYWxpemFjYW86IGVzdGFiRXhpc3RlbnRlLmNvbXBldGVuY2lhX2Zpc2NhbGl6YWNhbyxcclxuICAgICAgICBob3JhcmlvX2Z1bmNpb25hbWVudG86IGVzdGFiRXhpc3RlbnRlLmhvcmFyaW9fZnVuY2lvbmFtZW50byB8fCBcIlwiLFxyXG4gICAgICAgIGZvbnRlX2FiYXN0ZWNpbWVudG9fYWd1YTpcclxuICAgICAgICAgIGVzdGFiRXhpc3RlbnRlLmZvbnRlX2FiYXN0ZWNpbWVudG9fYWd1YSB8fCBcIlJlZGUgUMO6YmxpY2EgKENPUEFTQSlcIixcclxuICAgICAgICBwb3NzdWlfcmVzZXJ2YXRvcmlvX3Byb3ByaW86XHJcbiAgICAgICAgICBlc3RhYkV4aXN0ZW50ZS5wb3NzdWlfcmVzZXJ2YXRvcmlvX3Byb3ByaW8sXHJcbiAgICAgICAgY2FwYWNpZGFkZV9yZXNlcnZhdG9yaW9fbGl0cm9zOlxyXG4gICAgICAgICAgZXN0YWJFeGlzdGVudGUuY2FwYWNpZGFkZV9yZXNlcnZhdG9yaW9fbGl0cm9zLFxyXG4gICAgICAgIHJlcHJlc2VudGFudGVfbGVnYWw6IGVzdGFiRXhpc3RlbnRlLnJlcHJlc2VudGFudGVfbGVnYWxcclxuICAgICAgICAgID8ge1xyXG4gICAgICAgICAgICAgIG5vbWVfY29tcGxldG86IGVzdGFiRXhpc3RlbnRlLnJlcHJlc2VudGFudGVfbGVnYWwubm9tZV9jb21wbGV0byxcclxuICAgICAgICAgICAgICBjcGY6IGVzdGFiRXhpc3RlbnRlLnJlcHJlc2VudGFudGVfbGVnYWwuY3BmLFxyXG4gICAgICAgICAgICAgIHJnX251bWVybzogZXN0YWJFeGlzdGVudGUucmVwcmVzZW50YW50ZV9sZWdhbC5yZ19udW1lcm8gfHwgXCJcIixcclxuICAgICAgICAgICAgICByZ19vcmdhb19lbWlzc29yOlxyXG4gICAgICAgICAgICAgICAgZXN0YWJFeGlzdGVudGUucmVwcmVzZW50YW50ZV9sZWdhbC5yZ19vcmdhb19lbWlzc29yIHx8IFwiU1NQL01HXCIsXHJcbiAgICAgICAgICAgICAgdGVsZWZvbmU6IGVzdGFiRXhpc3RlbnRlLnJlcHJlc2VudGFudGVfbGVnYWwudGVsZWZvbmUsXHJcbiAgICAgICAgICAgICAgZW1haWw6IGVzdGFiRXhpc3RlbnRlLnJlcHJlc2VudGFudGVfbGVnYWwuZW1haWwsXHJcbiAgICAgICAgICAgICAgZW5kZXJlY29fcmVzaWRlbmNpYWw6XHJcbiAgICAgICAgICAgICAgICBlc3RhYkV4aXN0ZW50ZS5yZXByZXNlbnRhbnRlX2xlZ2FsLmVuZGVyZWNvX3Jlc2lkZW5jaWFsLFxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICA6IHtcclxuICAgICAgICAgICAgICBub21lX2NvbXBsZXRvOiBcIlwiLFxyXG4gICAgICAgICAgICAgIGNwZjogXCJcIixcclxuICAgICAgICAgICAgICByZ19udW1lcm86IFwiXCIsXHJcbiAgICAgICAgICAgICAgcmdfb3JnYW9fZW1pc3NvcjogXCJTU1AvTUdcIixcclxuICAgICAgICAgICAgICB0ZWxlZm9uZTogXCJcIixcclxuICAgICAgICAgICAgICBlbWFpbDogXCJcIixcclxuICAgICAgICAgICAgICBlbmRlcmVjb19yZXNpZGVuY2lhbDogXCJcIixcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICBjbmFlczogZXN0YWJFeGlzdGVudGUuY25hZXMubWFwKChjKSA9PiAoe1xyXG4gICAgICAgICAgY25hZV9jb2RpZ286IGMuY25hZV9jb2RpZ28sXHJcbiAgICAgICAgICBkZXNjcmljYW86IGMuY25hZT8uZGVzY3JpY2FvLFxyXG4gICAgICAgICAgZ3JhdV9yaXNjb19wYWRyYW86IGMuY25hZT8uZ3JhdV9yaXNjb19wYWRyYW8sXHJcbiAgICAgICAgICBleGlnZV9ydDogYy5jbmFlPy5leGlnZV9ydCxcclxuICAgICAgICAgIGVoX3ByaW5jaXBhbDogYy5laF9wcmluY2lwYWwsXHJcbiAgICAgICAgICBkYXRhX2luaWNpb19hdGl2aWRhZGU6IGMuZGF0YV9pbmljaW9fYXRpdmlkYWRlIHx8IFwiXCIsXHJcbiAgICAgICAgfSkpLFxyXG4gICAgICB9KTtcclxuICAgIH1cclxuICB9LCBbZXN0YWJFeGlzdGVudGUsIHJlc2V0XSk7XHJcblxyXG4gIGNvbnN0IHdhdGNoZWRDbmFlcyA9IHdhdGNoKFwiY25hZXNcIikgfHwgW107XHJcblxyXG4gIC8vIEPDoWxjdWxvIHJlYXRpdm8gZG8gcmlzY28gc2FuaXTDoXJpbyBwcmVwb25kZXJhbnRlIG5vIGZvcm11bMOhcmlvXHJcbiAgY29uc3QgcmlzY29QcmVwb25kZXJhbnRlID0gdXNlTWVtbzxOaXZlbFJpc2NvPigoKSA9PiB7XHJcbiAgICBpZiAod2F0Y2hlZENuYWVzLmxlbmd0aCA9PT0gMCkgcmV0dXJuIFwiRGlzcGVuc2Fkb1wiO1xyXG4gICAgY29uc3QgcmlzY29zID0gd2F0Y2hlZENuYWVzLm1hcCgoYykgPT4gYy5ncmF1X3Jpc2NvX3BhZHJhbyk7XHJcbiAgICBpZiAocmlzY29zLmluY2x1ZGVzKFwiUmlzY28gSUlJXCIpKSByZXR1cm4gXCJSaXNjbyBJSUlcIjtcclxuICAgIGlmIChyaXNjb3MuaW5jbHVkZXMoXCJSaXNjbyBJSVwiKSkgcmV0dXJuIFwiUmlzY28gSUlcIjtcclxuICAgIGlmIChyaXNjb3MuaW5jbHVkZXMoXCJSaXNjbyBJXCIpKSByZXR1cm4gXCJSaXNjbyBJXCI7XHJcbiAgICByZXR1cm4gXCJEaXNwZW5zYWRvXCI7XHJcbiAgfSwgW3dhdGNoZWRDbmFlc10pO1xyXG5cclxuICBjb25zdCBvblN1Ym1pdCA9IGFzeW5jICh2YWx1ZXM6IEVzdGFiZWxlY2ltZW50b0Zvcm1TY2hlbWEpID0+IHtcclxuICAgIHNldEZvcm1FcnJvcihudWxsKTtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHNhbHZvID0gYXdhaXQgc2FsdmFyTXV0YXRpb24ubXV0YXRlQXN5bmModmFsdWVzIGFzIEVzdGFiZWxlY2ltZW50b0Zvcm1WYWx1ZXMpO1xyXG4gICAgICBuYXZpZ2F0ZShST1VURVMuRVNUQUJFTEVDSU1FTlRPUy5ERVRBTEhFKHNhbHZvLmlkKSk7XHJcbiAgICB9IGNhdGNoIChlcnI6IHVua25vd24pIHtcclxuICAgICAgc2V0Rm9ybUVycm9yKHBhcnNlQXBpRXJyb3IoZXJyKSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgaWYgKGlzRWRpdGluZyAmJiBjYXJyZWdhbmRvRGFkb3MpIHtcclxuICAgIHJldHVybiAoXHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0xNiB0ZXh0LWNlbnRlciB0ZXh0LXhzIHRleHQtc2xhdGUtNDAwIGZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyXCI+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTYgaC02IGJvcmRlci0yIGJvcmRlci10ZWFsLTUwMCBib3JkZXItdC10cmFuc3BhcmVudCByb3VuZGVkLWZ1bGwgYW5pbWF0ZS1zcGluIG1iLTNcIiAvPlxyXG4gICAgICAgIENhcnJlZ2FuZG8gZGFkb3MgZG8gZXN0YWJlbGVjaW1lbnRvIHBhcmEgZWRpw6fDo28uLi5cclxuICAgICAgPC9kaXY+XHJcbiAgICApO1xyXG4gIH1cclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS02IG1heC13LTR4bCBteC1hdXRvXCI+XHJcbiAgICAgIHsvKiBUb3BvIGNvbSBUw610dWxvIGUgUmlzY28gQ2FsY3VsYWRvICovfVxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgc206ZmxleC1yb3cgc206aXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtNCBiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC14bCBwLTYgc2hhZG93LXhzXCI+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxyXG4gICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gbmF2aWdhdGUoUk9VVEVTLkVTVEFCRUxFQ0lNRU5UT1MuTElTVCl9XHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMSB0ZXh0LXNsYXRlLTQwMCBob3Zlcjp0ZXh0LXNsYXRlLTYwMCBkYXJrOmhvdmVyOnRleHQtd2hpdGUgcm91bmRlZFwiXHJcbiAgICAgICAgICAgIHRpdGxlPVwiVm9sdGFyXCJcclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgPEFycm93TGVmdCBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz5cclxuICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1ib2xkIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZVwiPlxyXG4gICAgICAgICAgICAgIHtpc0VkaXRpbmcgPyBcIkVkaXRhciBFc3RhYmVsZWNpbWVudG9cIiA6IFwiTm92byBFc3RhYmVsZWNpbWVudG8gUmVndWxhZG9cIn1cclxuICAgICAgICAgICAgPC9oMT5cclxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTUwMCBkYXJrOnRleHQtc2xhdGUtNDAwXCI+XHJcbiAgICAgICAgICAgICAgUHJlZW5jaGEgb3MgZGFkb3MgY2FkYXN0cmFpcywgZW5kZXJlw6dvIGVtIHtBUFBfQ09ORklHLm11bmljaXBpb30ve0FQUF9DT05GSUcudWZ9IGUgYXRpdmlkYWRlcyBlY29uw7RtaWNhcy5cclxuICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgcC0yIGJnLXNsYXRlLTUwIGRhcms6Ymctc2xhdGUtODAwLzgwIHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtNzAwXCI+XHJcbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSBmb250LW1lZGl1bSB0ZXh0LXNsYXRlLTUwMFwiPlxyXG4gICAgICAgICAgICBSaXNjbyBFc3RpbWFkbzpcclxuICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgIDxSaXNjb0JhZGdlIHJpc2NvPXtyaXNjb1ByZXBvbmRlcmFudGV9IHNpemU9XCJzbVwiIC8+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAge2Zvcm1FcnJvciAmJiAoXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTQgYmctcm9zZS01MCBkYXJrOmJnLXJvc2UtOTUwLzQwIGJvcmRlciBib3JkZXItcm9zZS0yMDAgZGFyazpib3JkZXItcm9zZS04MDAgcm91bmRlZC14bCB0ZXh0LXhzIHRleHQtcm9zZS04MDAgZGFyazp0ZXh0LXJvc2UtMjAwIGZsZXggaXRlbXMtc3RhcnQgZ2FwLTNcIj5cclxuICAgICAgICAgIDxBbGVydENpcmNsZSBjbGFzc05hbWU9XCJ3LTUgaC01IHRleHQtcm9zZS02MDAgc2hyaW5rLTAgbXQtMC41XCIgLz5cclxuICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgYmxvY2tcIj5FcnJvIG5hIFZhbGlkYcOnw6NvOjwvc3Bhbj5cclxuICAgICAgICAgICAgPHNwYW4+e2Zvcm1FcnJvcn08L3NwYW4+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgKX1cclxuXHJcbiAgICAgIDxmb3JtIG9uU3VibWl0PXtoYW5kbGVTdWJtaXQob25TdWJtaXQpfSBjbGFzc05hbWU9XCJzcGFjZS15LTZcIj5cclxuICAgICAgICB7LyogU2XDp8OjbyAxOiBJZGVudGlmaWNhw6fDo28gSnVyw61kaWNhICovfVxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGFyazpiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtODAwIHJvdW5kZWQteGwgcC02IHNoYWRvdy14cyBzcGFjZS15LTRcIj5cclxuICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGUgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHBiLTIgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTEwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDBcIj5cclxuICAgICAgICAgICAgPEJ1aWxkaW5nMiBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtdGVhbC02MDBcIiAvPlxyXG4gICAgICAgICAgICAxLiBJZGVudGlmaWNhw6fDo28gSnVyw61kaWNhXHJcbiAgICAgICAgICA8L2gyPlxyXG5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBzbTpncmlkLWNvbHMtMyBnYXAtNCB0ZXh0LXhzXCI+XHJcbiAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0zMDAgZm9udC1tZWRpdW0gbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgVGlwbyBkZSBDYWRhc3RybyAqXHJcbiAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICA8c2VsZWN0XHJcbiAgICAgICAgICAgICAgICB7Li4ucmVnaXN0ZXIoXCJ0aXBvX2NhZGFzdHJvXCIpfVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB5LTIgcHgtMyBiZy1zbGF0ZS01MCBkYXJrOmJnLXNsYXRlLTgwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTMwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC1sZ1wiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlBKXCI+UGVzc29hIEp1csOtZGljYSAoUEopPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiUEZcIj5QZXNzb2EgRsOtc2ljYSAoUEYpPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgPC9zZWxlY3Q+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzbTpjb2wtc3Bhbi0yXCI+XHJcbiAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0zMDAgZm9udC1tZWRpdW0gbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgQ05QSiBvdSBDUEYgKGFwZW5hcyBuw7ptZXJvcyBvdSBjb20gbcOhc2NhcmEpICpcclxuICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgey4uLnJlZ2lzdGVyKFwiY25wal9jcGZcIil9XHJcbiAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkV4OiAxOC4zMDMuMTg3LzAwMDEtNDQgb3UgMTExLjIyMi4zMzMtNDRcIlxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB5LTIgcHgtMyBiZy1zbGF0ZS01MCBkYXJrOmJnLXNsYXRlLTgwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTMwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC1sZyBmb250LW1vbm9cIlxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAge2Vycm9ycy5jbnBqX2NwZiAmJiAoXHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LXJvc2UtNjAwIG10LTEgYmxvY2tcIj5cclxuICAgICAgICAgICAgICAgICAge2Vycm9ycy5jbnBqX2NwZi5tZXNzYWdlfVxyXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzbTpjb2wtc3Bhbi0yXCI+XHJcbiAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0zMDAgZm9udC1tZWRpdW0gbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgUmF6w6NvIFNvY2lhbCAvIE5vbWUgQ2l2aWwgKlxyXG4gICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICB7Li4ucmVnaXN0ZXIoXCJyYXphb19zb2NpYWxcIil9XHJcbiAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIk5vbWUgZW1wcmVzYXJpYWwgcmVnaXN0cmFkb1wiXHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHktMiBweC0zIGJnLXNsYXRlLTUwIGRhcms6Ymctc2xhdGUtODAwIGJvcmRlciBib3JkZXItc2xhdGUtMzAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCByb3VuZGVkLWxnXCJcclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIHtlcnJvcnMucmF6YW9fc29jaWFsICYmIChcclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtcm9zZS02MDAgbXQtMSBibG9ja1wiPlxyXG4gICAgICAgICAgICAgICAgICB7ZXJyb3JzLnJhemFvX3NvY2lhbC5tZXNzYWdlfVxyXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTMwMCBmb250LW1lZGl1bSBtYi0xXCI+XHJcbiAgICAgICAgICAgICAgICBOb21lIEZhbnRhc2lhXHJcbiAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgIHsuLi5yZWdpc3RlcihcIm5vbWVfZmFudGFzaWFcIil9XHJcbiAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIk5vbWUgY29tZXJjaWFsIGRpdnVsZ2Fkb1wiXHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHktMiBweC0zIGJnLXNsYXRlLTUwIGRhcms6Ymctc2xhdGUtODAwIGJvcmRlciBib3JkZXItc2xhdGUtMzAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCByb3VuZGVkLWxnXCJcclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0zMDAgZm9udC1tZWRpdW0gbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgSW5zY3Jpw6fDo28gTXVuaWNpcGFsXHJcbiAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgIHsuLi5yZWdpc3RlcihcImluc2NyaWNhb19tdW5pY2lwYWxcIil9XHJcbiAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkV4OiAxMDIwMzBcIlxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB5LTIgcHgtMyBiZy1zbGF0ZS01MCBkYXJrOmJnLXNsYXRlLTgwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTMwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC1sZyBmb250LW1vbm9cIlxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTMwMCBmb250LW1lZGl1bSBtYi0xXCI+XHJcbiAgICAgICAgICAgICAgICBDb21wZXTDqm5jaWEgZGUgRmlzY2FsaXphw6fDo29cclxuICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDxzZWxlY3RcclxuICAgICAgICAgICAgICAgIHsuLi5yZWdpc3RlcihcImNvbXBldGVuY2lhX2Zpc2NhbGl6YWNhb1wiKX1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweS0yIHB4LTMgYmctc2xhdGUtNTAgZGFyazpiZy1zbGF0ZS04MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS0zMDAgZGFyazpib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQtbGdcIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJNdW5pY2lwYWxcIj5NdW5pY2lwYWw8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJFc3RhZHVhbFwiPkVzdGFkdWFsPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiUGFjdHVhZG9cIj5QYWN0dWFkbzwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgIDwvc2VsZWN0PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICB7LyogU2XDp8OjbyAyOiBMb2NhbGl6YcOnw6NvIGUgQ29udGF0byAqL31cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIGRhcms6Ymctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLXhsIHAtNiBzaGFkb3cteHMgc3BhY2UteS00XCI+XHJcbiAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBwYi0yIGJvcmRlci1iIGJvcmRlci1zbGF0ZS0xMDAgZGFyazpib3JkZXItc2xhdGUtODAwXCI+XHJcbiAgICAgICAgICAgIDxNYXBQaW4gY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LXRlYWwtNjAwXCIgLz5cclxuICAgICAgICAgICAgMi4gRW5kZXJlw6dvIGUgQ29udGF0b3MgZW0ge0FQUF9DT05GSUcubXVuaWNpcGlvfS97QVBQX0NPTkZJRy51Zn1cclxuICAgICAgICAgIDwvaDI+XHJcblxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIHNtOmdyaWQtY29scy00IGdhcC00IHRleHQteHNcIj5cclxuICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTMwMCBmb250LW1lZGl1bSBtYi0xXCI+XHJcbiAgICAgICAgICAgICAgICBDRVAgKlxyXG4gICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICB7Li4ucmVnaXN0ZXIoXCJjZXBcIil9XHJcbiAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIjM1MTg5MDAwIG91IDM1MTg5LTAwMFwiXHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHktMiBweC0zIGJnLXNsYXRlLTUwIGRhcms6Ymctc2xhdGUtODAwIGJvcmRlciBib3JkZXItc2xhdGUtMzAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCByb3VuZGVkLWxnIGZvbnQtbW9ub1wiXHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICB7ZXJyb3JzLmNlcCAmJiAoXHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LXJvc2UtNjAwIG10LTEgYmxvY2tcIj5cclxuICAgICAgICAgICAgICAgICAge2Vycm9ycy5jZXAubWVzc2FnZX1cclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic206Y29sLXNwYW4tMlwiPlxyXG4gICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMzAwIGZvbnQtbWVkaXVtIG1iLTFcIj5cclxuICAgICAgICAgICAgICAgIExvZ3JhZG91cm8gKFJ1YSwgQXZlbmlkYSwgUHJhw6dhKSAqXHJcbiAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgIHsuLi5yZWdpc3RlcihcImxvZ3JhZG91cm9cIil9XHJcbiAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkV4OiBBdmVuaWRhIEp1c2NlbGlubyBLdWJpdHNjaGVrXCJcclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweS0yIHB4LTMgYmctc2xhdGUtNTAgZGFyazpiZy1zbGF0ZS04MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS0zMDAgZGFyazpib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQtbGdcIlxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAge2Vycm9ycy5sb2dyYWRvdXJvICYmIChcclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtcm9zZS02MDAgbXQtMSBibG9ja1wiPlxyXG4gICAgICAgICAgICAgICAgICB7ZXJyb3JzLmxvZ3JhZG91cm8ubWVzc2FnZX1cclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0zMDAgZm9udC1tZWRpdW0gbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgTsO6bWVybyAqXHJcbiAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgIHsuLi5yZWdpc3RlcihcIm51bWVyb1wiKX1cclxuICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRXg6IDEwMCBvdSBTL05cIlxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB5LTIgcHgtMyBiZy1zbGF0ZS01MCBkYXJrOmJnLXNsYXRlLTgwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTMwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC1sZ1wiXHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICB7ZXJyb3JzLm51bWVybyAmJiAoXHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LXJvc2UtNjAwIG10LTEgYmxvY2tcIj5cclxuICAgICAgICAgICAgICAgICAge2Vycm9ycy5udW1lcm8ubWVzc2FnZX1cclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0zMDAgZm9udC1tZWRpdW0gbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgQ29tcGxlbWVudG9cclxuICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgey4uLnJlZ2lzdGVyKFwiY29tcGxlbWVudG9cIil9XHJcbiAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkV4OiBTYWxhIDIsIEdhbHDDo28gQVwiXHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHktMiBweC0zIGJnLXNsYXRlLTUwIGRhcms6Ymctc2xhdGUtODAwIGJvcmRlciBib3JkZXItc2xhdGUtMzAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCByb3VuZGVkLWxnXCJcclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0zMDAgZm9udC1tZWRpdW0gbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgQmFpcnJvICpcclxuICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgey4uLnJlZ2lzdGVyKFwiYmFpcnJvXCIpfVxyXG4gICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJDZW50cm8sIE5vdm8gSG9yaXpvbnRlLCBldGMuXCJcclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweS0yIHB4LTMgYmctc2xhdGUtNTAgZGFyazpiZy1zbGF0ZS04MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS0zMDAgZGFyazpib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQtbGdcIlxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAge2Vycm9ycy5iYWlycm8gJiYgKFxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1yb3NlLTYwMCBtdC0xIGJsb2NrXCI+XHJcbiAgICAgICAgICAgICAgICAgIHtlcnJvcnMuYmFpcnJvLm1lc3NhZ2V9XHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMzAwIGZvbnQtbWVkaXVtIG1iLTFcIj5cclxuICAgICAgICAgICAgICAgIE11bmljw61waW9cclxuICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgey4uLnJlZ2lzdGVyKFwibXVuaWNpcGlvXCIpfVxyXG4gICAgICAgICAgICAgICAgcmVhZE9ubHlcclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweS0yIHB4LTMgYmctc2xhdGUtMTAwIGRhcms6Ymctc2xhdGUtODAwLzUwIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCByb3VuZGVkLWxnIHRleHQtc2xhdGUtNTAwIGN1cnNvci1ub3QtYWxsb3dlZFwiXHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMzAwIGZvbnQtbWVkaXVtIG1iLTFcIj5cclxuICAgICAgICAgICAgICAgIFVGXHJcbiAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgIHsuLi5yZWdpc3RlcihcInVmXCIpfVxyXG4gICAgICAgICAgICAgICAgcmVhZE9ubHlcclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweS0yIHB4LTMgYmctc2xhdGUtMTAwIGRhcms6Ymctc2xhdGUtODAwLzUwIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCByb3VuZGVkLWxnIHRleHQtc2xhdGUtNTAwIGN1cnNvci1ub3QtYWxsb3dlZFwiXHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNtOmNvbC1zcGFuLTJcIj5cclxuICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTMwMCBmb250LW1lZGl1bSBtYi0xXCI+XHJcbiAgICAgICAgICAgICAgICBUZWxlZm9uZSBDZWx1bGFyIC8gV2hhdHNBcHAgKlxyXG4gICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICB7Li4ucmVnaXN0ZXIoXCJ0ZWxlZm9uZV9jZWx1bGFyXCIpfVxyXG4gICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCIoMzMpIDk4ODg4LTAwMDBcIlxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB5LTIgcHgtMyBiZy1zbGF0ZS01MCBkYXJrOmJnLXNsYXRlLTgwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTMwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC1sZyBmb250LW1vbm9cIlxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAge2Vycm9ycy50ZWxlZm9uZV9jZWx1bGFyICYmIChcclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtcm9zZS02MDAgbXQtMSBibG9ja1wiPlxyXG4gICAgICAgICAgICAgICAgICB7ZXJyb3JzLnRlbGVmb25lX2NlbHVsYXIubWVzc2FnZX1cclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic206Y29sLXNwYW4tMlwiPlxyXG4gICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMzAwIGZvbnQtbWVkaXVtIG1iLTFcIj5cclxuICAgICAgICAgICAgICAgIEUtbWFpbCBJbnN0aXR1Y2lvbmFsICpcclxuICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgdHlwZT1cImVtYWlsXCJcclxuICAgICAgICAgICAgICAgIHsuLi5yZWdpc3RlcihcImVtYWlsXCIpfVxyXG4gICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJjb250YXRvQGVtcHJlc2EuY29tLmJyXCJcclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweS0yIHB4LTMgYmctc2xhdGUtNTAgZGFyazpiZy1zbGF0ZS04MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS0zMDAgZGFyazpib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQtbGdcIlxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAge2Vycm9ycy5lbWFpbCAmJiAoXHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LXJvc2UtNjAwIG10LTEgYmxvY2tcIj5cclxuICAgICAgICAgICAgICAgICAge2Vycm9ycy5lbWFpbC5tZXNzYWdlfVxyXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzbTpjb2wtc3Bhbi00IGZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHB0LTJcIj5cclxuICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXHJcbiAgICAgICAgICAgICAgICBpZD1cImFjZXNzb19jb21wYXJ0aWxoYWRvX2NoZWNrXCJcclxuICAgICAgICAgICAgICAgIHsuLi5yZWdpc3RlcihcImFjZXNzb19jb21wYXJ0aWxoYWRvX3Jlc2lkZW5jaWFcIil9XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJyb3VuZGVkIHRleHQtdGVhbC02MDAgZm9jdXM6cmluZy10ZWFsLTUwMCBoLTQgdy00XCJcclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgaHRtbEZvcj1cImFjZXNzb19jb21wYXJ0aWxoYWRvX2NoZWNrXCJcclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTMwMCBjdXJzb3ItcG9pbnRlclwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgTyBlc3RhYmVsZWNpbWVudG8gcG9zc3VpIGFjZXNzbyBjb21wYXJ0aWxoYWRvIG91IGZ1bmNpb25hIGVtIHJlc2lkw6puY2lhXHJcbiAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgey8qIFNlw6fDo28gMzogQXRpdmlkYWRlcyBFY29uw7RtaWNhcyAoQ05BRXMpICovfVxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGFyazpiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtODAwIHJvdW5kZWQteGwgcC02IHNoYWRvdy14c1wiPlxyXG4gICAgICAgICAgPENvbnRyb2xsZXJcclxuICAgICAgICAgICAgY29udHJvbD17Y29udHJvbH1cclxuICAgICAgICAgICAgbmFtZT1cImNuYWVzXCJcclxuICAgICAgICAgICAgcmVuZGVyPXsoeyBmaWVsZCB9KSA9PiAoXHJcbiAgICAgICAgICAgICAgPENuYWVTZWxlY3RBc3luY1xyXG4gICAgICAgICAgICAgICAgc2VsZWN0ZWRDbmFlcz17ZmllbGQudmFsdWUgYXMgU2VsZWN0ZWRDTkFFW119XHJcbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17ZmllbGQub25DaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICBlcnJvcj17ZXJyb3JzLmNuYWVzPy5tZXNzYWdlfVxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICB7LyogU2XDp8OjbyA0OiBSZXByZXNlbnRhbnRlIExlZ2FsICovfVxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGFyazpiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtODAwIHJvdW5kZWQteGwgcC02IHNoYWRvdy14cyBzcGFjZS15LTRcIj5cclxuICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGUgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHBiLTIgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTEwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDBcIj5cclxuICAgICAgICAgICAgPFVzZXIgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LXRlYWwtNjAwXCIgLz5cclxuICAgICAgICAgICAgNC4gUmVwcmVzZW50YW50ZSBMZWdhbFxyXG4gICAgICAgICAgPC9oMj5cclxuXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgc206Z3JpZC1jb2xzLTMgZ2FwLTQgdGV4dC14c1wiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNtOmNvbC1zcGFuLTJcIj5cclxuICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTMwMCBmb250LW1lZGl1bSBtYi0xXCI+XHJcbiAgICAgICAgICAgICAgICBOb21lIENvbXBsZXRvIGRvIFJlcHJlc2VudGFudGUgKlxyXG4gICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICB7Li4ucmVnaXN0ZXIoXCJyZXByZXNlbnRhbnRlX2xlZ2FsLm5vbWVfY29tcGxldG9cIil9XHJcbiAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkV4OiBKb3PDqSBDYXJsb3MgRmVycmVpcmFcIlxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB5LTIgcHgtMyBiZy1zbGF0ZS01MCBkYXJrOmJnLXNsYXRlLTgwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTMwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC1sZ1wiXHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICB7ZXJyb3JzLnJlcHJlc2VudGFudGVfbGVnYWw/Lm5vbWVfY29tcGxldG8gJiYgKFxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1yb3NlLTYwMCBtdC0xIGJsb2NrXCI+XHJcbiAgICAgICAgICAgICAgICAgIHtlcnJvcnMucmVwcmVzZW50YW50ZV9sZWdhbC5ub21lX2NvbXBsZXRvLm1lc3NhZ2V9XHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMzAwIGZvbnQtbWVkaXVtIG1iLTFcIj5cclxuICAgICAgICAgICAgICAgIENQRiBkbyBSZXByZXNlbnRhbnRlICpcclxuICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgey4uLnJlZ2lzdGVyKFwicmVwcmVzZW50YW50ZV9sZWdhbC5jcGZcIil9XHJcbiAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIjExMS4yMjIuMzMzLTQ0XCJcclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweS0yIHB4LTMgYmctc2xhdGUtNTAgZGFyazpiZy1zbGF0ZS04MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS0zMDAgZGFyazpib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQtbGcgZm9udC1tb25vXCJcclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIHtlcnJvcnMucmVwcmVzZW50YW50ZV9sZWdhbD8uY3BmICYmIChcclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtcm9zZS02MDAgbXQtMSBibG9ja1wiPlxyXG4gICAgICAgICAgICAgICAgICB7ZXJyb3JzLnJlcHJlc2VudGFudGVfbGVnYWwuY3BmLm1lc3NhZ2V9XHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMzAwIGZvbnQtbWVkaXVtIG1iLTFcIj5cclxuICAgICAgICAgICAgICAgIFRlbGVmb25lIGRvIFJlcHJlc2VudGFudGUgKlxyXG4gICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICB7Li4ucmVnaXN0ZXIoXCJyZXByZXNlbnRhbnRlX2xlZ2FsLnRlbGVmb25lXCIpfVxyXG4gICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCIoMzMpIDk4ODAxLTExMjJcIlxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB5LTIgcHgtMyBiZy1zbGF0ZS01MCBkYXJrOmJnLXNsYXRlLTgwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTMwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC1sZyBmb250LW1vbm9cIlxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzbTpjb2wtc3Bhbi0yXCI+XHJcbiAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0zMDAgZm9udC1tZWRpdW0gbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgRS1tYWlsIGRvIFJlcHJlc2VudGFudGUgKlxyXG4gICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICB0eXBlPVwiZW1haWxcIlxyXG4gICAgICAgICAgICAgICAgey4uLnJlZ2lzdGVyKFwicmVwcmVzZW50YW50ZV9sZWdhbC5lbWFpbFwiKX1cclxuICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwicmVwcmVzZW50YW50ZUBlbWFpbC5jb21cIlxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB5LTIgcHgtMyBiZy1zbGF0ZS01MCBkYXJrOmJnLXNsYXRlLTgwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTMwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC1sZ1wiXHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNtOmNvbC1zcGFuLTNcIj5cclxuICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTMwMCBmb250LW1lZGl1bSBtYi0xXCI+XHJcbiAgICAgICAgICAgICAgICBFbmRlcmXDp28gUmVzaWRlbmNpYWwgZG8gUmVwcmVzZW50YW50ZSAqXHJcbiAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgIHsuLi5yZWdpc3RlcihcInJlcHJlc2VudGFudGVfbGVnYWwuZW5kZXJlY29fcmVzaWRlbmNpYWxcIil9XHJcbiAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlJ1YSwgTsO6bWVybywgQmFpcnJvLCBNdW5pY8OtcGlvL1VGXCJcclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweS0yIHB4LTMgYmctc2xhdGUtNTAgZGFyazpiZy1zbGF0ZS04MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS0zMDAgZGFyazpib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQtbGdcIlxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIHsvKiBTZcOnw6NvIDU6IFNhbmVhbWVudG8gZSBJbmZyYWVzdHJ1dHVyYSAqL31cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIGRhcms6Ymctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLXhsIHAtNiBzaGFkb3cteHMgc3BhY2UteS00XCI+XHJcbiAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBwYi0yIGJvcmRlci1iIGJvcmRlci1zbGF0ZS0xMDAgZGFyazpib3JkZXItc2xhdGUtODAwXCI+XHJcbiAgICAgICAgICAgIDxEcm9wbGV0cyBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtdGVhbC02MDBcIiAvPlxyXG4gICAgICAgICAgICA1LiBTYW5lYW1lbnRvIGUgQWJhc3RlY2ltZW50byBkZSDDgWd1YVxyXG4gICAgICAgICAgPC9oMj5cclxuXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgc206Z3JpZC1jb2xzLTMgZ2FwLTQgdGV4dC14c1wiPlxyXG4gICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMzAwIGZvbnQtbWVkaXVtIG1iLTFcIj5cclxuICAgICAgICAgICAgICAgIEZvbnRlIGRlIEFiYXN0ZWNpbWVudG9cclxuICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgey4uLnJlZ2lzdGVyKFwiZm9udGVfYWJhc3RlY2ltZW50b19hZ3VhXCIpfVxyXG4gICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJSZWRlIFDDumJsaWNhIChDT1BBU0EpXCJcclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweS0yIHB4LTMgYmctc2xhdGUtNTAgZGFyazpiZy1zbGF0ZS04MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS0zMDAgZGFyazpib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQtbGdcIlxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBwdC02XCI+XHJcbiAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxyXG4gICAgICAgICAgICAgICAgaWQ9XCJyZXNlcnZhdG9yaW9fcHJvcHJpb19jaGVja1wiXHJcbiAgICAgICAgICAgICAgICB7Li4ucmVnaXN0ZXIoXCJwb3NzdWlfcmVzZXJ2YXRvcmlvX3Byb3ByaW9cIil9XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJyb3VuZGVkIHRleHQtdGVhbC02MDAgZm9jdXM6cmluZy10ZWFsLTUwMCBoLTQgdy00XCJcclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgaHRtbEZvcj1cInJlc2VydmF0b3Jpb19wcm9wcmlvX2NoZWNrXCJcclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTMwMCBjdXJzb3ItcG9pbnRlclwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgUG9zc3VpIHJlc2VydmF0w7NyaW8gcHLDs3ByaW9cclxuICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0zMDAgZm9udC1tZWRpdW0gbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgQ2FwYWNpZGFkZSBkbyBSZXNlcnZhdMOzcmlvIChMaXRyb3MpXHJcbiAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgey4uLnJlZ2lzdGVyKFwiY2FwYWNpZGFkZV9yZXNlcnZhdG9yaW9fbGl0cm9zXCIpfVxyXG4gICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFeDogNTAwMFwiXHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHktMiBweC0zIGJnLXNsYXRlLTUwIGRhcms6Ymctc2xhdGUtODAwIGJvcmRlciBib3JkZXItc2xhdGUtMzAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCByb3VuZGVkLWxnIGZvbnQtbW9ub1wiXHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgey8qIEJvdMO1ZXMgZGUgQcOnw6NvICovfVxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1lbmQgZ2FwLTMgcHQtNCBib3JkZXItdCBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMFwiPlxyXG4gICAgICAgICAgPExpbmtcclxuICAgICAgICAgICAgdG89e1JPVVRFUy5FU1RBQkVMRUNJTUVOVE9TLkxJU1R9XHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTQgcHktMiB0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtc2xhdGUtNjAwIGRhcms6dGV4dC1zbGF0ZS0zMDAgaG92ZXI6Ymctc2xhdGUtMTAwIGRhcms6aG92ZXI6Ymctc2xhdGUtODAwIHJvdW5kZWQtbGcgdHJhbnNpdGlvbi1jb2xvcnNcIlxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICBDYW5jZWxhclxyXG4gICAgICAgICAgPC9MaW5rPlxyXG5cclxuICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgdHlwZT1cInN1Ym1pdFwiXHJcbiAgICAgICAgICAgIGRpc2FibGVkPXtpc1N1Ym1pdHRpbmcgfHwgc2FsdmFyTXV0YXRpb24uaXNQZW5kaW5nfVxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgcHgtNSBweS0yLjUgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtd2hpdGUgYmctdGVhbC02MDAgaG92ZXI6YmctdGVhbC01MDAgcm91bmRlZC1sZyBzaGFkb3cteHMgdHJhbnNpdGlvbi1jb2xvcnMgZGlzYWJsZWQ6b3BhY2l0eS01MFwiXHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIHtpc1N1Ym1pdHRpbmcgfHwgc2FsdmFyTXV0YXRpb24uaXNQZW5kaW5nID8gKFxyXG4gICAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMy41IGgtMy41IGJvcmRlci0yIGJvcmRlci13aGl0ZSBib3JkZXItdC10cmFuc3BhcmVudCByb3VuZGVkLWZ1bGwgYW5pbWF0ZS1zcGluXCIgLz5cclxuICAgICAgICAgICAgICAgIDxzcGFuPkdyYXZhbmRvIG5vIEJhbmNvLi4uPC9zcGFuPlxyXG4gICAgICAgICAgICAgIDwvPlxyXG4gICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAgICA8U2F2ZSBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNVwiIC8+XHJcbiAgICAgICAgICAgICAgICA8c3Bhbj5TYWx2YXIgRXN0YWJlbGVjaW1lbnRvPC9zcGFuPlxyXG4gICAgICAgICAgICAgIDwvPlxyXG4gICAgICAgICAgICApfVxyXG4gICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZm9ybT5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBFc3RhYmVsZWNpbWVudG9Gb3JtUGFnZTtcclxuIl19