import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/estabelecimentos/CnaeSelectAsync.tsx");const React = __vite__cjsImport0_react; const useEffect = __vite__cjsImport0_react["useEffect"]; const useMemo = __vite__cjsImport0_react["useMemo"]; const useRef = __vite__cjsImport0_react["useRef"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"];/**
* Componente de Busca Assíncrona e Gestão de CNAEs com Debounce
* Permite selecionar atividades do catálogo oficial, definir estritamente 1 CNAE principal
* e sinaliza alertas regulatórios (Exigência de RT e Projeto Arquitetônico).
*/
import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=0fd2848a";
import { AlertTriangle, Check, Plus, Search, Trash2 } from "/node_modules/.vite/deps/lucide-react.js?v=0fd2848a";
import { useCNAEAutocomplete } from "/src/hooks/useEstabelecimentos.ts";
import RiscoBadge from "/src/components/estabelecimentos/RiscoBadge.tsx";
var _jsxFileName = "E:/Projetos VSCODE/visa_braunas/src/components/estabelecimentos/CnaeSelectAsync.tsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=0fd2848a";
var _s = $RefreshSig$();
export const CnaeSelectAsync = ({ selectedCnaes, onChange, error }) => {
	_s();
	const [searchTerm, setSearchTerm] = useState("");
	const [debouncedSearch, setDebouncedSearch] = useState("");
	const [dropdownOpen, setDropdownOpen] = useState(false);
	const dropdownRef = useRef(null);
	// Debounce de 350ms para evitar sobrecarga de consultas
	useEffect(() => {
		const handler = setTimeout(() => {
			setDebouncedSearch(searchTerm);
		}, 350);
		return () => clearTimeout(handler);
	}, [searchTerm]);
	const { data: cnaesCatalogo = [], isLoading } = useCNAEAutocomplete(debouncedSearch);
	// Fecha o dropdown ao clicar fora
	useEffect(() => {
		function handleClickOutside(event) {
			if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
				setDropdownOpen(false);
			}
		}
		document.addEventListener("mousedown", handleClickOutside);
		return () => document.removeEventListener("mousedown", handleClickOutside);
	}, []);
	// Alerta de exigência de Responsável Técnico (RT)
	const cnaesComExigenciaRT = useMemo(() => {
		return selectedCnaes.filter((c) => c.exige_rt);
	}, [selectedCnaes]);
	// Cálculo visual do Risco Sanitário Preponderante
	const riscoPreponderante = useMemo(() => {
		if (selectedCnaes.length === 0) return "Dispensado";
		const riscos = selectedCnaes.map((c) => c.grau_risco_padrao);
		if (riscos.includes("Risco III")) return "Risco III";
		if (riscos.includes("Risco II")) return "Risco II";
		if (riscos.includes("Risco I")) return "Risco I";
		return "Dispensado";
	}, [selectedCnaes]);
	const handleAddCnae = (cnae) => {
		if (selectedCnaes.some((item) => item.cnae_codigo === cnae.codigo)) {
			setDropdownOpen(false);
			return;
		}
		const ehPrimeiro = selectedCnaes.length === 0;
		const novoItem = {
			cnae_codigo: cnae.codigo,
			descricao: cnae.descricao,
			grau_risco_padrao: cnae.grau_risco_padrao,
			exige_rt: cnae.exige_rt,
			exige_projeto_arquitetonico: cnae.exige_projeto_arquitetonico,
			eh_principal: ehPrimeiro,
			data_inicio_atividade: new Date().toISOString().split("T")[0]
		};
		onChange([...selectedCnaes, novoItem]);
		setSearchTerm("");
		setDropdownOpen(false);
	};
	const handleSetPrincipal = (codigo) => {
		const atualizados = selectedCnaes.map((item) => ({
			...item,
			eh_principal: item.cnae_codigo === codigo
		}));
		onChange(atualizados);
	};
	const handleRemove = (codigo) => {
		const filtrados = selectedCnaes.filter((item) => item.cnae_codigo !== codigo);
		// Se removeu o que era principal, define o primeiro restante como principal
		if (filtrados.length > 0 && !filtrados.some((i) => i.eh_principal)) {
			filtrados[0].eh_principal = true;
		}
		onChange(filtrados);
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2 border-b border-slate-100 dark:border-slate-800",
				children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
					className: "text-xs font-semibold text-slate-900 dark:text-white uppercase tracking-wider",
					children: "Atividades Econômicas Vinculadas (CNAEs)"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 134,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("p", {
					className: "text-[11px] text-slate-500 dark:text-slate-400",
					children: "É obrigatório vincular pelo menos 1 atividade econômica, definindo estritamente uma como principal."
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 137,
					columnNumber: 11
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 133,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ _jsxDEV("span", {
						className: "text-[11px] text-slate-500 font-medium",
						children: "Risco Calculado:"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 143,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV(RiscoBadge, {
						risco: riscoPreponderante,
						size: "sm"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 146,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 142,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 132,
				columnNumber: 7
			}, this),
			cnaesComExigenciaRT.length > 0 && /* @__PURE__ */ _jsxDEV("div", {
				className: "p-3 bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 rounded-lg text-xs text-amber-900 dark:text-amber-200 flex items-start gap-2.5",
				children: [/* @__PURE__ */ _jsxDEV(AlertTriangle, { className: "w-4 h-4 text-amber-600 dark:text-amber-400 shrink-0 mt-0.5" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 153,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "space-y-1",
					children: [/* @__PURE__ */ _jsxDEV("span", {
						className: "font-semibold block",
						children: "Exigência Regulatória de Responsável Técnico (RT):"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 155,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("p", {
						className: "text-[11px] leading-relaxed",
						children: [
							"As atividades",
							" ",
							/* @__PURE__ */ _jsxDEV("strong", { children: cnaesComExigenciaRT.map((c) => c.cnae_codigo).join(", ") }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 160,
								columnNumber: 15
							}, this),
							" ",
							"exigem a indicação obrigatória de um Responsável Técnico com registro ativo no Conselho de Classe (ex: CRF, CRM, CRBio)."
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 158,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 154,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 152,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "relative",
				ref: dropdownRef,
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "relative",
					children: [/* @__PURE__ */ _jsxDEV(Search, { className: "w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 172,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("input", {
						type: "text",
						value: searchTerm,
						onChange: (e) => {
							setSearchTerm(e.target.value);
							setDropdownOpen(true);
						},
						onFocus: () => setDropdownOpen(true),
						placeholder: "Digite o código (ex: 4771-7/01) ou descrição da atividade...",
						className: "w-full pl-9 pr-4 py-2 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg text-xs text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-teal-500"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 173,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 171,
					columnNumber: 9
				}, this), dropdownOpen && /* @__PURE__ */ _jsxDEV("div", {
					className: "absolute z-30 mt-1 w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-lg max-h-60 overflow-y-auto",
					children: isLoading ? /* @__PURE__ */ _jsxDEV("div", {
						className: "p-4 text-center text-xs text-slate-400",
						children: "Pesquisando catálogo de CNAEs..."
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 190,
						columnNumber: 15
					}, this) : cnaesCatalogo.length === 0 ? /* @__PURE__ */ _jsxDEV("div", {
						className: "p-4 text-center text-xs text-slate-400",
						children: [
							"Nenhum CNAE encontrado para \"",
							debouncedSearch,
							"\"."
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 194,
						columnNumber: 15
					}, this) : /* @__PURE__ */ _jsxDEV("ul", {
						className: "divide-y divide-slate-100 dark:divide-slate-800 text-xs",
						children: cnaesCatalogo.map((cnae) => {
							const jaSelecionado = selectedCnaes.some((i) => i.cnae_codigo === cnae.codigo);
							return /* @__PURE__ */ _jsxDEV("li", {
								onClick: () => !jaSelecionado && handleAddCnae(cnae),
								className: `p-3 flex items-start justify-between gap-3 transition-colors ${jaSelecionado ? "bg-slate-50 dark:bg-slate-800/40 opacity-60 cursor-not-allowed" : "hover:bg-teal-50/60 dark:hover:bg-slate-800/80 cursor-pointer"}`,
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "space-y-0.5",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center gap-2",
										children: [
											/* @__PURE__ */ _jsxDEV("span", {
												className: "font-mono font-semibold text-slate-900 dark:text-white",
												children: cnae.codigo
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 215,
												columnNumber: 27
											}, this),
											/* @__PURE__ */ _jsxDEV(RiscoBadge, {
												risco: cnae.grau_risco_padrao,
												size: "sm"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 218,
												columnNumber: 27
											}, this),
											cnae.exige_rt && /* @__PURE__ */ _jsxDEV("span", {
												className: "text-[10px] font-medium text-amber-700 dark:text-amber-300 bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 px-1.5 py-0.2 rounded",
												children: "Exige RT"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 220,
												columnNumber: 29
											}, this),
											cnae.exige_projeto_arquitetonico && /* @__PURE__ */ _jsxDEV("span", {
												className: "text-[10px] font-medium text-blue-700 dark:text-blue-300 bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-800 px-1.5 py-0.2 rounded",
												children: "Projeto Arquitetônico"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 225,
												columnNumber: 29
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 214,
										columnNumber: 25
									}, this), /* @__PURE__ */ _jsxDEV("p", {
										className: "text-[11px] text-slate-600 dark:text-slate-300 leading-snug",
										children: cnae.descricao
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 230,
										columnNumber: 25
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 213,
									columnNumber: 23
								}, this), /* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									disabled: jaSelecionado,
									className: "p-1 rounded text-teal-600 hover:bg-teal-100 dark:hover:bg-teal-950/60 transition-colors shrink-0",
									children: jaSelecionado ? /* @__PURE__ */ _jsxDEV(Check, { className: "w-4 h-4 text-emerald-600" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 241,
										columnNumber: 27
									}, this) : /* @__PURE__ */ _jsxDEV(Plus, { className: "w-4 h-4" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 243,
										columnNumber: 27
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 235,
									columnNumber: 23
								}, this)]
							}, cnae.id, true, {
								fileName: _jsxFileName,
								lineNumber: 204,
								columnNumber: 21
							}, this);
						})
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 198,
						columnNumber: 15
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 188,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 170,
				columnNumber: 7
			}, this),
			error && /* @__PURE__ */ _jsxDEV("p", {
				className: "text-xs text-rose-600 font-medium",
				children: error
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 255,
				columnNumber: 17
			}, this),
			selectedCnaes.length === 0 ? /* @__PURE__ */ _jsxDEV("div", {
				className: "p-6 border border-dashed border-slate-300 dark:border-slate-700 rounded-xl text-center text-xs text-slate-500",
				children: "Nenhuma atividade CNAE adicionada. Utilize a busca acima para vincular o CNAE principal."
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 259,
				columnNumber: 9
			}, this) : /* @__PURE__ */ _jsxDEV("div", {
				className: "border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden",
				children: /* @__PURE__ */ _jsxDEV("table", {
					className: "w-full text-left text-xs",
					children: [/* @__PURE__ */ _jsxDEV("thead", {
						className: "bg-slate-50 dark:bg-slate-800/60 border-b border-slate-200 dark:border-slate-800 text-slate-500 font-semibold uppercase tracking-wider text-[11px]",
						children: /* @__PURE__ */ _jsxDEV("tr", { children: [
							/* @__PURE__ */ _jsxDEV("th", {
								className: "py-2.5 px-3 text-center w-20",
								children: "Principal"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 267,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV("th", {
								className: "py-2.5 px-3",
								children: "Código & Descrição"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 268,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV("th", {
								className: "py-2.5 px-3",
								children: "Risco Sanitário"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 269,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV("th", {
								className: "py-2.5 px-3",
								children: "Exigências"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 270,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV("th", {
								className: "py-2.5 px-3 text-center w-16",
								children: "Ação"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 271,
								columnNumber: 17
							}, this)
						] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 266,
							columnNumber: 15
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 265,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("tbody", {
						className: "divide-y divide-slate-100 dark:divide-slate-800",
						children: selectedCnaes.map((item) => /* @__PURE__ */ _jsxDEV("tr", {
							className: `hover:bg-slate-50/50 dark:hover:bg-slate-800/40 ${item.eh_principal ? "bg-teal-50/30 dark:bg-teal-950/20 font-medium" : ""}`,
							children: [
								/* @__PURE__ */ _jsxDEV("td", {
									className: "py-2.5 px-3 text-center",
									children: /* @__PURE__ */ _jsxDEV("input", {
										type: "radio",
										name: "cnae_principal_radio",
										checked: item.eh_principal,
										onChange: () => handleSetPrincipal(item.cnae_codigo),
										className: "text-teal-600 focus:ring-teal-500 h-3.5 w-3.5 cursor-pointer",
										title: "Definir como CNAE principal"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 285,
										columnNumber: 21
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 284,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("td", {
									className: "py-2.5 px-3",
									children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "font-mono font-semibold text-slate-900 dark:text-white block",
										children: item.cnae_codigo
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 295,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: "text-[11px] text-slate-600 dark:text-slate-400",
										children: item.descricao || "Atividade Econômica"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 298,
										columnNumber: 21
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 294,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("td", {
									className: "py-2.5 px-3",
									children: /* @__PURE__ */ _jsxDEV(RiscoBadge, {
										risco: item.grau_risco_padrao || "Risco II",
										size: "sm"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 303,
										columnNumber: 21
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 302,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("td", {
									className: "py-2.5 px-3",
									children: /* @__PURE__ */ _jsxDEV("div", {
										className: "flex flex-wrap gap-1",
										children: [
											item.exige_rt && /* @__PURE__ */ _jsxDEV("span", {
												className: "text-[10px] text-amber-700 dark:text-amber-300 bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 px-1 rounded",
												children: "Exige RT"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 311,
												columnNumber: 25
											}, this),
											item.exige_projeto_arquitetonico && /* @__PURE__ */ _jsxDEV("span", {
												className: "text-[10px] text-blue-700 dark:text-blue-300 bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-800 px-1 rounded",
												children: "Projeto Arq."
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 316,
												columnNumber: 25
											}, this),
											!item.exige_rt && !item.exige_projeto_arquitetonico && /* @__PURE__ */ _jsxDEV("span", {
												className: "text-[10px] text-slate-400",
												children: "Nenhuma"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 321,
												columnNumber: 25
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 309,
										columnNumber: 21
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 308,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("td", {
									className: "py-2.5 px-3 text-center",
									children: /* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										onClick: () => handleRemove(item.cnae_codigo),
										className: "p-1 text-slate-400 hover:text-rose-600 rounded transition-colors",
										title: "Remover CNAE",
										children: /* @__PURE__ */ _jsxDEV(Trash2, { className: "w-3.5 h-3.5" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 332,
											columnNumber: 23
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 326,
										columnNumber: 21
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 325,
									columnNumber: 19
								}, this)
							]
						}, item.cnae_codigo, true, {
							fileName: _jsxFileName,
							lineNumber: 276,
							columnNumber: 17
						}, this))
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 274,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 264,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 263,
				columnNumber: 9
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 130,
		columnNumber: 5
	}, this);
};
_s(CnaeSelectAsync, "yYcti7aPnr+s3wnGba91GLfS8Vc=", false, function() {
	return [useCNAEAutocomplete];
});
_c = CnaeSelectAsync;
export default CnaeSelectAsync;
var _c;
$RefreshReg$(_c, "CnaeSelectAsync");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/estabelecimentos/CnaeSelectAsync.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("E:/Projetos VSCODE/visa_braunas/src/components/estabelecimentos/CnaeSelectAsync.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("E:/Projetos VSCODE/visa_braunas/src/components/estabelecimentos/CnaeSelectAsync.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "E:/Projetos VSCODE/visa_braunas/src/components/estabelecimentos/CnaeSelectAsync.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7Ozs7QUFNQSxPQUFPLFNBQVMsV0FBVyxTQUFTLFFBQVEsZ0JBQWdCO0FBQzVELFNBQ0UsZUFFQSxPQUdBLE1BQ0EsUUFDQSxjQUVLO0FBQ1AsU0FBUywyQkFBMkI7QUFFcEMsT0FBTyxnQkFBZ0I7Ozs7QUFrQnZCLE9BQU8sTUFBTSxtQkFBbUQsRUFDOUQsZUFDQSxVQUNBLFlBQ0k7O0NBQ0osTUFBTSxDQUFDLFlBQVksaUJBQWlCLFNBQVMsRUFBRTtDQUMvQyxNQUFNLENBQUMsaUJBQWlCLHNCQUFzQixTQUFTLEVBQUU7Q0FDekQsTUFBTSxDQUFDLGNBQWMsbUJBQW1CLFNBQVMsS0FBSztDQUN0RCxNQUFNLGNBQWMsT0FBdUIsSUFBSTs7Q0FHL0MsZ0JBQWdCO0VBQ2QsTUFBTSxVQUFVLGlCQUFpQjtHQUMvQixtQkFBbUIsVUFBVTtFQUMvQixHQUFHLEdBQUc7RUFDTixhQUFhLGFBQWEsT0FBTztDQUNuQyxHQUFHLENBQUMsVUFBVSxDQUFDO0NBRWYsTUFBTSxFQUFFLE1BQU0sZ0JBQWdCLENBQUMsR0FBRyxjQUFjLG9CQUM5QyxlQUNGOztDQUdBLGdCQUFnQjtFQUNkLFNBQVMsbUJBQW1CLE9BQW1CO0dBQzdDLElBQ0UsWUFBWSxXQUNaLENBQUMsWUFBWSxRQUFRLFNBQVMsTUFBTSxNQUFjLEdBQ2xEO0lBQ0EsZ0JBQWdCLEtBQUs7R0FDdkI7RUFDRjtFQUNBLFNBQVMsaUJBQWlCLGFBQWEsa0JBQWtCO0VBQ3pELGFBQWEsU0FBUyxvQkFBb0IsYUFBYSxrQkFBa0I7Q0FDM0UsR0FBRyxDQUFDLENBQUM7O0NBR0wsTUFBTSxzQkFBc0IsY0FBYztFQUN4QyxPQUFPLGNBQWMsUUFBUSxNQUFNLEVBQUUsUUFBUTtDQUMvQyxHQUFHLENBQUMsYUFBYSxDQUFDOztDQUdsQixNQUFNLHFCQUFxQixjQUEwQjtFQUNuRCxJQUFJLGNBQWMsV0FBVyxHQUFHLE9BQU87RUFDdkMsTUFBTSxTQUFTLGNBQWMsS0FBSyxNQUFNLEVBQUUsaUJBQWlCO0VBQzNELElBQUksT0FBTyxTQUFTLFdBQVcsR0FBRyxPQUFPO0VBQ3pDLElBQUksT0FBTyxTQUFTLFVBQVUsR0FBRyxPQUFPO0VBQ3hDLElBQUksT0FBTyxTQUFTLFNBQVMsR0FBRyxPQUFPO0VBQ3ZDLE9BQU87Q0FDVCxHQUFHLENBQUMsYUFBYSxDQUFDO0NBRWxCLE1BQU0saUJBQWlCLFNBQW1CO0VBQ3hDLElBQUksY0FBYyxNQUFNLFNBQVMsS0FBSyxnQkFBZ0IsS0FBSyxNQUFNLEdBQUc7R0FDbEUsZ0JBQWdCLEtBQUs7R0FDckI7RUFDRjtFQUVBLE1BQU0sYUFBYSxjQUFjLFdBQVc7RUFDNUMsTUFBTSxXQUF5QjtHQUM3QixhQUFhLEtBQUs7R0FDbEIsV0FBVyxLQUFLO0dBQ2hCLG1CQUFtQixLQUFLO0dBQ3hCLFVBQVUsS0FBSztHQUNmLDZCQUE2QixLQUFLO0dBQ2xDLGNBQWM7R0FDZCx1QkFBdUIsSUFBSSxLQUFLLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDO0VBQzdEO0VBRUEsU0FBUyxDQUFDLEdBQUcsZUFBZSxRQUFRLENBQUM7RUFDckMsY0FBYyxFQUFFO0VBQ2hCLGdCQUFnQixLQUFLO0NBQ3ZCO0NBRUEsTUFBTSxzQkFBc0IsV0FBbUI7RUFDN0MsTUFBTSxjQUFjLGNBQWMsS0FBSyxVQUFVO0dBQy9DLEdBQUc7R0FDSCxjQUFjLEtBQUssZ0JBQWdCO0VBQ3JDLEVBQUU7RUFDRixTQUFTLFdBQVc7Q0FDdEI7Q0FFQSxNQUFNLGdCQUFnQixXQUFtQjtFQUN2QyxNQUFNLFlBQVksY0FBYyxRQUFRLFNBQVMsS0FBSyxnQkFBZ0IsTUFBTTs7RUFFNUUsSUFBSSxVQUFVLFNBQVMsS0FBSyxDQUFDLFVBQVUsTUFBTSxNQUFNLEVBQUUsWUFBWSxHQUFHO0dBQ2xFLFVBQVUsRUFBRSxDQUFDLGVBQWU7RUFDOUI7RUFDQSxTQUFTLFNBQVM7Q0FDcEI7Q0FFQSxPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQWY7R0FFRSx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFFBQUQ7S0FBTSxXQUFVO2VBQWdGO0lBRTFGOzs7O2NBQ04sd0JBQUMsS0FBRDtLQUFHLFdBQVU7ZUFBaUQ7SUFFM0Q7Ozs7WUFDQTs7OztjQUVMLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxRQUFEO01BQU0sV0FBVTtnQkFBeUM7S0FFbkQ7Ozs7ZUFDTix3QkFBQyxZQUFEO01BQVksT0FBTztNQUFvQixNQUFLO0tBQU07Ozs7YUFDL0M7Ozs7O1lBQ0Y7Ozs7OztHQUdKLG9CQUFvQixTQUFTLEtBQzVCLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxlQUFELEVBQWUsV0FBVSw2REFBOEQ7Ozs7Y0FDdkYsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLFFBQUQ7TUFBTSxXQUFVO2dCQUFzQjtLQUVoQzs7OztlQUNOLHdCQUFDLEtBQUQ7TUFBRyxXQUFVO2dCQUFiO09BQTJDO09BQzNCO09BQ2Qsd0JBQUMsVUFBRCxZQUNHLG9CQUFvQixLQUFLLE1BQU0sRUFBRSxXQUFXLENBQUMsQ0FBQyxLQUFLLElBQUksRUFDbEQ7Ozs7O09BQUU7T0FBSTtNQUViOzs7OzthQUNBOzs7OztZQUNGOzs7Ozs7R0FJUCx3QkFBQyxPQUFEO0lBQUssV0FBVTtJQUFXLEtBQUs7Y0FBL0IsQ0FDRSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsUUFBRCxFQUFRLFdBQVUsa0VBQW1FOzs7O2VBQ3JGLHdCQUFDLFNBQUQ7TUFDRSxNQUFLO01BQ0wsT0FBTztNQUNQLFdBQVcsTUFBTTtPQUNmLGNBQWMsRUFBRSxPQUFPLEtBQUs7T0FDNUIsZ0JBQWdCLElBQUk7TUFDdEI7TUFDQSxlQUFlLGdCQUFnQixJQUFJO01BQ25DLGFBQVk7TUFDWixXQUFVO0tBQ1g7Ozs7YUFDRTs7Ozs7Y0FHSixnQkFDQyx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUNaLFlBQ0Msd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQXlDO0tBRW5EOzs7O2dCQUNILGNBQWMsV0FBVyxJQUMzQix3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZjtPQUF3RDtPQUN4QjtPQUFnQjtNQUMzQzs7Ozs7Z0JBRUwsd0JBQUMsTUFBRDtNQUFJLFdBQVU7Z0JBQ1gsY0FBYyxLQUFLLFNBQVM7T0FDM0IsTUFBTSxnQkFBZ0IsY0FBYyxNQUNqQyxNQUFNLEVBQUUsZ0JBQWdCLEtBQUssTUFDaEM7T0FDQSxPQUNFLHdCQUFDLE1BQUQ7UUFFRSxlQUFlLENBQUMsaUJBQWlCLGNBQWMsSUFBSTtRQUNuRCxXQUFXLGdFQUNULGdCQUNJLG1FQUNBO2tCQU5SLENBU0Usd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDRSx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZjtXQUNFLHdCQUFDLFFBQUQ7WUFBTSxXQUFVO3NCQUNiLEtBQUs7V0FDRjs7Ozs7V0FDTix3QkFBQyxZQUFEO1lBQVksT0FBTyxLQUFLO1lBQW1CLE1BQUs7V0FBTTs7Ozs7V0FDckQsS0FBSyxZQUNKLHdCQUFDLFFBQUQ7WUFBTSxXQUFVO3NCQUFrSztXQUU1Szs7Ozs7V0FFUCxLQUFLLCtCQUNKLHdCQUFDLFFBQUQ7WUFBTSxXQUFVO3NCQUE0SjtXQUV0Szs7Ozs7VUFFTDs7Ozs7bUJBQ0wsd0JBQUMsS0FBRDtVQUFHLFdBQVU7b0JBQ1YsS0FBSztTQUNMOzs7O2lCQUNBOzs7OztrQkFFTCx3QkFBQyxVQUFEO1NBQ0UsTUFBSztTQUNMLFVBQVU7U0FDVixXQUFVO21CQUVULGdCQUNDLHdCQUFDLE9BQUQsRUFBTyxXQUFVLDJCQUE0Qjs7OztvQkFFN0Msd0JBQUMsTUFBRCxFQUFNLFdBQVUsVUFBVzs7Ozs7UUFFdkI7Ozs7Z0JBQ047VUF6Q0csS0FBSzs7OztjQXlDUjtNQUVSLENBQUM7S0FDQzs7Ozs7SUFFSDs7OztZQUVKOzs7Ozs7R0FFSixTQUFTLHdCQUFDLEtBQUQ7SUFBRyxXQUFVO2NBQXFDO0dBQVM7Ozs7O0dBR3BFLGNBQWMsV0FBVyxJQUN4Qix3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFnSDtHQUUxSDs7OztjQUVMLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQ2Isd0JBQUMsU0FBRDtLQUFPLFdBQVU7ZUFBakIsQ0FDRSx3QkFBQyxTQUFEO01BQU8sV0FBVTtnQkFDZix3QkFBQyxNQUFEO09BQ0Usd0JBQUMsTUFBRDtRQUFJLFdBQVU7a0JBQStCO09BQWE7Ozs7O09BQzFELHdCQUFDLE1BQUQ7UUFBSSxXQUFVO2tCQUFjO09BQXNCOzs7OztPQUNsRCx3QkFBQyxNQUFEO1FBQUksV0FBVTtrQkFBYztPQUFtQjs7Ozs7T0FDL0Msd0JBQUMsTUFBRDtRQUFJLFdBQVU7a0JBQWM7T0FBYzs7Ozs7T0FDMUMsd0JBQUMsTUFBRDtRQUFJLFdBQVU7a0JBQStCO09BQVE7Ozs7O01BQ25EOzs7OztLQUNDOzs7O2VBQ1Asd0JBQUMsU0FBRDtNQUFPLFdBQVU7Z0JBQ2QsY0FBYyxLQUFLLFNBQ2xCLHdCQUFDLE1BQUQ7T0FFRSxXQUFXLG1EQUNULEtBQUssZUFDRCxrREFDQTtpQkFMUjtRQVFFLHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUNaLHdCQUFDLFNBQUQ7VUFDRSxNQUFLO1VBQ0wsTUFBSztVQUNMLFNBQVMsS0FBSztVQUNkLGdCQUFnQixtQkFBbUIsS0FBSyxXQUFXO1VBQ25ELFdBQVU7VUFDVixPQUFNO1NBQ1A7Ozs7O1FBQ0M7Ozs7O1FBQ0osd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQWQsQ0FDRSx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFDYixLQUFLO1NBQ0Y7Ozs7bUJBQ04sd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQ2IsS0FBSyxhQUFhO1NBQ2Y7Ozs7aUJBQ0o7Ozs7OztRQUNKLHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUNaLHdCQUFDLFlBQUQ7VUFDRSxPQUFPLEtBQUsscUJBQXFCO1VBQ2pDLE1BQUs7U0FDTjs7Ozs7UUFDQzs7Ozs7UUFDSix3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFDWix3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZjtXQUNHLEtBQUssWUFDSix3QkFBQyxRQUFEO1lBQU0sV0FBVTtzQkFBNkk7V0FFdko7Ozs7O1dBRVAsS0FBSywrQkFDSix3QkFBQyxRQUFEO1lBQU0sV0FBVTtzQkFBdUk7V0FFako7Ozs7O1dBRVAsQ0FBQyxLQUFLLFlBQVksQ0FBQyxLQUFLLCtCQUN2Qix3QkFBQyxRQUFEO1lBQU0sV0FBVTtzQkFBNkI7V0FBYTs7Ozs7VUFFekQ7Ozs7OztRQUNIOzs7OztRQUNKLHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUNaLHdCQUFDLFVBQUQ7VUFDRSxNQUFLO1VBQ0wsZUFBZSxhQUFhLEtBQUssV0FBVztVQUM1QyxXQUFVO1VBQ1YsT0FBTTtvQkFFTix3QkFBQyxRQUFELEVBQVEsV0FBVSxjQUFlOzs7OztTQUMzQjs7Ozs7UUFDTjs7Ozs7T0FDRjtTQTFERyxLQUFLOzs7O2FBMERSLENBQ0w7S0FDSTs7OzthQUNGOzs7Ozs7R0FDSjs7Ozs7RUFFSjs7Ozs7O0FBRVQ7Ozs7O0FBRUEsZUFBZSIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJDbmFlU2VsZWN0QXN5bmMudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbIi8qKlxyXG4gKiBDb21wb25lbnRlIGRlIEJ1c2NhIEFzc8OtbmNyb25hIGUgR2VzdMOjbyBkZSBDTkFFcyBjb20gRGVib3VuY2VcclxuICogUGVybWl0ZSBzZWxlY2lvbmFyIGF0aXZpZGFkZXMgZG8gY2F0w6Fsb2dvIG9maWNpYWwsIGRlZmluaXIgZXN0cml0YW1lbnRlIDEgQ05BRSBwcmluY2lwYWxcclxuICogZSBzaW5hbGl6YSBhbGVydGFzIHJlZ3VsYXTDs3Jpb3MgKEV4aWfDqm5jaWEgZGUgUlQgZSBQcm9qZXRvIEFycXVpdGV0w7RuaWNvKS5cclxuICovXHJcblxyXG5pbXBvcnQgUmVhY3QsIHsgdXNlRWZmZWN0LCB1c2VNZW1vLCB1c2VSZWYsIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7XHJcbiAgQWxlcnRUcmlhbmdsZSxcclxuICBCdWlsZGluZyxcclxuICBDaGVjayxcclxuICBDaGVja0NpcmNsZTIsXHJcbiAgRmlsZUNoZWNrMixcclxuICBQbHVzLFxyXG4gIFNlYXJjaCxcclxuICBUcmFzaDIsXHJcbiAgVXNlckNoZWNrLFxyXG59IGZyb20gXCJsdWNpZGUtcmVhY3RcIjtcclxuaW1wb3J0IHsgdXNlQ05BRUF1dG9jb21wbGV0ZSB9IGZyb20gXCIuLi8uLi9ob29rcy91c2VFc3RhYmVsZWNpbWVudG9zXCI7XHJcbmltcG9ydCB7IENOQUVJdGVtLCBOaXZlbFJpc2NvIH0gZnJvbSBcIi4uLy4uL3R5cGVzL2VzdGFiZWxlY2ltZW50b1wiO1xyXG5pbXBvcnQgUmlzY29CYWRnZSBmcm9tIFwiLi9SaXNjb0JhZGdlXCI7XHJcblxyXG5leHBvcnQgaW50ZXJmYWNlIFNlbGVjdGVkQ05BRSB7XHJcbiAgY25hZV9jb2RpZ286IHN0cmluZztcclxuICBkZXNjcmljYW8/OiBzdHJpbmc7XHJcbiAgZ3JhdV9yaXNjb19wYWRyYW8/OiBOaXZlbFJpc2NvO1xyXG4gIGV4aWdlX3J0PzogYm9vbGVhbjtcclxuICBleGlnZV9wcm9qZXRvX2FycXVpdGV0b25pY28/OiBib29sZWFuO1xyXG4gIGVoX3ByaW5jaXBhbDogYm9vbGVhbjtcclxuICBkYXRhX2luaWNpb19hdGl2aWRhZGU/OiBzdHJpbmc7XHJcbn1cclxuXHJcbmludGVyZmFjZSBDbmFlU2VsZWN0QXN5bmNQcm9wcyB7XHJcbiAgc2VsZWN0ZWRDbmFlczogU2VsZWN0ZWRDTkFFW107XHJcbiAgb25DaGFuZ2U6IChjbmFlczogU2VsZWN0ZWRDTkFFW10pID0+IHZvaWQ7XHJcbiAgZXJyb3I/OiBzdHJpbmc7XHJcbn1cclxuXHJcbmV4cG9ydCBjb25zdCBDbmFlU2VsZWN0QXN5bmM6IFJlYWN0LkZDPENuYWVTZWxlY3RBc3luY1Byb3BzPiA9ICh7XHJcbiAgc2VsZWN0ZWRDbmFlcyxcclxuICBvbkNoYW5nZSxcclxuICBlcnJvcixcclxufSkgPT4ge1xyXG4gIGNvbnN0IFtzZWFyY2hUZXJtLCBzZXRTZWFyY2hUZXJtXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtkZWJvdW5jZWRTZWFyY2gsIHNldERlYm91bmNlZFNlYXJjaF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbZHJvcGRvd25PcGVuLCBzZXREcm9wZG93bk9wZW5dID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IGRyb3Bkb3duUmVmID0gdXNlUmVmPEhUTUxEaXZFbGVtZW50PihudWxsKTtcclxuXHJcbiAgLy8gRGVib3VuY2UgZGUgMzUwbXMgcGFyYSBldml0YXIgc29icmVjYXJnYSBkZSBjb25zdWx0YXNcclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgaGFuZGxlciA9IHNldFRpbWVvdXQoKCkgPT4ge1xyXG4gICAgICBzZXREZWJvdW5jZWRTZWFyY2goc2VhcmNoVGVybSk7XHJcbiAgICB9LCAzNTApO1xyXG4gICAgcmV0dXJuICgpID0+IGNsZWFyVGltZW91dChoYW5kbGVyKTtcclxuICB9LCBbc2VhcmNoVGVybV0pO1xyXG5cclxuICBjb25zdCB7IGRhdGE6IGNuYWVzQ2F0YWxvZ28gPSBbXSwgaXNMb2FkaW5nIH0gPSB1c2VDTkFFQXV0b2NvbXBsZXRlKFxyXG4gICAgZGVib3VuY2VkU2VhcmNoXHJcbiAgKTtcclxuXHJcbiAgLy8gRmVjaGEgbyBkcm9wZG93biBhbyBjbGljYXIgZm9yYVxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBmdW5jdGlvbiBoYW5kbGVDbGlja091dHNpZGUoZXZlbnQ6IE1vdXNlRXZlbnQpIHtcclxuICAgICAgaWYgKFxyXG4gICAgICAgIGRyb3Bkb3duUmVmLmN1cnJlbnQgJiZcclxuICAgICAgICAhZHJvcGRvd25SZWYuY3VycmVudC5jb250YWlucyhldmVudC50YXJnZXQgYXMgTm9kZSlcclxuICAgICAgKSB7XHJcbiAgICAgICAgc2V0RHJvcGRvd25PcGVuKGZhbHNlKTtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcihcIm1vdXNlZG93blwiLCBoYW5kbGVDbGlja091dHNpZGUpO1xyXG4gICAgcmV0dXJuICgpID0+IGRvY3VtZW50LnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJtb3VzZWRvd25cIiwgaGFuZGxlQ2xpY2tPdXRzaWRlKTtcclxuICB9LCBbXSk7XHJcblxyXG4gIC8vIEFsZXJ0YSBkZSBleGlnw6puY2lhIGRlIFJlc3BvbnPDoXZlbCBUw6ljbmljbyAoUlQpXHJcbiAgY29uc3QgY25hZXNDb21FeGlnZW5jaWFSVCA9IHVzZU1lbW8oKCkgPT4ge1xyXG4gICAgcmV0dXJuIHNlbGVjdGVkQ25hZXMuZmlsdGVyKChjKSA9PiBjLmV4aWdlX3J0KTtcclxuICB9LCBbc2VsZWN0ZWRDbmFlc10pO1xyXG5cclxuICAvLyBDw6FsY3VsbyB2aXN1YWwgZG8gUmlzY28gU2FuaXTDoXJpbyBQcmVwb25kZXJhbnRlXHJcbiAgY29uc3QgcmlzY29QcmVwb25kZXJhbnRlID0gdXNlTWVtbzxOaXZlbFJpc2NvPigoKSA9PiB7XHJcbiAgICBpZiAoc2VsZWN0ZWRDbmFlcy5sZW5ndGggPT09IDApIHJldHVybiBcIkRpc3BlbnNhZG9cIjtcclxuICAgIGNvbnN0IHJpc2NvcyA9IHNlbGVjdGVkQ25hZXMubWFwKChjKSA9PiBjLmdyYXVfcmlzY29fcGFkcmFvKTtcclxuICAgIGlmIChyaXNjb3MuaW5jbHVkZXMoXCJSaXNjbyBJSUlcIikpIHJldHVybiBcIlJpc2NvIElJSVwiO1xyXG4gICAgaWYgKHJpc2Nvcy5pbmNsdWRlcyhcIlJpc2NvIElJXCIpKSByZXR1cm4gXCJSaXNjbyBJSVwiO1xyXG4gICAgaWYgKHJpc2Nvcy5pbmNsdWRlcyhcIlJpc2NvIElcIikpIHJldHVybiBcIlJpc2NvIElcIjtcclxuICAgIHJldHVybiBcIkRpc3BlbnNhZG9cIjtcclxuICB9LCBbc2VsZWN0ZWRDbmFlc10pO1xyXG5cclxuICBjb25zdCBoYW5kbGVBZGRDbmFlID0gKGNuYWU6IENOQUVJdGVtKSA9PiB7XHJcbiAgICBpZiAoc2VsZWN0ZWRDbmFlcy5zb21lKChpdGVtKSA9PiBpdGVtLmNuYWVfY29kaWdvID09PSBjbmFlLmNvZGlnbykpIHtcclxuICAgICAgc2V0RHJvcGRvd25PcGVuKGZhbHNlKTtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG5cclxuICAgIGNvbnN0IGVoUHJpbWVpcm8gPSBzZWxlY3RlZENuYWVzLmxlbmd0aCA9PT0gMDtcclxuICAgIGNvbnN0IG5vdm9JdGVtOiBTZWxlY3RlZENOQUUgPSB7XHJcbiAgICAgIGNuYWVfY29kaWdvOiBjbmFlLmNvZGlnbyxcclxuICAgICAgZGVzY3JpY2FvOiBjbmFlLmRlc2NyaWNhbyxcclxuICAgICAgZ3JhdV9yaXNjb19wYWRyYW86IGNuYWUuZ3JhdV9yaXNjb19wYWRyYW8sXHJcbiAgICAgIGV4aWdlX3J0OiBjbmFlLmV4aWdlX3J0LFxyXG4gICAgICBleGlnZV9wcm9qZXRvX2FycXVpdGV0b25pY286IGNuYWUuZXhpZ2VfcHJvamV0b19hcnF1aXRldG9uaWNvLFxyXG4gICAgICBlaF9wcmluY2lwYWw6IGVoUHJpbWVpcm8sXHJcbiAgICAgIGRhdGFfaW5pY2lvX2F0aXZpZGFkZTogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLnNwbGl0KFwiVFwiKVswXSxcclxuICAgIH07XHJcblxyXG4gICAgb25DaGFuZ2UoWy4uLnNlbGVjdGVkQ25hZXMsIG5vdm9JdGVtXSk7XHJcbiAgICBzZXRTZWFyY2hUZXJtKFwiXCIpO1xyXG4gICAgc2V0RHJvcGRvd25PcGVuKGZhbHNlKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVTZXRQcmluY2lwYWwgPSAoY29kaWdvOiBzdHJpbmcpID0+IHtcclxuICAgIGNvbnN0IGF0dWFsaXphZG9zID0gc2VsZWN0ZWRDbmFlcy5tYXAoKGl0ZW0pID0+ICh7XHJcbiAgICAgIC4uLml0ZW0sXHJcbiAgICAgIGVoX3ByaW5jaXBhbDogaXRlbS5jbmFlX2NvZGlnbyA9PT0gY29kaWdvLFxyXG4gICAgfSkpO1xyXG4gICAgb25DaGFuZ2UoYXR1YWxpemFkb3MpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZVJlbW92ZSA9IChjb2RpZ286IHN0cmluZykgPT4ge1xyXG4gICAgY29uc3QgZmlsdHJhZG9zID0gc2VsZWN0ZWRDbmFlcy5maWx0ZXIoKGl0ZW0pID0+IGl0ZW0uY25hZV9jb2RpZ28gIT09IGNvZGlnbyk7XHJcbiAgICAvLyBTZSByZW1vdmV1IG8gcXVlIGVyYSBwcmluY2lwYWwsIGRlZmluZSBvIHByaW1laXJvIHJlc3RhbnRlIGNvbW8gcHJpbmNpcGFsXHJcbiAgICBpZiAoZmlsdHJhZG9zLmxlbmd0aCA+IDAgJiYgIWZpbHRyYWRvcy5zb21lKChpKSA9PiBpLmVoX3ByaW5jaXBhbCkpIHtcclxuICAgICAgZmlsdHJhZG9zWzBdLmVoX3ByaW5jaXBhbCA9IHRydWU7XHJcbiAgICB9XHJcbiAgICBvbkNoYW5nZShmaWx0cmFkb3MpO1xyXG4gIH07XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNFwiPlxyXG4gICAgICB7LyogQ2FiZcOnYWxobyBkYSBTZcOnw6NvIGNvbSBCYWRnZSBkZSBSaXNjbyBQcmVwb25kZXJhbnRlICovfVxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgc206ZmxleC1yb3cgc206aXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtMiBwYi0yIGJvcmRlci1iIGJvcmRlci1zbGF0ZS0xMDAgZGFyazpib3JkZXItc2xhdGUtODAwXCI+XHJcbiAgICAgICAgPGRpdj5cclxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGUgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCI+XHJcbiAgICAgICAgICAgIEF0aXZpZGFkZXMgRWNvbsO0bWljYXMgVmluY3VsYWRhcyAoQ05BRXMpXHJcbiAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LXNsYXRlLTUwMCBkYXJrOnRleHQtc2xhdGUtNDAwXCI+XHJcbiAgICAgICAgICAgIMOJIG9icmlnYXTDs3JpbyB2aW5jdWxhciBwZWxvIG1lbm9zIDEgYXRpdmlkYWRlIGVjb27DtG1pY2EsIGRlZmluaW5kbyBlc3RyaXRhbWVudGUgdW1hIGNvbW8gcHJpbmNpcGFsLlxyXG4gICAgICAgICAgPC9wPlxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LXNsYXRlLTUwMCBmb250LW1lZGl1bVwiPlxyXG4gICAgICAgICAgICBSaXNjbyBDYWxjdWxhZG86XHJcbiAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICA8UmlzY29CYWRnZSByaXNjbz17cmlzY29QcmVwb25kZXJhbnRlfSBzaXplPVwic21cIiAvPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIHsvKiBBbGVydGEgVmlzdWFsIGRlIEV4aWfDqm5jaWEgZGUgUlQgKi99XHJcbiAgICAgIHtjbmFlc0NvbUV4aWdlbmNpYVJULmxlbmd0aCA+IDAgJiYgKFxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0zIGJnLWFtYmVyLTUwIGRhcms6YmctYW1iZXItOTUwLzQwIGJvcmRlciBib3JkZXItYW1iZXItMjAwIGRhcms6Ym9yZGVyLWFtYmVyLTgwMCByb3VuZGVkLWxnIHRleHQteHMgdGV4dC1hbWJlci05MDAgZGFyazp0ZXh0LWFtYmVyLTIwMCBmbGV4IGl0ZW1zLXN0YXJ0IGdhcC0yLjVcIj5cclxuICAgICAgICAgIDxBbGVydFRyaWFuZ2xlIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1hbWJlci02MDAgZGFyazp0ZXh0LWFtYmVyLTQwMCBzaHJpbmstMCBtdC0wLjVcIiAvPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTFcIj5cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCBibG9ja1wiPlxyXG4gICAgICAgICAgICAgIEV4aWfDqm5jaWEgUmVndWxhdMOzcmlhIGRlIFJlc3BvbnPDoXZlbCBUw6ljbmljbyAoUlQpOlxyXG4gICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIGxlYWRpbmctcmVsYXhlZFwiPlxyXG4gICAgICAgICAgICAgIEFzIGF0aXZpZGFkZXN7XCIgXCJ9XHJcbiAgICAgICAgICAgICAgPHN0cm9uZz5cclxuICAgICAgICAgICAgICAgIHtjbmFlc0NvbUV4aWdlbmNpYVJULm1hcCgoYykgPT4gYy5jbmFlX2NvZGlnbykuam9pbihcIiwgXCIpfVxyXG4gICAgICAgICAgICAgIDwvc3Ryb25nPntcIiBcIn1cclxuICAgICAgICAgICAgICBleGlnZW0gYSBpbmRpY2HDp8OjbyBvYnJpZ2F0w7NyaWEgZGUgdW0gUmVzcG9uc8OhdmVsIFTDqWNuaWNvIGNvbSByZWdpc3RybyBhdGl2byBubyBDb25zZWxobyBkZSBDbGFzc2UgKGV4OiBDUkYsIENSTSwgQ1JCaW8pLlxyXG4gICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgKX1cclxuXHJcbiAgICAgIHsvKiBDYW1wbyBkZSBQZXNxdWlzYSBBdXRvY29tcGxldGUgY29tIERyb3Bkb3duICovfVxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlXCIgcmVmPXtkcm9wZG93blJlZn0+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZVwiPlxyXG4gICAgICAgICAgPFNlYXJjaCBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtc2xhdGUtNDAwIGFic29sdXRlIGxlZnQtMyB0b3AtMS8yIC10cmFuc2xhdGUteS0xLzJcIiAvPlxyXG4gICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgdmFsdWU9e3NlYXJjaFRlcm19XHJcbiAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4ge1xyXG4gICAgICAgICAgICAgIHNldFNlYXJjaFRlcm0oZS50YXJnZXQudmFsdWUpO1xyXG4gICAgICAgICAgICAgIHNldERyb3Bkb3duT3Blbih0cnVlKTtcclxuICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgb25Gb2N1cz17KCkgPT4gc2V0RHJvcGRvd25PcGVuKHRydWUpfVxyXG4gICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkRpZ2l0ZSBvIGPDs2RpZ28gKGV4OiA0NzcxLTcvMDEpIG91IGRlc2NyacOnw6NvIGRhIGF0aXZpZGFkZS4uLlwiXHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBwbC05IHByLTQgcHktMiBiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTMwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC1sZyB0ZXh0LXhzIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZSBwbGFjZWhvbGRlci1zbGF0ZS00MDAgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLXRlYWwtNTAwXCJcclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIHsvKiBEcm9wZG93biBkZSBSZXN1bHRhZG9zICovfVxyXG4gICAgICAgIHtkcm9wZG93bk9wZW4gJiYgKFxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSB6LTMwIG10LTEgdy1mdWxsIGJnLXdoaXRlIGRhcms6Ymctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLXhsIHNoYWRvdy1sZyBtYXgtaC02MCBvdmVyZmxvdy15LWF1dG9cIj5cclxuICAgICAgICAgICAge2lzTG9hZGluZyA/IChcclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNCB0ZXh0LWNlbnRlciB0ZXh0LXhzIHRleHQtc2xhdGUtNDAwXCI+XHJcbiAgICAgICAgICAgICAgICBQZXNxdWlzYW5kbyBjYXTDoWxvZ28gZGUgQ05BRXMuLi5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgKSA6IGNuYWVzQ2F0YWxvZ28ubGVuZ3RoID09PSAwID8gKFxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC00IHRleHQtY2VudGVyIHRleHQteHMgdGV4dC1zbGF0ZS00MDBcIj5cclxuICAgICAgICAgICAgICAgIE5lbmh1bSBDTkFFIGVuY29udHJhZG8gcGFyYSBcIntkZWJvdW5jZWRTZWFyY2h9XCIuXHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgPHVsIGNsYXNzTmFtZT1cImRpdmlkZS15IGRpdmlkZS1zbGF0ZS0xMDAgZGFyazpkaXZpZGUtc2xhdGUtODAwIHRleHQteHNcIj5cclxuICAgICAgICAgICAgICAgIHtjbmFlc0NhdGFsb2dvLm1hcCgoY25hZSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICBjb25zdCBqYVNlbGVjaW9uYWRvID0gc2VsZWN0ZWRDbmFlcy5zb21lKFxyXG4gICAgICAgICAgICAgICAgICAgIChpKSA9PiBpLmNuYWVfY29kaWdvID09PSBjbmFlLmNvZGlnb1xyXG4gICAgICAgICAgICAgICAgICApO1xyXG4gICAgICAgICAgICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgICAgICAgICAgIDxsaVxyXG4gICAgICAgICAgICAgICAgICAgICAga2V5PXtjbmFlLmlkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gIWphU2VsZWNpb25hZG8gJiYgaGFuZGxlQWRkQ25hZShjbmFlKX1cclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHAtMyBmbGV4IGl0ZW1zLXN0YXJ0IGp1c3RpZnktYmV0d2VlbiBnYXAtMyB0cmFuc2l0aW9uLWNvbG9ycyAke1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBqYVNlbGVjaW9uYWRvXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPyBcImJnLXNsYXRlLTUwIGRhcms6Ymctc2xhdGUtODAwLzQwIG9wYWNpdHktNjAgY3Vyc29yLW5vdC1hbGxvd2VkXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA6IFwiaG92ZXI6YmctdGVhbC01MC82MCBkYXJrOmhvdmVyOmJnLXNsYXRlLTgwMC84MCBjdXJzb3ItcG9pbnRlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICB9YH1cclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMC41XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1vbm8gZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtjbmFlLmNvZGlnb31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPFJpc2NvQmFkZ2UgcmlzY289e2NuYWUuZ3JhdV9yaXNjb19wYWRyYW99IHNpemU9XCJzbVwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge2NuYWUuZXhpZ2VfcnQgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gZm9udC1tZWRpdW0gdGV4dC1hbWJlci03MDAgZGFyazp0ZXh0LWFtYmVyLTMwMCBiZy1hbWJlci01MCBkYXJrOmJnLWFtYmVyLTk1MC80MCBib3JkZXIgYm9yZGVyLWFtYmVyLTIwMCBkYXJrOmJvcmRlci1hbWJlci04MDAgcHgtMS41IHB5LTAuMiByb3VuZGVkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEV4aWdlIFJUXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7Y25hZS5leGlnZV9wcm9qZXRvX2FycXVpdGV0b25pY28gJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gZm9udC1tZWRpdW0gdGV4dC1ibHVlLTcwMCBkYXJrOnRleHQtYmx1ZS0zMDAgYmctYmx1ZS01MCBkYXJrOmJnLWJsdWUtOTUwLzQwIGJvcmRlciBib3JkZXItYmx1ZS0yMDAgZGFyazpib3JkZXItYmx1ZS04MDAgcHgtMS41IHB5LTAuMiByb3VuZGVkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFByb2pldG8gQXJxdWl0ZXTDtG5pY29cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1zbGF0ZS02MDAgZGFyazp0ZXh0LXNsYXRlLTMwMCBsZWFkaW5nLXNudWdcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7Y25hZS5kZXNjcmljYW99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtqYVNlbGVjaW9uYWRvfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTEgcm91bmRlZCB0ZXh0LXRlYWwtNjAwIGhvdmVyOmJnLXRlYWwtMTAwIGRhcms6aG92ZXI6YmctdGVhbC05NTAvNjAgdHJhbnNpdGlvbi1jb2xvcnMgc2hyaW5rLTBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7amFTZWxlY2lvbmFkbyA/IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8Q2hlY2sgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LWVtZXJhbGQtNjAwXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8UGx1cyBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvbGk+XHJcbiAgICAgICAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgICAgICB9KX1cclxuICAgICAgICAgICAgICA8L3VsPlxyXG4gICAgICAgICAgICApfVxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgKX1cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICB7ZXJyb3IgJiYgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXJvc2UtNjAwIGZvbnQtbWVkaXVtXCI+e2Vycm9yfTwvcD59XHJcblxyXG4gICAgICB7LyogVGFiZWxhIGRlIENOQUVzIFNlbGVjaW9uYWRvcyAqL31cclxuICAgICAge3NlbGVjdGVkQ25hZXMubGVuZ3RoID09PSAwID8gKFxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC02IGJvcmRlciBib3JkZXItZGFzaGVkIGJvcmRlci1zbGF0ZS0zMDAgZGFyazpib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQteGwgdGV4dC1jZW50ZXIgdGV4dC14cyB0ZXh0LXNsYXRlLTUwMFwiPlxyXG4gICAgICAgICAgTmVuaHVtYSBhdGl2aWRhZGUgQ05BRSBhZGljaW9uYWRhLiBVdGlsaXplIGEgYnVzY2EgYWNpbWEgcGFyYSB2aW5jdWxhciBvIENOQUUgcHJpbmNpcGFsLlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICApIDogKFxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtODAwIHJvdW5kZWQteGwgb3ZlcmZsb3ctaGlkZGVuXCI+XHJcbiAgICAgICAgICA8dGFibGUgY2xhc3NOYW1lPVwidy1mdWxsIHRleHQtbGVmdCB0ZXh0LXhzXCI+XHJcbiAgICAgICAgICAgIDx0aGVhZCBjbGFzc05hbWU9XCJiZy1zbGF0ZS01MCBkYXJrOmJnLXNsYXRlLTgwMC82MCBib3JkZXItYiBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCB0ZXh0LXNsYXRlLTUwMCBmb250LXNlbWlib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LVsxMXB4XVwiPlxyXG4gICAgICAgICAgICAgIDx0cj5cclxuICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0yLjUgcHgtMyB0ZXh0LWNlbnRlciB3LTIwXCI+UHJpbmNpcGFsPC90aD5cclxuICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0yLjUgcHgtM1wiPkPDs2RpZ28gJiBEZXNjcmnDp8OjbzwvdGg+XHJcbiAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMi41IHB4LTNcIj5SaXNjbyBTYW5pdMOhcmlvPC90aD5cclxuICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0yLjUgcHgtM1wiPkV4aWfDqm5jaWFzPC90aD5cclxuICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0yLjUgcHgtMyB0ZXh0LWNlbnRlciB3LTE2XCI+QcOnw6NvPC90aD5cclxuICAgICAgICAgICAgICA8L3RyPlxyXG4gICAgICAgICAgICA8L3RoZWFkPlxyXG4gICAgICAgICAgICA8dGJvZHkgY2xhc3NOYW1lPVwiZGl2aWRlLXkgZGl2aWRlLXNsYXRlLTEwMCBkYXJrOmRpdmlkZS1zbGF0ZS04MDBcIj5cclxuICAgICAgICAgICAgICB7c2VsZWN0ZWRDbmFlcy5tYXAoKGl0ZW0pID0+IChcclxuICAgICAgICAgICAgICAgIDx0clxyXG4gICAgICAgICAgICAgICAgICBrZXk9e2l0ZW0uY25hZV9jb2RpZ299XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGhvdmVyOmJnLXNsYXRlLTUwLzUwIGRhcms6aG92ZXI6Ymctc2xhdGUtODAwLzQwICR7XHJcbiAgICAgICAgICAgICAgICAgICAgaXRlbS5laF9wcmluY2lwYWxcclxuICAgICAgICAgICAgICAgICAgICAgID8gXCJiZy10ZWFsLTUwLzMwIGRhcms6YmctdGVhbC05NTAvMjAgZm9udC1tZWRpdW1cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgOiBcIlwiXHJcbiAgICAgICAgICAgICAgICAgIH1gfVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMi41IHB4LTMgdGV4dC1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJyYWRpb1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiY25hZV9wcmluY2lwYWxfcmFkaW9cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17aXRlbS5laF9wcmluY2lwYWx9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KCkgPT4gaGFuZGxlU2V0UHJpbmNpcGFsKGl0ZW0uY25hZV9jb2RpZ28pfVxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC10ZWFsLTYwMCBmb2N1czpyaW5nLXRlYWwtNTAwIGgtMy41IHctMy41IGN1cnNvci1wb2ludGVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiRGVmaW5pciBjb21vIENOQUUgcHJpbmNpcGFsXCJcclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8L3RkPlxyXG4gICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMi41IHB4LTNcIj5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1vbm8gZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGUgYmxvY2tcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtpdGVtLmNuYWVfY29kaWdvfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LXNsYXRlLTYwMCBkYXJrOnRleHQtc2xhdGUtNDAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7aXRlbS5kZXNjcmljYW8gfHwgXCJBdGl2aWRhZGUgRWNvbsO0bWljYVwifVxyXG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTIuNSBweC0zXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPFJpc2NvQmFkZ2VcclxuICAgICAgICAgICAgICAgICAgICAgIHJpc2NvPXtpdGVtLmdyYXVfcmlzY29fcGFkcmFvIHx8IFwiUmlzY28gSUlcIn1cclxuICAgICAgICAgICAgICAgICAgICAgIHNpemU9XCJzbVwiXHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTIuNSBweC0zXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBnYXAtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2l0ZW0uZXhpZ2VfcnQgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LWFtYmVyLTcwMCBkYXJrOnRleHQtYW1iZXItMzAwIGJnLWFtYmVyLTUwIGRhcms6YmctYW1iZXItOTUwLzQwIGJvcmRlciBib3JkZXItYW1iZXItMjAwIGRhcms6Ym9yZGVyLWFtYmVyLTgwMCBweC0xIHJvdW5kZWRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBFeGlnZSBSVFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAge2l0ZW0uZXhpZ2VfcHJvamV0b19hcnF1aXRldG9uaWNvICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1ibHVlLTcwMCBkYXJrOnRleHQtYmx1ZS0zMDAgYmctYmx1ZS01MCBkYXJrOmJnLWJsdWUtOTUwLzQwIGJvcmRlciBib3JkZXItYmx1ZS0yMDAgZGFyazpib3JkZXItYmx1ZS04MDAgcHgtMSByb3VuZGVkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgUHJvamV0byBBcnEuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICB7IWl0ZW0uZXhpZ2VfcnQgJiYgIWl0ZW0uZXhpZ2VfcHJvamV0b19hcnF1aXRldG9uaWNvICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1zbGF0ZS00MDBcIj5OZW5odW1hPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTIuNSBweC0zIHRleHQtY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVSZW1vdmUoaXRlbS5jbmFlX2NvZGlnbyl9XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTEgdGV4dC1zbGF0ZS00MDAgaG92ZXI6dGV4dC1yb3NlLTYwMCByb3VuZGVkIHRyYW5zaXRpb24tY29sb3JzXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiUmVtb3ZlciBDTkFFXCJcclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8VHJhc2gyIGNsYXNzTmFtZT1cInctMy41IGgtMy41XCIgLz5cclxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICAgICAgICAgIDwvdHI+XHJcbiAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgIDwvdGJvZHk+XHJcbiAgICAgICAgICA8L3RhYmxlPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICApfVxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IENuYWVTZWxlY3RBc3luYztcclxuIl19